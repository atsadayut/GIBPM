﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;


public partial class Print_QLBatchPrinting : System.Web.UI.Page
{
    DataTable dt;
    //string strIssueDateFrom;
    //string strIssueDateTo;
    //string strBrokerCode;
    //string strPolicy;
    //string strPolicyTo;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            
            Utilities.SetBrokerCodeDefault();
            BindResultBrokerCode(ddlBrokerCode);
        }
    }

    private void BindResultBrokerCode(DropDownList ddlBrokerCode)
    {
        string GBBroker = System.Web.HttpContext.Current.Session["GroupBrokerID"].ToString();
        dt = Motor.GetGroupBrokerCode(GBBroker);
        DataRow dr = dt.NewRow();
        //dr["BROKERCODE"] = "ALL";
        //dr["BROKERNAME1"] = "เลือกทั้งหมด";
        //dt.Rows.InsertAt(dr, 0);

        //VEHICLE 
        ddlBrokerCode.DataSource = dt;
        ddlBrokerCode.DataTextField = "BROKERNAME1";
        ddlBrokerCode.DataValueField = "BROKERCODE";
        ddlBrokerCode.DataBind();
        dt.Clear();
    }

    protected void btnSearchByIssuedDate_Click(object sender, EventArgs e)
    {


        if (txbIssuedDateFrom.CalendarDateString.Trim().Length == 0 && txbIssuedDateTo.CalendarDateString.Trim().Length == 0)
        {
            lbSearchPrintMsg.Text = "โปรดใส่วันที่ Issue Date From และ To";
        }
        else if (txbIssuedDateFrom.CalendarDateString.Trim().Length >= 10 && txbIssuedDateTo.CalendarDateString.Trim().Length < 10)
        {
            lbSearchPrintMsg.Text = "โปรดใส่วันที่ Issue Date From และ To";
        }
        else if (txbIssuedDateFrom.CalendarDateString.Trim().Length < 10 && txbIssuedDateTo.CalendarDateString.Trim().Length >= 10)
        {
            lbSearchPrintMsg.Text = "โปรดใส่วันที่ Issue Date From และ To";
        }
        else
        {
            if (txbIssuedDateFrom.CalendarDate > txbIssuedDateTo.CalendarDate)
            {
                lbSearchPrintMsg.Text = "วันที่ Issue Date From และ To ไม่ถูกต้อง";
            }
            else
            {
                lbSearchPrintMsg.Text = "";
                string strIssueDateFrom = txbIssuedDateFrom.CalendarDateString.ToString();//.Substring(7, 4);// + "-" + txbIssuedDateFrom.CalendarDateString.ToString().Substring(4, 2) + "-" + txbIssuedDateFrom.CalendarDateString.ToString().Substring(1, 2);
                string strIssueDateTo = txbIssuedDateTo.CalendarDateString.ToString();//.Substring(7, 4); //+ "-" + txbIssuedDateTo.CalendarDateString.ToString().Substring(4, 2) + "-" + txbIssuedDateTo.CalendarDateString.ToString().Substring(1, 2);
                strIssueDateFrom = strIssueDateFrom.Substring(6, 4) + "-" + strIssueDateFrom.Substring(3, 2) + "-" + strIssueDateFrom.Substring(0, 2);
                strIssueDateTo = strIssueDateTo.Substring(6, 4) + "-" + strIssueDateTo.Substring(3, 2) + "-" + strIssueDateTo.Substring(0, 2);
                string strBrokerCode = ddlBrokerCode.SelectedValue;
                //if (strBrokerCode == "ALL") { strBrokerCode = ""; }
                selectDocumentIssueDate(rblPolicyDocument.SelectedValue.ToString(), strIssueDateFrom, strIssueDateTo, strBrokerCode);
                //Response.Redirect(QuickLinkConfiguration.UrlReportingService + "copy_tax_invoiceFeed&rs:Format=PDF&Policy=&IssueDateFrom=" + strIssueDateFrom + "&IssueDateTo=" + strIssueDateTo + "&BrokerCode=" + strBrokerCode);

            }
        }
    }
    protected void btnSearchByPolicy_Click(object sender, EventArgs e)
    {
        //if (txbPolicyFrom.Text.Length < 8)
        //{
        //    lbSearchPrintMsg.Text = "โปรดใส่เลขกรมธรรม์";
        //}
        //else
        //{
        lbSearchPrintMsg.Text = "";

        string strPolicy = txbPolicyFrom.Text;
        string strPolicyTo = txbPolicyTo.Text;
        if (strPolicyTo.Trim().Length == 0) { strPolicyTo = strPolicy; }
        string strBrokerCode = ddlBrokerCode.SelectedValue;


        string strIssueDateFrom = txbIssuedDateFrom.CalendarDateString.ToString();//.Substring(7, 4);// + "-" + txbIssuedDateFrom.CalendarDateString.ToString().Substring(4, 2) + "-" + txbIssuedDateFrom.CalendarDateString.ToString().Substring(1, 2);
        string strIssueDateTo = txbIssuedDateTo.CalendarDateString.ToString();//.Substring(7, 4); //+ "-" + txbIssuedDateTo.CalendarDateString.ToString().Substring(4, 2) + "-" + txbIssuedDateTo.CalendarDateString.ToString().Substring(1, 2);
        if (strIssueDateFrom.Length > 0 && strIssueDateTo.Length > 0)
        {
            strIssueDateFrom = strIssueDateFrom.Substring(6, 4) + "-" + strIssueDateFrom.Substring(3, 2) + "-" + strIssueDateFrom.Substring(0, 2);
            strIssueDateTo = strIssueDateTo.Substring(6, 4) + "-" + strIssueDateTo.Substring(3, 2) + "-" + strIssueDateTo.Substring(0, 2);
        }
        selectDocumentPolicyNo(rblPolicyDocument.SelectedValue.ToString(), strPolicy, strPolicyTo, strIssueDateFrom, strIssueDateTo, strBrokerCode);
        //Response.Redirect(QuickLinkConfiguration.UrlReportingService + "copy_tax_invoiceFeedP&rs:Format=PDF&Policy=" + strPolicy + "&PolicyTo=" + strPolicyTo + "&BrokerCode=" + strBrokerCode);

        //}

    }
    protected void selectDocumentIssueDate(string intDocumentValue, string strIssueDateFrom, string strIssueDateTo, string strBrokerCode)
    {
        switch (intDocumentValue)
        {
            case "1":
                Response.Redirect(QuickLinkConfiguration.UrlReportingService + "copy_tax_invoiceFeed&rs:Format=PDF&Policy=&IssueDateFrom=" + strIssueDateFrom + "&IssueDateTo=" + strIssueDateTo + "&BrokerCode=" + strBrokerCode);
                break;
            case "2":
                Response.Redirect(QuickLinkConfiguration.UrlReportingService + "copy_tax_invoiceFeed&rs:Format=PDF&Policy=&IssueDateFrom=" + strIssueDateFrom + "&IssueDateTo=" + strIssueDateTo + "&BrokerCode=" + strBrokerCode);
                break;
            case "3":
                Response.Redirect(QuickLinkConfiguration.UrlReportingService + "copy_tax_invoiceFeed&rs:Format=PDF&Policy=&IssueDateFrom=" + strIssueDateFrom + "&IssueDateTo=" + strIssueDateTo + "&BrokerCode=" + strBrokerCode);
                break;
            case "4":
                Response.Redirect(QuickLinkConfiguration.UrlReportingService + "copy_tax_invoiceFeed&rs:Format=PDF&Policy=&IssueDateFrom=" + strIssueDateFrom + "&IssueDateTo=" + strIssueDateTo + "&BrokerCode=" + strBrokerCode);
                break;
            case "5":
                Response.Redirect(QuickLinkConfiguration.UrlReportingService + "copy_tax_invoiceFeed&rs:Format=PDF&Policy=&IssueDateFrom=" + strIssueDateFrom + "&IssueDateTo=" + strIssueDateTo + "&BrokerCode=" + strBrokerCode);
                break;
            case "6":
                Response.Redirect(QuickLinkConfiguration.UrlReportingService + "copy_tax_invoiceFeed&rs:Format=PDF&Policy=&IssueDateFrom=" + strIssueDateFrom + "&IssueDateTo=" + strIssueDateTo + "&BrokerCode=" + strBrokerCode);
                break;
            default:
                break;
        }
    }

    protected void selectDocumentPolicyNo(string intDocumentValue, string strPolicy, string strPolicyTo, string strIssueDateFrom, string strIssueDateTo, string strBrokerCode)
    {
        switch (intDocumentValue)
        {
            case "1":
                //Printing.setCountOriginalPrinting("1", strPolicy, strPolicyTo, strIssueDateFrom, strIssueDateTo, strBrokerCode);
                Response.Redirect(QuickLinkConfiguration.UrlReportingService + "QLOriginalVoluntory123&rs:Format=PDF&Policy=" + strPolicy + "&PolicyTo=" + strPolicyTo + "&IssueDateFrom=" + strIssueDateFrom + "&IssueDateTo=" + strIssueDateTo + "&BrokerCode=" + strBrokerCode);
                break;
            case "2":
                //Printing.setCountOriginalPrinting("2", strPolicy, strPolicyTo, strIssueDateFrom, strIssueDateTo, strBrokerCode);
                Response.Redirect(QuickLinkConfiguration.UrlReportingService + "QLOriginalVoluntory5&rs:Format=PDF&Policy=" + strPolicy + "&PolicyTo=" + strPolicyTo + "&IssueDateFrom=" + strIssueDateFrom + "&IssueDateTo=" + strIssueDateTo + "&BrokerCode=" + strBrokerCode);
                break;
            case "3":
                //Printing.setCountOriginalPrinting("3", strPolicy, strPolicyTo, strIssueDateFrom, strIssueDateTo, strBrokerCode);
                Response.Redirect(QuickLinkConfiguration.UrlReportingService + "QLOriginalCompulsory&rs:Format=PDF&Policy=" + strPolicy + "&PolicyTo=" + strPolicyTo + "&IssueDateFrom=" + strIssueDateFrom + "&IssueDateTo=" + strIssueDateTo + "&BrokerCode=" + strBrokerCode);
                break;
            default:
                break;
        }
    }
    protected void btnSearchByCopy_Click(object sender, EventArgs e)
    {
        lbSearchPrintMsg.Text = "";

        string strPolicy = txbPolicyFrom.Text;
        string strPolicyTo = txbPolicyTo.Text;
        if (strPolicyTo.Trim().Length == 0) { strPolicyTo = strPolicy; }
        string strBrokerCode = ddlBrokerCode.SelectedValue;


        string strIssueDateFrom = txbIssuedDateFrom.CalendarDateString.ToString();//.Substring(7, 4);// + "-" + txbIssuedDateFrom.CalendarDateString.ToString().Substring(4, 2) + "-" + txbIssuedDateFrom.CalendarDateString.ToString().Substring(1, 2);
        string strIssueDateTo = txbIssuedDateTo.CalendarDateString.ToString();//.Substring(7, 4); //+ "-" + txbIssuedDateTo.CalendarDateString.ToString().Substring(4, 2) + "-" + txbIssuedDateTo.CalendarDateString.ToString().Substring(1, 2);
        if (strIssueDateFrom.Length > 0 && strIssueDateTo.Length > 0)
        {
            strIssueDateFrom = strIssueDateFrom.Substring(6, 4) + "-" + strIssueDateFrom.Substring(3, 2) + "-" + strIssueDateFrom.Substring(0, 2);
            strIssueDateTo = strIssueDateTo.Substring(6, 4) + "-" + strIssueDateTo.Substring(3, 2) + "-" + strIssueDateTo.Substring(0, 2);
        }
        selectDocumentPolicyNoCopy(rblPolicyDocument.SelectedValue.ToString(), strPolicy, strPolicyTo, strIssueDateFrom, strIssueDateTo, strBrokerCode);

    }
    protected void selectDocumentPolicyNoCopy(string intDocumentValue, string strPolicy, string strPolicyTo, string strIssueDateFrom, string strIssueDateTo, string strBrokerCode)
    {
        switch (intDocumentValue)
        {
            case "1":
                Response.Redirect(QuickLinkConfiguration.UrlReportingService + "QLCopyVoluntory123&rs:Format=PDF&Policy=" + strPolicy + "&PolicyTo=" + strPolicyTo + "&IssueDateFrom=" + strIssueDateFrom + "&IssueDateTo=" + strIssueDateTo + "&BrokerCode=" + strBrokerCode);
                break;
            case "2":
                Response.Redirect(QuickLinkConfiguration.UrlReportingService + "QLCopyVoluntory5&rs:Format=PDF&Policy=" + strPolicy + "&PolicyTo=" + strPolicyTo + "&IssueDateFrom=" + strIssueDateFrom + "&IssueDateTo=" + strIssueDateTo + "&BrokerCode=" + strBrokerCode);
                break;
            case "3":
                Response.Redirect(QuickLinkConfiguration.UrlReportingService + "QLCopyCompulsory&rs:Format=PDF&Policy=" + strPolicy + "&PolicyTo=" + strPolicyTo + "&IssueDateFrom=" + strIssueDateFrom + "&IssueDateTo=" + strIssueDateTo + "&BrokerCode=" + strBrokerCode);
                break;
            default:
                break;
        }
    }

    protected void bthSumLetter_Click(object sender, EventArgs e)
    {
        lbSearchPrintMsg.Text = "";

        string strPolicy = txbPolicyFrom.Text;
        string strPolicyTo = txbPolicyTo.Text;
        if (strPolicyTo.Trim().Length == 0) { strPolicyTo = strPolicy; }
        string strBrokerCode = ddlBrokerCode.SelectedValue;


        string strIssueDateFrom = txbIssuedDateFrom.CalendarDateString.ToString();//.Substring(7, 4);// + "-" + txbIssuedDateFrom.CalendarDateString.ToString().Substring(4, 2) + "-" + txbIssuedDateFrom.CalendarDateString.ToString().Substring(1, 2);
        string strIssueDateTo = txbIssuedDateTo.CalendarDateString.ToString();//.Substring(7, 4); //+ "-" + txbIssuedDateTo.CalendarDateString.ToString().Substring(4, 2) + "-" + txbIssuedDateTo.CalendarDateString.ToString().Substring(1, 2);
        if (strIssueDateFrom.Length > 0 && strIssueDateTo.Length > 0)
        {
            strIssueDateFrom = strIssueDateFrom.Substring(6, 4) + "-" + strIssueDateFrom.Substring(3, 2) + "-" + strIssueDateFrom.Substring(0, 2);
            strIssueDateTo = strIssueDateTo.Substring(6, 4) + "-" + strIssueDateTo.Substring(3, 2) + "-" + strIssueDateTo.Substring(0, 2);
        }
        selectDocumentPolicyReport(rblPolicyDocument.SelectedValue.ToString(), strPolicy, strPolicyTo, strIssueDateFrom, strIssueDateTo, strBrokerCode);
    }

    protected void selectDocumentPolicyReport(string intDocumentValue, string strPolicy, string strPolicyTo, string strIssueDateFrom, string strIssueDateTo, string strBrokerCode)
    {
        switch (intDocumentValue)
        {
            case "1":
                Response.Redirect(QuickLinkConfiguration.UrlReportingService + "QLReportVoluntory123&rs:Format=PDF&Policy=" + strPolicy + "&PolicyTo=" + strPolicyTo + "&IssueDateFrom=" + strIssueDateFrom + "&IssueDateTo=" + strIssueDateTo + "&BrokerCode=" + strBrokerCode);
                break;
            case "2":
                Response.Redirect(QuickLinkConfiguration.UrlReportingService + "QLReportVoluntory5&rs:Format=PDF&Policy=" + strPolicy + "&PolicyTo=" + strPolicyTo + "&IssueDateFrom=" + strIssueDateFrom + "&IssueDateTo=" + strIssueDateTo + "&BrokerCode=" + strBrokerCode);
                break;
            case "3":
                Response.Redirect(QuickLinkConfiguration.UrlReportingService + "QLReportCompulsory&rs:Format=PDF&Policy=" + strPolicy + "&PolicyTo=" + strPolicyTo + "&IssueDateFrom=" + strIssueDateFrom + "&IssueDateTo=" + strIssueDateTo + "&BrokerCode=" + strBrokerCode);
                break;
            default:
                break;
        }
    }
}