using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using WFQuickLink;
using WFQuickLinkReport;

public partial class Print_MiddlePage : System.Web.UI.Page
{
    string volunpolicy = "";
    string complpolicy = "";

    DataTable dt;
    protected void Page_Load(object sender, EventArgs e)
    {
        volunpolicy = Request.QueryString["volun"].ToString().Trim();
        complpolicy = Request.QueryString["compl"].ToString().Trim();


        if (!IsPostBack)
        {

            try
            {
                //lbWaiting.Text = "�ô���ѡ�����к����ѧ�����ż� !";
                dt = new DataTable();

                string complPolicy = complpolicy;
                string volunPolicy = volunpolicy;

                #region "GET DATA FOR CONDITION INSERT JPACKAGE"
                dt = PolicyReprint.GetPolicyListForPrintToInsertTableJoinPackage(volunPolicy, complPolicy);

                string PolicyType = ""; //BOTH
                string PolicyClassType = ""; //Class 1
                string Fleet = "";      //0
                string Split = "";      //1
                string PolicyNumberVolun = ""; //P0159001
                string PolicyNumberCompl = ""; //P0159001
                string Barcode = "";    //5439999990000  
                if (dt.Rows.Count > 0)
                {
                    PolicyType = dt.Rows[0]["POLICYCREATETYPE"].ToString().Trim();
                    PolicyClassType = dt.Rows[0]["POLICYPACKAGETYPE"].ToString().Trim();
                    Fleet = dt.Rows[0]["ISFLEET"].ToString();
                    Split = (dt.Rows[0]["ISSPLITVAT"].ToString());
                    PolicyNumberVolun = dt.Rows[0]["VOLUNPOLICYNO"].ToString().Trim();
                    PolicyNumberCompl = dt.Rows[0]["COMPLPOLICYNO"].ToString().Trim();
                    Barcode = dt.Rows[0]["BARCODE"].ToString().Trim();

                    //VOLUN,Class 1,Not Fleet(0),Split(1),P0159000,Barcode("")
                    //Policy.InsertJoinPackage(VOLUN, tempClassType, "0","1", OutPolicyNumber, "");
                    //Policy.InsertJoinPackage("BOTH", tempClassType, "0", "1", OutPolicyNumber, "");

                    //Response.Write(PolicyType + "<br>");
                    //Response.Write(PolicyClassType + "<br>");
                    //Response.Write(Fleet + "<br>");
                    //Response.Write(Split + "<br>");
                    //Response.Write(PolicyNumberVolun + "<br>");
                    //Response.Write(PolicyNumberCompl + "<br>");
                    //Response.Write(Barcode + "<br>");

                    //Response.Write(job + "<br>");
                    //Response.Write(volunPolicy + "<br>");
                    //Response.Write(complPolicy + "<br>");

                }
                #endregion

                #region "CHECK POLICY IN TABLE JPACKAGE AND INSERT FOR CASE NOT FOUND POLICY NO OF IT"
                //CHECK POLICY IN TABLE REPORTJPACKAGE IN QUICKLINKREPORT DB
                //TEXT:
                //VALUE

                bool bTmpComp = false;
                bool bTmpVolun = false;
                bool bTmpGetDBorAS400 = false;
                DocumentService reportService = new DocumentService();
                DataTable dtVolun = new DataTable();
                DataTable dtCompl = new DataTable();
                Box_Document[] arrPolicyQutReport;
                Box_Document PolicyOutReportData;
                Box_Message[] arrMessageOutReport;

                string spoolName = "";
                int count = 0;
                int i = 0;

                #region "GET USER HOST"
                UserHostDetails user;
                user = UserMember.GetUserHost(Utilities.GetUsername().Trim());
                string Username = user.UserHostName.ToString();
                string Password = user.UserHostPassword.ToString();
                #endregion

                switch (PolicyType)
                {
                    case "BOTH"://�Ҥ�ѧ�Ѻ����Ҥ��Ѥ��
                        //CHECK POLICY IN TABLE REPORTJPACKAGE
                        bTmpComp = PolicyReprint.chkPolicyInReportJPackage(PolicyNumberCompl);
                        bTmpVolun = PolicyReprint.chkPolicyInReportJPackage(PolicyNumberVolun);
                        if (bTmpVolun && bTmpComp)
                        {
                            //have twin policy
                            //1.call service //or 2 call list print
                            //CHECK DATA FLAG FOR GET REPORT
                            bTmpGetDBorAS400 = PolicyReprint.chkPolicyReprintIsGetReportInDB(PolicyNumberCompl);
                            if (bTmpGetDBorAS400)
                            {
                                //REDIRECT TO LIST PRINT
                                #region "STEP2:REDIRECT TO LIST PRINT BOTH"
                                //Response.Redirect("../Report/ListPrint2.aspx?volun=" + PolicyNumberVolun + "&compl=" + PolicyNumberCompl);
                                #endregion
                            }
                            else
                            {
                                //FALSE GET SPOOL FILE AS/400
                                #region "STEP2:BOTH GET REPORT LIST AND GET CONTENT SPOOL FILE  FROM AS/400 WRITE TO DB QUICKLINK REPORT"
                                if (PolicyNumberVolun.Equals("") | PolicyNumberVolun == string.Empty)
                                {
                                    //lbSearchPrintMsg.Text = "�Դ��ͼԴ��Ҵ! �������ö���������������� ���ͧ�ҡ��������ͧ �Ҥ��Ѥ�� �����١���ҧ  ��سҵԴ��� AXA!";
                                    return;
                                }
                                if (PolicyNumberCompl.Equals("") | PolicyNumberCompl == string.Empty)
                                {
                                    //lbSearchPrintMsg.Text = "�Դ��ͼԴ��Ҵ! �������ö���������������� ���ͧ�ҡ��������ͧ �Ҥ�ѧ�Ѻ �����١���ҧ  ��سҵԴ��� AXA!";
                                    return;
                                }
                                dtVolun = Reports.GetListSpool(PolicyNumberVolun);
                                dtCompl = Reports.GetListSpool(PolicyNumberCompl);

                                spoolName = "";
                                count = dtVolun.Rows.Count + dtCompl.Rows.Count;
                                arrPolicyQutReport = new Box_Document[count];
                                bool bCombind = false;
                                i = 0;
                                if (dtVolun.Rows.Count > 0)
                                {
                                    foreach (DataRow dr in dtVolun.Rows)
                                    {
                                        PolicyOutReportData = new Box_Document();
                                        spoolName = dr["SpoolName"].ToString();
                                        PolicyOutReportData.PolicyNo = PolicyNumberVolun;
                                        PolicyOutReportData.Document = spoolName;
                                        PolicyOutReportData.Flag = true;
                                        arrPolicyQutReport[i] = PolicyOutReportData;
                                        i += 1;
                                    }
                                }
                                if (dtCompl.Rows.Count > 0)
                                {
                                    foreach (DataRow dr in dtCompl.Rows)
                                    {
                                        PolicyOutReportData = new Box_Document();
                                        spoolName = dr["SpoolName"].ToString();
                                        PolicyOutReportData.PolicyNo = PolicyNumberCompl;
                                        PolicyOutReportData.Document = spoolName;
                                        PolicyOutReportData.Flag = true;
                                        arrPolicyQutReport[i] = PolicyOutReportData;
                                        i += 1;
                                    }
                                    try
                                    {
                                        arrMessageOutReport = reportService.GetDocument(arrPolicyQutReport, Username, Password);
                                        bCombind = true;
                                    }
                                    catch (Exception ex)
                                    {
                                        //lbSearchPrintMsg.Text = "�Դ��ͼԴ��Ҵ! 㹡�����¡����������Ѻ�������������� ��سҵԴ��� AXA!";
                                        ex.Source += "Reprint Both : �Դ��ͼԴ��Ҵ! 㹡�����¡����������Ѻ�������������� ��سҵԴ��� AXA!";
                                        Utilities.LogError(ex);
                                        throw ex;
                                    }
                                }
                                if (bCombind)
                                {
                                    //LINK TO LIST PRINT PAGE 
                                    //Response.Redirect("../Report/ListPrint2.aspx?volun=" + PolicyNumberVolun + "&compl=" + PolicyNumberCompl);
                                }
                                else
                                {
                                    //lbSearchPrintMsg.Text = "�Դ��ͼԴ��Ҵ! 㹡�����¡����������Ѻ�������������� ��سҵԴ��� AXA!";
                                    return;
                                }
                                #endregion
                            }
                        }
                        else
                        {
                            //Response.Write("NOT HAVE <br>");
                            //NOT HAVE THIS POLICY INTABLE REPORT JOIN PACKAGE  SO INSERT IT
                            #region "STEP1:INSERT DATA FOR LIST PRINT"
                            Policy.InsertJoinPackage("BOTHC", PolicyClassType, Fleet, Split, PolicyNumberCompl, Barcode);
                            Policy.InsertJoinPackage("BOTH", PolicyClassType, Fleet, Split, PolicyNumberVolun, "");
                            #endregion

                            #region "STEP2:BOTH GET REPORT LIST AND GET CONTENT SPOOL FILE  FROM AS/400 WRITE TO DB QUICKLINK REPORT"
                            if (PolicyNumberVolun.Equals("") | PolicyNumberVolun == string.Empty)
                            {
                                //lbSearchPrintMsg.Text = "�Դ��ͼԴ��Ҵ! �������ö���������������� ���ͧ�ҡ��������ͧ �Ҥ��Ѥ�� �����١���ҧ  ��سҵԴ��� AXA!";
                                return;
                            }
                            if (PolicyNumberCompl.Equals("") | PolicyNumberCompl == string.Empty)
                            {
                                //lbSearchPrintMsg.Text = "�Դ��ͼԴ��Ҵ! �������ö���������������� ���ͧ�ҡ��������ͧ �Ҥ�ѧ�Ѻ �����١���ҧ  ��سҵԴ��� AXA!";
                                return;
                            }
                            dtVolun = Reports.GetListSpool(PolicyNumberVolun);
                            dtCompl = Reports.GetListSpool(PolicyNumberCompl);

                            spoolName = "";
                            count = dtVolun.Rows.Count + dtCompl.Rows.Count;
                            arrPolicyQutReport = new Box_Document[count];
                            bool bCombind = false;
                            i = 0;
                            if (dtVolun.Rows.Count > 0)
                            {
                                foreach (DataRow dr in dtVolun.Rows)
                                {
                                    PolicyOutReportData = new Box_Document();
                                    spoolName = dr["SpoolName"].ToString();
                                    PolicyOutReportData.PolicyNo = PolicyNumberVolun;
                                    PolicyOutReportData.Document = spoolName;
                                    PolicyOutReportData.Flag = true;
                                    arrPolicyQutReport[i] = PolicyOutReportData;
                                    i += 1;
                                }
                            }
                            if (dtCompl.Rows.Count > 0)
                            {
                                foreach (DataRow dr in dtCompl.Rows)
                                {
                                    PolicyOutReportData = new Box_Document();
                                    spoolName = dr["SpoolName"].ToString();
                                    PolicyOutReportData.PolicyNo = PolicyNumberCompl;
                                    PolicyOutReportData.Document = spoolName;
                                    PolicyOutReportData.Flag = true;
                                    arrPolicyQutReport[i] = PolicyOutReportData;
                                    i += 1;
                                }
                                try
                                {
                                    arrMessageOutReport = reportService.GetDocument(arrPolicyQutReport, Username, Password);
                                    bCombind = true;
                                }
                                catch (Exception ex)
                                {
                                    //lbSearchPrintMsg.Text = "�Դ��ͼԴ��Ҵ! 㹡�����¡����������Ѻ�������������� ��سҵԴ��� AXA!";
                                    ex.Source += "Reprint Both : �Դ��ͼԴ��Ҵ! 㹡�����¡����������Ѻ�������������� ��سҵԴ��� AXA!";
                                    Utilities.LogError(ex);
                                    throw ex;
                                }
                            }
                            if (bCombind)
                            {
                                //LINK TO LIST PRINT PAGE 
                                //Response.Redirect("../Report/ListPrint2.aspx?volun=" + PolicyNumberVolun + "&compl=" + PolicyNumberCompl);
                            }
                            else
                            {
                                //lbSearchPrintMsg.Text = "�Դ��ͼԴ��Ҵ! 㹡�����¡����������Ѻ�������������� ��سҵԴ��� AXA!";
                                return;
                            }
                            #endregion
                        }
                        break;
                    case "COMPL": //�Ҥ�ѧ�Ѻ
                        //CHECK POLICY IN TABLE REPORTJPACKAGE
                        bTmpComp = PolicyReprint.chkPolicyInReportJPackage(PolicyNumberCompl);
                        if (bTmpComp)
                        {
                            //have  policy
                            //CHECK DATA FLAG FOR GET REPORT
                            bTmpGetDBorAS400 = PolicyReprint.chkPolicyReprintIsGetReportInDB(PolicyNumberCompl);
                            if (bTmpGetDBorAS400)
                            {
                                //TRUE GET REPORT DATA IN DB
                                //REDIRECT TO LIST PRINT
                                #region "STEP2:REDIRECT TO LIST PRINT COMPL"
                                //Response.Redirect("../Report/ListPrint2.aspx?volun=&compl=" + PolicyNumberCompl);
                                #endregion
                            }
                            else
                            {
                                //FALSE GET SPOOL FILE AS/400
                                #region "STEP2:COMPL GET REPORT LIST AND GET CONTENT SPOOL FILE  FROM AS/400 WRITE TO DB QUICKLINK REPORT"
                                if (PolicyNumberCompl.Equals("") | PolicyNumberCompl == string.Empty)
                                {
                                    return;
                                }

                                //GET LIST FILE FOR GET NAME SPOOL BY POLICY
                                dtVolun = Reports.GetListSpool(PolicyNumberCompl);

                                spoolName = "";
                                count = dtVolun.Rows.Count;
                                arrPolicyQutReport = new Box_Document[count];
                                i = 0;

                                if (count > 0)
                                {
                                    foreach (DataRow dr in dtVolun.Rows)
                                    {
                                        PolicyOutReportData = new Box_Document();
                                        spoolName = dr["SpoolName"].ToString();
                                        PolicyOutReportData.PolicyNo = PolicyNumberCompl;
                                        PolicyOutReportData.Document = spoolName;
                                        PolicyOutReportData.Flag = true;
                                        arrPolicyQutReport[i] = PolicyOutReportData;
                                        i += 1;
                                    }
                                    try
                                    {
                                        //GET SPOOL FROM AS/400 WRITE TO DATABASE
                                        arrMessageOutReport = reportService.GetDocument(arrPolicyQutReport, Username, Password);
                                    }
                                    catch (Exception ex)
                                    {
                                        //lbSearchPrintMsg.Text = "�Դ��ͼԴ��Ҵ! 㹡�����¡����������Ѻ�������������� ��سҵԴ��� AXA!";
                                        ex.Source += "Reprint Compulsary : �Դ��ͼԴ��Ҵ! 㹡�����¡����������Ѻ�������������� ��سҵԴ��� AXA!";
                                        Utilities.LogError(ex);
                                        throw ex;

                                    }
                                    //Response.Redirect("../Report/ListPrint.aspx?policy=" + );
                                    //Response.Redirect("../Report/ListPrint2.aspx?volun=&compl=" + PolicyNumberCompl);
                                }
                                #endregion
                            }

                        }
                        else
                        {
                            //not have  //insert new
                            //Response.Write("Not Have <br>");

                            //NOT HAVE THIS POLICY INTABLE REPORT JOIN PACKAGE  SO INSERT IT
                            #region "STEP1:INSERT DATA FOR LIST PRINT"
                            Policy.InsertJoinPackage("COMPL", PolicyClassType, Fleet, Split, PolicyNumberCompl, Barcode);
                            #endregion

                            #region "STEP2:COMPL GET REPORT LIST AND GET CONTENT SPOOL FILE  FROM AS/400 WRITE TO DB QUICKLINK REPORT"
                            if (PolicyNumberCompl.Equals("") | PolicyNumberCompl == string.Empty)
                            {
                                return;
                            }

                            //GET LIST FILE FOR GET NAME SPOOL BY POLICY
                            dtVolun = Reports.GetListSpool(PolicyNumberCompl);

                            spoolName = "";
                            count = dtVolun.Rows.Count;
                            arrPolicyQutReport = new Box_Document[count];
                            i = 0;

                            if (count > 0)
                            {
                                foreach (DataRow dr in dtVolun.Rows)
                                {
                                    PolicyOutReportData = new Box_Document();
                                    spoolName = dr["SpoolName"].ToString();
                                    PolicyOutReportData.PolicyNo = PolicyNumberCompl;
                                    PolicyOutReportData.Document = spoolName;
                                    PolicyOutReportData.Flag = true;
                                    arrPolicyQutReport[i] = PolicyOutReportData;
                                    i += 1;
                                }
                                try
                                {
                                    //GET SPOOL FROM AS/400 WRITE TO DATABASE
                                    arrMessageOutReport = reportService.GetDocument(arrPolicyQutReport, Username, Password);
                                }
                                catch (Exception ex)
                                {
                                    //lbSearchPrintMsg.Text = "�Դ��ͼԴ��Ҵ! 㹡�����¡����������Ѻ�������������� ��سҵԴ��� AXA!";

                                    ex.Source += "Reprint Compulsary : �Դ��ͼԴ��Ҵ! 㹡�����¡����������Ѻ�������������� ��سҵԴ��� AXA!";
                                    Utilities.LogError(ex);
                                    throw ex;

                                }
                                //Response.Redirect("../Report/ListPrint.aspx?policy=" + );
                                //Response.Redirect("../Report/ListPrint2.aspx?volun=&compl=" + PolicyNumberCompl);
                            }
                            #endregion
                        }
                        break;
                    case "VOLUN": //�Ҥ��Ѥ��
                        //CHECK POLICY IN TABLE REPORTJPACKAGE
                        bTmpVolun = PolicyReprint.chkPolicyInReportJPackage(PolicyNumberVolun);
                        if (bTmpVolun)
                        {
                            //have  policy
                            //CHECK DATA FLAG FOR GET REPORT
                            bTmpGetDBorAS400 = PolicyReprint.chkPolicyReprintIsGetReportInDB(PolicyNumberVolun);
                            if (bTmpGetDBorAS400)
                            {
                                //TRUE GET REPORT DATA IN DB
                                //REDIRECT TO LIST PRINT
                                #region "STEP2:REDIRECT TO LIST PRINT VOLUN ONLY"
                                //Response.Redirect("../Report/ListPrint2.aspx?volun=" + PolicyNumberVolun + "&compl=");
                                #endregion
                            }
                            else
                            {
                                //FALSE GET SPOOL FILE AS/400
                                #region "STEP2:VOLUN GET REPORT LIST AND GET CONTENT SPOOL FILE  FROM AS/400 WRITE TO DB QUICKLINK REPORT"
                                if (PolicyNumberVolun.Equals("") | PolicyNumberVolun == string.Empty)
                                {
                                    //lbSearchPrintMsg.Text = "�Դ��ͼԴ��Ҵ! �������ö���������������� ���ͧ�ҡ�������� �Ҥ��Ѥ�� �����١���ҧ  ��سҵԴ��� AXA!";
                                    ShowMessage("�Դ��ͼԴ��Ҵ! �������ö���������������� ���ͧ�ҡ�������� �Ҥ��Ѥ�� �����١���ҧ  ��سҵԴ��� AXA!");
                                    return;
                                }

                                //GET SPOOL FROM AS/400 WRITE TO DATABASE
                                dtVolun = Reports.GetListSpool(PolicyNumberVolun);

                                spoolName = "";
                                count = dtVolun.Rows.Count;
                                arrPolicyQutReport = new Box_Document[count];

                                i = 0;
                                if (count > 0)
                                {
                                    foreach (DataRow dr in dtVolun.Rows)
                                    {
                                        PolicyOutReportData = new Box_Document();
                                        spoolName = dr["SpoolName"].ToString();
                                        PolicyOutReportData.PolicyNo = PolicyNumberVolun;
                                        PolicyOutReportData.Document = spoolName;
                                        PolicyOutReportData.Flag = true;
                                        arrPolicyQutReport[i] = PolicyOutReportData;
                                        i += 1;
                                    }
                                    try
                                    {
                                        arrMessageOutReport = reportService.GetDocument(arrPolicyQutReport, Username, Password);
                                    }
                                    catch (Exception ex)
                                    {
                                        //lbSearchPrintMsg.Text = "�Դ��ͼԴ��Ҵ! 㹡�����¡����������Ѻ�������������� ��سҵԴ��� AXA!";
                                        ShowMessage("�Դ��ͼԴ��Ҵ! 㹡�����¡����������Ѻ�������������� ��سҵԴ��� AXA!");

                                        ex.Source += "Reprint Voluntary : �Դ��ͼԴ��Ҵ! 㹡�����¡����������Ѻ�������������� ��سҵԴ��� AXA!";
                                        Utilities.LogError(ex);
                                        throw ex;

                                    }
                                    //Response.Redirect("../Report/ListPrint2.aspx?volun=" + PolicyNumberVolun + "&compl=");
                                }
                                #endregion
                            }
                        }
                        else
                        {
                            //not have  //insert new
                            Response.Write("Not Have <br>");

                            //NOT HAVE THIS POLICY INTABLE REPORT JOIN PACKAGE  SO INSERT IT
                            #region "STEP1:INSERT DATA FOR LIST PRINT"
                            Policy.InsertJoinPackage("VOLUN", PolicyClassType, Fleet, Split, PolicyNumberVolun, "");
                            #endregion

                            #region "STEP2:VOLUN GET REPORT LIST AND GET CONTENT SPOOL FILE  FROM AS/400 WRITE TO DB QUICKLINK REPORT"
                            if (PolicyNumberVolun.Equals("") | PolicyNumberVolun == string.Empty)
                            {
                                //lbSearchPrintMsg.Text = "�Դ��ͼԴ��Ҵ! �������ö���������������� ���ͧ�ҡ�������� �Ҥ��Ѥ�� �����١���ҧ  ��سҵԴ��� AXA!";
                                ShowMessage("�Դ��ͼԴ��Ҵ! �������ö���������������� ���ͧ�ҡ�������� �Ҥ��Ѥ�� �����١���ҧ  ��سҵԴ��� AXA!");
                                return;
                            }

                            //GET SPOOL FROM AS/400 WRITE TO DATABASE
                            dtVolun = Reports.GetListSpool(PolicyNumberVolun);

                            spoolName = "";
                            count = dtVolun.Rows.Count;
                            arrPolicyQutReport = new Box_Document[count];

                            i = 0;
                            if (count > 0)
                            {
                                foreach (DataRow dr in dtVolun.Rows)
                                {
                                    PolicyOutReportData = new Box_Document();
                                    spoolName = dr["SpoolName"].ToString();
                                    PolicyOutReportData.PolicyNo = PolicyNumberVolun;
                                    PolicyOutReportData.Document = spoolName;
                                    PolicyOutReportData.Flag = true;
                                    arrPolicyQutReport[i] = PolicyOutReportData;
                                    i += 1;
                                }
                                try
                                {
                                    arrMessageOutReport = reportService.GetDocument(arrPolicyQutReport, Username, Password);
                                }
                                catch (Exception ex)
                                {
                                    //lbSearchPrintMsg.Text = "�Դ��ͼԴ��Ҵ! 㹡�����¡����������Ѻ�������������� ��سҵԴ��� AXA!";
                                    ShowMessage("�Դ��ͼԴ��Ҵ! 㹡�����¡����������Ѻ�������������� ��سҵԴ��� AXA!");

                                    ex.Source += "Reprint Voluntary : �Դ��ͼԴ��Ҵ! 㹡�����¡����������Ѻ�������������� ��سҵԴ��� AXA!";
                                    Utilities.LogError(ex);
                                    throw ex;

                                }
                                //Response.Redirect("../Report/ListPrint2.aspx?volun=" + PolicyNumberVolun + "&compl=");
                            }
                            #endregion
                        }
                        break;

                    default: break;
                }
                #endregion
                Response.Redirect("../Report/ListPrint2.aspx?compl=" + complpolicy + "&volun=" + volunpolicy);
            }
            catch (Exception ex)
            {
                //ShowMessage("ERROR");
                //lbSearchPrintMsg.Text = "Event Click Button Print : ��سҵ�Ǩ�ͺ�բ�ͼԴ��Ҵ�Դ���";
                //ex.Source += "Event Click Button Print : ��سҵ�Ǩ�ͺ�բ�ͼԴ��Ҵ�Դ���";
                //Utilities.LogError(ex);
                //throw ex;
            }
        }

        
    }
    private void ShowMessage(string msg)
    {
        lbMsgPrint.Visible = true;
        lbMsgPrint.Text = msg;
        lbMsgPrint.ForeColor = System.Drawing.Color.White;
        lbMsgPrint.Font.Bold = true;
    }
}
