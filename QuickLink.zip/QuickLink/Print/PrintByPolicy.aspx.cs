using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using WFQuickLinkReport;  //FOR REPORT SERVICE
using System.Threading;
using System.Globalization;

public partial class Print_PrintByPolicy : System.Web.UI.Page
{
    DataTable dt;
    DataView dv;
    protected void Page_Load(object sender, EventArgs e)
    {
        lbSearchPrintMsg.Visible = false;
        CultureInfo culture = new CultureInfo("en-US");
        ClearMessage();
        if (!IsPostBack)
        {
            Utilities.SetBrokerCodeDefault();
	        ClearDataInGridViewReprint();
            GetDetailListDataPrint();
        }
        else
        { 
            dv = (DataView)Session["DataReprint"];
        }
    }

    //CLEAR MESSAGE
    //TEXT:
    //VALUE:
    private void ClearMessage()
    {
        lbSearchPrintMsg.Text = "";
    }

    private void ClearDataInGridViewReprint()
    { 
            Session["DataReprint"] = null;
            BindDataToGridPrint();  
    }

    //BIND DATA TO GRIDVIEW
    //TEXT:
    //VALUE:
    private void BindDataToGridPrint()
    {
        dv = (DataView)Session["DataReprint"];
        gvReprint.DataSource = dv;
        gvReprint.DataBind();
    }

    protected void gvReprint_RowCreated(object sender, GridViewRowEventArgs e)
    {
        TableCell td = e.Row.Cells[0];
        Boolean Y = false; 
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            if (gvReprint.PageIndex > 0)
            {
                LinkButton L1 = new LinkButton();
                Image M1 = new Image();
                M1.ImageUrl = "../Images/Backward.gif";
                //L1.Text = "First";
                //AddHandler L1.Click, AddressOf NextClick
                L1.Click += new EventHandler(FirstPage1);
                L1.Controls.Add(M1);
                td.Controls.Add(L1);

                Y = true;
                //separate
                Literal L2 = new Literal();
                L2.Text = "&nbsp&nbsp";
                td.Controls.Add(L2);

                L1 = new LinkButton();
                M1 = new Image();
                M1.ImageUrl = "../Images/Previous.gif";
                //L1.Text = "Pre";
                L1.Click += new EventHandler(PrePage1);
                L1.Controls.Add(M1);
                td.Controls.Add(L1);
            }
            if (gvReprint.PageIndex < gvReprint.PageCount - 1)
            {
                Literal L2 = new Literal();
                if (Y == true)
                {
                    // created first & pre
                    L2 = new Literal();
                    L2.Text = " &nbsp;&nbsp";
                    td.Controls.Add(L2);
                }
                LinkButton L1 = new LinkButton();
                Image M1 = new Image();
                M1.ImageUrl = "../Images/Next.gif";
                L1.Click += new EventHandler(NextPage1);
                //L1.Text = "Next";
                L1.Controls.Add(M1);
                td.Controls.Add(L1);

                L2 = new Literal();
                L2.Text = "&nbsp&nbsp";
                td.Controls.Add(L2);

                L1 = new LinkButton();
                M1 = new Image();
                M1.ImageUrl = "../Images/Forward.gif";
                //L1.Text = "Last";
                L1.Click += new EventHandler(LastPage1);
                L1.Controls.Add(M1);
                td.Controls.Add(L1);
            }
        }
    }

    protected void gvReprint_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvReprint.PageIndex = e.NewPageIndex;
        BindDataToGridPrint();
    }
    protected void gvReprint_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            int r = (int)e.Row.RowIndex;
            e.Row.Attributes.Add("onmouseover", "xfocus(this);");
            e.Row.Attributes.Add("onmouseout", "xleave(this," + r + ");");
        }
    }
    protected void gvReprint_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    //GET DATA FROM TABLE LISTFORPRINT
    //TEXT:
    //VALUE:
    private void GetDetailListDataPrint()
    {
        dt = PolicyReprint.GetPolicyListForShowInGridView();
        if (dt.Rows.Count > 0)
        {
            Session["DataReprint"] = dt.DefaultView;
            BindDataToGridPrint();
        }
        else
        {
            ClearDataInGridViewReprint();
        }
    }
    private void GetDetailListDataPrintByPolicyNo(string fromPolicy, string toPolicy)
    {
        dt = PolicyReprint.GetPolicyListForShowInGridViewByPolicy(fromPolicy, toPolicy);
        if (dt.Rows.Count > 0)
        {
            Session["DataReprint"] = dt.DefaultView;
            BindDataToGridPrint();
        }
        else
        {
            ClearDataInGridViewReprint();
        }
    }
    private void GetDetailListDataPrintByIssuedDate(string fromIssuedDate, string toIssuedDate)
    {
        dt = PolicyReprint.GetPolicyListForShowInGridViewByIssuedDate(fromIssuedDate, toIssuedDate);
        if (dt.Rows.Count > 0)
        {
            Session["DataReprint"] = dt.DefaultView;
            BindDataToGridPrint();
        }
        else
        {
            ClearDataInGridViewReprint();
        }
        
    }

    //BUTTON EVENT HANDDLER
    //TEXT:
    //VALUE:

    protected void btnSearchByPolicy_Click(object sender, EventArgs e)
    {
        //Set Default Page
        gvReprint.PageIndex = 0;
        //Validate Data
        try
        {
            string from = txbPolicyFrom.Text.Trim();
            string to = txbPolicyTo.Text.Trim();
            if (from.Equals("") & to.Equals(""))
            {
                ShowMessage("��س��к������Ţ����������س��ͧ��ä���..!");
                ClearDataInGridViewReprint();
		return;
            }
            else if (from.Equals(""))
            {
                GetDetailListDataPrintByPolicyNo(to, to);
            }
            else if (to.Equals(""))
            {
                GetDetailListDataPrintByPolicyNo(from, from);
            }
            else
            {
                GetDetailListDataPrintByPolicyNo(from, to);
            }
        }
        catch (Exception ex)
        {
            //Log Error Programming Event
            //Utilities.LogError(ex);
            //throw ex;
        }
    }
    protected void btnSearchByIssuedDate_Click(object sender, EventArgs e)
    {
        //Set Default Page
        gvReprint.PageIndex = 0;
        //Validate Data
        try
        {
            string from = txbIssuedDateFrom.CalendarDateString.Trim();
            string to = txbIssuedDateTo.CalendarDateString.Trim();
 
            if (from.Equals("") & to.Equals(""))
            {
                ShowMessage("��س��к��������� Issued Date ���س��ͧ��ä���..!");
                ClearDataInGridViewReprint();
                return;
            }
            if (from.Length != 10)
            {
                ShowMessage("�س�к��ٻẺ�ѹ������١��ͧ ! ��س��кص����� :(dd/MM/yyyy)");
                ClearDataInGridViewReprint();
                return;
            }
	    
            if (from.Equals(""))
            {
                //DateTime dTo = new DateTime(Utilities.getYear(to), Utilities.getMonth(to), Utilities.getDay(to));
                //String dTo = txbIssuedDateFrom.CalendarDateString.Trim();
		
		if (to.Length != 10)
            	{
                	ShowMessage("�س�к��ٻẺ�ѹ������١��ͧ ! ��س��кص����� :(dd/MM/yyyy)");
                	ClearDataInGridViewReprint();
                	return;
            	}
		String dTo = Utilities.getYear(to)+"/"+ Utilities.getMonth(to)+"/"+ Utilities.getDay(to);  
                to = dTo.ToString();
                GetDetailListDataPrintByIssuedDate(to, to);
            }
            else if (to.Equals(""))
            {
                //DateTime dFrom = new DateTime(Utilities.getYear(from), Utilities.getMonth(from), Utilities.getDay(from));
                //String dFrom = txbIssuedDateFrom.CalendarDateString.Trim(); 
		String dFrom = Utilities.getYear(from)+"/"+ Utilities.getMonth(from)+"/"+ Utilities.getDay(from);   
                from = dFrom.ToString();
                GetDetailListDataPrintByIssuedDate(from, from);
            }
            else
            {
                //DateTime dFrom = new DateTime(Utilities.getYear(from), Utilities.getMonth(from), Utilities.getDay(from));
                //String dFrom = txbIssuedDateFrom.CalendarDateString.Trim(); 
                String dFrom = Utilities.getYear(from)+"/"+ Utilities.getMonth(from)+"/"+ Utilities.getDay(from);
		from = dFrom.ToString();

                //DateTime dTo = new DateTime(Utilities.getYear(to), Utilities.getMonth(to), Utilities.getDay(to));
                //String dTo = txbIssuedDateTo.CalendarDateString.Trim(); 
                
		String dTo = Utilities.getYear(to)+"/"+ Utilities.getMonth(to)+"/"+ Utilities.getDay(to);  
		to = dTo.ToString();
                GetDetailListDataPrintByIssuedDate(from, to);
            }
	

        }
        catch (Exception ex)
        {
            //Log Error Programming Event
            //Utilities.LogError(ex);
            //throw ex;
            if (ex.Message.Trim() == "Input string was not in a correct format.")
            {
                ShowMessage("�س�к��ٻẺ�ѹ������١��ͧ ! ��س��кص����� :(dd/MM/yyyy)");
                ClearDataInGridViewReprint();
		return;
            }
	    
	    
	    ShowMessage("�س�к��ٻẺ�ѹ������١��ͧ ! ��س��кص����� :(dd/MM/yyyy)");
            ClearDataInGridViewReprint();
        }
    }

    //GRIDVIEW REPRINT CHANGE PAGE
    //TEXT:
    //VALUE
    private void GoPage1(Int16 xPage)
    {
        gvReprint.PageIndex = xPage;
        BindDataToGridPrint();
    }
    private void FirstPage1(object sender, EventArgs e)
    {
        this.GoPage1(0);
    }
    private void PrePage1(object sender, EventArgs e)
    {
        this.GoPage1(Convert.ToInt16(gvReprint.PageIndex - 1));
    }
    private void NextPage1(object sender, EventArgs e)
    {
        this.GoPage1(Convert.ToInt16(gvReprint.PageIndex + 1));
    }
    private void LastPage1(object sender, EventArgs e)
    {
        this.GoPage1(Convert.ToInt16(gvReprint.PageCount - 1));
    }

    private void ShowMessage(string msg)
    {
        lbSearchPrintMsg.Visible = true;
        lbSearchPrintMsg.Text = msg;
        lbSearchPrintMsg.ForeColor = System.Drawing.Color.White;
        lbSearchPrintMsg.BackColor = System.Drawing.Color.Red;
        lbSearchPrintMsg.Font.Bold = true;
    }
}

