using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

using PA.BLL;
using PA.BusinessObjects;


public partial class Report_ListPrint : System.Web.UI.Page
{
    string PolicyNo = "";
    string PolicyType = "";
    string PlanId = "";
    string brokercode = "";
    string JobNo = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        this.gdvDocument.RowDataBound += new GridViewRowEventHandler(gdvDocument_RowDataBound);
        this.btnSetPrintFlag.ServerClick += new EventHandler(btnSetPrintFlag_ServerClick);
        this.btnSendEmail.ServerClick += new EventHandler(btnSendEmail_ServerClick);
        DefaultPageRegisterClientScript();

        lbMsgPrint.Visible = false;
        brokercode = Utilities.BrokerCode();

        if (brokercode == "")
        {
            ShowMessage("�������ö����¡���� ���ͧ�ҡ�س�ѧ������������к� !");
            //VISIBLE
            gdvDocument.Visible = false;
            this.tblSendEmail.Visible = false;
        }
        else
        {
            try
            {
                PolicyNo = Request.QueryString["policyno"].ToString().Trim();
                PolicyType = Request.QueryString["policytype"].ToString().Trim();
                PlanId = Request.QueryString["planid"].ToString().Trim();
                JobNo = Request.QueryString["JobNo"].ToString().Trim();

                if (!Page.IsPostBack)
                {
                    this.GetEmailAdress();
                }
                if (PolicyNo.Trim() == string.Empty)
                {
                    ShowMessage("�������ö����¡���� ���ͧ�ҡ����բ����š��������� !");
                    return;
                }
                else
                {
                    lbPolicyReturn.Text = "<center>" + PolicyNo + "</center>";
                    this.BindData(JobNo);
                    this.tblSendEmail.Visible = true;
                }

            }
            catch (Exception ex)
            {
                ShowMessage(ex.Message);
            }
        }
    }

    protected void btnSendEmail_ServerClick(object sender, EventArgs e)
    {

        if (!string.IsNullOrEmpty(this.txtSendEmail.Value))
        {
            string jobno = "";

            string insuredName = Request.QueryString["insured_name"];

            string emailFrom = "QuickLinkTAHelpdesk@axa.co.th";
            string emailTo = this.txtSendEmail.Value.Trim();
            string subject = "Confirmation of Travel Insurance Schedule";

            string body = "This email address is unmonitored. Please do not use \"reply mail\" function to contact us. <br/><br/>";
            body += "<p>Policy No: " + PolicyNo + "<br/><br/>";

            body += "<p>Dear " + insuredName + ",<br/><br/>";

            body += "Thank you for choosing AXA Insurance Public Company Limited for your protection.<br/><br/><br/>";
            body += "Please click link to our website www.axa.co.th to download details of cover and <br/>";
            body += "policy wording of Personal Accident insurance <br/><br/>";
            //body += "Please click link below to download your Policy Wording:<br/>";
            //body += "�	http://www.axa.co.th/146/en/Useful-Links/Download<br>";
            //body += "�	Or http://www.axa.co.th/311/th/retail-insurance/travel/smarttraveller-plus<br/><br/>";
            body += "Should you have any queries regarding your policy, please contact your agent or<br/>";
            body += "AXA Insurance 0 2679 7600 (during 8.30 - 17.00 hr) <br/>";
            body += "In case of claim notification,<br/>";
            body += "Please contact Personal Accident Claim Department <br/>";
            body += "+66 2679 7600 ext. 2405 <br/>";
            body += "+66 2687 9356 direct line<br/>";

            body += "���������Сѹ��¡���Թ�ҧ �Ţ��� : " + PolicyNo + "<br/><br/>";
            body += "���¹ " + insuredName + ",<br/><br/>";
            body += "����ѷ �͡��һ�Сѹ��� �ӡѴ (��Ҫ�) �͢ͺ�س����ҹ����ҧ���� ����ѷ �繼��������������ͧ���ҹ <br/><br/>";
            body += "��ҹ����ö��ǹ���Ŵ ���͹䢤���������ͧ�ͧ��û�Сѹ����غѵ��˵���ǹ�ؤ�� ����<br/>";
            body += "�Ǻ䫤�ͧ����ѷ www.axa.co.th <br/>";
            //body += "�	http://www.axa.co.th/146/en/Useful-Links/Download<br/>";
            //body += "�	���� http://www.axa.co.th/311/th/retail-insurance/travel/smarttraveller-plus<br/><br>";
            body += "�ҡ��ҹ�դӶ������ǡѺ���͹䢡������� ����ö�ͺ���������᷹�ͧ��ҹ <br/>";
            body += "���͵Դ����ҷ�����ѷ�͡��һ�Сѹ��� �� 0 2679 7600 �����Ţ���� 2311, 2305 <br/>";
            body += "2304 �����ҧ���� 8.30 - 17.00 �.<br/><br/>";

            try
            {
                string type = "20";
                string path = path = Server.MapPath(Request.ApplicationPath + "/TA/DOC/" + PolicyNo);

                string filePath = path + "\\" + PolicyNo + type + ".pdf";

                Utilities.SendMail(emailFrom, emailTo, subject, body, true, filePath);

                this.lbMsgPrint.Text = "";
                this.lblMessageSendMailSuccess.Text = "E-mail Sent!!";

            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                ShowMessage(ex.Message);
                throw ex;
            }
        }
        else
        {
            this.lblMessageSendMailSuccess.Text = "";
            ShowMessage("Email Field not empty!! / ������������ҧ!!.");
        }
    }
    protected void gdvDocument_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        string url = "";

        string type = "";

        if (e.Row.RowIndex >= 0)
        {
            DataRowView rowView = (DataRowView)e.Row.DataItem;

            //------------------print original--------------------
            HtmlInputButton btnOriginal = new HtmlInputButton();
            btnOriginal.Value = "Print(" + rowView["FlagOriginal"].ToString() + ")";
            btnOriginal.Style.Add("width", "110px");

            if (Convert.ToInt32(rowView["FlagOriginal"]) < 1)
            {
                btnOriginal.Disabled = true;
            }
            else
            {

                btnOriginal.Attributes["onclick"] = "if (confirm('Are you sure you want to print?')==false) return;";
                btnOriginal.Attributes["onclick"] += "setFlagPrint('Original');";

                url = QuickLinkConfiguration.UrlReportingServiceNew + rowView["ReportName"].ToString() + "&rs:Format=pdf&rs:command=render&JobNo=" + JobNo + "&PolicyType=" + PolicyType + "&PlanId=" + PlanId;
                type = "15";
                printPAPolicy(url, PolicyNo, type);
                btnOriginal.Attributes["onclick"] += "window.open ( '" + @"../DOC/" + PolicyNo + @"/" + PolicyNo + type + @".pdf','_blank' );window.location.reload();";

            }

            e.Row.Cells[1].Controls.Add(btnOriginal);

            //------------------print Copy--------------------
            HtmlInputButton btnCopy = new HtmlInputButton();
            btnCopy.Value = "Print(" + rowView["FlagCopy"].ToString() + ")";
            btnCopy.Style.Add("width", "110px");
            if (Convert.ToInt32(rowView["FlagCopy"]) < 1)
            {
                btnCopy.Disabled = true;
            }
            else
            {
                btnCopy.Attributes["onclick"] = "if (confirm('Are you sure you want to print?')==false) return;";
                btnCopy.Attributes["onclick"] += "setFlagPrint('Copy');";

                url = QuickLinkConfiguration.UrlReportingServiceNew + rowView["ReportCopyName"].ToString() + "&rs:Format=pdf&rs:command=render&JobNo=" + JobNo + "&PolicyType=" + PolicyType + "&PlanId=" + PlanId;
                type = "20";
                printPAPolicy(url, PolicyNo, type);
                btnCopy.Attributes["onclick"] += "window.open ( '" + @"../DOC/" + PolicyNo + @"/" + PolicyNo + type + @".pdf','_blank' );window.location.reload();";

            }
            e.Row.Cells[2].Controls.Add(btnCopy);

            //------------------print view--------------------
            HtmlInputButton btnView = new HtmlInputButton();
            btnView.Value = "View";
            btnView.Attributes["onclick"] = "if (confirm('Are you sure you want to print?')==false) return;";

            url = QuickLinkConfiguration.UrlReportingServiceNew + rowView["ReportViewName"].ToString() + "&rs:Format=pdf&rs:command=render&JobNo=" + JobNo + "&PolicyType=" + PolicyType + "&PlanId=" + PlanId;
            type = "25";
            printPAPolicy(url, PolicyNo, type);
            btnView.Attributes["onclick"] += "window.open ( '" + @"../DOC/" + PolicyNo + @"/" + PolicyNo + type + @".pdf','_blank' );window.location.reload();";

            btnView.Style.Add("width", "110px");
            e.Row.Cells[3].Controls.Add(btnView);

        }
    }
    private void ShowMessage(string msg)
    {
        lbMsgPrint.Visible = true;
        lbMsgPrint.Text = msg;
        lbMsgPrint.ForeColor = System.Drawing.Color.White;
        lbMsgPrint.Font.Bold = true;
    }
    private void btnSetPrintFlag_ServerClick(object sender, EventArgs e)
    {
        PATransPrintsBLL SetPrintFlag = new PATransPrintsBLL();
        if (this.hdnPrintFlag.Value == "Original")
        {
            SetPrintFlag.SetPAPrintFlagOriginal(JobNo);
        }
        else
        {
            SetPrintFlag.SetPAPrintFlagCopy(JobNo);
        }
        this.BindData(PolicyNo);
        DefaultPageRegisterClientScript();
    }
    private void BindData(string JobNo)
    {
        DataTable DTAble = new DataTable();
        PATransPrintsBLL getPrintListReportName = new PATransPrintsBLL();

        DTAble = getPrintListReportName.GetPAPrintListReportName(JobNo);
        gdvDocument.DataSource = DTAble;
        gdvDocument.DataBind();
    }
    protected void DefaultPageRegisterClientScript()
    {
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptScrolling", "MenuScroll();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptTxtFocus", "setFocusTextbox();", true);

        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptFunction", "<script type='text/javascript' language='javscript'>function setFlagPrint(Flag) {$('[id$=hdnPrintFlag]').val(Flag);$('[id$=btnSetPrintFlag]').click();}</script>", false);

    }
    private void GetEmailAdress()
    {
        string jobno = Request.QueryString["jobno"];

        PATransPolicyHolders getEmail = new PATransPolicyHolders();
        PAGetBindPolicyBLL clsPAGetBindPolicyBLL = new PAGetBindPolicyBLL();
        getEmail = clsPAGetBindPolicyBLL.GetPATransPolicyHolders(JobNo);

        txtSendEmail.Value = getEmail.Email.Trim();
    }
    protected void chkSendEmail_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkSendEmail.Checked)
        {
            this.txtSendEmail.Visible = true;
            this.btnSendEmail.Visible = true;
        }
        else
        {
            this.txtSendEmail.Visible = false;
            this.btnSendEmail.Visible = false;
        }
    }
    public void PrintPAPolicy(string url, string policy)
    {

        System.Net.NetworkCredential Credentials = new System.Net.NetworkCredential();
        Credentials.UserName = "quicklink";
        Credentials.Password = "Password1";
        Credentials.Domain = "bkk.dom";
        //We can get values of these parameters from Request object.

        string URL = url;

        System.Net.HttpWebRequest Req = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(URL);


        Req.Credentials = Credentials;
        Req.ContentType = " text/html";


        Req.Method = "GET";

        string path = Server.MapPath(Request.ApplicationPath + "/PA/DOC/" + policy);

        System.IO.DirectoryInfo di = new DirectoryInfo(path);
        if (!di.Exists)
        {
            System.IO.Directory.CreateDirectory(path);
        }


        string filepath = path + "\\" + policy + ".pdf";
        if (!File.Exists(filepath))
        {

            System.Net.HttpWebResponse objResponse = (System.Net.HttpWebResponse)Req.GetResponse();

            System.IO.FileStream fs = new System.IO.FileStream(filepath, System.IO.FileMode.Create);

            System.IO.Stream stream = objResponse.GetResponseStream();

            byte[] buf = new byte[1024];

            int len = stream.Read(buf, 0, 1024);

            while (len > 0)
            {

                fs.Write(buf, 0, len);

                len = stream.Read(buf, 0, 1024);

            }

            stream.Close();
            stream.Flush();
            fs.Flush();
            fs.Close();

        }


    }

    public void printPAPolicy(string url, string policyno, string type)
    {
        System.Net.NetworkCredential Credentials = new System.Net.NetworkCredential();
        Credentials.UserName = "quicklink";
        Credentials.Password = "Password1";
        Credentials.Domain = "bkk.dom";
        //We can get values of these parameters from Request object.

        string URL = url;

        //Specify the path for saving.
        System.IO.DirectoryInfo di = new DirectoryInfo(@"C:\Inetpub\wwwroot\QuickLink\PA\DOC\" + policyno);

        if (!di.Exists)
        {
            System.IO.Directory.CreateDirectory(@"C:\Inetpub\wwwroot\QuickLink\PA\DOC\" + policyno);

        }

        string path = @"C:\Inetpub\wwwroot\QuickLink\PA\DOC\" + policyno + @"\" + policyno + type + @".pdf";


        if (!File.Exists(path))
        {

            System.Net.HttpWebRequest Req = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(URL);
            Req.Credentials = Credentials; // System.Net.CredentialCache.DefaultCredentials;
            Req.ContentType = " text/html";


            Req.Method = "GET";


            System.Net.HttpWebResponse objResponse = (System.Net.HttpWebResponse)Req.GetResponse();

            System.IO.FileStream fs = new System.IO.FileStream(path, System.IO.FileMode.Create);

            System.IO.Stream stream = objResponse.GetResponseStream();

            byte[] buf = new byte[1024];

            int len = stream.Read(buf, 0, 1024);

            while (len > 0)
            {

                fs.Write(buf, 0, len);

                len = stream.Read(buf, 0, 1024);

            }

            stream.Close();

            fs.Close();
        }
    }


}
