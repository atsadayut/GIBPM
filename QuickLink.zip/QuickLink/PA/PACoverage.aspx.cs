﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using WSQuickLinkTA;
public partial class PA_PACoverage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string policyNumber = Request.QueryString["PNUM"];

        //string Username = "QAPA";
        //string Password = "PASSWORD";

        //Box_Inquriy PolicyData;
        //Box_EnquiryPA[] PAInsuredData;
        //string Message = "";
        //string MessageStatus = "";

        //QuickLinkTravelService getPolicyMR = new QuickLinkTravelService();
        //PolicyData = getPolicyMR.GetPolicyInquiry(Username, Password, policyNumber, out PAInsuredData, out Message, out MessageStatus);

        this.BindInsureds((DataTable)Session["InsuredsCoverage"]);
    }

    protected void gridPACoverate_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataRow RowData = (DataRow)e.Row.DataItem;

            //Label lblNumRec = (Label)e.Row.FindControl("lblNumRec");
            //lblNumRec.Text = (e.Row.RowIndex + 1).ToString();

            Label lblCoverageCode = (Label)e.Row.FindControl("lblCoverageCode");
            lblCoverageCode.Text = RowData["CoverageCode"].ToString();

            Label lblCoverageDesc = (Label)e.Row.FindControl("lblCoverageDesc");
            lblCoverageDesc.Text = RowData["CoverageDesc"].ToString();

            Label lblCoveragePremium = (Label)e.Row.FindControl("lblCoveragePremium");
            lblCoveragePremium.Text = RowData["CoveragePremium"].ToString();

            Label lblCoverageSumInsured = (Label)e.Row.FindControl("lblCoverageSumInsured");
            lblCoverageSumInsured.Text = RowData["CoverageSumInsure"].ToString();

        }

    }
    private void BindInsureds(DataTable PAInsuredData)
    {
        string policyNumber = Request.QueryString["PNUM"].Trim();
        int index = Convert.ToInt32(Request.QueryString["INDEX"].Trim());
        index = index + 1;
        double SumPremuim = 0;
        
        DataRow[] InsuredDataRow = PAInsuredData.Select("InsuredID =" + index.ToString() );

        this.gridPACoverate.DataSource = InsuredDataRow;
        this.gridPACoverate.DataBind();

    }
}