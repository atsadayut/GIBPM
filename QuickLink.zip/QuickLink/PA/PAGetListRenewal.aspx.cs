﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using PA.BLL;

public partial class PA_PAGetListRenewal : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.btnSearchReport.ServerClick += new EventHandler(btnSearchReport_ServerClick);
        this.gdvReport.PageIndexChanging +=new GridViewPageEventHandler(gdvReport_PageIndexChanging);
        DefaultPageRegisterClientScript();
        if (!Page.IsPostBack)
        {
            string l_AgentCode = Utilities.BrokerCode();
            this.txtProducerCode.Value = l_AgentCode;
            Session.Remove("PAListRenewal");
        }

    }

    protected void btnSearchReport_ServerClick(object sender, EventArgs e)
    {
        

        if (this.txtEffectiveDateFrom.Value.Length >= 1 && this.txtEffectiveDateFrom.Value.Length <= 9)
        {
            this.lblMassage.Text = "Format วันที่ ของ Date From/To ไม่ถูกต้อง ที่ถูกต้องเป็น dd/mm/yyyy";
            this.txtEffectiveDateFrom.Value = "";
            this.txtEffectiveDateTo.Value = "";
        }
        else { this.lblMassage.Text = ""; }
        
        
        GetListRenewal(this.txbPolicyNo.Text.Trim(),this.txbInsuredName.Text.Trim(),GetFormateDateYMD(this.txtEffectiveDateFrom.Value.Trim()),GetFormateDateYMD(this.txtEffectiveDateTo.Value.Trim()));
    }
    protected void gdvReport_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

        this.gdvReport.PageIndex = e.NewPageIndex;
        gdvReport.DataSource = (DataTable)Session["PAListRenewal"];
        gdvReport.DataBind();

    }

    protected void DefaultPageRegisterClientScript()
    {
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptScrolling", "MenuScroll();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptTxtFocus", "setFocusTextbox();", true);
        //ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDrawCorner", "DrawDivCorner();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDisplayMsg", "DisplayWarning();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptMenu", "<script type='text/javascript' language='javascript'>$(document).ready(function () { $('.PERSONAL').find('img').attr('src', '../Images/Index/PA1.png');$('.PERSONAL').find('a').css('color', '#922d3d');$('.PERSONAL').hover(function () {$(this).find('img').attr('src', '../Images/Index/PA1.png'); },function () {$(this).find('img').attr('src', '../Images/Index/PA1.png');}); addSubMenu('hdnPa', '.subNavigate', 'Renewal Policy', '');$('[id$=txtTransactionDateFrom]').datepicker({ dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true  });$('[id$=txtTransactionDateTo]').datepicker({ dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true  });$('[id$=txtEffectiveDateFrom]').datepicker({ dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true  });$('[id$=txtEffectiveDateTo]').datepicker({ dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true  }); Accordion('.wizard', 'hdnCriteriaStep');}); </script>", false);
        

    }
    private void GetListRenewal(string PolicyNo, string InsureName, string EffectiveDateFrom, string EffectiveDateTo)
    {
        string l_AgentCode = Utilities.BrokerCode();
        string l_GroupBrokerID = Utilities.GetGroupBrokerID();
        DataTable result = new DataTable();
        //Session.Remove("PAListRenewal")

        PATransRenewalsBLL getListRenewal = new PATransRenewalsBLL();
        result = getListRenewal.GetPAListRenewals(PolicyNo, InsureName, EffectiveDateFrom, EffectiveDateTo, l_GroupBrokerID);
        Session.Add("PAListRenewal", result);

        if (result.Rows.Count > 0)
        {
            this.lblTotalRecord.Text = "แสดงรายการข้อมูล [จำนวนข้อมูลทั้งหมด " + result.Rows.Count + " รายการ]";


            this.gdvReport.DataSource = result;
            this.gdvReport.DataBind();

        }
        else
        {
            this.lblTotalRecord.Text = "แสดงรายการข้อมูล [จำนวนข้อมูลทั้งหมด " + 0 + " รายการ]";
            this.gdvReport.DataSource = null;
            this.gdvReport.DataBind();
            //this.gdvReport.Visible = false;
            //this.btnExportToExcel.Visible = false;
        }
    }
    private string GetFormateDateYMD(string date)
    {
        if(string.IsNullOrEmpty(date)){
               return "";
        }else{
        
            string[] DatePart  = date.Split('/');
            return DatePart[2] + '-' + DatePart[1] + '-' + DatePart[0];
        }
        
    }
    
    public override void VerifyRenderingInServerForm(Control control)
    {
        
    }
}