﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Globalization;

using WSQuickLinkTA;
using WSQuickLinkTAReport;
using PA.BLL;

public partial class PA_PARenewPolicy : System.Web.UI.Page
{
    
    protected void Page_Load(object sender, EventArgs e)
    {
        //this.DefaultPageRegisterClientScript();
        if (!Page.IsPostBack)
        {

            string policyNumber = "";
            policyNumber = Request.QueryString["PNUM"]; 
            //string motorProvince = Request.QueryString["REGPRV"].ToString().Trim();

            string Username = "";
            string Password = "";
 
            if (Session["UserHostName"].ToString().Substring(1, 2) == "QL")
            {
                Username = "QLPA"; Password = Session["UserHostPassword"].ToString().Trim();
            }
            else { Username = "QAPA"; Password = Session["UserHostPassword"].ToString().Trim(); }
        
            Box_Inquriy PolicyData;
            Box_EnquiryPA[] PAInsuredData;
            string Message = "";
            string MessageStatus = "";

            QuickLinkTravelService getPolicyMR = new QuickLinkTravelService();
            PolicyData = getPolicyMR.GetPolicyInquiry(Username, Password, policyNumber, out PAInsuredData, out Message, out MessageStatus);

            if (MessageStatus == "SUCCESS")
            {
                this.BindMainPolicy(PolicyData);
                
                double SumPremuim = this.BindInsureds(PAInsuredData);
                this.BindPremium(SumPremuim);
            }
            else
            {
                lblErrorMessage.Text = "ไม่พบข้อมูลที่ต้องการหรือเกิดข้อผิดพลาดในการเรียกข้อมูล!!!กรุณาติดต่อ AXA HelpDesk ";
                lblErrorMessage.Text += "<br>" + Message;
                btnRenew.Visible = false;
            }
           
        }        
    }
    protected void gridMotorDetails_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataRowView RowData = (DataRowView)e.Row.DataItem;


            Label lblNumRec = (Label)e.Row.FindControl("lblNumRec");
            lblNumRec.Text = (e.Row.RowIndex + 1).ToString();

            Label lblInsuredName = (Label)e.Row.FindControl("lblInsuredName");
            lblInsuredName.Text = RowData["InsuredName"].ToString();

            Label lblInsuredAge = (Label)e.Row.FindControl("lblInsuredAge");
            lblInsuredAge.Text = RowData["Age"].ToString();

            Label lblInsuredPlanCode = (Label)e.Row.FindControl("lblInsuredPlanCode");
            lblInsuredPlanCode.Text = RowData["PlanCode"].ToString();

            Label lblInsuredPremium = (Label)e.Row.FindControl("lblInsuredPremium");
            lblInsuredPremium.Text = RowData["Premium"].ToString();

            Label lblInsuredPremiumClass = (Label)e.Row.FindControl("lblInsuredPremiumClass");
            lblInsuredPremiumClass.Text = RowData["PremiumClass"].ToString();

            Label lblBeneficaly1 = (Label)e.Row.FindControl("lblBeneficaly1");
            lblBeneficaly1.Text = RowData["Beneficaly1"].ToString();

            Label lblBeneficaly2 = (Label)e.Row.FindControl("lblBeneficaly2");
            lblBeneficaly2.Text = RowData["Beneficaly2"].ToString();

            Label lblBeneficaly3 = (Label)e.Row.FindControl("lblBeneficaly3");
            lblBeneficaly3.Text = RowData["Beneficaly3"].ToString();

            Label lblBeneficaly4 = (Label)e.Row.FindControl("lblBeneficaly4");
            lblBeneficaly4.Text = RowData["Beneficaly4"].ToString();


            string policyNumber = Request.QueryString["PNUM"].Trim();
            e.Row.Attributes.Add("onclick", "popWinShowCoverate('" + policyNumber + "','" + e.Row.RowIndex.ToString() + "');");
            e.Row.Attributes.CssStyle.Add("cursor", "pointer");
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("PAGetListRenewal.aspx");
    }
    protected void btnRenew_Click(object sender, EventArgs e)
    {

        string Username = "QAPA";
        string Password = "PASSWORD";
        
        string policyno = this.lblPolicyNumber.Text;
        string inceptiondate = this.txtInceptionDate.CalendarDateString.Trim();
        string ref1 = this.txtRef1.Text.Trim();
        string ref2 = this.txtRef2.Text.Trim();

        string MessageStatus = "";
        string message = "";
        string SessionID = "";
        bool Found;
        bool FoundSpecified;

        //Check Agreement Date must not greater than Effective Date

        if ((inceptiondate == "") || (inceptiondate == string.Empty))
        {
            this.lblErrorMessage.Text = "กรุณาระบุวันที่ทำสัญญา!!! รูปแบบ ค.ศ.(dd/MM/yyyy)";
            return;
        }

        //--------------------------------------------------------------------------
        try
        {
            #region Call Service Check Claim

            QuickLinkTravelService ServiceRenew = new QuickLinkTravelService();
            message = ServiceRenew.RenewCheckClaim(Username, Password, policyno, inceptiondate, out MessageStatus, out Found,out FoundSpecified);
            
            if (MessageStatus == "UNSUCCESS")
            {

                throw new System.ArgumentException("RenewCheckClaim NotValid : " + message + " ,Policy No : " + policyno);

            }

            #endregion
            //-----------------------------------------------------------------------
            #region Call Service RenewPolicyPA
            message = ServiceRenew.RenewPolicy(Username, Password, policyno, inceptiondate, ref1, ref2, out MessageStatus, out SessionID);

            if (MessageStatus == "UNSUCCESS")
            {
                throw new System.ArgumentException(" " + message + " ,Policy No : " + policyno);
            }

            #endregion
            //-----------------------------------------------------------------------

            #region SET ApplinxTransPrint Renew

            string agentno = this.lblAgent.Text.Trim();
            string brokergroup = Utilities.GetGroupBrokerID();
            string createuser = Utilities.GetUsername();
            string JobNo = "";

            PATransPoliciesBLL setApplinxRenew = new PATransPoliciesBLL();
            setApplinxRenew.SetPAAppxTransPrintRenew(policyno, agentno, brokergroup, createuser,out JobNo);

            #endregion

            #region "Call Web Service getPADocument"
            message = "";
            SessionID = ""; ;
            MessageStatus = "";
            TADocumentService PAWebServicegetPADocument = new TADocumentService();

            Box_Document[] PA_BIGBOX = new Box_Document[1];
            Box_Document PA_BOX_DOC = new Box_Document();

            PA_BOX_DOC.PolicyNo = policyno;
            PA_BOX_DOC.Document = "RTHSBTDR";
            PA_BOX_DOC.Flag = true;

            PA_BIGBOX[0] = PA_BOX_DOC;

            Box_Message[] BoxMessage;

            string tempUserHostName = "";
            string tempUserHostPassword = "";
            if (Session["UserHostName"].ToString().Substring(0, 2) == "QL")
            {
                tempUserHostName = "QLPA"; tempUserHostPassword = Session["UserHostName"].ToString().Trim();
            }
            else { tempUserHostName = "QAPA"; tempUserHostPassword = Session["UserHostName"].ToString().Trim(); }
            BoxMessage = PAWebServicegetPADocument.getPADocument(PA_BIGBOX, tempUserHostName, tempUserHostPassword);

           // BoxMessage = PAWebServicegetPADocument.getPADocument(PA_BIGBOX, "QAPA", "PASSWORD");

            if (BoxMessage.Length < 1)
            {
                throw new System.ArgumentException("Web Service getPADocument Error : " + BoxMessage[0].Error + " ,Policy No : " + policyno);

            }
            else
            {
                if (BoxMessage[0].Success != "true")
                {
                    throw new System.ArgumentException("Web Service getPADocument Error : " + BoxMessage[0].Error + "  ,Policy No : " + policyno);
                }
            }
            #endregion

            #region SET SetTransPrintRenewal

            DataTable TableInsureds = (DataTable)ViewState["InsuredsRenewal"];

            foreach( DataRow rows in TableInsureds.Rows){
                setApplinxRenew.SetTransPrintRenewal(JobNo, Convert.ToInt32(rows["InsuredID"].ToString()), rows["InsuredName"].ToString(), rows["Age"].ToString(), rows["PlanCode"].ToString(), rows["Premium"].ToString());
            }

            #endregion

            #region SET SetTransPrintRenewalBenefic

            foreach (DataRow rows in TableInsureds.Rows)
            {
                for (int i = 1; i < 5; i++)
                {
                    if (!string.IsNullOrEmpty(rows["Beneficaly" + i].ToString()))
                    {
                        setApplinxRenew.SetTransPrintRenewalBenefic(JobNo, Convert.ToInt32(rows["InsuredID"].ToString()), i, rows["Beneficaly" + i].ToString());
                    }
                    else
                    {
                        break;
                    }
                }
            }

            #endregion
            
            Response.Redirect("PAPrintPolicy.aspx?policyno=" + policyno+"&status=RENEW");
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = "ทำการต่ออายุกรมธรรม์ไม่สำเร็จ!!!โปรดติดต่อ AXA HelpDesk </BR> " + ex.Message ;

        }
                               
    }

    protected void DefaultPageRegisterClientScript()
    {
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptScrolling", "MenuScroll();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptTxtFocus", "setFocusTextbox();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDisplayMsg", "DisplayWarning();", true);
        //ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDatePicker", "<script type='text/javascript' language='javascript'>  $(document).ready(function () {  $('.MOTOR').find('img').attr('src', '../Images/Index/MOTOR1.png');  $('.MOTOR').find('a').css('color', '#922d3d'); $('.MOTOR').hover( function () { $(this).find('img').attr('src', '../Images/Index/MOTOR1.png'); } , function () { $(this).find('img').attr('src', '../Images/Index/MOTOR1.png'); } );addSubMenu('hdnMotor', '.subNavigate', 'ต่ออายุกรมธรรม์', '');Accordion('.wizard', 'hdnCriteriaStep');});</script>", false);
    }

    private void BindMainPolicy(Box_Inquriy PolicyMain)
    {
        //---------------------------------------------------------------
        string PolicyNo = Request.QueryString["PNUM"].Trim();
        this.lblPolicyNumber.Text = PolicyNo;
        this.lblAgent.Text = PolicyMain.AgentCode.ToString().Trim();
        this.lblEffective.Text = PolicyMain.EffectiveDate.ToString().Trim();
        this.lblExpire.Text = PolicyMain.Expiry.ToString().Trim();
        this.lblAgentName.Text = PolicyMain.AgentName.ToString().Trim();
        this.txtInceptionDate.CalendarDateString = PolicyMain.Inception.ToString().Trim();
        this.lblName.Text = PolicyMain.ContractOwnerName.ToString().Trim();
        this.txbHdClientCode.Text = PolicyMain.ContractOwnerCode.ToString().Trim();
   
        DataTable AddressTable = Client.GetClientData(PolicyMain.ContractOwnerCode.ToString().Trim());

        //UPDATE 2010-09-29
        string clientType = "";
        if (AddressTable.Rows.Count > 0)
        {
            lblAddress.Text = AddressTable.Rows[0]["CLTADDR01"].ToString();
            lblAddress.Text += " " + AddressTable.Rows[0]["CLTADDR02"].ToString();
            lblAddress.Text += " " + AddressTable.Rows[0]["CLTADDR03"].ToString();
            lblAddress.Text += " " + AddressTable.Rows[0]["CLTADDR04"].ToString();
            lblAddress.Text += " " + AddressTable.Rows[0]["CLTADDR05"].ToString();
            clientType = AddressTable.Rows[0]["CLTTYPE"].ToString();
            
        }
        clientType = "P";
        if (clientType == "P")
        {
            btnModifyClient.Visible = true;
        }
        else
        {
            btnModifyClient.Visible = false;
        }

        //------------------------------------------------------------------
        this.lblOccupation.Text = "";
        //------------------------------------------------------------------
        
    }
    private double BindInsureds(Box_EnquiryPA[] PAInsuredData)
    {
        double SumPremuim = 0;
        DataTable TableTemp = new DataTable();
        TableTemp.Columns.Add(new DataColumn("InsuredID", typeof(Int32)));
        TableTemp.Columns.Add(new DataColumn("InsuredName", typeof(string)));
        TableTemp.Columns.Add(new DataColumn("Age", typeof(string)));
        TableTemp.Columns.Add(new DataColumn("PlanCode", typeof(string)));
        TableTemp.Columns.Add(new DataColumn("Premium", typeof(string)));
        TableTemp.Columns.Add(new DataColumn("PremiumClass", typeof(string)));
        TableTemp.Columns.Add(new DataColumn("Beneficaly1", typeof(string)));
        TableTemp.Columns.Add(new DataColumn("Beneficaly2", typeof(string)));
        TableTemp.Columns.Add(new DataColumn("Beneficaly3", typeof(string)));
        TableTemp.Columns.Add(new DataColumn("Beneficaly4", typeof(string)));

        DataTable TableCoverage = new DataTable();
        TableCoverage.Columns.Add(new DataColumn("InsuredID", typeof(string)));
        TableCoverage.Columns.Add(new DataColumn("CoverageCode", typeof(string)));
        TableCoverage.Columns.Add(new DataColumn("CoverageDesc", typeof(string)));
        TableCoverage.Columns.Add(new DataColumn("CoveragePremium", typeof(string)));
        TableCoverage.Columns.Add(new DataColumn("CoverageSumInsure", typeof(string)));

        for (int i = 0; i < PAInsuredData.Length; i++)
        {
            DataRow Row = TableTemp.NewRow();
            Row["InsuredID"] = i + 1;
            Row["InsuredName"] = PAInsuredData[i].ClientName.Trim();
            Row["Age"] = PAInsuredData[i].Age.Trim();
            Row["PlanCode"] = PAInsuredData[i].PlanCode.Trim();
            Row["Premium"] = PAInsuredData[i].PremiumGross[0].Trim();
            Row["PremiumClass"] = PAInsuredData[i].AddPremiumClass.Trim();

            Row["Beneficaly1"] = PAInsuredData[i].arrBeneficiary[0].Trim();
            Row["Beneficaly2"] = PAInsuredData[i].arrBeneficiary[1].Trim();
            Row["Beneficaly3"] = PAInsuredData[i].arrBeneficiary[2].Trim();
            Row["Beneficaly4"] = PAInsuredData[i].arrBeneficiary[3].Trim();
            SumPremuim += Convert.ToDouble(PAInsuredData[i].PremiumGross[0].ToString().Trim().Replace(",", ""));
            TableTemp.Rows.Add(Row);

            int length = PAInsuredData[i].arrCoverageCode.Length;
            for (int j = 0; j < length; j++)
            {
                DataRow CoverageRow = TableCoverage.NewRow();
                CoverageRow["InsuredID"] = i+1;
                CoverageRow["CoverageCode"] = PAInsuredData[i].arrCoverageCode[j].Trim();
                CoverageRow["CoverageDesc"] = PAInsuredData[i].arrCoverageDesc[j].Trim();
                CoverageRow["CoveragePremium"] = PAInsuredData[i].arrCoveragePremium[j].Trim();
                CoverageRow["CoverageSumInsure"] = PAInsuredData[i].arrCoverageSumInsure[j].Trim();

                //SumPremuim += Convert.ToDouble(PAInsuredData[i].AddPremium.ToString().Trim().Replace(",", ""));
                TableCoverage.Rows.Add(CoverageRow);


            }
        }
        ViewState.Add("InsuredsRenewal", TableTemp);
        //--------------------------------------------------------------------------
        
        Session.Add("InsuredsCoverage", TableCoverage);
        //---------------------------------------------------------------------------
        this.gridPADetails.DataSource = TableTemp;
        this.gridPADetails.DataBind();

        return SumPremuim;
    }
    private void BindPremium(double SumPremium)
    {
        this.lblNetPremium.Text = SumPremium.ToString();
        this.lblNetStamp.Text = Math.Ceiling(SumPremium * 0.004).ToString();
        this.lblNetVAT.Text = "0";// Math.Ceiling(SumPremium * 0.0275).ToString();
        this.lblNetTotal.Text = (Convert.ToInt32(this.lblNetPremium.Text) + Convert.ToInt32(this.lblNetStamp.Text) + Convert.ToInt32(this.lblNetVAT.Text)).ToString();
    }
}
