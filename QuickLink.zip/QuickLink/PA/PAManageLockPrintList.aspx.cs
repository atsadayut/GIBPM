﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using PA.BLL;

public partial class PA_PAManageLockPrintList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.btnSearchPolicy.ServerClick += new EventHandler(btnSearchPolicy_ServerClick);
        this.gdvListPrint.PageIndexChanging += new GridViewPageEventHandler(gdvListPrint_PageIndexChanging);
        this.gdvListPrint.RowUpdating +=new GridViewUpdateEventHandler(gdvListPrint_RowUpdating);
        this.gdvListPrint.RowEditing +=new GridViewEditEventHandler(gdvListPrint_RowEditing);
        this.gdvListPrint.RowCancelingEdit += new GridViewCancelEditEventHandler(gdvListPrint_RowCancelingEdit);
        this.gdvListPrint.RowDataBound += new GridViewRowEventHandler(gdvListPrint_RowDataBound);
       
    }

    protected void gdvListPrint_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        int item = 0;
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataTable Table = (DataTable)Session["GetPAGetReport"];
            DropDownList flagOriginal = (DropDownList)e.Row.FindControl("ddlFlagOriginal");
            if (flagOriginal != null)
            {
                item = int.Parse(Table.Rows[e.Row.RowIndex]["DefaultFlagOriginal"].ToString());
                for (int i = 0; i < item + 1; i++)
                {
                    flagOriginal.Items.Add(i.ToString());
                }
                flagOriginal.SelectedValue = Table.Rows[e.Row.RowIndex]["FlagOriginal"].ToString();
            }

            DropDownList flagCopy = (DropDownList)e.Row.FindControl("ddlFlagCopy");
            if (flagCopy != null)
            {
                item = int.Parse(Table.Rows[e.Row.RowIndex]["DefaultFlagCopy"].ToString());
                for (int i = 0; i < item + 1; i++)
                {
                    flagCopy.Items.Add(i.ToString());
                }
                flagCopy.SelectedValue = Table.Rows[e.Row.RowIndex]["FlagCopy"].ToString();
            }
        }
    }

    void btnSearchPolicy_ServerClick(object sender, EventArgs e)
    {
        if (this.txtPolicyNo.Text.Trim() == string.Empty)
        {
            this.lblErrorMessage.Text = "ไม่พบข้อมูลทีท่านเลือก";
            this.lblInformMessage.Text = "";
        }
        else
        {
            getListPrint(this.txtPolicyNo.Text.Trim());
        }
    }

    void gdvListPrint_RowEditing(object sender, GridViewEditEventArgs e)
    {

        gdvListPrint.EditIndex = e.NewEditIndex;
        BindDataToGridView();
    }
    void gdvListPrint_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gdvListPrint.EditIndex = -1;
        BindDataToGridView();
    }
    void gdvListPrint_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {

        DropDownList ddlFlagOriginal = (DropDownList)gdvListPrint.Rows[e.RowIndex].FindControl("ddlFlagOriginal");
        DropDownList ddlFlagCopy = (DropDownList)gdvListPrint.Rows[e.RowIndex].FindControl("ddlFlagCopy");
        Label lblEditPolicyNo = (Label)gdvListPrint.Rows[e.RowIndex].FindControl("lblEditPolicyNo");

        PATransPrintsBLL SetPAPrintAllFlag = new PATransPrintsBLL();
        SetPAPrintAllFlag.SetPAPrintAllFlag(lblEditPolicyNo.Text, Convert.ToInt16(ddlFlagOriginal.SelectedValue), Convert.ToInt16(ddlFlagCopy.SelectedValue));

        gdvListPrint.EditIndex = -1;

        getListPrint(lblEditPolicyNo.Text);

        this.lblInformMessage.Text = "แก้ไขข้อมูลเรียบร้อยแล้ว";
        this.lblErrorMessage.Text = "";
    }

    private void getListPrint(string PolicyNo)
    {
        PATransPrintsBLL getPolicies = new PATransPrintsBLL();
        Session["GetPAGetReport"] = getPolicies.GetPAReportForManage(PolicyNo);
        BindDataToGridView();

    }
    protected void BindDataToGridView()
    {

        DataTable lst = (DataTable)Session["GetPAGetReport"];
        gdvListPrint.DataSource = lst;
        gdvListPrint.DataBind();
        if (lst == null)
        {
            this.lblTotalRecord.Text = "แสดงรายการข้อมูล [จำนวนข้อมูลทั้งหมด " + 0 + " รายการ]";
        }
        else
        {
            this.lblTotalRecord.Text = "แสดงรายการข้อมูล [จำนวนข้อมูลทั้งหมด " + lst.Rows.Count + " รายการ]";
        }
        this.lblInformMessage.Text = "";
        this.lblErrorMessage.Text = "";

    }
    void gdvListPrint_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdvListPrint.PageIndex = e.NewPageIndex;
        BindDataToGridView();

        this.lblInformMessage.Text = "";
        this.lblErrorMessage.Text = "";
    }
}