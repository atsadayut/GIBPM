﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;

//ADDITIONAL USING REFERENCE
using System.Web.UI.HtmlControls;
using System.Data;
using System.Data.Common;
using PA.BLL;
using PA.BusinessObjects;
using PA.DAL;

using WSQuickLinkTA;
using WSQuickLinkTAReport;

public partial class PA_PAPolicy : System.Web.UI.Page
{
    //PAGE LOAD
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            this.DefaultPageRegisterClientScript();
            
            this.txtNumberOfChilden.TextChanged += new EventHandler(txtNumberOfChilden_TextChanged);
            //---------------------add check IDCard 2012-11-12-----------------------
            this.txtPolicyHolderIDCard.TextChanged += new EventHandler(txtPolicyHolderIDCard_TextChanged);
            
            //-----------------------------------------------------------------------
            this.ddlPackage.SelectedIndexChanged += new EventHandler(ddlPackage_SelectedIndexChanged); //Package
            this.ddlLanguage.SelectedIndexChanged += new EventHandler(ddlLanguage_SelectedIndexChanged);
            this.ddlPolicyHolderProvince.SelectedIndexChanged += new EventHandler(ddlProvine_SelectedIndexChanged);
            this.ddlPolicyHolderAmphure.SelectedIndexChanged += new EventHandler(ddlAmphure_SelectedIndexChanged);
            this.chkSameAsPolicyHolder.CheckedChanged += new EventHandler(chkSameAsPolicyHolder_CheckedChanged);
            this.ddlOccupationClass.SelectedIndexChanged += new EventHandler(ddlOccupationClass_SelectedIndexChanged);
            this.ddlInsurancePlan.SelectedIndexChanged += new EventHandler(ddlInsurancePlan_SelectedIndexChanged);

            this.btnIssuePolicy.ServerClick += new EventHandler(btnIssuePolicy_ServerClick);
            this.btnSaveDraft.ServerClick += new EventHandler(btnSaveDraft_ServerClick);

            this.lblJobnoValue.Text = "[Auto Generate]";
            this.lblInformMessage.Text = "";
            this.lblErrorMessage.Text = "";
            this.lblValidateDateofBirth.Text = "";
            
            if (!Page.IsPostBack)
            {
                //this.SetPackageToDropdownList(ddlPackage,20, ddlLanguage.SelectedValue.Trim());
                try
                {
                    string m_JobNo = Request.QueryString["JobNo"];
                    string m_mode = Request.QueryString["mode"];

                    if (!string.IsNullOrEmpty(m_JobNo))
                    {
                        //Edit Mode
                        if (!string.IsNullOrEmpty(m_mode))
                        {
                            if (string.Compare(m_mode.Trim(), "edit") == 0)
                            {
                                this.lblJobnoValue.Text = m_JobNo.Trim();
                            }
                        }
                        //End Edit Mode
                        
                        this.GetBindPolicyHolder(m_JobNo.Trim());
                        this.GetBindDOB(m_JobNo.Trim());
                        this.GetBindPackagePolicy(m_JobNo.Trim(), Utilities.GetGroupBrokerID());
                        this.GetBindTraveler(m_JobNo.Trim());
                        this.GetBindPremium(m_JobNo.Trim());
                    }
                }
                catch (Exception ex)
                {
                    //DEFAULT MODE
                }
            }
            else
            {
                this.GenerateDynamicTraveler();
                this.ClearCssClassFocusError();
            }
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }

    void ddlOccupationClass_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.SetPlanToDropdownList(ddlInsurancePlan, ddlPackage.SelectedValue, this.GetOccupationClass(this.ddlOccupationClass.SelectedValue.Equals(string.Empty) ? 0 : Convert.ToInt32(this.ddlOccupationClass.SelectedValue.Trim())), ddlLanguage.SelectedValue.Trim());
    }

    void btnSaveDraft_ServerClick(object sender, EventArgs e)
    {
        DbTransaction dbTransaction = null;
       
        try
        {
            #region "GET USER HOST AND WEB"
            string m_UserWeb = Utilities.GetUsername().Trim();
            #endregion

            #region "VALIDATE VARIABLE ISSUED POLICY"
            //-------------------------------------------------------------------------------------------------------------
            //BEGIN VARIABLE-TRANSPOLICY
            //BEGIN VALIDATE ITEMS
            string msg = "";
            bool flagmsg = false;
            this.ddlLanguage.CssClass = "";
            if (this.ddlLanguage.SelectedValue == "00")
            {
                msg += "Language |";
                flagmsg = true;
                this.ddlLanguage.CssClass = "inputFocusError";
            }
            this.txtEffectiveDateFrom.CssClass = "";
            if (this.txtEffectiveDateFrom.Text.Trim() == string.Empty)
            {
                msg += "Effective Date From |";
                flagmsg = true;
                this.txtEffectiveDateFrom.CssClass = "inputFocusError";
            }
            this.txtEffectiveDateTo.CssClass = "";
            if (this.txtEffectiveDateTo.Text.Trim() == string.Empty)
            {
                msg += "Effective Date To |";
                flagmsg = true;
                this.txtEffectiveDateTo.CssClass = "inputFocusError";
            }
            this.txtDateofBirth.CssClass = "";
            if (this.txtDateofBirth.Text.Trim() == string.Empty)
            {
                msg += "DOB |";
                flagmsg = true;
                this.txtDateofBirth.CssClass = "inputFocusError";
            }
            this.ddlPackage.CssClass = "";
            if (this.ddlPackage.SelectedValue.Trim() == "00" || this.ddlPackage.SelectedValue.Trim() == "")
            {
                msg += "Package |";
                flagmsg = true;
                this.ddlPackage.CssClass = "inputFocusError";
            }
            this.ddlInsurancePlan.CssClass = "";
            if (this.ddlInsurancePlan.SelectedValue.Trim() == "00" || this.ddlInsurancePlan.SelectedValue.Trim() == "")
            {
                msg += "Insurance Plan |";
                flagmsg = true;
                this.ddlInsurancePlan.CssClass = "inputFocusError";
            }
            this.txtOccupation.CssClass = "";

            this.ddlOccupationClass.CssClass = "";
            if (this.ddlOccupationClass.SelectedValue.Trim() == "0" || this.ddlOccupationClass.SelectedValue.Trim() == "")
            {
                msg += "Occupation Class |";
                flagmsg = true;
                this.ddlOccupationClass.CssClass = "inputFocusError";
            }
            if (flagmsg)
            {
                this.lblErrorMessage.Text = msg + " ห้ามเป็นค่าว่าง";
                this.lblInformMessage.Text = "";
                return;
            }
            //END VALIDATE ITEMS

            string m_JobNo = "";
            string m_PackageID = this.ddlPackage.SelectedValue.Trim();
            string m_PlanCode = this.ddlInsurancePlan.SelectedValue.Trim();
            string m_InceptionDate = this.txtEffectiveDateFrom.Text.Trim().Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtEffectiveDateFrom.Text.Trim());
            string m_ExpiryDate = this.txtEffectiveDateTo.Text.Trim().Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtEffectiveDateTo.Text.Trim()); ;
            string m_AgentCode = Utilities.BrokerCode();
            string m_StaffCode = "";
            string m_OccupatnClass = this.GetOccupationClass(this.ddlOccupationClass.SelectedValue.Equals(string.Empty) ? 0 : Convert.ToInt32(this.ddlOccupationClass.SelectedValue.Trim()));
            string m_OccupatnDestination = this.ddlOccupationClass.SelectedItem.Text.Trim();
            Nullable<int> m_NoOfChildren = int.Parse(this.txtNumberOfChilden.Text.Trim());
            Nullable<int> m_GrossPremium = null;
            if (this.lblNetPremiumValue.Text.Trim() != string.Empty)
            {
                m_GrossPremium = (int)Utilities.ExactNumber(this.lblNetPremiumValue.Text.Trim());
            }
            Nullable<int> m_Stamp = null;
            if (this.lblStampDiutyValue.Text.Trim() != string.Empty)
            {
                m_Stamp = (int)Utilities.ExactNumber(this.lblStampDiutyValue.Text.Trim());
            }
            Nullable<int> m_SBT = null;
            if (this.lblTaxValue.Text.Trim() != string.Empty)
            {
                m_SBT = (int)Utilities.ExactNumber(this.lblTaxValue.Text.Trim());
            }
            Nullable<int> m_TotalPremium = null;
            if (this.lblTotlaPremiumValue.Text.Trim() != string.Empty)
            {
                m_TotalPremium = (int)Utilities.ExactNumber(this.lblTotlaPremiumValue.Text.Trim());
            }
            Nullable<SByte> m_isLongName = 0;
            string m_GroupBrokerID = Utilities.GetGroupBrokerID();
            string m_User = m_UserWeb;
            string m_Lang = this.ddlLanguage.SelectedValue;     //Lang   
            string m_BranchNo = this.txtBranchNo.Value.Trim();
            //END VARIABLE-TRANSPOLICY


            //-------------------------------------------------------------------------------------------------------------
            //BEGIN VARIABLE-TRANSPOLICY HOLDER
            string policyholdertype = ""; //CHECK POLICY HOLDER TYPE
            foreach (ListItem item in rdoTaxInvoiceType.Items)
            {
                if (item.Selected == true)
                {
                    policyholdertype = item.Value.Trim();  //Private ,Commercial
                }
            }
            //BEGIN VALIDATE ITEMS
            msg = "";
            flagmsg = false;
            if (policyholdertype == "Private")
            {
                //Private
                this.ddlPolicyHolderTitle.Attributes["class"] = "";
                if (ddlPolicyHolderTitle.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlPolicyHolderTitle.SelectedItem.Text.Trim() == "Please Selected" || ddlPolicyHolderTitle.SelectedItem.Text.Trim() == "")
                {
                    msg += "Title |";
                    flagmsg = true;
                    this.ddlPolicyHolderTitle.Attributes["class"] = "inputFocusError";
                }


                this.txtPolicyHolderName.Attributes["class"] = "";
                if (txtPolicyHolderName.Value.Trim() == string.Empty)
                {
                    msg += "Name |";
                    flagmsg = true;
                    this.txtPolicyHolderName.Attributes["class"] = "inputFocusError";
                }
                this.txtPolicyHolderSurname.Attributes["class"] = "";
                if (txtPolicyHolderSurname.Value.Trim() == string.Empty)
                {
                    msg += "Family name |";
                    flagmsg = true;
                    this.txtPolicyHolderSurname.Attributes["class"] = "inputFocusError";
                }
                this.txtPolicyHolderBirthay.Attributes["class"] = "";
                if (txtPolicyHolderBirthay.Value.Trim() == string.Empty)
                {
                    msg += "Birthday |";
                    flagmsg = true;
                    this.txtPolicyHolderBirthay.Attributes["class"] = "inputFocusError";
                }
                this.txtPolicyHolderIDCard.CssClass = "";
                if (txtPolicyHolderIDCard.Text.Trim() == string.Empty)
                {
                    msg += "ID Card/ Tax ID |";
                    flagmsg = true;
                    this.txtPolicyHolderIDCard.CssClass = "inputFocusError";
                }
                this.txtPolicyHolderTel.Attributes["class"] = "";
                if (txtPolicyHolderTel.Value.Trim() == string.Empty)
                {
                    msg += "Tel |";
                    flagmsg = true;
                    this.txtPolicyHolderTel.Attributes["class"] = "inputFocusError";
                }
                this.txtPolicyHolderAddressNo.Attributes["class"] = "";
                if (txtPolicyHolderAddressNo.Value.Trim() == string.Empty)
                {
                    msg += "Address no. |";
                    flagmsg = true;
                    this.txtPolicyHolderAddressNo.Attributes["class"] = "inputFocusError";
                }
                this.ddlPolicyHolderProvince.Attributes["class"] = "";
                if (ddlPolicyHolderProvince.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlPolicyHolderProvince.SelectedItem.Text.Trim() == "Please Selected" || ddlPolicyHolderProvince.SelectedItem.Text.Trim() == "")
                {
                    msg += "Provine |";
                    flagmsg = true;
                    this.ddlPolicyHolderProvince.Attributes["class"] = "inputFocusError";
                }
                this.ddlPolicyHolderAmphure.Attributes["class"] = "";
                if (ddlPolicyHolderAmphure.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlPolicyHolderAmphure.SelectedItem.Text.Trim() == "Please Selected" || ddlPolicyHolderAmphure.SelectedItem.Text.Trim() == "")
                {
                    msg += "District |";
                    flagmsg = true;
                    this.ddlPolicyHolderAmphure.Attributes["class"] = "inputFocusError";
                }
                this.ddlPolicyHolderTumbon.Attributes["class"] = "";
                if (ddlPolicyHolderTumbon.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlPolicyHolderTumbon.SelectedItem.Text.Trim() == "Please Selected" || ddlPolicyHolderTumbon.SelectedItem.Text.Trim() == "")
                {
                    msg += "Sub District |";
                    flagmsg = true;
                    this.ddlPolicyHolderTumbon.Attributes["class"] = "inputFocusError";
                }
                this.txtPolicyHolderZipCode.Attributes["class"] = "";
                if (txtPolicyHolderZipCode.Value.Trim() == string.Empty)
                {
                    msg += "Zip Code  |";
                    flagmsg = true;
                    this.txtPolicyHolderZipCode.Attributes["class"] = "inputFocusError";
                }
                if (flagmsg)
                {
                    this.lblErrorMessage.Text = msg + " on Policy Holder ห้ามเป็นค่าว่าง";
                    this.lblInformMessage.Text = "";
                    return;
                }

                this.txtBranchNo.Value = "";
                m_BranchNo = "";
            }
            else //Commercial
            {
                this.txtPolicyHolderName.Attributes["class"] = "";
                if (txtPolicyHolderName.Value.Trim() == string.Empty)
                {
                    msg += "Name |";
                    flagmsg = true;
                    this.txtPolicyHolderName.Attributes["class"] = "inputFocusError";
                }
                
                this.txtPolicyHolderIDCard.Attributes["class"] = "";
                if (txtPolicyHolderIDCard.Text.Trim() == string.Empty)
                {
                    msg += "ID Card/ Corporate Tax ID |";
                    flagmsg = true;
                    this.txtPolicyHolderIDCard.CssClass = "inputFocusError";
                }
                this.txtPolicyHolderTel.Attributes["class"] = "";
                if (txtPolicyHolderTel.Value.Trim() == string.Empty)
                {
                    msg += "Tel |";
                    flagmsg = true;
                    this.txtPolicyHolderTel.Attributes["class"] = "inputFocusError";
                }
                this.txtPolicyHolderAddressNo.Attributes["class"] = "";
                if (txtPolicyHolderAddressNo.Value.Trim() == string.Empty)
                {
                    msg += "Address no. |";
                    flagmsg = true;
                    this.txtPolicyHolderAddressNo.Attributes["class"] = "inputFocusError";
                }
                this.ddlPolicyHolderProvince.Attributes["class"] = "";
                if (ddlPolicyHolderProvince.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlPolicyHolderProvince.SelectedItem.Text.Trim() == "Please Selected" || ddlPolicyHolderProvince.SelectedItem.Text.Trim() == "")
                {
                    msg += "Provine |";
                    flagmsg = true;
                    this.ddlPolicyHolderProvince.Attributes["class"] = "inputFocusError";
                }
                this.ddlPolicyHolderAmphure.Attributes["class"] = "";
                if (ddlPolicyHolderAmphure.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlPolicyHolderAmphure.SelectedItem.Text.Trim() == "Please Selected" || ddlPolicyHolderAmphure.SelectedItem.Text.Trim() == "")
                {
                    msg += "District |";
                    flagmsg = true;
                    this.ddlPolicyHolderAmphure.Attributes["class"] = "inputFocusError";
                }
                this.ddlPolicyHolderTumbon.Attributes["class"] = "";
                if (ddlPolicyHolderTumbon.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlPolicyHolderTumbon.SelectedItem.Text.Trim() == "Please Selected" || ddlPolicyHolderTumbon.SelectedItem.Text.Trim() == "")
                {
                    msg += "Sub District |";
                    flagmsg = true;
                    this.ddlPolicyHolderTumbon.Attributes["class"] = "inputFocusError";
                }
                this.txtPolicyHolderZipCode.Attributes["class"] = "";
                if (txtPolicyHolderZipCode.Value.Trim() == string.Empty)
                {
                    msg += "Zip Code  |";
                    flagmsg = true;
                    this.txtPolicyHolderZipCode.Attributes["class"] = "inputFocusError";
                }
                if (flagmsg)
                {
                    this.lblErrorMessage.Text = msg + " on Policy Holder ห้ามเป็นค่าว่าง";
                    this.lblInformMessage.Text = "";
                    return;
                }
            }
            //END VALIDATE ITEMS

            //string m_JobNo = "";
            int m_InsurerID = 1;
            string m_ClientType = policyholdertype == "Private" ? "P" : "C";
            string m_ClientTitle = this.ddlPolicyHolderTitle.SelectedValue.Trim();
            string m_ClientName = this.txtPolicyHolderName.Value.Trim();
            string m_ClientSurName = this.txtPolicyHolderSurname.Value.Trim();
            string m_AddressNo = this.txtPolicyHolderAddressNo.Value.Trim();
            string m_Building = this.txtPolicyHolderBuilding.Value.Trim();
            string m_Soi = this.txtPolicyHolderSoi.Value.Trim(); ;
            // Check If langauge is THAI && User Key something, repleace "ซอย" to empty and concat "ซอย" in front of them
            if (ddlLanguage.SelectedValue == "T" && !string.IsNullOrEmpty(m_Soi))
            {
                m_Soi = "ซอย" + m_Soi.Replace("ซอย", "").Trim();
            }
            // Check If langauge is THAI && User Key something, repleace "ถนน" to empty and concat "ถนน" in front of them
            string m_Road = this.txtPolicyHolderRoad.Value.Trim();
            if (ddlLanguage.SelectedValue == "T" && !string.IsNullOrEmpty(m_Road))
            {
                m_Road = "ถนน" + m_Road.Replace("ถนน", "").Trim();
            }
            string m_Province = this.ddlPolicyHolderProvince.SelectedItem.Text.Trim();
            if (ddlLanguage.SelectedValue == "T" && !string.IsNullOrEmpty(m_Province) && m_Province != "กรุงเทพมหานคร")
            {
                m_Province = "จังหวัด" + m_Province.Replace("จังหวัด", "").Trim();

            }
            string m_Amphur = this.ddlPolicyHolderAmphure.SelectedItem.Text.Trim();
            if (ddlLanguage.SelectedValue == "T" && !string.IsNullOrEmpty(m_Amphur) && m_Province != "กรุงเทพมหานคร")
            {
                m_Amphur = "อำเภอ" + m_Amphur.Replace("อำเภอ", "").Trim();

            }
            string m_Tumbol = this.ddlPolicyHolderTumbon.SelectedItem.Text.Trim();
            if (ddlLanguage.SelectedValue == "T" && !string.IsNullOrEmpty(m_Amphur) && m_Province != "กรุงเทพมหานคร")
            {
                m_Tumbol = "ตำบล" + m_Tumbol.Replace("ตำบล", "").Trim();

            }
            string m_PostCode = this.txtPolicyHolderZipCode.Value.Trim();
            string m_Birthday = this.txtPolicyHolderBirthay.Value.Trim().Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtPolicyHolderBirthay.Value.Trim());
            string m_Gender = this.ddlPolicyHolderGender.SelectedValue.Trim();
            string m_Status = this.ddlPolicyHolderMaritalStatus.SelectedValue.Trim();
            string m_Nationality = this.ddlPolicyHolderNationality.SelectedValue.Trim();
            string m_IDCard = this.txtPolicyHolderIDCard.Text.Trim();
            string m_Tel = this.txtPolicyHolderTel.Value.Trim();
            string m_Email = this.txtPolicyHolderEmail.Value.Trim();
            string m_LangPolicyHolder = this.ddlLanguage.SelectedValue;
            //END VARIABLE-TRANSPOLICY HOLDER


            //-------------------------------------------------------------------------------------------------------------
            //BEGIN VARIABLE-Insured
            PAPlanPackagesBLL clsplanpackage = new PAPlanPackagesBLL();
            PAPlanPackages getage = clsplanpackage.GetPAPlanPackages(m_PackageID);

            int m_AgeOfTravelerFrom = Convert.ToInt32(getage.AgeOfInsurerFrom);     //18
            int m_AgeOfTravelerTo = Convert.ToInt32(getage.AgeOfInsurerTo);         //68
            int m_AgeOfChildrenFrom = Convert.ToInt32(getage.AgeOfChildrenFrom);    //1
            int m_AgeOfChildrenTo = Convert.ToInt32(getage.AgeOfChildrenTo);        //17

            DateTime dt1 = new DateTime();
            DateTime dt2 = new DateTime();
            dt2 = Convert.ToDateTime(m_InceptionDate); //DEFAULT EFFECTTIVE DATE FROM
            bool ret = false;
            
            #region "Insured 1"
            string m_Traveler1ClientName = this.txtTraveler1Name.Value.Trim();
            string m_Traveler1ClientSurName = this.txtTraveler1Surname.Value.Trim();
            string m_Traveler1Birthday = this.txtDateofBirth.Text.Trim();
            string m_Traveler1IDCard = this.txtTraveler1IDCard.Value.Trim();
            string m_Traveler1Tel = this.txtTraveler1Tel.Value.Trim();
            bool chkTraveler1Hier = this.chkTraveler1BeneficialyHeir.Checked;

            msg = "";
            flagmsg = false;
            this.ddlTraveler1Title.Attributes["class"] = "";
            if (ddlTraveler1Title.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlTraveler1Title.SelectedItem.Text.Trim() == "Please Selected" || ddlTraveler1Title.SelectedItem.Text.Trim() == "")
                {
                    msg += "Title |";
                    flagmsg = true;
                    this.ddlTraveler1Title.Attributes["class"] = "inputFocusError";
                }

            this.txtTraveler1Name.Attributes["class"] = "";
            if (m_Traveler1ClientName == string.Empty)
            {
                msg += "Name |";
                flagmsg = true;
                this.txtTraveler1Name.Attributes["class"] = "inputFocusError";
            }
            this.txtTraveler1Surname.Attributes["class"] = "";
            if (m_Traveler1ClientSurName == string.Empty)
            {
                msg += "Family name |";
                flagmsg = true;
                this.txtTraveler1Surname.Attributes["class"] = "inputFocusError";
            }
            this.txtTraveler1Birthday.Attributes["class"] = "";
            if (m_Traveler1Birthday == string.Empty)
            {
                msg += "Birthday |";
                flagmsg = true;
                this.txtTraveler1Birthday.Attributes["class"] = "inputFocusError";
            }
            this.txtTraveler1IDCard.Attributes["class"] = "";
            if (m_Traveler1IDCard == string.Empty)
            {
                msg += "ID Card |";
                flagmsg = true;
                this.txtTraveler1IDCard.Attributes["class"] = "inputFocusError";
            }
            this.txtTraveler1Tel.Attributes["class"] = "";
            if (m_Traveler1Tel == string.Empty)
            {
                msg += "Tel |";
                flagmsg = true;
                this.txtTraveler1Tel.Attributes["class"] = "inputFocusError";
            }
            //CHECK BENEFICIARY
            if (chkTraveler1Hier == false)
            {
                this.txtTraveler1BeneficialyName1.Attributes["class"] = "";
                this.txtTraveler1BeneficialySurname1.Attributes["class"] = "";
                if (string.IsNullOrEmpty(txtTraveler1BeneficialyName1.Value.Trim()) || string.IsNullOrEmpty(txtTraveler1BeneficialySurname1.Value.Trim()))
                {
                    msg += "Beneficiary Name and Family name | ";
                    flagmsg = true;
                    this.txtTraveler1BeneficialyName1.Attributes["class"] = "inputFocusError";
                    this.txtTraveler1BeneficialySurname1.Attributes["class"] = "inputFocusError";
                }
            }
            //END CHECK
            if (flagmsg)
            {
                this.lblErrorMessage.Text = msg + " on Insured 1 ห้ามเป็นค่าว่าง";
                this.lblInformMessage.Text = "";
                return;
            }

            //CHECK BIRTHDAY ON TRAVELER 1
            string m_traveler1_birthday = this.txtTraveler1Birthday.Value.Trim().Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtTraveler1Birthday.Value.Trim()); //30/05/2012 to 2012-05-30;
            if (!m_traveler1_birthday.Equals(string.Empty))
            {
                dt1 = Convert.ToDateTime(m_traveler1_birthday);
                ret = this.IsBirthDayOverLimitOfEffectiveDate(m_AgeOfTravelerFrom, m_AgeOfTravelerTo, dt1, dt2);
                if (ret)
                {
                    this.lblErrorMessage.Text = "กรุณาติดต่อ บริษัท เนื่องจากอายุผู้เอาประกันภัยเกิน " + m_AgeOfTravelerTo + "ปี / Please contact AXA helpdesk as age is over " + m_AgeOfTravelerTo + " on Insured 1";
                    this.lblInformMessage.Text = "";
                    return;
                }
            }
            else
            {
                this.lblErrorMessage.Text = "Birthday on Insured 1 | ห้ามเป็นค่าว่าง";
                this.lblInformMessage.Text = "";
                return;
            }

            //VALIDATE RATIO IS 100 ON TRAVELER1
            int traveler1Ratio1 = 0;
            int traveler1Ratio2 = 0;
            int traveler1Ratio3 = 0;
            int traveler1Ratio4 = 0;

            if (chkTraveler1Hier == false)
            {
                if (!string.IsNullOrEmpty(txtTraveler1BeneficialyName1.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler1BeneficialySurname1.Value.Trim()))
                {
                    traveler1Ratio1 = txtTraveler1BeneficialyRatio1.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler1BeneficialyRatio1.Value.Trim());
                }

                if (!string.IsNullOrEmpty(txtTraveler1BeneficialyName2.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler1BeneficialySurname2.Value.Trim()))
                {
                    traveler1Ratio2 = txtTraveler1BeneficialyRatio2.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler1BeneficialyRatio2.Value.Trim());
                }

                if (!string.IsNullOrEmpty(txtTraveler1BeneficialyName3.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler1BeneficialySurname3.Value.Trim()))
                {
                    traveler1Ratio3 = txtTraveler1BeneficialyRatio3.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler1BeneficialyRatio3.Value.Trim());
                }

                if (!string.IsNullOrEmpty(txtTraveler1BeneficialyName4.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler1BeneficialySurname4.Value.Trim()))
                {
                    traveler1Ratio4 = txtTraveler1BeneficialyRatio4.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler1BeneficialyRatio4.Value.Trim());
                }
                if (traveler1Ratio1 + traveler1Ratio2 + traveler1Ratio3 + traveler1Ratio4 != 100)
                {
                    this.lblErrorMessage.Text = "Sum of Beneficiary Ratio on Insured1 Must be 100!!! ";
                    this.lblInformMessage.Text = "";
                    return;
                }
            }
            #endregion
            #region "TRAVELER 2,ANOTHER"
            if (ddlPackage.SelectedValue == "0004") //Family
            {
                #region "TRAVELERR 2"
                //CHECK TRAVELERR 2
                string m_Traveler2ClientName = this.txtTraveler2Name.Value.Trim();
                string m_Traveler2ClientSurName = this.txtTraveler2Surname.Value.Trim();
                string m_Traveler2Birthday = this.txtTraveler2Birthday.Value.Trim();
                string m_Traveler2IDCard = this.txtTraveler2IDCard.Value.Trim();
                string m_Traveler2Tel = this.txtTraveler2Tel.Value.Trim();
                bool chkTraveler2Hier = this.chkTraveler2BeneficialyHeir.Checked;

                msg = "";
                flagmsg = false;
                this.ddlTraveler2Title.Attributes["class"] = "";
                if (ddlTraveler2Title.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlTraveler2Title.SelectedItem.Text.Trim() == "Please Selected" || ddlTraveler2Title.SelectedItem.Text.Trim() == "")
                {
                    msg += "Title |";
                    flagmsg = true;
                    this.ddlTraveler2Title.Attributes["class"] = "inputFocusError";
                }
                this.txtTraveler2Name.Attributes["class"] = "";
                if (m_Traveler2ClientName == string.Empty)
                {
                    msg += "Name |";
                    flagmsg = true;
                    this.txtTraveler2Name.Attributes["class"] = "inputFocusError";
                }
                this.txtTraveler2Surname.Attributes["class"] = "";
                if (m_Traveler2ClientSurName == string.Empty)
                {
                    msg += "Family name |";
                    flagmsg = true;
                    this.txtTraveler2Surname.Attributes["class"] = "inputFocusError";
                }
                this.txtTraveler2Birthday.Attributes["class"] = "";
                if (m_Traveler2Birthday == string.Empty)
                {
                    msg += "Birthday |";
                    flagmsg = true;
                    this.txtTraveler2Birthday.Attributes["class"] = "inputFocusError";
                }
                this.txtTraveler2IDCard.Attributes["class"] = "";
                if (m_Traveler2IDCard == string.Empty)
                {
                    msg += "Passport No |";
                    flagmsg = true;
                    this.txtTraveler2IDCard.Attributes["class"] = "inputFocusError";
                }
                this.txtTraveler2Tel.Attributes["class"] = "";
                if (m_Traveler2Tel == string.Empty)
                {
                    msg += "Tel |";
                    flagmsg = true;
                    this.txtTraveler2Tel.Attributes["class"] = "inputFocusError";
                }
                //CHECK BENEFICIARY
                if (chkTraveler2Hier == false)
                {
                    this.txtTraveler2BeneficialyName1.Attributes["class"] = "";
                    this.txtTraveler2BeneficialySurname1.Attributes["class"] = "";
                    if (string.IsNullOrEmpty(txtTraveler2BeneficialyName1.Value.Trim()) || string.IsNullOrEmpty(txtTraveler2BeneficialySurname1.Value.Trim()))
                    {
                        msg += "Beneficiary Name and Family name | ";
                        flagmsg = true;
                        this.txtTraveler2BeneficialyName1.Attributes["class"] = "inputFocusError";
                        this.txtTraveler2BeneficialySurname1.Attributes["class"] = "inputFocusError";
                    }
                }
                //END CHECK
                if (flagmsg)
                {
                    this.lblErrorMessage.Text = msg + " on Insured 2 ห้ามเป็นค่าว่าง";
                    this.lblInformMessage.Text = "";
                    return;
                }

                //CHECK BIRTHDAY ON Insured 2
                string m_traveler2_birthday = this.txtTraveler2Birthday.Value.Trim().Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtTraveler2Birthday.Value.Trim()); //30/05/2012 to 2012-05-30;
                if (!m_traveler2_birthday.Equals(string.Empty))
                {
                    dt1 = Convert.ToDateTime(m_traveler2_birthday);
                    ret = this.IsBirthDayOverLimitOfEffectiveDate(m_AgeOfTravelerFrom, m_AgeOfTravelerTo, dt1, dt2);
                    if (ret)
                    {
                        this.lblErrorMessage.Text = "กรุณาติดต่อ บริษัท เนื่องจากอายุผู้เอาประกันภัยเกิน " + m_AgeOfTravelerTo + "ปี / Please contact AXA helpdesk as age is over " + m_AgeOfTravelerTo + " on Insured 2";
                        this.lblInformMessage.Text = "";
                        return;
                    }
                }
                else
                {
                    this.lblErrorMessage.Text = "Birthday on Insured 2 | ห้ามเป็นค่าว่าง";
                    this.lblInformMessage.Text = "";
                    return;
                }

                //VALIDATE RATIO IS 100 ON TRAVELER1
                int traveler2Ratio1 = 0;
                int traveler2Ratio2 = 0;
                int traveler2Ratio3 = 0;
                int traveler2Ratio4 = 0;

                if (chkTraveler2Hier == false)
                {
                    if (!string.IsNullOrEmpty(txtTraveler2BeneficialyName1.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler2BeneficialySurname1.Value.Trim()))
                    {
                        traveler2Ratio1 = txtTraveler2BeneficialyRatio1.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler2BeneficialyRatio1.Value.Trim());
                    }

                    if (!string.IsNullOrEmpty(txtTraveler2BeneficialyName2.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler2BeneficialySurname2.Value.Trim()))
                    {
                        traveler2Ratio2 = txtTraveler2BeneficialyRatio2.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler2BeneficialyRatio2.Value.Trim());
                    }

                    if (!string.IsNullOrEmpty(txtTraveler2BeneficialyName3.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler2BeneficialySurname3.Value.Trim()))
                    {
                        traveler2Ratio3 = txtTraveler2BeneficialyRatio3.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler2BeneficialyRatio3.Value.Trim());
                    }

                    if (!string.IsNullOrEmpty(txtTraveler2BeneficialyName4.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler2BeneficialySurname4.Value.Trim()))
                    {
                        traveler2Ratio4 = txtTraveler2BeneficialyRatio4.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler2BeneficialyRatio4.Value.Trim());
                    }

                    if (traveler2Ratio1 + traveler2Ratio2 + traveler2Ratio3 + traveler2Ratio4 != 100)
                    {
                        this.lblErrorMessage.Text = "Sum of Beneficiary Ratio on Insured2 Must be 100!!! ";
                        this.lblInformMessage.Text = "";
                        return;
                    }
                }
                #endregion
                #region "TRAVELER ANOTHER"
                //CHECK CHILD (1,2) 
                int m_allpeople = (int)m_NoOfChildren + 2;
                if (m_allpeople > 2)
                {
                    //CHECK CHILD 
                    for (int ch = 3; ch <= m_allpeople; ch++)
                    {

                        //CHECK EMPTY ON TRAVELER 3 UP -----
                        string id_ddltraveltitle = "ctl00$MainContent$ddlTraveler" + ch + "Title";  //ctl00$MainContent$ddlTraveler3Title
                        string m_TravelTitle = Request.Form[id_ddltraveltitle].Trim();
                        string id_clientname = "ctl00$MainContent$txtTraveler" + ch + "Name";
                        string m_TravelerChildClientName = Request.Form[id_clientname].Trim();
                        string id_clientsurname = "ctl00$MainContent$txtTraveler" + ch + "SurName";
                        string m_TravelerChildClientSurName = Request.Form[id_clientsurname].Trim();
                        string id_birthday = "ctl00$MainContent$txtTraveler" + ch + "Birthday";
                        string m_TravelerChildBirthday = Request.Form[id_birthday].Trim();
                        string id_idcard = "ctl00$MainContent$txtTraveler" + ch + "IDCard";
                        string m_TravelerChildIDCard = Request.Form[id_idcard];
                        string id_tel = "ctl00$MainContent$txtTraveler" + ch + "Tel";
                        string m_TravelerChildTel = Request.Form[id_tel];

                        msg = "";
                        flagmsg = false;

                        if (m_TravelTitle == "โปรดเลือก" || m_TravelTitle == "Please Selected" || m_TravelTitle == ""|| m_TravelTitle == "00")
                        {
                            msg += "Title |";
                            flagmsg = true;
                        }

                        if (m_TravelerChildClientName == string.Empty)
                        {
                            msg += "Name |";
                            flagmsg = true;
                        }
                        if (m_TravelerChildClientSurName == string.Empty)
                        {
                            msg += "Family name |";
                            flagmsg = true;
                        }
                        if (m_TravelerChildBirthday == string.Empty)
                        {
                            msg += "Birthday |";
                            flagmsg = true;
                        }
                        if (m_TravelerChildIDCard == string.Empty)
                        {
                            msg += "ID Card |";
                            flagmsg = true;
                        }
                        if (m_TravelerChildTel == string.Empty)
                        {
                            msg += "Tel |";
                            flagmsg = true;
                        }

                        //CHECK BENEFICIARY
                        string m_BeneficiaryName = "";
                        string m_BeneficiarySurName = "";
                        string id_BeneficiaryName = "ctl00$MainContent$txtTraveler" + ch + "BeneficialyName1";
                        m_BeneficiaryName = Request.Form[id_BeneficiaryName];
                        string id_BeneficiarySurName = "ctl00$MainContent$txtTraveler" + ch + "BeneficialySurname1";
                        m_BeneficiarySurName = Request.Form[id_BeneficiarySurName];
                        string id_BeneficiaryHier = "ctl00$MainContent$chkTraveler" + ch + "BeneficialyHeir";
                        string m_BeneficiaryHier = Request.Form[id_BeneficiaryHier];
                        if (m_BeneficiaryHier != "on")
                        {
                            if (string.IsNullOrEmpty(m_BeneficiaryName) && string.IsNullOrEmpty(m_BeneficiarySurName))
                            {
                                msg += "Name and Family name |";
                                flagmsg = true;
                            }
                        }

                        if (flagmsg)
                        {
                            msg += " on Insured " + ch + " ห้ามเป็นค่าว่าง";
                            break;
                        }

                        //CHECK BIRTHDAY ON Insured 3 UP -----
                        msg = "";
                        flagmsg = false;
                        /*if (!string.IsNullOrEmpty(Request.Form[id_birthday]))
                        {
                            string m_travelerchild_birthday = TA.TAUtilities.ConvertDateFieldToDB(Request.Form[id_birthday]);
                            dt1 = Convert.ToDateTime(m_travelerchild_birthday);
                            ret = this.IsBirthDayOverLimitOfEffectiveDate(1, 21, dt1, dt2);
                            if (ret)
                            {
                                msg += "Insured " + ch + " Birthday ไม่อยู่ในช่วง 1-21 ปี นับจากวันที่คุ้มครอง| <br>";
                                flagmsg = true;
                                break;
                            }
                            else
                            {
                                //1-23
                                dt1 = Convert.ToDateTime(m_travelerchild_birthday);
                                ret = this.IsBirthDayOverLimitOfEffectiveDate(m_AgeOfChildrenFrom, m_AgeOfChildrenTo, dt1, dt2); //1-17
                                if (ret)
                                {
                                    string id_isStudent = "ctl00$MainContent$chkTraveler" + ch + "Occupation";
                                    int m_isStudent = 0;
                                    if (!string.IsNullOrEmpty(Request.Form[id_isStudent]))
                                    {
                                        m_isStudent = 1; //on = true = selected
                                    }
                                    string id_isSingle = "ctl00$MainContent$chkTraveler" + ch + "Status";
                                    int m_isSingle = 0;
                                    if (!string.IsNullOrEmpty(Request.Form[id_isSingle]))
                                    {
                                    }
                                    if (m_isStudent == 0 || m_isSingle == 0)
                                    {
                                        msg += "Insured " + ch + " Birthday ไม่อยู่ในช่วง " + m_AgeOfChildrenFrom + "-" + m_AgeOfChildrenTo + " ปี นับจากวันที่คุ้มครองไม่เป็นนักศึกษาและสถานะภาพไม่โสด | <br>";
                                        flagmsg = true;
                                        break;
                                    }
                                }
                            }
                        }*/
                        //VALIDATE RATIO IS 100 ON TRAVELER1
                        int travelerxRatio = 0;

                        for (int j = 1; j < 5; j++)
                        {

                            string msub_BeneficiaryName = "";
                            string msub_BeneficiarySurName = "";
                            string msub_BeneficiaryRatio = "";

                            string idsub_BeneficiaryName = "ctl00$MainContent$txtTraveler" + ch + "BeneficialyName" + j.ToString();
                            msub_BeneficiaryName = Request.Form[idsub_BeneficiaryName];

                            string idsub_BeneficiarySurName = "ctl00$MainContent$txtTraveler" + ch + "BeneficialySurname" + j.ToString();
                            msub_BeneficiarySurName = Request.Form[idsub_BeneficiarySurName];

                            string idsub_BeneficiaryRatio = "ctl00$MainContent$txtTraveler" + ch + "BeneficialyRatio" + j.ToString();
                            msub_BeneficiaryRatio = Request.Form[idsub_BeneficiaryRatio];

                            if (m_BeneficiaryHier == "on")
                            {

                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(msub_BeneficiaryName) && !string.IsNullOrEmpty(msub_BeneficiarySurName))
                                {
                                    travelerxRatio += msub_BeneficiaryRatio.Equals(string.Empty) ? 0 : Convert.ToInt32(msub_BeneficiaryRatio.Trim());
                                }
                            }
                        }
                        if (travelerxRatio != 100 && m_BeneficiaryHier != "on")
                        {
                            this.lblErrorMessage.Text = "Sum of Beneficiary Ratio on Insured " + ch + " Must be 100!!! ";
                            this.lblInformMessage.Text = "";
                            return;
                        }
                    }
                    if (flagmsg)
                    {
                        this.lblErrorMessage.Text = msg;
                        this.lblInformMessage.Text = "";
                        return;
                    }
                }

                #endregion
            }
            #endregion
           
            //END VARIABLE-TRAVELER



            //-------------------------------------------------------------------------------------------------------------
            //BEGIN VARIABLE-LONGNAME
            //string m_JobNo = "";
            string m_LongName1 = this.txtLongName1.Value.Trim();
            string m_LongName2 = this.txtLongName2.Value.Trim();
            string m_temp = string.Concat(m_LongName1, m_LongName2);
            if (m_temp != string.Empty)
            {
                m_isLongName = 1;
            }
            //END VARIABLE-LONGNAME


            //-------------------------------------------------------------------------------------------------------------
            //BEGIN VARIABLE-PLAN PREMIUM
            PAPlanPremiumsBLL clsPAPlanPremiumsBLL = new PAPlanPremiumsBLL();
            DataTable dt = clsPAPlanPremiumsBLL.GetDtPAPlanPremiums(m_PlanCode, m_OccupatnClass);
            double m_d_SumInsuredPA2 = double.Parse(dt.Rows[0]["SumInsuredPA2"].ToString().Trim());
            double m_d_SumInsuredME = double.Parse(dt.Rows[0]["SumInsuredME"].ToString().Trim());
            double m_d_PremiumPA2 = double.Parse(dt.Rows[0]["PremiumPA2"].ToString().Trim());
            double m_d_PremiumME = double.Parse(dt.Rows[0]["PremiumME"].ToString().Trim());
            double m_d_AddPremium = double.Parse(dt.Rows[0]["AddPremium"].ToString().Trim());
            double m_d_netpremium = double.Parse(dt.Rows[0]["GrossPremium"].ToString().Trim());
            double m_d_tax = double.Parse(dt.Rows[0]["SBT"].ToString().Trim());
            double m_d_stamp = double.Parse(dt.Rows[0]["Stamp"].ToString().Trim());
            double m_d_total = double.Parse(dt.Rows[0]["TotalPremium"].ToString().Trim());
            //END VARIABLE-PLAN PREMIUM


            //-------------------------------------------------------------------------------------------------------------
            
            #endregion

            #region "GET/SET JOB NUMBER (NOW NONE TRANSACTION)"
            PAJobRunningBLL clsPAJobRunningBLL = new PAJobRunningBLL();
            string qry_mode = Request.QueryString["mode"];
            string qry_jobno = Request.QueryString["JobNo"];

            if (!string.IsNullOrEmpty(qry_mode) && !string.IsNullOrEmpty(qry_jobno))
            {
                if (string.Compare(qry_mode.Trim(), "edit") == 0)
                {
                    m_JobNo = qry_jobno.Trim();
                }
                else
                {
                    m_JobNo = clsPAJobRunningBLL.GetPAJobRunningNumber();

                    if (string.IsNullOrEmpty(m_JobNo))
                    {
                        throw new Exception("เกิดข้อผิดพลาดในการสร้างหมายเลข Job Number กรุณาทดลองบันทึกงานอีกครั้งหรือติดต่อผู้ดูแลระบบ");
                    }
                }
            }
            else
            {
                m_JobNo = clsPAJobRunningBLL.GetPAJobRunningNumber();

                if (string.IsNullOrEmpty(m_JobNo))
                {
                    throw new Exception("เกิดข้อผิดพลาดในการสร้างหมายเลข Job Number กรุณาทดลองบันทึกงานอีกครั้งหรือติดต่อผู้ดูแลระบบ");
                }
            }

            #endregion

            #region "OPEN DB"
            //OPEN DB
            DbProviderHelper.OpenDb();
            #endregion

            #region "OPEN TRANSACTION"
            //TRANSACTION BEGIN
            dbTransaction = DbProviderHelper.BeginTransaction();
            #endregion

            #region "#1-INSERT/UPDATE TRANSPOLICY"
            //Create TransPolicy
            PATransPoliciesBLL clsPATransPoliciesBLL = new PATransPoliciesBLL();
            //clsPATransPoliciesBLL.SetPATransPolicy(m_JobNo, "0003", "1A", "2012-08-30", "2013-08-30", "BR002", "AJ", "01", "Programer", 0, 890, 7, 20, 1000, 0, "G0001", "Nam", "T");
            clsPATransPoliciesBLL.SetPATransPolicy(m_JobNo, m_PackageID, m_PlanCode, m_InceptionDate, m_ExpiryDate, m_AgentCode, m_StaffCode, m_OccupatnClass, m_OccupatnDestination, m_NoOfChildren, m_GrossPremium, m_Stamp, m_SBT, m_TotalPremium, m_isLongName, m_GroupBrokerID, m_User, m_Lang, dbTransaction);
            #endregion

            #region "#2-INSERT/UPDATE TRANSPOLICYHOLDER"
            PATransPolicyHoldersBLL clsPATransPolicyHoldersBLL = new PATransPolicyHoldersBLL();
            //clsPATransPolicyHoldersBLL.SetPATransPolicyHolders(m_JobNo, 1, "P", "นาย", "ลอง", "ลองนามสกุล", "1/1", "อาคาร", "ซอย", "ถนน", "กรุงเทพมหานคร", "หลักสี่", "ตำบล", "10240", "1989-08-28", "F", "Z", "", "38418000XXXXX", "081", "Test@hotmail.com", "T");
            clsPATransPolicyHoldersBLL.SetPATransPolicyHolders(m_JobNo, m_InsurerID, m_ClientType, m_ClientTitle, m_ClientName, m_ClientSurName, m_AddressNo, m_Building, m_Soi, m_Road, m_Province, m_Amphur, m_Tumbol, m_PostCode, m_Birthday, m_Gender, m_Status, m_Nationality, m_IDCard, m_Tel, m_Email, m_LangPolicyHolder, m_BranchNo, dbTransaction);
            #endregion

            #region "#3,4-INSERT/UPDATE TRANSPOLICY INSURE"

            int numberofchid = int.Parse(this.txtNumberOfChilden.Text.Trim());
            if (numberofchid == 0)
            {
                if (ddlPackage.SelectedValue != "0004") // 0004 = Family
                {
                    numberofchid = -1; // Set for != Family
                }
            }
            int m_sum_TotalPremiumPolicyInsure = 0;
            int m_sum_SBTPolicyInsure = 0;
            int m_sum_StampPolicyInsure = 0;
            int m_sum_GrossPremiumPolicyInsure = 0;

            for (int c = 1; c <= (numberofchid + 2); c++)
            {
                //-------------------------------------------------------------------------------------------------------------
                //BEGIN VARIABLE-TRANSPOLICY INSURE
                //string  m_JobNo = "";
                int m_InsuredIDPolicyInsure = c;
                string m_ClientCodePolicyInsure = "";
                string m_ClientTitlePolicyInsure = this.ddlTraveler1Title.SelectedItem.Text.Trim();
                string m_ClientNamePolicyInsure = this.txtTraveler1Name.Value.Trim();
                string m_ClientSurNamePolicyInsure = this.txtTraveler1Surname.Value.Trim();
                string m_BirthdayPolicyInsure = this.txtDateofBirth.Text.Trim().Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtDateofBirth.Text.Trim());
                string m_IDCardPolicyInsure = this.txtTraveler1IDCard.Value.Trim();
                string m_TelPolicyInsure = this.txtTraveler1Tel.Value.Trim();
                Nullable<int> m_SumInsuredPA2PolicyInsure = (int)m_d_SumInsuredPA2;
                Nullable<int> m_SumInsuredMEPolicyInsure = (int)m_d_SumInsuredME;
                Nullable<int> m_PremiumPA2PolicyInsure = (int)m_d_PremiumME;
                Nullable<int> m_PremiumMEPolicyInsure = (int)m_d_PremiumPA2;
                Nullable<int> m_AddPremiumPolicyInsure = (int)m_d_AddPremium;
                Nullable<int> m_GrossPremiumPolicyInsure = (int)m_d_netpremium;
                Nullable<int> m_StampPolicyInsure = (int)m_d_stamp;
                Nullable<int> m_SBTPolicyInsure = (int)m_d_tax;
                Nullable<int> m_TotalPremiumPolicyInsure = (int)m_d_total;
                Nullable<SByte> m_isBeneficiaryPolicyInsure = 0;
                Nullable<SByte> m_isStudentPolicyInsure = 0;
                Nullable<SByte> m_isSinglePolicyInsure = 0;
                //END VARIABLE-TRANSPOLICY INSURE
                //-------------------------------------------------------------------------------------------------------------
                // if parent calucate here
                if (m_InsuredIDPolicyInsure < 3)
                {
                    m_sum_GrossPremiumPolicyInsure += Convert.ToInt32(m_GrossPremiumPolicyInsure);
                    m_sum_StampPolicyInsure += Convert.ToInt32(m_StampPolicyInsure);
                    m_sum_SBTPolicyInsure += Convert.ToInt32(m_SBTPolicyInsure);
                    m_sum_TotalPremiumPolicyInsure += Convert.ToInt32(m_TotalPremiumPolicyInsure);
                }

                string id_title = "ctl00$MainContent$ddlTraveler" + c + "Title";                //ctl00$MainContent$ddlTraveler1Title
                m_ClientTitlePolicyInsure = Request.Form[id_title];                             //Values
                string id_clientname = "ctl00$MainContent$txtTraveler" + c + "Name";
                m_ClientNamePolicyInsure = Request.Form[id_clientname];
                string id_clientsurname = "ctl00$MainContent$txtTraveler" + c + "SurName";
                m_ClientSurNamePolicyInsure = Request.Form[id_clientsurname];
                string id_birthday = "ctl00$MainContent$txtTraveler" + c + "Birthday";
                m_BirthdayPolicyInsure = "";
                if (!string.IsNullOrEmpty(Request.Form[id_birthday]))
                {
                    m_BirthdayPolicyInsure = TA.TAUtilities.ConvertDateFieldToDB(Request.Form[id_birthday]);
                }
                //string id_passportid = "ctl00$MainContent$txtTraveler" + c + "PassportNo";
                string id_idcard = "ctl00$MainContent$txtTraveler" + c + "IDCard";
                m_IDCardPolicyInsure = Request.Form[id_idcard];
                string id_tel = "ctl00$MainContent$txtTraveler" + c + "Tel";
                m_TelPolicyInsure = Request.Form[id_tel];
                string id_isStudent = "ctl00$MainContent$chkTraveler" + c + "Occupation";
                m_isStudentPolicyInsure = 0;
                if (!string.IsNullOrEmpty(Request.Form[id_isStudent]))
                {
                    m_isStudentPolicyInsure = 1; //on = true = selected
                }
                string id_isSingle = "ctl00$MainContent$chkTraveler" + c + "Status";
                m_isSinglePolicyInsure = 0;
                if (!string.IsNullOrEmpty(Request.Form[id_isSingle]))
                {
                    m_isSinglePolicyInsure = 1; //on = true = selected
                }

                //Calculte Child Premium

                decimal m_suminsured_discount = 1.00M;
                decimal m_premium_discount = 1.00M;

                if (m_InsuredIDPolicyInsure > 2)
                {
                    
                    try
                    {

                        //IF Child  17 years 
                        //then  discount 
                        dt1 = Convert.ToDateTime(m_BirthdayPolicyInsure);
                        ret = this.IsBirthDayOverLimitOfEffectiveDate(1, 17, dt1, dt2);
                        if (!ret)
                        {
                            m_suminsured_discount = 0.50M;
                            m_premium_discount = 0.850M;
                        }
                        else
                        {
                            
                            ret = this.IsBirthDayOverLimitOfEffectiveDate(18, 21, dt1, dt2);
                            bool m_isStudent_and_isSingle = false;
                            if (m_isStudentPolicyInsure == 1  && m_isSinglePolicyInsure == 1 )
                            {
                                m_isStudent_and_isSingle = true; //on = true = selected
                            }
                            //IF Child between 18 years and  21 years ,be student and single
                            // then discount
                            if (!ret && m_isStudent_and_isSingle)
                            {
                                m_suminsured_discount = 0.50M;
                                m_premium_discount = 0.850M;
                            }
                            else
                            {
                                m_suminsured_discount = 1.00M;
                                m_premium_discount = 1.00M;
                            }
                        }

                        m_SumInsuredPA2PolicyInsure = Convert.ToInt32(m_SumInsuredPA2PolicyInsure * Convert.ToDouble(m_suminsured_discount));
                        m_SumInsuredMEPolicyInsure = Convert.ToInt32(m_d_SumInsuredME * Convert.ToDouble( m_suminsured_discount));


                        m_PremiumPA2PolicyInsure = Convert.ToInt32(m_d_PremiumME * Convert.ToDouble(m_premium_discount));
                        m_PremiumMEPolicyInsure = Convert.ToInt32(m_d_PremiumPA2 * Convert.ToDouble(m_premium_discount));
                        
                        m_AddPremiumPolicyInsure = Convert.ToInt32(m_d_AddPremium * Convert.ToDouble(m_premium_discount));
                        
                      
                        //2013-04-03 เพิ่มการเช็ค ทศนิยมตั้งแต่ 0.75 ให้ปัดขึ้น
                        double n =   Math.Round((double)m_GrossPremiumPolicyInsure * Convert.ToDouble(m_premium_discount),2);
                        string s = string.Format("{0:0.00}", n); 

                        Int32 d = Int32.Parse(s.Substring(s.IndexOf(".") + 1));

                        if (d >= 75)
                        {
                            m_GrossPremiumPolicyInsure = Convert.ToInt32(Math.Floor((double)m_GrossPremiumPolicyInsure * Convert.ToDouble(m_premium_discount))) + 1;
                        }
                        else 
                        {
                            m_GrossPremiumPolicyInsure = Convert.ToInt32(Math.Floor((double)m_GrossPremiumPolicyInsure * Convert.ToDouble(m_premium_discount))) ;
                        }

                        //m_GrossPremiumPolicyInsure = Convert.ToInt32(Math.Round((double)m_GrossPremiumPolicyInsure * Convert.ToDouble(m_premium_discount)));

                        m_StampPolicyInsure = Convert.ToInt32((Math.Ceiling((double)m_GrossPremiumPolicyInsure * 0.004)));
                        m_SBTPolicyInsure = 0;//Convert.ToInt32((Math.Ceiling((double)m_GrossPremiumPolicyInsure * 0.0275)));

                        //else not discount
                        
                        m_TotalPremiumPolicyInsure = m_GrossPremiumPolicyInsure + m_StampPolicyInsure + m_SBTPolicyInsure;

                        //summary of all insured
                        m_sum_GrossPremiumPolicyInsure += Convert.ToInt32(m_GrossPremiumPolicyInsure);
                        m_sum_StampPolicyInsure += Convert.ToInt32(m_StampPolicyInsure);
                        m_sum_SBTPolicyInsure += Convert.ToInt32(m_SBTPolicyInsure);
                        m_sum_TotalPremiumPolicyInsure += Convert.ToInt32(m_TotalPremiumPolicyInsure);
                    }
                    catch (Exception ex)
                    {
                        this.lblErrorMessage.Text = "โปรแกรมเกิดข้อผิดพลาดในการคำนวณค่าเบี้ย สำหรับผู้เอาประกันภัย";
                        this.lblInformMessage.Text = "";
                        return;
                    }
                }
                

                //EXECUTE PROCEDURE
                PATransPolicyInsuredsBLL clsPATransPolicyInsuredsBLL = new PATransPolicyInsuredsBLL();
                //clsPATransPolicyInsuredsBLL.SetPATransPolicyInsureds(m_JobNo,1, "", "นาย", "ทดสอบ", "ทดสอบนามสกุล", "1989-08-28", "38418000XXXXX", "081", 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,0.50M,0.85M,1,1);            
                clsPATransPolicyInsuredsBLL.SetPATransPolicyInsureds(m_JobNo, m_InsuredIDPolicyInsure, m_ClientCodePolicyInsure, m_ClientTitlePolicyInsure, m_ClientNamePolicyInsure, m_ClientSurNamePolicyInsure, m_BirthdayPolicyInsure, m_IDCardPolicyInsure, m_TelPolicyInsure, m_SumInsuredPA2PolicyInsure, m_SumInsuredMEPolicyInsure, m_PremiumPA2PolicyInsure, m_PremiumMEPolicyInsure, m_AddPremiumPolicyInsure, m_GrossPremiumPolicyInsure, m_StampPolicyInsure, m_SBTPolicyInsure, m_TotalPremiumPolicyInsure, m_isBeneficiaryPolicyInsure, m_isStudentPolicyInsure, m_isSinglePolicyInsure, m_suminsured_discount,m_premium_discount,m_PackageID,m_PlanCode,m_OccupatnClass, dbTransaction);

                #region "#4-INSERT/UPDATE TRANSPOLICY BENEFICIARIES OF INSURE ONLY"
                for (int j = 1; j < 5; j++)
                {
                    //string m_JobNo = "";
                    //int m_TravelerID = c;
                    //int m_Seq = j;
                    string m_BeneficiaryTitle = "";
                    string m_BeneficiaryName = "";
                    string m_BeneficiarySurName = "";
                    string m_BeneficiaryRelation = "";
                    string m_BeneficiaryRatio = "";
                    string m_BeneficiaryTel = "";

                    string id_BeneficiaryTitle = "ctl00$MainContent$ddlTraveler" + c + "BeneficialyTitle" + j.ToString();
                    m_BeneficiaryTitle = Request.Form[id_BeneficiaryTitle];

                    string id_BeneficiaryName = "ctl00$MainContent$txtTraveler" + c + "BeneficialyName" + j.ToString();
                    m_BeneficiaryName = Request.Form[id_BeneficiaryName];

                    string id_BeneficiarySurName = "ctl00$MainContent$txtTraveler" + c + "BeneficialySurname" + j.ToString();
                    m_BeneficiarySurName = Request.Form[id_BeneficiarySurName];

                    string id_BeneficiaryRelation = "ctl00$MainContent$ddlTraveler" + c + "BeneficialyRelationShip" + j.ToString();
                    m_BeneficiaryRelation = Request.Form[id_BeneficiaryRelation];

                    string id_BeneficiaryRatio = "ctl00$MainContent$txtTraveler" + c + "BeneficialyRatio" + j.ToString();
                    m_BeneficiaryRatio = Request.Form[id_BeneficiaryRatio];

                    string id_BeneficiaryTel = "ctl00$MainContent$txtTraveler" + c + "BeneficialyTel" + j.ToString();
                    m_BeneficiaryTel = Request.Form[id_BeneficiaryTel];

                    string id_BeneficiaryHier = "ctl00$MainContent$chkTraveler" + c + "BeneficialyHeir";
                    string m_BeneficiaryHier = Request.Form[id_BeneficiaryHier];
                    if (m_BeneficiaryHier != "on")
                    {
                        if (!string.IsNullOrEmpty(m_BeneficiaryName) && !string.IsNullOrEmpty(m_BeneficiarySurName))
                        {
                            PATransBeneficiariesBLL clsPATransBeneficiariesBLL = new PATransBeneficiariesBLL();
                            //clsPATransBeneficiariesBLL.SetPATransBeneficiary(m_JobNo, 1, 1, "นาย", "สมมุติ", "นามสกุล", "พ่อ", "100", "021111999");
                            clsPATransBeneficiariesBLL.SetPATransBeneficiary(m_JobNo, c, j, m_BeneficiaryTitle, m_BeneficiaryName, m_BeneficiarySurName, m_BeneficiaryRelation, m_BeneficiaryRatio, m_BeneficiaryTel, dbTransaction);
                        }
                    }
                }
                #endregion

            }

            //--sum of TotalPremiumPolicyInsure of all Insured
            clsPATransPoliciesBLL.SetPATransPolicy(m_JobNo, m_PackageID, m_PlanCode, m_InceptionDate, m_ExpiryDate, m_AgentCode, m_StaffCode, m_OccupatnClass, m_OccupatnDestination, m_NoOfChildren, m_sum_GrossPremiumPolicyInsure, m_sum_StampPolicyInsure, m_sum_SBTPolicyInsure, m_sum_TotalPremiumPolicyInsure, m_isLongName, m_GroupBrokerID, m_User, m_Lang, dbTransaction);
           

            #endregion

            #region "#5-INSERT/UPDATE TRANSLONGNAME"
            if (m_temp != string.Empty)
            {
                PATransLongNamesBLL clsPATransLongNamesBLL = new PATransLongNamesBLL();
                //clsPATransLongNamesBLL.SetPATransLongName(m_JobNo, "L1", "L2", "L3", "L4");
                clsPATransLongNamesBLL.SetPATransLongName(m_JobNo, m_LongName1, m_LongName2, "", "", dbTransaction);
            }
            #endregion

            #region "COMMIT DB"
            //COMMIT DB
            //DbProviderHelper.CommitTransaction(dbTransaction);
            #endregion

            #region "CLOSE DB"
            //CLOSE DB
            DbProviderHelper.CloseDb();
            dbTransaction.Dispose();
            dbTransaction = null;

            #endregion

            #region "ISSUED TA POLICY"

            //Bind Job no
            this.lblJobnoValue.Text = m_JobNo;

            //Bind Message
            this.lblErrorMessage.Text = "";
            this.lblInformMessage.Text = "บันทึกข้อมูลลงฐานข้อมูลเรียบร้อย";

            #endregion

           
        }
        catch (Exception ex)
        {
            if (dbTransaction != null)
            {
                #region "ROLLBACK DB"
                //ROLLBACK DB
                DbProviderHelper.RollbackTransaction(dbTransaction);
                #endregion

                #region "CLOSE DB"
                //CLOSE DB
                DbProviderHelper.CloseDb();
                #endregion
            }
            this.lblErrorMessage.Text = ex.Message.ToString();
            this.lblInformMessage.Text = "";
        }
        if (this.lblJobnoValue.Text != "[Auto Generate]")
        {
            Response.Redirect("PAPolicy.aspx?jobno=" + this.lblJobnoValue.Text + "&mode=edit");
        }
    }

    void btnIssuePolicy_ServerClick(object sender, EventArgs e)
    {
        DbTransaction dbTransaction = null;

        string qry_mode = "";
        string qry_jobno = "";
        string m_JobNo = lblJobnoValue.Text;
        if (m_JobNo == "[Auto Generate]") { m_JobNo = string.Empty; qry_mode = ""; } else { qry_mode = "edit"; }
        string m_UserWeb = "";
        string m_AgentCode = "";
        string m_GroupBrokerID = "";
        string m_CreateUser = "";
        string ckEx = "";
        try
        {
            #region "GET USER HOST AND WEB"
             m_UserWeb = Utilities.GetUsername().Trim();
            #endregion

            #region "VALIDATE VARIABLE ISSUED POLICY"
            //-------------------------------------------------------------------------------------------------------------
            //BEGIN VARIABLE-TRANSPOLICY
            //BEGIN VALIDATE ITEMS
            string msg = "";
            bool flagmsg = false;
            this.ddlLanguage.CssClass = "";
            if (this.ddlLanguage.SelectedValue == "00")
            {
                msg += "Language |";
                flagmsg = true;
                this.ddlLanguage.CssClass = "inputFocusError";
            }
            this.txtEffectiveDateFrom.CssClass = "";
            if (this.txtEffectiveDateFrom.Text.Trim() == string.Empty)
            {
                msg += "Effective Date From |";
                flagmsg = true;
                this.txtEffectiveDateFrom.CssClass = "inputFocusError";
            }
            this.txtEffectiveDateTo.CssClass = "";
            if (this.txtEffectiveDateTo.Text.Trim() == string.Empty)
            {
                msg += "Effective Date To |";
                flagmsg = true;
                this.txtEffectiveDateTo.CssClass = "inputFocusError";
            }
            this.txtDateofBirth.CssClass = "";
            if (this.txtDateofBirth.Text.Trim() == string.Empty)
            {
                msg += "DOB |";
                flagmsg = true;
                this.txtDateofBirth.CssClass = "inputFocusError";
            }
            this.ddlPackage.CssClass = "";
            if (this.ddlPackage.SelectedValue.Trim() == "00" || this.ddlPackage.SelectedValue.Trim() == "")
            {
                msg += "Package |";
                flagmsg = true;
                this.ddlPackage.CssClass = "inputFocusError";
            }
            this.ddlInsurancePlan.CssClass = "";
            if (this.ddlInsurancePlan.SelectedValue.Trim() == "00" || this.ddlInsurancePlan.SelectedValue.Trim() == "")
            {
                msg += "Insurance Plan |";
                flagmsg = true;
                this.ddlInsurancePlan.CssClass = "inputFocusError";
            }
            this.txtOccupation.CssClass = "";

            this.ddlOccupationClass.CssClass = "";
            if (this.ddlOccupationClass.SelectedValue.Trim() == "0" || this.ddlOccupationClass.SelectedValue.Trim() == "")
            {
                msg += "Occupation Class |";
                flagmsg = true;
                this.ddlOccupationClass.CssClass = "inputFocusError";
            }
            if (flagmsg)
            {
                this.lblErrorMessage.Text = msg + " ห้ามเป็นค่าว่าง";
                this.lblInformMessage.Text = "";
                return;
            }
            //END VALIDATE ITEMS

         
            string m_PackageID = this.ddlPackage.SelectedValue.Trim();
            string m_PlanCode = this.ddlInsurancePlan.SelectedValue.Trim();
            string m_InceptionDate = this.txtEffectiveDateFrom.Text.Trim().Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtEffectiveDateFrom.Text.Trim());
            string m_ExpiryDate = this.txtEffectiveDateTo.Text.Trim().Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtEffectiveDateTo.Text.Trim()); ;
             m_AgentCode = Utilities.BrokerCode();
            string m_StaffCode = "";
            string m_OccupatnClass = this.GetOccupationClass(this.ddlOccupationClass.SelectedValue.Equals(string.Empty) ? 0 : Convert.ToInt32(this.ddlOccupationClass.SelectedValue.Trim()));
            string m_OccupatnDestination = this.ddlOccupationClass.SelectedItem.Text.Trim();
            Nullable<int> m_NoOfChildren = int.Parse(this.txtNumberOfChilden.Text.Trim());
            Nullable<int> m_GrossPremium = null;
            if (this.lblNetPremiumValue.Text.Trim() != string.Empty)
            {
                m_GrossPremium = (int)Utilities.ExactNumber(this.lblNetPremiumValue.Text.Trim());
            }
            Nullable<int> m_Stamp = null;
            if (this.lblStampDiutyValue.Text.Trim() != string.Empty)
            {
                m_Stamp = (int)Utilities.ExactNumber(this.lblStampDiutyValue.Text.Trim());
            }
            Nullable<int> m_SBT = null;
            if (this.lblTaxValue.Text.Trim() != string.Empty)
            {
                m_SBT = (int)Utilities.ExactNumber(this.lblTaxValue.Text.Trim());
            }
            Nullable<int> m_TotalPremium = null;
            if (this.lblTotlaPremiumValue.Text.Trim() != string.Empty)
            {
                m_TotalPremium = (int)Utilities.ExactNumber(this.lblTotlaPremiumValue.Text.Trim());
            }
            Nullable<SByte> m_isLongName = 0;
             m_GroupBrokerID = Utilities.GetGroupBrokerID();
            string m_User = m_UserWeb;
            string m_Lang = this.ddlLanguage.SelectedValue;     //Lang   
            string m_BranchNo = this.txtBranchNo.Value.Trim();
            //END VARIABLE-TRANSPOLICY


            //-------------------------------------------------------------------------------------------------------------
            //BEGIN VARIABLE-TRANSPOLICY HOLDER
            string policyholdertype = ""; //CHECK POLICY HOLDER TYPE
            foreach (ListItem item in rdoTaxInvoiceType.Items)
            {
                if (item.Selected == true)
                {
                    policyholdertype = item.Value.Trim();  //Private ,Commercial
                }
            }

            

            //BEGIN VALIDATE ITEMS
            msg = "";
            flagmsg = false;
            if (policyholdertype == "Private")
            {
                //Private
                this.ddlPolicyHolderTitle.Attributes["class"] = "";
                if (ddlPolicyHolderTitle.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlPolicyHolderTitle.SelectedItem.Text.Trim() == "Please Selected" || ddlPolicyHolderTitle.SelectedItem.Text.Trim() == "")
                {
                    msg += "Title |";
                    flagmsg = true;
                    this.ddlPolicyHolderTitle.Attributes["class"] = "inputFocusError";
                }


                this.txtPolicyHolderName.Attributes["class"] = "";
                if (txtPolicyHolderName.Value.Trim() == string.Empty)
                {
                    msg += "Name |";
                    flagmsg = true;
                    this.txtPolicyHolderName.Attributes["class"] = "inputFocusError";
                }
                this.txtPolicyHolderSurname.Attributes["class"] = "";
                if (txtPolicyHolderSurname.Value.Trim() == string.Empty)
                {
                    msg += "Family name |";
                    flagmsg = true;
                    this.txtPolicyHolderSurname.Attributes["class"] = "inputFocusError";
                }
                this.txtPolicyHolderBirthay.Attributes["class"] = "";
                if (txtPolicyHolderBirthay.Value.Trim() == string.Empty)
                {
                    msg += "Birthday |";
                    flagmsg = true;
                    this.txtPolicyHolderBirthay.Attributes["class"] = "inputFocusError";
                }
                this.txtPolicyHolderIDCard.CssClass = "";
                if (txtPolicyHolderIDCard.Text.Trim() == string.Empty)
                {
                    msg += "ID Card/ Tax ID |";
                    flagmsg = true;
                    this.txtPolicyHolderIDCard.CssClass = "inputFocusError";
                }
                this.txtPolicyHolderTel.Attributes["class"] = "";
                if (txtPolicyHolderTel.Value.Trim() == string.Empty)
                {
                    msg += "Tel |";
                    flagmsg = true;
                    this.txtPolicyHolderTel.Attributes["class"] = "inputFocusError";
                }
                this.txtPolicyHolderAddressNo.Attributes["class"] = "";
                if (txtPolicyHolderAddressNo.Value.Trim() == string.Empty)
                {
                    msg += "Address no. |";
                    flagmsg = true;
                    this.txtPolicyHolderAddressNo.Attributes["class"] = "inputFocusError";
                }
                this.ddlPolicyHolderProvince.Attributes["class"] = "";
                if (ddlPolicyHolderProvince.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlPolicyHolderProvince.SelectedItem.Text.Trim() == "Please Selected" || ddlPolicyHolderProvince.SelectedItem.Text.Trim() == "")
                {
                    msg += "Provine |";
                    flagmsg = true;
                    this.ddlPolicyHolderProvince.Attributes["class"] = "inputFocusError";
                }
                this.ddlPolicyHolderAmphure.Attributes["class"] = "";
                if (ddlPolicyHolderAmphure.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlPolicyHolderAmphure.SelectedItem.Text.Trim() == "Please Selected" || ddlPolicyHolderAmphure.SelectedItem.Text.Trim() == "")
                {
                    msg += "District |";
                    flagmsg = true;
                    this.ddlPolicyHolderAmphure.Attributes["class"] = "inputFocusError";
                }
                this.ddlPolicyHolderTumbon.Attributes["class"] = "";
                if (ddlPolicyHolderTumbon.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlPolicyHolderTumbon.SelectedItem.Text.Trim() == "Please Selected" || ddlPolicyHolderTumbon.SelectedItem.Text.Trim() == "")
                {
                    msg += "Sub District |";
                    flagmsg = true;
                    this.ddlPolicyHolderTumbon.Attributes["class"] = "inputFocusError";
                }
                this.txtPolicyHolderZipCode.Attributes["class"] = "";
                if (txtPolicyHolderZipCode.Value.Trim() == string.Empty)
                {
                    msg += "Zip Code  |";
                    flagmsg = true;
                    this.txtPolicyHolderZipCode.Attributes["class"] = "inputFocusError";
                }
                if (flagmsg)
                {
                    this.lblErrorMessage.Text = msg + " on Policy Holder ห้ามเป็นค่าว่าง";
                    this.lblInformMessage.Text = "";
                    return;
                }
                this.txtBranchNo.Value = "";
                m_BranchNo = "";
            }
            else //Commercial
            {
                this.txtPolicyHolderName.Attributes["class"] = "";
                if (txtPolicyHolderName.Value.Trim() == string.Empty)
                {
                    msg += "Name |";
                    flagmsg = true;
                    this.txtPolicyHolderName.Attributes["class"] = "inputFocusError";
                }

                this.txtPolicyHolderIDCard.Attributes["class"] = "";
                if (txtPolicyHolderIDCard.Text.Trim() == string.Empty)
                {
                    msg += "ID Card/ Corporate Tax ID |";
                    flagmsg = true;
                    this.txtPolicyHolderIDCard.CssClass = "inputFocusError";
                }
                this.txtPolicyHolderTel.Attributes["class"] = "";
                if (txtPolicyHolderTel.Value.Trim() == string.Empty)
                {
                    msg += "Tel |";
                    flagmsg = true;
                    this.txtPolicyHolderTel.Attributes["class"] = "inputFocusError";
                }
                this.txtPolicyHolderAddressNo.Attributes["class"] = "";
                if (txtPolicyHolderAddressNo.Value.Trim() == string.Empty)
                {
                    msg += "Address no. |";
                    flagmsg = true;
                    this.txtPolicyHolderAddressNo.Attributes["class"] = "inputFocusError";
                }
                this.ddlPolicyHolderProvince.Attributes["class"] = "";
                if (ddlPolicyHolderProvince.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlPolicyHolderProvince.SelectedItem.Text.Trim() == "Please Selected" || ddlPolicyHolderProvince.SelectedItem.Text.Trim() == "")
                {
                    msg += "Provine |";
                    flagmsg = true;
                    this.ddlPolicyHolderProvince.Attributes["class"] = "inputFocusError";
                }
                this.ddlPolicyHolderAmphure.Attributes["class"] = "";
                if (ddlPolicyHolderAmphure.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlPolicyHolderAmphure.SelectedItem.Text.Trim() == "Please Selected" || ddlPolicyHolderAmphure.SelectedItem.Text.Trim() == "")
                {
                    msg += "District |";
                    flagmsg = true;
                    this.ddlPolicyHolderAmphure.Attributes["class"] = "inputFocusError";
                }
                this.ddlPolicyHolderTumbon.Attributes["class"] = "";
                if (ddlPolicyHolderTumbon.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlPolicyHolderTumbon.SelectedItem.Text.Trim() == "Please Selected" || ddlPolicyHolderTumbon.SelectedItem.Text.Trim() == "")
                {
                    msg += "Sub District |";
                    flagmsg = true;
                    this.ddlPolicyHolderTumbon.Attributes["class"] = "inputFocusError";
                }
                this.txtPolicyHolderZipCode.Attributes["class"] = "";
                if (txtPolicyHolderZipCode.Value.Trim() == string.Empty)
                {
                    msg += "Zip Code  |";
                    flagmsg = true;
                    this.txtPolicyHolderZipCode.Attributes["class"] = "inputFocusError";
                }
                if (flagmsg)
                {
                    this.lblErrorMessage.Text = msg + " on Policy Holder ห้ามเป็นค่าว่าง";
                    this.lblInformMessage.Text = "";
                    return;
                }
            }
            //END VALIDATE ITEMS

            //string m_JobNo = "";
            int m_InsurerID = 1;
            string m_ClientType = policyholdertype == "Private" ? "P" : "C";
            string m_ClientTitle = this.ddlPolicyHolderTitle.SelectedValue.Trim();
            string m_ClientName = this.txtPolicyHolderName.Value.Trim();
            string m_ClientSurName = this.txtPolicyHolderSurname.Value.Trim();
            string m_AddressNo = this.txtPolicyHolderAddressNo.Value.Trim();
            string m_Building = this.txtPolicyHolderBuilding.Value.Trim();
            string m_Soi = this.txtPolicyHolderSoi.Value.Trim(); ;
            // Check If langauge is THAI && User Key something, repleace "ซอย" to empty and concat "ซอย" in front of them
            if (ddlLanguage.SelectedValue == "T" && !string.IsNullOrEmpty(m_Soi))
            {
                m_Soi = "ซอย" + m_Soi.Replace("ซอย", "").Trim();
            }
            // Check If langauge is THAI && User Key something, repleace "ถนน" to empty and concat "ถนน" in front of them
            string m_Road = this.txtPolicyHolderRoad.Value.Trim();
            if (ddlLanguage.SelectedValue == "T" && !string.IsNullOrEmpty(m_Road))
            {
                m_Road = "ถนน" + m_Road.Replace("ถนน", "").Trim();
            }
            //string m_Province = this.ddlPolicyHolderProvince.SelectedItem.Text.Trim();
            //string m_Amphur = this.ddlPolicyHolderAmphure.SelectedItem.Text.Trim();
            //string m_Tumbol = this.ddlPolicyHolderTumbon.SelectedItem.Text.Trim();

            string m_Province = this.ddlPolicyHolderProvince.SelectedItem.Text.Trim();
            if (ddlLanguage.SelectedValue == "T" && !string.IsNullOrEmpty(m_Province) && m_Province != "กรุงเทพมหานคร")
            {
                m_Province = "จังหวัด" + m_Province.Replace("จังหวัด", "").Trim();

            }
            string m_Amphur = this.ddlPolicyHolderAmphure.SelectedItem.Text.Trim();
            if (ddlLanguage.SelectedValue == "T" && !string.IsNullOrEmpty(m_Amphur) && m_Province != "กรุงเทพมหานคร")
            {
                m_Amphur = "อำเภอ" + m_Amphur.Replace("อำเภอ", "").Trim();

            }
            string m_Tumbol = this.ddlPolicyHolderTumbon.SelectedItem.Text.Trim();
            if (ddlLanguage.SelectedValue == "T" && !string.IsNullOrEmpty(m_Amphur) && m_Province != "กรุงเทพมหานคร")
            {
                m_Tumbol = "ตำบล" + m_Tumbol.Replace("ตำบล", "").Trim();

            }
            string m_PostCode = this.txtPolicyHolderZipCode.Value.Trim();
            string m_Birthday = this.txtPolicyHolderBirthay.Value.Trim().Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtPolicyHolderBirthay.Value.Trim());
            string m_Gender = this.ddlPolicyHolderGender.SelectedValue.Trim();
            string m_Status = this.ddlPolicyHolderMaritalStatus.SelectedValue.Trim();
            string m_Nationality = this.ddlPolicyHolderNationality.SelectedValue.Trim();
            string m_IDCard = this.txtPolicyHolderIDCard.Text.Trim();
            string m_Tel = this.txtPolicyHolderTel.Value.Trim();
            string m_Email = this.txtPolicyHolderEmail.Value.Trim();
            string m_LangPolicyHolder = this.ddlLanguage.SelectedValue;
            
            //END VARIABLE-TRANSPOLICY HOLDER


            //-------------------------------------------------------------------------------------------------------------
            //BEGIN VARIABLE-Insured
            PAPlanPackagesBLL clsplanpackage = new PAPlanPackagesBLL();
            PAPlanPackages getage = clsplanpackage.GetPAPlanPackages(m_PackageID);

            int m_AgeOfTravelerFrom = Convert.ToInt32(getage.AgeOfInsurerFrom);     //18
            int m_AgeOfTravelerTo = Convert.ToInt32(getage.AgeOfInsurerTo);         //68
            int m_AgeOfChildrenFrom = Convert.ToInt32(getage.AgeOfChildrenFrom);    //1
            int m_AgeOfChildrenTo = Convert.ToInt32(getage.AgeOfChildrenTo);        //17

            DateTime dt1 = new DateTime();
            DateTime dt2 = new DateTime();
            dt2 = Convert.ToDateTime(m_InceptionDate); //DEFAULT EFFECTTIVE DATE FROM
            bool ret = false;

            #region "Insured 1"
            string m_Traveler1ClientName = this.txtTraveler1Name.Value.Trim();
            string m_Traveler1ClientSurName = this.txtTraveler1Surname.Value.Trim();
            string m_Traveler1Birthday = this.txtDateofBirth.Text.Trim();
            string m_Traveler1IDCard = this.txtTraveler1IDCard.Value.Trim();
            string m_Traveler1Tel = this.txtTraveler1Tel.Value.Trim();
            bool chkTraveler1Hier = this.chkTraveler1BeneficialyHeir.Checked;

            msg = "";
            flagmsg = false;
            this.ddlTraveler1Title.Attributes["class"] = "";
            if (ddlTraveler1Title.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlTraveler1Title.SelectedItem.Text.Trim() == "Please Selected" || ddlTraveler1Title.SelectedItem.Text.Trim() == "")
            {
                msg += "Title |";
                flagmsg = true;
                this.ddlTraveler1Title.Attributes["class"] = "inputFocusError";
            }

            this.txtTraveler1Name.Attributes["class"] = "";
            if (m_Traveler1ClientName == string.Empty)
            {
                msg += "Name |";
                flagmsg = true;
                this.txtTraveler1Name.Attributes["class"] = "inputFocusError";
            }
            this.txtTraveler1Surname.Attributes["class"] = "";
            if (m_Traveler1ClientSurName == string.Empty)
            {
                msg += "Family name |";
                flagmsg = true;
                this.txtTraveler1Surname.Attributes["class"] = "inputFocusError";
            }
            this.txtTraveler1Birthday.Attributes["class"] = "";
            if (m_Traveler1Birthday == string.Empty)
            {
                msg += "Birthday |";
                flagmsg = true;
                this.txtTraveler1Birthday.Attributes["class"] = "inputFocusError";
            }
            this.txtTraveler1IDCard.Attributes["class"] = "";
            if (m_Traveler1IDCard == string.Empty)
            {
                msg += "ID Card |";
                flagmsg = true;
                this.txtTraveler1IDCard.Attributes["class"] = "inputFocusError";
            }
            this.txtTraveler1Tel.Attributes["class"] = "";
            if (m_Traveler1Tel == string.Empty)
            {
                msg += "Tel |";
                flagmsg = true;
                this.txtTraveler1Tel.Attributes["class"] = "inputFocusError";
            }
            //CHECK BENEFICIARY
            if (chkTraveler1Hier == false)
            {
                this.txtTraveler1BeneficialyName1.Attributes["class"] = "";
                this.txtTraveler1BeneficialySurname1.Attributes["class"] = "";
                if (string.IsNullOrEmpty(txtTraveler1BeneficialyName1.Value.Trim()) || string.IsNullOrEmpty(txtTraveler1BeneficialySurname1.Value.Trim()))
                {
                    msg += "Beneficiary Name and Family name | ";
                    flagmsg = true;
                    this.txtTraveler1BeneficialyName1.Attributes["class"] = "inputFocusError";
                    this.txtTraveler1BeneficialySurname1.Attributes["class"] = "inputFocusError";
                }
            }
            //END CHECK
            if (flagmsg)
            {
                this.lblErrorMessage.Text = msg + " on Insured 1 ห้ามเป็นค่าว่าง";
                this.lblInformMessage.Text = "";
                return;
            }

            //CHECK BIRTHDAY ON TRAVELER 1
            string m_traveler1_birthday = this.txtTraveler1Birthday.Value.Trim().Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtTraveler1Birthday.Value.Trim()); //30/05/2012 to 2012-05-30;
            if (!m_traveler1_birthday.Equals(string.Empty))
            {
                dt1 = Convert.ToDateTime(m_traveler1_birthday);
                ret = this.IsBirthDayOverLimitOfEffectiveDate(m_AgeOfTravelerFrom, m_AgeOfTravelerTo, dt1, dt2);
                if (ret)
                {
                    this.lblErrorMessage.Text = "กรุณาติดต่อ บริษัท เนื่องจากอายุผู้เอาประกันภัยเกิน " + m_AgeOfTravelerTo + "ปี / Please contact AXA helpdesk as age is over " + m_AgeOfTravelerTo + " on Insured 1";
                    this.lblInformMessage.Text = "";
                    return;
                }
            }
            else
            {
                this.lblErrorMessage.Text = "Birthday on Insured 1 | ห้ามเป็นค่าว่าง";
                this.lblInformMessage.Text = "";
                return;
            }

            //VALIDATE RATIO IS 100 ON TRAVELER1
            int traveler1Ratio1 = 0;
            int traveler1Ratio2 = 0;
            int traveler1Ratio3 = 0;
            int traveler1Ratio4 = 0;

            if (chkTraveler1Hier == false)
            {
                if (!string.IsNullOrEmpty(txtTraveler1BeneficialyName1.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler1BeneficialySurname1.Value.Trim()))
                {
                    traveler1Ratio1 = txtTraveler1BeneficialyRatio1.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler1BeneficialyRatio1.Value.Trim());
                }

                if (!string.IsNullOrEmpty(txtTraveler1BeneficialyName2.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler1BeneficialySurname2.Value.Trim()))
                {
                    traveler1Ratio2 = txtTraveler1BeneficialyRatio2.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler1BeneficialyRatio2.Value.Trim());
                }

                if (!string.IsNullOrEmpty(txtTraveler1BeneficialyName3.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler1BeneficialySurname3.Value.Trim()))
                {
                    traveler1Ratio3 = txtTraveler1BeneficialyRatio3.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler1BeneficialyRatio3.Value.Trim());
                }

                if (!string.IsNullOrEmpty(txtTraveler1BeneficialyName4.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler1BeneficialySurname4.Value.Trim()))
                {
                    traveler1Ratio4 = txtTraveler1BeneficialyRatio4.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler1BeneficialyRatio4.Value.Trim());
                }
                if (traveler1Ratio1 + traveler1Ratio2 + traveler1Ratio3 + traveler1Ratio4 != 100)
                {
                    this.lblErrorMessage.Text = "Sum of Beneficiary Ratio on Insured1 Must be 100!!! ";
                    this.lblInformMessage.Text = "";
                    return;
                }
            }
            #endregion
            #region "TRAVELER 2,ANOTHER"
            if (ddlPackage.SelectedValue == "0004") //Family
            {
                #region "TRAVELERR 2"
                //CHECK TRAVELERR 2
                string m_Traveler2ClientName = this.txtTraveler2Name.Value.Trim();
                string m_Traveler2ClientSurName = this.txtTraveler2Surname.Value.Trim();
                string m_Traveler2Birthday = this.txtTraveler2Birthday.Value.Trim();
                string m_Traveler2IDCard = this.txtTraveler2IDCard.Value.Trim();
                string m_Traveler2Tel = this.txtTraveler2Tel.Value.Trim();
                bool chkTraveler2Hier = this.chkTraveler2BeneficialyHeir.Checked;

                msg = "";
                flagmsg = false;
                this.ddlTraveler2Title.Attributes["class"] = "";
                if (ddlTraveler2Title.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlTraveler2Title.SelectedItem.Text.Trim() == "Please Selected" || ddlTraveler2Title.SelectedItem.Text.Trim() == "")
                {
                    msg += "Title |";
                    flagmsg = true;
                    this.ddlTraveler2Title.Attributes["class"] = "inputFocusError";
                }
                this.txtTraveler2Name.Attributes["class"] = "";
                if (m_Traveler2ClientName == string.Empty)
                {
                    msg += "Name |";
                    flagmsg = true;
                    this.txtTraveler2Name.Attributes["class"] = "inputFocusError";
                }
                this.txtTraveler2Surname.Attributes["class"] = "";
                if (m_Traveler2ClientSurName == string.Empty)
                {
                    msg += "Family name |";
                    flagmsg = true;
                    this.txtTraveler2Surname.Attributes["class"] = "inputFocusError";
                }
                this.txtTraveler2Birthday.Attributes["class"] = "";
                if (m_Traveler2Birthday == string.Empty)
                {
                    msg += "Birthday |";
                    flagmsg = true;
                    this.txtTraveler2Birthday.Attributes["class"] = "inputFocusError";
                }
                this.txtTraveler2IDCard.Attributes["class"] = "";
                if (m_Traveler2IDCard == string.Empty)
                {
                    msg += "Passport No |";
                    flagmsg = true;
                    this.txtTraveler2IDCard.Attributes["class"] = "inputFocusError";
                }
                this.txtTraveler2Tel.Attributes["class"] = "";
                if (m_Traveler2Tel == string.Empty)
                {
                    msg += "Tel |";
                    flagmsg = true;
                    this.txtTraveler2Tel.Attributes["class"] = "inputFocusError";
                }
                //CHECK BENEFICIARY
                if (chkTraveler2Hier == false)
                {
                    this.txtTraveler2BeneficialyName1.Attributes["class"] = "";
                    this.txtTraveler2BeneficialySurname1.Attributes["class"] = "";
                    if (string.IsNullOrEmpty(txtTraveler2BeneficialyName1.Value.Trim()) || string.IsNullOrEmpty(txtTraveler2BeneficialySurname1.Value.Trim()))
                    {
                        msg += "Beneficiary Name and Family name | ";
                        flagmsg = true;
                        this.txtTraveler2BeneficialyName1.Attributes["class"] = "inputFocusError";
                        this.txtTraveler2BeneficialySurname1.Attributes["class"] = "inputFocusError";
                    }
                }
                //END CHECK
                if (flagmsg)
                {
                    this.lblErrorMessage.Text = msg + " on Insured 2 ห้ามเป็นค่าว่าง";
                    this.lblInformMessage.Text = "";
                    return;
                }

                //CHECK BIRTHDAY ON Insured 2
                string m_traveler2_birthday = this.txtTraveler2Birthday.Value.Trim().Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtTraveler2Birthday.Value.Trim()); //30/05/2012 to 2012-05-30;
                if (!m_traveler2_birthday.Equals(string.Empty))
                {
                    dt1 = Convert.ToDateTime(m_traveler2_birthday);
                    ret = this.IsBirthDayOverLimitOfEffectiveDate(m_AgeOfTravelerFrom, m_AgeOfTravelerTo, dt1, dt2);
                    if (ret)
                    {
                        this.lblErrorMessage.Text = "กรุณาติดต่อ บริษัท เนื่องจากอายุผู้เอาประกันภัยเกิน " + m_AgeOfTravelerTo + "ปี / Please contact AXA helpdesk as age is over " + m_AgeOfTravelerTo + " on Insured 2";
                        this.lblInformMessage.Text = "";
                        return;
                    }
                }
                else
                {
                    this.lblErrorMessage.Text = "Birthday on Insured 2 | ห้ามเป็นค่าว่าง";
                    this.lblInformMessage.Text = "";
                    return;
                }

                //VALIDATE RATIO IS 100 ON TRAVELER1
                int traveler2Ratio1 = 0;
                int traveler2Ratio2 = 0;
                int traveler2Ratio3 = 0;
                int traveler2Ratio4 = 0;

                if (chkTraveler2Hier == false)
                {
                    if (!string.IsNullOrEmpty(txtTraveler2BeneficialyName1.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler2BeneficialySurname1.Value.Trim()))
                    {
                        traveler2Ratio1 = txtTraveler2BeneficialyRatio1.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler2BeneficialyRatio1.Value.Trim());
                    }

                    if (!string.IsNullOrEmpty(txtTraveler2BeneficialyName2.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler2BeneficialySurname2.Value.Trim()))
                    {
                        traveler2Ratio2 = txtTraveler2BeneficialyRatio2.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler2BeneficialyRatio2.Value.Trim());
                    }

                    if (!string.IsNullOrEmpty(txtTraveler2BeneficialyName3.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler2BeneficialySurname3.Value.Trim()))
                    {
                        traveler2Ratio3 = txtTraveler2BeneficialyRatio3.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler2BeneficialyRatio3.Value.Trim());
                    }

                    if (!string.IsNullOrEmpty(txtTraveler2BeneficialyName4.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler2BeneficialySurname4.Value.Trim()))
                    {
                        traveler2Ratio4 = txtTraveler2BeneficialyRatio4.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler2BeneficialyRatio4.Value.Trim());
                    }

                    if (traveler2Ratio1 + traveler2Ratio2 + traveler2Ratio3 + traveler2Ratio4 != 100)
                    {
                        this.lblErrorMessage.Text = "Sum of Beneficiary Ratio on Insured2 Must be 100!!! ";
                        this.lblInformMessage.Text = "";
                        return;
                    }
                }
                #endregion
                #region "TRAVELER ANOTHER"
                //CHECK CHILD (1,2) 
                int m_allpeople = (int)m_NoOfChildren + 2;
                if (m_allpeople > 2)
                {
                    //CHECK CHILD 
                    for (int ch = 3; ch <= m_allpeople; ch++)
                    {

                        //CHECK EMPTY ON TRAVELER 3 UP -----
                        string id_ddltraveltitle = "ctl00$MainContent$ddlTraveler" + ch + "Title";  //ctl00$MainContent$ddlTraveler3Title
                        string m_TravelTitle = Request.Form[id_ddltraveltitle].Trim();
                        string id_clientname = "ctl00$MainContent$txtTraveler" + ch + "Name";
                        string m_TravelerChildClientName = Request.Form[id_clientname].Trim();
                        string id_clientsurname = "ctl00$MainContent$txtTraveler" + ch + "SurName";
                        string m_TravelerChildClientSurName = Request.Form[id_clientsurname].Trim();
                        string id_birthday = "ctl00$MainContent$txtTraveler" + ch + "Birthday";
                        string m_TravelerChildBirthday = Request.Form[id_birthday].Trim();
                        string id_idcard = "ctl00$MainContent$txtTraveler" + ch + "IDCard";
                        string m_TravelerChildIDCard = Request.Form[id_idcard];
                        string id_tel = "ctl00$MainContent$txtTraveler" + ch + "Tel";
                        string m_TravelerChildTel = Request.Form[id_tel];

                        msg = "";
                        flagmsg = false;

                        if (m_TravelTitle == "โปรดเลือก" || m_TravelTitle == "Please Selected" || m_TravelTitle == "" || m_TravelTitle == "00")
                        {
                            msg += "Title |";
                            flagmsg = true;
                        }

                        if (m_TravelerChildClientName == string.Empty)
                        {
                            msg += "Name |";
                            flagmsg = true;
                        }
                        if (m_TravelerChildClientSurName == string.Empty)
                        {
                            msg += "Family name |";
                            flagmsg = true;
                        }
                        if (m_TravelerChildBirthday == string.Empty)
                        {
                            msg += "Birthday |";
                            flagmsg = true;
                        }
                        if (m_TravelerChildIDCard == string.Empty)
                        {
                            msg += "ID Card |";
                            flagmsg = true;
                        }
                        if (m_TravelerChildTel == string.Empty)
                        {
                            msg += "Tel |";
                            flagmsg = true;
                        }

                        //CHECK BENEFICIARY
                        string m_BeneficiaryName = "";
                        string m_BeneficiarySurName = "";
                        string id_BeneficiaryName = "ctl00$MainContent$txtTraveler" + ch + "BeneficialyName1";
                        m_BeneficiaryName = Request.Form[id_BeneficiaryName];
                        string id_BeneficiarySurName = "ctl00$MainContent$txtTraveler" + ch + "BeneficialySurname1";
                        m_BeneficiarySurName = Request.Form[id_BeneficiarySurName];
                        string id_BeneficiaryHier = "ctl00$MainContent$chkTraveler" + ch + "BeneficialyHeir";
                        string m_BeneficiaryHier = Request.Form[id_BeneficiaryHier];
                        if (m_BeneficiaryHier != "on")
                        {
                            if (string.IsNullOrEmpty(m_BeneficiaryName) && string.IsNullOrEmpty(m_BeneficiarySurName))
                            {
                                msg += "Name and Family name |";
                                flagmsg = true;
                            }
                        }

                        if (flagmsg)
                        {
                            msg += " on Insured " + ch + " ห้ามเป็นค่าว่าง";
                            break;
                        }

                        //CHECK BIRTHDAY ON Insured 3 UP -----
                        msg = "";
                        flagmsg = false;
                        /*if (!string.IsNullOrEmpty(Request.Form[id_birthday]))
                        {
                            string m_travelerchild_birthday = TA.TAUtilities.ConvertDateFieldToDB(Request.Form[id_birthday]);
                            dt1 = Convert.ToDateTime(m_travelerchild_birthday);
                            ret = this.IsBirthDayOverLimitOfEffectiveDate(1, 21, dt1, dt2);
                            if (ret)
                            {
                                msg += "Insured " + ch + " Birthday ไม่อยู่ในช่วง 1-21 ปี นับจากวันที่คุ้มครอง| <br>";
                                flagmsg = true;
                                break;
                            }
                            else
                            {
                                //1-23
                                dt1 = Convert.ToDateTime(m_travelerchild_birthday);
                                ret = this.IsBirthDayOverLimitOfEffectiveDate(m_AgeOfChildrenFrom, m_AgeOfChildrenTo, dt1, dt2); //1-17
                                if (ret)
                                {
                                    string id_isStudent = "ctl00$MainContent$chkTraveler" + ch + "Occupation";
                                    int m_isStudent = 0;
                                    if (!string.IsNullOrEmpty(Request.Form[id_isStudent]))
                                    {
                                        m_isStudent = 1; //on = true = selected
                                    }
                                    string id_isSingle = "ctl00$MainContent$chkTraveler" + ch + "Status";
                                    int m_isSingle = 0;
                                    if (!string.IsNullOrEmpty(Request.Form[id_isSingle]))
                                    {
                                    }
                                    if (m_isStudent == 0 || m_isSingle == 0)
                                    {
                                        msg += "Insured " + ch + " Birthday ไม่อยู่ในช่วง " + m_AgeOfChildrenFrom + "-" + m_AgeOfChildrenTo + " ปี นับจากวันที่คุ้มครองไม่เป็นนักศึกษาและสถานะภาพไม่โสด | <br>";
                                        flagmsg = true;
                                        break;
                                    }
                                }
                            }
                        }*/
                        //VALIDATE RATIO IS 100 ON TRAVELER1
                        int travelerxRatio = 0;

                        for (int j = 1; j < 5; j++)
                        {

                            string msub_BeneficiaryName = "";
                            string msub_BeneficiarySurName = "";
                            string msub_BeneficiaryRatio = "";

                            string idsub_BeneficiaryName = "ctl00$MainContent$txtTraveler" + ch + "BeneficialyName" + j.ToString();
                            msub_BeneficiaryName = Request.Form[idsub_BeneficiaryName];

                            string idsub_BeneficiarySurName = "ctl00$MainContent$txtTraveler" + ch + "BeneficialySurname" + j.ToString();
                            msub_BeneficiarySurName = Request.Form[idsub_BeneficiarySurName];

                            string idsub_BeneficiaryRatio = "ctl00$MainContent$txtTraveler" + ch + "BeneficialyRatio" + j.ToString();
                            msub_BeneficiaryRatio = Request.Form[idsub_BeneficiaryRatio];

                            if (m_BeneficiaryHier == "on")
                            {

                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(msub_BeneficiaryName) && !string.IsNullOrEmpty(msub_BeneficiarySurName))
                                {
                                    travelerxRatio += msub_BeneficiaryRatio.Equals(string.Empty) ? 0 : Convert.ToInt32(msub_BeneficiaryRatio.Trim());
                                }
                            }
                        }
                        if (travelerxRatio != 100 && m_BeneficiaryHier != "on")
                        {
                            this.lblErrorMessage.Text = "Sum of Beneficiary Ratio on Insured " + ch + " Must be 100!!! ";
                            this.lblInformMessage.Text = "";
                            return;
                        }
                    }
                    if (flagmsg)
                    {
                        this.lblErrorMessage.Text = msg;
                        this.lblInformMessage.Text = "";
                        return;
                    }
                }

                #endregion
            }
            #endregion

            //END VARIABLE-TRAVELER



            //-------------------------------------------------------------------------------------------------------------
            //BEGIN VARIABLE-LONGNAME
            //string m_JobNo = "";
            string m_LongName1 = this.txtLongName1.Value.Trim();
            string m_LongName2 = this.txtLongName2.Value.Trim();
            string m_temp = string.Concat(m_LongName1, m_LongName2);
            if (m_temp != string.Empty)
            {
                m_isLongName = 1;
            }
            //END VARIABLE-LONGNAME


            //-------------------------------------------------------------------------------------------------------------
            //BEGIN VARIABLE-PLAN PREMIUM
            PAPlanPremiumsBLL clsPAPlanPremiumsBLL = new PAPlanPremiumsBLL();
            DataTable dt = clsPAPlanPremiumsBLL.GetDtPAPlanPremiums(m_PlanCode, m_OccupatnClass);
            double m_d_SumInsuredPA2 = double.Parse(dt.Rows[0]["SumInsuredPA2"].ToString().Trim());
            double m_d_SumInsuredME = double.Parse(dt.Rows[0]["SumInsuredME"].ToString().Trim());
            double m_d_PremiumPA2 = double.Parse(dt.Rows[0]["PremiumPA2"].ToString().Trim());
            double m_d_PremiumME = double.Parse(dt.Rows[0]["PremiumME"].ToString().Trim());
            double m_d_AddPremium = double.Parse(dt.Rows[0]["AddPremium"].ToString().Trim());
            double m_d_netpremium = double.Parse(dt.Rows[0]["GrossPremium"].ToString().Trim());
            double m_d_tax = double.Parse(dt.Rows[0]["SBT"].ToString().Trim());
            double m_d_stamp = double.Parse(dt.Rows[0]["Stamp"].ToString().Trim());
            double m_d_total = double.Parse(dt.Rows[0]["TotalPremium"].ToString().Trim());
            //END VARIABLE-PLAN PREMIUM


            //-------------------------------------------------------------------------------------------------------------

            #endregion

            #region "GET/SET JOB NUMBER (NOW NONE TRANSACTION)"
            PAJobRunningBLL clsPAJobRunningBLL = new PAJobRunningBLL();
            if (string.Compare(qry_mode.Trim(), "edit") == 0)
            {
                qry_mode = Request.QueryString["mode"];
                qry_jobno = Request.QueryString["JobNo"];
            }
            if (!string.IsNullOrEmpty(qry_mode) && !string.IsNullOrEmpty(qry_jobno))
            {
                if (string.Compare(qry_mode.Trim(), "edit") == 0)
                {
                    m_JobNo = qry_jobno.Trim();
                }
                else
                {
                    m_JobNo = clsPAJobRunningBLL.GetPAJobRunningNumber();

                    if (string.IsNullOrEmpty(m_JobNo))
                    {
                        throw new Exception("เกิดข้อผิดพลาดในการสร้างหมายเลข Job Number กรุณาทดลองบันทึกงานอีกครั้งหรือติดต่อผู้ดูแลระบบ");
                    }
                }
            }
            else
            {
                m_JobNo = clsPAJobRunningBLL.GetPAJobRunningNumber();

                if (string.IsNullOrEmpty(m_JobNo))
                {
                    throw new Exception("เกิดข้อผิดพลาดในการสร้างหมายเลข Job Number กรุณาทดลองบันทึกงานอีกครั้งหรือติดต่อผู้ดูแลระบบ");
                }
            }

            lblJobnoValue.Text = m_JobNo;
            #endregion
            
            #region "OPEN DB"
            //OPEN DB
            DbProviderHelper.OpenDb();
            #endregion

            #region "OPEN TRANSACTION"
            //TRANSACTION BEGIN
            dbTransaction = DbProviderHelper.BeginTransaction();
            #endregion

            #region "#1-INSERT/UPDATE TRANSPOLICY"
            //Create TransPolicy
            PATransPoliciesBLL clsPATransPoliciesBLL = new PATransPoliciesBLL();
            //clsPATransPoliciesBLL.SetPATransPolicy(m_JobNo, "0003", "1A", "2012-08-30", "2013-08-30", "BR002", "AJ", "01", "Programer", 0, 890, 7, 20, 1000, 0, "G0001", "Nam", "T");
            clsPATransPoliciesBLL.SetPATransPolicy(m_JobNo, m_PackageID, m_PlanCode, m_InceptionDate, m_ExpiryDate, m_AgentCode, m_StaffCode, m_OccupatnClass, m_OccupatnDestination, m_NoOfChildren, m_GrossPremium, m_Stamp, m_SBT, m_TotalPremium, m_isLongName, m_GroupBrokerID, m_User, m_Lang, dbTransaction);
            #endregion

            #region "#2-INSERT/UPDATE TRANSPOLICYHOLDER"
            PATransPolicyHoldersBLL clsPATransPolicyHoldersBLL = new PATransPolicyHoldersBLL();
            //clsPATransPolicyHoldersBLL.SetPATransPolicyHolders(m_JobNo, 1, "P", "นาย", "ลอง", "ลองนามสกุล", "1/1", "อาคาร", "ซอย", "ถนน", "กรุงเทพมหานคร", "หลักสี่", "ตำบล", "10240", "1989-08-28", "F", "Z", "", "38418000XXXXX", "081", "Test@hotmail.com", "T");
            clsPATransPolicyHoldersBLL.SetPATransPolicyHolders(m_JobNo, m_InsurerID, m_ClientType, m_ClientTitle, m_ClientName, m_ClientSurName, m_AddressNo, m_Building, m_Soi, m_Road, m_Province, m_Amphur, m_Tumbol, m_PostCode, m_Birthday, m_Gender, m_Status, m_Nationality, m_IDCard, m_Tel, m_Email, m_LangPolicyHolder, m_BranchNo, dbTransaction);
            #endregion

            #region "#3,4-INSERT/UPDATE TRANSPOLICY INSURE"

            int numberofchid = int.Parse(this.txtNumberOfChilden.Text.Trim());
            if (numberofchid == 0)
            {
                if (ddlPackage.SelectedValue != "0004") // 0004 = Family
                {
                    numberofchid = -1; // Set for != Family
                }
            }
            int m_sum_TotalPremiumPolicyInsure = 0;
            int m_sum_SBTPolicyInsure = 0;
            int m_sum_StampPolicyInsure = 0;
            int m_sum_GrossPremiumPolicyInsure = 0;

            for (int c = 1; c <= (numberofchid + 2); c++)
            {
                //-------------------------------------------------------------------------------------------------------------
                //BEGIN VARIABLE-TRANSPOLICY INSURE
                //string  m_JobNo = "";
                int m_InsuredIDPolicyInsure = c;
                string m_ClientCodePolicyInsure = "";
                string m_ClientTitlePolicyInsure = this.ddlTraveler1Title.SelectedItem.Text.Trim();
                string m_ClientNamePolicyInsure = this.txtTraveler1Name.Value.Trim();
                string m_ClientSurNamePolicyInsure = this.txtTraveler1Surname.Value.Trim();
                string m_BirthdayPolicyInsure = this.txtDateofBirth.Text.Trim().Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtDateofBirth.Text.Trim());
                string m_IDCardPolicyInsure = this.txtTraveler1IDCard.Value.Trim();
                string m_TelPolicyInsure = this.txtTraveler1Tel.Value.Trim();
                Nullable<int> m_SumInsuredPA2PolicyInsure = (int)m_d_SumInsuredPA2;
                Nullable<int> m_SumInsuredMEPolicyInsure = (int)m_d_SumInsuredME;
                Nullable<int> m_PremiumPA2PolicyInsure = (int)m_d_PremiumME;
                Nullable<int> m_PremiumMEPolicyInsure = (int)m_d_PremiumPA2;
                Nullable<int> m_AddPremiumPolicyInsure = (int)m_d_AddPremium;
                Nullable<int> m_GrossPremiumPolicyInsure = (int)m_d_netpremium;
                Nullable<int> m_StampPolicyInsure = (int)m_d_stamp;
                Nullable<int> m_SBTPolicyInsure = (int)m_d_tax;
                Nullable<int> m_TotalPremiumPolicyInsure = (int)m_d_total;
                Nullable<SByte> m_isBeneficiaryPolicyInsure = 0;
                Nullable<SByte> m_isStudentPolicyInsure = 0;
                Nullable<SByte> m_isSinglePolicyInsure = 0;
                //END VARIABLE-TRANSPOLICY INSURE
                //-------------------------------------------------------------------------------------------------------------
                // if parent calucate here
                if (m_InsuredIDPolicyInsure < 3)
                {
                    m_sum_GrossPremiumPolicyInsure += Convert.ToInt32(m_GrossPremiumPolicyInsure);
                    m_sum_StampPolicyInsure += Convert.ToInt32(m_StampPolicyInsure);
                    m_sum_SBTPolicyInsure += Convert.ToInt32(m_SBTPolicyInsure);
                    m_sum_TotalPremiumPolicyInsure += Convert.ToInt32(m_TotalPremiumPolicyInsure);
                }

                string id_title = "ctl00$MainContent$ddlTraveler" + c + "Title";                //ctl00$MainContent$ddlTraveler1Title
                m_ClientTitlePolicyInsure = Request.Form[id_title];                             //Values
                string id_clientname = "ctl00$MainContent$txtTraveler" + c + "Name";
                m_ClientNamePolicyInsure = Request.Form[id_clientname];
                string id_clientsurname = "ctl00$MainContent$txtTraveler" + c + "SurName";
                m_ClientSurNamePolicyInsure = Request.Form[id_clientsurname];
                string id_birthday = "ctl00$MainContent$txtTraveler" + c + "Birthday";
                m_BirthdayPolicyInsure = "";
                if (!string.IsNullOrEmpty(Request.Form[id_birthday]))
                {
                    m_BirthdayPolicyInsure = TA.TAUtilities.ConvertDateFieldToDB(Request.Form[id_birthday]);
                }
                //string id_passportid = "ctl00$MainContent$txtTraveler" + c + "PassportNo";
                string id_idcard = "ctl00$MainContent$txtTraveler" + c + "IDCard";
                m_IDCardPolicyInsure = Request.Form[id_idcard];
                string id_tel = "ctl00$MainContent$txtTraveler" + c + "Tel";
                m_TelPolicyInsure = Request.Form[id_tel];
                string id_isStudent = "ctl00$MainContent$chkTraveler" + c + "Occupation";
                m_isStudentPolicyInsure = 0;
                if (!string.IsNullOrEmpty(Request.Form[id_isStudent]))
                {
                    m_isStudentPolicyInsure = 1; //on = true = selected
                }
                string id_isSingle = "ctl00$MainContent$chkTraveler" + c + "Status";
                m_isSinglePolicyInsure = 0;
                if (!string.IsNullOrEmpty(Request.Form[id_isSingle]))
                {
                    m_isSinglePolicyInsure = 1; //on = true = selected
                }

                //Calculte Child Premium

                decimal m_suminsured_discount = 1.00M;
                decimal m_premium_discount = 1.00M;

                if (m_InsuredIDPolicyInsure > 2)
                {

                    try
                    {

                        //IF Child  17 years 
                        //then  discount 
                        dt1 = Convert.ToDateTime(m_BirthdayPolicyInsure);
                        ret = this.IsBirthDayOverLimitOfEffectiveDate(1, 17, dt1, dt2);
                        if (!ret)
                        {
                            m_suminsured_discount = 0.50M;
                            m_premium_discount = 0.850M;
                        }
                        else
                        {

                            ret = this.IsBirthDayOverLimitOfEffectiveDate(18, 21, dt1, dt2);
                            bool m_isStudent_and_isSingle = false;
                            if (m_isStudentPolicyInsure == 1 && m_isSinglePolicyInsure == 1)
                            {
                                m_isStudent_and_isSingle = true; //on = true = selected
                            }
                            //IF Child between 18 years and  21 years ,be student and single
                            // then discount
                            if (!ret && m_isStudent_and_isSingle)
                            {
                                m_suminsured_discount = 0.50M;
                                m_premium_discount = 0.850M;
                            }
                            else
                            {
                                m_suminsured_discount = 1.00M;
                                m_premium_discount = 1.00M;
                            }
                        }

                        m_SumInsuredPA2PolicyInsure = Convert.ToInt32(m_SumInsuredPA2PolicyInsure * Convert.ToDouble(m_suminsured_discount));
                        m_SumInsuredMEPolicyInsure = Convert.ToInt32(m_d_SumInsuredME * Convert.ToDouble(m_suminsured_discount));


                        m_PremiumPA2PolicyInsure = Convert.ToInt32(m_d_PremiumME * Convert.ToDouble(m_premium_discount));
                        m_PremiumMEPolicyInsure = Convert.ToInt32(m_d_PremiumPA2 * Convert.ToDouble(m_premium_discount));
                        m_AddPremiumPolicyInsure = Convert.ToInt32(m_d_AddPremium * Convert.ToDouble(m_premium_discount));

                        //2013-04-03 เพิ่มการเช็ค ทศนิยมตั้งแต่ 0.75 ให้ปัดขึ้น
                        double n = Math.Round((double)m_GrossPremiumPolicyInsure * Convert.ToDouble(m_premium_discount), 2);
                        string s = string.Format("{0:0.00}", n); 
                        Int32 d = Int32.Parse(s.Substring(s.IndexOf(".") + 1));
                        if (d >= 75)
                        {
                            m_GrossPremiumPolicyInsure = Convert.ToInt32(Math.Floor((double)m_GrossPremiumPolicyInsure * Convert.ToDouble(m_premium_discount))) + 1;
                        }
                        else
                        {
                            m_GrossPremiumPolicyInsure = Convert.ToInt32(Math.Floor((double)m_GrossPremiumPolicyInsure * Convert.ToDouble(m_premium_discount)));
                        }
                        //m_GrossPremiumPolicyInsure = Convert.ToInt32(Math.Round((double)m_GrossPremiumPolicyInsure * Convert.ToDouble(m_premium_discount)));

                        m_StampPolicyInsure = Convert.ToInt32((Math.Ceiling((double)m_GrossPremiumPolicyInsure * 0.004)));
                        m_SBTPolicyInsure = 0;//Convert.ToInt32((Math.Ceiling((double)m_GrossPremiumPolicyInsure * 0.0275)));

                        //else not discount

                        m_TotalPremiumPolicyInsure = m_GrossPremiumPolicyInsure + m_StampPolicyInsure + m_SBTPolicyInsure;

                        //summary of all insured
                        m_sum_GrossPremiumPolicyInsure += Convert.ToInt32(m_GrossPremiumPolicyInsure);
                        m_sum_StampPolicyInsure += Convert.ToInt32(m_StampPolicyInsure);
                        m_sum_SBTPolicyInsure += Convert.ToInt32(m_SBTPolicyInsure);
                        m_sum_TotalPremiumPolicyInsure += Convert.ToInt32(m_TotalPremiumPolicyInsure);
                    }
                    catch (Exception ex)
                    {
                        this.lblErrorMessage.Text = "โปรแกรมเกิดข้อผิดพลาดในการคำนวณค่าเบี้ย สำหรับผู้เอาประกันภัย";
                        this.lblInformMessage.Text = "";
                        return;
                    }
                }


                //EXECUTE PROCEDURE
                PATransPolicyInsuredsBLL clsPATransPolicyInsuredsBLL = new PATransPolicyInsuredsBLL();
                //clsPATransPolicyInsuredsBLL.SetPATransPolicyInsureds(m_JobNo,1, "", "นาย", "ทดสอบ", "ทดสอบนามสกุล", "1989-08-28", "38418000XXXXX", "081", 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,0.50M,0.85M,1,1);            
                clsPATransPolicyInsuredsBLL.SetPATransPolicyInsureds(m_JobNo, m_InsuredIDPolicyInsure, m_ClientCodePolicyInsure, m_ClientTitlePolicyInsure, m_ClientNamePolicyInsure, m_ClientSurNamePolicyInsure, m_BirthdayPolicyInsure, m_IDCardPolicyInsure, m_TelPolicyInsure, m_SumInsuredPA2PolicyInsure, m_SumInsuredMEPolicyInsure, m_PremiumPA2PolicyInsure, m_PremiumMEPolicyInsure, m_AddPremiumPolicyInsure, m_GrossPremiumPolicyInsure, m_StampPolicyInsure, m_SBTPolicyInsure, m_TotalPremiumPolicyInsure, m_isBeneficiaryPolicyInsure, m_isStudentPolicyInsure, m_isSinglePolicyInsure, m_suminsured_discount, m_premium_discount, m_PackageID, m_PlanCode, m_OccupatnClass, dbTransaction);

                #region "#4-INSERT/UPDATE TRANSPOLICY BENEFICIARIES OF INSURE ONLY"
                for (int j = 1; j < 5; j++)
                {
                    //string m_JobNo = "";
                    //int m_TravelerID = c;
                    //int m_Seq = j;
                    string m_BeneficiaryTitle = "";
                    string m_BeneficiaryName = "";
                    string m_BeneficiarySurName = "";
                    string m_BeneficiaryRelation = "";
                    string m_BeneficiaryRatio = "";
                    string m_BeneficiaryTel = "";

                    string id_BeneficiaryTitle = "ctl00$MainContent$ddlTraveler" + c + "BeneficialyTitle" + j.ToString();
                    m_BeneficiaryTitle = Request.Form[id_BeneficiaryTitle];

                    string id_BeneficiaryName = "ctl00$MainContent$txtTraveler" + c + "BeneficialyName" + j.ToString();
                    m_BeneficiaryName = Request.Form[id_BeneficiaryName];

                    string id_BeneficiarySurName = "ctl00$MainContent$txtTraveler" + c + "BeneficialySurname" + j.ToString();
                    m_BeneficiarySurName = Request.Form[id_BeneficiarySurName];

                    string id_BeneficiaryRelation = "ctl00$MainContent$ddlTraveler" + c + "BeneficialyRelationShip" + j.ToString();
                    m_BeneficiaryRelation = Request.Form[id_BeneficiaryRelation];

                    string id_BeneficiaryRatio = "ctl00$MainContent$txtTraveler" + c + "BeneficialyRatio" + j.ToString();
                    m_BeneficiaryRatio = Request.Form[id_BeneficiaryRatio];

                    string id_BeneficiaryTel = "ctl00$MainContent$txtTraveler" + c + "BeneficialyTel" + j.ToString();
                    m_BeneficiaryTel = Request.Form[id_BeneficiaryTel];

                    string id_BeneficiaryHier = "ctl00$MainContent$chkTraveler" + c + "BeneficialyHeir";
                    string m_BeneficiaryHier = Request.Form[id_BeneficiaryHier];
                    if (m_BeneficiaryHier != "on")
                    {
                        if (!string.IsNullOrEmpty(m_BeneficiaryName) && !string.IsNullOrEmpty(m_BeneficiarySurName))
                        {
                            PATransBeneficiariesBLL clsPATransBeneficiariesBLL = new PATransBeneficiariesBLL();
                            //clsPATransBeneficiariesBLL.SetPATransBeneficiary(m_JobNo, 1, 1, "นาย", "สมมุติ", "นามสกุล", "พ่อ", "100", "021111999");
                            clsPATransBeneficiariesBLL.SetPATransBeneficiary(m_JobNo, c, j, m_BeneficiaryTitle, m_BeneficiaryName, m_BeneficiarySurName, m_BeneficiaryRelation, m_BeneficiaryRatio, m_BeneficiaryTel, dbTransaction);
                        }
                    }
                }
                #endregion

            }

            //--sum of TotalPremiumPolicyInsure of all Insured
            clsPATransPoliciesBLL.SetPATransPolicy(m_JobNo, m_PackageID, m_PlanCode, m_InceptionDate, m_ExpiryDate, m_AgentCode, m_StaffCode, m_OccupatnClass, m_OccupatnDestination, m_NoOfChildren, m_sum_GrossPremiumPolicyInsure, m_sum_StampPolicyInsure, m_sum_SBTPolicyInsure, m_sum_TotalPremiumPolicyInsure, m_isLongName, m_GroupBrokerID, m_User, m_Lang, dbTransaction);


            #endregion

            #region "#5-INSERT/UPDATE TRANSLONGNAME"
            if (m_temp != string.Empty)
            {
                PATransLongNamesBLL clsPATransLongNamesBLL = new PATransLongNamesBLL();
                //clsPATransLongNamesBLL.SetPATransLongName(m_JobNo, "L1", "L2", "L3", "L4");
                clsPATransLongNamesBLL.SetPATransLongName(m_JobNo, m_LongName1, m_LongName2, "", "", dbTransaction);
            }
            #endregion

            #region "COMMIT DB"
            //COMMIT DB
            //DbProviderHelper.CommitTransaction(dbTransaction);
            #endregion

            #region "CLOSE DB"
            //CLOSE DB
            DbProviderHelper.CloseDb();
            dbTransaction.Dispose();
            dbTransaction = null;

            #endregion

            ckEx = "1";
   
        }
        catch (Exception ex)
        {
            if (dbTransaction != null)
            {
                #region "ROLLBACK DB"
                //ROLLBACK DB
                DbProviderHelper.RollbackTransaction(dbTransaction);
                #endregion

                #region "CLOSE DB"
                //CLOSE DB
                DbProviderHelper.CloseDb();
                #endregion
            }
            ckEx = "0";
            this.lblErrorMessage.Text = ex.Message.ToString();
            this.lblInformMessage.Text = "";
        }
        if (ckEx == "1")
        {
            string policyno_from_webservice = "";

            try
            {
                #region "ISSUED TA POLICY"
                string tempUserHostName = "";
                string tempUserHostPassword = "";
                if (Session["UserHostName"].ToString().Substring(0, 2) == "QL")
                {
                    tempUserHostName = "QLPA"; tempUserHostPassword = Session["UserHostPassword"].ToString().Trim();
                }
                else { tempUserHostName = "QAPA"; tempUserHostPassword = Session["UserHostPassword"].ToString().Trim(); }
                //Bind Job no
                this.lblJobnoValue.Text = m_JobNo;

                #region Call Web Service Create Clients
                string message = "";
                string SessionID = ""; ;
                QuickLinkTravelService PAWebServiceSetNewPAClients = new QuickLinkTravelService();
                string output = PAWebServiceSetNewPAClients.SetNewPAClients(m_JobNo, out message, out SessionID);

                if (string.Compare(output, "SUCCESS") != 0)
                {
                      throw new System.ArgumentException("Web Service New PA Clients Error : " + message + " in SessionID : " + SessionID);
                } 
                #endregion

                #region Call Web Service Create Policy
                    message = "";
                    SessionID = ""; ;
                    string MessageStatus = "";

                    QuickLinkTravelService PAWebServiceSetNewPAPolicy = new QuickLinkTravelService();
                    policyno_from_webservice = PAWebServiceSetNewPAPolicy.SetNewPAPolicy(m_JobNo,tempUserHostName,tempUserHostPassword, out message, out MessageStatus);

                    if (string.Compare(MessageStatus, "SUCCESS") != 0 || policyno_from_webservice == "")
                    {
                        throw new System.ArgumentException("Web Service New PA Policy Error : " + message + " in SessionID : " + policyno_from_webservice);
                    } 
                     #endregion

                #region "Call Web Service getPADocument"
                        message = "";
                        SessionID = ""; ;
                        MessageStatus = "";
                        TADocumentService PAWebServicegetPADocument = new TADocumentService();

                        Box_Document[] PA_BIGBOX = new Box_Document[1];
                        Box_Document PA_BOX_DOC = new Box_Document();

                        PA_BOX_DOC.PolicyNo = policyno_from_webservice;
                        PA_BOX_DOC.Document = "RTHSBTDR";
                        PA_BOX_DOC.Flag = true;

                        PA_BIGBOX[0] = PA_BOX_DOC;

                        Box_Message[] BoxMessage;

      
                        BoxMessage = PAWebServicegetPADocument.getPADocument(PA_BIGBOX, tempUserHostName, tempUserHostPassword);

                        if (BoxMessage.Length < 1)
                        {
                            throw new System.ArgumentException("Web Service getPADocument Error : " + BoxMessage[0].Error + " ,Policy No : " + policyno_from_webservice);

                        }
                        else
                        {
                            if (BoxMessage[0].Success != "true")
                            {
                                //throw new System.ArgumentException(BoxMessage[0].Error);
                                throw new System.ArgumentException("Web Service getPADocument Error : " + BoxMessage[0].Error + "  ,Policy No : " + policyno_from_webservice);
                            }
                            else { 
                                    //Bind Message
                                    Response.Redirect("PAPrintPolicy.aspx?policyno=" + policyno_from_webservice);
                                    this.lblErrorMessage.Text = "";
                                    this.lblInformMessage.Text = "ISSUED POLICY SUCCESS. POLICY NUMBER : " + policyno_from_webservice;
                                    
                            }
                        }
                        #endregion
					
                #endregion
            }
            catch (Exception ex)
            {
                
                this.lblErrorMessage.Text = ex.Message.ToString();
                this.lblInformMessage.Text = "";
            }
            //if (policyno_from_webservice.Length != 0 & this.lblErrorMessage.Text == "")
            //{
            //    DateTime viewTime;

            //    viewTime = DateTime.Now;

            //    DateTime viewTime2 = viewTime.AddSeconds(15.0);

            //    while (viewTime < viewTime2)
            //    {

            //        viewTime = DateTime.Now;

            //        if (viewTime > viewTime2)
            //        {

            //          Response.Redirect("PAPrintPolicy.aspx?policyno=" + policyno_from_webservice);

            //        }

            //    }

                
            //}
        }
    }

    void txtNumberOfChilden_TextChanged(object sender, EventArgs e)
    {
        if (!string.IsNullOrEmpty(this.txtNumberOfChilden.Text))
        {
            try
            {
                if (Convert.ToInt32(this.txtNumberOfChilden.Text.Trim()) > 0)
                    this.GenerateDynamicTraveler();
            }
            catch { }
            //
            //this.ProcessCalPremiumAndShowCoverage();
        }

    }

    void ddlInsurancePlan_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlInsurancePlan.SelectedValue != "00")
        {
            this.SetDefaultPremium(ddlInsurancePlan.SelectedValue, this.GetOccupationClass(this.ddlOccupationClass.SelectedValue.Equals(string.Empty) ? 0 : Convert.ToInt32(this.ddlOccupationClass.SelectedValue.Trim())));
            this.SetDefaultPlanCoverage(ddlInsurancePlan.SelectedValue.Trim(), ddlLanguage.SelectedValue.Trim(), this.GetOccupationClass(this.ddlOccupationClass.SelectedValue.Equals(string.Empty) ? 0 : Convert.ToInt32(this.ddlOccupationClass.SelectedValue.Trim())));            
        }
    }

    void chkSameAsPolicyHolder_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            if (chkSameAsPolicyHolder.Checked)
            {
                this.ddlTraveler1Title.SelectedValue = this.ddlPolicyHolderTitle.SelectedValue;
                this.txtTraveler1Name.Value = this.txtPolicyHolderName.Value;
                this.txtTraveler1Surname.Value = this.txtPolicyHolderSurname.Value;
                this.txtTraveler1Birthday.Value = this.txtDateofBirth.Text;
                this.txtTraveler1IDCard.Value = this.txtPolicyHolderIDCard.Text;
                this.txtTraveler1Tel.Value = this.txtPolicyHolderTel.Value;
                //this.txtTraveler1Email.Value = this.txtEmail.Value;

                if (this.txtPolicyHolderIDCard.Text.Length != 13)
                {
                    this.txtTraveler1IDCard.Value = this.txtPolicyHolderIDCard.Text.Trim();
                }

                //this.ClearCssClassFocusError();
            }
            else
            {
                this.ddlTraveler1Title.SelectedIndex = 0;
                this.txtTraveler1Name.Value = "";
                this.txtTraveler1Surname.Value = "";
                this.txtTraveler1Birthday.Value = "";
                this.txtTraveler1IDCard.Value = "";
                this.txtTraveler1Tel.Value = "";
                //this.txtTraveler1Email.Value = "";
                this.txtTraveler1IDCard.Value = "";
            }

            //this.SetDefaultPlanCoverage(this.ddlInsurancePlan.SelectedValue);

        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }

    void ddlAmphure_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.SetTumbolToDropdownList(ddlPolicyHolderTumbon, ddlPolicyHolderProvince.SelectedValue, ddlPolicyHolderAmphure.SelectedValue, ddlLanguage.SelectedValue);
    }

    void ddlProvine_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.SetAmphurToDropdownList(ddlPolicyHolderAmphure, ddlPolicyHolderProvince.SelectedValue, ddlLanguage.SelectedValue);
    }

    void ddlLanguage_SelectedIndexChanged(object sender, EventArgs e)
    {
        //Bind Package
        this.SetPackageToDropdownList(ddlPackage,this.GetAge(), ddlLanguage.SelectedValue.Trim());        
        //Bind Other
        this.ActionChangeLanguage();
    }

    void ddlPackage_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.ActionChangeLanguage();
        //this.SetPlanToDropdownList(ddlInsurancePlan, ddlPackage.SelectedValue, ddlLanguage.SelectedValue.Trim());
        this.ShowHideTraveler2Zone();
    }

    protected void ActionChangeLanguage()
    {
        if (ddlLanguage.SelectedValue != "00")
        {
            
            //ddlOccupation
            this.SetOccupationClassToDropdownList(ddlOccupationClass, ddlLanguage.SelectedValue.Trim());
            //Bind Insure Plan
            this.SetPlanToDropdownList(ddlInsurancePlan, ddlPackage.SelectedValue, this.GetOccupationClass(this.ddlOccupationClass.SelectedValue.Equals(string.Empty) ? 0 : Convert.ToInt32(this.ddlOccupationClass.SelectedValue.Trim())), ddlLanguage.SelectedValue.Trim());

            //Bind Title Holder
            this.SetTitleToDropdownList(ddlPolicyHolderTitle, ddlLanguage.SelectedValue);
            //Bind Genter Holder
            this.SetGenderToDropdownList(ddlPolicyHolderGender, ddlLanguage.SelectedValue);
            //Bind Married Holder
            this.SetMarriedToDropdownList(ddlPolicyHolderMaritalStatus, ddlLanguage.SelectedValue);
            //Bind Nationality Holder
            this.SetNationalityToDropdownList(ddlPolicyHolderNationality, ddlLanguage.SelectedValue);
            //Bind dropdown list "ddlProvine" holder
            this.SetProvinceToDropdownList(ddlPolicyHolderProvince, ddlLanguage.SelectedValue);
            //Bind dropdown list "ddlAmphure" holder
            this.SetAmphurToDropdownList(ddlPolicyHolderAmphure, "01", ddlLanguage.SelectedValue);
            //Bind dropdown list "ddlTumbon" holder
            this.SetTumbolToDropdownList(ddlPolicyHolderTumbon, "01", "0101", ddlLanguage.SelectedValue);

            ////Bind dropdown list Title "Traveler 2"
            this.SetTitleToDropdownList(ddlTraveler1Title, ddlLanguage.SelectedValue);
            this.SetTitleToDropdownList(ddlTraveler1BeneficialyTitle1, ddlLanguage.SelectedValue);
            this.SetTitleToDropdownList(ddlTraveler1BeneficialyTitle2, ddlLanguage.SelectedValue);
            this.SetTitleToDropdownList(ddlTraveler1BeneficialyTitle3, ddlLanguage.SelectedValue);
            this.SetTitleToDropdownList(ddlTraveler1BeneficialyTitle4, ddlLanguage.SelectedValue);

            ////Bind dropdown list Relation "Traveler 1"
            this.SetRelationToDropdownList(ddlTraveler1BeneficialyRelationShip1, ddlLanguage.SelectedValue);
            this.SetRelationToDropdownList(ddlTraveler1BeneficialyRelationShip2, ddlLanguage.SelectedValue);
            this.SetRelationToDropdownList(ddlTraveler1BeneficialyRelationShip3, ddlLanguage.SelectedValue);
            this.SetRelationToDropdownList(ddlTraveler1BeneficialyRelationShip4, ddlLanguage.SelectedValue);

            ////Bind dropdown list Title "Traveler 2"
            this.SetTitleToDropdownList(ddlTraveler2Title, ddlLanguage.SelectedValue);
            this.SetTitleToDropdownList(ddlTraveler2BeneficialyTitle1, ddlLanguage.SelectedValue);
            this.SetTitleToDropdownList(ddlTraveler2BeneficialyTitle2, ddlLanguage.SelectedValue);
            this.SetTitleToDropdownList(ddlTraveler2BeneficialyTitle3, ddlLanguage.SelectedValue);
            this.SetTitleToDropdownList(ddlTraveler2BeneficialyTitle4, ddlLanguage.SelectedValue);
            ////Bind dropdown list Relation "Traveler 2"
            this.SetRelationToDropdownList(ddlTraveler2BeneficialyRelationShip1, ddlLanguage.SelectedValue);
            this.SetRelationToDropdownList(ddlTraveler2BeneficialyRelationShip2, ddlLanguage.SelectedValue);
            this.SetRelationToDropdownList(ddlTraveler2BeneficialyRelationShip3, ddlLanguage.SelectedValue);
            this.SetRelationToDropdownList(ddlTraveler2BeneficialyRelationShip4, ddlLanguage.SelectedValue);
        }
    }

    #region "BIND DROPDOWNLIST"
    protected void SetOccupationClassToDropdownList(DropDownList ddl, string lang)
    {
        try
        {
            ddl.Items.Clear();
            List<PAOccupation> lstPAOccupation = new List<PAOccupation>();
            PAOccupationBLL clsPAOccupation = new PAOccupationBLL();

            lstPAOccupation = clsPAOccupation.GetPAOccupations(lang);

            var ps = from p in lstPAOccupation
                     where p.Status == true
                     select p;

            ListItem m_listitem = new ListItem();

            if (lang == "T")
            {
                m_listitem = new ListItem("โปรดเลือก", "");
            }
            else
            {
                m_listitem = new ListItem("Please Select", "");
            }
                        
            if (ddl.Items.Count <= 0)
            {                                
                if (ps.ToList().Count > 0)
                {
                    ddl.Items.Add(m_listitem);
                    foreach (PAOccupation item in ps.ToList())
                    {
                        if (lang == "T")
                        {
                            m_listitem = new ListItem(item.DescriptionTH, item.OccupationID.ToString());
                            //m_listitem.Attributes["occ_class"] = item.OccupatnClass.ToString();
                        }
                        else
                        {
                            m_listitem = new ListItem(item.DescriptionEN, item.OccupationID.ToString());
                            //m_listitem.Attributes["occ_class"] = item.OccupatnClass.ToString();
                        }

                        ddl.Items.Add(m_listitem);
                    }
                }
            }            
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    protected void SetPackageToDropdownList(DropDownList ddl,int age,string lang)
    {
        try
        {
            //PROCESS GET DATA     
            PAGetDDLTableBLL clsPAGetDDLTableBLL = new PAGetDDLTableBLL();
            DataTable dt = clsPAGetDDLTableBLL.GetDDLPackage(age, lang);
            DataRow dr = dt.NewRow();
            if (lang == "T") 
                dr["PackageName"] = "โปรดเลือก";
            else
                dr["PackageName"] = "Please Selected";
            dr["PackageID"] = "00";
            dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "PackageName";
                ddl.DataValueField = "PackageID";
                ddl.DataBind();
            }
            else
            {
                ddl.DataSource = null;
                ddl.DataBind();
            }
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    
    }
    protected void SetPlanToDropdownList(DropDownList ddl, string packageid, string OccupationClass, string lang)
    {
        try
        {
            //PROCESS GET DATA     
            PAGetDDLTableBLL clsPAGetDDLTableBLL = new PAGetDDLTableBLL();
            DataTable dt = clsPAGetDDLTableBLL.GetDDLPlan(packageid, OccupationClass, lang);
            DataRow dr = dt.NewRow();
            if (lang == "T")
                dr["PlanName"] = "โปรดเลือก";
            else
                dr["PlanName"] = "Please Selected";
            
            dr["PlanCode"] = "00";
            dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "PlanName";
                ddl.DataValueField = "PlanCode";
                ddl.DataBind();
            }
            else
            {
                ddl.DataSource = null;
                ddl.DataBind();
            }
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }

    }
    protected void SetTitleToDropdownList(DropDownList ddl,string lang)
    {
        try
        {
            //PROCESS GET DATA
            PAGetDDLTableBLL clsPAGetDDLTableBLL = new PAGetDDLTableBLL();
            DataTable dt = clsPAGetDDLTableBLL.GetDDLTitle(lang);
            DataRow dr = dt.NewRow();
            if (lang == "T")
                dr["TitleLong"] = "โปรดเลือก";
            else
                dr["TitleLong"] = "Please Selected";

            dr["Title"] = "00";
            dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "TitleLong";
                ddl.DataValueField = "Title";
                ddl.DataBind();
            }
            else
            {
                ddl.DataSource = null;
                ddl.DataBind();
            }

        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    protected void SetGenderToDropdownList(DropDownList ddl, string lang)
    {
        try
        {
            //PROCESS GET DATA
            PAGetDDLTableBLL clsPAGetDDLTableBLL = new PAGetDDLTableBLL();
            DataTable dt = clsPAGetDDLTableBLL.GetDDLGender(lang);
            DataRow dr = dt.NewRow();
            if (lang == "T")
                dr["gender"] = "โปรดเลือก";
            else
                dr["gender"] = "Please Selected";

            dr["gendercode"] = "00";
            dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "gender";
                ddl.DataValueField = "gendercode";
                ddl.DataBind();
            }
            else
            {
                ddl.DataSource = null;
                ddl.DataBind();
            }
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    protected void SetMarriedToDropdownList(DropDownList ddl, string lang)
    {
        try
        {
            //PROCESS GET DATA
            PAGetDDLTableBLL clsPAGetDDLTableBLL = new PAGetDDLTableBLL();
            DataTable dt = clsPAGetDDLTableBLL.GetDDLMarried(lang);
            DataRow dr = dt.NewRow();
            if (lang == "T")
                dr["Married"] = "โปรดเลือก";
            else
                dr["Married"] = "Please Selected";

            dr["MarriedCode"] = "00";
            dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "Married";
                ddl.DataValueField = "MarriedCode";
                ddl.DataBind();
            }
            else
            {
                ddl.DataSource = null;
                ddl.DataBind();
            }
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    protected void SetNationalityToDropdownList(DropDownList ddl, string lang)
    {
        try
        {
            //PROCESS GET DATA
            PAGetDDLTableBLL clsPAGetDDLTableBLL = new PAGetDDLTableBLL();
            DataTable dt = clsPAGetDDLTableBLL.GetDDLNationality(lang);
            DataRow dr = dt.NewRow();
            if (lang == "T")
                dr["Nationality"] = "โปรดเลือก";
            else
                dr["Nationality"] = "Please Selected";

            dr["NationalityCode"] = "00";
            dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "Nationality";
                ddl.DataValueField = "NationalityCode";
                ddl.DataBind();
            }
            else
            {
                ddl.DataSource = null;
                ddl.DataBind();
            }
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    protected void SetRelationToDropdownList(DropDownList ddl, string lang)
    {
        try
        {
            //PROCESS GET DATA
            PAGetDDLTableBLL clsPAGetDDLTableBLL = new PAGetDDLTableBLL();
            DataTable dt = clsPAGetDDLTableBLL.GetDDLRelation(lang);
            DataRow dr = dt.NewRow();
            if (lang == "T")
                dr["Relation"] = "โปรดเลือก";
            else
                dr["Relation"] = "Please Selected";

            dr["ID"] = "00";
            dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "Relation";
                ddl.DataValueField = "Relation";
                ddl.DataBind();
            }
            else
            {
                ddl.DataSource = null;
                ddl.DataBind();
            }
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    protected void SetProvinceToDropdownList(DropDownList ddl, string lang)
    {
        try
        {
            if (lang == "T")
            {
                SetThaiProvinceToDropdownList(ddl);
            }
            else
            {
                SetEngProvinceToDropdownList(ddl);
            }
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    protected void SetAmphurToDropdownList(DropDownList ddl, string provinceid, string lang)
    {
        try
        {
            if (lang == "T")
            {
                SetThaiAmphurToDropdownList(ddl, provinceid);
            }
            else
            {
                SetEngAmphurToDropdownList(ddl, provinceid);
            }
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    protected void SetTumbolToDropdownList(DropDownList ddl, string provinceid, string amphurid, string lang)
    {
        try
        {
            if (lang == "T")
            {
                SetThaiTumbolToDropdownList(ddl, provinceid, amphurid);
            }
            else
            {
                SetEngTumbolToDropdownList(ddl, provinceid, amphurid);
            }
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    //PROCESS SET THAI PROVINCE TO DROPDOWNLIST FROM QUICKLINK DB
    protected void SetThaiProvinceToDropdownList(DropDownList ddl)
    {
        try
        {
            //PROCESS GET DATA
            DataTable dt = Client.GetProvinceThaiLanguage(); //GET ALL
            DataRow dr = dt.NewRow();
            dr["Description"] = "โปรดเลือก";
            dr["ProvinceID"] = "00";
            dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "Description";
                ddl.DataValueField = "ProvinceID";
                ddl.DataBind();
            }
            else
            {
                ddl.DataSource = null;
                ddl.DataBind();
            }
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    //PROCESS SET ENG PROVINCE TO DROPDOWNLIST FROM QUICKLINK DB
    protected void SetEngProvinceToDropdownList(DropDownList ddl)
    {
        try
        {
            //PROCESS GET DATA
            DataTable dt = Client.GetProvinceEngLanguage(); //GET ALL
            DataRow dr = dt.NewRow();
            dr["Description_EN"] = "Please Selected";
            dr["ProvinceID"] = "00";
            dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "Description_EN";
                ddl.DataValueField = "ProvinceID";
                ddl.DataBind();
            }
            else
            {
                ddl.DataSource = null;
                ddl.DataBind();
            }
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    //PROCESS SET THAI AMPHUR TO DROPDOWNLIST FROM QUICKLINK DB
    protected void SetThaiAmphurToDropdownList(DropDownList ddl, string provinceid)
    {
        try
        {
            //PROCESS GET DATA
            DataTable dt = Client.GetAmphurByProvinceThai(provinceid); //GET ALL
            DataRow dr = dt.NewRow();
            dr["Amphur"] = "โปรดเลือก";
            dr["AmphurID"] = "00";
            dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "Amphur";
                ddl.DataValueField = "AmphurID";
                ddl.DataBind();
            }
            else
            {
                ddl.DataSource = null;
                ddl.DataBind();
            }
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    //PROCESS SET ENG AMPHUR TO DROPDOWNLIST FROM QUICKLINK DB
    protected void SetEngAmphurToDropdownList(DropDownList ddl, string provinceid)
    {
        try
        {
            //PROCESS GET DATA
            DataTable dt = Client.GetAmphurByProvinceEng(provinceid); //GET ALL
            DataRow dr = dt.NewRow();
            dr["Amphur_EN"] = "Please Selected";
            dr["AmphurID"] = "00";
            dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "Amphur_EN";
                ddl.DataValueField = "AmphurID";
                ddl.DataBind();
            }
            else
            {
                ddl.DataSource = null;
                ddl.DataBind();
            }
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    //PROCESS SET THAI TUMBOL TO DROPDOWNLIST FROM QUICKLINK DB
    protected void SetThaiTumbolToDropdownList(DropDownList ddl, string provinceid, string amphurid)
    {
        try
        {
            //PROCESS GET DATA
            DataTable dt = Client.GetTumbolByProvinceAndAmphurThai(provinceid, amphurid); //GET ALL
            DataRow dr = dt.NewRow();
            dr["Tumbol"] = "โปรดเลือก";
            dr["TumbolID"] = "00";
            dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "Tumbol";
                ddl.DataValueField = "TumbolID";
                ddl.DataBind();
            }
            else
            {
                ddl.DataSource = null;
                ddl.DataBind();
            }
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    //PROCESS SET ENG TUMBOL TO DROPDOWNLIST FROM QUICKLINK DB
    protected void SetEngTumbolToDropdownList(DropDownList ddl, string provinceid, string amphurid)
    {
        try
        {
            //PROCESS GET DATA
            DataTable dt = Client.GetTumbolByProvinceAndAmphurEng(provinceid, amphurid); //GET ALL
            DataRow dr = dt.NewRow();
            dr["Tumbol_EN"] = "Please Selected";
            dr["TumbolID"] = "00";
            dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "Tumbol_EN";
                ddl.DataValueField = "TumbolID";
                ddl.DataBind();
            }
            else
            {
                ddl.DataSource = null;
                ddl.DataBind();
            }
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }

    #endregion

    #region "Gennerate Traveler by Number of Childen"
    private void GenerateDynamicTraveler()
    {
        this.divTravelerParent.Controls.Clear();
        if (this.txtNumberOfChilden.Text.Trim() == string.Empty) return;

        if (!string.IsNullOrEmpty(this.txtNumberOfChilden.Text))
        {
			int NumberOfChilden;
            try
            {
                NumberOfChilden = Convert.ToInt32(this.txtNumberOfChilden.Text);
            }
            catch { return; }
			
			
            if (this.txtNumberOfChilden.Text.Trim() == "0" || NumberOfChilden == 0)
            {
                return;
            }
            else
            {
                
                for (int i = 0; i < NumberOfChilden; i++)
                {
                    int code = i + 3;

                    HtmlGenericControl h6 = new HtmlGenericControl("h6");
                    h6.InnerText = "Insured " + code + " / ผู้เอาประกันภัย " + code;

                    this.divTravelerParent.Controls.Add(h6);

                    HtmlGenericControl div = new HtmlGenericControl("div");
                    this.divTravelerParent.Controls.Add(div);

                    HtmlTable tableTaveler = new HtmlTable();
                    tableTaveler.Align = "center";
                    tableTaveler.Width = "98%";

                    div.Controls.Add(tableTaveler);

                    #region Table Traveler
                    HtmlTableRow tableTaveler_tr = new HtmlTableRow();
                    tableTaveler.Controls.Add(tableTaveler_tr);

                    //-------------- TravelerTitle ----------------------
                    HtmlTableCell tableTaveler_tdTitle = new HtmlTableCell();
                    tableTaveler_tdTitle.Align = "left";

                    Label lblTravelerTitle = new Label();
                    lblTravelerTitle.Font.Bold = true;
                    lblTravelerTitle.ID = "lblTraveler" + code + "Title";
                    lblTravelerTitle.Text = "<font color=red>*</font>&nbsp;" + "Title : <br />&nbsp;&nbsp;&nbsp;";

                    Label lblTravelerTitleTh = new Label();
                    lblTravelerTitleTh.Font.Bold = true;
                    lblTravelerTitleTh.Font.Size = FontUnit.Point(8);
                    lblTravelerTitleTh.ID = "lblTraveler" + code + "Title_th";
                    lblTravelerTitleTh.Text = "คำนำหน้าชื่อ <br />";

                    DropDownList ddlTravelerTitle = new DropDownList();
                    ddlTravelerTitle.Width = 110;
                    ddlTravelerTitle.ID = "ddlTraveler" + code + "Title";

                    SetTitleToDropdownList(ddlTravelerTitle, this.ddlLanguage.SelectedValue);

                    ddlTravelerTitle.SelectedValue = Request.Form["ctl00$MainContent$ddlTraveler" + code + "Title"];

                    //-------VVVVVVVVVVVVVVVVVVVVVVVVVVV------------


                    tableTaveler_tdTitle.Controls.Add(lblTravelerTitle);
                    tableTaveler_tdTitle.Controls.Add(lblTravelerTitleTh);
                    tableTaveler_tdTitle.Controls.Add(ddlTravelerTitle);

                    tableTaveler_tr.Controls.Add(tableTaveler_tdTitle);

                    //-------------- TravelerName -----------------------
                    HtmlTableCell tableTaveler_tdName = new HtmlTableCell();
                    tableTaveler_tdName.Align = "left";

                    Label lblTravelerName = new Label();
                    lblTravelerName.Font.Bold = true;
                    lblTravelerName.ID = "lblTraveler" + code + "Name";
                    lblTravelerName.Text = "<font color=red>*</font>&nbsp;" + "Name : <br/>&nbsp;&nbsp;&nbsp;";

                    Label lblTravelerNameTh = new Label();
                    lblTravelerNameTh.Font.Bold = true;
                    lblTravelerNameTh.Font.Size = FontUnit.Point(8);
                    lblTravelerNameTh.ID = "lblTraveler" + code + "Name_th";
                    lblTravelerNameTh.Text = "ชื่อ <br />";

                    HtmlInputText txtTravelerName = new HtmlInputText();
                    txtTravelerName.MaxLength = 60;
                    txtTravelerName.Style.Add("width", "195px");
                    txtTravelerName.ID = "txtTraveler" + code + "Name";
                    txtTravelerName.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "Name"];

                    tableTaveler_tdName.Controls.Add(lblTravelerName);
                    tableTaveler_tdName.Controls.Add(lblTravelerNameTh);
                    tableTaveler_tdName.Controls.Add(txtTravelerName);

                    tableTaveler_tr.Controls.Add(tableTaveler_tdName);

                    //-------------- TravelerSurname -----------------------
                    HtmlTableCell tableTaveler_tdSurname = new HtmlTableCell();
                    tableTaveler_tdSurname.Align = "left";

                    Label lblTravelerSurname = new Label();
                    lblTravelerSurname.Font.Bold = true;
                    lblTravelerSurname.ID = "lblTraveler" + code + "Surname";
                    lblTravelerSurname.Text = "Family name : <br/>";

                    Label lblTravelerSurnameTh = new Label();
                    lblTravelerSurnameTh.Font.Bold = true;
                    lblTravelerSurnameTh.Font.Size = FontUnit.Point(8);
                    lblTravelerSurnameTh.ID = "lblTraveler" + code + "Surname_th";
                    lblTravelerSurnameTh.Text = "นามสกุล <br />";

                    HtmlInputText txtTravelerSurname = new HtmlInputText();
                    txtTravelerSurname.MaxLength = 60;
                    txtTravelerSurname.Style.Add("width", "195px");
                    txtTravelerSurname.ID = "txtTraveler" + code + "Surname";
                    txtTravelerSurname.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "Surname"];

                    tableTaveler_tdSurname.Controls.Add(lblTravelerSurname);
                    tableTaveler_tdSurname.Controls.Add(lblTravelerSurnameTh);
                    tableTaveler_tdSurname.Controls.Add(txtTravelerSurname);

                    tableTaveler_tr.Controls.Add(tableTaveler_tdSurname);

                    //-------------- TravelerBirthday -----------------------
                    HtmlTableCell tableTaveler_tdBirthday = new HtmlTableCell();
                    tableTaveler_tdBirthday.Align = "left";

                    Label lblTravelerBirthday = new Label();
                    lblTravelerBirthday.Font.Bold = true;
                    lblTravelerBirthday.ID = "lblTraveler" + code + "Birthday";
                    lblTravelerBirthday.Text = "<font color=red>*</font>&nbsp;" + "DOB : <br/>&nbsp;&nbsp;&nbsp;";

                    Label lblTravelerBirthdayTh = new Label();
                    lblTravelerBirthdayTh.Font.Bold = true;
                    lblTravelerBirthdayTh.Font.Size = FontUnit.Point(8);
                    lblTravelerBirthdayTh.ID = "lblTraveler" + code + "Birthday_th";
                    lblTravelerBirthdayTh.Text = "วัน เดือน ปี เกิด <br />";

                    HtmlInputText txtTravelerBirthday = new HtmlInputText();
                    txtTravelerBirthday.ID = "txtTraveler" + code + "Birthday";
                    txtTravelerBirthday.MaxLength = 10;
                    txtTravelerBirthday.Style.Add("width", "80px");
                    txtTravelerBirthday.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "Birthday"];

                    tableTaveler_tdBirthday.Controls.Add(lblTravelerBirthday);
                    tableTaveler_tdBirthday.Controls.Add(lblTravelerBirthdayTh);
                    tableTaveler_tdBirthday.Controls.Add(txtTravelerBirthday);

                    tableTaveler_tr.Controls.Add(tableTaveler_tdBirthday);

                    //--------------  TravelerIDCard -----------------------
                    HtmlTableCell tableTaveler_tdIDCard = new HtmlTableCell();
                    tableTaveler_tdIDCard.Align = "left";

                    Label lblTravelerIDCard = new Label();
                    lblTravelerIDCard.Font.Bold = true;
                    lblTravelerIDCard.ID = "lblTraveler" + code + "IDCard";
                    lblTravelerIDCard.Text = "<font color=red>*</font>&nbsp;" + "ID Card : <br/>&nbsp;&nbsp;&nbsp;";

                    Label lblTravelerIDCardTh = new Label();
                    lblTravelerIDCardTh.Font.Bold = true;
                    lblTravelerIDCardTh.Font.Size = FontUnit.Point(8);
                    lblTravelerIDCardTh.ID = "lblTraveler" + code + "IDCard_th";
                    lblTravelerIDCardTh.Text = "เลขที่บัตรประชาชน <br />";

                    HtmlInputText txtTravelerIDCard = new HtmlInputText();
                    txtTravelerIDCard.ID = "txtTraveler" + code + "IDCard";
                    txtTravelerIDCard.Style.Add("width", "120px");
                    txtTravelerIDCard.MaxLength = 13;
                    txtTravelerIDCard.Value= Request.Form["ctl00$MainContent$txtTraveler" + code + "IDCard"];

                    tableTaveler_tdIDCard.Controls.Add(lblTravelerIDCard);
                    tableTaveler_tdIDCard.Controls.Add(lblTravelerIDCardTh);
                    tableTaveler_tdIDCard.Controls.Add(txtTravelerIDCard);

                    tableTaveler_tr.Controls.Add(tableTaveler_tdIDCard);

                    //--------------  TravelerTel -----------------------
                    HtmlTableCell tableTaveler_tdTel = new HtmlTableCell();
                    tableTaveler_tdTel.Align = "left";

                    Label lblTravelerTel = new Label();
                    lblTravelerTel.Font.Bold = true;
                    lblTravelerTel.ID = "lblTraveler" + code + "Tel";
                    lblTravelerTel.Text = "<font color=red>*</font>&nbsp;" + "Tel : <br/>&nbsp;&nbsp;&nbsp;";

                    Label lblTravelerTelTh = new Label();
                    lblTravelerTelTh.Font.Bold = true;
                    lblTravelerTelTh.Font.Size = FontUnit.Point(8);
                    lblTravelerTelTh.ID = "lblTraveler" + code + "Tel_th";
                    lblTravelerTelTh.Text = "เบอร์โทรศัพท์ <br />";

                    HtmlInputText txtTravelerTel = new HtmlInputText();
                    txtTravelerTel.ID = "txtTraveler" + code + "Tel";
                    txtTravelerTel.Style.Add("width", "120px");
                    txtTravelerTel.MaxLength = 30;
                    txtTravelerTel.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "Tel"];

                    tableTaveler_tdTel.Controls.Add(lblTravelerTel);
                    tableTaveler_tdTel.Controls.Add(lblTravelerTelTh);
                    tableTaveler_tdTel.Controls.Add(txtTravelerTel);

                    tableTaveler_tr.Controls.Add(tableTaveler_tdTel);


                    //>>>>>>>>>>>>>>>  new rows -----------------------

                    HtmlTableRow tableTaveler_tr2 = new HtmlTableRow();
                    tableTaveler.Controls.Add(tableTaveler_tr2);

                    HtmlTableCell tableTaveler_td6 = new HtmlTableCell();
                    tableTaveler_td6.ColSpan = 6;
                    tableTaveler_td6.Align = "right";
                    tableTaveler_tr2.Controls.Add(tableTaveler_td6);

                    //-------------- TravelerOccupation -----------------------


                    HtmlTable tableTravelerOcc = new HtmlTable();
                    tableTravelerOcc.CellPadding = 2;
                    tableTravelerOcc.CellSpacing = 0;

                    tableTaveler_td6.Controls.Add(tableTravelerOcc);

                    HtmlTableRow tableTravelerOcc_row = new HtmlTableRow();
                    tableTravelerOcc.Controls.Add(tableTravelerOcc_row);

                    HtmlTableCell tableTaveler_tdOccupation1 = new HtmlTableCell();
                    tableTaveler_tdOccupation1.Align = "right";


                    Label lblTravelerOccupation = new Label();
                    lblTravelerOccupation.Font.Bold = true;
                    lblTravelerOccupation.ID = "lblTraveler" + code + "Occupation";
                    lblTravelerOccupation.Text = "Occupation : <br/>";

                    Label lblTravelerOccupationTh = new Label();
                    lblTravelerOccupationTh.Font.Bold = true;
                    lblTravelerOccupationTh.Font.Size = FontUnit.Point(8);
                    lblTravelerOccupationTh.ID = "lblTraveler" + code + "Occupation_th";
                    lblTravelerOccupationTh.Text = "อาชีพ";

                    HtmlTableCell tableTaveler_tdOccupation2 = new HtmlTableCell();
                    tableTaveler_tdOccupation2.Align = "left";
                    tableTaveler_tdOccupation2.VAlign = "top";

                    CheckBox chkTravelerOccupation = new CheckBox();
                    chkTravelerOccupation.ID = "chkTraveler" + code + "Occupation";
                    chkTravelerOccupation.Text = "Student";
                    if (!string.IsNullOrEmpty(Request.Form["ctl00$MainContent$chkTraveler" + code + "Occupation"]))
                    {
                        chkTravelerOccupation.Checked = true;
                    }
                    else
                    {
                        chkTravelerOccupation.Checked = false;
                    }

                    HtmlAnchor br = new HtmlAnchor();
                    br.InnerHtml = "<br/>";

                    tableTaveler_tdOccupation1.Controls.Add(lblTravelerOccupation);
                    tableTaveler_tdOccupation1.Controls.Add(lblTravelerOccupationTh);

                    tableTaveler_tdOccupation2.Controls.Add(chkTravelerOccupation);

                    tableTravelerOcc_row.Controls.Add(tableTaveler_tdOccupation1);
                    tableTravelerOcc_row.Controls.Add(tableTaveler_tdOccupation2);

                    //-------------- TravelerStatus -----------------------
                    HtmlTableRow tableTravelerStatus_row = new HtmlTableRow();
                    tableTravelerOcc.Controls.Add(tableTravelerStatus_row);

                    HtmlTableCell tableTaveler_tdStatus1 = new HtmlTableCell();
                    tableTaveler_tdStatus1.Align = "right";

                    Label lblTravelerStatus = new Label();
                    lblTravelerStatus.Font.Bold = true;
                    lblTravelerStatus.ID = "lblTraveler" + code + "Status";
                    lblTravelerStatus.Text = "Status : <br/>";

                    Label lblTravelerStatusTh = new Label();
                    lblTravelerStatusTh.Font.Bold = true;
                    lblTravelerStatusTh.Font.Size = FontUnit.Point(8);
                    lblTravelerStatusTh.ID = "lblTraveler" + code + "Status_th";
                    lblTravelerStatusTh.Text = "สถานะ ";

                    HtmlTableCell tableTaveler_tdStatus2 = new HtmlTableCell();
                    tableTaveler_tdStatus2.Align = "left";
                    tableTaveler_tdStatus2.VAlign = "top";
                    tableTaveler_tdStatus2.Width = "80px";

                    CheckBox chkTravelerStatus = new CheckBox();
                    chkTravelerStatus.ID = "chkTraveler" + code + "Status";
                    chkTravelerStatus.Text = "Single";
                    if (!string.IsNullOrEmpty(Request.Form["ctl00$MainContent$chkTraveler" + code + "Status"]))
                    {
                        chkTravelerStatus.Checked = true;
                    }
                    else
                    {
                        chkTravelerStatus.Checked = false;
                    }

                    tableTaveler_tdStatus1.Controls.Add(lblTravelerStatus);
                    tableTaveler_tdStatus1.Controls.Add(lblTravelerStatusTh);
                    tableTaveler_tdStatus2.Controls.Add(chkTravelerStatus);

                    tableTravelerStatus_row.Controls.Add(tableTaveler_tdStatus1);
                    tableTravelerStatus_row.Controls.Add(tableTaveler_tdStatus2);

                    //-----------------end table 1-----------------------------
                    #endregion

                    //------------------table Beneficialy---------------------
                    HtmlTable tableBeneficialy1 = new HtmlTable();
                    tableBeneficialy1.Align = "center";
                    tableBeneficialy1.Width = "80%";

                    div.Controls.Add(tableBeneficialy1);

                    #region Table Beneficialy 1
                    //-------------- Beneficialy row 1----------------------
                    HtmlTableRow tableBeneficialy1_tr = new HtmlTableRow();

                    tableBeneficialy1.Controls.Add(tableBeneficialy1_tr);

                    HtmlTableCell tableBeneficialy1_tdBeneficialy = new HtmlTableCell();
                    tableBeneficialy1_tdBeneficialy.Align = "left";
                    tableBeneficialy1_tdBeneficialy.Width = "90px";

                    Label lblTravelerBeneficialy = new Label();
                    lblTravelerBeneficialy.ID = "lblTraveler" + code + "Beneficialy";
                    lblTravelerBeneficialy.Font.Bold = true;
                    lblTravelerBeneficialy.Text = "Beneficiary :";

                    HtmlAnchor tagA = new HtmlAnchor();
                    tagA.InnerHtml = "<br/>";

                    Label lblTravelerBeneficialyTh = new Label();
                    lblTravelerBeneficialyTh.ID = "lblTraveler" + code + "Beneficialy_th";
                    lblTravelerBeneficialyTh.Font.Bold = true;
                    lblTravelerBeneficialyTh.Font.Size = FontUnit.Point(8);
                    lblTravelerBeneficialyTh.Text = "ผู้รับประโยชน์";

                    tableBeneficialy1_tdBeneficialy.Controls.Add(lblTravelerBeneficialy);
                    tableBeneficialy1_tdBeneficialy.Controls.Add(tagA);
                    tableBeneficialy1_tdBeneficialy.Controls.Add(lblTravelerBeneficialyTh);

                    tableBeneficialy1_tr.Controls.Add(tableBeneficialy1_tdBeneficialy);

                    HtmlTableCell tableBeneficialy1_tdBeneficialyHeir = new HtmlTableCell();
                    tableBeneficialy1_tdBeneficialyHeir.Align = "left";
                    tableBeneficialy1_tdBeneficialyHeir.VAlign = "top";

                    CheckBox chkTravelerBeneficialyHeir = new CheckBox();
                    chkTravelerBeneficialyHeir.ID = "chkTraveler" + code + "BeneficialyHeir";

                    chkTravelerBeneficialyHeir.Text = "&nbsp;Estate of the Insured person /กองมรดกของผู้เอาประกันภัย";

                    if (!string.IsNullOrEmpty(Request.Form["ctl00$MainContent$chkTraveler" + code + "BeneficialyHeir"]))
                    {
                        if (Request.Form["ctl00$MainContent$chkTraveler" + code + "BeneficialyHeir"] == string.Empty)
                        {
                            chkTravelerBeneficialyHeir.Checked = false;
                        }
                        else
                        {
                            chkTravelerBeneficialyHeir.Checked = true;
                        }
                    }
                    else
                    {
                        chkTravelerBeneficialyHeir.Checked = true;
                    }

                    tableBeneficialy1_tdBeneficialyHeir.Controls.Add(chkTravelerBeneficialyHeir);

                    tableBeneficialy1_tr.Controls.Add(tableBeneficialy1_tdBeneficialyHeir);

                    #endregion

                    #region Table Beneficialy 2
                    //----------------Beneficialy row 2---------------------

                    HtmlTable tableBeneficialy2 = new HtmlTable();
                    tableBeneficialy2.Align = "center";
                    tableBeneficialy2.Width = "80%";

                    div.Controls.Add(tableBeneficialy2);

                    HtmlTableRow tableBeneficialy2_tr = new HtmlTableRow();

                    tableBeneficialy2.Controls.Add(tableBeneficialy2_tr);
                    for (int j = 1; j < 5; j++)
                    {
                        HtmlTableRow tableBeneficialy2_tr2 = new HtmlTableRow();
                        tableBeneficialy2.Controls.Add(tableBeneficialy2_tr2);

                        //---------------------- lblTraveler1BeneficialyTitle1- ---------------
                        HtmlTableCell tableBeneficialy2_tdBeneficialyTitle = new HtmlTableCell();
                        tableBeneficialy2_tdBeneficialyTitle.Align = "left";

                        Label lblTravelerBeneficialyTitle = new Label();
                        lblTravelerBeneficialyTitle.ID = "lblTraveler" + code + "BeneficialyTitle" + j.ToString();
                        lblTravelerBeneficialyTitle.Font.Bold = true;
                        lblTravelerBeneficialyTitle.Text = "<font color=red>*</font>&nbsp;" + "Title : <br/>&nbsp;&nbsp;&nbsp;";

                        Label lblTravelerBeneficialyTitleTh = new Label();
                        lblTravelerBeneficialyTitleTh.ID = "lblTraveler" + code + "BeneficialyTitle" + j.ToString() + "_th";
                        lblTravelerBeneficialyTitleTh.Font.Bold = true;
                        lblTravelerBeneficialyTitleTh.Font.Size = FontUnit.Point(8);
                        lblTravelerBeneficialyTitleTh.Text = "คำนำหน้าชื่อ <br/>";

                        DropDownList ddlTravelerBeneficialyTitle = new DropDownList();
                        ddlTravelerBeneficialyTitle.Width = 110;
                        ddlTravelerBeneficialyTitle.ID = "ddlTraveler" + code + "BeneficialyTitle" + j.ToString();

                        SetTitleToDropdownList(ddlTravelerBeneficialyTitle, this.ddlLanguage.SelectedValue);

                        ddlTravelerBeneficialyTitle.SelectedValue = Request.Form["ctl00$MainContent$ddlTraveler" + code + "BeneficialyTitle" + j.ToString()];

                        //-------VVVVVVVVVVVVVVVVVVVVVVVVVVV------------

                        if (j == 1)
                        {
                            tableBeneficialy2_tdBeneficialyTitle.Controls.Add(lblTravelerBeneficialyTitle);
                            tableBeneficialy2_tdBeneficialyTitle.Controls.Add(lblTravelerBeneficialyTitleTh);

                        }
                        tableBeneficialy2_tdBeneficialyTitle.Controls.Add(ddlTravelerBeneficialyTitle);

                        tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyTitle);

                        //---------------------- lblTraveler1BeneficialyName1- ---------------
                        HtmlTableCell tableBeneficialy2_tdBeneficialyName = new HtmlTableCell();
                        tableBeneficialy2_tdBeneficialyName.Align = "left";

                        Label lblTravelerBeneficialyName = new Label();
                        lblTravelerBeneficialyName.ID = "lblTraveler" + code + "BeneficialyName" + j.ToString();
                        lblTravelerBeneficialyName.Font.Bold = true;
                        lblTravelerBeneficialyName.Text = "<font color=red>*</font>&nbsp;" + "Name : <br/>&nbsp;&nbsp;&nbsp;";

                        Label lblTravelerBeneficialyNameTh = new Label();
                        lblTravelerBeneficialyNameTh.ID = "lblTraveler" + code + "BeneficialyName" + j.ToString() + "_th";
                        lblTravelerBeneficialyNameTh.Font.Bold = true;
                        lblTravelerBeneficialyNameTh.Font.Size = FontUnit.Point(8);
                        lblTravelerBeneficialyNameTh.Text = "ชื่อ <br/>";

                        HtmlInputText txtTravelerBeneficialyName = new HtmlInputText();
                        txtTravelerBeneficialyName.MaxLength = 100;
                        txtTravelerBeneficialyName.Style.Add("width", "195px");
                        txtTravelerBeneficialyName.ID = "txtTraveler" + code + "BeneficialyName" + j.ToString();
                        txtTravelerBeneficialyName.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialyName" + j.ToString()];

                        if (j == 1)
                        {
                            tableBeneficialy2_tdBeneficialyName.Controls.Add(lblTravelerBeneficialyName);
                            tableBeneficialy2_tdBeneficialyName.Controls.Add(lblTravelerBeneficialyNameTh);

                        }
                        tableBeneficialy2_tdBeneficialyName.Controls.Add(txtTravelerBeneficialyName);

                        tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyName);

                        //---------------------- lblTraveler1BeneficialySurname1- ---------------
                        HtmlTableCell tableBeneficialy2_tdBeneficialySurname = new HtmlTableCell();
                        tableBeneficialy2_tdBeneficialySurname.Align = "left";

                        Label lblTravelerBeneficialySurname = new Label();
                        lblTravelerBeneficialySurname.ID = "lblTraveler" + code + "BeneficialySurname" + j.ToString();
                        lblTravelerBeneficialySurname.Font.Bold = true;
                        lblTravelerBeneficialySurname.Text = "<font color=red>*</font>&nbsp;" + "Family name : <br/>&nbsp;&nbsp;&nbsp;";

                        Label lblTravelerBeneficialySurnameTh = new Label();
                        lblTravelerBeneficialySurnameTh.ID = "lblTraveler" + code + "BeneficialySurname" + j.ToString() + "_th";
                        lblTravelerBeneficialySurnameTh.Font.Bold = true;
                        lblTravelerBeneficialySurnameTh.Font.Size = FontUnit.Point(8);
                        lblTravelerBeneficialySurnameTh.Text = "นามสกุล <br/>";

                        HtmlInputText txtTravelerBeneficialySurname = new HtmlInputText();
                        txtTravelerBeneficialySurname.Style.Add("width", "195px");
                        txtTravelerBeneficialySurname.ID = "txtTraveler" + code + "BeneficialySurname" + j.ToString();
                        txtTravelerBeneficialySurname.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialySurname" + j.ToString()];


                        if (j == 1)
                        {
                            tableBeneficialy2_tdBeneficialySurname.Controls.Add(lblTravelerBeneficialySurname);
                            tableBeneficialy2_tdBeneficialySurname.Controls.Add(lblTravelerBeneficialySurnameTh);

                        }
                        tableBeneficialy2_tdBeneficialySurname.Controls.Add(txtTravelerBeneficialySurname);

                        tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialySurname);

                        //---------------------- lblTraveler1BeneficialyRelationShip1- ---------------
                        HtmlTableCell tableBeneficialy2_tdBeneficialyRelationShip = new HtmlTableCell();
                        tableBeneficialy2_tdBeneficialyRelationShip.Align = "left";

                        Label lblTravelerBeneficialyRelationShip = new Label();
                        lblTravelerBeneficialyRelationShip.ID = "lblTraveler" + code + "BeneficialyRelationShip" + j.ToString();
                        lblTravelerBeneficialyRelationShip.Font.Bold = true;
                        lblTravelerBeneficialyRelationShip.Text = "RelationShip : <br/>";

                        Label lblTravelerBeneficialyRelationShipTh = new Label();
                        lblTravelerBeneficialyRelationShipTh.ID = "lblTraveler" + code + "BeneficialyRelationShip" + j.ToString() + "_th";
                        lblTravelerBeneficialyRelationShipTh.Font.Bold = true;
                        lblTravelerBeneficialyRelationShipTh.Font.Size = FontUnit.Point(8);
                        lblTravelerBeneficialyRelationShipTh.Text = "ความสัมพันธ์กับผู้เอาประกันภัย<br/>";

                        DropDownList ddlTravelerBeneficialyRelationShip = new DropDownList();
                        ddlTravelerBeneficialyRelationShip.ID = "ddlTraveler" + code + "BeneficialyRelationShip" + j.ToString();
                        ddlTravelerBeneficialyRelationShip.Style.Add("width", "160px");

                        SetRelationToDropdownList(ddlTravelerBeneficialyRelationShip, this.ddlLanguage.SelectedValue);
                        ddlTravelerBeneficialyRelationShip.SelectedValue = Request.Form["ctl00$MainContent$ddlTraveler" + code + "BeneficialyRelationShip" + j.ToString()];
                        //-------VVVVVVVVVVVVVVVVVVVVVVVVVVV------------

                        if (j == 1)
                        {
                            tableBeneficialy2_tdBeneficialyRelationShip.Controls.Add(lblTravelerBeneficialyRelationShip);
                            tableBeneficialy2_tdBeneficialyRelationShip.Controls.Add(lblTravelerBeneficialyRelationShipTh);

                        }
                        tableBeneficialy2_tdBeneficialyRelationShip.Controls.Add(ddlTravelerBeneficialyRelationShip);

                        tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyRelationShip);

                        #region #//Part of Traveler Beneficiary Ratio
                        HtmlTableCell tableBeneficialy2_tdBeneficialyRatio = new HtmlTableCell();
                        tableBeneficialy2_tdBeneficialyRatio.Align = "left";

                        Label lblTravelerBeneficialyRatio = new Label();
                        lblTravelerBeneficialyRatio.ID = "lblTraveler" + code + "BeneficialyRatio" + j.ToString();
                        lblTravelerBeneficialyRatio.Font.Bold = true;
                        lblTravelerBeneficialyRatio.Text = "<font color=red>*</font>&nbsp;" + "Ratio : <br/>";

                        Label lblTravelerBeneficialyRatioTh = new Label();
                        lblTravelerBeneficialyRatioTh.ID = "lblTraveler" + code + "BeneficialyRatio" + j.ToString() + "_th";
                        lblTravelerBeneficialyRatioTh.Font.Bold = true;
                        lblTravelerBeneficialyRatioTh.Font.Size = FontUnit.Point(8);
                        lblTravelerBeneficialyRatioTh.Text = "&nbsp;&nbsp;&nbsp;&nbsp;สัดส่วน(%)<br/>";

                        HtmlInputText txtTravelerBeneficialyRatio = new HtmlInputText();
                        txtTravelerBeneficialyRatio.ID = "txtTraveler" + code + "BeneficialyRatio" + j.ToString();
                        txtTravelerBeneficialyRatio.Style.Add("width", "70px");
                        txtTravelerBeneficialyRatio.MaxLength = 3;
                        txtTravelerBeneficialyRatio.Attributes.Add("onkeypress", "return numbersonly(event);");
                        txtTravelerBeneficialyRatio.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialyRatio" + j.ToString()];

                        if (j == 1)
                        {
                            tableBeneficialy2_tdBeneficialyRatio.Controls.Add(lblTravelerBeneficialyRatio);
                            tableBeneficialy2_tdBeneficialyRatio.Controls.Add(lblTravelerBeneficialyRatioTh);
                        }

                        tableBeneficialy2_tdBeneficialyRatio.Controls.Add(txtTravelerBeneficialyRatio);

                        tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyRatio);

                        #endregion

                        //---------------------- lblTraveler1BeneficialyTel1- ---------------
                        HtmlTableCell tableBeneficialy2_tdBeneficialyTel = new HtmlTableCell();
                        tableBeneficialy2_tdBeneficialyTel.Align = "left";

                        Label lblTravelerBeneficialyTel = new Label();
                        lblTravelerBeneficialyTel.ID = "lblTraveler" + code + "BeneficialyTel" + j.ToString();
                        lblTravelerBeneficialyTel.Font.Bold = true;
                        lblTravelerBeneficialyTel.Text = "Tel : <br/>";

                        Label lblTravelerBeneficialyTelTh = new Label();
                        lblTravelerBeneficialyTelTh.ID = "lblTraveler" + code + "BeneficialyTel" + j.ToString() + "_th";
                        lblTravelerBeneficialyTelTh.Font.Bold = true;
                        lblTravelerBeneficialyTelTh.Font.Size = FontUnit.Point(8);
                        lblTravelerBeneficialyTelTh.Text = "เบอร์โทรศัพท์<br/>";

                        HtmlInputText txtTravelerBeneficialyTel = new HtmlInputText();
                        txtTravelerBeneficialyTel.ID = "txtTraveler" + code + "BeneficialyTel" + j.ToString();
                        txtTravelerBeneficialyTel.Style.Add("width", "100px");
                        txtTravelerBeneficialyTel.MaxLength = 100;
                        txtTravelerBeneficialyTel.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialyTel" + j.ToString()];


                        if (j == 1)
                        {
                            tableBeneficialy2_tdBeneficialyTel.Controls.Add(lblTravelerBeneficialyTel);
                            tableBeneficialy2_tdBeneficialyTel.Controls.Add(lblTravelerBeneficialyTelTh);
                            //br = new HtmlAnchor();
                            //br.InnerHtml = "<br/>";
                            //tableBeneficialy_tdBeneficialyTel.Controls.Add(br);
                        }
                        tableBeneficialy2_tdBeneficialyTel.Controls.Add(txtTravelerBeneficialyTel);

                        tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyTel);

                    }

                    #endregion

                }


            }
        }
    }
    private void RemoveDynamicTravelerControl()
    {
        this.divTravelerParent.Controls.Clear();
    }
    #endregion

    #region "BIND SET DEFAULT VALUES PREMIUM/COVARAGE"
    //PROCESS SET DEFAULT PREMIUM
    protected void SetDefaultPremium(string plancode, string OccupationClass)
    {
        try
        {
            this.lblNetPremiumValue.Text = "";
            this.lblTaxValue.Text = "";
            this.lblStampDiutyValue.Text = "";
            this.lblTotlaPremiumValue.Text = "";
            this.lblPersonalAccidentValue.Text = "";

            PAPlanPremiumsBLL clsPAPlanPremiumsBLL = new PAPlanPremiumsBLL();
            DataTable dt = clsPAPlanPremiumsBLL.GetDtPAPlanPremiums(plancode, OccupationClass);
            if (dt.Rows.Count > 0)
            {
                double m_d_netpremium = double.Parse(dt.Rows[0]["GrossPremium"].ToString().Trim());
                double m_d_tax = double.Parse(dt.Rows[0]["SBT"].ToString().Trim());
                double m_d_stamp = double.Parse(dt.Rows[0]["Stamp"].ToString().Trim());
                double m_d_total = double.Parse(dt.Rows[0]["TotalPremium"].ToString().Trim());

                double m_t_netpremium = m_d_netpremium;
                double m_t_tax = m_d_tax;
                double m_t_stamp = m_d_stamp;
                double m_t_total = m_d_total;

                this.lblNetPremiumValue.Text = Utilities.StringFormatWithCommaEng(m_t_netpremium.ToString());
                this.lblTaxValue.Text = Utilities.StringFormatWithCommaEng(m_t_tax.ToString());
                this.lblStampDiutyValue.Text = Utilities.StringFormatWithCommaEng(m_t_stamp.ToString());
                this.lblTotlaPremiumValue.Text = Utilities.StringFormatWithCommaEng(m_t_total.ToString());
            }                                                  
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }

    }
    //PROCESS SET DEFAULT COVERAGE
    protected void SetDefaultPlanCoverage(string planid, string lang, string ccupationClass)
    {
        try
        {
            PAPlanCoveragesBLL clsPAPlanCoveragesBLL = new PAPlanCoveragesBLL();
            DataTable dt = clsPAPlanCoveragesBLL.GetDtPAPlanCoverages(ddlInsurancePlan.SelectedValue.Trim(), ddlLanguage.SelectedValue.Trim(), ccupationClass);            
            this.gdvCoverage.DataSource = dt;            
            this.gdvCoverage.DataBind();
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    #endregion

    protected void GetBindPackagePolicy(string JobNo, string GroupBrokerID)
    {
        try
        {
            //TATransPolicyBLL clstranspolicy = new TATransPolicyBLL();
            //TAGetBindPackagePolicy getbindpackagepolicy = clstranspolicy.GetTATransPolicy(JobNo, GroupBrokerID);

            PAGetBindPolicyBLL clsPAGetBindPolicyBLL = new PAGetBindPolicyBLL();
            PAGetBindPackagePolicy getbindpackagepolicy = clsPAGetBindPolicyBLL.GetPABindPackagePolicy(JobNo, GroupBrokerID);

            
            if (!string.IsNullOrEmpty(getbindpackagepolicy.JobNo))
            {
                //HAVE DATA
                //this.ddlLanguage.SelectedValue; Set by PolicyHolder
                this.txtEffectiveDateFrom.Text = TA.TAUtilities.ConvertDateTimeToEnShowDateString(Convert.ToDateTime(getbindpackagepolicy.InceptionDate.Trim()));
                this.txtEffectiveDateTo.Text = TA.TAUtilities.ConvertDateTimeToEnShowDateString(Convert.ToDateTime(getbindpackagepolicy.ExpiryDate.Trim()));
                //this.txtDateofBirth.Text = TA.TAUtilities.ConvertDateTimeToEnShowDateString(Convert.ToDateTime(getbindpackagepolicy..Trim())); //Replace by DOB Policy Holder

                //Bind dropdown list "ddlPackage"
                this.SetPackageToDropdownList(ddlPackage, this.GetAge(), ddlLanguage.SelectedValue.Trim());
                this.ddlPackage.SelectedValue = getbindpackagepolicy.PackageID.Trim();

                //Show Area NumberOfChilden
                this.ShowHideTraveler2Zone();

                this.txtNumberOfChilden.Text = getbindpackagepolicy.NoOfChildren.Trim();

                
                this.txtOccupation.Text = getbindpackagepolicy.OccupatnDestination.Trim();

                //Bind dropdown list "ddlInsurancePlan"
                this.SetOccupationClassToDropdownList(ddlOccupationClass, ddlLanguage.SelectedValue.Trim());
                //this.ddlOccupationClass.Items.FindByText(getbindpackagepolicy.OccupatnDestination.ToString().Trim()).Selected = true;
                this.setDDLOccupationClassValue(getbindpackagepolicy.OccupatnDestination.Trim());
                string m_occupation_class = this.GetOccupationClass(this.ddlOccupationClass.SelectedValue.Equals(string.Empty) ? 0 : Convert.ToInt32(this.ddlOccupationClass.SelectedValue.Trim()));

                //Bind dropdown list "ddlInsurancePlan"
                this.SetPlanToDropdownList(ddlInsurancePlan, this.ddlPackage.SelectedValue.Trim(), m_occupation_class, ddlLanguage.SelectedValue.Trim());
                this.ddlInsurancePlan.SelectedValue = getbindpackagepolicy.PlanCode.Trim();


                this.lblTaxValue.Text = Utilities.StringFormatWithCommaEng(getbindpackagepolicy.SBT.Trim());
                this.lblStampDiutyValue.Text = Utilities.StringFormatWithCommaEng(getbindpackagepolicy.Stamp.Trim());
                this.lblTotlaPremiumValue.Text = Utilities.StringFormatWithCommaEng(getbindpackagepolicy.TotalPremium.Trim());
                this.txtLongName1.Value = getbindpackagepolicy.LongName1.Trim();
                this.txtLongName2.Value = getbindpackagepolicy.LongName2.Trim();

                
                //Bind default coveage area and premium
                this.SetDefaultPremium(ddlInsurancePlan.SelectedValue.Trim(), m_occupation_class);
                this.SetDefaultPlanCoverage(ddlInsurancePlan.SelectedValue.Trim(), ddlLanguage.SelectedValue.Trim(), m_occupation_class); 

            }
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    protected void GetBindPolicyHolder(string JobNo)
    {
        try
        {
            PATransPolicyHolders transpolicyholder = new PATransPolicyHolders();
            PAGetBindPolicyBLL clsPAGetBindPolicyBLL = new PAGetBindPolicyBLL();
            transpolicyholder = clsPAGetBindPolicyBLL.GetPATransPolicyHolders(JobNo);
            if (!string.IsNullOrEmpty(transpolicyholder.JobNo))
            {
                //HAVE DATA
                switch (transpolicyholder.ClientType.Trim())
                {
                    case "P"://Bind data "Private"
                        //Bind Date of Birth
                        //this.txtDateofBirth.Text = TA.TAUtilities.ConvertDateTimeToEnShowDateString(Convert.ToDateTime(transpolicyholder.Birthday.Trim()));

                        this.rdoTaxInvoiceType.SelectedIndex = 0;
                        this.txtPolicyHolderName.Value = transpolicyholder.ClientName.Trim();
                        this.txtPolicyHolderSurname.Value = transpolicyholder.ClientSurName.Trim();
                        this.txtPolicyHolderAddressNo.Value = transpolicyholder.AddressNo.Trim();
                        this.txtPolicyHolderBuilding.Value = transpolicyholder.Building.Trim();
                        this.txtPolicyHolderSoi.Value = transpolicyholder.Soi.Trim();
                        this.txtPolicyHolderRoad.Value = transpolicyholder.Road.Trim();
                        this.ddlLanguage.SelectedValue = transpolicyholder.Language;

                        //Bind dropdown list "ddlPolicyHolderGender"
                        this.SetGenderToDropdownList(ddlPolicyHolderGender, transpolicyholder.Language.Trim());
                        this.ddlPolicyHolderGender.SelectedValue = transpolicyholder.ClientGender.Trim();

                        //Bind dropdown list "ddlPolicyHolderMaritalStatus"
                        this.SetMarriedToDropdownList(ddlPolicyHolderMaritalStatus, transpolicyholder.Language.Trim());
                        this.ddlPolicyHolderMaritalStatus.SelectedValue = transpolicyholder.ClientStatus.Trim();

                        //Bind dropdown list "ddlPolicyHolderNationality"
                        this.SetNationalityToDropdownList(ddlPolicyHolderNationality, transpolicyholder.Language.Trim());
                        this.ddlPolicyHolderNationality.SelectedValue = transpolicyholder.CountryCode.Trim();

                        //Bind dropdown list "ddlPolicyHolderProvince"
                        this.SetProvinceToDropdownList(ddlPolicyHolderProvince, transpolicyholder.Language.Trim());
                        string Province = transpolicyholder.Province.Trim();
                        Province = Province.Replace("จังหวัด", "");
                        this.findDropdownValueByText(this.ddlPolicyHolderProvince, Province);
                        //this.ddlPolicyHolderProvince.SelectedItem.Text = transpolicyholder.Province.Trim();

                        //Bind dropdown list "ddlPolicyHolderAmphure"
                        this.SetAmphurToDropdownList(ddlPolicyHolderAmphure, this.ddlPolicyHolderProvince.SelectedValue, transpolicyholder.Language.Trim());
                        string Amphur = transpolicyholder.Amphur.Trim();
                        Amphur = Amphur.Replace("อำเภอ", "");
                        this.findDropdownValueByText(this.ddlPolicyHolderAmphure, Amphur);
                        //this.ddlPolicyHolderAmphure.SelectedItem.Text = transpolicyholder.Amphur.Trim();

                        //Bind dropdown list "ddlPolicyHolderTumbon"
                        this.SetTumbolToDropdownList(ddlPolicyHolderTumbon, this.ddlPolicyHolderProvince.SelectedValue, this.ddlPolicyHolderAmphure.SelectedValue, transpolicyholder.Language.Trim());
                        string Tumbol = transpolicyholder.Tumbol.Trim();
                        Tumbol = Tumbol.Replace("ตำบล", "");
                        this.findDropdownValueByText(this.ddlPolicyHolderTumbon, Tumbol);
                        //this.ddlPolicyHolderTumbon.SelectedItem.Text = transpolicyholder.Tumbol.Trim();

                        //Bind dropdown list "ddlPolicyHolderTitle"
                        this.SetTitleToDropdownList(ddlPolicyHolderTitle, transpolicyholder.Language.Trim());
                        this.ddlPolicyHolderTitle.SelectedValue = transpolicyholder.ClientTitle.Trim();

                        this.txtPolicyHolderZipCode.Value = transpolicyholder.PostCode.Trim();
                        this.txtPolicyHolderBirthay.Value = TA.TAUtilities.ConvertDateTimeToEnShowDateString(Convert.ToDateTime(transpolicyholder.Birthday.Trim()));
                        this.txtPolicyHolderIDCard.Text = transpolicyholder.IDCard.Trim() == string.Empty ? transpolicyholder.PassportID.Trim() : transpolicyholder.IDCard.Trim();
                        this.txtPolicyHolderTel.Value = transpolicyholder.Tel.Trim();
                        this.txtPolicyHolderEmail.Value = transpolicyholder.Email.Trim();
                        break;
                    case "C"://Bind data "Commercial"
                        //Bind Date of Birth
                        //this.txtDateofBirth.Text = TA.TAUtilities.ConvertDateTimeToEnShowDateString(Convert.ToDateTime(transpolicyholder.Birthday.Trim()));

                        this.rdoTaxInvoiceType.SelectedIndex = 1;
                        this.txtPolicyHolderName.Value = transpolicyholder.ClientName.Trim();
                        this.txtPolicyHolderSurname.Value = transpolicyholder.ClientSurName.Trim();
                        this.txtPolicyHolderAddressNo.Value = transpolicyholder.AddressNo.Trim();
                        this.txtPolicyHolderBuilding.Value = transpolicyholder.Building.Trim();
                        this.txtPolicyHolderSoi.Value = transpolicyholder.Soi.Trim();
                        this.txtPolicyHolderRoad.Value = transpolicyholder.Road.Trim();
                        this.ddlLanguage.SelectedValue = transpolicyholder.Language;

                        //Bind dropdown list "ddlPolicyHolderMaritalStatus"
                        this.SetMarriedToDropdownList(ddlPolicyHolderMaritalStatus, transpolicyholder.Language.Trim());
                        this.ddlPolicyHolderMaritalStatus.SelectedValue = transpolicyholder.ClientStatus.Trim();

                        //Bind dropdown list "ddlPolicyHolderNationality"
                        this.SetNationalityToDropdownList(ddlPolicyHolderNationality, transpolicyholder.Language.Trim());
                        this.ddlPolicyHolderNationality.SelectedValue = transpolicyholder.CountryCode.Trim();

                        //Bind dropdown list "ddlPolicyHolderProvince"
                        this.SetProvinceToDropdownList(ddlPolicyHolderProvince, transpolicyholder.Language.Trim());
                        Province = transpolicyholder.Province.Trim();
                        Province = Province.Replace("จังหวัด", "");
                        this.findDropdownValueByText(this.ddlPolicyHolderProvince, Province);
                        //this.ddlPolicyHolderProvince.SelectedItem.Text = transpolicyholder.Province.Trim();
                        
                        //Bind dropdown list "ddlPolicyHolderAmphure"
                        this.SetAmphurToDropdownList(ddlPolicyHolderAmphure, this.ddlPolicyHolderProvince.SelectedValue, transpolicyholder.Language.Trim());
                        Amphur = transpolicyholder.Amphur.Trim();
                        Amphur = Amphur.Replace("อำเภอ", "");
                        this.findDropdownValueByText(this.ddlPolicyHolderAmphure, Amphur);
                        //this.ddlPolicyHolderAmphure.SelectedItem.Text = transpolicyholder.Amphur.Trim();

                        //Bind dropdown list "ddlPolicyHolderTumbon"
                        this.SetTumbolToDropdownList(ddlPolicyHolderTumbon, this.ddlPolicyHolderProvince.SelectedValue, this.ddlPolicyHolderAmphure.SelectedValue, transpolicyholder.Language.Trim());
                        Tumbol = transpolicyholder.Tumbol.Trim();
                        Tumbol = Tumbol.Replace("ตำบล", "");
                        this.findDropdownValueByText(this.ddlPolicyHolderTumbon, Tumbol);
                        //this.ddlPolicyHolderTumbon.SelectedItem.Text = transpolicyholder.Tumbol.Trim();

                        this.txtPolicyHolderZipCode.Value = transpolicyholder.PostCode.Trim();
                        this.txtPolicyHolderIDCard.Text = transpolicyholder.TaxID.Trim();                   
                        this.txtPolicyHolderTel.Value = transpolicyholder.Tel.Trim();
                        this.txtPolicyHolderEmail.Value = transpolicyholder.Email.Trim();

                        this.txtBranchNo.Value = transpolicyholder.BranchNo.Trim();
                        break;
                    default: break;
                }
            }
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    protected void GetBindDOB(string JobNo)
    {
        try
        {
            PAGetBindPolicyBLL clsPAGetBindPolicyBLL = new PAGetBindPolicyBLL();
            DataTable dt = clsPAGetBindPolicyBLL.GetBindPolicyInsureds(JobNo);

            if (dt.Rows.Count > 0)
            {
                // blind Date of Birth from Insured 1
                this.txtDateofBirth.Text = TA.TAUtilities.ConvertDateTimeToEnShowDateString(Convert.ToDateTime(dt.Rows[0]["Birthday"].ToString().Trim()));
                //Benefit 
            }
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    protected void GetBindTraveler(string JobNo)
    {
        try
        {
            PAGetBindPolicyBLL clsPAGetBindPolicyBLL = new PAGetBindPolicyBLL();
            DataTable dt = clsPAGetBindPolicyBLL.GetBindPolicyInsureds(JobNo);

            if (dt.Rows.Count > 0)
            {
                //HAVE DATA
                //Bind dropdown list "ddlTraveler1Title"
                this.SetTitleToDropdownList(ddlTraveler1Title, ddlLanguage.SelectedValue.Trim());
                this.ddlTraveler1Title.SelectedValue = dt.Rows[0]["ClientTitle"].ToString().Trim();

                this.txtTraveler1Name.Value = dt.Rows[0]["ClientName"].ToString().Trim();
                this.txtTraveler1Surname.Value = dt.Rows[0]["ClientSurName"].ToString().Trim();
                this.txtTraveler1Birthday.Value = TA.TAUtilities.ConvertDateTimeToEnShowDateString(Convert.ToDateTime(dt.Rows[0]["Birthday"].ToString().Trim()));
                this.txtTraveler1IDCard.Value = dt.Rows[0]["IDCard"].ToString().Trim() == string.Empty ? dt.Rows[0]["PassportID"].ToString().Trim() : dt.Rows[0]["IDCard"].ToString().Trim();
                this.txtTraveler1Tel.Value = dt.Rows[0]["Tel"].ToString().Trim();

                // blind Date of Birth from Insured 1
                //this.txtDateofBirth.Text = TA.TAUtilities.ConvertDateTimeToEnShowDateString(Convert.ToDateTime(dt.Rows[0]["Birthday"].ToString().Trim()));
                //Benefit 
                this.SetTitleToDropdownList(ddlTraveler1BeneficialyTitle1, this.ddlLanguage.SelectedValue);
                this.SetTitleToDropdownList(ddlTraveler1BeneficialyTitle2, this.ddlLanguage.SelectedValue);
                this.SetTitleToDropdownList(ddlTraveler1BeneficialyTitle3, this.ddlLanguage.SelectedValue);
                this.SetTitleToDropdownList(ddlTraveler1BeneficialyTitle4, this.ddlLanguage.SelectedValue);
                this.SetRelationToDropdownList(ddlTraveler1BeneficialyRelationShip1, this.ddlLanguage.SelectedValue);
                this.SetRelationToDropdownList(ddlTraveler1BeneficialyRelationShip2, this.ddlLanguage.SelectedValue);
                this.SetRelationToDropdownList(ddlTraveler1BeneficialyRelationShip3, this.ddlLanguage.SelectedValue);
                this.SetRelationToDropdownList(ddlTraveler1BeneficialyRelationShip4, this.ddlLanguage.SelectedValue);

                DataTable dtbenefit = clsPAGetBindPolicyBLL.GetBindBeneficiaryOfInsured(JobNo,1);
                if (dtbenefit.Rows.Count > 0)
                {
                    //HAVE DATA
                    //Benefit Groop 1 Only
                        
                    foreach (DataRow row in dtbenefit.Rows)
                    {
                        string m_travelerid = row["InsuredID"].ToString().Trim();
                        string m_seq = row["BeneficiaryID"].ToString().Trim();
                        if (m_travelerid == "1")
                        {
                            //Bind Benefit
                            this.chkTraveler1BeneficialyHeir.Checked = false;
                            switch (m_seq)
                            {
                                case "1":
                                    this.ddlTraveler1BeneficialyTitle1.SelectedValue = row["BeneficiaryTitle"].ToString().Trim();
                                    this.txtTraveler1BeneficialyName1.Value = row["BeneficiaryName"].ToString().Trim();
                                    this.txtTraveler1BeneficialySurname1.Value = row["BeneficiarySurName"].ToString().Trim();
                                    this.ddlTraveler1BeneficialyRelationShip1.SelectedValue = row["BeneficiaryRelation"].ToString().Trim();
                                    this.txtTraveler1BeneficialyRatio1.Value = row["BeneficiaryRatio"].ToString().Trim();
                                    this.txtTraveler1BeneficialyTel1.Value = row["BeneficiaryTel"].ToString().Trim();
                                    break;
                                case "2":
                                    this.ddlTraveler1BeneficialyTitle2.SelectedValue = row["BeneficiaryTitle"].ToString().Trim();
                                    this.txtTraveler1BeneficialyName2.Value = row["BeneficiaryName"].ToString().Trim();
                                    this.txtTraveler1BeneficialySurname2.Value = row["BeneficiarySurName"].ToString().Trim();
                                    this.ddlTraveler1BeneficialyRelationShip2.SelectedValue = row["BeneficiaryRelation"].ToString().Trim();
                                    this.txtTraveler1BeneficialyRatio2.Value = row["BeneficiaryRatio"].ToString().Trim();
                                    this.txtTraveler1BeneficialyTel2.Value = row["BeneficiaryTel"].ToString().Trim();
                                    break;
                                case "3":
                                    this.ddlTraveler1BeneficialyTitle3.SelectedValue = row["BeneficiaryTitle"].ToString().Trim();
                                    this.txtTraveler1BeneficialyName3.Value = row["BeneficiaryName"].ToString().Trim();
                                    this.txtTraveler1BeneficialySurname3.Value = row["BeneficiarySurName"].ToString().Trim();
                                    this.ddlTraveler1BeneficialyRelationShip3.SelectedValue = row["BeneficiaryRelation"].ToString().Trim();
                                    this.txtTraveler1BeneficialyRatio3.Value = row["BeneficiaryRatio"].ToString().Trim();
                                    this.txtTraveler1BeneficialyTel3.Value = row["BeneficiaryTel"].ToString().Trim();
                                    break;
                                case "4":
                                    this.ddlTraveler1BeneficialyTitle4.SelectedValue = row["BeneficiaryTitle"].ToString().Trim();
                                    this.txtTraveler1BeneficialyName4.Value = row["BeneficiaryName"].ToString().Trim();
                                    this.txtTraveler1BeneficialySurname4.Value = row["BeneficiarySurName"].ToString().Trim();
                                    this.ddlTraveler1BeneficialyRelationShip4.SelectedValue = row["BeneficiaryRelation"].ToString().Trim();
                                    this.txtTraveler1BeneficialyRatio4.Value = row["BeneficiaryRatio"].ToString().Trim();
                                    this.txtTraveler1BeneficialyTel4.Value = row["BeneficiaryTel"].ToString().Trim();
                                    break;
                            }
                        }
                    }
                }

                if (dt.Rows.Count > 1)
                {
                    dtbenefit = clsPAGetBindPolicyBLL.GetBindBeneficiaryOfInsured(JobNo, 2);
                    

                    this.SetTitleToDropdownList(ddlTraveler2Title, this.ddlLanguage.SelectedValue);
                    this.ddlTraveler2Title.SelectedValue = dt.Rows[1]["ClientTitle"].ToString().Trim();
                    this.txtTraveler2Name.Value = dt.Rows[1]["ClientName"].ToString().Trim();
                    this.txtTraveler2Surname.Value = dt.Rows[1]["ClientSurName"].ToString().Trim();
                    this.txtTraveler2Birthday.Value = TA.TAUtilities.ConvertDateTimeToEnShowDateString(Convert.ToDateTime(dt.Rows[1]["Birthday"].ToString().Trim()));
                    this.txtTraveler2IDCard.Value = dt.Rows[1]["IDCard"].ToString().Trim() == string.Empty ? dt.Rows[1]["PassportID"].ToString().Trim() : dt.Rows[1]["IDCard"].ToString().Trim();
                    this.txtTraveler2Tel.Value = dt.Rows[1]["Tel"].ToString().Trim();


                    //Benefit Groop 2 Only
                    this.SetTitleToDropdownList(ddlTraveler2BeneficialyTitle1, this.ddlLanguage.SelectedValue);
                    this.SetTitleToDropdownList(ddlTraveler2BeneficialyTitle2, this.ddlLanguage.SelectedValue);
                    this.SetTitleToDropdownList(ddlTraveler2BeneficialyTitle3, this.ddlLanguage.SelectedValue);
                    this.SetTitleToDropdownList(ddlTraveler2BeneficialyTitle4, this.ddlLanguage.SelectedValue);
                    this.SetRelationToDropdownList(ddlTraveler2BeneficialyRelationShip1, this.ddlLanguage.SelectedValue);
                    this.SetRelationToDropdownList(ddlTraveler2BeneficialyRelationShip2, this.ddlLanguage.SelectedValue);
                    this.SetRelationToDropdownList(ddlTraveler2BeneficialyRelationShip3, this.ddlLanguage.SelectedValue);
                    this.SetRelationToDropdownList(ddlTraveler2BeneficialyRelationShip4, this.ddlLanguage.SelectedValue);

                    if (dtbenefit.Rows.Count > 0)
                    {
                        //HAVE DATA
                            
                        foreach (DataRow row in dtbenefit.Rows)
                        {
                            string m_travelerid = row["InsuredID"].ToString().Trim();
                            string m_seq = row["BeneficiaryID"].ToString().Trim();
                            if (m_travelerid == "2")
                            {
                                //Bind Benefit
                                this.chkTraveler2BeneficialyHeir.Checked = false;
                                switch (m_seq)
                                {
                                    case "1":
                                        this.ddlTraveler2BeneficialyTitle1.SelectedValue = row["BeneficiaryTitle"].ToString().Trim();
                                        this.txtTraveler2BeneficialyName1.Value = row["BeneficiaryName"].ToString().Trim();
                                        this.txtTraveler2BeneficialySurname1.Value = row["BeneficiarySurName"].ToString().Trim();
                                        this.ddlTraveler2BeneficialyRelationShip1.SelectedValue = row["BeneficiaryRelation"].ToString().Trim();
                                        this.txtTraveler2BeneficialyRatio1.Value = row["BeneficiaryRatio"].ToString().Trim();
                                        this.txtTraveler2BeneficialyTel1.Value = row["BeneficiaryTel"].ToString().Trim();
                                        break;
                                    case "2":
                                        this.ddlTraveler2BeneficialyTitle2.SelectedValue = row["BeneficiaryTitle"].ToString().Trim();
                                        this.txtTraveler2BeneficialyName2.Value = row["BeneficiaryName"].ToString().Trim();
                                        this.txtTraveler2BeneficialySurname2.Value = row["BeneficiarySurName"].ToString().Trim();
                                        this.ddlTraveler2BeneficialyRelationShip2.SelectedValue = row["BeneficiaryRelation"].ToString().Trim();
                                        this.txtTraveler2BeneficialyRatio2.Value = row["BeneficiaryRatio"].ToString().Trim();
                                        this.txtTraveler2BeneficialyTel2.Value = row["BeneficiaryTel"].ToString().Trim();
                                        break;
                                    case "3":
                                        this.ddlTraveler2BeneficialyTitle3.SelectedValue = row["BeneficiaryTitle"].ToString().Trim();
                                        this.txtTraveler2BeneficialyName3.Value = row["BeneficiaryName"].ToString().Trim();
                                        this.txtTraveler2BeneficialySurname3.Value = row["BeneficiarySurName"].ToString().Trim();
                                        this.ddlTraveler2BeneficialyRelationShip3.SelectedValue = row["BeneficiaryRelation"].ToString().Trim();
                                        this.txtTraveler2BeneficialyRatio3.Value = row["BeneficiaryRatio"].ToString().Trim();
                                        this.txtTraveler2BeneficialyTel3.Value = row["BeneficiaryTel"].ToString().Trim();
                                        break;
                                    case "4":
                                        this.ddlTraveler2BeneficialyTitle4.SelectedValue = row["BeneficiaryTitle"].ToString().Trim();
                                        this.txtTraveler2BeneficialyName4.Value = row["BeneficiaryName"].ToString().Trim();
                                        this.txtTraveler2BeneficialySurname4.Value = row["BeneficiarySurName"].ToString().Trim();
                                        this.ddlTraveler2BeneficialyRelationShip4.SelectedValue = row["BeneficiaryRelation"].ToString().Trim();
                                        this.txtTraveler2BeneficialyRatio4.Value = row["BeneficiaryRatio"].ToString().Trim();
                                        this.txtTraveler2BeneficialyTel4.Value = row["BeneficiaryTel"].ToString().Trim();
                                        break;
                                }
                            }
                        }
                    }
                    //Generage Another Traveler
                    this.GenerateDynamicTraveler(dt, JobNo);
                }


            }
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    protected void GetBindPremium(string JobNo)
    {
        PATransPoliciesBLL clsPATransPolicy = new PATransPoliciesBLL();
        PATransPolicies getBindPremium = new PATransPolicies();
        getBindPremium = clsPATransPolicy.GetPATransPolicies(JobNo);

        if (!string.IsNullOrEmpty(getBindPremium.JobNo))
        {
            this.lblNetPremiumValue.Text = Utilities.StringFormatWithCommaEng(getBindPremium.GrossPremium.ToString().Trim());
            this.lblTaxValue.Text = Utilities.StringFormatWithCommaEng(getBindPremium.SBT.ToString().Trim());
            this.lblStampDiutyValue.Text = Utilities.StringFormatWithCommaEng(getBindPremium.Stamp.ToString().Trim());
            this.lblTotlaPremiumValue.Text = Utilities.StringFormatWithCommaEng(getBindPremium.TotalPremium.ToString().Trim());
        }                           
    }
    protected void ShowHideTraveler2Zone()
    {
        if (ddlPackage.SelectedValue != "0004")
        {
            this.txtNumberOfChilden.Text = "0";
            this.GenerateDynamicTraveler();
        }
    }
    protected void GenerateDynamicTraveler(DataTable dt, string JobNo)
    {
        this.divTravelerParent.Controls.Clear();
        if (this.txtNumberOfChilden.Text.Trim() == string.Empty) return;

        if (!string.IsNullOrEmpty(this.txtNumberOfChilden.Text))
        {

            int NumberOfChilden;
            try
            {
                NumberOfChilden = Convert.ToInt32(this.txtNumberOfChilden.Text);
            }
            catch { return; }

            if (this.txtNumberOfChilden.Text.Trim() == "0" || NumberOfChilden == 0)
            {
                return;
            }
            else
            {
                
                for (int i = 0; i < NumberOfChilden; i++)
                {
                    int code = i + 3;
                    int index = i + 2;
                    HtmlGenericControl h6 = new HtmlGenericControl("h6");
                    h6.InnerText = "Insured " + code + " / ผู้เอาประกันภัย " + code;

                    this.divTravelerParent.Controls.Add(h6);

                    HtmlGenericControl div = new HtmlGenericControl("div");
                    this.divTravelerParent.Controls.Add(div);

                    HtmlTable tableTaveler = new HtmlTable();
                    tableTaveler.Align = "center";
                    tableTaveler.Width = "98%";

                    div.Controls.Add(tableTaveler);

                    #region Table Traveler
                    HtmlTableRow tableTaveler_tr = new HtmlTableRow();
                    tableTaveler.Controls.Add(tableTaveler_tr);

                    //-------------- TravelerTitle ----------------------
                    HtmlTableCell tableTaveler_tdTitle = new HtmlTableCell();
                    tableTaveler_tdTitle.Align = "left";

                    Label lblTravelerTitle = new Label();
                    lblTravelerTitle.Font.Bold = true;
                    lblTravelerTitle.ID = "lblTraveler" + code + "Title";
                    lblTravelerTitle.Text = "<font color=red>*</font>&nbsp;" + "Title : <br />&nbsp;&nbsp;&nbsp;";

                    Label lblTravelerTitleTh = new Label();
                    lblTravelerTitleTh.Font.Bold = true;
                    lblTravelerTitleTh.Font.Size = FontUnit.Point(8);
                    lblTravelerTitleTh.ID = "lblTraveler" + code + "Title_th";
                    lblTravelerTitleTh.Text = "คำนำหน้าชื่อ <br />";

                    DropDownList ddlTravelerTitle = new DropDownList();
                    ddlTravelerTitle.Width = 110;
                    ddlTravelerTitle.ID = "ddlTraveler" + code + "Title";

                    SetTitleToDropdownList(ddlTravelerTitle, this.ddlLanguage.SelectedValue);

                    ddlTravelerTitle.SelectedValue = dt.Rows[index]["ClientTitle"].ToString().Trim();
                    //-------VVVVVVVVVVVVVVVVVVVVVVVVVVV------------


                    tableTaveler_tdTitle.Controls.Add(lblTravelerTitle);
                    tableTaveler_tdTitle.Controls.Add(lblTravelerTitleTh);
                    tableTaveler_tdTitle.Controls.Add(ddlTravelerTitle);

                    tableTaveler_tr.Controls.Add(tableTaveler_tdTitle);

                    //-------------- TravelerName -----------------------
                    HtmlTableCell tableTaveler_tdName = new HtmlTableCell();
                    tableTaveler_tdName.Align = "left";

                    Label lblTravelerName = new Label();
                    lblTravelerName.Font.Bold = true;
                    lblTravelerName.ID = "lblTraveler" + code + "Name";
                    lblTravelerName.Text = "<font color=red>*</font>&nbsp;" + "Name : <br/>&nbsp;&nbsp;&nbsp;";

                    Label lblTravelerNameTh = new Label();
                    lblTravelerNameTh.Font.Bold = true;
                    lblTravelerNameTh.Font.Size = FontUnit.Point(8);
                    lblTravelerNameTh.ID = "lblTraveler" + code + "Name_th";
                    lblTravelerNameTh.Text = "ชื่อ <br />";

                    HtmlInputText txtTravelerName = new HtmlInputText();
                    txtTravelerName.MaxLength = 60;
                    txtTravelerName.Style.Add("width", "195px");
                    txtTravelerName.ID = "txtTraveler" + code + "Name";
                    txtTravelerName.Value = dt.Rows[index]["ClientName"].ToString().Trim();//Request.Form["ctl00$MainContent$ddlTraveler" + code + "Name"];

                    tableTaveler_tdName.Controls.Add(lblTravelerName);
                    tableTaveler_tdName.Controls.Add(lblTravelerNameTh);
                    tableTaveler_tdName.Controls.Add(txtTravelerName);

                    tableTaveler_tr.Controls.Add(tableTaveler_tdName);

                    //-------------- TravelerSurname -----------------------
                    HtmlTableCell tableTaveler_tdSurname = new HtmlTableCell();
                    tableTaveler_tdSurname.Align = "left";

                    Label lblTravelerSurname = new Label();
                    lblTravelerSurname.Font.Bold = true;
                    lblTravelerSurname.ID = "lblTraveler" + code + "Surname";
                    lblTravelerSurname.Text = "Family name : <br/>";

                    Label lblTravelerSurnameTh = new Label();
                    lblTravelerSurnameTh.Font.Bold = true;
                    lblTravelerSurnameTh.Font.Size = FontUnit.Point(8);
                    lblTravelerSurnameTh.ID = "lblTraveler" + code + "Surname_th";
                    lblTravelerSurnameTh.Text = "นามสกุล <br />";

                    HtmlInputText txtTravelerSurname = new HtmlInputText();
                    txtTravelerSurname.MaxLength = 60;
                    txtTravelerSurname.Style.Add("width", "195px");
                    txtTravelerSurname.ID = "txtTraveler" + code + "Surname";
                    txtTravelerSurname.Value = dt.Rows[index]["ClientSurName"].ToString().Trim();//Request.Form["ctl00$MainContent$ddlTraveler" + code + "Surname"];

                    tableTaveler_tdSurname.Controls.Add(lblTravelerSurname);
                    tableTaveler_tdSurname.Controls.Add(lblTravelerSurnameTh);
                    tableTaveler_tdSurname.Controls.Add(txtTravelerSurname);

                    tableTaveler_tr.Controls.Add(tableTaveler_tdSurname);

                    //-------------- TravelerBirthday -----------------------
                    HtmlTableCell tableTaveler_tdBirthday = new HtmlTableCell();
                    tableTaveler_tdBirthday.Align = "left";

                    Label lblTravelerBirthday = new Label();
                    lblTravelerBirthday.Font.Bold = true;
                    lblTravelerBirthday.ID = "lblTraveler" + code + "Birthday";
                    lblTravelerBirthday.Text = "<font color=red>*</font>&nbsp;" + "DOB : <br/>&nbsp;&nbsp;&nbsp;";

                    Label lblTravelerBirthdayTh = new Label();
                    lblTravelerBirthdayTh.Font.Bold = true;
                    lblTravelerBirthdayTh.Font.Size = FontUnit.Point(8);
                    lblTravelerBirthdayTh.ID = "lblTraveler" + code + "Birthday_th";
                    lblTravelerBirthdayTh.Text = "วัน เดือน ปี เกิด <br />";

                    HtmlInputText txtTravelerBirthday = new HtmlInputText();
                    txtTravelerBirthday.ID = "txtTraveler" + code + "Birthday";
                    txtTravelerBirthday.MaxLength = 10;
                    txtTravelerBirthday.Style.Add("width", "80px");
                    txtTravelerBirthday.Value = TA.TAUtilities.ConvertDateTimeToEnShowDateString(Convert.ToDateTime(dt.Rows[index]["Birthday"].ToString().Trim()));   //Request.Form["ctl00$MainContent$ddlTraveler" + code + "Birthday"];

                    tableTaveler_tdBirthday.Controls.Add(lblTravelerBirthday);
                    tableTaveler_tdBirthday.Controls.Add(lblTravelerBirthdayTh);
                    tableTaveler_tdBirthday.Controls.Add(txtTravelerBirthday);

                    tableTaveler_tr.Controls.Add(tableTaveler_tdBirthday);

                    //--------------  TravelerPassportNo -----------------------
                    HtmlTableCell tableTaveler_tdPassportNo = new HtmlTableCell();
                    tableTaveler_tdPassportNo.Align = "left";

                    Label lblTravelerPassportNo = new Label();
                    lblTravelerPassportNo.Font.Bold = true;
                    lblTravelerPassportNo.ID = "lblTraveler" + code + "IDCard";
                    lblTravelerPassportNo.Text = "<font color=red>*</font>&nbsp;" + "ID Card : <br/>&nbsp;&nbsp;&nbsp;";

                    Label lblTravelerPassportNoTh = new Label();
                    lblTravelerPassportNoTh.Font.Bold = true;
                    lblTravelerPassportNoTh.Font.Size = FontUnit.Point(8);
                    lblTravelerPassportNoTh.ID = "lblTraveler" + code + "PassportNo_th";
                    lblTravelerPassportNoTh.Text = "เลขที่บัตรประชาชน <br />";

                    HtmlInputText txtTravelerPassportNo = new HtmlInputText();
                    txtTravelerPassportNo.ID = "txtTraveler" + code + "IDCard";
                    txtTravelerPassportNo.Style.Add("width", "120px");
                    txtTravelerPassportNo.MaxLength = 13;
                    txtTravelerPassportNo.Value = dt.Rows[index]["IDCard"].ToString().Trim() == string.Empty ? dt.Rows[index]["PassportID"].ToString().Trim() : dt.Rows[index]["IDCard"].ToString().Trim();

                    tableTaveler_tdPassportNo.Controls.Add(lblTravelerPassportNo);
                    tableTaveler_tdPassportNo.Controls.Add(lblTravelerPassportNoTh);
                    tableTaveler_tdPassportNo.Controls.Add(txtTravelerPassportNo);

                    tableTaveler_tr.Controls.Add(tableTaveler_tdPassportNo);

                    //--------------  TravelerTel -----------------------
                    HtmlTableCell tableTaveler_tdTel = new HtmlTableCell();
                    tableTaveler_tdTel.Align = "left";

                    Label lblTravelerTel = new Label();
                    lblTravelerTel.Font.Bold = true;
                    lblTravelerTel.ID = "lblTraveler" + code + "Tel";
                    lblTravelerTel.Text = "<font color=red>*</font>&nbsp;" + "Tel : <br/>&nbsp;&nbsp;&nbsp;";

                    Label lblTravelerTelTh = new Label();
                    lblTravelerTelTh.Font.Bold = true;
                    lblTravelerTelTh.Font.Size = FontUnit.Point(8);
                    lblTravelerTelTh.ID = "lblTraveler" + code + "Tel_th";
                    lblTravelerTelTh.Text = "เบอร์โทรศัพท์ <br />";

                    HtmlInputText txtTravelerTel = new HtmlInputText();
                    txtTravelerTel.ID = "txtTraveler" + code + "Tel";
                    txtTravelerTel.Style.Add("width", "120px");
                    txtTravelerTel.MaxLength = 30;
                    txtTravelerTel.Value = dt.Rows[index]["Tel"].ToString().Trim();//Request.Form["ctl00$MainContent$ddlTraveler" + code + "Tel"];

                    tableTaveler_tdTel.Controls.Add(lblTravelerTel);
                    tableTaveler_tdTel.Controls.Add(lblTravelerTelTh);
                    tableTaveler_tdTel.Controls.Add(txtTravelerTel);

                    tableTaveler_tr.Controls.Add(tableTaveler_tdTel);


                    //>>>>>>>>>>>>>>>  new rows -----------------------

                    HtmlTableRow tableTaveler_tr2 = new HtmlTableRow();
                    tableTaveler.Controls.Add(tableTaveler_tr2);

                    HtmlTableCell tableTaveler_td6 = new HtmlTableCell();
                    tableTaveler_td6.ColSpan = 6;
                    tableTaveler_td6.Align = "right";
                    tableTaveler_tr2.Controls.Add(tableTaveler_td6);

                    //-------------- TravelerOccupation -----------------------


                    HtmlTable tableTravelerOcc = new HtmlTable();
                    tableTravelerOcc.CellPadding = 2;
                    tableTravelerOcc.CellSpacing = 0;

                    tableTaveler_td6.Controls.Add(tableTravelerOcc);

                    HtmlTableRow tableTravelerOcc_row = new HtmlTableRow();
                    tableTravelerOcc.Controls.Add(tableTravelerOcc_row);

                    HtmlTableCell tableTaveler_tdOccupation1 = new HtmlTableCell();
                    tableTaveler_tdOccupation1.Align = "right";


                    Label lblTravelerOccupation = new Label();
                    lblTravelerOccupation.Font.Bold = true;
                    lblTravelerOccupation.ID = "lblTraveler" + code + "Occupation";
                    lblTravelerOccupation.Text = "Occupation : <br/>";

                    Label lblTravelerOccupationTh = new Label();
                    lblTravelerOccupationTh.Font.Bold = true;
                    lblTravelerOccupationTh.Font.Size = FontUnit.Point(8);
                    lblTravelerOccupationTh.ID = "lblTraveler" + code + "Occupation_th";
                    lblTravelerOccupationTh.Text = "อาชีพ";

                    HtmlTableCell tableTaveler_tdOccupation2 = new HtmlTableCell();
                    tableTaveler_tdOccupation2.Align = "left";
                    tableTaveler_tdOccupation2.VAlign = "top";

                    CheckBox chkTravelerOccupation = new CheckBox();
                    chkTravelerOccupation.ID = "chkTraveler" + code + "Occupation";
                    chkTravelerOccupation.Text = "Student";



                    if (!string.IsNullOrEmpty(dt.Rows[index]["isStudent"].ToString().Trim()))
                    {
                        if (dt.Rows[index]["isStudent"].ToString().Trim() == "0")
                        {
                            chkTravelerOccupation.Checked = false;
                        }
                        else
                        {
                            chkTravelerOccupation.Checked = true;
                        }

                    }


                    HtmlAnchor br = new HtmlAnchor();
                    br.InnerHtml = "<br/>";

                    tableTaveler_tdOccupation1.Controls.Add(lblTravelerOccupation);
                    tableTaveler_tdOccupation1.Controls.Add(lblTravelerOccupationTh);

                    tableTaveler_tdOccupation2.Controls.Add(chkTravelerOccupation);

                    tableTravelerOcc_row.Controls.Add(tableTaveler_tdOccupation1);
                    tableTravelerOcc_row.Controls.Add(tableTaveler_tdOccupation2);

                    //-------------- TravelerStatus -----------------------
                    HtmlTableRow tableTravelerStatus_row = new HtmlTableRow();
                    tableTravelerOcc.Controls.Add(tableTravelerStatus_row);

                    HtmlTableCell tableTaveler_tdStatus1 = new HtmlTableCell();
                    tableTaveler_tdStatus1.Align = "right";

                    Label lblTravelerStatus = new Label();
                    lblTravelerStatus.Font.Bold = true;
                    lblTravelerStatus.ID = "lblTraveler" + code + "Status";
                    lblTravelerStatus.Text = "Status : <br/>";

                    Label lblTravelerStatusTh = new Label();
                    lblTravelerStatusTh.Font.Bold = true;
                    lblTravelerStatusTh.Font.Size = FontUnit.Point(8);
                    lblTravelerStatusTh.ID = "lblTraveler" + code + "Status_th";
                    lblTravelerStatusTh.Text = "สถานะ ";

                    HtmlTableCell tableTaveler_tdStatus2 = new HtmlTableCell();
                    tableTaveler_tdStatus2.Align = "left";
                    tableTaveler_tdStatus2.VAlign = "top";
                    tableTaveler_tdStatus2.Width = "80px";

                    CheckBox chkTravelerStatus = new CheckBox();
                    chkTravelerStatus.ID = "chkTraveler" + code + "Status";
                    chkTravelerStatus.Text = "Single";
                    if (!string.IsNullOrEmpty(dt.Rows[index]["isSingle"].ToString().Trim()))
                    {
                        if (dt.Rows[index]["isSingle"].ToString().Trim() == "0")
                        {
                            chkTravelerStatus.Checked = false;
                        }
                        else
                        {
                            chkTravelerStatus.Checked = true;
                        }

                    }


                    tableTaveler_tdStatus1.Controls.Add(lblTravelerStatus);
                    tableTaveler_tdStatus1.Controls.Add(lblTravelerStatusTh);
                    tableTaveler_tdStatus2.Controls.Add(chkTravelerStatus);

                    tableTravelerStatus_row.Controls.Add(tableTaveler_tdStatus1);
                    tableTravelerStatus_row.Controls.Add(tableTaveler_tdStatus2);

                    //-----------------end table 1-----------------------------
                    #endregion

                    //------------------table Beneficialy---------------------
                    HtmlTable tableBeneficialy1 = new HtmlTable();
                    tableBeneficialy1.Align = "center";
                    tableBeneficialy1.Width = "80%";

                    div.Controls.Add(tableBeneficialy1);


                    #region Table Beneficialy

                    //Bind benefit traveler

                    PAGetBindPolicyBLL clsPAGetBindPolicyBLL = new PAGetBindPolicyBLL();
                    DataTable dtbenefit = clsPAGetBindPolicyBLL.GetBindBeneficiaryOfInsured(JobNo, code);

                    //Benefit Group by TravelerID
                    if (dtbenefit.Rows.Count > 0)
                    {
                        #region Table Beneficialy 1
                        //-------------- Beneficialy row 1----------------------
                        HtmlTableRow tableBeneficialy1_tr = new HtmlTableRow();

                        tableBeneficialy1.Controls.Add(tableBeneficialy1_tr);

                        HtmlTableCell tableBeneficialy1_tdBeneficialy = new HtmlTableCell();
                        tableBeneficialy1_tdBeneficialy.Align = "left";
                        tableBeneficialy1_tdBeneficialy.Width = "80px";

                        Label lblTravelerBeneficialy = new Label();
                        lblTravelerBeneficialy.ID = "lblTraveler" + code + "Beneficialy";
                        lblTravelerBeneficialy.Font.Bold = true;
                        lblTravelerBeneficialy.Text = "Beneficiary :";

                        Label lblTravelerBeneficialyTh = new Label();
                        lblTravelerBeneficialyTh.ID = "lblTraveler" + code + "Beneficialy_th";
                        lblTravelerBeneficialyTh.Font.Bold = true;
                        lblTravelerBeneficialyTh.Font.Size = FontUnit.Point(8);
                        lblTravelerBeneficialyTh.Text = "ผู้รับประโยชน์";

                        tableBeneficialy1_tdBeneficialy.Controls.Add(lblTravelerBeneficialy);
                        tableBeneficialy1_tdBeneficialy.Controls.Add(lblTravelerBeneficialyTh);

                        tableBeneficialy1_tr.Controls.Add(tableBeneficialy1_tdBeneficialy);

                        HtmlTableCell tableBeneficialy1_tdBeneficialyHeir = new HtmlTableCell();
                        tableBeneficialy1_tdBeneficialyHeir.Align = "left";
                        tableBeneficialy1_tdBeneficialyHeir.VAlign = "top";

                        CheckBox chkTravelerBeneficialyHeir = new CheckBox();
                        chkTravelerBeneficialyHeir.ID = "chkTraveler" + code + "BeneficialyHeir";

                        chkTravelerBeneficialyHeir.Text = "&nbsp;Estate of the Insured person /กองมรดกของผู้เอาประกันภัย";

                        chkTravelerBeneficialyHeir.Checked = false;

                        tableBeneficialy1_tdBeneficialyHeir.Controls.Add(chkTravelerBeneficialyHeir);

                        tableBeneficialy1_tr.Controls.Add(tableBeneficialy1_tdBeneficialyHeir);

                        #endregion

                        HtmlTable tableBeneficialy2 = new HtmlTable();
                        tableBeneficialy2.Align = "center";
                        tableBeneficialy2.Width = "80%";

                        div.Controls.Add(tableBeneficialy2);

                        HtmlTableRow tableBeneficialy2_tr = new HtmlTableRow();

                        tableBeneficialy2.Controls.Add(tableBeneficialy2_tr);

                        //HAVE DATA
                        int loopcount = 0;
                        foreach (DataRow row in dtbenefit.Rows)
                        {
                            loopcount += 1;
                            string m_travelerid = row["InsuredID"].ToString().Trim();
                            string m_seq = row["BeneficiaryID"].ToString().Trim();
                            for (int j = 1; j < 5; j++)
                            {
                                if (m_seq == j.ToString()) //1 == 1
                                {
                                    #region "Bind Benefit from DB"
                                    HtmlTableRow tableBeneficialy2_tr2 = new HtmlTableRow();
                                    tableBeneficialy2.Controls.Add(tableBeneficialy2_tr2);

                                    //---------------------- lblTraveler1BeneficialyTitle1- ---------------
                                    HtmlTableCell tableBeneficialy2_tdBeneficialyTitle = new HtmlTableCell();
                                    tableBeneficialy2_tdBeneficialyTitle.Align = "left";

                                    Label lblTravelerBeneficialyTitle = new Label();
                                    lblTravelerBeneficialyTitle.ID = "lblTraveler" + code + "BeneficialyTitle" + j.ToString();
                                    lblTravelerBeneficialyTitle.Font.Bold = true;
                                    lblTravelerBeneficialyTitle.Text = "<font color=red>*</font>&nbsp;" + "Title : <br/>&nbsp;&nbsp;&nbsp;";

                                    Label lblTravelerBeneficialyTitleTh = new Label();
                                    lblTravelerBeneficialyTitleTh.ID = "lblTraveler" + code + "BeneficialyTitle" + j.ToString() + "_th";
                                    lblTravelerBeneficialyTitleTh.Font.Bold = true;
                                    lblTravelerBeneficialyTitleTh.Font.Size = FontUnit.Point(8);
                                    lblTravelerBeneficialyTitleTh.Text = "คำนำหน้าชื่อ <br/>";

                                    DropDownList ddlTravelerBeneficialyTitle = new DropDownList();
                                    ddlTravelerBeneficialyTitle.Width = 110;
                                    ddlTravelerBeneficialyTitle.ID = "ddlTraveler" + code + "BeneficialyTitle" + j.ToString();

                                    SetTitleToDropdownList(ddlTravelerBeneficialyTitle, this.ddlLanguage.SelectedValue);
                                   
                                    ddlTravelerBeneficialyTitle.SelectedValue = row["BeneficiaryTitle"].ToString().Trim();

                                    //-------VVVVVVVVVVVVVVVVVVVVVVVVVVV------------

                                    if (j == 1)
                                    {
                                        tableBeneficialy2_tdBeneficialyTitle.Controls.Add(lblTravelerBeneficialyTitle);
                                        tableBeneficialy2_tdBeneficialyTitle.Controls.Add(lblTravelerBeneficialyTitleTh);

                                    }
                                    tableBeneficialy2_tdBeneficialyTitle.Controls.Add(ddlTravelerBeneficialyTitle);

                                    tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyTitle);

                                    //---------------------- lblTraveler1BeneficialyName1- ---------------
                                    HtmlTableCell tableBeneficialy2_tdBeneficialyName = new HtmlTableCell();
                                    tableBeneficialy2_tdBeneficialyName.Align = "left";

                                    Label lblTravelerBeneficialyName = new Label();
                                    lblTravelerBeneficialyName.ID = "lblTraveler" + code + "BeneficialyName" + j.ToString();
                                    lblTravelerBeneficialyName.Font.Bold = true;
                                    lblTravelerBeneficialyName.Text = "<font color=red>*</font>&nbsp;" + "Name : <br/>&nbsp;&nbsp;&nbsp;";

                                    Label lblTravelerBeneficialyNameTh = new Label();
                                    lblTravelerBeneficialyNameTh.ID = "lblTraveler" + code + "BeneficialyName" + j.ToString() + "_th";
                                    lblTravelerBeneficialyNameTh.Font.Bold = true;
                                    lblTravelerBeneficialyNameTh.Font.Size = FontUnit.Point(8);
                                    lblTravelerBeneficialyNameTh.Text = "ชื่อ <br/>";

                                    HtmlInputText txtTravelerBeneficialyName = new HtmlInputText();
                                    txtTravelerBeneficialyName.MaxLength = 100;
                                    txtTravelerBeneficialyName.Style.Add("width", "195px");
                                    txtTravelerBeneficialyName.ID = "txtTraveler" + code + "BeneficialyName" + j.ToString();
                                    txtTravelerBeneficialyName.Value = row["BeneficiaryName"].ToString().Trim(); //Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialyName" + j.ToString()];

                                    if (j == 1)
                                    {
                                        tableBeneficialy2_tdBeneficialyName.Controls.Add(lblTravelerBeneficialyName);
                                        tableBeneficialy2_tdBeneficialyName.Controls.Add(lblTravelerBeneficialyNameTh);
 
                                    }
                                    tableBeneficialy2_tdBeneficialyName.Controls.Add(txtTravelerBeneficialyName);

                                    tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyName);

                                    //---------------------- lblTraveler1BeneficialySurname1- ---------------
                                    HtmlTableCell tableBeneficialy2_tdBeneficialySurname = new HtmlTableCell();
                                    tableBeneficialy2_tdBeneficialySurname.Align = "left";

                                    Label lblTravelerBeneficialySurname = new Label();
                                    lblTravelerBeneficialySurname.ID = "lblTraveler" + code + "BeneficialySurname" + j.ToString();
                                    lblTravelerBeneficialySurname.Font.Bold = true;
                                    lblTravelerBeneficialySurname.Text = "<font color=red>*</font>&nbsp;" + "Family name : <br/>&nbsp;&nbsp;&nbsp;";

                                    Label lblTravelerBeneficialySurnameTh = new Label();
                                    lblTravelerBeneficialySurnameTh.ID = "lblTraveler" + code + "BeneficialySurname" + j.ToString() + "_th";
                                    lblTravelerBeneficialySurnameTh.Font.Bold = true;
                                    lblTravelerBeneficialySurnameTh.Font.Size = FontUnit.Point(8);
                                    lblTravelerBeneficialySurnameTh.Text = "นามสกุล <br/>";

                                    HtmlInputText txtTravelerBeneficialySurname = new HtmlInputText();
                                    txtTravelerBeneficialySurname.Style.Add("width", "195px");
                                    txtTravelerBeneficialySurname.ID = "txtTraveler" + code + "BeneficialySurname" + j.ToString();
                                    txtTravelerBeneficialySurname.Value = row["BeneficiarySurName"].ToString().Trim(); //Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialySurname" + j.ToString()];


                                    if (j == 1)
                                    {
                                        tableBeneficialy2_tdBeneficialySurname.Controls.Add(lblTravelerBeneficialySurname);
                                        tableBeneficialy2_tdBeneficialySurname.Controls.Add(lblTravelerBeneficialySurnameTh);

                                    }
                                    tableBeneficialy2_tdBeneficialySurname.Controls.Add(txtTravelerBeneficialySurname);

                                    tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialySurname);

                                    //---------------------- lblTraveler1BeneficialyRelationShip1- ---------------
                                    HtmlTableCell tableBeneficialy2_tdBeneficialyRelationShip = new HtmlTableCell();
                                    tableBeneficialy2_tdBeneficialyRelationShip.Align = "left";

                                    Label lblTravelerBeneficialyRelationShip = new Label();
                                    lblTravelerBeneficialyRelationShip.ID = "lblTraveler" + code + "BeneficialyRelationShip" + j.ToString();
                                    lblTravelerBeneficialyRelationShip.Font.Bold = true;
                                    lblTravelerBeneficialyRelationShip.Text = "RelationShip : <br/>";

                                    Label lblTravelerBeneficialyRelationShipTh = new Label();
                                    lblTravelerBeneficialyRelationShipTh.ID = "lblTraveler" + code + "BeneficialyRelationShip" + j.ToString() + "_th";
                                    lblTravelerBeneficialyRelationShipTh.Font.Bold = true;
                                    lblTravelerBeneficialyRelationShipTh.Font.Size = FontUnit.Point(8);
                                    lblTravelerBeneficialyRelationShipTh.Text = "ความสัมพันธ์กับผู้เอาประกันภัย<br/>";

                                    DropDownList ddlTravelerBeneficialyRelationShip = new DropDownList();
                                    ddlTravelerBeneficialyRelationShip.ID = "ddlTraveler" + code + "BeneficialyRelationShip" + j.ToString();
                                    ddlTravelerBeneficialyRelationShip.Style.Add("width", "160px");

                                    SetRelationToDropdownList(ddlTravelerBeneficialyRelationShip, this.ddlLanguage.SelectedValue);
                                    ddlTravelerBeneficialyRelationShip.SelectedValue = row["BeneficiaryRelation"].ToString().Trim(); //Request.Form["ctl00$MainContent$ddlTraveler" + code + "BeneficialyRelationShip" + j.ToString()];
                                    //-------VVVVVVVVVVVVVVVVVVVVVVVVVVV------------
                                    

                                    if (j == 1)
                                    {
                                        tableBeneficialy2_tdBeneficialyRelationShip.Controls.Add(lblTravelerBeneficialyRelationShip);
                                        tableBeneficialy2_tdBeneficialyRelationShip.Controls.Add(lblTravelerBeneficialyRelationShipTh);
                                        
                                    }
                                    tableBeneficialy2_tdBeneficialyRelationShip.Controls.Add(ddlTravelerBeneficialyRelationShip);

                                    tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyRelationShip);

                                    #region #//Part of Traveler Beneficiary Ratio
                                    HtmlTableCell tableBeneficialy2_tdBeneficialyRatio = new HtmlTableCell();
                                    tableBeneficialy2_tdBeneficialyRatio.Align = "left";

                                    Label lblTravelerBeneficialyRatio = new Label();
                                    lblTravelerBeneficialyRatio.ID = "lblTraveler" + code + "BeneficialyRatio" + j.ToString();
                                    lblTravelerBeneficialyRatio.Font.Bold = true;
                                    lblTravelerBeneficialyRatio.Text = "<font color=red>*</font>&nbsp;" + "Ratio : <br/>";

                                    Label lblTravelerBeneficialyRatioTh = new Label();
                                    lblTravelerBeneficialyRatioTh.ID = "lblTraveler" + code + "BeneficialyRatio" + j.ToString() + "_th";
                                    lblTravelerBeneficialyRatioTh.Font.Bold = true;
                                    lblTravelerBeneficialyRatioTh.Font.Size = FontUnit.Point(8);
                                    lblTravelerBeneficialyRatioTh.Text = "สัดส่วน<br/>";

                                    HtmlInputText txtTravelerBeneficialyRatio = new HtmlInputText();
                                    txtTravelerBeneficialyRatio.ID = "txtTraveler" + code + "BeneficialyRatio" + j.ToString();
                                    txtTravelerBeneficialyRatio.Style.Add("width", "70px");
                                    txtTravelerBeneficialyRatio.MaxLength = 3;
                                    txtTravelerBeneficialyRatio.Attributes.Add("onkeypress", "return numbersonly(event);");
                                    txtTravelerBeneficialyRatio.Value = row["BeneficiaryRatio"].ToString().Trim();//Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialyRatio" + j.ToString()];

                                    if (j == 1)
                                    {
                                        tableBeneficialy2_tdBeneficialyRatio.Controls.Add(lblTravelerBeneficialyRatio);
                                        tableBeneficialy2_tdBeneficialyRatio.Controls.Add(lblTravelerBeneficialyRatioTh);
                                    }

                                    tableBeneficialy2_tdBeneficialyRatio.Controls.Add(txtTravelerBeneficialyRatio);

                                    tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyRatio);

                                    #endregion

                                    //---------------------- lblTraveler1BeneficialyTel1- ---------------
                                    HtmlTableCell tableBeneficialy2_tdBeneficialyTel = new HtmlTableCell();
                                    tableBeneficialy2_tdBeneficialyTel.Align = "left";

                                    Label lblTravelerBeneficialyTel = new Label();
                                    lblTravelerBeneficialyTel.ID = "lblTraveler" + code + "BeneficialyTel" + j.ToString();
                                    lblTravelerBeneficialyTel.Font.Bold = true;
                                    lblTravelerBeneficialyTel.Text = "Tel : <br/>";

                                    Label lblTravelerBeneficialyTelTh = new Label();
                                    lblTravelerBeneficialyTelTh.ID = "lblTraveler" + code + "BeneficialyTel" + j.ToString() + "_th";
                                    lblTravelerBeneficialyTelTh.Font.Bold = true;
                                    lblTravelerBeneficialyTelTh.Font.Size = FontUnit.Point(8);
                                    lblTravelerBeneficialyTelTh.Text = "เบอร์โทรศัพท์<br/>";

                                    HtmlInputText txtTravelerBeneficialyTel = new HtmlInputText();
                                    txtTravelerBeneficialyTel.ID = "txtTraveler" + code + "BeneficialyTel" + j.ToString();
                                    txtTravelerBeneficialyTel.Style.Add("width", "100px");
                                    txtTravelerBeneficialyTel.MaxLength = 100;
                                    txtTravelerBeneficialyTel.Value = row["BeneficiaryTel"].ToString().Trim(); //Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialyTel" + j.ToString()];


                                    if (j == 1)
                                    {
                                        tableBeneficialy2_tdBeneficialyTel.Controls.Add(lblTravelerBeneficialyTel);
                                        tableBeneficialy2_tdBeneficialyTel.Controls.Add(lblTravelerBeneficialyTelTh);

                                    }

                                    tableBeneficialy2_tdBeneficialyTel.Controls.Add(txtTravelerBeneficialyTel);

                                    tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyTel);
                                    #endregion
                                }
                            }
                        }
                        if (loopcount < 3)
                        {
                            for (int j = loopcount + 1; j < 5; j++)
                            {
                                #region "Bind Benefit default"
                                HtmlTableRow tableBeneficialy2_tr2 = new HtmlTableRow();
                                tableBeneficialy2.Controls.Add(tableBeneficialy2_tr2);

                                //---------------------- lblTraveler1BeneficialyTitle1- ---------------
                                HtmlTableCell tableBeneficialy2_tdBeneficialyTitle = new HtmlTableCell();
                                tableBeneficialy2_tdBeneficialyTitle.Align = "left";

                                Label lblTravelerBeneficialyTitle = new Label();
                                lblTravelerBeneficialyTitle.ID = "lblTraveler" + code + "BeneficialyTitle" + j.ToString();
                                lblTravelerBeneficialyTitle.Font.Bold = true;
                                lblTravelerBeneficialyTitle.Text = "<font color=red>*</font>&nbsp;" + "Title : <br/>&nbsp;&nbsp;&nbsp;";

                                Label lblTravelerBeneficialyTitleTh = new Label();
                                lblTravelerBeneficialyTitleTh.ID = "lblTraveler" + code + "BeneficialyTitle" + j.ToString() + "_th";
                                lblTravelerBeneficialyTitleTh.Font.Bold = true;
                                lblTravelerBeneficialyTitleTh.Font.Size = FontUnit.Point(8);
                                lblTravelerBeneficialyTitleTh.Text = "คำนำหน้าชื่อ <br/>";

                                DropDownList ddlTravelerBeneficialyTitle = new DropDownList();
                                ddlTravelerBeneficialyTitle.Width = 110;
                                ddlTravelerBeneficialyTitle.ID = "ddlTraveler" + code + "BeneficialyTitle" + j.ToString();

                                SetTitleToDropdownList(ddlTravelerBeneficialyTitle,this.ddlLanguage.SelectedValue);
                                
                                ddlTravelerBeneficialyTitle.SelectedValue = Request.Form["ctl00$MainContent$ddlTraveler" + code + "BeneficialyTitle" + j.ToString()];

                                //-------VVVVVVVVVVVVVVVVVVVVVVVVVVV------------

                                if (j == 1)
                                {
                                    tableBeneficialy2_tdBeneficialyTitle.Controls.Add(lblTravelerBeneficialyTitle);
                                    tableBeneficialy2_tdBeneficialyTitle.Controls.Add(lblTravelerBeneficialyTitleTh);

                                }
                                tableBeneficialy2_tdBeneficialyTitle.Controls.Add(ddlTravelerBeneficialyTitle);

                                tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyTitle);

                                //---------------------- lblTraveler1BeneficialyName1- ---------------
                                HtmlTableCell tableBeneficialy2_tdBeneficialyName = new HtmlTableCell();
                                tableBeneficialy2_tdBeneficialyName.Align = "left";

                                Label lblTravelerBeneficialyName = new Label();
                                lblTravelerBeneficialyName.ID = "lblTraveler" + code + "BeneficialyName" + j.ToString();
                                lblTravelerBeneficialyName.Font.Bold = true;
                                lblTravelerBeneficialyName.Text = "<font color=red>*</font>&nbsp;" + "Name : <br/>&nbsp;&nbsp;&nbsp;";

                                Label lblTravelerBeneficialyNameTh = new Label();
                                lblTravelerBeneficialyNameTh.ID = "lblTraveler" + code + "BeneficialyName" + j.ToString() + "_th";
                                lblTravelerBeneficialyNameTh.Font.Bold = true;
                                lblTravelerBeneficialyNameTh.Font.Size = FontUnit.Point(8);
                                lblTravelerBeneficialyNameTh.Text = "ชื่อ <br/>";

                                HtmlInputText txtTravelerBeneficialyName = new HtmlInputText();
                                txtTravelerBeneficialyName.MaxLength = 100;
                                txtTravelerBeneficialyName.Style.Add("width", "195px");
                                txtTravelerBeneficialyName.ID = "txtTraveler" + code + "BeneficialyName" + j.ToString();
                                txtTravelerBeneficialyName.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialyName" + j.ToString()];

                                if (j == 1)
                                {
                                    tableBeneficialy2_tdBeneficialyName.Controls.Add(lblTravelerBeneficialyName);
                                    tableBeneficialy2_tdBeneficialyName.Controls.Add(lblTravelerBeneficialyNameTh);

                                }
                                tableBeneficialy2_tdBeneficialyName.Controls.Add(txtTravelerBeneficialyName);

                                tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyName);

                                //---------------------- lblTraveler1BeneficialySurname1- ---------------
                                HtmlTableCell tableBeneficialy2_tdBeneficialySurname = new HtmlTableCell();
                                tableBeneficialy2_tdBeneficialySurname.Align = "left";

                                Label lblTravelerBeneficialySurname = new Label();
                                lblTravelerBeneficialySurname.ID = "lblTraveler" + code + "BeneficialySurname" + j.ToString();
                                lblTravelerBeneficialySurname.Font.Bold = true;
                                lblTravelerBeneficialySurname.Text = "<font color=red>*</font>&nbsp;" + "Family name : <br/>&nbsp;&nbsp;&nbsp;";

                                Label lblTravelerBeneficialySurnameTh = new Label();
                                lblTravelerBeneficialySurnameTh.ID = "lblTraveler" + code + "BeneficialySurname" + j.ToString() + "_th";
                                lblTravelerBeneficialySurnameTh.Font.Bold = true;
                                lblTravelerBeneficialySurnameTh.Font.Size = FontUnit.Point(8);
                                lblTravelerBeneficialySurnameTh.Text = "นามสกุล <br/>";

                                HtmlInputText txtTravelerBeneficialySurname = new HtmlInputText();
                                txtTravelerBeneficialySurname.Style.Add("width", "195px");
                                txtTravelerBeneficialySurname.ID = "txtTraveler" + code + "BeneficialySurname" + j.ToString();
                                txtTravelerBeneficialySurname.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialySurname" + j.ToString()];


                                if (j == 1)
                                {
                                    tableBeneficialy2_tdBeneficialySurname.Controls.Add(lblTravelerBeneficialySurname);
                                    tableBeneficialy2_tdBeneficialySurname.Controls.Add(lblTravelerBeneficialySurnameTh);

                                }
                                tableBeneficialy2_tdBeneficialySurname.Controls.Add(txtTravelerBeneficialySurname);

                                tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialySurname);

                                //---------------------- lblTraveler1BeneficialyRelationShip1- ---------------
                                HtmlTableCell tableBeneficialy2_tdBeneficialyRelationShip = new HtmlTableCell();
                                tableBeneficialy2_tdBeneficialyRelationShip.Align = "left";

                                Label lblTravelerBeneficialyRelationShip = new Label();
                                lblTravelerBeneficialyRelationShip.ID = "lblTraveler" + code + "BeneficialyRelationShip" + j.ToString();
                                lblTravelerBeneficialyRelationShip.Font.Bold = true;
                                lblTravelerBeneficialyRelationShip.Text = "RelationShip : <br/>";

                                Label lblTravelerBeneficialyRelationShipTh = new Label();
                                lblTravelerBeneficialyRelationShipTh.ID = "lblTraveler" + code + "BeneficialyRelationShip" + j.ToString() + "_th";
                                lblTravelerBeneficialyRelationShipTh.Font.Bold = true;
                                lblTravelerBeneficialyRelationShipTh.Font.Size = FontUnit.Point(8);
                                lblTravelerBeneficialyRelationShipTh.Text = "ความสัมพันธ์กับผู้เอาประกันภัย<br/>";

                                DropDownList ddlTravelerBeneficialyRelationShip = new DropDownList();
                                ddlTravelerBeneficialyRelationShip.ID = "ddlTraveler" + code + "BeneficialyRelationShip" + j.ToString();
                                ddlTravelerBeneficialyRelationShip.Style.Add("width", "150px");

                                SetRelationToDropdownList(ddlTravelerBeneficialyRelationShip, this.ddlLanguage.SelectedValue);
                                ddlTravelerBeneficialyRelationShip.SelectedValue = Request.Form["ctl00$MainContent$ddlTraveler" + code + "BeneficialyRelationShip" + j.ToString()];
                                //-------VVVVVVVVVVVVVVVVVVVVVVVVVVV------------
                                

                                if (j == 1)
                                {
                                    tableBeneficialy2_tdBeneficialyRelationShip.Controls.Add(lblTravelerBeneficialyRelationShip);
                                    tableBeneficialy2_tdBeneficialyRelationShip.Controls.Add(lblTravelerBeneficialyRelationShipTh);

                                }
                                tableBeneficialy2_tdBeneficialyRelationShip.Controls.Add(ddlTravelerBeneficialyRelationShip);

                                tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyRelationShip);

                                #region #//Part of Traveler Beneficiary Ratio
                                HtmlTableCell tableBeneficialy2_tdBeneficialyRatio = new HtmlTableCell();
                                tableBeneficialy2_tdBeneficialyRatio.Align = "left";

                                Label lblTravelerBeneficialyRatio = new Label();
                                lblTravelerBeneficialyRatio.ID = "lblTraveler" + code + "BeneficialyRatio" + j.ToString();
                                lblTravelerBeneficialyRatio.Font.Bold = true;
                                lblTravelerBeneficialyRatio.Text = "<font color=red>*</font>&nbsp;" + "Ratio : <br/>";

                                Label lblTravelerBeneficialyRatioTh = new Label();
                                lblTravelerBeneficialyRatioTh.ID = "lblTraveler" + code + "BeneficialyRatio" + j.ToString() + "_th";
                                lblTravelerBeneficialyRatioTh.Font.Bold = true;
                                lblTravelerBeneficialyRatioTh.Font.Size = FontUnit.Point(8);
                                lblTravelerBeneficialyRatioTh.Text = "สัดส่วน<br/>";

                                HtmlInputText txtTravelerBeneficialyRatio = new HtmlInputText();
                                txtTravelerBeneficialyRatio.ID = "txtTraveler" + code + "BeneficialyRatio" + j.ToString();
                                txtTravelerBeneficialyRatio.Style.Add("width", "70px");
                                txtTravelerBeneficialyRatio.MaxLength = 3;
                                txtTravelerBeneficialyRatio.Attributes.Add("onkeypress", "return numbersonly(event);");
                                txtTravelerBeneficialyRatio.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialyRatio" + j.ToString()];

                                if (j == 1)
                                {
                                    tableBeneficialy2_tdBeneficialyRatio.Controls.Add(lblTravelerBeneficialyRatio);
                                    tableBeneficialy2_tdBeneficialyRatio.Controls.Add(lblTravelerBeneficialyRatioTh);
                                }

                                tableBeneficialy2_tdBeneficialyRatio.Controls.Add(txtTravelerBeneficialyRatio);

                                tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyRatio);

                                #endregion

                                //---------------------- lblTraveler1BeneficialyTel1- ---------------
                                HtmlTableCell tableBeneficialy2_tdBeneficialyTel = new HtmlTableCell();
                                tableBeneficialy2_tdBeneficialyTel.Align = "left";

                                Label lblTravelerBeneficialyTel = new Label();
                                lblTravelerBeneficialyTel.ID = "lblTraveler" + code + "BeneficialyTel" + j.ToString();
                                lblTravelerBeneficialyTel.Font.Bold = true;
                                lblTravelerBeneficialyTel.Text = "Tel : <br/>";

                                Label lblTravelerBeneficialyTelTh = new Label();
                                lblTravelerBeneficialyTelTh.ID = "lblTraveler" + code + "BeneficialyTel" + j.ToString() + "_th";
                                lblTravelerBeneficialyTelTh.Font.Bold = true;
                                lblTravelerBeneficialyTelTh.Font.Size = FontUnit.Point(8);
                                lblTravelerBeneficialyTelTh.Text = "เบอร์โทรศัพท์<br/>";

                                HtmlInputText txtTravelerBeneficialyTel = new HtmlInputText();
                                txtTravelerBeneficialyTel.ID = "txtTraveler" + code + "BeneficialyTel" + j.ToString();
                                txtTravelerBeneficialyTel.Style.Add("width", "120px");
                                txtTravelerBeneficialyTel.MaxLength = 100;
                                txtTravelerBeneficialyTel.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialyTel" + j.ToString()];


                                if (j == 1)
                                {
                                    tableBeneficialy2_tdBeneficialyTel.Controls.Add(lblTravelerBeneficialyTel);
                                    tableBeneficialy2_tdBeneficialyTel.Controls.Add(lblTravelerBeneficialyTelTh);

                                }

                                tableBeneficialy2_tdBeneficialyTel.Controls.Add(txtTravelerBeneficialyTel);

                                tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyTel);
                                #endregion
                            }
                        }
                    }
                    else
                    {
                        /// No benefit
                        #region Table Beneficialy 1
                        //-------------- Beneficialy row 1----------------------
                        HtmlTableRow tableBeneficialy1_tr = new HtmlTableRow();

                        tableBeneficialy1.Controls.Add(tableBeneficialy1_tr);

                        HtmlTableCell tableBeneficialy1_tdBeneficialy = new HtmlTableCell();
                        tableBeneficialy1_tdBeneficialy.Align = "left";
                        tableBeneficialy1_tdBeneficialy.Width = "80px";

                        Label lblTravelerBeneficialy = new Label();
                        lblTravelerBeneficialy.ID = "lblTraveler" + code + "Beneficialy";
                        lblTravelerBeneficialy.Font.Bold = true;
                        lblTravelerBeneficialy.Text = "Beneficiary :";

                        Label lblTravelerBeneficialyTh = new Label();
                        lblTravelerBeneficialyTh.ID = "lblTraveler" + code + "Beneficialy_th";
                        lblTravelerBeneficialyTh.Font.Bold = true;
                        lblTravelerBeneficialyTh.Font.Size = FontUnit.Point(8);
                        lblTravelerBeneficialyTh.Text = "ผู้รับประโยชน์";

                        tableBeneficialy1_tdBeneficialy.Controls.Add(lblTravelerBeneficialy);
                        tableBeneficialy1_tdBeneficialy.Controls.Add(lblTravelerBeneficialyTh);

                        tableBeneficialy1_tr.Controls.Add(tableBeneficialy1_tdBeneficialy);

                        HtmlTableCell tableBeneficialy1_tdBeneficialyHeir = new HtmlTableCell();
                        tableBeneficialy1_tdBeneficialyHeir.Align = "left";
                        tableBeneficialy1_tdBeneficialyHeir.VAlign = "top";

                        CheckBox chkTravelerBeneficialyHeir = new CheckBox();
                        chkTravelerBeneficialyHeir.ID = "chkTraveler" + code + "BeneficialyHeir";

                        chkTravelerBeneficialyHeir.Text = "&nbsp;Estate of the Insured person /กองมรดกของผู้เอาประกันภัย";

                        if (Request.Form["ctl00$MainContent$chkTraveler" + code + "BeneficialyHeir"] == "")
                        {
                            chkTravelerBeneficialyHeir.Checked = Convert.ToBoolean(Request.Form["ctl00$MainContent$chkTraveler" + code + "BeneficialyHeir"]);
                        }
                        else
                        {
                            chkTravelerBeneficialyHeir.Checked = true;
                        }

                        tableBeneficialy1_tdBeneficialyHeir.Controls.Add(chkTravelerBeneficialyHeir);

                        tableBeneficialy1_tr.Controls.Add(tableBeneficialy1_tdBeneficialyHeir);

                        #endregion

                        HtmlTable tableBeneficialy2 = new HtmlTable();
                        tableBeneficialy2.Align = "center";
                        tableBeneficialy2.Width = "80%";

                        div.Controls.Add(tableBeneficialy2);

                        HtmlTableRow tableBeneficialy2_tr = new HtmlTableRow();

                        tableBeneficialy2.Controls.Add(tableBeneficialy2_tr);

                        for (int j = 1; j < 5; j++)
                        {
                            HtmlTableRow tableBeneficialy2_tr2 = new HtmlTableRow();
                            tableBeneficialy2.Controls.Add(tableBeneficialy2_tr2);

                            //---------------------- lblTraveler1BeneficialyTitle1- ---------------
                            HtmlTableCell tableBeneficialy2_tdBeneficialyTitle = new HtmlTableCell();
                            tableBeneficialy2_tdBeneficialyTitle.Align = "left";

                            Label lblTravelerBeneficialyTitle = new Label();
                            lblTravelerBeneficialyTitle.ID = "lblTraveler" + code + "BeneficialyTitle" + j.ToString();
                            lblTravelerBeneficialyTitle.Font.Bold = true;
                            lblTravelerBeneficialyTitle.Text = "<font color=red>*</font>&nbsp;" + "Title : <br/>&nbsp;&nbsp;&nbsp;";

                            Label lblTravelerBeneficialyTitleTh = new Label();
                            lblTravelerBeneficialyTitleTh.ID = "lblTraveler" + code + "BeneficialyTitle" + j.ToString() + "_th";
                            lblTravelerBeneficialyTitleTh.Font.Bold = true;
                            lblTravelerBeneficialyTitleTh.Font.Size = FontUnit.Point(8);
                            lblTravelerBeneficialyTitleTh.Text = "คำนำหน้าชื่อ <br/>";

                            DropDownList ddlTravelerBeneficialyTitle = new DropDownList();
                            ddlTravelerBeneficialyTitle.Width = 110;
                            ddlTravelerBeneficialyTitle.ID = "ddlTraveler" + code + "BeneficialyTitle" + j.ToString();

                            SetTitleToDropdownList(ddlTravelerBeneficialyTitle, this.ddlLanguage.SelectedValue.Trim());

                            ddlTravelerBeneficialyTitle.SelectedValue = Request.Form["ctl00$MainContent$ddlTraveler" + code + "BeneficialyTitle" + j.ToString()];

                            //-------VVVVVVVVVVVVVVVVVVVVVVVVVVV------------

                            if (j == 1)
                            {
                                tableBeneficialy2_tdBeneficialyTitle.Controls.Add(lblTravelerBeneficialyTitle);
                                tableBeneficialy2_tdBeneficialyTitle.Controls.Add(lblTravelerBeneficialyTitleTh);

                            }
                            tableBeneficialy2_tdBeneficialyTitle.Controls.Add(ddlTravelerBeneficialyTitle);

                            tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyTitle);

                            //---------------------- lblTraveler1BeneficialyName1- ---------------
                            HtmlTableCell tableBeneficialy2_tdBeneficialyName = new HtmlTableCell();
                            tableBeneficialy2_tdBeneficialyName.Align = "left";

                            Label lblTravelerBeneficialyName = new Label();
                            lblTravelerBeneficialyName.ID = "lblTraveler" + code + "BeneficialyName" + j.ToString();
                            lblTravelerBeneficialyName.Font.Bold = true;
                            lblTravelerBeneficialyName.Text = "<font color=red>*</font>&nbsp;" + "Name : <br/>&nbsp;&nbsp;&nbsp;";

                            Label lblTravelerBeneficialyNameTh = new Label();
                            lblTravelerBeneficialyNameTh.ID = "lblTraveler" + code + "BeneficialyName" + j.ToString() + "_th";
                            lblTravelerBeneficialyNameTh.Font.Bold = true;
                            lblTravelerBeneficialyNameTh.Font.Size = FontUnit.Point(8);
                            lblTravelerBeneficialyNameTh.Text = "ชื่อ <br/>";

                            HtmlInputText txtTravelerBeneficialyName = new HtmlInputText();
                            txtTravelerBeneficialyName.MaxLength = 100;
                            txtTravelerBeneficialyName.Style.Add("width", "195px");
                            txtTravelerBeneficialyName.ID = "txtTraveler" + code + "BeneficialyName" + j.ToString();
                            txtTravelerBeneficialyName.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialyName" + j.ToString()];

                            if (j == 1)
                            {
                                tableBeneficialy2_tdBeneficialyName.Controls.Add(lblTravelerBeneficialyName);
                                tableBeneficialy2_tdBeneficialyName.Controls.Add(lblTravelerBeneficialyNameTh);

                            }
                            tableBeneficialy2_tdBeneficialyName.Controls.Add(txtTravelerBeneficialyName);

                            tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyName);

                            //---------------------- lblTraveler1BeneficialySurname1- ---------------
                            HtmlTableCell tableBeneficialy2_tdBeneficialySurname = new HtmlTableCell();
                            tableBeneficialy2_tdBeneficialySurname.Align = "left";

                            Label lblTravelerBeneficialySurname = new Label();
                            lblTravelerBeneficialySurname.ID = "lblTraveler" + code + "BeneficialySurname" + j.ToString();
                            lblTravelerBeneficialySurname.Font.Bold = true;
                            lblTravelerBeneficialySurname.Text = "<font color=red>*</font>&nbsp;" + "Family name : <br/>&nbsp;&nbsp;&nbsp;";

                            Label lblTravelerBeneficialySurnameTh = new Label();
                            lblTravelerBeneficialySurnameTh.ID = "lblTraveler" + code + "BeneficialySurname" + j.ToString() + "_th";
                            lblTravelerBeneficialySurnameTh.Font.Bold = true;
                            lblTravelerBeneficialySurnameTh.Font.Size = FontUnit.Point(8);
                            lblTravelerBeneficialySurnameTh.Text = "นามสกุล <br/>";

                            HtmlInputText txtTravelerBeneficialySurname = new HtmlInputText();
                            txtTravelerBeneficialySurname.Style.Add("width", "195px");
                            txtTravelerBeneficialySurname.ID = "txtTraveler" + code + "BeneficialySurname" + j.ToString();
                            txtTravelerBeneficialySurname.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialySurname" + j.ToString()];


                            if (j == 1)
                            {
                                tableBeneficialy2_tdBeneficialySurname.Controls.Add(lblTravelerBeneficialySurname);
                                tableBeneficialy2_tdBeneficialySurname.Controls.Add(lblTravelerBeneficialySurnameTh);

                            }
                            tableBeneficialy2_tdBeneficialySurname.Controls.Add(txtTravelerBeneficialySurname);

                            tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialySurname);

                            //---------------------- lblTraveler1BeneficialyRelationShip1- ---------------
                            HtmlTableCell tableBeneficialy2_tdBeneficialyRelationShip = new HtmlTableCell();
                            tableBeneficialy2_tdBeneficialyRelationShip.Align = "left";

                            Label lblTravelerBeneficialyRelationShip = new Label();
                            lblTravelerBeneficialyRelationShip.ID = "lblTraveler" + code + "BeneficialyRelationShip" + j.ToString();
                            lblTravelerBeneficialyRelationShip.Font.Bold = true;
                            lblTravelerBeneficialyRelationShip.Text = "RelationShip : <br/>";

                            Label lblTravelerBeneficialyRelationShipTh = new Label();
                            lblTravelerBeneficialyRelationShipTh.ID = "lblTraveler" + code + "BeneficialyRelationShip" + j.ToString() + "_th";
                            lblTravelerBeneficialyRelationShipTh.Font.Bold = true;
                            lblTravelerBeneficialyRelationShipTh.Font.Size = FontUnit.Point(8);
                            lblTravelerBeneficialyRelationShipTh.Text = "ความสัมพันธ์กับผู้เอาประกันภัย<br/>";

                            DropDownList ddlTravelerBeneficialyRelationShip = new DropDownList();
                            ddlTravelerBeneficialyRelationShip.ID = "ddlTraveler" + code + "BeneficialyRelationShip" + j.ToString();
                            ddlTravelerBeneficialyRelationShip.Style.Add("width", "160px");

                            SetRelationToDropdownList(ddlTravelerBeneficialyRelationShip, this.ddlLanguage.SelectedValue);
                            ddlTravelerBeneficialyRelationShip.SelectedValue = Request.Form["ctl00$MainContent$ddlTraveler" + code + "BeneficialyRelationShip" + j.ToString()];
                            //-------VVVVVVVVVVVVVVVVVVVVVVVVVVV------------
                            

                            if (j == 1)
                            {
                                tableBeneficialy2_tdBeneficialyRelationShip.Controls.Add(lblTravelerBeneficialyRelationShip);
                                tableBeneficialy2_tdBeneficialyRelationShip.Controls.Add(lblTravelerBeneficialyRelationShipTh);

                            }
                            tableBeneficialy2_tdBeneficialyRelationShip.Controls.Add(ddlTravelerBeneficialyRelationShip);

                            tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyRelationShip);

                            #region #//Part of Traveler Beneficiary Ratio
                            HtmlTableCell tableBeneficialy2_tdBeneficialyRatio = new HtmlTableCell();
                            tableBeneficialy2_tdBeneficialyRatio.Align = "left";

                            Label lblTravelerBeneficialyRatio = new Label();
                            lblTravelerBeneficialyRatio.ID = "lblTraveler" + code + "BeneficialyRatio" + j.ToString();
                            lblTravelerBeneficialyRatio.Font.Bold = true;
                            lblTravelerBeneficialyRatio.Text = "<font color=red>*</font>&nbsp;" + "Ratio : <br/>";

                            Label lblTravelerBeneficialyRatioTh = new Label();
                            lblTravelerBeneficialyRatioTh.ID = "lblTraveler" + code + "BeneficialyRatio" + j.ToString() + "_th";
                            lblTravelerBeneficialyRatioTh.Font.Bold = true;
                            lblTravelerBeneficialyRatioTh.Font.Size = FontUnit.Point(8);
                            lblTravelerBeneficialyRatioTh.Text = "สัดส่วน<br/>";

                            HtmlInputText txtTravelerBeneficialyRatio = new HtmlInputText();
                            txtTravelerBeneficialyRatio.ID = "txtTraveler" + code + "BeneficialyRatio" + j.ToString();
                            txtTravelerBeneficialyRatio.Style.Add("width", "70px");
                            txtTravelerBeneficialyRatio.MaxLength = 3;
                            txtTravelerBeneficialyRatio.Attributes.Add("onkeypress", "return numbersonly(event);");
                            txtTravelerBeneficialyRatio.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialyRatio" + j.ToString()];

                            if (j == 1)
                            {
                                tableBeneficialy2_tdBeneficialyRatio.Controls.Add(lblTravelerBeneficialyRatio);
                                tableBeneficialy2_tdBeneficialyRatio.Controls.Add(lblTravelerBeneficialyRatioTh);
                            }

                            tableBeneficialy2_tdBeneficialyRatio.Controls.Add(txtTravelerBeneficialyRatio);

                            tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyRatio);

                            #endregion

                            //---------------------- lblTraveler1BeneficialyTel1- ---------------
                            HtmlTableCell tableBeneficialy2_tdBeneficialyTel = new HtmlTableCell();
                            tableBeneficialy2_tdBeneficialyTel.Align = "left";

                            Label lblTravelerBeneficialyTel = new Label();
                            lblTravelerBeneficialyTel.ID = "lblTraveler" + code + "BeneficialyTel" + j.ToString();
                            lblTravelerBeneficialyTel.Font.Bold = true;
                            lblTravelerBeneficialyTel.Text = "Tel : <br/>";

                            Label lblTravelerBeneficialyTelTh = new Label();
                            lblTravelerBeneficialyTelTh.ID = "lblTraveler" + code + "BeneficialyTel" + j.ToString() + "_th";
                            lblTravelerBeneficialyTelTh.Font.Bold = true;
                            lblTravelerBeneficialyTelTh.Font.Size = FontUnit.Point(8);
                            lblTravelerBeneficialyTelTh.Text = "เบอร์โทรศัพท์<br/>";

                            HtmlInputText txtTravelerBeneficialyTel = new HtmlInputText();
                            txtTravelerBeneficialyTel.ID = "txtTraveler" + code + "BeneficialyTel" + j.ToString();
                            txtTravelerBeneficialyTel.Style.Add("width", "100px");
                            txtTravelerBeneficialyTel.MaxLength = 100;
                            txtTravelerBeneficialyTel.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialyTel" + j.ToString()];


                            if (j == 1)
                            {
                                tableBeneficialy2_tdBeneficialyTel.Controls.Add(lblTravelerBeneficialyTel);
                                tableBeneficialy2_tdBeneficialyTel.Controls.Add(lblTravelerBeneficialyTelTh);

                            }

                            tableBeneficialy2_tdBeneficialyTel.Controls.Add(txtTravelerBeneficialyTel);

                            tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyTel);
                        }
                    }

                    #endregion

                }


            }
        }
    }
    protected bool IsBirthDayOverLimitOfEffectiveDate(int nminday, int nmaxday, DateTime birthday, DateTime effdatefrom)
    {
        bool ret = false;
        long numOfDays = TA.TAUtilities.DateDiff(TA.TAUtilities.DateInterval.Year, birthday, effdatefrom);
        if (nminday <= numOfDays && numOfDays <= nmaxday)
        {
            ret = false;
        }
        else
        {
            ret = true;
        }
        return ret;
    }
    protected int GetAge()
    {
        int ret = 0;
        if (!this.txtDateofBirth.Text.Trim().Equals(string.Empty))
        {
            DateTime birthday = Convert.ToDateTime(TA.TAUtilities.ConvertDateFieldToDB(this.txtDateofBirth.Text.Trim()));
            long nyear = TA.TAUtilities.DateDiff(TA.TAUtilities.DateInterval.Year, birthday, DateTime.Now);
            long nday = TA.TAUtilities.DateDiff(TA.TAUtilities.DateInterval.Day, birthday, DateTime.Now);
            if (nday >= 365)
            {
                ret = (int)nyear;
            }  
        }
        return ret;
    }
    
    //OTHER
    protected void DefaultPageRegisterClientScript()
    {
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptScrolling", "MenuScroll();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptTxtFocus", "setFocusTextbox();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDisplayMsg", "DisplayWarning();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDatePicker", "<script type='text/javascript' language='javascript'>$(document).ready(function () { $('.PERSONAL').find('img').attr('src', '../Images/Index/PA1.png');$('.PERSONAL').find('a').css('color', '#922d3d');$('.PERSONAL').hover(function () {$(this).find('img').attr('src', '../Images/Index/PA1.png'); },function () {$(this).find('img').attr('src', '../Images/Index/PA1.png');}); addSubMenu('hdnPa', '.subNavigate', 'สร้างกรมธรรม์ PA', 'Issue Policy');$('[id$=txtEffectiveDateFrom]').datepicker({ dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true  }); $('[id$=txtDateofBirth]').datepicker({ dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true,yearRange: '1900:' });$('[id$=txtPolicyHolderBirthay]').datepicker({ dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true,yearRange: '1900:' });if($('[id$=ddlPackage]').val() != '0004'){$('[name=MyFamily]').hide();}$('[id$=txtTraveler1IDCard]').change(function(){checkThaiIDCard(this)});for (i = 2; i < parseInt($('[id$=txtNumberOfChilden]').val()) + 3; i++) { $('[id$=txtTraveler' + i + 'IDCard]').change(function(){checkThaiIDCard(this)}); $('[id$=txtTraveler' + i + 'Birthday]').datepicker({ dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true,yearRange: '1900:' });}  Accordion('.wizard', 'hdnCriteriaStep');AccordionSub1('.wizardSub', 'hdnCriteriaStep');PolicyTypePA();$('[name$=rdoTaxInvoiceType]').click( function () {PolicyTypePA();}); $('[id$=BeneficialyHeir]').click( function(){ hideBeneficialy(this); }); $('[id$=BeneficialyHeir]').filter(function(){ hideBeneficialy(this);}); }); </script>", false);
        //-------------update 2012/11/16-------------- for key only each language they choose
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptsetKeyboardLanguage", "setKeyboardLanguagePA();", true);
    }
    protected void txtEffectiveDateFrom_TextChanged(object sender, EventArgs e)
    {
        this.lblValidateSingleTripNumOfDays.Text = "";
        //Check Is BackDate
        this.ValidateBackCurrentDate(this.txtEffectiveDateFrom.Text.Trim());
        //End Check

     
        if (!string.IsNullOrEmpty(this.txtEffectiveDateFrom.Text))
        {
            this.txtEffectiveDateTo.Text = TA.TAUtilities.CheckCultureAndConvertToDateTime(this.txtEffectiveDateFrom.Text.Trim()).AddYears(1).ToString("dd/MM/yyyy");
            this.txtEffectiveDateTo.Enabled = false;
        }
        
        

       // this.ValidateSingleTripNumOfDays();

        if (!string.IsNullOrEmpty(this.txtEffectiveDateFrom.Text) && !string.IsNullOrEmpty(this.txtEffectiveDateTo.Text))
        {
            DateTime dt1 = TA.TAUtilities.CheckCultureAndConvertToDateTime(this.txtEffectiveDateFrom.Text.Trim());
            DateTime dt2 = TA.TAUtilities.CheckCultureAndConvertToDateTime(this.txtEffectiveDateTo.Text.Trim());
           // this.txtDuration.Value = this.CalculateTripDuration(dt1, dt2).ToString();

          //  this.ValidateEffectiveBackDate(this.txtEffectiveDateFrom.Text.Trim(), this.txtEffectiveDateTo.Text.Trim());
        }

       // this.ProcessCalPremiumAndShowCoverage();

        //this.RemoveDynamicTravelerControl();
        //this.GenerateDynamicTraveler();
    }
    protected void txtEffectiveDateTo_TextChanged(object sender, EventArgs e)
    {
        this.lblValidateSingleTripNumOfDays.Text = "";
        this.lblValidateSingleTripNumOfDays.Visible = false;
      //  this.ValidateSingleTripNumOfDays();

        //Check Is BackDate
       // this.ValidateBackCurrentDate(this.txtEffectiveDateTo.Text.Trim());
        //End Check

        if (!string.IsNullOrEmpty(this.txtEffectiveDateFrom.Text) && !string.IsNullOrEmpty(this.txtEffectiveDateTo.Text))
        {
            DateTime dt1 = TA.TAUtilities.CheckCultureAndConvertToDateTime(this.txtEffectiveDateFrom.Text.Trim());
            DateTime dt2 = TA.TAUtilities.CheckCultureAndConvertToDateTime(this.txtEffectiveDateTo.Text.Trim());
           // this.txtDuration.Value = this.CalculateTripDuration(dt1, dt2).ToString();

          //  this.ValidateEffectiveBackDate(this.txtEffectiveDateFrom.Text.Trim(), this.txtEffectiveDateTo.Text.Trim());
        }

       // this.ProcessCalPremiumAndShowCoverage();

        //this.RemoveDynamicTravelerControl();
        //this.GenerateDynamicTraveler();
    
  
    }
    protected void txtDateofBirth_TextChanged(object sender, EventArgs e)
    {
        if (!string.IsNullOrEmpty(this.txtDateofBirth.Text))
        {
            this.txtTraveler1Birthday.Value = this.txtDateofBirth.Text.Trim();
            
            //SET PACKAGE
            int m_dob_length = this.txtDateofBirth.Text.Trim().Length;
            ddlPackage.DataSource = "";
            ddlPackage.DataBind();

            if (m_dob_length == 10)
            {
                string[] list = this.txtDateofBirth.Text.Trim().Split('/');
                if (list.Length == 3)
                {
                    int age = this.GetAge();
                    if (age > 0)
                    {
                        this.SetPackageToDropdownList(ddlPackage, age, ddlLanguage.SelectedValue.Trim());
                    }
                    else
                    {
                        this.lblValidateDateofBirth.Text = "อายุอย่างน้อยต้องครบ 1 ปีบริบูรณ์.";
                    }
                }
                else
                {
                    this.lblValidateDateofBirth.Text = "รูปแบบวันที่ไม่ถูกต้อง ค.ศ.[dd/mm/yyyy]";
                }
            }
            else
            {
                this.lblValidateDateofBirth.Text = "รูปแบบวันที่ไม่ถูกต้อง ค.ศ.[dd/mm/yyyy]";
            }
        }
    }

    private string GetOccupationClass(int occupationID)
    {
        string retValue = string.Empty;

        PAOccupation paOccupation = new PAOccupation();
        PAOccupationBLL clsPAOccupation = new PAOccupationBLL();
        paOccupation = clsPAOccupation.GetPAOccupation(occupationID);

        retValue = string.IsNullOrEmpty(paOccupation.OccupatnClass) ? "" : paOccupation.OccupatnClass.Trim();

        return retValue;
    }
    private void ClearCssClassFocusError()
    {
        #region "VALIDATE VARIABLE ISSUED POLICY"
        //-------------------------------------------------------------------------------------------------------------
        //BEGIN VARIABLE-TRANSPOLICY
        //BEGIN VALIDATE ITEMS        
        this.ddlLanguage.CssClass = "";
        if (this.ddlLanguage.SelectedValue == "00")
        {
            this.ddlLanguage.CssClass = "inputFocusError";
        }
        
        this.txtEffectiveDateFrom.CssClass = "";
        if (this.txtEffectiveDateFrom.Text.Trim() == string.Empty)
        {            
            this.txtEffectiveDateFrom.CssClass = "inputFocusError";
        }
        this.txtEffectiveDateTo.CssClass = "";
        if (this.txtEffectiveDateTo.Text.Trim() == string.Empty)
        {            
            this.txtEffectiveDateTo.CssClass = "inputFocusError";
        }
        this.txtDateofBirth.CssClass = "";
        if (this.txtDateofBirth.Text.Trim() == string.Empty)
        {            
            this.txtDateofBirth.CssClass = "inputFocusError";
        }
        this.ddlPackage.CssClass = "";
        if (this.ddlPackage.SelectedValue.Trim() == "00" || this.ddlPackage.SelectedValue.Trim() == "")
        {            
            this.ddlPackage.CssClass = "inputFocusError";
        }
        this.ddlInsurancePlan.CssClass = "";
        if (this.ddlInsurancePlan.SelectedValue.Trim() == "00" || this.ddlInsurancePlan.SelectedValue.Trim() == "")
        {            
            this.ddlInsurancePlan.CssClass = "inputFocusError";
        }        
        this.ddlOccupationClass.CssClass = "";
        if (this.ddlOccupationClass.SelectedValue.Trim() == "0" || this.ddlOccupationClass.SelectedValue.Trim() == "")
        {            
            this.ddlOccupationClass.CssClass = "inputFocusError";
        }
        

        string m_JobNo = "";
        string m_PackageID = this.ddlPackage.SelectedValue.Trim();
        string m_PlanCode = this.ddlInsurancePlan.SelectedValue.Trim();
        string m_InceptionDate = this.txtEffectiveDateFrom.Text.Trim().Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtEffectiveDateFrom.Text.Trim());
        string m_ExpiryDate = this.txtEffectiveDateTo.Text.Trim().Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtEffectiveDateTo.Text.Trim()); ;
        string m_AgentCode = Utilities.BrokerCode();
        string m_StaffCode = "";
        string m_OccupatnClass = this.GetOccupationClass(this.ddlOccupationClass.SelectedValue.Equals(string.Empty) ? 0 : Convert.ToInt32(this.ddlOccupationClass.SelectedValue.Trim()));
        string m_OccupatnDestination;
        if (this.ddlOccupationClass.Items.Count > 0)
        {
            m_OccupatnDestination = string.IsNullOrEmpty(this.ddlOccupationClass.SelectedItem.Text) ? "" : this.ddlOccupationClass.SelectedItem.Text.Trim();
        }
        else
        {
            m_OccupatnDestination = "";
        }
        Nullable<int> m_NoOfChildren = int.Parse(this.txtNumberOfChilden.Text.Trim());
        Nullable<int> m_GrossPremium = null;
        if (this.lblNetPremiumValue.Text.Trim() != string.Empty)
        {
            m_GrossPremium = (int)Utilities.ExactNumber(this.lblNetPremiumValue.Text.Trim());
        }
        Nullable<int> m_Stamp = null;
        if (this.lblStampDiutyValue.Text.Trim() != string.Empty)
        {
            m_Stamp = (int)Utilities.ExactNumber(this.lblStampDiutyValue.Text.Trim());
        }
        Nullable<int> m_SBT = null;
        if (this.lblTaxValue.Text.Trim() != string.Empty)
        {
            m_SBT = (int)Utilities.ExactNumber(this.lblTaxValue.Text.Trim());
        }
        Nullable<int> m_TotalPremium = null;
        if (this.lblTotlaPremiumValue.Text.Trim() != string.Empty)
        {
            m_TotalPremium = (int)Utilities.ExactNumber(this.lblTotlaPremiumValue.Text.Trim());
        }
        Nullable<SByte> m_isLongName = 0;
        string m_GroupBrokerID = Utilities.GetGroupBrokerID();        
        string m_Lang = "";     //Lang            
        //END VARIABLE-TRANSPOLICY


        //-------------------------------------------------------------------------------------------------------------
        //BEGIN VARIABLE-TRANSPOLICY HOLDER
        string policyholdertype = ""; //CHECK POLICY HOLDER TYPE
        foreach (ListItem item in rdoTaxInvoiceType.Items)
        {
            if (item.Selected == true)
            {
                policyholdertype = item.Value.Trim();  //Private ,Commercial
            }
        }
        //BEGIN VALIDATE ITEMS        
        if (policyholdertype == "Private")
        {
            //Private
            this.ddlPolicyHolderTitle.Attributes["class"] = "";
            if (ddlPolicyHolderTitle.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlPolicyHolderTitle.SelectedItem.Text.Trim() == "Please Selected" || ddlPolicyHolderTitle.SelectedItem.Text.Trim() == "")
            {               
                this.ddlPolicyHolderTitle.Attributes["class"] = "inputFocusError";
            }


            this.txtPolicyHolderName.Attributes["class"] = "";
            if (txtPolicyHolderName.Value.Trim() == string.Empty)
            {                
                this.txtPolicyHolderName.Attributes["class"] = "inputFocusError";
            }
            this.txtPolicyHolderSurname.Attributes["class"] = "";
            if (txtPolicyHolderSurname.Value.Trim() == string.Empty)
            {                
                this.txtPolicyHolderSurname.Attributes["class"] = "inputFocusError";
            }
            this.txtPolicyHolderBirthay.Attributes["class"] = "";
            if (txtPolicyHolderBirthay.Value.Trim() == string.Empty)
            {                
                this.txtPolicyHolderBirthay.Attributes["class"] = "inputFocusError";
            }
            this.txtPolicyHolderIDCard.CssClass = "";
            if (txtPolicyHolderIDCard.Text.Trim() == string.Empty)
            {                
                this.txtPolicyHolderIDCard.CssClass = "inputFocusError";
            }
            this.txtPolicyHolderTel.Attributes["class"] = "";
            if (txtPolicyHolderTel.Value.Trim() == string.Empty)
            {                
                this.txtPolicyHolderTel.Attributes["class"] = "inputFocusError";
            }
            this.txtPolicyHolderAddressNo.Attributes["class"] = "";
            if (txtPolicyHolderAddressNo.Value.Trim() == string.Empty)
            {                
                this.txtPolicyHolderAddressNo.Attributes["class"] = "inputFocusError";
            }
            this.ddlPolicyHolderProvince.Attributes["class"] = "";
            if (ddlPolicyHolderProvince.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlPolicyHolderProvince.SelectedItem.Text.Trim() == "Please Selected" || ddlPolicyHolderProvince.SelectedItem.Text.Trim() == "")
            {                
                this.ddlPolicyHolderProvince.Attributes["class"] = "inputFocusError";
            }
            this.ddlPolicyHolderAmphure.Attributes["class"] = "";
            if (ddlPolicyHolderAmphure.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlPolicyHolderAmphure.SelectedItem.Text.Trim() == "Please Selected" || ddlPolicyHolderAmphure.SelectedItem.Text.Trim() == "")
            {                
                this.ddlPolicyHolderAmphure.Attributes["class"] = "inputFocusError";
            }
            this.ddlPolicyHolderTumbon.Attributes["class"] = "";
            if (ddlPolicyHolderTumbon.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlPolicyHolderTumbon.SelectedItem.Text.Trim() == "Please Selected" || ddlPolicyHolderTumbon.SelectedItem.Text.Trim() == "")
            {                
                this.ddlPolicyHolderTumbon.Attributes["class"] = "inputFocusError";
            }
            this.txtPolicyHolderZipCode.Attributes["class"] = "";
            if (txtPolicyHolderZipCode.Value.Trim() == string.Empty)
            {                
                this.txtPolicyHolderZipCode.Attributes["class"] = "inputFocusError";
            }            
        }
        else //Commercial
        {
            this.txtPolicyHolderName.Attributes["class"] = "";
            if (txtPolicyHolderName.Value.Trim() == string.Empty)
            {                
                this.txtPolicyHolderName.Attributes["class"] = "inputFocusError";
            }
            this.txtPolicyHolderSurname.Attributes["class"] = "";
            /*if (txtPolicyHolderSurname.Value.Trim() == string.Empty)
            {                
                this.txtPolicyHolderSurname.Attributes["class"] = "inputFocusError";
            }*/
            this.txtPolicyHolderIDCard.Attributes["class"] = "";
            if (txtPolicyHolderIDCard.Text.Trim() == string.Empty)
            {                
                this.txtPolicyHolderIDCard.CssClass = "inputFocusError";
            }
            this.txtPolicyHolderTel.Attributes["class"] = "";
            if (txtPolicyHolderTel.Value.Trim() == string.Empty)
            {                
                this.txtPolicyHolderTel.Attributes["class"] = "inputFocusError";
            }
            this.txtPolicyHolderAddressNo.Attributes["class"] = "";
            if (txtPolicyHolderAddressNo.Value.Trim() == string.Empty)
            {               
                this.txtPolicyHolderAddressNo.Attributes["class"] = "inputFocusError";
            }
            this.ddlPolicyHolderProvince.Attributes["class"] = "";
            if (ddlPolicyHolderProvince.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlPolicyHolderProvince.SelectedItem.Text.Trim() == "Please Selected" || ddlPolicyHolderProvince.SelectedItem.Text.Trim() == "")
            {                
                this.ddlPolicyHolderProvince.Attributes["class"] = "inputFocusError";
            }
            this.ddlPolicyHolderAmphure.Attributes["class"] = "";
            if (ddlPolicyHolderAmphure.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlPolicyHolderAmphure.SelectedItem.Text.Trim() == "Please Selected" || ddlPolicyHolderAmphure.SelectedItem.Text.Trim() == "")
            {                
                this.ddlPolicyHolderAmphure.Attributes["class"] = "inputFocusError";
            }
            this.ddlPolicyHolderTumbon.Attributes["class"] = "";
            if (ddlPolicyHolderTumbon.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlPolicyHolderTumbon.SelectedItem.Text.Trim() == "Please Selected" || ddlPolicyHolderTumbon.SelectedItem.Text.Trim() == "")
            {                
                this.ddlPolicyHolderTumbon.Attributes["class"] = "inputFocusError";
            }
            this.txtPolicyHolderZipCode.Attributes["class"] = "";
            if (txtPolicyHolderZipCode.Value.Trim() == string.Empty)
            {                
                this.txtPolicyHolderZipCode.Attributes["class"] = "inputFocusError";
            }            
        }
        //END VALIDATE ITEMS

        //string m_JobNo = "";
        int m_InsurerID = 1;
        string m_ClientType = policyholdertype == "Private" ? "P" : "C";
        string m_ClientTitle = this.ddlPolicyHolderTitle.SelectedValue.Trim();
        string m_ClientName = this.txtPolicyHolderName.Value.Trim();
        string m_ClientSurName = this.txtPolicyHolderSurname.Value.Trim();
        string m_AddressNo = this.txtPolicyHolderAddressNo.Value.Trim();
        string m_Building = this.txtPolicyHolderBuilding.Value.Trim();
        string m_Soi = this.txtPolicyHolderSoi.Value.Trim();
        string m_Road = this.txtPolicyHolderRoad.Value.Trim();
        string m_Province = this.ddlPolicyHolderProvince.SelectedItem.Text.Trim();
        string m_Amphur = this.ddlPolicyHolderAmphure.SelectedItem.Text.Trim();
        string m_Tumbol = this.ddlPolicyHolderTumbon.SelectedItem.Text.Trim();
        string m_PostCode = this.txtPolicyHolderZipCode.Value.Trim();
        string m_Birthday = this.txtPolicyHolderBirthay.Value.Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtPolicyHolderBirthay.Value.Trim());
        string m_Gender = this.ddlPolicyHolderGender.SelectedValue.Trim();
        string m_Status = this.ddlPolicyHolderMaritalStatus.SelectedValue.Trim();
        string m_Nationality = this.ddlPolicyHolderNationality.SelectedValue.Trim();
        string m_IDCard = this.txtPolicyHolderIDCard.Text.Trim();
        string m_Tel = this.txtPolicyHolderTel.Value.Trim();
        string m_Email = this.txtPolicyHolderEmail.Value.Trim();
        string m_LangPolicyHolder = this.ddlLanguage.SelectedValue;
        //END VARIABLE-TRANSPOLICY HOLDER

        //-------------------------------------------------------------------------------------------------------------
        //BEGIN VARIABLE-TRAVELER
        PAPlanPackagesBLL clsplanpackage = new PAPlanPackagesBLL();
        PAPlanPackages getage = clsplanpackage.GetPAPlanPackages(m_PackageID);

        int m_AgeOfTravelerFrom = Convert.ToInt32(getage.AgeOfInsurerFrom);     //18
        int m_AgeOfTravelerTo = Convert.ToInt32(getage.AgeOfInsurerTo);         //68
        int m_AgeOfChildrenFrom = Convert.ToInt32(getage.AgeOfChildrenFrom);    //1
        int m_AgeOfChildrenTo = Convert.ToInt32(getage.AgeOfChildrenTo);        //17

        DateTime dt1 = new DateTime();
        DateTime dt2 = new DateTime();
        
        dt2 = string.IsNullOrEmpty(m_InceptionDate)? DateTime.Today : Convert.ToDateTime(m_InceptionDate); //DEFAULT EFFECTTIVE DATE FROM
        bool ret = false;

        #region "TRAVELER 1"
        string m_Traveler1ClientName = this.txtTraveler1Name.Value.Trim();
        string m_Traveler1ClientSurName = this.txtTraveler1Surname.Value.Trim();
        string m_Traveler1Birthday = this.txtTraveler1Birthday.Value.Trim();
        string m_Traveler1IDCard = this.txtTraveler1IDCard.Value.Trim();
        string m_Traveler1Tel = this.txtTraveler1Tel.Value.Trim();
        bool chkTraveler1Hier = this.chkTraveler1BeneficialyHeir.Checked;
        
        this.ddlTraveler1Title.Attributes["class"] = "";
        if (ddlTraveler1Title.Items.Count < 1 || ddlTraveler1Title.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlTraveler1Title.SelectedItem.Text.Trim() == "Please Selected" || ddlTraveler1Title.SelectedItem.Text.Trim() == "")
        {           
            this.ddlTraveler1Title.Attributes["class"] = "inputFocusError";
        }

        this.txtTraveler1Name.Attributes["class"] = "";
        if (m_Traveler1ClientName == string.Empty)
        {            
            this.txtTraveler1Name.Attributes["class"] = "inputFocusError";
        }
        this.txtTraveler1Surname.Attributes["class"] = "";
        if (m_Traveler1ClientSurName == string.Empty)
        {            
            this.txtTraveler1Surname.Attributes["class"] = "inputFocusError";
        }
        this.txtTraveler1Birthday.Attributes["class"] = "";
        if (m_Traveler1Birthday == string.Empty)
        {            
            this.txtTraveler1Birthday.Attributes["class"] = "inputFocusError";
        }
        this.txtTraveler1IDCard.Attributes["class"] = "";
        if (m_Traveler1IDCard == string.Empty)
        {            
            this.txtTraveler1IDCard.Attributes["class"] = "inputFocusError";
        }
        this.txtTraveler1Tel.Attributes["class"] = "";
        if (m_Traveler1Tel == string.Empty)
        {            
            this.txtTraveler1Tel.Attributes["class"] = "inputFocusError";
        }
        //CHECK BENEFICIARY
        if (chkTraveler1Hier == false)
        {
            this.txtTraveler1BeneficialyName1.Attributes["class"] = "";
            this.txtTraveler1BeneficialySurname1.Attributes["class"] = "";
            if (string.IsNullOrEmpty(txtTraveler1BeneficialyName1.Value.Trim()) || string.IsNullOrEmpty(txtTraveler1BeneficialySurname1.Value.Trim()))
            {               
                this.txtTraveler1BeneficialyName1.Attributes["class"] = "inputFocusError";
                this.txtTraveler1BeneficialySurname1.Attributes["class"] = "inputFocusError";
            }
        }        
        
        #endregion
        #region "TRAVELER 2,ANOTHER"
        if (ddlPackage.SelectedValue == "0004") //Family
        {
            #region "TRAVELERR 2"
            //CHECK TRAVELERR 2
            string m_Traveler2ClientName = this.txtTraveler2Name.Value.Trim();
            string m_Traveler2ClientSurName = this.txtTraveler2Surname.Value.Trim();
            string m_Traveler2Birthday = this.txtTraveler2Birthday.Value.Trim();
            string m_Traveler2IDCard = this.txtTraveler2IDCard.Value.Trim();
            string m_Traveler2Tel = this.txtTraveler2Tel.Value.Trim();
            bool chkTraveler2Hier = this.chkTraveler2BeneficialyHeir.Checked;
            
            this.ddlTraveler2Title.Attributes["class"] = "";
            if (ddlTraveler2Title.Items.Count < 1 || ddlTraveler2Title.SelectedItem.Text.Trim() == "โปรดเลือก" || ddlTraveler2Title.SelectedItem.Text.Trim() == "Please Selected" || ddlTraveler2Title.SelectedItem.Text.Trim() == "")
            {                
                this.ddlTraveler2Title.Attributes["class"] = "inputFocusError";
            }
            this.txtTraveler2Name.Attributes["class"] = "";
            if (m_Traveler2ClientName == string.Empty)
            {               
                this.txtTraveler2Name.Attributes["class"] = "inputFocusError";
            }
            this.txtTraveler2Surname.Attributes["class"] = "";
            if (m_Traveler2ClientSurName == string.Empty)
            {                
                this.txtTraveler2Surname.Attributes["class"] = "inputFocusError";
            }
            this.txtTraveler2Birthday.Attributes["class"] = "";
            if (m_Traveler2Birthday == string.Empty)
            {                
                this.txtTraveler2Birthday.Attributes["class"] = "inputFocusError";
            }
            this.txtTraveler2IDCard.Attributes["class"] = "";
            if (m_Traveler2IDCard == string.Empty)
            {                
                this.txtTraveler2IDCard.Attributes["class"] = "inputFocusError";
            }
            this.txtTraveler2Tel.Attributes["class"] = "";
            if (m_Traveler2Tel == string.Empty)
            {                
                this.txtTraveler2Tel.Attributes["class"] = "inputFocusError";
            }
            //CHECK BENEFICIARY
            if (chkTraveler2Hier == false)
            {
                this.txtTraveler2BeneficialyName1.Attributes["class"] = "";
                this.txtTraveler2BeneficialySurname1.Attributes["class"] = "";
                if (string.IsNullOrEmpty(txtTraveler2BeneficialyName1.Value.Trim()) || string.IsNullOrEmpty(txtTraveler2BeneficialySurname1.Value.Trim()))
                {                    
                    this.txtTraveler2BeneficialyName1.Attributes["class"] = "inputFocusError";
                    this.txtTraveler2BeneficialySurname1.Attributes["class"] = "inputFocusError";
                }
            }
            //END CHECK                                    
            #endregion            
        }
        #endregion
                
        #endregion
    }

    private void ValidateBackCurrentDate(string dateValue)
    {
        bool isBackCurrentDate = false;

        isBackCurrentDate = TA.TAUtilities.CheckIsBackDate(dateValue,-3);

        if (isBackCurrentDate == true)
        {
            this.lblValidateSingleTripNumOfDays.Visible = true;
            this.lblValidateSingleTripNumOfDays.Text = "***ไม่สามารถระบุวันที่ย้อนหลังได้ไม่เกิน 3 วัน กรุณาระบุใหม่อีกครั้ง!!!";
            this.txtEffectiveDateFrom.Text = "";
            this.txtEffectiveDateTo.Text = "";
        }
    }

    private void setDDLOccupationClassValue(string searchName)
    {
        for (int i = 0; i < this.ddlOccupationClass.Items.Count; i++)
        {
            if (this.ddlOccupationClass.Items[i].Text.Trim() == searchName)
            {
                this.ddlOccupationClass.Items[i].Selected = true ;
                break;
            }
        }
    }


    protected void txtPolicyHolderIDCard_TextChanged(object sender, EventArgs e)
    {
        string policyholdertype = ""; //CHECK POLICY HOLDER TYPE
        foreach (ListItem item in rdoTaxInvoiceType.Items)
        {
            if (item.Selected == true)
            {
                policyholdertype = item.Value.Trim();  //Private ,Commercial
            }
        }

        if (!string.IsNullOrEmpty(this.txtPolicyHolderIDCard.Text.Trim()))
        {
            if (string.Compare(policyholdertype, "Private") == 0)
            {

                if (txtPolicyHolderIDCard.Text.Trim().Length == 13)
                {
                    if (TA.TAUtilities.ChkIDNO(txtPolicyHolderIDCard.Text.Trim()) == true)
                    {
                        this.txtPolicyHolderTel.Focus();
                    }
                    else
                    {
                        TA.TAUtilities.msgBOX(this.Page, "เลขที่บัตรประชาชนไม่ถูกต้อง");
                        this.txtPolicyHolderIDCard.Text = "";
                    }
                }
                else
                {
                    //Pending Check Passport Logic

                    //TA.TAUtilities.msgBOX(this.Page, "เลขที่บัตรประชาชนไม่ถูกต้อง (13 หลัก)");
                    //this.txtIDCard.Text = "";
                }
            }
            else
            {
                //กรณี Commercial
                this.txtPolicyHolderTel.Focus();
            }
        }
        else
        {
            TA.TAUtilities.msgBOX(this.Page, "กรุณาระบุเลขที่บัตรประชาชน/Passport No./Tax ID");
            this.txtPolicyHolderIDCard.Focus();
        }
    }

    private string findDropdownValueByText(DropDownList sender, string selected)
    {
        for (int i = 0; i < sender.Items.Count; i++)
        {
            if (sender.Items[i].Text == selected)
            {
                sender.Items[i].Selected = true;
                return sender.Items[i].Value;
            }
        }
        return "";
    }

}