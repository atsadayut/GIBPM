﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;  
using PA.BLL;

public partial class PA_PAPrintPolicy : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {            
            this.btnSearchPolicy.ServerClick += new EventHandler(btnSearchPolicy_ServerClick);
            this.gdvUploadList.PageIndexChanging += new GridViewPageEventHandler(gdvUploadList_PageIndexChanging);

            this.DefaultPageRegisterClientScript();
            this.lblErrorMessage.Text = "";
            this.lblInformMessage.Text = "";

            if (!Page.IsPostBack)
            {
                //string GroupBrokerID = Utilities.GetGroupBrokerID();
                //this.GetListUploadPolicy("", "", GroupBrokerID);
            }

        }
        catch (Exception err)
        {
            this.lblErrorMessage.Text = err.Message;
            this.lblInformMessage.Text = "";
        }
    }

    protected void gdvUploadList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdvUploadList.PageIndex = e.NewPageIndex;
        string GroupBrokerID = Utilities.GetGroupBrokerID();
        this.GetListUploadPolicy(GetFormateDateYMD(this.txtIssuedDateFrom.Text), GetFormateDateYMD(this.txtIssuedDateTo.Text), GroupBrokerID);
    }

    protected void DefaultPageRegisterClientScript()
    {
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptScrolling", "MenuScroll();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptTxtFocus", "setFocusTextbox();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDisplayMsg", "DisplayWarning();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptMenu", "<script type='text/javascript' language='javascript'>$(document).ready(function () { $('.PERSONAL').find('img').attr('src', '../Images/Index/PA1.png');$('.PERSONAL').find('a').css('color', '#922d3d');$('.PERSONAL').hover(function () {$(this).find('img').attr('src', '../Images/Index/PA1.png'); },function () {$(this).find('img').attr('src', '../Images/Index/PA1.png');}); addSubMenu('hdnPa', '.subNavigate', 'พิมพ์กรมธรรม์ PA', 'Print policy');$('[id$=txtIssuedDateFrom]').datepicker({ dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true  });$('[id$=txtIssuedDateTo]').datepicker({ dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true  }); Accordion('.wizard', 'hdnCriteriaStep');}); </script>", false);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptFunction", "<script type='text/javascript' language='javscript'>function RedirectToPage(JobNo) {$('[name=uploadframe]').attr('src','upload/ListUpload.aspx?JobNo=' + JobNo );}</script>", false);      
    }

    protected void btnSearchPolicy_ServerClick(object sender, EventArgs e)
    {
        try
        {
            string GroupBrokerID = Utilities.GetGroupBrokerID();
            this.GetListUploadPolicy(GetFormateDateYMD(this.txtIssuedDateFrom.Text), GetFormateDateYMD(this.txtIssuedDateTo.Text), GroupBrokerID);            
            this.DefaultPageRegisterClientScript();
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.Message.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    private void GetListUploadPolicy(string IssuredDateFrom, string IssuedDateTo, string GroupBrokerID)
    {
        PATransUploadFilesBLL getListPolicy = new PATransUploadFilesBLL();
        DataTable DTable = new DataTable();
        DTable = getListPolicy.GetPAListPolicy(IssuredDateFrom, IssuedDateTo, GroupBrokerID);        

        if (DTable.Rows.Count > 0)
        {
            this.lblTotalRecord.Text = "แสดงรายการข้อมูล [จำนวนข้อมูลทั้งหมด " + DTable.Rows.Count + " รายการ]";

            gdvUploadList.DataSource = DTable;
            gdvUploadList.DataBind();
        }
        else
        {
            this.lblTotalRecord.Text = "แสดงรายการข้อมูล [จำนวนข้อมูลทั้งหมด " + 0 + " รายการ]";
            gdvUploadList.DataSource = null;
            gdvUploadList.DataBind();
        }        
    }    
    private string GetFormateDateYMD(string date)
    {
        if (string.IsNullOrEmpty(date))
        {
            return "";
        }
        else
        {
            string[] DatePart = date.Split('/');
            return DatePart[2] + '-' + DatePart[1] + '-' + DatePart[0];
        }

    }

}