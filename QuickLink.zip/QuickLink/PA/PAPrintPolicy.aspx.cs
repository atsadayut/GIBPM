﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;  
using PA.BLL;

public partial class PA_PAPrintPolicy : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            DefaultPageRegisterClientScript();
            this.btnSearchPolicy.ServerClick += new EventHandler(btnSearchPolicy_ServerClick);
            this.gdvReprint.PageIndexChanging +=new GridViewPageEventHandler(gdvReprint_PageIndexChanging);

            AutoGotoListPrint();
        }
        catch (Exception err)
        {
            this.lblErrorMessage.Text = err.Message;
            this.lblInformMessage.Text = "";
        }
    }
    protected void gdvReprint_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        string status = "";
        status = Request.QueryString["status"];
        if(string.IsNullOrEmpty(status)){
            status = "NEW";
        }
        gdvReprint.PageIndex = e.NewPageIndex;
        string GroupBrokerID = Utilities.GetGroupBrokerID();
        this.GetTranPolicy(this.txtPolicyFrom.Text, this.txtPolicyTo.Text, this.txtIssuedDateFrom.Text, this.txtIssuedDateTo.Text, GroupBrokerID, status.ToString());
    }
    protected void DefaultPageRegisterClientScript()
    {
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptScrolling", "MenuScroll();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptTxtFocus", "setFocusTextbox();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDisplayMsg", "DisplayWarning();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptMenu", "<script type='text/javascript' language='javascript'>$(document).ready(function () { $('.PERSONAL').find('img').attr('src', '../Images/Index/PA1.png');$('.PERSONAL').find('a').css('color', '#922d3d');$('.PERSONAL').hover(function () {$(this).find('img').attr('src', '../Images/Index/PA1.png'); },function () {$(this).find('img').attr('src', '../Images/Index/PA1.png');}); addSubMenu('hdnPa', '.subNavigate', 'พิมพ์กรมธรรม์ PA', 'Print Policy');$('[id$=txtIssuedDateFrom]').datepicker({ dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true  });$('[id$=txtIssuedDateTo]').datepicker({ dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true  }); Accordion('.wizard', 'hdnCriteriaStep');}); </script>", false);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptFunction", "<script type='text/javascript' language='javscript'>function RedirectToPage(PolicyNo, PolicyType, PlanId,jobno,insured_name) {$('[name=printframe]').attr('src','Print/ListPrint.aspx?policyno=' + PolicyNo + '&policytype=' + PolicyType + '&planid=' + PlanId + '&jobno=' + jobno + '&insured_name=' + insured_name);}</script>", false);
      
    }
    protected void btnSearchPolicy_ServerClick(object sender, EventArgs e)
    {
        string status = "";
        status = Request.QueryString["status"];
        if (string.IsNullOrEmpty(status))
        {
            status = "NEW";
        }

        string GroupBrokerID = Utilities.GetGroupBrokerID();

        this.GetTranPolicy(this.txtPolicyFrom.Text, this.txtPolicyTo.Text, GetFormateDateYMD(this.txtIssuedDateFrom.Text), GetFormateDateYMD(this.txtIssuedDateTo.Text), GroupBrokerID, status);
        DefaultPageRegisterClientScript();
    }
    private void GetTranPolicy(string PolicyFrom,string PolicyTo,string IssuredDateFrom,string IssuedDateTo, string GroupBrokerID,string status)
    {
        PATransPrintsBLL getListPolicy = new PATransPrintsBLL();

        DataTable DTable = new DataTable();
        DTable = getListPolicy.GetPAListPrintPolicy(PolicyFrom, PolicyTo, IssuredDateFrom, IssuedDateTo, GroupBrokerID, status);

        if (DTable.Rows.Count > 0)
        {
            this.lblTotalRecord.Text = "แสดงรายการข้อมูล [จำนวนข้อมูลทั้งหมด " + DTable.Rows.Count + " รายการ]";

            gdvReprint.DataSource = DTable;
            gdvReprint.DataBind();
        }
        else
        {
            this.lblTotalRecord.Text = "แสดงรายการข้อมูล [จำนวนข้อมูลทั้งหมด " + 0 + " รายการ]";
            gdvReprint.DataSource = null;
            gdvReprint.DataBind();
        }

        this.lblErrorMessage.Text = "";
        this.lblInformMessage.Text = "";
    }
    private void AutoGotoListPrint()
    {
        try
        {
            if ( Request.QueryString["policyno"].ToString().Trim() != "")
            {
            string PolicyNo = Request.QueryString["policyno"].ToString().Trim();
            string status = "";
            status = Request.QueryString["status"];
            if (string.IsNullOrEmpty(status))
            {
                status = "NEW";
            }

            this.txtPolicyFrom.Text = PolicyNo;


            string GroupBrokerID = Utilities.GetGroupBrokerID();
            this.GetTranPolicy(PolicyNo, "", "", "", GroupBrokerID,status);
            DefaultPageRegisterClientScript();
            }
        }
        catch (Exception err)
        {
        }

    }
    private string GetFormateDateYMD(string date)
    {
        if (string.IsNullOrEmpty(date))
        {
            return "";
        }
        else
        {
            string[] DatePart = date.Split('/');
            return DatePart[2] + '-' + DatePart[1] + '-' + DatePart[0];
        }

    }
}