using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

using PA.BLL;
using PA.BusinessObjects;


public partial class Report_ListPrint : System.Web.UI.Page
{
    string GroupBrokerID = "";
    string JobNo = "";

    protected void Page_Load(object sender, EventArgs e)
    {

        this.gdvDocument.RowDataBound += new GridViewRowEventHandler(gdvDocument_RowDataBound);
        this.btnUpload.ServerClick += new EventHandler(btnUpload_ServerClick);
        this.DefaultPageRegisterClientScript();

        lbMsgPrint.Visible = false;
        GroupBrokerID = Utilities.GetGroupBrokerID();
        JobNo = Request.QueryString["JobNo"].ToString();

        if (!string.IsNullOrEmpty(JobNo))
            JobNo = JobNo.Trim();

        if (GroupBrokerID == "")
        {
            ShowMessage("�������ö����¡���� ���ͧ�ҡ�س�ѧ������������к� !");
            //VISIBLE
            this.gdvDocument.Visible = false;            
        }
        else
        {
            try
            {                                
                if (!Page.IsPostBack)
                {
                    this.BindData(JobNo, GroupBrokerID); 
                }                                
            }
            catch (Exception ex)
            {
                this.ShowMessage(ex.Message);
            }
        }
    }

    protected void btnUpload_ServerClick(object sender, EventArgs e)
    {
        int index = 0;
        foreach (GridViewRow row in gdvDocument.Rows)
        {
            index += 1;
            FileUpload fileUpload = row.Cells[8].Controls[0].FindControl("fileUpload") as FileUpload;
            int insuredID = Convert.ToInt32(row.Cells[2].Text);

            if (fileUpload.HasFile)
            {
                this.UploadFile(fileUpload, JobNo, insuredID);
            }
        }

        this.BindData(JobNo, GroupBrokerID); 
        //Response.Redirect("ListUpload.aspx?JobNo=" + JobNo);
    }

    protected void gdvDocument_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string jobNo = JobNo;
            string strInsuredID = e.Row.Cells[2].Text.ToString();
            int insuredId = Convert.ToInt32(strInsuredID);
                                    
            PATransUploadFilesBLL clsPATransUploadFiles = new PATransUploadFilesBLL();
            PATransUploadFiles getPATransUploadFiles = new PATransUploadFiles();
            getPATransUploadFiles = clsPATransUploadFiles.GetPATransUploadFiles(jobNo, insuredId);

            string filePath = getPATransUploadFiles.FullPath;
                        
            HtmlInputButton btnView = (HtmlInputButton)e.Row.FindControl("btnView");
            btnView.Attributes["onclick"] = "window.open ( '../" + filePath + "','_blank' )";
            
            //FileUpload fileUpload = (FileUpload)e.Row.FindControl("fileUpload");                                    
        }
    }
       
    private void ShowMessage(string msg)
    {
        lbMsgPrint.Visible = true;
        lbMsgPrint.Text = msg;
        lbMsgPrint.ForeColor = System.Drawing.Color.White;
        lbMsgPrint.Font.Bold = true;
    }
   
    protected void DefaultPageRegisterClientScript()
    {
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptScrolling", "MenuScroll();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptTxtFocus", "setFocusTextbox();", true);

        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptFunction", "<script type='text/javascript' language='javscript'>function setFlagPrint(Flag) {$('[id$=hdnPrintFlag]').val(Flag);$('[id$=btnSetPrintFlag]').click();}</script>", false);

    }

    private void BindData(string JobNo, string GroupBrokerID)
    {
        DataTable DTable = new DataTable();
        PATransUploadFilesBLL getListUploadPolicyByJobNo = new PATransUploadFilesBLL();

        DTable = getListUploadPolicyByJobNo.GetPAListUploadPolicyByJobNo(JobNo, GroupBrokerID);
        gdvDocument.DataSource = DTable;
        gdvDocument.DataBind();
    }

    private void UploadFile(FileUpload fileupload, string jobNo, int insuredID)
    {
        if (fileupload.HasFile)
        {
            string task = "PA";
            string filePath = "../UploadFiles/" + task + "/" + jobNo + "/" + fileupload.FileName;
            int fileSize = fileupload.PostedFile.ContentLength;
            string fileName = fileupload.FileName;
            string user = Utilities.BrokerCode();

            string chkMessage = Utility.UploadFile(fileupload, task, jobNo);

            if (!string.IsNullOrEmpty(chkMessage))
            {
                if (chkMessage.Trim() == "File uploaded successfully.")
                {
                    PATransUploadFilesBLL SetUploadData = new PATransUploadFilesBLL();
                    SetUploadData.SetPATransUploadFiles(JobNo, "", insuredID, fileName, fileSize, filePath, filePath, user);                    
                }
                else
                {
                    this.ShowMessage(chkMessage);
                    return;
                }
            }
            else
            {
                this.ShowMessage(chkMessage);
                return;
            }
        }
        
    }

    //protected void btnUpload_Click(object sender, EventArgs e)
    //{
    //    int index = 0;
    //    foreach (GridViewRow row in gdvDocument.Rows)
    //    {
    //        index += 1;
    //        FileUpload fileUpload = row.Cells[8].Controls[0].FindControl("fileUpload") as FileUpload;
    //        int insuredID = Convert.ToInt32(row.Cells[2].Text);

    //        if (fileUpload.HasFile)
    //        {
    //            this.UploadFile(fileUpload, JobNo, insuredID);
    //        }
    //    }
    //}
}
