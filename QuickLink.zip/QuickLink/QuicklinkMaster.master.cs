﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using DSNWorkFlow.BusinessObjects;
using DSNWorkFlow.BLL;
using DSNWorkFlow.BLL.Authen;
using DSNWorkFlow.BLL.Common;
using DSNWorkFlow.Operational;

public partial class QuicklinkMaster : System.Web.UI.MasterPage
{
    DataTable dt;
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            string tempMsgExpire = Session["BeforeNumDayBeforeExpire"].ToString().Trim();
            if (!tempMsgExpire.Equals(""))
            {
                if (tempMsgExpire.Equals("0"))
                {
                    ShowMessageExpire("บัญชีผู้ใช้งานของท่านจะสามารถใช้งานได้ถึงวันนี้เท่านั้น กรุณาทำการเปลี่ยนรหัสผู้ใช้.");
                }
                else if (tempMsgExpire.Equals("-1"))
                {
                    ShowMessageExpire("บัญชีผู้ใช้งานของท่านได้หมดอายุการใช้งานแล้ว กรุณาทำการเปลี่ยนรหัสผู้ใช้ เพื่อต่ออายุการใช้งาน.");
                }
                else
                {
                    ShowMessageExpire("บัญชีผู้ใช้งานของท่านจะหมดอายุในอีก " + Session["BeforeNumDayBeforeExpire"].ToString() + " วัน กรุณาทำการเปลี่ยนรหัสผู้ใช้.");
                }
            }
            if (!IsPostBack)
            {
                try
                {
                    Session.Timeout = 9000;
                    //Start Get User
                    #region "GET USER HOST AND WEB"

                    try
                    {
                        string tempUserName = Session["Username"].ToString().Trim();
                        if (tempUserName.Equals(""))
                        {
                            Session["Username"] = Utilities.GetUsername().Trim();
                            tempUserName = Session["Username"].ToString().Trim();
                           
                        }
                    }
                    catch { }

                    lblUsername.Text = " ยินดีต้อนรับ : " + Session["Username"].ToString().Trim(); 

                    #endregion
                    //End
                  

                    string temp = Session["BrokerCode"].ToString().Trim();
                    dt = new DataTable();
                    dt = Utilities.GetAllBrokerCodeInGroup();
                  
                    if (dt.Rows.Count > 0)
                    {
                        //BIND DATA TO COMBO
                        DataTable dtTemp = new DataTable();
                        DataRow dr;
                        dtTemp.Columns.Add(new DataColumn("BROKERNAME1", typeof(string)));
                        dtTemp.Columns.Add(new DataColumn("BROKERCODE1", typeof(string)));
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            dr = dtTemp.NewRow();
                            dr["BROKERNAME1"] = dt.Rows[i]["BROKERCODE"].ToString().Trim() + " : " + dt.Rows[i]["BROKERNAME"].ToString().Trim();
                            dr["BROKERCODE1"] = dt.Rows[i]["BROKERCODE"].ToString().Trim();
                            dtTemp.Rows.Add(dr);
                        }
                        cmdBrokerInGroup.DataSource = dtTemp;
                        cmdBrokerInGroup.DataTextField = "BROKERNAME1";
                        cmdBrokerInGroup.DataValueField = "BROKERCODE1";
                        cmdBrokerInGroup.DataBind();

                        string tempBrokerCode = dt.Rows[0]["BROKERCODE"].ToString().Trim();
                        string tempGroupBrokerID = dt.Rows[0]["GROUPBROKERID"].ToString().Trim();
                        string tempUserHostName = dt.Rows[0]["USERHOSTNAME"].ToString().Trim();
                        string tempUserHostPassword = dt.Rows[0]["USERHOSTPASSWORD"].ToString().Trim();
                        if (temp.Equals(""))
                        {

                            Session["BrokerCode"] = tempBrokerCode;
                            Session["GroupBrokerID"] = tempGroupBrokerID;
                            Session["UserHostName"] = tempUserHostName;
                            Session["UserHostPassword"] = tempUserHostPassword;
                            temp = tempBrokerCode;
                        }
                        else
                        {
                            cmdBrokerInGroup.SelectedValue = temp;  //Broker Code

                        }

                        //Menu Authentication
                        this.DSNWorkFlowAuthMenu();
                    }
                    else
                    {
                        ShowMessageExpire("เกิดข้อผิดพลาด ในการใช้งานข้อมูล ตัวแทน กรุณาติดต่อ AXA HelpDesk");
                    }
                }
                catch (Exception ex)
                {
                    lbMessageExpire.Text += "<BR><div style='color:red'>เกิดข้อผิดพลาด ในการใช้งานข้อมูล ตัวแทน กรุณาติดต่อ AXA HelpDesk</div>" + ex.Message;
                    lbMessageExpire.Visible = true;
                        System.Threading.Thread.Sleep(10);
                        Response.Redirect("~/Login.aspx");                  
                  }
            }
            else
            {
                string ckSession = Session["Username"].ToString().Trim();
                if (ckSession.Equals("")) { Response.Redirect("~/Login.aspx"); }
            }
        }
        catch
        {
            Response.Redirect("~/Login.aspx");
        }
    }
    protected void cmdBrokerInGroup_SelectedIndexChanged(object sender, EventArgs e)
    {
        string tempBrokerCode = cmdBrokerInGroup.SelectedValue.Trim();
        Session["BrokerCode"] = tempBrokerCode;
    }
    protected void ShowMessageExpire(string msg)
    {
        lbMessageExpire.Text = msg;
        lbMessageExpire.Visible = true;
    }
    protected void DSNWorkFlowAuthMenu()
    {
        //Check Session Timeout        
        //if (string.IsNullOrEmpty(SecurityUtility.UserCode))
        //    Response.Redirect("../Logout.aspx");

        //string rolesCode = Request.QueryString["roles_code"];
        string rolesCode = string.Empty;
        string fixLocale = "th";

        //if (!string.IsNullOrEmpty(SecurityUtility.UserGroup))
        //    rolesCode = SecurityUtility.UserGroup.Trim();

        foreach (string role in Roles.GetRolesForUser(Utilities.GetUsername().Trim()))
        {
            rolesCode = role;
        }


        try
        {
            Common_auth_menu authmenu = new Common_auth_menu();
            authmenu.Roles_code = rolesCode;
            authmenu.Isactive = true;
            authmenu.Common_menu.Locale = fixLocale;

            #region get all enable menu by roles code
            ArrayList lstCategoryIdByRoles = new ArrayList();
            ProcessGetAuthMenuSelectCategoryDataByRolesCodeLocale getAllMenuByRoles = new ProcessGetAuthMenuSelectCategoryDataByRolesCodeLocale(rolesCode, fixLocale);
            getAllMenuByRoles.Invoke();
            if (getAllMenuByRoles.RowCount > 0)
            {
                foreach (DataRow chkDr in getAllMenuByRoles.ResultSet.Tables[0].Rows)
                {
                    string categoryId = chkDr[3].ToString();
                    lstCategoryIdByRoles.Add(categoryId);
                }
            }
            #endregion

            ProcessGetAuthMenuSelectCategoryDataByRolesCodeLocaleIsActive getmenubyroles = new ProcessGetAuthMenuSelectCategoryDataByRolesCodeLocaleIsActive();
            getmenubyroles.Common_auth_menu = authmenu;
            getmenubyroles.Invoke();
            if (getmenubyroles.RowCount > 0)
            {
                foreach (DataRow dr in getmenubyroles.ResultSet.Tables[0].Rows)
                {
                    int catParent = 0;
                    string strCatParent = dr[0].ToString();
                    string strLocale = dr[1].ToString();
                    string strCatParentName = dr[2].ToString();
                    //string strHidden = strCatParentName + ",";
                    string strHidden = string.Empty;
                    //----------------
                    if (!string.IsNullOrEmpty(strCatParent))
                        catParent = Convert.ToInt32(strCatParent);

                    ProcessGetMenuByParentIDLocale getmunubyparent = new ProcessGetMenuByParentIDLocale(catParent, strLocale);
                    getmunubyparent.Invoke();
                    if (getmunubyparent.RowCount > 0)
                    {
                        foreach (DataRow dr1 in getmunubyparent.ResultSet.Tables[0].Rows)
                        {
                            string strCatId = dr1[0].ToString();

                            if (lstCategoryIdByRoles.Contains(strCatId) == true)
                            {
                                string strCatName = dr1[2].ToString();
                                int catChild = Convert.ToInt32(dr1[0].ToString());
                                string strCatPath = dr1[4].ToString();
                                //----------------find child---------------------
                                ProcessGetMenuByParentIDLocale getmunubychild = new ProcessGetMenuByParentIDLocale(catChild, strLocale);
                                getmunubychild.Invoke();
                                if (getmunubychild.RowCount > 0)
                                {
                                    strHidden += strCatName + ",child,";

                                    foreach (DataRow dr2 in getmunubychild.ResultSet.Tables[0].Rows)
                                    {
                                        string strChildCatId = dr2[0].ToString();

                                        if (lstCategoryIdByRoles.Contains(strChildCatId) == true)
                                        {
                                            string strChildCatName = dr2[2].ToString();
                                            string strChildCatPath = dr2[4].ToString();
                                            //----------------find child---------------------


                                            strHidden += strChildCatName + "," + strChildCatPath + ",";
                                        }
                                    }
                                    strHidden += "child,";
                                }
                                else
                                {

                                    strHidden += strCatName + "," + strCatPath + ",";
                                }
                            }
                        }
                    }

                    switch (catParent)
                    {
                        case 1: this.hdnMotor.Value = strHidden;
                            break;
                        case 2: this.hdnTa.Value = strHidden;
                            break;
                        case 3: this.hdnPa.Value = strHidden;
                            break;
                        case 4: this.hdnHome.Value = strHidden;
                            break;
                        case 5: this.hdnQuaotation.Value = strHidden;
                            break;
                        case 7: this.hdnKYC.Value = strHidden;
                            break;
                    }
                }
            }
        }
        catch (Exception ex)
        {

        }
    }
}
