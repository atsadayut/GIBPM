﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Globalization;

using WFQuickLink;
using WFQuickLinkReport;

public partial class Renew_RenewPolicy : System.Web.UI.Page
{
    private string msg;
    private string msgStatus;
    string ccDate;
    string effectiveDate;
    string vDateNow;
    string barCodeValue;
    DataTable dt;
    string clientType;
    string clientCode;
    string idCard;
    string BrNo;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        this.DefaultPageRegisterClientScript();

        vDateNow = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        string tempValue = vDateNow.Substring(0, 4);
        
        if (Int32.Parse(tempValue) > 2540)
        {
            vDateNow = DateTime.Now.AddYears(-543).ToString("yyyy-MM-dd HH:mm:ss");
        }

        if (!Page.IsPostBack)
        {
            DataTable dt = new DataTable();
            DataTable dt1 = new DataTable();
            DataTable dt2 = new DataTable();
            DataRow dr;
            DataView dv;
            string policyNumber = Request.QueryString["CHDRNUM"].ToString().Trim();
            string PolType = Request.QueryString["POLICYTYPE"].ToString().Trim();
            string motorProvince = Request.QueryString["REGPRV"].ToString().Trim();
            Box_InquiryMotor[] arrMotorData;
            Box_Inquriy policyData;
            lblErrorMsg.Visible = false;
            btnPrint.Visible = false;
            clientType = null;

            UserHostDetails user;
            user = UserMember.GetUserHost(Utilities.GetUsername().Trim());
            string Username = user.UserHostName.ToString();
            string Password = user.UserHostPassword.ToString();

            QuickLinkService getPolicyMR = new QuickLinkService();
            policyData = getPolicyMR.GetPolicyInquiry(Username, Password, policyNumber, out arrMotorData, out msg, out msgStatus);
            
            if (!motorProvince.Equals(""))
            {
                this.BindResultMotorProvince(cmbMotorProvince);
                cmbMotorProvince.SelectedValue = motorProvince;
            }
            else
            {
                this.BindResultMotorProvince(cmbMotorProvince);
            }

            
            
            if (msgStatus == "SUCCESS")
            {                
                ///Check Date for Renewal in 20 days condition
                ///
                dt2 = Renew.GetPolicyMRData(policyNumber);
              if (dt2.Rows.Count > 0)
                {
                    ccDate = dt2.Rows[0]["CCDATE"].ToString();
                    //ccDate = policyData.Inception.Trim();
                }
                string CCDate = "";
                if (ccDate == "" || ccDate == string.Empty)
                {

                }
                else
                {
                    CCDate = DateTime.Parse(ccDate).ToString("yyyy-MM-dd HH:mm:ss");
                    string tempDate = CCDate.Substring(0, 4);
                    if (Int32.Parse(tempDate) > 2540)
                    {
                        CCDate = DateTime.Parse(ccDate).AddYears(-543).ToString("yyyy-MM-dd HH:mm:ss");
                    }

                    //
                    //DateTime CCDATE = DateTime.Parse(ccDate);
                    //DateTime now = DateTime.Now;
                }

                DateTime CCDATE = DateTime.Parse(CCDate);
                DateTime now = DateTime.Parse(vDateNow);

                int limitNumDateRenew = QuickLinkConfiguration.LimitDateForRenew; //-30 
                int tempLimit = Math.Abs(limitNumDateRenew);
                UInt32 UlimitNumDateRenew = (UInt32)tempLimit;            //30

                //DateTime addDate = now.AddDays(30);
                //DateTime minusDate = now.AddDays(-30);
                limitNumDateRenew = -1;

                DateTime addDate = now.AddDays(UlimitNumDateRenew);
                DateTime minusDate = now.AddDays(limitNumDateRenew);

                bool chkDateBefore = (addDate >= CCDATE);
                bool chkDateAfter = (minusDate <= CCDATE);

                bool iscompl = Utilities.IsPolicyTypeCompulsary(policyData.PolicyType.Trim());

               


                //equal compuls not check
               // if (!iscompl)
               // {
                if ((chkDateBefore == true) && (chkDateAfter == true))
                {

                }
                else
                {

                    if (iscompl)
                    {
                        if (chkDateBefore == false)
                        { }
                        else {
                            lblErrorMsg.Text = "ไม่สามารถดำเนินการต่ออายุกรมธรรม์ได้เนื่องจากผิดเงื่อนไข!!!<BR>(ต้องต่ออายุก่อนวันหมดอายุภายใน " + UlimitNumDateRenew + " วันเท่านั้น)<br>";
                            lblErrorMsg.Visible = true;
                            btnRenew.Attributes.Add("style", "display: none;");

                            //btnRenew.Visible = false;
                            btnPrint.Visible = false;
                        }
                    }
                    else
                    {
                        lblErrorMsg.Text = "ไม่สามารถดำเนินการต่ออายุกรมธรรม์ได้เนื่องจากผิดเงื่อนไข!!!<BR>(ต้องต่ออายุก่อนวันหมดอายุภายใน " + UlimitNumDateRenew + " วันเท่านั้น)<br>";
                        lblErrorMsg.Visible = true;
                        btnRenew.Attributes.Add("style", "display: none;");
                        //btnRenew.Visible = false;
                        btnPrint.Visible = false;
                    }
                }
                //}

                ///

                string ref1 = policyData.Reference1;
                string tempRef1 = "";
                string tempLastRef = "";
                string mrYear = "";
                string mrMonth = "";
                string mrDay = "";
                string currMrDate = "";

                if (!(ref1 == "" || ref1 == string.Empty))
                {
                    int ref1Length = ref1.Length;
                    tempRef1 = ref1.Substring(0, ref1Length - 8);
                    tempLastRef = ref1.Substring(ref1Length - 8, 8);

                    mrYear = tempLastRef.Substring(0, 4);
                    mrMonth = tempLastRef.Substring(4, 2);
                    mrDay = tempLastRef.Substring(6, 2);
                    currMrDate = mrDay + "/" + mrMonth + "/" + mrYear;
                }

                //Call Check Claim Service                       
                bool getFound;
                bool getFoundSp;
                getPolicyMR.RenewCheckClaim(Username, Password, policyNumber, currMrDate, out msgStatus, out getFound, out getFoundSp);

                if (msgStatus.Trim() == "SUCCESS" && getFound == true)
                {
                    lblErrorMsg.Text = "<font color=red>" + "ไม่สามารถดำเนินการต่ออายุกรมธรรม์ได้เนื่องจากผิดเงื่อนไข!!!<BR>(มีประวัติการเคลมเกิดขึ้น กรุณาติดต่อ AXA HelpDesk) </font>";
                    lblErrorMsg.Visible = true;
                    btnRenew.Attributes.Add("style", "display: none;");
                   
                   // btnRenew.Visible = false;
                    btnPrint.Visible = false;
                }
                //End Call

                lblPolicyNumber.Text = policyNumber;
                lblAgent.Text = policyData.AgentCode;
                lblAgentName.Text = policyData.AgentName;
                lblEffective.Text = policyData.EffectiveDate;
                effectiveDate = policyData.EffectiveDate;
                ///Default Value in DatePicker1
                ///
                /*if (!IsPostBack)
                {
                    DatePicker1.CalendarDateString = policyData.EffectiveDate;
                }*/
                ///
                //DatePicker1.CalendarDateString = policyData.EffectiveDate;
                lblExpire.Text = policyData.Expiry;
                lblName.Text = policyData.ContractOwnerName;
                lblType.Text = policyData.PolicyType;
                lblTypeDes.Text = PolType.ToString();
                bool ckPType = Utilities.IsPolicyTypeCompulsary(policyData.PolicyType.Trim());
                if (!ckPType)
                {
                    if (tempRef1.ToString().Trim().Length == 0)
                    {
                        tempRef1 = "อู่ประกัน";
                    }
                }

                lblRef1.Text = tempRef1.Trim();
                txtRef2.Text = policyData.Reference2.Trim();

                //if (policyData.AgentCode.Trim() == QuickLinkConfiguration.BrokerTisco.Trim())
                //{
                //    txtRef2.ReadOnly = false;
                //}
                //else
                //{
                txtRef2.ReadOnly = false;
                //}

                dt1 = Client.GetClientData(policyData.ContractOwnerCode);

                //UPDATE 2010-09-29
                this.txbHdClientCode.Text = policyData.ContractOwnerCode;
                

                if (dt1.Rows.Count > 0)
                {
                    lblAddress.Text = dt1.Rows[0]["CLTADDR01"].ToString();
                    lblAddress.Text += " " + dt1.Rows[0]["CLTADDR02"].ToString();
                    lblAddress.Text += " " + dt1.Rows[0]["CLTADDR03"].ToString();
                    lblAddress.Text += " " + dt1.Rows[0]["CLTADDR04"].ToString();
                    lblAddress.Text += " " + dt1.Rows[0]["CLTADDR05"].ToString();
                    clientType = dt1.Rows[0]["CLTTYPE"].ToString();
                    clientCode = dt1.Rows[0]["CLNTNUM"].ToString();
                    idCard = dt1.Rows[0]["SECUITYNO"].ToString();
                    BrNo = dt1.Rows[0]["ZHUBNO"].ToString();
                }

                if (clientType == "P")
                {
                    btnModifyClient.Visible = true;
                }
                else
                {
                    btnModifyClient.Visible = false;
                }

                dt.Columns.Add(new DataColumn("รหัส", typeof(string)));
                dt.Columns.Add(new DataColumn("ชื่อรถ", typeof(string)));
                dt.Columns.Add(new DataColumn("เลขทะเบียน", typeof(string)));
                dt.Columns.Add(new DataColumn("เลขตัวถัง", typeof(string)));
                dt.Columns.Add(new DataColumn("แบบตัวถัง", typeof(string)));
                dt.Columns.Add(new DataColumn("จำนวนที่นั่ง", typeof(string)));

                double premiumGrossValue = 0;
                double stampValue = 0;
                double vatValue = 0;
                double premiumTotalValue = 0;
                CultureInfo culture = new CultureInfo("th-TH");

                string specifier = "C";

                for (int i = 0; i < arrMotorData.Length; i++)
                {
                    txtCover.Text = arrMotorData[i].Cover.Trim();
                    txtODSI.Text = arrMotorData[i].ODSI.Trim();
                    //txtBarcode.Text = arrMotorData[i].Barcode.Trim();
                    dr = dt.NewRow();
                    dr["รหัส"] = arrMotorData[i].MakeCode;
                    dr["ชื่อรถ"] = arrMotorData[i].MakeCodeDescription;
                    dr["เลขทะเบียน"] = arrMotorData[i].RegNo;
                    dr["เลขตัวถัง"] = arrMotorData[i].Chassis;
                    dr["แบบตัวถัง"] = arrMotorData[i].Body;
                    dr["จำนวนที่นั่ง"] = arrMotorData[i].Seats;
                    dt.Rows.Add(dr);

                    //Add data to Hidded Field
                    txtHdChassis.Text = arrMotorData[i].Chassis.Trim();
                    txtHdRegNo.Text = arrMotorData[i].RegNo.Trim();
                    //

                    ///Get Total Premium
                    ///
                    for (int j = 0; j < arrMotorData[i].PremiumGross.Length; j++)
                    {
                        try
                        {
                            premiumGrossValue += double.Parse(arrMotorData[i].PremiumGross[j]);
                        }
                        catch
                        { 
                        
                        }
                    }

                    for (int k = 0; k < arrMotorData[i].PremiumStampDuty.Length; k++)
                    {
                        try
                        {
                            stampValue += double.Parse(arrMotorData[i].PremiumStampDuty[k]);
                        }
                        catch
                        { 
                        }
                    }

                    for (int l = 0; l < arrMotorData[i].PremiumVat.Length; l++)
                    {
                        try
                        {
                            vatValue += double.Parse(arrMotorData[i].PremiumVat[l]);
                        }
                        catch
                        {

                        }
                    }

                    for (int m = 0; m < arrMotorData[i].PremiumTotal.Length; m++)
                    {
                        try
                        {
                            premiumTotalValue += double.Parse(arrMotorData[i].PremiumTotal[m]);
                        }
                        catch
                        { 
                        
                        }
                    }
                }
                ////
                txtLicense.Text = txtHdRegNo.Text.Trim();
                cmbMotorProvince.SelectedValue = txtHdRegPrv.Text.Trim();
                try
                {
                    txtIDCard.Text = dt1.Rows[0]["SECUITYNO"].ToString();
                    txtBrNo.Text = dt1.Rows[0]["ZHUBNO"].ToString();
                    
                }
                catch { txtIDCard.Text = ""; }
                ///Premium Binding
                ///
                lblNetPremium.Text = premiumGrossValue.ToString(specifier, culture).Substring(1, premiumGrossValue.ToString(specifier, culture).Length - 1);
                lblNetStamp.Text = stampValue.ToString(specifier, culture).Substring(1, stampValue.ToString(specifier, culture).Length - 1);
                lblNetVAT.Text = vatValue.ToString(specifier, culture).Substring(1, vatValue.ToString(specifier, culture).Length - 1);
                lblNetTotal.Text = premiumTotalValue.ToString(specifier, culture).Substring(1, premiumTotalValue.ToString(specifier, culture).Length - 1);
                ////

                ///Grid Binding
                ///
                dv = dt.DefaultView;

                gridMotorDetails.DataSource = dv;
                gridMotorDetails.DataBind();
                ////   
            }
            else
            {
                lblErrorMsg.Text = "<font color=red>" + "ไม่พบข้อมูลที่ต้องการหรือเกิดข้อผิดพลาดในการเรียกข้อมูล!!!กรุณาติดต่อ AXA HelpDesk </font>";
                lblErrorMsg.Text += "<br>" + msg;
                lblErrorMsg.Visible = true;
                btnRenew.Attributes.Add("style", "display: none;");
                
                //btnRenew.Visible = false;
                btnPrint.Visible = false;
            }
        }        
    }
    protected void gridMotorDetails_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        string policyNumber = Request.QueryString["CHDRNUM"].ToString().Trim();
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            int r = (int)e.Row.RowIndex;
            e.Row.Attributes.Add("onmouseover", "xfocus(this);");
            e.Row.Attributes.Add("onmouseout", "xleave(this," + r + ");");
            string m_MakeCode = e.Row.Cells[0].Text.Trim();
            string m_RegNo = e.Row.Cells[2].Text.Trim();
            //e.Row.Attributes.Add("onclick", "alert('" + m_MakeCode + "');");
            e.Row.Attributes.Add("onclick", "OpenMotorDetail('" + policyNumber + "','" + m_MakeCode + "');");
            //e.Row.Attributes.Add("onclick", "OpenMotorDetail();");
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("RenewMain.aspx");
    }
    protected void btnRenew_Click(object sender, EventArgs e)
    {
        if (txtLicense.Text.Trim().Length == 0 & cmbMotorProvince.SelectedValue != "99") 
        {
            lblErrorMsg.Text = "<font color=red>" + "กรุณาใส่ทะเบียนรถยนต์ </BR> " + msg + "</font>";
            lblErrorMsg.Visible = true;

        }
        else if (cmbMotorProvince.SelectedValue == "99" & txtLicense.Text.Trim().Length > 0)
        {
            lblErrorMsg.Text = "<font color=red>" + "กรุณาเลือกทะเบียนจังหวัด </BR> " + msg + "</font>";
            lblErrorMsg.Visible = true;

        }
        else if (txtIDCard.Text.Trim().Length != 13 )
        {
            lblErrorMsg.Text = "<font color=red>" + "กรุณาเลขที่ผู้เสียภาษี/เลขที่บัตรประชาชน </BR> " + msg + "</font>";
            lblErrorMsg.Visible = true;
        }
        else if (clientType == "C" && txtBrNo.Text.Trim().Length == 0) {
            lblErrorMsg.Text = "<font color=red>" + "กรุณาใส่ข้อมูลสาขาที่เป็นตัวเลข </BR> " + msg + "</font>";
            lblErrorMsg.Visible = true;
        }
        else
        {
            string policyNumber = Request.QueryString["CHDRNUM"].ToString().Trim();
            string msgPremium = "O/S Premium Present";
            string agreementDate = DatePicker1.CalendarDateString;
            string ref1;
            if (lblRef1.Text.Trim() == "อู่ประกัน")
            { ref1 = ""; }
            else
            { ref1 = lblRef1.Text.Trim(); }
            string ref2 = txtRef2.Text.Trim();
            string booksVolume = "";
            string booksNo = "";
            string booksDate = "";

            UserHostDetails user;
            user = UserMember.GetUserHost(Utilities.GetUsername().Trim());
            string Username = user.UserHostName.ToString();
            string Password = user.UserHostPassword.ToString();

            ///Check Agreement Date must not greater than Effective Date
            ///
            if ((agreementDate.Trim() == "") || (agreementDate.Trim() == string.Empty))
            {
                lblErrorMsg.Text = "<font color=red>" + "กรุณาระบุวันที่ทำสัญญา!!! รูปแบบ ค.ศ.(dd/MM/yyyy)</font>";
                lblErrorMsg.Visible = true;
                return;
            }
            else
            {
                

                //
                //MM/dd/yyyy  ,06/30/2009

                //CultureInfo culture = new CultureInfo("en-US");

                //string think = "6/21/2009";
                //DateTime Try = DateTime.Parse(think,new System.Globalization.CultureInfo("en-US"));
                //Response.Write(Try);

                DateTime agDate = DateTime.Parse(agreementDate, new System.Globalization.CultureInfo("th-TH"));
                DateTime efDate = DateTime.Parse(lblEffective.Text, new System.Globalization.CultureInfo("th-TH"));

                bool chkAgDate = (agDate <= efDate);

                if (chkAgDate == true)
                {
                    if (chkBooks.Checked == true)
                    {
                        booksVolume = txbBooksValume.Text.Trim();
                        booksNo = txbBooksNo.Text.Trim();
                        booksDate = txbBooksDate.Text.Trim();
                        if (string.IsNullOrEmpty(booksVolume) | string.IsNullOrEmpty(booksNo) | string.IsNullOrEmpty(booksDate))
                        {
                            lblErrorMsg.Text = "<font color=red>" + "คุณได้ทำการเลือกส่วนการ บันทึกใบเสร็จรับเงินชั่วคราวไว้  กรุณาระบุ เล่มที่ ,เลขที่ และ วันที่รับเงิน ด้วย!.</font>";
                            lblErrorMsg.Visible = true;
                            return;
                        }
                    }
                    else
                    {
                        booksVolume = "99999";
                        booksNo = "99999";
                        booksDate = lblEffective.Text;
                    }

                    BrNo = txtBrNo.Text.ToString();
                    if (BrNo.ToString().Length == 1 ) {BrNo = "00" + BrNo;}
                    if (BrNo.ToString().Length == 2 ) {BrNo = "0" + BrNo;}
                     

                    QuickLinkService renewPolicyMR = new QuickLinkService();
                    //msg = renewPolicyMR.RenewPolicy(Username, Password, policyNumber, agreementDate, ref1, ref2, out msgStatus);
                     string mg;
                    if (clientType == "C") {
                        mg = renewPolicyMR.EditCorporateClientTaxID(Username,Password,clientCode,idCard,BrNo ,out mg,out msgStatus);
                    } else {
                        mg = renewPolicyMR.EditIndividualClientTaxID(Username, Password, clientCode, idCard, out msgStatus);
                    }

                   if ((mg == "") || (mg == string.Empty))
                    {
                        if (msgStatus.Trim() == "SUCCESS")
                        {
                            msg = renewPolicyMR.RenewPolicy(Username, Password, policyNumber, agreementDate, ref1, ref2, booksVolume, booksNo, booksDate, txtBarcode.Text, txtLicense.Text, cmbMotorProvince.SelectedValue, out msgStatus, out barCodeValue);

                            string outputString = "";
                            txtHdRegNo.Text = txtLicense.Text;
                            txtHdRegPrv.Text = cmbMotorProvince.SelectedValue;
                            txtBarcode.Text = barCodeValue;
                            if ((msg == "") || (msg == string.Empty))
                            {
                                if (msgStatus.Trim() == "SUCCESS")
                                {
                                    lblErrorMsg.Text = "ทำการต่ออายุกรมธรรม์เรียบร้อยแล้ว!!!";
                                    lblErrorMsg.ForeColor = System.Drawing.Color.LightGreen;
                                    lblErrorMsg.Font.Bold = true;

                                    lblErrorMsg.Visible = true;
                                    
                                    btnPrint.Visible = true;
                                    btnRenew.Attributes.Add("style", "display: none;");
                                    //btnRenew.Visible = false;
                                    Renew.UpdatePolicyMR(policyNumber);
                                    OperateRePrintForRenew(policyNumber, barCodeValue);
                                    OperateChasisForRenew(policyNumber, lblType.Text.Trim(), txtHdChassis.Text, txtHdRegNo.Text);
                                }
                                else
                                {
                                    lblErrorMsg.Text = "<font color=red>" + "ทำการต่ออายุกรมธรรม์ไม่สำเร็จ!!!โปรดติดต่อ AXA HelpDesk" + msg + "</font>";
                                    lblErrorMsg.Visible = true;
                                }
                            }
                            else
                            {
                                msg.Substring(0, 20);
                                if (string.Compare(msgPremium.Trim(), outputString.Trim(), false) == 0)
                                {
                                    btnRenew.Attributes.Add("style", "display: none;");
                                    //btnRenew.Visible = false;
                                    btnPrint.Visible = false;
                                    lblErrorMsg.Text = "<font color=red>" + "ไม่สามารถต่ออายุกรมธรรม์ได้เนื่องจากยังไม่ได้รับการชำระเบี้ยประกัน!</font>";
                                    lblErrorMsg.Visible = true;
                                    return;
                                }
                                else
                                {
                                    if (msgStatus.Trim() == "SUCCESS")
                                    {
                                        lblErrorMsg.Text = "ทำการต่ออายุกรมธรรม์เรียบร้อยแล้ว!!!";
                                        lblErrorMsg.ForeColor = System.Drawing.Color.LightGreen;
                                        lblErrorMsg.Font.Bold = true;

                                        lblErrorMsg.Visible = true;
                                        btnPrint.Visible = true;
                                        btnRenew.Attributes.Add("style", "display: none;");
                                        //btnRenew.Visible = false;
                                        Renew.UpdatePolicyMR(policyNumber);
                                        OperateRePrintForRenew(policyNumber, barCodeValue);
                                        OperateChasisForRenew(policyNumber.Trim(), lblType.Text.Trim(), txtHdChassis.Text.Trim(), txtHdRegNo.Text.Trim());
                                    }
                                    else
                                    {
                                        int id = msg.IndexOf("-7");

                                        if (id > 0) { msg = "เนื่องจากขณะนี้ท่านมียอดหนี้ค้างชำระเกินวงเงินที่กำหนด ขออภัยในความไม่สะดวก"; }

                                        lblErrorMsg.Text = "<font color=red>" + "ทำการต่ออายุกรมธรรม์ไม่สำเร็จ!!!โปรดติดต่อ AXA HelpDesk </BR> " + msg + "</font>";
                                        lblErrorMsg.Visible = true;
                                    }
                                }
                            }

                        }

                        }
                        else
                        {
                            lblErrorMsg.Text = "<font color=red>" + "เงื่อนไขไม่ถูกต้อง โปรดตรวจสอบวันที่ทำสัญญา!!!<BR>(วันที่ทำสัญญาต้องไม่เกินวันที่กรมธรรม์เริ่มคุ้มครอง)</font>";
                            lblErrorMsg.Visible = true;
                            return;
                        }
                   }
            }
        }
        ////                        
    }
    protected void btnPrint_Click(object sender, EventArgs e)
    {        
	    #region "GET USER HOST"
        UserHostDetails user;
        user = UserMember.GetUserHost(Utilities.GetUsername().Trim());
        string Username = user.UserHostName.ToString();
        string Password = user.UserHostPassword.ToString();
        #endregion
        

	    DocumentService reportService = new DocumentService();       
        string policyNumber = Request.QueryString["CHDRNUM"].ToString().Trim();
        DataTable dt = new DataTable();
        bool chkReport = Reports.CheckReportJPackage(policyNumber);
        Box_Document PolicyOutReportData;
        Box_Message[] arrMessageOutReport;
        Box_Document[] arrPolicyOutReport;
        bool chkType = Utilities.IsPolicyTypeCompulsary(lblType.Text.Trim());
        if (chkReport == false)
        {
            string policyType = "";
            string fleet = "0";
            string pClass = Renew.CheckClass(txtCover.Text, txtODSI.Text);
            string barCode = txtBarcode.Text;
            
            /*if (lblType.Text.Trim() == "VPG")
            {
                policyType = "COMPL";
            }*/
            if (chkType == true)
            {
                policyType = "COMPL";
            }
            else
            {
                policyType = "VOLUN";
            }
            Policy.InsertJoinPackage(policyType, pClass, fleet, "0", policyNumber, barCode);
        }
        else
        {
            Reports.UpdateFlagReport(policyNumber);

            string policyType = "";
            string fleet = "0";
            string pClass = Renew.CheckClass(txtCover.Text, txtODSI.Text);
            string barCode = txtBarcode.Text;
            /*if (lblType.Text.Trim() == "VPG")
            {
                policyType = "COMPL";
            }*/
            if (chkType == true)
            {
                policyType = "COMPL";
            }
            else
            {
                policyType = "VOLUN";
            }
            Policy.InsertJoinPackage(policyType, pClass, fleet, "0", policyNumber, barCode);
        }

        dt = Reports.GetListSpool(policyNumber);
        int count = dt.Rows.Count;
        string spoolName = "";                  
        arrPolicyOutReport = new Box_Document[count];
        int i = 0;

        if (count > 0)
        {
            foreach (DataRow dr in dt.Rows)
            {
                PolicyOutReportData = new Box_Document();
                spoolName = dr["SpoolName"].ToString();
                PolicyOutReportData.PolicyNo = policyNumber;
                PolicyOutReportData.Document = spoolName;
                PolicyOutReportData.Flag = true;
                arrPolicyOutReport[i] = PolicyOutReportData;
                i += 1;
            }
            try
            {
                arrMessageOutReport = reportService.GetDocument(arrPolicyOutReport, Username, Password);                
            }
            catch (Exception ex)
            {
                //
                //return;
                lblErrorMsg.Text = "<font color=red>" + ex.ToString()+"</font>";
            }

            //if (lblType.Text.Trim() == "VPG"
            //2010-02-03 To add type of CMI policy 
            bool ckType = Utilities.IsPolicyTypeCompulsary(lblType.Text.Trim());

            //if (lblType.Text.Trim() == "VBY" || lblType.Text.Trim() == "VCF" || lblType.Text.Trim() == "VCY" || lblType.Text.Trim() == "VMD" || lblType.Text.Trim() == "VMY" || lblType.Text.Trim() == "VPF" || lblType.Text.Trim() == "VPG" || lblType.Text.Trim() == "VPY" || lblType.Text.Trim() == "VSY")
            if (ckType)
                {
                //Response.Redirect("https://www.eservices.axa.co.th/QuickLink/Report/ListPrint.aspx?compl=" + policyNumber + "&volun=");
                Response.Redirect("../Report/ListPrint.aspx?compl=" + policyNumber + "&volun=");
            }
            else
            {
                //Response.Redirect("https://www.eservices.axa.co.th/QuickLink/Report/ListPrint.aspx?volun=" + policyNumber + "&compl=");
                Response.Redirect("../Report/ListPrint.aspx?volun=" + policyNumber + "&compl=");
            }
        }
    }

    private void OperateRePrintForRenew(string PolicyNumber,string BarCode)
    {
        bool chkExistData = PolicyReprint.chkRenewPolicyForPrint(PolicyNumber);

        if (chkExistData == true)
        {
            PolicyReprint.UpdatePolicyForPrint(PolicyNumber);
        }
                
        #region "SAVE DATA TO TABLE POLICYFORPRINT"
        try
        {
            PolicyForPrintData printdata = new PolicyForPrintData();
            string policyType = "";
            string job = "";
            bool chkType = Utilities.IsPolicyTypeCompulsary(lblType.Text.Trim());
            if (chkType == true)
            {
                policyType = "COMPL";
                printdata.VolunPolicy = "";
                printdata.ComplPolicy = PolicyNumber;
            }
            else
            {
                policyType = "VOLUN";
                printdata.VolunPolicy = PolicyNumber;
                printdata.ComplPolicy = "";
            }

            job = Motor.GetJobNumber("JOBRNO");
            Motor.UpdateJobRenew(job);

            printdata.JobNo = job; //JR00000001
            printdata.PolicyCreateType = policyType;
            printdata.PolicyPackageType = Renew.CheckClass(txtCover.Text, txtODSI.Text); //Class 1,Class 5,Class 3, 
            printdata.PolicyPackageFullType = "";
            printdata.ClientCode = "";//cd.ClientNo;
            printdata.ClientFullName = lblName.Text;
            printdata.Inception = lblEffective.Text;
            printdata.ExpireDate = lblExpire.Text;
            printdata.IssuedDate = DateTime.Today;//DateTime.Now;
            printdata.IsFleet = '0';
            printdata.IsSplitVat = '0';            
            printdata.Barcode = BarCode;
            printdata.BrokerCode = Utilities.BrokerCode();
            printdata.ProgramCreate = "Renew";
            printdata.ProgramUpdate = "";
            printdata.IsUseCurrent = true;
            printdata.CreateDate = DateTime.Now;
            ////printdata.UpdateDate = DateTime.Now;
            ////printdata.CancelDate = DateTime.Now;

            printdata.GroupBrokerId = Utilities.GetGroupBrokerID();

            PolicyReprint.InsertPolicyForPrint(printdata);

        }
        catch (Exception ex)
        {
            lblErrorMsg.Text = "<font color=red>" + "เกิดข้อผิดพลาดในการนำข้อมูลเข้าฐานข้อมูลส่วนพิมพ์กรมธรรม์ย้อนหลัง!!!(กรุณาติดต่อ AXA HelpDesk)</font>";
            lblErrorMsg.Text += "<br>" + ex.ToString();
            lblErrorMsg.Visible = true;
            return;
        }
        #endregion
    }

    private void OperateChasisForRenew(string policy,string cnttype,string chassis,string regno)
    {
        bool chkExistData = Chassis.chkPolicyChassis(policy, cnttype, chassis);
        string exdate = lblExpire.Text;
        ChassisData chassisData = new ChassisData();

        if (chkExistData == true)
        {
            Chassis.UpdateChassis(exdate, policy, cnttype, chassis);
        }
        else
        {
            chassisData.PolicyNo = policy;
            chassisData.ContactType = cnttype;
            chassisData.ExpiryDate = exdate;
            chassisData.Regno = regno;
            chassisData.Chassis = chassis;
            chassisData.Source = "WEB";
            Chassis.CreateChassis(chassisData);
        }
    }
    private void BindResultMotorProvince(DropDownList province)
    {
        dt = Motor.GetAllProvinceMotor();

        DataRow dr = dt.NewRow();
        dr["LONGDESC"] = "กรุงเทพมหานคร";
        dr["DESCITEM"] = "กท";
        dt.Rows.InsertAt(dr, 0);

        //BIND DATA TO COMBO Garage
        province.DataSource = dt;
        province.DataTextField = "LONGDESC";
        province.DataValueField = "DESCITEM";
        province.DataBind();

        dt.Clear();

    }
    protected void txtIDCard_TextChanged(object sender, EventArgs e)
    {
        string policyholdertype;
        if (clientType.ToString() == "P")
        {
            policyholdertype = "Private"; //CHECK POLICY HOLDER TYPE
        }
        else { policyholdertype = "Corporate"; }
 
        if (!string.IsNullOrEmpty(this.txtIDCard.Text.Trim()))
        {
            if (string.Compare(policyholdertype, "Private") == 0)
            {

                if (txtIDCard.Text.Trim().Length == 13)
                {
                    if (TA.TAUtilities.ChkIDNO(txtIDCard.Text.Trim()) == true)
                    {
                        this.txtIDCard.Focus();
                    }
                    else
                    {
                        TA.TAUtilities.msgBOX(this.Page, "เลขที่บัตรประชาชนไม่ถูกต้อง");
                        this.txtIDCard.Text = "";
                    }
                }
                else
                {
                    //Pending Check Passport Logic

                    //TA.TAUtilities.msgBOX(this.Page, "เลขที่บัตรประชาชนไม่ถูกต้อง (13 หลัก)");
                    //this.txtIDCard.Text = "";
                }
            }
            else
            {
                //กรณี Commercial
                this.txtIDCard.Focus();
            }
        }
        else
        {
            TA.TAUtilities.msgBOX(this.Page, "กรุณาระบุเลขที่บัตรประชาชน/Passport No./Tax ID");
            this.txtIDCard.Focus();
        }
    }

    protected void DefaultPageRegisterClientScript()
    {
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptScrolling", "MenuScroll();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptTxtFocus", "setFocusTextbox();", true);
        //ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDrawCorner", "DrawDivCorner();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDisplayMsg", "DisplayWarning();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDatePicker", "<script type='text/javascript' language='javascript'>  $(document).ready(function () {  $('.MOTOR').find('img').attr('src', '../Images/Index/MOTOR1.png');  $('.MOTOR').find('a').css('color', '#922d3d'); $('.MOTOR').hover( function () { $(this).find('img').attr('src', '../Images/Index/MOTOR1.png'); } , function () { $(this).find('img').attr('src', '../Images/Index/MOTOR1.png'); } );addSubMenu('hdnMotor', '.subNavigate', 'ต่ออายุกรมธรรม์', '');Accordion('.wizard', 'hdnCriteriaStep');});</script>", false);
    }
}
