﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data ;
using System.Globalization;

using WFQuickLink;
public partial class Renew_ModifyClient : System.Web.UI.Page
{
    DataTable dt;

    protected void Page_Load(object sender, EventArgs e)
    {
        //PERSONAL CLIENT
        cmbP_Language.SelectedIndexChanged += new EventHandler(cmbP_Language_SelectedIndexChanged);
        rdbTitle1.CheckedChanged += new EventHandler(rdbTitle1_CheckedChanged);
        rdbTitle2.CheckedChanged += new EventHandler(rdbTitle2_CheckedChanged);
        rdbTitle3.CheckedChanged += new EventHandler(rdbTitle3_CheckedChanged);
        rdbTitle4.CheckedChanged += new EventHandler(rdbTitle4_CheckedChanged);
        cmbTitle.SelectedIndexChanged += new EventHandler(cmbTitle_SelectedIndexChanged);
        cmbP_Province.SelectedIndexChanged += new EventHandler(cmbP_Province_SelectedIndexChanged);
        cmbP_Aumper.SelectedIndexChanged += new EventHandler(cmbP_Aumper_SelectedIndexChanged);
        //CORPORATE CLIENT
        cmbC_Language.SelectedIndexChanged += new EventHandler(cmbC_Language_SelectedIndexChanged);
        cmbC_Province.SelectedIndexChanged += new EventHandler(cmbC_Province_SelectedIndexChanged);
        cmbC_Aumper.SelectedIndexChanged += new EventHandler(cmbC_Aumper_SelectedIndexChanged);
        //OTHER
        btnUpdatePersonalClient.ServerClick +=new EventHandler(btnUpdatePersonalClient_ServerClick);
        btnUpdateCorporateClient.ServerClick +=new EventHandler(btnUpdateCorporateClient_ServerClick);
        btnClose.ServerClick += new EventHandler(btnClose_ServerClick);
        btnClose1.ServerClick += new EventHandler(btnClose1_ServerClick);

        if (!Page.IsPostBack)
        {
            //
            CultureInfo culture = new CultureInfo("en-US");

            // PROVINCE
            this.BindResultToProvince();

            // COMBO SEX
            this.BindResultToSex(rdbTitle1.Text);

            // this.BindResultToSex("นาย");
            // COMBO NATIONALITY
            this.BindResultToNationalityThai();

            // COMBO MARRIED
            this.BindResultToMarried(); 

            // CLIENT
            string clientcode = Request.QueryString["ClientCode"].ToString().Trim();
            string clienttype = "";
            string clienttitle = "";
            string clientname = "";
            string clientsurname = "";
            DataTable  dtClient = Client.GetClientType(clientcode);
            if (dtClient.Rows.Count > 0)
            {
                clienttype = dtClient.Rows[0]["CLTTYPE"].ToString().Trim();
                clienttitle = dtClient.Rows[0]["SALUTL"].ToString().Trim();
                clientname = dtClient.Rows[0]["LGIVNAME"].ToString().Trim();
                clientsurname = dtClient.Rows[0]["LSURNAME"].ToString().Trim();
                switch (clienttype)
                {
                    case "P":
                        this.lbP_ReturnClientNo.Text = clientcode;
                        this.txbP_Name.Text = clientname;
                        this.txbP_Name.ReadOnly = true;
                        this.txbP_Surname.Text = clientsurname;
                        this.txbP_Surname.ReadOnly = true;
                        mvClient.ActiveViewIndex = 0;
                        this.BindResultToProvince();
                        break;
                    case "C":
                        this.lbC_ReturnClientNo.Text = clientcode;
                        this.txbC_Corporation1.Text = clientsurname;
                        this.txbC_Corporation1.ReadOnly = true;
                        this.txbC_Corporation2.Text = clientname;
                        this.txbC_Corporation2.ReadOnly = true;
                        mvClient.ActiveViewIndex = 1;
                        this.BindResultToProvince();
                        break;
                    default: break;
                }
            }
            else
            {

            }
            
            
            
        }
    }

    void btnClose1_ServerClick(object sender, EventArgs e)
    {
        Response.Redirect("../ClosePage.aspx");
    }

    void btnClose_ServerClick(object sender, EventArgs e)
    {
        Response.Redirect("../ClosePage.aspx");
    }

    protected void cmbP_Language_SelectedIndexChanged(object sender, EventArgs e)
    {
        string lang = cmbP_Language.SelectedValue;
        if (lang == "E")
        {
            rdbTitle1.Text = "MR";
            rdbTitle2.Text = "MRS";
            rdbTitle3.Text = "MISS";
            rdbTitle4.Text = "Other";

            BindResultToNationalityEng();
            //UPDATE 2009-07-21
            BindResultToProvinceEng();
        }
        else
        {
            rdbTitle1.Text = "นาย";
            rdbTitle2.Text = "นาง";
            rdbTitle3.Text = "นางสาว";
            rdbTitle4.Text = "อื่น ๆ";

            this.BindResultToNationalityThai();
            //UPDATE 2009-07-21
            BindResultToProvinceThai();
        }
        // COMBO PROVINCE
        // UPDATE HIDE 2009-07-21
        //this.BindResultToProvince();
        // COMBO SEX
        if (rdbTitle1.Checked)
        {
            this.BindResultToSex(rdbTitle1.Text.Trim());
        }
        if (rdbTitle2.Checked)
        {
            this.BindResultToSex(rdbTitle2.Text.Trim());
        }
        if (rdbTitle3.Checked)
        {
            this.BindResultToSex(rdbTitle3.Text.Trim());
        }
        // COMBO MARRIED
        this.BindResultToMarried();
        // COMBO TITLE
        if (rdbTitle4.Checked)
        {
            this.BindResultToTitle();
            this.cmbTitle.Enabled = true;
            this.cmbTitle.Visible = true;
            this.BindResultToSex(rdbTitle4.Text.Trim());
        }
        else
        {
            this.cmbTitle.Enabled = false;
            this.cmbTitle.Visible = false;
        }

        //UPDATE 2009-07-01
        cmbP_Province.Enabled = true;
        cmbP_Aumper.Enabled = false;
        cmbP_Tumbol.Enabled = false;


        //SET FOCUS CURSOR
        rdbTitle1.Focus();
    }
    protected void cmbC_Language_SelectedIndexChanged(object sender, EventArgs e)
    {
        // COMBO PROVINCE
        if (cmbC_Language.SelectedValue.Equals("E"))
        {
            cmbC_Solution.Enabled = false;
            //UPDATE 2009-07-21
            BindResultToProvinceEng();
        }
        else
        {
            cmbC_Solution.Enabled = true;
            //UPDATE 2009-07-21
            BindResultToProvinceThai();
        }
        //UPDATE HIDE 2009-07-21
        //this.BindResultToProvince();

        //UPDATE 2009-07-01
        cmbC_Province.Enabled = true;
        cmbC_Aumper.Enabled = false;
        cmbC_Tumbol.Enabled = false;
    }
    protected void cmbTitle_SelectedIndexChanged(object sender, EventArgs e)
    {
        // COMBO SEX
        this.BindResultToSex(cmbTitle.SelectedValue);
    }
    protected void cmbP_Province_SelectedIndexChanged(object sender, EventArgs e)
    {
        //UPDATE 2009-07-21
        string lang = cmbP_Language.SelectedValue;
        if (lang == "E")
        {
            dt = Client.GetAmphurByProvinceEng(cmbP_Province.SelectedValue);
            DataRow dr = dt.NewRow();
            dr["Amphur_EN"] = "โปรดเลือก";
            dr["AmphurID"] = "0";
            dt.Rows.InsertAt(dr, 0);

            cmbP_Aumper.Enabled = true;
            cmbP_Aumper.DataSource = dt;
            cmbP_Aumper.DataTextField = "Amphur_EN";
            cmbP_Aumper.DataValueField = "AmphurID";
            cmbP_Aumper.DataBind();
        }
        else
        {
            dt = Client.GetAmphurByProvinceThai(cmbP_Province.SelectedValue);
            DataRow dr = dt.NewRow();
            dr["Amphur"] = "โปรดเลือก";
            dr["AmphurID"] = "0";
            dt.Rows.InsertAt(dr, 0);

            cmbP_Aumper.Enabled = true;
            cmbP_Aumper.DataSource = dt;
            cmbP_Aumper.DataTextField = "Amphur";
            cmbP_Aumper.DataValueField = "AmphurID";
            cmbP_Aumper.DataBind();
        }
        //SET FOCUS CURSOR
        //txbP_Postcode.Focus();
    }
    protected void cmbC_Province_SelectedIndexChanged(object sender, EventArgs e)
    {
        //UPDATE 2009-07-21
        string lang = cmbC_Language.SelectedValue;
        if (lang == "E")
        {
            dt = Client.GetAmphurByProvinceEng(cmbC_Province.SelectedValue);
            DataRow dr = dt.NewRow();
            dr["Amphur_EN"] = "โปรดเลือก";
            dr["AmphurID"] = "0";
            dt.Rows.InsertAt(dr, 0);

            cmbC_Aumper.Enabled = true;
            cmbC_Aumper.DataSource = dt;
            cmbC_Aumper.DataTextField = "Amphur_EN";
            cmbC_Aumper.DataValueField = "AmphurID";
            cmbC_Aumper.DataBind();
        }
        else
        {
            dt = Client.GetAmphurByProvinceThai(cmbC_Province.SelectedValue);
            DataRow dr = dt.NewRow();
            dr["Amphur"] = "โปรดเลือก";
            dr["AmphurID"] = "0";
            dt.Rows.InsertAt(dr, 0);

            cmbC_Aumper.Enabled = true;
            cmbC_Aumper.DataSource = dt;
            cmbC_Aumper.DataTextField = "Amphur";
            cmbC_Aumper.DataValueField = "AmphurID";
            cmbC_Aumper.DataBind();
        }
        //SET FOCUS CURSOR
        //txbC_PostCode.Focus();
    }
    protected void cmbP_Aumper_SelectedIndexChanged(object sender, EventArgs e)
    {
        //UPDATE 2009-07-21
        string lang = cmbP_Language.SelectedValue;
        if (lang == "E")
        {
            dt = Client.GetTumbolByProvinceAndAmphurEng(cmbP_Province.SelectedValue, cmbP_Aumper.SelectedValue);
            DataRow dr = dt.NewRow();
            dr["Tumbol_EN"] = "โปรดเลือก";
            dr["TumbolID"] = "0";
            dt.Rows.InsertAt(dr, 0);

            cmbP_Tumbol.Enabled = true;
            cmbP_Tumbol.DataSource = dt;
            cmbP_Tumbol.DataTextField = "Tumbol_EN";
            cmbP_Tumbol.DataValueField = "TumbolID";
            cmbP_Tumbol.DataBind();
        }
        else
        {
            dt = Client.GetTumbolByProvinceAndAmphurThai(cmbP_Province.SelectedValue, cmbP_Aumper.SelectedValue);
            DataRow dr = dt.NewRow();
            dr["Tumbol"] = "โปรดเลือก";
            dr["TumbolID"] = "0";
            dt.Rows.InsertAt(dr, 0);

            cmbP_Tumbol.Enabled = true;
            cmbP_Tumbol.DataSource = dt;
            cmbP_Tumbol.DataTextField = "Tumbol";
            cmbP_Tumbol.DataValueField = "TumbolID";
            cmbP_Tumbol.DataBind();
        }
        //SET FOCUS CURSOR
        //txbP_Postcode.Focus();


    }
    protected void cmbC_Aumper_SelectedIndexChanged(object sender, EventArgs e)
    {
        //UPDATE 2009-07-21
        string lang = cmbC_Language.SelectedValue;
        if (lang == "E")
        {
            dt = Client.GetTumbolByProvinceAndAmphurEng(cmbC_Province.SelectedValue, cmbC_Aumper.SelectedValue);
            DataRow dr = dt.NewRow();
            dr["Tumbol_EN"] = "โปรดเลือก";
            dr["TumbolID"] = "0";
            dt.Rows.InsertAt(dr, 0);

            cmbC_Tumbol.Enabled = true;
            cmbC_Tumbol.DataSource = dt;
            cmbC_Tumbol.DataTextField = "Tumbol_EN";
            cmbC_Tumbol.DataValueField = "TumbolID";
            cmbC_Tumbol.DataBind();
        }
        else
        {
            dt = Client.GetTumbolByProvinceAndAmphurThai(cmbC_Province.SelectedValue, cmbC_Aumper.SelectedValue);
            DataRow dr = dt.NewRow();
            dr["Tumbol"] = "โปรดเลือก";
            dr["TumbolID"] = "0";
            dt.Rows.InsertAt(dr, 0);

            cmbC_Tumbol.Enabled = true;
            cmbC_Tumbol.DataSource = dt;
            cmbC_Tumbol.DataTextField = "Tumbol";
            cmbC_Tumbol.DataValueField = "TumbolID";
            cmbC_Tumbol.DataBind();
        }
        //SET FOCUS CURSOR
        //txbC_PostCode.Focus();
    }
    
    

    protected void rdbTitle4_CheckedChanged(object sender, EventArgs e)
    {
        this.BindResultToTitle();
    }
    protected void rdbTitle1_CheckedChanged(object sender, EventArgs e)
    {
        cmbTitle.Enabled = false;
        cmbTitle.Visible = false;
        // COMBO SEX
        this.BindResultToSex(rdbTitle1.Text.Trim());
    }
    protected void rdbTitle2_CheckedChanged(object sender, EventArgs e)
    {
        cmbTitle.Enabled = false;
        cmbTitle.Visible = false;
        // COMBO SEX
        this.BindResultToSex(rdbTitle2.Text.Trim());
    }
    protected void rdbTitle3_CheckedChanged(object sender, EventArgs e)
    {
        cmbTitle.Enabled = false;
        cmbTitle.Visible = false;
        // COMBO SEX
        this.BindResultToSex(rdbTitle3.Text.Trim());
    }



    protected void btnUpdatePersonalClient_ServerClick(object sender, EventArgs e)
    {
        try
        {
            #region "GET USER HOST"
            UserHostDetails user;
            user = UserMember.GetUserHost(Utilities.GetUsername().Trim());
            string Username = user.UserHostName.ToString();
            string Password = user.UserHostPassword.ToString();
            #endregion

            WFQuickLink.QuickLinkService service = new QuickLinkService();
            Box_PersonalClient PersonalClient = new Box_PersonalClient();
            string personalclientcode = "";
            string message = "";
            string clientno = lbP_ReturnClientNo.Text.Trim() ;
            personalclientcode = clientno;
            string UserWeb = Utilities.GetUsername().Trim();
            string tempMsgError = "";
            bool isBoolCheckValid = false;
            //VALIDATE CLIENT
            ClientDetails cd = new ClientDetails();

            if (rdbTitle1.Checked)
            {
                cd.Salutation = rdbTitle1.Text.Trim();
            }
            if (rdbTitle2.Checked)
            {
                cd.Salutation = rdbTitle2.Text.Trim();
            }
            if (rdbTitle3.Checked)
            {
                cd.Salutation = rdbTitle3.Text.Trim();
                if (cd.Salutation.Equals("นางสาว"))
                {
                    cd.Salutation = "น.ส.";
                }
            }
            if (rdbTitle4.Checked)
            {
                if (cmbTitle.SelectedItem.Text.Equals("โปรดเลือก"))
                {
                    //Validate
                    tempMsgError += " กรุณาเลือก คำนำหน้า! ";
                    isBoolCheckValid = true;
                }
                else
                {
                    cd.Salutation = cmbTitle.SelectedValue;
                    //cd.SalutationOther = cmbTitle.SelectedValue;  //
                }
            }
            if (txbP_Name.Text.Trim().Equals(""))
            {
                tempMsgError += " กรุณาระบุ ชื่อ ! ";
                isBoolCheckValid = true;
            }
            if (txbP_Surname.Text.Trim().Equals(""))
            {
                tempMsgError += " กรุณาระบุ นามสกุล ! ";
                isBoolCheckValid = true;
            }

            //UPDATE 2009-08-03  CHECK VALIDATION FORMAT ID & PASSPORT
            if (txbP_ID.Text.Trim().Equals(""))
            {
                tempMsgError += " กรุณาระบุ หมายเลขบัตรประชาชน ! ";
                isBoolCheckValid = true;

            }
            else
            {
                #region "VALIDATION ID"
                if (this.cmbP_Nationality.SelectedValue == "THA" || this.cmbP_Nationality.SelectedValue == "TH")
                {
                    if (this.txbP_ID.Text.Trim().Length < 13)
                    {
                        tempMsgError += " หมายเลขบัตรประชาชน ต้องมีความยาวเท่ากับ 13 หลัก กรุณาระบุให้ถูกต้อง! ";
                        isBoolCheckValid = true;
                    }
                    else
                    {
                        if (this.txbP_ID.Text.Trim() == "9999999999999")
                        {
                            isBoolCheckValid = false;
                        }
                        else
                        {
                            if (!Utilities.isID(this.txbP_ID.Text.Trim()))
                            {
                                tempMsgError += " รูปแบบ หมายเลขบัตรประชาชน ไม่ถูกต้อง กรุณาระบุให้ถูกต้อง! ";
                                isBoolCheckValid = true;
                            }
                        }
                    }
                    //if (isBoolCheckValid)
                    //{
                    //    lbMessageHead.Text = tempMsgError;
                    //    lbMessageHead.ForeColor = System.Drawing.Color.Red;
                    //    lbMessageHead.Font.Bold = true;
                    //    return;
                    //}
                }
                #endregion

            }
            if (txbP_DataOfBirth.CalendarDateString.Trim().Equals(""))
            {
                tempMsgError += " กรุณาระบุ วันเดือนปีเกิด  ! ";
                isBoolCheckValid = true;
            }
            //update May 06,2010
            DateTime datBOD = txbP_DataOfBirth.CalendarDate;
            DateTime datNow = DateTime.Now;
            TimeSpan datOld = datNow.Subtract(datBOD);
            int intOld = datOld.Days / 365;
            //lbeDOB.Text = intOld.ToString();
            if (intOld > 90 || intOld < 18)
            {
                tempMsgError += " กรุณาระบุ วันเดือนปีเกิด  อยู่ระหว่างอายุ 18-90 ปี! ";
                isBoolCheckValid = true;
            }
            //--
            if (cmbP_Sex.SelectedItem.Text.Equals("โปรดเลือก"))
            {
                tempMsgError += " กรุณาเลือก เพศ ! ";
                isBoolCheckValid = true;
            }
            if (cmbP_Married.SelectedItem.Text.Equals("โปรดเลือก"))
            {
                tempMsgError += " กรุณาเลือก สถานภาพ ! ";
                isBoolCheckValid = true;
            }
            if (cmbP_Nationality.SelectedItem.Text.Equals("โปรดเลือก"))
            {
                tempMsgError += " กรุณาเลือก สัญชาติ ! ";
                isBoolCheckValid = true;
            }
            if (txbP_HomeNo.Text.Trim().Equals(""))
            {
                tempMsgError += " กรุณาระบุ เลขที่ ! ";
                isBoolCheckValid = true;
            }
            if (cmbP_Tumbol.SelectedItem.Text.Equals("โปรดเลือก"))
            {
                tempMsgError += " กรุณาเลือก ตำบล/แขวง! ";
                isBoolCheckValid = true;
            }
            if (cmbP_Aumper.SelectedItem.Text.Equals("โปรดเลือก"))
            {
                tempMsgError += " กรุณาเลือก อำเภอ/เขต ! ";
                isBoolCheckValid = true;
            }
            if (cmbP_Province.SelectedItem.Text.Equals("โปรดเลือก"))
            {
                tempMsgError += " กรุณาเลือก จังหวัด ! ";
                isBoolCheckValid = true;
            }
            if (txbP_Postcode.Text.Trim().Equals(""))
            {
                tempMsgError += " กรุณาระบุ รหัสไปรษณีย์ ! ";
                isBoolCheckValid = true;
            }
            if (txbP_Tel.Text.Trim().Equals(""))
            {
                tempMsgError += " กรุณาระบุ โทรศัพท์ ! ";
                isBoolCheckValid = true;
            }
            if (isBoolCheckValid)
            {
                lbMessagePosonalClient.Text = tempMsgError;
                lbMessagePosonalClient.ForeColor = System.Drawing.Color.Red;
                lbMessagePosonalClient.Font.Bold = true;
                return;
            }
            //CREATE  PERSONAL CLIENT TO UPDATE
            cd.ClientNo = clientno;
            cd.ClientType = "P";
            if (rdbTitle1.Checked)
            {
                cd.Salutation = rdbTitle1.Text.Trim();
            }
            if (rdbTitle2.Checked)
            {
                cd.Salutation = rdbTitle2.Text.Trim();
            }
            if (rdbTitle3.Checked)
            {
                cd.Salutation = rdbTitle3.Text.Trim();
                if (cd.Salutation.Equals("นางสาว"))
                {
                    cd.Salutation = "น.ส.";
                }
            }
            if (rdbTitle4.Checked)
            {
                cd.Salutation = cmbTitle.SelectedValue;
            }
            cd.Name = txbP_Name.Text.Trim();
            cd.Surname = txbP_Surname.Text.Trim();
            if (cmbP_Language.SelectedValue.Equals("T"))
            {
                cd.Address1 = txbP_HomeNo.Text + " " + txbP_Building.Text.Trim();
                if (txbP_Soi.Text.Trim().Equals("") && txbP_Street.Text.Trim().Equals(""))
                {
                    cd.Address2 = "";
                }
                else if (txbP_Soi.Text.Trim().Equals(""))
                {
                    cd.Address2 = "ถ." + txbP_Street.Text.Trim();
                }
                else if (txbP_Street.Text.Trim().Equals(""))
                {
                    if (txbP_Soi.Text.Trim().Substring(0, 1) == "*")
                    {
                        cd.Address2 = txbP_Soi.Text.Trim().Replace("*", "");
                    }
                    else
                    {
                        cd.Address2 = "ซ." + txbP_Soi.Text.Trim();
                    }
                }
                else
                {
                    if (txbP_Soi.Text.Trim().Substring(0, 1) == "*")
                    {
                        cd.Address2 = txbP_Soi.Text.Trim().Replace("*", "") + " ถ." + txbP_Street.Text.Trim();
                    }
                    else
                    {
                        cd.Address2 = "ซ." + txbP_Soi.Text.Trim() + " ถ." + txbP_Street.Text.Trim();
                    }
                }
                cd.Address3 = "ต." + cmbP_Tumbol.SelectedItem.Text;  //"";
                cd.Address4 = "อ." + cmbP_Aumper.SelectedItem.Text;  //"";
                cd.Address5 = "จ." + cmbP_Province.SelectedItem.Text;//"";

                //UPDATE 2009-08-26
                if (cmbP_Province.SelectedItem.Text.Trim().Equals("กรุงเทพมหานคร"))
                {
                    cd.Address3 = cmbP_Tumbol.SelectedItem.Text;  //"";
                    cd.Address4 = cmbP_Aumper.SelectedItem.Text;  //"";
                    cd.Address5 = cmbP_Province.SelectedItem.Text;//"";
                }

                //Add 2010-07-13 for address of client is long.
                if (cd.Address1.Length > 30)
                {
                    int intLength = cd.Address1.Length - 30;
                    string strAddress1 = cd.Address1.ToString();
                    string strAddress2 = cd.Address2.ToString();
                    string strAddress3 = cd.Address3.ToString();
                    string strAddress4 = cd.Address4.ToString();
                    cd.Address1 = cd.Address1.Substring(0, 30);
                    cd.Address2 = strAddress1.Substring(30, intLength).ToString() + " " + strAddress2;
                    cd.Address2 = cd.Address2.Trim();

                    if (cd.Address2.Length > 30)
                    {
                        intLength = cd.Address2.Length - 30;
                        strAddress2 = cd.Address2.ToString();
                        strAddress3 = cd.Address3.ToString();
                        cd.Address2 = strAddress2.Substring(0, 30);
                        cd.Address3 = strAddress2.Substring(30, intLength).ToString() + " " + strAddress3;
                        cd.Address3 = cd.Address3.Trim();

                        if (cd.Address3.Length > 30)
                        {
                            intLength = cd.Address3.Length - 30;
                            strAddress3 = cd.Address3.ToString();
                            strAddress4 = cd.Address4.ToString();
                            cd.Address3 = strAddress3.Substring(0, 30);
                            cd.Address4 = strAddress3.Substring(30, intLength).ToString() + " " + strAddress4;
                            cd.Address4 = cd.Address4.Trim();
                        }
                    }
                }
            }
            else
            {
                cd.Address1 = txbP_HomeNo.Text + " " + txbP_Building.Text.Trim();
                if (txbP_Soi.Text.Trim().Equals("") && txbP_Street.Text.Trim().Equals(""))
                {
                    cd.Address2 = "";
                }
                else if (txbP_Soi.Text.Trim().Equals(""))
                {
                    cd.Address2 = txbP_Street.Text.Trim();
                }
                else if (txbP_Street.Text.Trim().Equals(""))
                {
                    cd.Address2 = txbP_Soi.Text.Trim();
                }
                else
                {
                    cd.Address2 = txbP_Soi.Text.Trim() + " " + txbP_Street.Text.Trim();
                }

                cd.Address3 = cmbP_Tumbol.SelectedItem.Text;  //"";
                cd.Address4 = cmbP_Aumper.SelectedItem.Text;  //"";
                cd.Address5 = cmbP_Province.SelectedItem.Text;//"";
            }

            cd.PostCode = txbP_Postcode.Text.Trim();
            cd.Country = "THA";
            cd.SEX = cmbP_Sex.SelectedValue;
            cd.Married = cmbP_Married.SelectedValue;
            cd.Status = "AC";
            cd.BusRes = "R";
            cd.ID = txbP_ID.Text.Trim();
            cd.Phone = txbP_Tel.Text.Trim();
            cd.PhoneOffice = txbP_TelOffice.Text.Trim();
            cd.PhoneMoblie = txbP_TelMobile.Text.Trim();
            cd.Emails = txbP_Email.Text.Trim();
            cd.Nationality = cmbP_Nationality.SelectedValue;
            cd.DOB = txbP_DataOfBirth.CalendarDateString.Trim();
            cd.FAXNO = "";
            cd.FAXNO01 = "";
            cd.TaxID = "";
            cd.Language = cmbP_Language.SelectedValue;
            cd.Datetime = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            //cd.Datetime = DateTime.Now.ToString();
            cd.LicenseDriver = txbP_DriverLicense.Text.Trim();
            //Update 2009-09-15
            cd.GroupBrokerId = Utilities.GetGroupBrokerID();

            //FULLNAME
            string fullname = "";
            fullname = cd.Salutation + " " + cd.Name + " " + cd.Surname;

            //SET VALUE CLIENT TO BUSINESS ENTITY
            PersonalClient.Inception = "";                                      //วันที่สร้าง
            PersonalClient.Salutation = cd.Salutation;                          //คำนำหน้า
            PersonalClient.Name = cd.Name;                                      //ชื่อ
            PersonalClient.Surname = cd.Surname;                                //นามสกุล
            PersonalClient.Street = cd.Address1;                                //"ถ." + txbP_Street.Text;                    //ถนน
            PersonalClient.AddressLine1 = cd.Address2;                          //txbP_HomeNo.Text.Trim() + " " + txbP_Building.Text.Trim();
            PersonalClient.AddressLine2 = cd.Address3;                          //"ซ." + txbP_Soi.Text.Trim() + "ต." + cmbP_Tumbol.SelectedItem.Text;
            PersonalClient.AddressLine3 = cd.Address4;                          //"อ." + cmbP_Aumper.SelectedItem.Text;
            PersonalClient.AddressLine41Postcode = txbP_Postcode.Text.Trim();   //
            PersonalClient.AddressLine42Province = cd.Address5;                 //"จ." + cmbP_Province.SelectedItem.Text;
            PersonalClient.Gender = cd.SEX;                                     //cmbP_Sex.SelectedValue;       //เพศ               
            PersonalClient.Married = cd.Married;                                //cmbP_Married.SelectedValue;   //สถานภาพ
            PersonalClient.Country = cd.Country;
            PersonalClient.BusRes = cd.BusRes;
            PersonalClient.ID = cd.ID;                                          //txbP_ID.Text.Trim();          //หมายเลขบัตรประชาชน
            PersonalClient.TelPhone = cd.Phone;
            PersonalClient.TelMobile = cd.PhoneMoblie;
            PersonalClient.TelOffice = cd.PhoneOffice;
            PersonalClient.Emails = cd.Emails;
            PersonalClient.NameFormat = "";
            PersonalClient.Nationality = cd.Nationality;
            PersonalClient.CompanyDoctor = "";
            PersonalClient.Language = cd.Language;                              //cmbP_Language.SelectedValue;   //ภาษา
            PersonalClient.BirthDate = cd.DOB;                                  //txbP_DataOfBirth.Text.Trim();  //วันเดือนปีเกิด
            PersonalClient.DriverLicense = "";

            //PROCESS WEB SERVICES
            clientno = service.EditIndividualClient(Username, Password, PersonalClient, personalclientcode, out message);
            if (message.Equals("SUCCESS"))
            {
                //SHOW DATA
                //UPDATE DATA TO DB
                Client.UpdateClient(cd);
                //-----------------
                //UPDATE CLIENT LOG--
                Client.UpdateClientLog(clientno, UserWeb);
                //-------------------
                //SUCCESS
                this.lbMessagePosonalClient.Text = "ปรับปรุงข้อมูลเรียบร้อย(" + clientno + ")";
                this.lbMessagePosonalClient.ForeColor = System.Drawing.ColorTranslator.FromHtml("#00C000");
                this.lbMessagePosonalClient.Font.Size = FontUnit.XXLarge;
                this.lbMessagePosonalClient.Font.Bold = true;
                //SAVE TO DATABASE
            }
            else  //NOT SUCCESS
            {
                this.lbMessagePosonalClient.Text = "ไม่สามารถปรับปรุงข้อมูลลูกค้าท่านนี้ได้.";
                this.lbMessagePosonalClient.ForeColor = System.Drawing.Color.Red;
                this.lbMessagePosonalClient.Font.Bold = true;
            }
        }
        catch (Exception ex)
        {
            this.lbMessagePosonalClient.Text = "ไม่สามารถปรับปรุงข้อมูลลูกค้าท่านนี้ได้ เนื่องจาก : <br> " + ex.Message.ToString();
            this.lbMessagePosonalClient.ForeColor = System.Drawing.Color.Red;
            this.lbMessagePosonalClient.Font.Bold = true;
        }
    }
    protected void btnUpdateCorporateClient_ServerClick(object sender, EventArgs e)
    {
        #region "GET USER HOST"
        UserHostDetails user;
        user = UserMember.GetUserHost(Utilities.GetUsername().Trim());
        string Username = user.UserHostName.ToString();
        string Password = user.UserHostPassword.ToString();
        #endregion
        WFQuickLink.QuickLinkService service = new QuickLinkService();
        Box_CorporateClient CorporateClient = new Box_CorporateClient();
        string corporateclientcode = "";
        string message = "";
        string messagestatus = "";
        string clientno = lbC_ReturnClientNo.Text.Trim();
        corporateclientcode = clientno;
        string UserWeb = Utilities.GetUsername().Trim();

        string tempCompanyNameLine1 = "";
        string fullname = "";
        //CREATE CORPORATE 
        ClientDetails cd = new ClientDetails();
        cd.ClientNo = clientno;
        cd.ClientType = "C";
        cd.Salutation = "";
        cd.Name = "";
        if (cmbC_Language.SelectedValue.Equals("T"))
        {
            if (cmbC_Solution.SelectedValue == "")
            {
                cd.Surname = txbC_Corporation1.Text.Trim() + " " + txbC_Corporation2.Text.Trim();
                tempCompanyNameLine1 = txbC_Corporation1.Text.Trim();
            }
            else
            {
                cd.Surname = cmbC_Solution.SelectedValue + " " + txbC_Corporation1.Text.Trim() + " " + txbC_Corporation2.Text.Trim();
                tempCompanyNameLine1 = cmbC_Solution.SelectedValue + " " + txbC_Corporation1.Text.Trim();
            }
            cd.Address1 = txbC_HomeNo.Text.Trim() + " " + txbC_Building.Text.Trim();    //"";
            if (txbC_Soi.Text.Trim().Equals("") && txbC_Street.Text.Trim().Equals(""))
            {
                cd.Address2 = "";
            }
            else if (txbC_Soi.Text.Trim().Equals(""))
            {
                cd.Address2 = "ถ." + txbC_Street.Text.Trim();
            }
            else if (txbC_Street.Text.Trim().Equals(""))
            {
                cd.Address2 = "ซ." + txbC_Soi.Text.Trim();
            }
            else
            {
                cd.Address2 = "ซ." + txbC_Soi.Text.Trim() + " ถ." + txbC_Street.Text.Trim();
            }
            cd.Address3 = "ต." + cmbC_Tumbol.SelectedItem.Text;  //"";
            cd.Address4 = "อ." + cmbC_Aumper.SelectedItem.Text;  //"";
            cd.Address5 = "จ." + cmbC_Province.SelectedItem.Text;//"";

            //UPDATE 2009-08-26
            if (cmbC_Province.SelectedItem.Text.Trim().Equals("กรุงเทพมหานคร"))
            {
                cd.Address3 = cmbC_Tumbol.SelectedItem.Text;  //"";
                cd.Address4 = cmbC_Aumper.SelectedItem.Text;  //"";
                cd.Address5 = cmbC_Province.SelectedItem.Text;//"";
            }
            //Add 2010-07-13 for address of client is long.
            if (cd.Address1.Length > 30)
            {
                int intLength = cd.Address1.Length - 30;
                string strAddress1 = cd.Address1.ToString();
                string strAddress2 = cd.Address2.ToString();
                string strAddress3 = cd.Address3.ToString();
                string strAddress4 = cd.Address4.ToString();
                cd.Address1 = cd.Address1.Substring(0, 30);
                cd.Address2 = strAddress1.Substring(30, intLength).ToString() + " " + strAddress2;
                cd.Address2 = cd.Address2.Trim();

                if (cd.Address2.Length > 30)
                {
                    intLength = cd.Address2.Length - 30;
                    strAddress2 = cd.Address2.ToString();
                    strAddress3 = cd.Address3.ToString();
                    cd.Address2 = strAddress2.Substring(0, 30);
                    cd.Address3 = strAddress2.Substring(30, intLength).ToString() + " " + strAddress3;
                    cd.Address3 = cd.Address3.Trim();

                    if (cd.Address3.Length > 30)
                    {
                        intLength = cd.Address3.Length - 30;
                        strAddress3 = cd.Address3.ToString();
                        strAddress4 = cd.Address4.ToString();
                        cd.Address3 = strAddress3.Substring(0, 30);
                        cd.Address4 = strAddress3.Substring(30, intLength).ToString() + " " + strAddress4;
                        cd.Address4 = cd.Address4.Trim();
                    }
                }
            }
            //FULLNAME
            fullname = cd.Surname;
        }
        else
        {
            cd.Surname = txbC_Corporation1.Text.Trim() + " " + txbC_Corporation2.Text.Trim();
            tempCompanyNameLine1 = txbC_Corporation1.Text.Trim();

            cd.Address1 = txbC_HomeNo.Text.Trim() + " " + txbC_Building.Text.Trim();    //"";
            if (txbC_Soi.Text.Trim().Equals("") && txbC_Street.Text.Trim().Equals(""))
            {
                cd.Address2 = " ";
            }
            else if (txbC_Soi.Text.Trim().Equals(""))
            {
                cd.Address2 = txbC_Street.Text.Trim();
            }
            else if (txbC_Street.Text.Trim().Equals(""))
            {
                cd.Address2 = txbC_Soi.Text.Trim();
            }
            else
            {
                cd.Address2 = txbC_Soi.Text.Trim() + " " + txbC_Street.Text.Trim();
            }

            cd.Address3 = cmbC_Tumbol.SelectedItem.Text;    //"";
            cd.Address4 = cmbC_Aumper.SelectedItem.Text;    //"";
            cd.Address5 = cmbC_Province.SelectedItem.Text;  //"";

            //FULLNAME
            fullname = cd.Surname;
        }

        cd.PostCode = txbC_PostCode.Text.Trim();
        cd.Country = "THA";
        cd.SEX = "";
        cd.Married = "";
        cd.Status = "";
        cd.BusRes = "R";
        cd.ID = "";
        cd.Phone = txbC_Tel.Text.Trim();
        cd.PhoneOffice = "";
        cd.PhoneMoblie = "";
        cd.Emails = txbC_InternetAddress.Text.Trim();
        cd.Nationality = "";
        cd.DOB = "";
        cd.FAXNO = txbC_Fax.Text.Trim();
        cd.FAXNO01 = "";
        cd.TaxID = txbC_TaxID.Text.Trim();
        cd.Language = cmbC_Language.SelectedValue;
        cd.Datetime = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
        cd.LicenseDriver = "";
        cd.GroupBrokerId = Utilities.GetGroupBrokerID();


        CorporateClient.Inception = "";
        CorporateClient.CoporatePart1 = tempCompanyNameLine1;
        CorporateClient.CorportePart2 = txbC_Corporation2.Text.Trim();
        CorporateClient.Street = cd.Address1;//เลขที่+อาคาร
        CorporateClient.AddressLine1 = cd.Address2; //ซอย ถนน
        CorporateClient.AddressLine2 = cd.Address3; //ตำบล
        CorporateClient.AddressLine3 = cd.Address4; //อำเภอ
        CorporateClient.AddressLine41Postcode = txbC_PostCode.Text.Trim();
        CorporateClient.AddressLine42Province = cd.Address5;  //"จ." + cmbC_Province.SelectedItem.Text;
        CorporateClient.Country = "THA";
        CorporateClient.Telephone = txbC_Tel.Text.Trim();
        CorporateClient.Facsimile = txbC_Fax.Text.Trim();
        CorporateClient.EmailAddress = txbC_InternetAddress.Text.Trim();
        CorporateClient.TaxID = txbC_TaxID.Text.Trim();

        //PROCESS WEB SERVICES
        clientno = service.EditCorporateClient(Username, Password, CorporateClient, corporateclientcode, out message, out messagestatus);
        if (messagestatus.Equals("SUCCESS"))
        {
            //SHOW DATA
            //UPDATE DATA TO DB
            Client.UpdateClient(cd);
            //-----------------
            //UPDATE CLIENT LOG--
            Client.UpdateClientLog(clientno, UserWeb);
            //-------------------
            //SUCCESS
            this.lbMessageCorporateClient.Text = "ปรับปรุงข้อมูลเรียบร้อย(" + clientno + ")";
            this.lbMessageCorporateClient.ForeColor = System.Drawing.ColorTranslator.FromHtml("#00C000");
            this.lbMessageCorporateClient.Font.Size = FontUnit.XXLarge;
            this.lbMessageCorporateClient.Font.Bold = true;
            //SAVE TO DATABASE
        }
        else  //NOT SUCCESS
        {
            this.lbMessageCorporateClient.Text = "ไม่สามารถปรับปรุงข้อมูลลูกค้าท่านนี้ได้.";
            this.lbMessageCorporateClient.ForeColor = System.Drawing.Color.Red;
            this.lbMessageCorporateClient.Font.Bold = true;
        }
    }



    private void BindResultToSex(string titleValue)
    {
        dt = Client.GetSexByLanguageAndTitle(cmbP_Language.SelectedValue, titleValue);
        if (dt.Rows.Count <= 0)
        {
            dt = Client.GetSexByLanguage(cmbP_Language.SelectedValue);
        }
        if (dt.Rows.Count > 1)
        {
            DataRow dr = dt.NewRow();
            dr["CLTSEX_LONGDESC"] = "โปรดเลือก";
            dr["CLTSEX"] = "0";
            dt.Rows.InsertAt(dr, 0);
        }
        cmbP_Sex.DataSource = dt;
        cmbP_Sex.DataTextField = "CLTSEX_LONGDESC";
        cmbP_Sex.DataValueField = "CLTSEX";
        cmbP_Sex.DataBind();
        dt.Clear();
    }
    private void BindResultToNationalityEng()
    {
        dt = new DataTable();
        dt = Client.GetNationalityEngLanguage();
        if (dt.Rows.Count > 0)
        {
            DataRow dr = dt.NewRow();
            dr["ENG_LANG_NATIONALITY"] = "โปรดเลือก";
            dr["DESCITEM"] = "0";
            dt.Rows.InsertAt(dr, 0);

            //VEHICLE 
            cmbP_Nationality.DataSource = dt;
            cmbP_Nationality.DataTextField = "ENG_LANG_NATIONALITY";
            cmbP_Nationality.DataValueField = "DESCITEM";
            cmbP_Nationality.DataBind();

            dt.Clear();

        }
    }
    private void BindResultToNationalityThai()
    {
        dt = new DataTable();
        dt = Client.GetNationalityThaiLanguage();
        if (dt.Rows.Count > 0)
        {
            DataRow dr = dt.NewRow();
            dr["THAI_LANG_NATIONALITY"] = "ไทย";
            dr["DESCITEM"] = "THA";
            dt.Rows.InsertAt(dr, 0);

            //VEHICLE 
            cmbP_Nationality.DataSource = dt;
            cmbP_Nationality.DataTextField = "THAI_LANG_NATIONALITY";
            cmbP_Nationality.DataValueField = "DESCITEM";
            cmbP_Nationality.DataBind();

            dt.Clear();
        }
    }
    private void BindResultToProvince()
    {

        dt = Client.GetAllProvince();

        DataRow dr = dt.NewRow();
        dr["Description"] = "โปรดเลือก";
        dr["ProvinceID"] = "0";
        dt.Rows.InsertAt(dr, 0);

        cmbP_Province.DataSource = dt;
        cmbP_Province.DataTextField = "Description";
        cmbP_Province.DataValueField = "ProvinceID";
        cmbP_Province.DataBind();

        cmbC_Province.DataSource = dt;
        cmbC_Province.DataTextField = "Description";
        cmbC_Province.DataValueField = "ProvinceID";
        cmbC_Province.DataBind();

        dt.Clear();
    }
    private void BindResultToProvinceThai()
    {
        dt = Client.GetProvinceThaiLanguage();

        DataRow dr = dt.NewRow();
        dr["Description"] = "โปรดเลือก";
        dr["ProvinceID"] = "0";
        dt.Rows.InsertAt(dr, 0);

        cmbP_Province.DataSource = dt;
        cmbP_Province.DataTextField = "Description";
        cmbP_Province.DataValueField = "ProvinceID";
        cmbP_Province.DataBind();

        cmbC_Province.DataSource = dt;
        cmbC_Province.DataTextField = "Description";
        cmbC_Province.DataValueField = "ProvinceID";
        cmbC_Province.DataBind();

        dt.Clear();
    }
    private void BindResultToProvinceEng()
    {
        dt = Client.GetProvinceEngLanguage();

        DataRow dr = dt.NewRow();
        dr["Description_EN"] = "โปรดเลือก";
        dr["ProvinceID"] = "0";
        dt.Rows.InsertAt(dr, 0);

        cmbP_Province.DataSource = dt;
        cmbP_Province.DataTextField = "Description_EN";
        cmbP_Province.DataValueField = "ProvinceID";
        cmbP_Province.DataBind();

        cmbC_Province.DataSource = dt;
        cmbC_Province.DataTextField = "Description_EN";
        cmbC_Province.DataValueField = "ProvinceID";
        cmbC_Province.DataBind();

        dt.Clear();
    }
    private void BindResultToMarried()
    {
        dt = Client.GetMarriedByLanguage(cmbP_Language.SelectedValue);

        DataRow dr = dt.NewRow();
        dr["MARRYD_LONGDESC"] = "โปรดเลือก";
        dr["MARRYD"] = "0";
        dt.Rows.InsertAt(dr, 0);

        cmbP_Married.DataSource = dt;
        cmbP_Married.DataTextField = "MARRYD_LONGDESC";
        cmbP_Married.DataValueField = "MARRYD";
        cmbP_Married.DataBind();
        dt.Clear();
    }
    private void BindResultToTitle()
    {
        dt = Client.GetTitleByLanguage(cmbP_Language.SelectedValue);
        cmbTitle.Enabled = true;
        cmbTitle.Visible = true;

        DataRow dr = dt.NewRow();
        dr["LONGDESC"] = "โปรดเลือก";
        dr["DESCITEM"] = "0";
        dt.Rows.InsertAt(dr, 0);

        cmbTitle.DataSource = dt;
        cmbTitle.DataTextField = "LONGDESC";
        cmbTitle.DataValueField = "DESCITEM";
        cmbTitle.DataBind();
        dt.Clear();
    }


    //EditIndividualClient
    
}