﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using TA.BLL;
using TA.BusinessObjects;
using System.Data;

public partial class TA_Admin_TAManageCountry : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.gdvListCountry.PageIndexChanging+=new GridViewPageEventHandler(gdvListCountry_PageIndexChanging);


        this.gdvListCountry.RowEditing += new GridViewEditEventHandler(gdvListCountry_RowEditing);
        this.gdvListCountry.RowCancelingEdit += new GridViewCancelEditEventHandler(gdvListCountry_RowCancelingEdit);
        this.gdvListCountry.RowUpdating += new GridViewUpdateEventHandler(gdvListCountry_RowUpdating);
        if (!Page.IsPostBack)
        {
            getCountry();
        }
    }

    void gdvListCountry_RowEditing(object sender, GridViewEditEventArgs e)
    {

        gdvListCountry.EditIndex = e.NewEditIndex;
        BindDataToGridView();
    }
    void gdvListCountry_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gdvListCountry.EditIndex = -1;
        BindDataToGridView();
    }
    void gdvListCountry_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        
        CheckBox chkisEnable = (CheckBox)gdvListCountry.Rows[e.RowIndex].FindControl("chkEditisEnable");
        Label lblEditCountryCode = (Label)gdvListCountry.Rows[e.RowIndex].FindControl("lblEditCountryCode");

        TATBCountryBLL setCountry = new TATBCountryBLL();
        setCountry.SetTATBCountry(lblEditCountryCode.Text, Convert.ToInt16(chkisEnable.Checked));

        gdvListCountry.EditIndex = -1;

        getCountry();

        this.lblInformMessage.Text = "แก้ไขข้อมูลเรียบร้อยแล้ว";
        this.lblErrorMessage.Text = "";
    }
    private void getCountry()
    {
        TATBCountryBLL getCountry = new TATBCountryBLL();
        Session["GetTATBCountrys"] = getCountry.GetAllColumnTATBCountrys();
        BindDataToGridView();
        
    }
    protected void BindDataToGridView()
    {

        DataTable lst = (DataTable)Session["GetTATBCountrys"];
        gdvListCountry.DataSource = lst;
        gdvListCountry.DataBind();
        if (lst == null)
        {
            this.lblTotalRecord.Text = "แสดงรายการข้อมูล [จำนวนข้อมูลทั้งหมด " + 0 + " รายการ]";
        }
        else
        {
            this.lblTotalRecord.Text = "แสดงรายการข้อมูล [จำนวนข้อมูลทั้งหมด " + lst.Rows.Count + " รายการ]";
        }

    }
    protected void gdvListCountry_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdvListCountry.PageIndex = e.NewPageIndex;
        BindDataToGridView();

        this.lblInformMessage.Text = "";
        this.lblErrorMessage.Text = "";
    }

}