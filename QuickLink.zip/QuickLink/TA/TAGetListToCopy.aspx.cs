﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

//ADDITIONAL USING REFERENCE
using TA.BLL;
using TA.BusinessObjects;
using TA.DAL;
using System.Data;
using System.Data.Common;
using System.Globalization;
using System.IO;

public partial class TA_TAGetListToCopy : System.Web.UI.Page
{
    //PAGE LOAD
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            this.lblMassage.Text = ""; 
            DefaultPageRegisterClientScript();

            this.gdvListToCopyTaPolicy.RowCommand += new GridViewCommandEventHandler(gdvListToCopyTaPolicy_RowCommand);
            this.gdvListToCopyTaPolicy.RowDeleted += new GridViewDeletedEventHandler(gdvListToCopyTaPolicy_RowDeleted);
            this.gdvListToCopyTaPolicy.RowDeleting += new GridViewDeleteEventHandler(gdvListToCopyTaPolicy_RowDeleting);
            this.gdvListToCopyTaPolicy.PageIndexChanging += new GridViewPageEventHandler(gdvListToCopyTaPolicy_PageIndexChanging);
            this.gdvListToCopyTaPolicy.RowDataBound += new GridViewRowEventHandler(gdvListToCopyTaPolicy_RowDataBound);
            this.gdvListToCopyTaPolicy.RowCreated += new GridViewRowEventHandler(gdvListToCopyTaPolicy_RowCreated);
            this.gdvListToCopyTaPolicy.PageIndexChanging +=new GridViewPageEventHandler(gdvListToCopyTaPolicy_PageIndexChanging);

            this.btnSearch.ServerClick += new EventHandler(btnSearch_ServerClick);

            if (Page.IsPostBack)
            {
                this.GetListTAPolicy();
            }
            else
            { 
                //POST BACK
                
            }
            
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }

    protected void btnSearch_ServerClick(object sender, EventArgs e)
    {
        this.GetListTAPolicy();
    }

    protected void GetListTAPolicy()
    {
        if (this.txtTransDateFromSearch.Text.Length >= 1 && this.txtTransDateFromSearch.Text.Length <= 9)
        {
            this.lblMassage.Text = "Format วันที่ ของ Date From/To ไม่ถูกต้อง ที่ถูกต้องเป็น dd/mm/yyyy";
            this.txtTransDateFromSearch.Text = "";
            this.txtTransDateToSearch.Text = "";
        }
        else { this.lblMassage.Text = ""; }

        string m_PolicyNo = this.txbPolicyNoSearch.Text.Trim();
        string m_JobNo = this.txtJobNoSearch.Text.Trim() ;
        string m_InsureName = this.txbInsuredNameSearch.Text.Trim();
        string m_TravelerName = "";
        string m_PassportID = "";
        string m_TransDateFrom = this.txtTransDateFromSearch.Text.Trim();
        string m_TransDateTo = this.txtTransDateToSearch.Text.Trim();
        string m_GroupBrokerId = Utilities.GetGroupBrokerID();

  

        TATransPolicyBLL clstranspolicy = new TATransPolicyBLL();
        DataTable dt = clstranspolicy.GetDtTAGetListTAPolicy(m_PolicyNo, m_JobNo, m_InsureName, m_TravelerName, m_PassportID, GetFormateDateYMD(m_TransDateFrom), GetFormateDateYMD(m_TransDateTo), m_GroupBrokerId);
        this.SetDataToBindGridView(dt);
        
    }

    //CONTROL HANDLER PROCESS OF GRIDVIEW
    protected void gdvListToCopyTaPolicy_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdvListToCopyTaPolicy.PageIndex = e.NewPageIndex;
        BindDataToGridView();
    }
    protected void gdvListToCopyTaPolicy_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        DataRowView RowData = (DataRowView)e.Row.DataItem;
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string m_policyno = RowData["PolicyNo"].ToString(); //policyno
            HtmlInputButton btnEdit = (HtmlInputButton)e.Row.FindControl("btnEdit");
            if (string.IsNullOrEmpty(m_policyno))
            {
                btnEdit.Visible = true;
                btnEdit.Attributes["onclick"] = "window.location='Default.aspx?JobNo=" + RowData["JobNo"].ToString() + "&mode=edit'";
            }
            else
            {
                btnEdit.Visible = false;                
            }
                        
        }
    }
    protected void gdvListToCopyTaPolicy_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        
    }
    protected void gdvListToCopyTaPolicy_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {
      
    }
    protected void gdvListToCopyTaPolicy_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
      
    }
    protected void gdvListToCopyTaPolicy_RowCreated(object sender, GridViewRowEventArgs e)
    {
        
    }


    //BIND DATA ON GRIDVIEW
    protected void SetDataToBindGridView(DataTable dt)
    {
        if (dt.Rows.Count > 0)
        {
            Session["GetDtTAGetListTAPolicy"] = dt.DefaultView;
            BindDataToGridView();
        }
        else
        {
            ClearDataInGridView();
        }
    }
    protected void BindDataToGridView()
    {
        DataView dv = (DataView)Session["GetDtTAGetListTAPolicy"];
        gdvListToCopyTaPolicy.DataSource = dv;
        gdvListToCopyTaPolicy.DataBind();
        if (dv == null)
        {
            this.lblTotalRecord.Text = "แสดงรายการข้อมูล [จำนวนข้อมูลทั้งหมด " + 0 + " รายการ]";
        }
        else
        {
            this.lblTotalRecord.Text = "แสดงรายการข้อมูล [จำนวนข้อมูลทั้งหมด " + dv.Count + " รายการ]";
        }

    }
    protected void ClearDataInGridView()
    {
        Session["GetDtTAGetListTAPolicy"] = null;
        BindDataToGridView();
    }
    protected void ClearDataOnPage()
    {
        //CLEAR MESSAGE
        this.lblInformMessage.Text = "";
        this.lblErrorMessage.Text = "";

        //CLEARE DATA IN GRIDVIEW
        this.ClearDataInGridView();
    }
    private string GetFormateDateYMD(string date)
    {
        if (string.IsNullOrEmpty(date))
        {
            return "";
        }
        else
        {

            string[] DatePart = date.Split('/');
            return DatePart[2] + '-' + DatePart[1] + '-' + DatePart[0];
        }

    }
    protected void DefaultPageRegisterClientScript()
    {
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptScrolling", "MenuScroll();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptTxtFocus", "setFocusTextbox();", true);
        //ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDrawCorner", "DrawDivCorner();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDisplayMsg", "DisplayWarning();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptMenu", "<script type='text/javascript' language='javascript'>$(document).ready(function () { $('.TRAVEL').find('img').attr('src', '../Images/Index/TA1.png');$('.TRAVEL').find('a').css('color', '#922d3d');$('.TRAVEL').hover(function () {$(this).find('img').attr('src', '../Images/Index/TA1.png'); },function () {$(this).find('img').attr('src', '../Images/Index/TA1.png');}); addSubMenu('hdnTa', '.subNavigate', 'Duplicate /Edit Job', '');$('[id$=txtTransDateFromSearch]').datepicker({ dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true });$('[id$=txtTransDateToSearch]').datepicker({ dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true });Accordion('.wizard', 'hdnCriteriaStep'); }); </script>", false);
       
    }
}