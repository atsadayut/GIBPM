using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using TA.BLL;
using TA.BusinessObjects;
using System.Data.Common;

public partial class Report_ListPrint : System.Web.UI.Page
{
    string PolicyNo = "";
    string PolicyType = "";
    string PlanId = "";
    string brokercode = "";
    string EndtNo = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        this.gdvDocument.RowDataBound +=new GridViewRowEventHandler(gdvDocument_RowDataBound);
        this.btnSetPrintFlag.ServerClick +=new EventHandler(btnSetPrintFlag_ServerClick);
        this.btnSendEmail.ServerClick += new EventHandler(btnSendEmail_ServerClick);
        DefaultPageRegisterClientScript();

        lbMsgPrint.Visible = false;
        brokercode = Utilities.BrokerCode();
       

        if (brokercode == "")
        {
            ShowMessage("�������ö����¡���� ���ͧ�ҡ�س�ѧ������������к� !");
            //VISIBLE
            gdvDocument.Visible = false;
            this.tblSendEmail.Visible = false;
        }
        else
        {
            try
            {
                PolicyNo = Request.QueryString["policyno"].ToString().Trim();
                PolicyType = Request.QueryString["policytype"].ToString().Trim();
                PlanId = Request.QueryString["planid"].ToString().Trim();
                EndtNo = Request.QueryString["endtno"].ToString().Trim();

                if (!Page.IsPostBack)
                {
                    this.GetEmailAdress();
                }
                if (PolicyNo.Trim() == string.Empty)
                {
                    ShowMessage("�������ö����¡���� ���ͧ�ҡ����բ����š��������� !");
                    return;
                }
                else
                {
                    lbPolicyReturn.Text = "<center>" + PolicyNo + "</center>";
                    this.BindData(PolicyNo,EndtNo);
                    this.tblSendEmail.Visible = true;
                }
                
            }
            catch (Exception ex)
            {
                ShowMessage(ex.Message);
            }
        }
    }

    protected void btnSendEmail_ServerClick(object sender, EventArgs e)
    {

        if (!string.IsNullOrEmpty(this.txtSendEmail.Value))
        {
            string jobno = "";
            //if (EndtNo == "1") {
            //    jobno = Request.QueryString["jobno"] + "-1";
            //} else {
            //    jobno = Request.QueryString["jobno"];
            //}
            string insuredName = Request.QueryString["insured_name"];

            string emailFrom = "nampetch.bo@axa.co.th";//"QuickLinkTAHelpdesk@axa.co.th";
            string emailTo = this.txtSendEmail.Value.Trim();
            string subject = "Confirmation of Travel Insurance Schedule";

            string body = "This email address is unmonitored. Please do not use \"reply mail\" function to contact us. <br/><br/>";
            body += "<p>Policy No: " + PolicyNo + "<br/><br/>";

            body += "<p>Dear " + insuredName + ",<br/><br/>";

            body += "Thank you for choosing AXA for your travel insurance.<br/><br/><br/>";
            body += "We are pleased to confirm your Travel Insurance schedule and attached herewith, please find your details of  coverage.<br/><br/>";
            body += " <FONT COLOR=#FF0000><b> Please click link below to download your Policy Wording for your benefit in case of claims</b></FONT><br/>";
            body += "� <a href='http://www.axa.co.th/viewdownload.aspx?file=679fi_616.pdf&ofile=Policy+SmartTraveller+Plus+EN.pdf' target='_blank'>Policy Wording Download</a> <br>";
            body += "�	Or http://www.axa.co.th/311/th/retail-insurance/travel/smarttraveller-plus<br/><br/>";
            body += "We are pleased to recommend you keeping this policy schedule during your travelling.<br/><br/>";
            body += "In case of accident, kindly contact our Hotline 24 Hour emergency assistance at +66 2642 6688, +66 2206 5488.<br/><br/>";
            body += "We wish you a safe and pleasant trip.<br/><br/>";
            body += "Free 24 Hour Emergency Assistance<br/>";
            body += "AXA HOTLINE<br/>";
            body += "Tel: +66 2642 6688 <br/>";
            body += "Tel: +66 2206 5488<br/>";
             body += "For full details please visit www.axa.co.th<br/><br/><br/><br/>";

             body += "���������Сѹ��¡���Թ�ҧ �Ţ��� : " + PolicyNo + "<br/><br/>";
            body += "���¹ " + insuredName + ",<br/><br/>";
            body += "����ѷ �͡��һ�Сѹ��� �ӡѴ (��Ҫ�) �͢ͺ�س����ҹ����ҧ���� ����ѷ �繼��������������ͧ���ҹ ������ҧ����Թ�ҧ<br/><br/>";
            body += "����ѷ��Ṻ ���ҧ���������Сѹ��¡���Թ�ҧ �������� ��ѡ�ҹ�׹�ѹ����������ͧ���ҹ <br/><br/>";
            body += " <FONT COLOR=#FF0000><b> ��سҴ�ǹ���Ŵ �����ͻ�Сѹ��¡���Թ�ҧ����췷������������� ���ͻ���ª��ͧ��ҹ㹡�����������:</b></FONT><br/>";
            body += "� <a href='http://www.axa.co.th/viewdownload.aspx?file=678fi_134.pdf&ofile=Policy+SmartTraveller+Plus+TH.pdf' target='_blank'>�����ͻ�Сѹ��¡���Թ�ҧ����췷������������� ��ǹ���Ŵ </a><br/>";
            body += "�	���� http://www.axa.co.th/311/th/retail-insurance/travel/smarttraveller-plus<br/><br>";
            body += "���ͤ����дǡ�ͧ��ҹ �ҧ����ѷ �й�����ҹ �����͡��ù��  �����ҧ����Թ�ҧ�ͧ��ҹ �ҡ��ҹ���ʺ�غѵ��˵� ���� <br/>";
            body += "��ͧ��ä������������ ��سҵԴ����ٹ���͡��� �͵�Ź� ��ԡ�ê�������ͩء�Թ��ʹ 24 ���������� <br/>";
            body += "�����Ţ +66 2642 6688, +66 2206 5488.<br/><br/>";
            body += "������ҹ�դ����آ��л�ʹ��µ�ʹ����Թ�ҧ<br/><br/>";

            body += "<b>��ԡ�ê�������ͩء�Թ 24 �������</b><br/>";
            body += "<b>�͡��� �͵�Ź�</b><br/>";
            body += "��: +66 2642 6688 <br/>";
            body += "��: +66 2206 5488<br/>";
            body += "���䫴� : www.axa.co.th<br/></p>";

            try
            {
                //string url = "";
                string type = "";
                if (EndtNo == "1")
                {
                    type = "11";
                    //url = QuickLinkConfiguration.UrlReportingServiceTQM + "TA_copy_CancelPolicy" + "&rs:Format=pdf&rs:command=render&EndtNO=" + PolicyNo;
                }
                else
                {
                    type = "10";
                    //url = QuickLinkConfiguration.UrlReportingServiceTQM + "TA_copy_Policy" + "&rs:Format=pdf&rs:command=render&PolicyNo=" + PolicyNo + "&PolicyType=" + PolicyType + "&PlanId=" + PlanId;


                }

               // this.PrintTAPolicy(url, jobno);

                string path =  path = Server.MapPath(Request.ApplicationPath + "/TA/DOC/" + PolicyNo);
                //ScriptManager.RegisterStartupScript(this, typeof(string), "OPEN_WINDOW", "window.open( '" + @"~/../../TA/DOC/" + jobno + @"/" + jobno + @".pdf" + "', null, 'height=400,width=800,status=yes,toolbar=no,menubar=no,location=no' );", true);
                //string filePath = @"C:\Inetpub\wwwroot\QuickLink\TA\DOC\" + jobno + @"\" + jobno + @".pdf";

                string filePath = path + "\\" + PolicyNo+type + ".pdf";
                //string filePath = @"D:\QuickLinkTA\TA\DOC\" + jobno + @"\" + jobno + @".pdf";
                //string filePath = Server.MapPath(Request.ApplicationPath + "/TA/DOC/" + jobno + "/" + jobno + ".pdf");
                // string filePath = Server.MapPath("../DOC/" + jobno + "/" + jobno + ".pdf");
                Utilities.SendMail(emailFrom, emailTo, subject, body, true, filePath);

                Utilities.SendMailck(emailFrom, emailTo, subject, body, true, filePath, Session["Username"].ToString().Trim());

                 this.lbMsgPrint.Text = "";
                this.lblMessageSendMailSuccess.Text = "E-mail Sent!!";
                //Response.End();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex); 
                ShowMessage(ex.Message);
                throw ex;
                
                //Response.Write(ex.Message);
                //Response.End();
            }
        }
        else
        {
            this.lblMessageSendMailSuccess.Text = "";
            ShowMessage("Email Field not empty!! / ������������ҧ!!.");
        }                
    }
    protected void gdvDocument_RowDataBound(object sender, GridViewRowEventArgs e)
    {
       string url = "";
        //string policyno = "";
        string type = "";

        if (e.Row.RowIndex >= 0)
        {
            DataRowView rowView =  (DataRowView)e.Row.DataItem;
            
            //------------------print original--------------------
            HtmlInputButton btnOriginal = new HtmlInputButton();
            btnOriginal.Value = "Print(" + rowView["FlagOriginal"].ToString() + ")";
            btnOriginal.Style.Add("width", "110px");
            //if (rowView["FlagOriginal"].ToString() == "0")
            if (Convert.ToInt32(rowView["FlagOriginal"]) < 1)
            {
                btnOriginal.Disabled = true;
            }
            else
            {
                
                btnOriginal.Attributes["onclick"] = "if (confirm('Are you sure you want to print?')==false) return;";
                btnOriginal.Attributes["onclick"] += "setFlagPrint('Original');";

                if (rowView["EndtNo"].ToString() == "0")
                {
                    url = QuickLinkConfiguration.UrlReportingServiceNew + rowView["ReportName"].ToString() + "&rs:Format=pdf&rs:command=render&PolicyNo=" + PolicyNo + "&PolicyType=" + PolicyType + "&PlanId=" + PlanId;
                    type = "00";
                    printTAPolicy(url, PolicyNo, type);
                    btnOriginal.Attributes["onclick"] += "window.open ( '" + @"../DOC/" + PolicyNo + @"/" + PolicyNo + type + @".pdf','_blank' );window.location.reload();";
                    //btnOriginal.Attributes["onclick"] += "window.open ( '" + QuickLinkConfiguration.UrlReportingService + rowView["ReportName"].ToString() + "&rs:Format=pdf&rs:command=render&PolicyNo=" + PolicyNo + "&PolicyType=" + PolicyType + "&PlanId=" + PlanId + "' );window.location.reload();";
                }
                else
                {
                   // btnOriginal.Attributes["onclick"] += "window.open ( '" + QuickLinkConfiguration.UrlReportingService + rowView["ReportName"].ToString() + "&rs:Format=pdf&rs:command=render&EndtNO=" + PolicyNo + "' );window.location.reload();";

                    url = QuickLinkConfiguration.UrlReportingServiceNew + rowView["ReportName"].ToString() + "&rs:Format=pdf&rs:command=render&EndtNO=" + PolicyNo;
                    type = "01";
                    printTAPolicy(url, PolicyNo, type);
                    btnOriginal.Attributes["onclick"] += "window.open ( '" + @"../DOC/" + PolicyNo + @"/" + PolicyNo + type + @".pdf','_blank' );window.location.reload();";
                }
            }
            
            e.Row.Cells[1].Controls.Add(btnOriginal);

            //------------------print Copy--------------------
            HtmlInputButton btnCopy = new HtmlInputButton();
            btnCopy.Value = "Print(" + rowView["FlagCopy"].ToString() + ")";
            btnCopy.Style.Add("width", "110px");
            //if (rowView["FlagCopy"].ToString() == "0")
            if (Convert.ToInt32(rowView["FlagCopy"]) < 1)
            {
                btnCopy.Disabled = true;
            }
            else
            {
                btnCopy.Attributes["onclick"] = "if (confirm('Are you sure you want to print?')==false) return;";
                btnCopy.Attributes["onclick"] += "setFlagPrint('Copy');";
                if (rowView["EndtNo"].ToString() == "0")
                {
                   // btnCopy.Attributes["onclick"] += "window.open ( '" + QuickLinkConfiguration.UrlReportingService + rowView["ReportCopyName"].ToString() + "&rs:Format=pdf&rs:command=render&PolicyNo=" + PolicyNo + "&PolicyType=" + PolicyType + "&PlanId=" + PlanId + "') ;window.location.reload();";
                    url = QuickLinkConfiguration.UrlReportingServiceNew + rowView["ReportCopyName"].ToString() + "&rs:Format=pdf&rs:command=render&PolicyNo=" + PolicyNo + "&PolicyType=" + PolicyType + "&PlanId=" + PlanId;
                    type = "10";
                    printTAPolicy(url, PolicyNo, type);
                    btnCopy.Attributes["onclick"] += "window.open ( '" + @"../DOC/" + PolicyNo + @"/" + PolicyNo + type + @".pdf','_blank' );window.location.reload();";
 
                }
                else
                {
                    //btnCopy.Attributes["onclick"] += "window.open ( '" + QuickLinkConfiguration.UrlReportingService + rowView["ReportCopyName"].ToString() + "&rs:Format=pdf&rs:command=render&amp;EndtNO=" + PolicyNo + "') ;window.location.reload();";
                    url = QuickLinkConfiguration.UrlReportingServiceNew + rowView["ReportCopyName"].ToString() + "&rs:Format=pdf&rs:command=render&EndtNO=" + PolicyNo;
                    type = "11";
                    printTAPolicy(url, PolicyNo, type);

                    btnCopy.Attributes["onclick"]  += "window.open ( '" + @"../DOC/" + PolicyNo + @"/" + PolicyNo + type + @".pdf','_blank' );window.location.reload();";

                }
            }
            e.Row.Cells[2].Controls.Add(btnCopy);

            //------------------print view--------------------
            HtmlInputButton btnView = new HtmlInputButton();
            btnView.Value = "View";
            btnView.Attributes["onclick"] = "if (confirm('Are you sure you want to print?')==false) return;";
            if (rowView["EndtNo"].ToString() == "0")
            {
                //btnView.Attributes["onclick"] += "window.location =('" + QuickLinkConfiguration.UrlReportingService + rowView["ReportViewName"].ToString() + "&rs:Format=pdf&rs:command=render&PolicyNo=" + PolicyNo + "&PolicyType=" + PolicyType + "&PlanId=" + PlanId + "') ;";
                url = QuickLinkConfiguration.UrlReportingServiceNew + rowView["ReportViewName"].ToString() + "&rs:Format=pdf&rs:command=render&PolicyNo=" + PolicyNo + "&PolicyType=" + PolicyType + "&PlanId=" + PlanId;
                type = "20";
                printTAPolicy(url, PolicyNo, type);
                btnView.Attributes["onclick"] += "window.open ( '" + @"../DOC/" + PolicyNo + @"/" + PolicyNo + type + @".pdf','_blank' );window.location.reload();";

            }
            else
            {
              //  btnView.Attributes["onclick"] += "window.location =('" + QuickLinkConfiguration.UrlReportingService + rowView["ReportViewName"].ToString() + "&rs:Format=PDF&rs:command=render&EndtNO=" + PolicyNo + "') ;";
                url = QuickLinkConfiguration.UrlReportingServiceNew + rowView["ReportViewName"].ToString() + "&rs:Format=pdf&rs:command=render&EndtNO=" + PolicyNo;
                type ="21";
                printTAPolicy(url, PolicyNo, type);

                btnView.Attributes["onclick"] += "window.open ( '" + @"../DOC/" + PolicyNo + @"/" + PolicyNo + type + @".pdf','_blank' );window.location.reload();";

            }
            btnView.Style.Add("width", "110px");
            e.Row.Cells[3].Controls.Add(btnView);

        }
    }
    private void ShowMessage(string msg)
    {
        lbMsgPrint.Visible = true;
        lbMsgPrint.Text = msg; 
        lbMsgPrint.ForeColor = System.Drawing.Color.White  ;
        lbMsgPrint.Font.Bold = true;
    }
    private void btnSetPrintFlag_ServerClick(object sender, EventArgs e)
    {
        TATransPolicyBLL SetPrintFlag = new TATransPolicyBLL();
        if (this.hdnPrintFlag.Value == "Original")
        {
            SetPrintFlag.SetTAPrintFlagOriginal(PolicyNo, EndtNo, 1);
        }
        else
        {
            SetPrintFlag.SetTAPrintFlagCopy(PolicyNo, EndtNo, 1);
        }
        this.BindData(PolicyNo,EndtNo);
        DefaultPageRegisterClientScript();
    }
    private void BindData(string v_PolicyNo,string v_Endtno)
    {
        DataTable DTAble = new DataTable();
        TATransPolicyBLL getPrintListReportName = new TATransPolicyBLL();

        DTAble = getPrintListReportName.GetTAPrintListReportName(v_PolicyNo, v_Endtno);
        gdvDocument.DataSource = DTAble;
        gdvDocument.DataBind();
    }
    protected void DefaultPageRegisterClientScript()
    {
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptScrolling", "MenuScroll();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptTxtFocus", "setFocusTextbox();", true);
       
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptFunction", "<script type='text/javascript' language='javscript'>function setFlagPrint(Flag) {$('[id$=hdnPrintFlag]').val(Flag);$('[id$=btnSetPrintFlag]').click();}</script>", false);

    }
    private void GetEmailAdress()
    {
        string jobno = Request.QueryString["jobno"];

        TATransPolicyHolderBLL getEmail = new TATransPolicyHolderBLL();
        TATransPolicyHolder clsTATransPolicyHolder = new TATransPolicyHolder();
        clsTATransPolicyHolder = getEmail.GetTATransPolicyHolder(jobno);

        txtSendEmail.Value = clsTATransPolicyHolder.Email.Trim();
    }
    protected void chkSendEmail_CheckedChanged(object sender, EventArgs e)
    {
        if (this.chkSendEmail.Checked)
        {
            this.txtSendEmail.Visible = true;
            this.btnSendEmail.Visible = true;
        }
        else
        {
            this.txtSendEmail.Visible = false;
            this.btnSendEmail.Visible = false;
        }
    }
    public void PrintTAPolicy(string url, string policy)
    {
        string Command = "Render";
        string Format = "PDF";

        System.Net.NetworkCredential Credentials = new System.Net.NetworkCredential();
        //Credentials.UserName = "quicklink";
        //Credentials.Password = "Password1";
        Credentials.UserName = "nampetch";
        Credentials.Password = "Applinx@0";
        Credentials.Domain = "bkk.dom";
            //We can get values of these parameters from Request object.

            string URL = url;
        

            // URL = URL + "&rs:Command=" + Command + "&rs:Format=" + Format + "&Policy=" + Policy + "&PolicyTo=" + PolicyTo + "&IssueDateFrom=" + IssueDateFrom + "&IssueDateTo=" + IssueDateTo + "&BrokerCode=" + BrokerCode;
            System.Net.HttpWebRequest Req = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(URL);
            
        
        //Req.Credentials = System.Net.CredentialCache.DefaultCredentials;
            Req.Credentials = Credentials;
            Req.ContentType = " text/html";


            Req.Method = "GET";

            string path = Server.MapPath(Request.ApplicationPath + "/TA/DOC/" + policy);
            //Specify the path for saving.
            //System.IO.DirectoryInfo di = new DirectoryInfo(@"C:\Inetpub\wwwroot\QuickLink\TA\DOC\" + jobno);
            System.IO.DirectoryInfo di = new DirectoryInfo(path);
            if (!di.Exists)
            {
                //System.IO.Directory.CreateDirectory(@"C:\Inetpub\wwwroot\QuickLink\TA\DOC\" + jobno);
                System.IO.Directory.CreateDirectory(path);
            }

            //string filepath = @"C:\Inetpub\wwwroot\QuickLink\TA\DOC\" + jobno + @"\" + jobno + @".pdf";
            //string filepath = path + "\\" + jobno + ".pdf";
            // string filepath = "D:/QuickLinkTA/TA/DOC/" + jobno + "/" + jobno + ".pdf";
            //string filepath = Server.MapPath(Request.ApplicationPath + "/TA/DOC/" + jobno + "/" + jobno + ".pfd");
            //string filepath = Server.MapPath("../DOC/" + jobno + "/" + jobno + ".pdf");
            string filepath = path + "\\" + policy + ".pdf";
            if (!File.Exists(filepath))
            {
            //    File.Delete(filepath);
            //} else {
              System.Net.HttpWebResponse objResponse = (System.Net.HttpWebResponse)Req.GetResponse();

            System.IO.FileStream fs = new System.IO.FileStream(filepath, System.IO.FileMode.Create);

            System.IO.Stream stream = objResponse.GetResponseStream();

            byte[] buf = new byte[1024];

            int len = stream.Read(buf, 0, 1024);

            while (len > 0)
            {

                fs.Write(buf, 0, len);

                len = stream.Read(buf, 0, 1024);

            }

            stream.Close();
            stream.Flush();
            fs.Flush();
            fs.Close();         
            
            }



        

            //Response.Write(filepath);
            //Response.End();
            
        
        
    }

    public void printTAPolicy(string url, string policyno, string type)
    {
        string Command = "Render";
        string Format = "PDF";

        System.Net.NetworkCredential Credentials = new System.Net.NetworkCredential();
        //Credentials.UserName = "quicklink";
        //Credentials.Password = "Password1";
        Credentials.UserName = "nampetch";
        Credentials.Password = "Applinx@0";
        Credentials.Domain = "bkk.dom";
        //We can get values of these parameters from Request object.

        string URL = url;


        // URL = URL + "&rs:Command=" + Command + "&rs:Format=" + Format + "&Policy=" + Policy + "&PolicyTo=" + PolicyTo + "&IssueDateFrom=" + IssueDateFrom + "&IssueDateTo=" + IssueDateTo + "&BrokerCode=" + BrokerCode;


        //Specify the path for saving.
        System.IO.DirectoryInfo di = new DirectoryInfo(@"C:\Inetpub\wwwroot\QuickLink\TA\DOC\" + policyno);
        //System.IO.DirectoryInfo di = new DirectoryInfo(@"D:\Workspaces\QuickLinkEnhancement\QuickLink\TA\DOC\" + policyno);
        if (!di.Exists)
        {
            System.IO.Directory.CreateDirectory(@"C:\Inetpub\wwwroot\QuickLink\TA\DOC\" + policyno);
            //System.IO.Directory.CreateDirectory(@"D:\Workspaces\QuickLinkEnhancement\QuickLink\TA\DOC\" + policyno);
        }

        string path = @"C:\Inetpub\wwwroot\QuickLink\TA\DOC\" + policyno + @"\" + policyno + type + @".pdf";
        //string path = @"D:\Workspaces\QuickLinkEnhancement\QuickLink\TA\DOC\" + policyno + @"\" + policyno + type + @".pdf";

        if (!File.Exists(path))
        {
        //     File.Delete(path);
        //} else {

            System.Net.HttpWebRequest Req = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(URL);
            Req.Credentials = Credentials; // System.Net.CredentialCache.DefaultCredentials;
            Req.ContentType = " text/html";


            Req.Method = "GET";


            System.Net.HttpWebResponse objResponse = (System.Net.HttpWebResponse)Req.GetResponse();

            System.IO.FileStream fs = new System.IO.FileStream(path, System.IO.FileMode.Create);

            System.IO.Stream stream = objResponse.GetResponseStream();

            byte[] buf = new byte[1024];

            int len = stream.Read(buf, 0, 1024);

            while (len > 0)
            {

                fs.Write(buf, 0, len);

                len = stream.Read(buf, 0, 1024);

            }

            stream.Close();

            fs.Close();
        }
    }


}
