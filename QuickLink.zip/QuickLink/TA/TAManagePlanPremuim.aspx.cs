﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using TA.BLL;

public partial class TA_TAManagePlanPremuim : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.btnSearchPlanPremium.ServerClick += new EventHandler(btnSearchPlanPremium_ServerClick);
        this.gdvPlanPremuim.PageIndexChanging += new GridViewPageEventHandler(gdvPlanPremuim_PageIndexChanging);
        this.gdvPlanPremuim.RowUpdating += new GridViewUpdateEventHandler(gdvPlanPremuim_RowUpdating);
        this.gdvPlanPremuim.RowEditing += new GridViewEditEventHandler(gdvPlanPremuim_RowEditing);
        this.gdvPlanPremuim.RowCancelingEdit += new GridViewCancelEditEventHandler(gdvPlanPremuim_RowCancelingEdit);
        //this.gdvPlanPremuim.RowDataBound += new GridViewRowEventHandler(gdvPlanPremuim_RowDataBound);

        if (!Page.IsPostBack)
        {
            SetPlanIDToDropdownList(this.ddlInsurancePlan);
        }
    }

    void btnSearchPlanPremium_ServerClick(object sender, EventArgs e)
    {
        string v_PlanID = this.ddlInsurancePlan.SelectedValue;
        string v_TravelPlan = this.rdoTravelPlan.SelectedValue;

        if (v_PlanID == "0000")
        {
            this.lblErrorMessage.Text = "ไม่พบข้อมูลที่ท่านเลือก.";
            this.lblInformMessage.Text = "";
            this.gdvPlanPremuim.Visible = false;
            this.lblTotalRecord.Visible = false;
        }
        else
        {
            getPlanPremuim(v_PlanID, v_TravelPlan);
            this.gdvPlanPremuim.Visible = true;
            this.lblTotalRecord.Visible = true;
        }
    }
    protected void SetPlanIDToDropdownList(DropDownList ddl)
    {
        try
        {
            //PROCESS GET DATA
            TATBPlanIDBLL clsplanid = new TATBPlanIDBLL();
            DataTable dt = clsplanid.GetDtTATBPlanIDs(); //GET ALL
            DataRow dr = dt.NewRow();
            dr["PlanName"] = "โปรดเลือก";
            dr["PlanID"] = "0000";
            dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "PlanName";
                ddl.DataValueField = "PlanID";
                ddl.DataBind();
            }

        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }

    void gdvPlanPremuim_RowEditing(object sender, GridViewEditEventArgs e)
    {

        gdvPlanPremuim.EditIndex = e.NewEditIndex;
        BindDataToGridView();
    }
    void gdvPlanPremuim_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gdvPlanPremuim.EditIndex = -1;
        BindDataToGridView();
    }
    void gdvPlanPremuim_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {

        HiddenField hdnPolicyType = (HiddenField)gdvPlanPremuim.Rows[e.RowIndex].FindControl("hdnPolicyType");
        Label lblPlanID = (Label)gdvPlanPremuim.Rows[e.RowIndex].FindControl("lblPlanID");
        Label lblTravelPlan = (Label)gdvPlanPremuim.Rows[e.RowIndex].FindControl("lblTravelPlan");
        Label lblDurationFrom = (Label)gdvPlanPremuim.Rows[e.RowIndex].FindControl("lblDurationFrom");
        Label lblDurationTo = (Label)gdvPlanPremuim.Rows[e.RowIndex].FindControl("lblDurationTo");
        TextBox txtNetPremium = (TextBox)gdvPlanPremuim.Rows[e.RowIndex].FindControl("txtNetPremium");
        CheckBox chkisEnabel = (CheckBox)gdvPlanPremuim.Rows[e.RowIndex].FindControl("chkisEnabel");
        string m_UserWeb = Utilities.GetUsername().Trim();

        TAPlanPremuimBLL SetTATransCoverage = new TAPlanPremuimBLL();
        SetTATransCoverage.SetTAPlanPremuim(lblPlanID.Text, hdnPolicyType.Value, lblTravelPlan.Text, Convert.ToInt32(lblDurationFrom.Text), Convert.ToInt32(lblDurationTo.Text), Convert.ToDouble(txtNetPremium.Text), Convert.ToSByte(chkisEnabel.Checked), m_UserWeb);

        gdvPlanPremuim.EditIndex = -1;

        btnSearchPlanPremium_ServerClick(this.btnSearchPlanPremium,EventArgs.Empty);

        this.lblInformMessage.Text = "แก้ไขข้อมูลเรียบร้อยแล้ว";
        this.lblErrorMessage.Text = "";
    }

    private void getPlanPremuim(string PlanID, string TravelPlan)
    {
        TAPlanPremuimBLL GetAllTAPlanPremuim = new TAPlanPremuimBLL();
        Session["getPlanPremuim"] = GetAllTAPlanPremuim.GetAllTAPlanPremuim(PlanID, TravelPlan);
        BindDataToGridView();

    }
    protected void BindDataToGridView()
    {

        DataTable lst = (DataTable)Session["getPlanPremuim"];
        gdvPlanPremuim.DataSource = lst;
        gdvPlanPremuim.DataBind();
        if (lst == null)
        {
            this.lblTotalRecord.Text = "แสดงรายการข้อมูล [จำนวนข้อมูลทั้งหมด " + 0 + " รายการ]";
        }
        else
        {
            this.lblTotalRecord.Text = "แสดงรายการข้อมูล [จำนวนข้อมูลทั้งหมด " + lst.Rows.Count + " รายการ]";
        }
        this.lblInformMessage.Text = "";
        this.lblErrorMessage.Text = "";

    }
    void gdvPlanPremuim_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdvPlanPremuim.PageIndex = e.NewPageIndex;
        BindDataToGridView();

        this.lblInformMessage.Text = "";
        this.lblErrorMessage.Text = "";
    }
}