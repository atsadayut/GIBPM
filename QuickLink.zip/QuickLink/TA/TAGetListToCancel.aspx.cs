﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

//ADDITIONAL USING REFERENCE
using TA.BLL;
using TA.BusinessObjects;
using TA.DAL;
using System.Data;
using System.Data.Common;
using System.Globalization;
using System.IO;

using WSQuickLinkTA;
using WSQuickLinkTAReport;

public partial class TA_TAGetListToCancel : System.Web.UI.Page
{
    //PAGE LOAD
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            DefaultPageRegisterClientScript();

            this.gdvListToCancelTaPolicy.RowCommand += new GridViewCommandEventHandler(gdvListToCancelTaPolicy_RowCommand);
            this.gdvListToCancelTaPolicy.RowDeleted += new GridViewDeletedEventHandler(gdvListToCancelTaPolicy_RowDeleted);
            this.gdvListToCancelTaPolicy.RowDeleting += new GridViewDeleteEventHandler(gdvListToCancelTaPolicy_RowDeleting);
            this.gdvListToCancelTaPolicy.PageIndexChanging += new GridViewPageEventHandler(gdvListToCancelTaPolicy_PageIndexChanging);
            this.gdvListToCancelTaPolicy.RowDataBound += new GridViewRowEventHandler(gdvListToCancelTaPolicy_RowDataBound);
            this.gdvListToCancelTaPolicy.RowCreated += new GridViewRowEventHandler(gdvListToCancelTaPolicy_RowCreated);

            this.btnSearch.ServerClick += new EventHandler(btnSearch_ServerClick);
            this.hideBtnCancel.ServerClick += new EventHandler(hideBtnCancel_ServerClick);

            if (Page.IsPostBack)
            {
                this.GetListTAPolicy();
            }
            else
            { 
                //POST BACK
                
            }
            
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }

    //HANDLER
    protected void hideBtnCancel_ServerClick(object sender, EventArgs e)
    {
        try
        { 
            //SAVE DATA
            string m_jobno = this.hideJobno.Value.Trim().Equals("&nbsp;") ? "" : this.hideJobno.Value.Trim();
            string m_policyno = this.hidePolicyno.Value.Trim().Equals("&nbsp;") ? "" : this.hidePolicyno.Value.Trim();
            string m_userid = Utilities.GetUsername() + " " + Request.ServerVariables["REMOTE_HOST"].ToString();
            string m_groupbrokerid = Utilities.GetGroupBrokerID();
            string ip = System.Web.HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (string.IsNullOrEmpty(ip))
            {
                ip = System.Web.HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
            }

            this.SetTATransCancelPolicy(m_jobno, m_policyno, m_userid, m_groupbrokerid, ip);

            string m_UserWeb = Utilities.GetUsername();
            string m_CreateUser = m_UserWeb;
            string m_AgentCode = Utilities.BrokerCode();

            //REDIRECT
            //Response.Redirect("");
            //--------------------------------------------------------  
            #region Call Method SetTransCancelPolicy.
            TATransPolicyBLL SetTransCancelPolicy = new TATransPolicyBLL();
            SetTransCancelPolicy.SetTATransCancelPolicy(m_jobno, m_policyno, m_UserWeb, m_groupbrokerid, ip);
            #endregion

            #region Call Web Services to Issued TA Policy.
            string msgOut = string.Empty;
            string msgStatus = string.Empty;
            string out_PolicyNo = string.Empty;

            QuickLinkTravelService wsQuickLinkTAIssue = new QuickLinkTravelService();
            out_PolicyNo = wsQuickLinkTAIssue.SetCancelTAPolicy(m_policyno, out msgOut, out msgStatus);

            if (string.Compare(msgStatus, "SUCCESS") != 0)
            {
                throw new System.ArgumentException(msgOut);
            }
            #endregion
       
            #region Call Method SetTransTaxInvoince.
            TATransPolicyBLL SetTransTaxInvoince = new TATransPolicyBLL();
            SetTransTaxInvoince.SetTATransTaxInvoince(out_PolicyNo, m_jobno, m_UserWeb, "1");
            #endregion

            #region Call Web Services getTADocument CREADIT
            WSQuickLinkTAReport.Box_Document[] BoxDocument = new Box_Document[1];

            WSQuickLinkTAReport.Box_Message[] BoxMessage;

            WSQuickLinkTAReport.TADocumentService getTADocument = new WSQuickLinkTAReport.TADocumentService();

            Box_Document BoxDocuemtDetail = new Box_Document();
            BoxDocuemtDetail.PolicyNo = out_PolicyNo;
            BoxDocuemtDetail.Document = "RTHSBTCR";

            BoxDocument[0] = BoxDocuemtDetail;

            BoxMessage = getTADocument.getTADocument(BoxDocument, "QAAPP", "PASSWORD");

            if (BoxMessage[0].Success != "true")
            {
                throw new System.ArgumentException(BoxMessage[0].Error);
            }
            #endregion

            #region Call Web Services getTADocument ENDT
            WSQuickLinkTAReport.Box_Document[] BoxDocumentENDT = new Box_Document[1];

            WSQuickLinkTAReport.Box_Message[] BoxMessageENDT;

            WSQuickLinkTAReport.TADocumentService getTADocumentENDT = new WSQuickLinkTAReport.TADocumentService();

            Box_Document BoxDocuemtDetailENDT = new Box_Document();
            BoxDocuemtDetailENDT.PolicyNo = out_PolicyNo;
            BoxDocuemtDetailENDT.Document = "TMIS007";

            BoxDocumentENDT[0] = BoxDocuemtDetailENDT;

            BoxMessageENDT = getTADocumentENDT.getTADocument(BoxDocumentENDT, "QAAPP", "PASSWORD");

            if (BoxMessageENDT[0].Success != "true")
            {
                throw new System.ArgumentException(BoxMessageENDT[0].Error);
            }
            #endregion

            #region Call Method SetTranPrint.
            TATransPolicyBLL SetTranPrint = new TATransPolicyBLL();
            SetTransTaxInvoince.SetTATransPrint(out_PolicyNo, m_jobno, "1", m_AgentCode, m_groupbrokerid, m_CreateUser);
            #endregion

            this.SendEMail(m_jobno, m_policyno);
            Response.Redirect("TAPrintPolicy.aspx?policyno=" + out_PolicyNo + "&endtno=1");
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }        
    }
    protected void btnSearch_ServerClick(object sender, EventArgs e)
    {
        this.GetListTAPolicy();
    }
    
    //PROCESS DATA
    protected void GetListTAPolicy()
    {
        string m_PolicyNo = this.txbPolicyNoSearch.Text.Trim();
        string m_jobno = "";
        string m_InsureName = this.txbInsuredNameSearch.Text.Trim();
        string m_TravelerName = "";
        string m_PassportID = "";
        string m_TransDateFrom = "";
        string m_TransDateTo = "";
        string m_GroupBrokerId = Utilities.GetGroupBrokerID();

        TATransPolicyBLL clstranspolicy = new TATransPolicyBLL();
        //DataTable dt = clstranspolicy.GetDtTAGetListTAPolicy(m_PolicyNo, m_jobno, m_InsureName, m_TravelerName, m_PassportID, m_TransDateFrom, m_TransDateTo, m_GroupBrokerId);
        DataTable dt = clstranspolicy.GetDtTAGetListTAPolicyForCancel(m_PolicyNo, m_jobno, m_InsureName, m_TravelerName, m_PassportID, m_TransDateFrom, m_TransDateTo, m_GroupBrokerId);
        this.SetDataToBindGridView(dt);
        
    }
    protected void SetTATransCancelPolicy(string JobNo, string PolicyNo, string UserID, string GroupBrokerID, string IPAddress)
    {
        try
        {
            TATransPolicyBLL clstranspolicy = new TATransPolicyBLL();
            int ret = clstranspolicy.SetTATransCancelPolicy(JobNo, PolicyNo, UserID, GroupBrokerID, IPAddress);
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        } 
    }

    //CONTROL HANDLER PROCESS OF GRIDVIEW
    protected void gdvListToCancelTaPolicy_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdvListToCancelTaPolicy.PageIndex = e.NewPageIndex;
        BindDataToGridView();
    }
    protected void gdvListToCancelTaPolicy_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string m_jobno = e.Row.Cells[1].Text.Trim(); //jobno
            string m_policyno = e.Row.Cells[2].Text.Trim(); //policyno
            HtmlInputButton btnCancel = (HtmlInputButton)e.Row.FindControl("btnCancel");
            btnCancel.Attributes.Add("onclick", "gotoCancelPopup('" + m_jobno + "','" + m_policyno + "')");
        }        
    }
    protected void gdvListToCancelTaPolicy_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        
    }
    protected void gdvListToCancelTaPolicy_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {
      
    }
    protected void gdvListToCancelTaPolicy_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
      
    }
    protected void gdvListToCancelTaPolicy_RowCreated(object sender, GridViewRowEventArgs e)
    {
        
    }


    //BIND DATA ON GRIDVIEW
    protected void SetDataToBindGridView(DataTable dt)
    {
        if (dt.Rows.Count > 0)
        {
            Session["GetDtTAGetListTAPolicyCancel"] = dt.DefaultView;
            BindDataToGridView();
        }
        else
        {
            ClearDataInGridView();
        }
    }
    protected void BindDataToGridView()
    {
        DataView dv = (DataView)Session["GetDtTAGetListTAPolicyCancel"];
        gdvListToCancelTaPolicy.DataSource = dv;
        gdvListToCancelTaPolicy.DataBind();
        if (dv == null)
        {
            this.lblTotalRecord.Text = "แสดงรายการข้อมูล [จำนวนข้อมูลทั้งหมด " + 0 + " รายการ]";
        }
        else
        {
            this.lblTotalRecord.Text = "แสดงรายการข้อมูล [จำนวนข้อมูลทั้งหมด " + dv.Count + " รายการ]";
        }

    }
    protected void ClearDataInGridView()
    {
        Session["GetDtTAGetListTAPolicyCancel"] = null;
        BindDataToGridView();
    }
    protected void ClearDataOnPage()
    {
        //CLEAR MESSAGE
        this.lblInformMessage.Text = "";
        this.lblErrorMessage.Text = "";

        //CLEARE DATA IN GRIDVIEW
        this.ClearDataInGridView();
    }
    protected void DefaultPageRegisterClientScript()
    {
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptScrolling", "MenuScroll();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptTxtFocus", "setFocusTextbox();", true);
        //ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDrawCorner", "DrawDivCorner();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDisplayMsg", "DisplayWarning();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptMenu", "<script type='text/javascript' language='javascript'>$(document).ready(function () { $('.TRAVEL').find('img').attr('src', '../Images/Index/TA1.png');$('.TRAVEL').find('a').css('color', '#922d3d');$('.TRAVEL').hover(function () {$(this).find('img').attr('src', '../Images/Index/TA1.png'); },function () {$(this).find('img').attr('src', '../Images/Index/TA1.png');}); addSubMenu('hdnTa', '.subNavigate', 'Cancel Policy', '');Accordion('.wizard', 'hdnCriteriaStep'); }); </script>", false);
       
    }
    private void SendEMail(string v_jobno,string v_policynumber)
    {
        string jobno = v_jobno;
        string policynumber = v_policynumber;

        string emailFrom = "QuickLinkHelpdesk@axa.co.th";
        string emailTo = "QuickLinkTAHelpdesk@axa.co.th";
        string subject = "policy number ;" + policynumber + " be canceled!!";
        string body = "<p>Dear AXA,<br/>";
        body += "policy number ;" + policynumber + " in jobno : " + jobno + " be canceled!!";


        try
        {

            Utilities.SendMail(emailFrom, emailTo, subject, body, true);


            //Response.End();
        }
        catch (Exception ex)
        {
            Utilities.LogError(ex);
            throw ex;

            //Response.Write(ex.Message);
            //Response.End();
        }
    }
}