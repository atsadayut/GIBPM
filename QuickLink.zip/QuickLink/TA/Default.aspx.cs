﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

//ADDITIONAL USING REFERENCE
using TA.BLL;
using TA.BusinessObjects;
using TA.DAL;
using System.Data;
using System.Data.Common;
using System.Globalization;
using System.IO;
using WSQuickLinkTA;
using WSQuickLinkTAReport;


public partial class TA_Default : System.Web.UI.Page
{
    //PAGE LOAD
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            
            this.DefaultPageRegisterClientScript();
            this.ddlInsurancePlan.SelectedIndexChanged += new EventHandler(ddlInsurancePlan_SelectedIndexChanged);
            this.ddlProvine.SelectedIndexChanged += new EventHandler(ddlProvine_SelectedIndexChanged);
            this.ddlAmphure.SelectedIndexChanged += new EventHandler(ddlAmphure_SelectedIndexChanged);
            this.gdvCoverage.RowCreated += new GridViewRowEventHandler(gdvCoverage_RowCreated);
            this.gdvCoverage.RowDataBound += new GridViewRowEventHandler(gdvCoverage_RowDataBound);
            this.btnIssuePolicy.ServerClick += new EventHandler(btnIssuePolicy_ServerClick);
            this.btnSaveDraft.ServerClick += new EventHandler(btnSaveDraft_ServerClick);

            this.btnNumberOfChilden.ServerClick += new EventHandler(btnNumberOfChilden_ServerClick);
            this.chkSameAsPolicyHolder.CheckedChanged += new EventHandler(chkSameAsPolicyHolder_CheckedChanged);

            //----------new 2012 07 25
            this.ddlCountryOfDestination.SelectedIndexChanged +=new EventHandler(ddlCountryOfDestination_SelectedIndexChanged);

            this.ddlLanguage.SelectedIndexChanged += new EventHandler(ddlLanguage_SelectedIndexChanged);
            //Clear some data
            this.lblJobnoValue.Text = "[Auto Generate]";
            this.lblInformMessage.Text = "";
            this.lblErrorMessage.Text = "";

            if (!Page.IsPostBack)
            {
                #region "TEST DATA"
                //--------------------------------------------------------------------------------------------------------------------
                //List<TATBCountry> lst = new List<TATBCountry>();
                //TATBCountryBLL  clscountry = new TATBCountryBLL();
                //lst = clscountry.GetTATBCountrys();
                //gdvCoverage.DataSource = lst;
                //gdvCoverage.DataBind();

                //--------------------------------------------------------------------------------------------------------------------
                //TATBCountryBLL clscountry = new TATBCountryBLL();
                //DataTable dt = clscountry.GetDtTATBCountrys();
                //gdvCoverage.DataSource = dt;
                //gdvCoverage.DataBind();

                //--------------------------------------------------------------------------------------------------------------------
                //PROCESS GET DDL MASTER_STANDARD LIST
                //protected void GetMasterStandardList(DropDownList ddl)
                //{
                //    try
                //    {
                //        //PROCESS GET DATA
                //        List<master_standard> lstmaster_standard = new List<master_standard>();
                //        master_standardBLL clsmaster_standard = new master_standardBLL();
                //        lstmaster_standard = clsmaster_standard.Getmaster_standards(); //GET ALL

                //        ListItem m_listitem = new ListItem("โปรดเลือก", "000");
                //        ddl.Items.Add(m_listitem);

                //        if (lstmaster_standard.Count > 0)
                //        {
                //            foreach (master_standard item in lstmaster_standard)
                //            {
                //                m_listitem = new ListItem(item.standard_name, item.standard_code);
                //                ddl.Items.Add(m_listitem);
                //            }
                //        }
                //    }
                //    catch (Exception ex)
                //    {
                //        this.lblErrorMessage.Text = ex.ToString();
                //        this.lblInformMessage.Text = "";
                //    }
                //}
                //--------------------------------------------------------------------------------------------------------------------

                //TATBTitleBLL clstitle = new TATBTitleBLL();
                //DataTable dt = clstitle.GetDtTATBCountrys();
                //gdvCoverage.DataSource = dt;
                //gdvCoverage.DataBind();

                //--------------------------------------------------------------------------------------------------------------------
                //TAJobRunningBLL clsjobrunning = new TAJobRunningBLL();
                //lblUsername.Text = clsjobrunning.GetTAJobRunningNumber(); 


                //--------------------------------------------------------------------------------------------------------------------

                //TAPlanCoverageBLL plancoverage = new TAPlanCoverageBLL();
                //DataTable dt = plancoverage.GetDtTAPlanCoverages("0001");
                //gdvCoverage.DataSource = dt;
                //gdvCoverage.DataBind();

                #endregion

                //Bind dropdown list "ddlCountryOfDestination"
                this.SetCountryToDropdownList(ddlCountryOfDestination);
                //Bind dropdown list "ddlInsurancePlan"
                this.SetPlanIDToDropdownList(ddlInsurancePlan);
                //Show/Hide Traveler2 Zone
                this.ShowHideTraveler2Zone();

                try
                {
                    string m_JobNo = Request.QueryString["JobNo"];                                        
                    string m_mode = Request.QueryString["mode"];

                    if (!string.IsNullOrEmpty(m_JobNo))
                    {
                        //Edit Mode
                        if (!string.IsNullOrEmpty(m_mode))
                        {
                            if (string.Compare(m_mode.Trim(), "edit") == 0)
                            {
                                this.lblJobnoValue.Text = m_JobNo.Trim();
                            }
                        }
                        //End Edit Mode
                        
                        this.GetBindPolicyHolder(m_JobNo.Trim());
                        this.GetBindPackagePolicy(m_JobNo.Trim(), Utilities.GetGroupBrokerID());
                        this.GetBindTraveler(m_JobNo.Trim());
                    }
                }
                catch (Exception ex)
                { 
                    //DEFAULT MODE
                }
            }
            else
            {
                //PAGE POST BACK 
                GenerateDynamicTraveler();
                this.BindJobNoFromQry2Text();
                this.ClearCssClassFocusError();
            }
        }
        catch (Exception ex)
        {
            Utilities.LogError(ex);
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
        
    #region "PROCESS HANDLER"

    //PROCESS HANDLER    
    protected void gdvCoverage_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataRowView drv = (DataRowView)e.Row.DataItem;
            Label lb = (Label)e.Row.FindControl("lblCoverageAgreement");
            lb.Text = drv.Row["CoverageDetailTH"].ToString() + "<br>" + drv.Row["CoverageDetailEN"].ToString();

            //string m_comvergetype = drv.Row["CoverageType"].ToString();
            //if (m_comvergetype == "REMARK")
            //{
            //    //INSERT TABLE REMARKS
            //    TableRow tr = new TableRow();
            //    TableCell tc = new TableCell();
            //    tc.Text = drv.Row["CoverageDetailTH"].ToString() + drv.Row["CoverageDetailEN"].ToString();
            //    tr.Cells.Add(tc);
            //    tblCoverageRemark.Rows.Add(tr);
            //    e.Row.Cells.Clear();  //CLEARE ROW REMARKS
            //}
            //else
            //{
            //    Label lb = (Label)e.Row.FindControl("lblCoverageAgreement");
            //    lb.Text = drv.Row["CoverageDetailTH"].ToString() +"<br>" + drv.Row["CoverageDetailEN"].ToString();
            //}
        }

    }
    protected void gdvCoverage_RowCreated(object sender, GridViewRowEventArgs e)
    {


    }
    protected void btnIssuePolicy_ServerClick(object sender, EventArgs e)
    {
        DbTransaction dbTransaction = null;
        string qry_mode = "";
        string qry_jobno = "";
        string m_JobNo = lblJobnoValue.Text;
        if (m_JobNo == "[Auto Generate]") { m_JobNo = string.Empty; qry_mode = ""; } else { qry_mode = "edit"; }
        string m_UserWeb = "";
        string m_AgentCode = "";
        string m_GroupBrokerID = "";
        string m_CreateUser = "";
        string ckEx = "";
        try
        {


            #region "GET USER HOST AND WEB"
             m_UserWeb = Utilities.GetUsername().Trim() ;
            //UserHostDetails m_User = UserMember.GetUserHost(m_UserWeb);
            //string m_Username = m_User.UserHostName.ToString();
            //string m_Password = m_User.UserHostPassword.ToString();
            #endregion

            #region "VALIDATE VARIABLE ISSUED POLICY"
            //BEGIN VARIABLE-TRANSPOLICY
            //string m_JobNo = "";                           
            string m_PolicyNo = "";
            string m_TravelPlan = "";
            foreach (ListItem item in rdoTravelPlan.Items)
            {
                if (item.Selected)
                {
                    m_TravelPlan = item.Value.Trim();
                }
            }
            string m_PolicyType = "";
            foreach (ListItem item in rdoPolicyType.Items)
            {
                if (item.Selected)
                {
                    m_PolicyType = item.Value.Trim();
                }
            }

            Nullable<int> m_NumbersOfChildren = int.Parse(this.txtNumberOfChilden.Text.Trim()); ;

            string m_PlanID = this.ddlInsurancePlan.SelectedValue.Trim();
            string m_EffectiveDateFrom = this.txtEffectiveDateFrom.Text.Trim().Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtEffectiveDateFrom.Text.Trim());
            string m_EffectiveDateTo = this.txtEffectiveDateTo.Text.Trim().Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtEffectiveDateTo.Text.Trim());
            string m_CountryOfDestination = this.ddlCountryOfDestination.SelectedItem.Text.Trim();  //Our customer need to change value to text name ,chage date 2012-06-09
            string m_ContryOther = this.txtCountryOfDestinationOther.Value.Trim();
             m_AgentCode = Utilities.BrokerCode(); //;this.ddlIntermediary.SelectedValue;
            string m_OccupatnCode = "";
            Nullable<decimal> m_NetPremium = null;
            if (this.lblNetPremiumValue.Text.Trim() != string.Empty)
            {
                m_NetPremium = (decimal)Utilities.ExactNumber(this.lblNetPremiumValue.Text.Trim());
            }
            Nullable<int> m_Stamp = null;
            if (this.lblStampDiutyValue.Text.Trim() != string.Empty)
            {
                m_Stamp = (int)Utilities.ExactNumber(this.lblStampDiutyValue.Text.Trim());
            }
            Nullable<decimal> m_SBT = null;
            if (this.lblTaxValue.Text.Trim() != string.Empty)
            {
                m_SBT = (decimal)Utilities.ExactNumber(this.lblTaxValue.Text.Trim());
            }
            Nullable<decimal> m_TotalPremium = null;
            if (this.lblTotlaPremiumValue.Text.Trim() != string.Empty)
            {
                m_TotalPremium = (decimal)Utilities.ExactNumber(this.lblTotlaPremiumValue.Text.Trim());
            }
            Nullable<sbyte> m_isLongName = 0;
            Nullable<sbyte> m_isBeneficiary = 0;



            m_CreateUser = m_UserWeb ;

            //m_CreateUser = m_UserWeb;
             m_GroupBrokerID = Utilities.GetGroupBrokerID(); ;
            //END VARIABLE-TRANSPOLICY

            //-------------------------------------------------------------------------------------------------------------
            string msg = "";
            bool flagmsg = false;
 
            if (m_EffectiveDateFrom == string.Empty)
            {
                msg += "Effective Date From |";
                flagmsg = true;
                this.txtEffectiveDateFrom.CssClass = "inputFocusError";
            }

            if (m_EffectiveDateTo == string.Empty)
            {
                msg += "Effective Date To |";
                flagmsg = true;
                this.txtEffectiveDateTo.CssClass = "inputFocusError";
            }
            if (m_CountryOfDestination == "โปรดเลือก")
            {
                msg += "Country Of Destination |";
                flagmsg = true;
            }
            if (m_PlanID == "0000")
            {
                msg += "Insurance Plan |";
                flagmsg = true;
            }
            if (flagmsg)
            {
                this.lblErrorMessage.Text = msg + " ห้ามเป็นค่าว่าง";
                this.lblInformMessage.Text = "";
                return;
            }

            //-------------------------------------------------------------------------------------------------------------
            //BEGIN VARIABLE-TRANSPOLICY HOLDER
            //string m_JOBNO = "";
            string m_BranchNo = this.txtBranchNo.Value.Trim();
            string m_Language = this.ddlLanguage.SelectedValue;
            string m_ClientType = "";
            string m_ClientTitle = this.ddlPolicyHolderTitle.SelectedValue.Trim();
            string m_ClientName = this.txtName.Value.Trim();
            string m_ClientSurName = this.txtSurname.Value.Trim();
            string m_ClientAddress1 = this.txtAddress1.Value.Trim();
            string m_ClientAddress2 = this.txtAddress2.Value.Trim();
            string m_Province = this.ddlProvine.SelectedItem.Text.Trim();  //Our customer need to keep name of province,change value same as text on dropdownlist  ,change date 2012-06-09
            string m_Amphur = this.ddlAmphure.SelectedItem.Text.Trim(); //Our customer need to keep name of amphur,change value same as text on dropdownlist  ,change date 2012-06-09
            string m_Tumbol = this.ddlTumbon.SelectedItem.Text.Trim(); //Our customer need to keep name of tumbol,change value same as text on dropdownlist  ,change date 2012-06-09
            string m_Postcode = this.txtZipCode.Value.Trim();
            string m_Birthday = this.txtBirthday.Value.Trim().Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtBirthday.Value.Trim()); //30/05/2012 to 2012-05-30
            string m_IdCard = this.txtIDCard.Text.Trim();
            string m_Tel = this.txtTel.Value.Trim();
            string m_Email = this.txtEmail.Value.Trim();

            //END VARIABLE-TRANSPOLICY HOLDER
            //-------------------------------------------------------------------------------------------------------------

            //START GET TA GET AGE BY POLICY TYPE,TRAVEL PLAN,PLAN ID
            TAPlanPackageBLL clsplanpackage = new TAPlanPackageBLL();
            TAGetAge getage = clsplanpackage.GetTAGetAge(m_PolicyType, m_TravelPlan, m_PlanID);
            int m_AgeOfTravelerFrom = Convert.ToInt32(getage.AgeOfTravelerFrom);
            int m_AgeOfTravelerTo = Convert.ToInt32(getage.AgeOfTravelerTo);
            //END GET TA GET AGE

            DateTime dt1 = new DateTime();
            DateTime dt2 = new DateTime();
            bool ret = false;
            string policyholdertype = ""; //CHECK POLICY HOLDER TYPE
            foreach (ListItem item in rdoTaxInvoiceType.Items)
            {
                if (item.Selected == true)
                {
                    policyholdertype = item.Value.Trim();  //Private ,Commercial
                }
            }
            msg = "";
            flagmsg = false;
            if (policyholdertype == "Private")
            {
                //Private
                if (m_ClientName == string.Empty)
                {
                    msg += "Name |";
                    flagmsg = true;
                    this.txtName.Attributes["class"] = "inputFocusError";
                }

                if (m_ClientSurName == string.Empty)
                {
                    msg += "Family name |";
                    flagmsg = true;
                    this.txtSurname.Attributes["class"] = "inputFocusError";
                }

                if (m_Birthday == string.Empty)
                {
                    msg += "Birthday |";
                    flagmsg = true;
                    this.txtBirthday.Attributes["class"] = "inputFocusError";
                }
                if (m_IdCard == string.Empty)
                {
                    msg += "ID Card/ Tax ID |";
                    flagmsg = true;
                    this.txtIDCard.CssClass = "inputFocusError";
                }
                if (m_Tel == string.Empty)
                {
                    msg += "Tel |";
                    flagmsg = true;
                    this.txtTel.Attributes["class"] = "inputFocusError";
                }
                if (m_ClientAddress1 == string.Empty)
                {
                    msg += "Address 1 |";
                    flagmsg = true;
                    this.txtAddress1.Attributes["class"] = "inputFocusError";
                }
                if (m_Province == "โปรดเลือก" || m_Province == "Please Selected")
                {
                    msg += "Provine |";
                    flagmsg = true;
                }
                if (m_Amphur == "โปรดเลือก" || m_Amphur == "Please Selected")
                {
                    msg += "District |";
                    flagmsg = true;
                }
                if (m_Tumbol == "โปรดเลือก" || m_Tumbol == "Please Selected")
                {
                    msg += "Sub District |";
                    flagmsg = true;
                }
                if (m_Postcode == string.Empty)
                {
                    msg += "Zip Code  |";
                    flagmsg = true;
                    this.txtZipCode.Attributes["class"] = "inputFocusError";
                }
                if (flagmsg)
                {
                    this.lblErrorMessage.Text = msg + " on Policy Holder ห้ามเป็นค่าว่าง";
                    this.lblInformMessage.Text = "";
                    return;
                }

                //CHECK BIRTHDAY ON POLICY HOLDER
                dt1 = Convert.ToDateTime(m_Birthday);
                dt2 = Convert.ToDateTime(m_EffectiveDateFrom);
                //ret = this.IsBirthDayOverLimitOfEffectiveDate(1, 70, dt1, dt2);
                ret = this.IsBirthDayOverLimitOfEffectiveDate(m_AgeOfTravelerFrom, m_AgeOfTravelerTo, dt1, dt2);
                if (ret)
                {
                    //this.lblErrorMessage.Text = "Birthday on Policy Holder ไม่อยู่ในช่วง 1-70 ปี นับจากวันที่เดินทาง";
                    this.lblErrorMessage.Text = "Birthday on Policy Holder ไม่อยู่ในช่วง " + m_AgeOfTravelerFrom + "-" + m_AgeOfTravelerTo + " ปี นับจากวันที่เดินทาง";
                    this.lblInformMessage.Text = "";
                    return;
                }

                this.txtBranchNo.Value = "";
                m_BranchNo = "";
            }
            else //Commercial
            {
                if (m_ClientName == string.Empty)
                {
                    msg += "Name |";
                    flagmsg = true;
                    this.txtName.Attributes["class"] = "inputFocusError";
                }
                /*if (m_ClientSurName == string.Empty)
                {
                    msg += "Name 2 |";
                    flagmsg = true;
                    this.txtSurname.Attributes["class"] = "inputFocusError";
                }*/
                if (m_IdCard == string.Empty)
                {
                    msg += "ID Card/ Corporate Tax ID |";
                    flagmsg = true;
                    this.txtIDCard.CssClass = "inputFocusError";
                }
                if (m_Tel == string.Empty)
                {
                    msg += "Tel |";
                    flagmsg = true;
                    this.txtTel.Attributes["class"] = "inputFocusError";
                }
                if (m_ClientAddress1 == string.Empty)
                {
                    msg += "Address 1 |";
                    flagmsg = true;
                    this.txtAddress1.Attributes["class"] = "inputFocusError";
                }
                if (m_Province == "โปรดเลือก" || m_Province == "Please Selected")
                {
                    msg += "Provine |";
                    flagmsg = true;
                }
                if (m_Amphur == "โปรดเลือก" || m_Amphur == "Please Selected")
                {
                    msg += "District |";
                    flagmsg = true;
                }
                if (m_Tumbol == "โปรดเลือก" || m_Tumbol == "Please Selected")
                {
                    msg += "Sub District |";
                    flagmsg = true;
                }
                if (m_Postcode == string.Empty)
                {
                    msg += "Zip Code  |";
                    flagmsg = true;
                    this.txtZipCode.Attributes["class"] = "inputFocusError";
                }
                if (flagmsg)
                {
                    this.lblErrorMessage.Text = msg + " on Policy Holder ห้ามเป็นค่าว่าง";
                    this.lblInformMessage.Text = "";
                    return;
                }
            }



            //-------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------
            //CHECK TRAVELER 1
            string m_Traveler1ClientName = this.txtTraveler1Name.Value.Trim();
            string m_Traveler1ClientSurName = this.txtTraveler1Surname.Value.Trim();
            string m_Traveler1Birthday = this.txtTraveler1Birthday.Value.Trim();
            string m_Traveler1PassportNo = this.txtTraveler1PassportNo.Value.Trim();
            string m_Traveler1Tel = this.txtTraveler1Tel.Value.Trim();
            bool chkTraveler1Hier = this.chkTraveler1BeneficialyHeir.Checked;

            msg = "";
            flagmsg = false;
            if (m_Traveler1ClientName == string.Empty)
            {
                msg += "Name |";
                flagmsg = true;
                this.txtTraveler1Name.Attributes["class"] = "inputFocusError";
            }
            if (m_Traveler1ClientSurName == string.Empty)
            {
                msg += "Family name |";
                flagmsg = true;
                this.txtTraveler1Surname.Attributes["class"] = "inputFocusError";
            }
            if (m_Traveler1Birthday == string.Empty)
            {
                msg += "Birthday |";
                flagmsg = true;
                this.txtTraveler1Birthday.Attributes["class"] = "inputFocusError";
            }

            if (m_Traveler1PassportNo == string.Empty)
            {
                msg += "Passport No |";
                flagmsg = true;
                this.txtTraveler1PassportNo.Attributes["class"] = "inputFocusError";
            }
            if (m_Traveler1Tel == string.Empty)
            {
                msg += "Tel |";
                flagmsg = true;
                this.txtTraveler1Tel.Attributes["class"] = "inputFocusError";
            }
            //CHECK BENEFICIARY
            if (chkTraveler1Hier == false)
            {
                if (string.IsNullOrEmpty(txtTraveler1BeneficialyName1.Value.Trim()) || string.IsNullOrEmpty(txtTraveler1BeneficialySurname1.Value.Trim()))
                {
                    msg += "Beneficiary Name and Family name | ";
                    flagmsg = true;
                    this.txtTraveler1BeneficialyName1.Attributes["class"] = "inputFocusError";
                }
            }
            //END CHECK
            if (flagmsg)
            {
                this.lblErrorMessage.Text = msg + " on Traveler 1 ห้ามเป็นค่าว่าง";
                this.lblInformMessage.Text = "";
                return;
            }


            //DEFAULT EFFECTTIVE DATE FROM
            dt2 = Convert.ToDateTime(m_EffectiveDateFrom);

            //CHECK BIRTHDAY ON TRAVELER 1
            //string m_traveler1_birthday = this.txtTraveler1Birthday.Value.Trim();
            string m_traveler1_birthday = this.txtTraveler1Birthday.Value.Trim().Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtTraveler1Birthday.Value.Trim()); //30/05/2012 to 2012-05-30;
            if (!m_traveler1_birthday.Equals(string.Empty))
            {
                dt1 = Convert.ToDateTime(m_traveler1_birthday);
                //ret = this.IsBirthDayOverLimitOfEffectiveDate(1, 70, Convert.ToDateTime(dt1), Convert.ToDateTime(dt2));
                //ret = this.IsBirthDayOverLimitOfEffectiveDate(1, 70, dt1, dt2);
                ret = this.IsBirthDayOverLimitOfEffectiveDate(m_AgeOfTravelerFrom, m_AgeOfTravelerTo, dt1, dt2);
                if (ret)
                {
                    //this.lblErrorMessage.Text = "Birthday on Traveler 1 ไม่อยู่ในช่วง 1-70 ปี นับจากวันที่เดินทาง";
                    //this.lblErrorMessage.Text = "กรุณาติดต่อ บริษัท เนื่องจากอายุผู้เดินทางเกิน 70ปี / Please contact AXA helpdesk as age is over 70 ";
                    this.lblErrorMessage.Text = "กรุณาติดต่อ บริษัท เนื่องจากอายุผู้เดินทางเกิน " + m_AgeOfTravelerTo + "ปี / Please contact AXA helpdesk as age is over " + m_AgeOfTravelerTo;

                    this.lblInformMessage.Text = "";
                    return;
                }
            }
            else
            {
                this.lblErrorMessage.Text = "Birthday on Traveler 1 | ห้ามเป็นค่าว่าง";
                this.lblInformMessage.Text = "";
                return;
            }

            //VALIDATE RATIO IS 100 ON TRAVELER1
            int traveler1Ratio1 = 0;
            int traveler1Ratio2 = 0;
            int traveler1Ratio3 = 0;

            if (chkTraveler1Hier == false)
            {
                if (!string.IsNullOrEmpty(txtTraveler1BeneficialyName1.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler1BeneficialySurname1.Value.Trim()))
                {
                    traveler1Ratio1 = txtTraveler1BeneficialyRatio1.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler1BeneficialyRatio1.Value.Trim());
                }

                if (!string.IsNullOrEmpty(txtTraveler1BeneficialyName2.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler1BeneficialySurname2.Value.Trim()))
                {
                    traveler1Ratio2 = txtTraveler1BeneficialyRatio2.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler1BeneficialyRatio2.Value.Trim());
                }

                if (!string.IsNullOrEmpty(txtTraveler1BeneficialyName3.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler1BeneficialySurname3.Value.Trim()))
                {
                    traveler1Ratio3 = txtTraveler1BeneficialyRatio3.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler1BeneficialyRatio3.Value.Trim());
                }

                if (traveler1Ratio1 + traveler1Ratio2 + traveler1Ratio3 != 100)
                {
                    this.lblErrorMessage.Text = "Sum of Beneficiary Ratio on Traveler1 Must be 100!!! ";
                    this.lblInformMessage.Text = "";
                    return;
                }
            }

            //END VALIDATE

            //-------------------------------------------------------------------------------------------------------------
            if (m_PolicyType == TA.TAUtilities.PolicyType.Family.ToString())
            {
                //CHECK TRAVER 2
                string m_Traveler2ClientName = this.txtTraveler2Name.Value.Trim();
                string m_Traveler2ClientSurName = this.txtTraveler2Surname.Value.Trim();
                string m_Traveler2Birthday = this.txtTraveler2Birthday.Value.Trim();
                string m_Traveler2PassportNo = this.txtTraveler2PassportNo.Value.Trim();
                string m_Traveler2Tel = this.txtTraveler2Tel.Value.Trim();
                bool chkTraveler2Hier = this.chkTraveler2BeneficialyHeir.Checked;

                msg = "";
                flagmsg = false;
                if (m_Traveler2ClientName == string.Empty)
                {
                    msg += "Name |";
                    flagmsg = true;
                    this.txtTraveler2Name.Attributes["class"] = "inputFocusError";
                }
                if (m_Traveler2ClientSurName == string.Empty)
                {
                    msg += "Family name |";
                    flagmsg = true;
                    this.txtTraveler2Surname.Attributes["class"] = "inputFocusError";
                }
                if (m_Traveler2Birthday == string.Empty)
                {
                    msg += "Birthday |";
                    flagmsg = true;
                    this.txtTraveler2Birthday.Attributes["class"] = "inputFocusError";
                }

                if (m_Traveler2PassportNo == string.Empty)
                {
                    msg += "Passport No |";
                    flagmsg = true;
                    this.txtTraveler2PassportNo.Attributes["class"] = "inputFocusError";
                }
                if (m_Traveler2Tel == string.Empty)
                {
                    msg += "Tel |";
                    flagmsg = true;
                    this.txtTraveler2Tel.Attributes["class"] = "inputFocusError";
                }
                //CHECK BENEFICIARY
                if (chkTraveler2Hier == false)
                {
                    if (string.IsNullOrEmpty(txtTraveler2BeneficialyName1.Value.Trim()) || string.IsNullOrEmpty(txtTraveler2BeneficialySurname1.Value.Trim()))
                    {
                        msg += "Beneficiary Name and Family name | ";
                        flagmsg = true;
                        this.txtTraveler2BeneficialyName1.Attributes["class"] = "inputFocusError";
                    }
                }
                //END CHECK
                if (flagmsg)
                {
                    this.lblErrorMessage.Text = msg + " on Traveler 2 ห้ามเป็นค่าว่าง";
                    this.lblInformMessage.Text = "";
                    return;
                }
                //CHECK BIRTHDAY ON TRAVELER 2
                //string m_traveler2_birthday = this.txtTraveler2Birthday.Value.Trim();
                string m_traveler2_birthday = this.txtTraveler2Birthday.Value.Trim().Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtTraveler2Birthday.Value.Trim()); //30/05/2012 to 2012-05-30;
                if (!m_traveler2_birthday.Equals(string.Empty))
                {
                    dt1 = Convert.ToDateTime(m_traveler2_birthday);
                    //ret = this.IsBirthDayOverLimitOfEffectiveDate(1, 70, Convert.ToDateTime(dt1), Convert.ToDateTime(dt2));
                    //ret = this.IsBirthDayOverLimitOfEffectiveDate(1, 70, dt1, dt2);
                    ret = this.IsBirthDayOverLimitOfEffectiveDate(m_AgeOfTravelerFrom, m_AgeOfTravelerTo, dt1, dt2);

                    if (ret)
                    {
                        //this.lblErrorMessage.Text = "Birthday on Traveler 2 ไม่อยู่ในช่วง 1-70 ปี นับจากวันที่เดินทาง";
                        //this.lblErrorMessage.Text = "กรุณาติดต่อ บริษัท เนื่องจากอายุผู้เดินทางเกิน 70ปี / Please contact AXA helpdesk as age is over 70 ";
                        this.lblErrorMessage.Text = "กรุณาติดต่อ บริษัท เนื่องจากอายุผู้เดินทางเกิน " + m_AgeOfTravelerTo + "ปี / Please contact AXA helpdesk as age is over " + m_AgeOfTravelerTo;

                        this.lblInformMessage.Text = "";
                        return;
                    }
                }
                else
                {
                    this.lblErrorMessage.Text = "Birthday on Traveler 2 | ห้ามเป็นค่าว่าง";
                    this.lblInformMessage.Text = "";
                    return;
                }

                //VALIDATE RATIO IS 100 ON TRAVELER1
                int traveler2Ratio1 = 0;
                int traveler2Ratio2 = 0;
                int traveler2Ratio3 = 0;

                if (chkTraveler2Hier == false)
                {
                    if (!string.IsNullOrEmpty(txtTraveler2BeneficialyName1.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler2BeneficialySurname1.Value.Trim()))
                    {
                        traveler2Ratio1 = txtTraveler2BeneficialyRatio1.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler2BeneficialyRatio1.Value.Trim());
                    }

                    if (!string.IsNullOrEmpty(txtTraveler2BeneficialyName2.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler2BeneficialySurname2.Value.Trim()))
                    {
                        traveler2Ratio2 = txtTraveler2BeneficialyRatio2.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler2BeneficialyRatio2.Value.Trim());
                    }

                    if (!string.IsNullOrEmpty(txtTraveler1BeneficialyName3.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler1BeneficialySurname3.Value.Trim()))
                    {
                        traveler2Ratio3 = txtTraveler2BeneficialyRatio3.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler2BeneficialyRatio3.Value.Trim());
                    }

                    if (traveler2Ratio1 + traveler2Ratio2 + traveler2Ratio3 != 100)
                    {
                        this.lblErrorMessage.Text = "Sum of Beneficiary Ratio on Traveler2 Must be 100!!! ";
                        this.lblInformMessage.Text = "";
                        return;
                    }
                }

                //END VALIDATE


                //CHECK CHILD (1,2) 
                int m_allpeople = (int)m_NumbersOfChildren + 2;
                //string m_msgofchild = "";
                //bool m_flagmsg = false;
                if (m_allpeople > 2)
                {
                    //CHECK CHILD 
                    for (int ch = 3; ch <= m_allpeople; ch++)
                    {

                        //CHECK EMPTY ON TRAVELER 3 UP -----
                        string id_clientname = "ctl00$MainContent$txtTraveler" + ch + "Name";
                        string m_TravelerChildClientName = Request.Form[id_clientname].Trim();
                        string id_clientsurname = "ctl00$MainContent$txtTraveler" + ch + "SurName";
                        string m_TravelerChildClientSurName = Request.Form[id_clientsurname].Trim();
                        string id_birthday = "ctl00$MainContent$txtTraveler" + ch + "Birthday";
                        string m_TravelerChildBirthday = Request.Form[id_birthday].Trim();
                        string id_passportid = "ctl00$MainContent$txtTraveler" + ch + "PassportNo";
                        string m_TravelerChildPassportID = Request.Form[id_passportid];
                        string id_tel = "ctl00$MainContent$txtTraveler" + ch + "Tel";
                        string m_TravelerChildTel = Request.Form[id_tel];

                        msg = "";
                        flagmsg = false;
                        if (m_TravelerChildClientName == string.Empty)
                        {
                            msg += "Name |";
                            flagmsg = true;
                        }
                        if (m_TravelerChildClientSurName == string.Empty)
                        {
                            msg += "Family name |";
                            flagmsg = true;
                        }
                        if (m_TravelerChildBirthday == string.Empty)
                        {
                            msg += "Birthday |";
                            flagmsg = true;
                        }
                        if (m_TravelerChildPassportID == string.Empty)
                        {
                            msg += "Passport No |";
                            flagmsg = true;
                        }
                        if (m_TravelerChildTel == string.Empty)
                        {
                            msg += "Tel |";
                            flagmsg = true;
                        }

                        //CHECK BENEFICIARY
                        string m_BeneficiaryName = "";
                        string m_BeneficiarySurName = "";
                        string id_BeneficiaryName = "ctl00$MainContent$txtTraveler" + ch + "BeneficialyName1";
                        m_BeneficiaryName = Request.Form[id_BeneficiaryName];
                        string id_BeneficiarySurName = "ctl00$MainContent$txtTraveler" + ch + "BeneficialySurname1";
                        m_BeneficiarySurName = Request.Form[id_BeneficiarySurName];
                        string id_BeneficiaryHier = "ctl00$MainContent$chkTraveler" + ch + "BeneficialyHeir";
                        string m_BeneficiaryHier = Request.Form[id_BeneficiaryHier];
                        if (m_BeneficiaryHier == "on")
                        {

                        }
                        else
                        {
                            if (string.IsNullOrEmpty(m_BeneficiaryName) && string.IsNullOrEmpty(m_BeneficiarySurName))
                            {
                                msg += "Name and Family name |";
                                flagmsg = true;
                            }
                        }
                        //END CHECK

                        if (flagmsg)
                        {
                            msg += " on Traveler " + ch + " ห้ามเป็นค่าว่าง";
                            break;
                        }

                        //CHECK BIRTHDAY ON TRAVELER 3 UP -----
                        msg = "";
                        flagmsg = false;
                        if (!string.IsNullOrEmpty(Request.Form[id_birthday]))
                        {
                            string m_travelerchild_birthday = TA.TAUtilities.ConvertDateFieldToDB(Request.Form[id_birthday]);
                            dt1 = Convert.ToDateTime(m_travelerchild_birthday);
                            ret = this.IsBirthDayOverLimitOfEffectiveDate(1, 21, dt1, dt2);
                            if (ret)
                            {
                                msg += "Traveler " + ch + " Birthday ไม่อยู่ในช่วง 1-21 ปี นับจากวันที่เดินทาง | <br>";
                                flagmsg = true;
                                break;
                            }
                            else
                            {
                                //1-21
                                dt1 = Convert.ToDateTime(m_travelerchild_birthday);
                                ret = this.IsBirthDayOverLimitOfEffectiveDate(1, 18, dt1, dt2);
                                if (ret)
                                {
                                    string id_isStudent = "ctl00$MainContent$chkTraveler" + ch + "Occupation";
                                    int m_isStudent = 0;
                                    if (!string.IsNullOrEmpty(Request.Form[id_isStudent]))
                                    {
                                        m_isStudent = 1; //on = true = selected
                                    }
                                    string id_isSingle = "ctl00$MainContent$chkTraveler" + ch + "Status";
                                    int m_isSingle = 0;
                                    if (!string.IsNullOrEmpty(Request.Form[id_isSingle]))
                                    {
                                        m_isSingle = 1;
                                    }
                                    if (m_isStudent == 0 || m_isSingle == 0)
                                    {
                                        msg += "Traveler " + ch + " Birthday ไม่อยู่ในช่วง 1-18 ปี นับจากวันที่เดินทาง ไม่เป็นนักศึกษาและสถานะภาพไม่โสด | <br>";
                                        flagmsg = true;
                                        break;
                                    }
                                }
                            }
                        }

                        //VALIDATE RATIO IS 100 ON TRAVELER1
                        int travelerxRatio = 0;

                        for (int j = 1; j < 4; j++)
                        {

                            string msub_BeneficiaryName = "";
                            string msub_BeneficiarySurName = "";
                            string msub_BeneficiaryRatio = "";

                            string idsub_BeneficiaryName = "ctl00$MainContent$txtTraveler" + ch + "BeneficialyName" + j.ToString();
                            msub_BeneficiaryName = Request.Form[idsub_BeneficiaryName];

                            string idsub_BeneficiarySurName = "ctl00$MainContent$txtTraveler" + ch + "BeneficialySurname" + j.ToString();
                            msub_BeneficiarySurName = Request.Form[idsub_BeneficiarySurName];

                            string idsub_BeneficiaryRatio = "ctl00$MainContent$txtTraveler" + ch + "BeneficialyRatio" + j.ToString();
                            msub_BeneficiaryRatio = Request.Form[idsub_BeneficiaryRatio];

                            if (m_BeneficiaryHier == "on")
                            {

                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(msub_BeneficiaryName) && !string.IsNullOrEmpty(msub_BeneficiarySurName))
                                {
                                    travelerxRatio += msub_BeneficiaryRatio.Equals(string.Empty) ? 0 : Convert.ToInt32(msub_BeneficiaryRatio.Trim());
                                }
                            }
                        }

                        if (travelerxRatio != 100 && m_BeneficiaryHier != "on")
                        {
                            this.lblErrorMessage.Text = "Sum of Beneficiary Ratio on Traveler " + ch + " Must be 100!!! ";
                            this.lblInformMessage.Text = "";
                            return;
                        }
                        //END VALIDATE
                    }
                    if (flagmsg)
                    {
                        this.lblErrorMessage.Text = msg;
                        this.lblInformMessage.Text = "";
                        return;
                    }
                }
            }

            //
            //VARIABLE LONGNAME-------------------------------------------------------------------------------------------------------------
            //string m_JobNo = "";
            string m_LongName1 = this.txtLongName1.Value.Trim();
            string m_LongName2 = this.txtLongName2.Value.Trim();
            //string m_LongName3 = this.txtLongName3.Value.Trim();
            //string m_LongName4 = this.txtLongName4.Value.Trim();
            string m_temp = string.Concat(m_LongName1, m_LongName2);
            if (m_temp != string.Empty)
            {
                m_isLongName = 1;
            }

            #endregion

            //SET TA POLICY ALL PROCESS 
            string planID = this.ddlInsurancePlan.SelectedValue;
            string travelPlanType = this.rdoTravelPlan.SelectedValue.Trim();
            int duration = 0;

            if (!string.IsNullOrEmpty(this.txtDuration.Value.Trim()))
                duration = Convert.ToInt32(this.txtDuration.Value.Trim());

            TAPlanPremuimBLL planpremium = new TAPlanPremuimBLL();
            TAPremuim premium = planpremium.GetTAPremuim(planID, duration, travelPlanType);
            double m_d_netpremium = double.Parse(premium.NetPremium.Trim());
            double m_d_tax = double.Parse(premium.TAX.Trim());
            double m_d_stamp = double.Parse(premium.Stamp.Trim());
            double m_d_total = double.Parse(premium.Total.Trim());

            #region "GET/SET JOB NUMBER (NOW NONE TRANSACTION)"
            //GET/SET JOB NUMBER
            //string m_JobNo = "AXA-TA-20120500007";
            TAJobRunningBLL clsjobrunning = new TAJobRunningBLL();
            if (string.Compare(qry_mode.Trim(), "edit") == 0)
            {
                qry_mode = Request.QueryString["mode"];
                qry_jobno = Request.QueryString["JobNo"];
            }

            if (!string.IsNullOrEmpty(qry_mode) && !string.IsNullOrEmpty(qry_jobno))
            {
                if (string.Compare(qry_mode.Trim(), "edit") == 0)
                {
                    m_JobNo = qry_jobno.Trim();
                }
                else
                {
                    m_JobNo = clsjobrunning.GetTAJobRunningNumber();

                    if (string.IsNullOrEmpty(m_JobNo))
                    {
                        throw new Exception("เกิดข้อผิดพลาดในการสร้างหมายเลข Job Number กรุณาทดลองบันทึกงานอีกครั้งหรือติดต่อผู้ดูแลระบบ");
                    }
                }
            }
            else
            {
                m_JobNo = clsjobrunning.GetTAJobRunningNumber();

                if (string.IsNullOrEmpty(m_JobNo))
                {
                    throw new Exception("เกิดข้อผิดพลาดในการสร้างหมายเลข Job Number กรุณาทดลองบันทึกงานอีกครั้งหรือติดต่อผู้ดูแลระบบ");
                }
            }
            
            //m_JobNo = clsjobrunning.GetTAJobRunningNumber();
            //if (string.IsNullOrEmpty(m_JobNo))
            //{
            //    throw new Exception("เกิดข้อผิดพลาดในการสร้างหมายเลข Job Number กรุณาทดลองบันทึกงานอีกครั้งหรือติดต่อผู้ดูแลระบบ");
            //}
            #endregion

            #region "OPEN DB"
            //OPEN DB
            DbProviderHelper.OpenDb();
            #endregion

            #region "OPEN TRANSACTION"
            //TRANSACTION BEGIN
            dbTransaction = DbProviderHelper.BeginTransaction();
            #endregion

            #region "#1-INSERT/UPDATE TRANSPOLICY"
            //#1-INSERT/UPDATE TRANSPOLICY

            TATransPolicyBLL clstranspolicy = new TATransPolicyBLL();
            //clstranspolicy.SetTATransPolicy("AXA-TA-20120500001", "", "Annual", "Individual", 0, "0001", "2012-05-23", "2013-05-23", "TH", "", "", 0, 0, 0, 0, 0, 0, "", "BA347", dbTransaction);

            string ip = System.Web.HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (string.IsNullOrEmpty(ip))
            {
                ip = System.Web.HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
            }
            clstranspolicy.SetTATransPolicy(m_JobNo, m_PolicyNo, m_TravelPlan, m_PolicyType, m_NumbersOfChildren, m_PlanID, m_EffectiveDateFrom, m_EffectiveDateTo, m_CountryOfDestination, m_ContryOther, m_AgentCode, m_OccupatnCode, m_NetPremium, m_Stamp, m_SBT, m_TotalPremium, m_isLongName, m_isBeneficiary, m_CreateUser, m_GroupBrokerID, ip, dbTransaction);

            #endregion

            #region "#2-INSERT/UPDATE TRANSCOVERAGE"
            //#2-INSERT/UPDATE TRANSCOVERAGE
            //VARIABLE
            //string m_JobNo = "";
            float m_PersonalAccident = (float)Utilities.ExactNumber(this.lblPersonalAccidentValue.Text.Trim());
            string m_PlanId = this.ddlInsurancePlan.SelectedValue.Trim();

            TATransCoverageBLL clstranscoverage = new TATransCoverageBLL();
            //clstranscoverage.SetTATransCoverage("AXA-TA-20120500001", (float)1000000, "0001", dbTransaction);
            clstranscoverage.SetTATransCoverage(m_JobNo, m_PersonalAccident, m_PlanId, dbTransaction);
            #endregion

            #region "#3-INSERT/UPDATE TRANSPOLICYHOLDER"
            //#3-INSERT/UPDATE TRANSPOLICYHOLDER
            policyholdertype = ""; //CHECK POLICY HOLDER TYPE
            foreach (ListItem item in rdoTaxInvoiceType.Items)
            {
                if (item.Selected == true)
                {
                    policyholdertype = item.Value.Trim();  //Private ,Commercial
                }
            }
            TATransPolicyHolderBLL clstranspolicyholder = new TATransPolicyHolderBLL();
            if (policyholdertype == "Private")
            {
                //Private
                m_ClientType = "P";
                clstranspolicyholder.SetTATransPolicyHolder(m_JobNo, m_ClientType, m_ClientTitle, m_ClientName, m_ClientSurName, m_ClientAddress1, m_ClientAddress2, m_Province, m_Amphur, m_Tumbol, m_Postcode, m_Birthday, m_IdCard, m_Tel, m_Email, m_Language, m_BranchNo, dbTransaction);
            }
            else
            {
                //Commercial
                m_ClientType = "C";
                clstranspolicyholder.SetTATransPolicyHolder(m_JobNo, m_ClientType, "", m_ClientName, m_ClientSurName, m_ClientAddress1, m_ClientAddress2, m_Province, m_Amphur, m_Tumbol, m_Postcode, "", m_IdCard, m_Tel, m_Email, m_Language, m_BranchNo, dbTransaction);
            }

            #endregion

            #region "#4-INSERT/UPDATE TRANSTRAVELER"
            //#4-INSERT/UPDATE TRANSTRAVELER
            //VARIABLE            
            int numberofchid = int.Parse(this.txtNumberOfChilden.Text.Trim());

            if (numberofchid == 0 && m_PolicyType == "Individual")
                numberofchid = -1;

            for (int c = 1; c <= (numberofchid + 2); c++)
            {
                //string m_JobNo = "";
                int m_TravelerId = c;
                //string m_ClientTitle = "";
                //string m_ClientName  = "";
                //string m_ClientSurName  = "";
                //string m_Birthday = null;
                string m_PassportID = "";
                Nullable<sbyte> m_isStudent = null;
                Nullable<sbyte> m_isSingle = null;
                //string m_Tel  = "";

                string id_title = "ctl00$MainContent$ddlTraveler" + c + "Title";     //ctl00$MainContent$ddlTraveler1Title
                m_ClientTitle = Request.Form[id_title];                             //Values
                string id_clientname = "ctl00$MainContent$txtTraveler" + c + "Name";
                m_ClientName = Request.Form[id_clientname];
                string id_clientsurname = "ctl00$MainContent$txtTraveler" + c + "SurName";
                m_ClientSurName = Request.Form[id_clientsurname];
                string id_birthday = "ctl00$MainContent$txtTraveler" + c + "Birthday";
                m_Birthday = "";
                if (!string.IsNullOrEmpty(Request.Form[id_birthday]))
                {
                    //m_Birthday = TA.TAUtilities.ConvertDateFieldToDB(m_Birthday);
                    m_Birthday = TA.TAUtilities.ConvertDateFieldToDB(Request.Form[id_birthday]);
                }
                string id_passportid = "ctl00$MainContent$txtTraveler" + c + "PassportNo";
                m_PassportID = Request.Form[id_passportid];
                string id_isStudent = "ctl00$MainContent$chkTraveler" + c + "Occupation";
                m_isStudent = 0;
                if (!string.IsNullOrEmpty(Request.Form[id_isStudent]))
                {
                    m_isStudent = 1; //on = true = selected
                }
                string id_isSingle = "ctl00$MainContent$chkTraveler" + c + "Status";
                m_isSingle = 0;
                if (!string.IsNullOrEmpty(Request.Form[id_isSingle]))
                {
                    m_isSingle = 1; //on = true = selected
                }
                string id_tel = "ctl00$MainContent$txtTraveler" + c + "Tel";
                m_Tel = Request.Form[id_tel];

                //กรณี Family ลูก ๆ จะได้รับ PA คุ้มครอง 50% 2012-06-05
                float travelerPA = 0;
                if (m_TravelerId > 2)
                    travelerPA = m_PersonalAccident / 2;
                else
                    travelerPA = m_PersonalAccident;

                //Process Get Each Traveler Net Premium , Tax , Stamp , Total Premium 2012-06-05
                Nullable<decimal> travelerNetPremium = null;
                Nullable<int> travelerStamp = null;
                Nullable<int> travelerSBT = null;
                Nullable<decimal> travelerTotalPremium = null;

                if (m_TravelerId > 2)
                {
                    if (m_TravelerId > 4)
                    {
                        travelerNetPremium = (decimal)m_d_netpremium / 2;
                        travelerStamp = (int)m_d_stamp / 2;
                        travelerSBT = (int)m_d_tax / 2;
                        travelerTotalPremium = (decimal)m_d_total / 2;
                    }
                    else
                    {
                        travelerNetPremium = 0;
                        travelerStamp = 0;
                        travelerSBT = 0;
                        travelerTotalPremium = 0;
                    }
                }
                else
                {
                    travelerNetPremium = (decimal)m_d_netpremium;
                    travelerStamp = (int)m_d_stamp;
                    travelerSBT = (int)m_d_tax;
                    travelerTotalPremium = (decimal)m_d_total;
                }
                //End 

                //EXEC PROCEDURE
                TATransTravelerBLL clstranstraveler = new TATransTravelerBLL();
                //clstranstraveler.SetTATransTraveler(m_JobNo, m_TravelerId, m_ClientTitle, m_ClientName, m_ClientSurName, m_Birthday, m_PassportID, m_Tel, m_isStudent, m_isSingle, null, dbTransaction);
                clstranstraveler.SetTATransTraveler(m_JobNo, m_TravelerId, m_ClientTitle, m_ClientName, m_ClientSurName, m_Birthday, m_PassportID, m_Tel, m_isStudent, m_isSingle, Convert.ToDecimal(travelerPA), travelerNetPremium, travelerStamp, travelerSBT, travelerTotalPremium, null, dbTransaction);

                #region "#5-INSERT/UPDATE TRANSBENEFICIARY"
                //#5-INSERT/UPDATE TRANSBENEFICIARY

                for (int j = 1; j < 4; j++)
                {
                    //string m_JobNo = "";
                    int m_TravelerID = c;
                    int m_Seq = j;
                    string m_BeneficiaryTitle = "";
                    string m_BeneficiaryName = "";
                    string m_BeneficiarySurName = "";
                    string m_BeneficiaryRelation = "";
                    string m_BeneficiaryRatio = "";
                    string m_BeneficiaryTel = "";

                    string id_BeneficiaryTitle = "ctl00$MainContent$ddlTraveler" + c + "BeneficialyTitle" + j.ToString();
                    m_BeneficiaryTitle = Request.Form[id_BeneficiaryTitle];

                    string id_BeneficiaryName = "ctl00$MainContent$txtTraveler" + c + "BeneficialyName" + j.ToString();
                    m_BeneficiaryName = Request.Form[id_BeneficiaryName];

                    string id_BeneficiarySurName = "ctl00$MainContent$txtTraveler" + c + "BeneficialySurname" + j.ToString();
                    m_BeneficiarySurName = Request.Form[id_BeneficiarySurName];

                    string id_BeneficiaryRelation = "ctl00$MainContent$ddlTraveler" + c + "BeneficialyRelationShip" + j.ToString();
                    m_BeneficiaryRelation = Request.Form[id_BeneficiaryRelation];

                    string id_BeneficiaryRatio = "ctl00$MainContent$txtTraveler" + c + "BeneficialyRatio" + j.ToString();
                    m_BeneficiaryRatio = Request.Form[id_BeneficiaryRatio];

                    string id_BeneficiaryTel = "ctl00$MainContent$txtTraveler" + c + "BeneficialyTel" + j.ToString();
                    m_BeneficiaryTel = Request.Form[id_BeneficiaryTel];

                    string id_BeneficiaryHier = "ctl00$MainContent$chkTraveler" + c + "BeneficialyHeir";
                    string m_BeneficiaryHier = Request.Form[id_BeneficiaryHier];
                    if (m_BeneficiaryHier == "on")
                    {

                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(m_BeneficiaryName) && !string.IsNullOrEmpty(m_BeneficiarySurName))
                        {
                            TATransBeneficiaryBLL clstransbeneficiary = new TATransBeneficiaryBLL();
                            clstransbeneficiary.SetTATransBeneficiary(m_JobNo, c, j, m_BeneficiaryTitle, m_BeneficiaryName, m_BeneficiarySurName, m_BeneficiaryRelation, m_BeneficiaryRatio, m_BeneficiaryTel, dbTransaction);
                        }
                    }
                }

                #endregion

            }
            #endregion

            #region "#6-INSERT/UPDATE TRANSLONGNAME"
            //#6-INSERT/UPDATE TRANSLONGNAME
            if (m_temp != string.Empty)
            {
                TATransLongNameBLL clstranslongname = new TATransLongNameBLL();
                clstranslongname.SetTATransLongName(m_JobNo, m_LongName1, m_LongName2, dbTransaction);
            }

            #endregion

            #region "COMMIT DB"
            //COMMIT DB
            //DbProviderHelper.CommitTransaction(dbTransaction);

            
            #endregion

            #region "CLOSE DB"
            //CLOSE DB
            DbProviderHelper.CloseDb();
            dbTransaction.Dispose();
            dbTransaction = null;

            #endregion
            ckEx = "1";
        }
        catch (Exception ex)
        {
            //Utilities.LogError(ex);
            if (dbTransaction != null)
            {
                #region "ROLLBACK DB"
                //ROLLBACK DB
                DbProviderHelper.RollbackTransaction(dbTransaction);
                #endregion

                #region "CLOSE DB"
                //CLOSE DB
                DbProviderHelper.CloseDb();
                #endregion
            }
            ckEx = "0";
            this.lblErrorMessage.Text = ex.Message.ToString();
            this.lblInformMessage.Text = "";
        }
            
            #region "ISSUED TA POLICY"

            //string m_GroupBrokerID = Utilities.GetGroupBrokerID();
            //string m_AgentCode = Utilities.BrokerCode();
            //string m_CreateUser = m_UserWeb;
            //Bind Job no
            //string m_JobNo = "AXA-TA-20120700004";
            //this.lblJobnoValue.Text = m_JobNo;

            //Bind Message
        if (ckEx == "1")
        {
            string msgOut = string.Empty;
            string msgStatus = string.Empty;
            string out_PolicyNo = string.Empty;
            string tempUserHostName = "";
            string tempUserHostPassword = "";
            try
            {    

                if (Session["UserHostName"].ToString().Substring(0, 2) == "QL")
                {
                    tempUserHostName = "QLAPP"; tempUserHostPassword = Session["UserHostPassword"].ToString().Trim();
                }
                else { tempUserHostName = "QAAPP"; tempUserHostPassword = Session["UserHostPassword"].ToString().Trim(); }
                this.lblErrorMessage.Text = "";
                this.lblInformMessage.Text = "บันทึกข้อมูลลงฐานข้อมูลเรียบร้อย";

                #region Call Web Service New Client


                string msgOutMessageStatus = string.Empty;
                string msgOutClient = string.Empty;
                string msgOutSession = string.Empty;
                QuickLinkTravelService wsQuickLinkTAClient = new QuickLinkTravelService();
                msgOutMessageStatus = wsQuickLinkTAClient.SetNewTAClients(m_JobNo, out msgOutClient, out msgOutSession);

                if (string.Compare(msgOutMessageStatus, "SUCCESS") != 0)
                {
                    throw new System.ArgumentException("Create New TA Clients Error : " + msgOutClient);
                }
               #endregion

                    #region Call Web Services to Issued TA Policy.
      
                    QuickLinkTravelService wsQuickLinkTAIssue = new QuickLinkTravelService();
                    out_PolicyNo = wsQuickLinkTAIssue.SetNewTAPolicy(m_JobNo, tempUserHostName, tempUserHostPassword, out msgOut, out msgStatus);

                    if (string.Compare(msgStatus, "SUCCESS") != 0)
                    {
                        throw new System.ArgumentException("Create New TA Policy Error : " + msgOut); 
                    }  
                    #endregion
     

                        #region Call Method SetTransTaxInvoince.
                        TATransPolicyBLL SetTransTaxInvoince = new TATransPolicyBLL();
                        SetTransTaxInvoince.SetTATransTaxInvoince(out_PolicyNo, m_JobNo, m_UserWeb, "0");
                        #endregion
       
                        #region Call Web Services getTADocument
                        WSQuickLinkTAReport.Box_Document[] BoxDocument = new Box_Document[1];

                        WSQuickLinkTAReport.Box_Message[] BoxMessage;

                        WSQuickLinkTAReport.TADocumentService getTADocument = new WSQuickLinkTAReport.TADocumentService();

                        Box_Document BoxDocuemtDetail = new Box_Document();
                        BoxDocuemtDetail.PolicyNo = out_PolicyNo;
                        BoxDocuemtDetail.Document = "RTHSBTDR";
                        BoxDocuemtDetail.Flag = true;

                        BoxDocument[0] = BoxDocuemtDetail;



                        BoxMessage = getTADocument.getTADocument(BoxDocument, tempUserHostName, tempUserHostPassword);

                        if (BoxMessage.Length < 1)
                        {
                            throw new System.ArgumentException("Issued Success,Policy No : " + out_PolicyNo + ",But have some problem in Tax Invoice Process.");

                        }
                        else
                        {
                            if (BoxMessage[0].Success != "true")
                            {
                                //throw new System.ArgumentException(BoxMessage[0].Error);
                                throw new System.ArgumentException("Issued Success,Policy No : " + out_PolicyNo + ",But have some problem in Tax Invoice Process.");
                            }
                            else
                            {                        
                                #region Call Method SetTranPrint.
                                    TATransPolicyBLL SetTranPrint = new TATransPolicyBLL();
                                    SetTransTaxInvoince.SetTATransPrint(out_PolicyNo, m_JobNo, "", m_AgentCode, m_GroupBrokerID, m_CreateUser);
                                    this.lblErrorMessage.Text = "";
                                #endregion
                                    
                                
                            }
                        }
                        #endregion
            }
            catch (Exception ex)
            {
                this.lblErrorMessage.Text = ex.Message.ToString();
                this.lblInformMessage.Text = "";
            }
            #endregion
            if (out_PolicyNo.Length != 0 & this.lblErrorMessage.Text=="")
            {
                Response.Redirect("TAPrintPolicy.aspx?policyno=" + out_PolicyNo + "&endtno=0");
            }
        }
    }
    protected void btnSaveDraft_ServerClick(object sender, EventArgs e)
    {
        DbTransaction dbTransaction = null;
        try
        {

            #region "GET USER HOST AND WEB"
            string m_UserWeb = Utilities.GetUsername().Trim();
            //UserHostDetails m_User = UserMember.GetUserHost(m_UserWeb);
            //string m_Username = m_User.UserHostName.ToString();
            //string m_Password = m_User.UserHostPassword.ToString();
            #endregion

            #region "VALIDATE VARIABLE ISSUED POLICY"
            //BEGIN VARIABLE-TRANSPOLICY
            //string m_JobNo = "";                           
            string m_PolicyNo = "";
            string m_TravelPlan = "";
            foreach (ListItem item in rdoTravelPlan.Items)
            {
                if (item.Selected)
                {
                    m_TravelPlan = item.Value.Trim();
                }
            }
            string m_PolicyType = "";
            foreach (ListItem item in rdoPolicyType.Items)
            {
                if (item.Selected)
                {
                    m_PolicyType = item.Value.Trim();
                }
            }

            Nullable<int> m_NumbersOfChildren = int.Parse(this.txtNumberOfChilden.Text.Trim()); ;

            string m_PlanID = this.ddlInsurancePlan.SelectedValue.Trim();
            string m_EffectiveDateFrom = this.txtEffectiveDateFrom.Text.Trim().Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtEffectiveDateFrom.Text.Trim());
            string m_EffectiveDateTo = this.txtEffectiveDateTo.Text.Trim().Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtEffectiveDateTo.Text.Trim());
            string m_CountryOfDestination = this.ddlCountryOfDestination.SelectedItem.Text.Trim();  //Our customer need to change value to text name ,chage date 2012-06-09
            string m_ContryOther = this.txtCountryOfDestinationOther.Value.Trim();
            string m_AgentCode = Utilities.BrokerCode(); //;this.ddlIntermediary.SelectedValue;
            string m_OccupatnCode = "";
            Nullable<decimal> m_NetPremium = null;
            if (this.lblNetPremiumValue.Text.Trim() != string.Empty)
            {
                m_NetPremium = (decimal)Utilities.ExactNumber(this.lblNetPremiumValue.Text.Trim());
            }
            Nullable<int> m_Stamp = null;
            if (this.lblStampDiutyValue.Text.Trim() != string.Empty)
            {
                m_Stamp = (int)Utilities.ExactNumber(this.lblStampDiutyValue.Text.Trim());
            }
            Nullable<decimal> m_SBT = null;
            if (this.lblTaxValue.Text.Trim() != string.Empty)
            {
                m_SBT = (decimal)Utilities.ExactNumber(this.lblTaxValue.Text.Trim());
            }
            Nullable<decimal> m_TotalPremium = null;
            if (this.lblTotlaPremiumValue.Text.Trim() != string.Empty)
            {
                m_TotalPremium = (decimal)Utilities.ExactNumber(this.lblTotlaPremiumValue.Text.Trim());
            }
            Nullable<sbyte> m_isLongName = 0;
            Nullable<sbyte> m_isBeneficiary = 0;



            string m_CreateUser = m_UserWeb;
            string m_GroupBrokerID = Utilities.GetGroupBrokerID(); ;
            //END VARIABLE-TRANSPOLICY

            //-------------------------------------------------------------------------------------------------------------
            string msg = "";
            bool flagmsg = false;
            if (m_EffectiveDateFrom == string.Empty)
            {
                msg += "Effective Date From |";
                flagmsg = true;
                this.txtEffectiveDateFrom.CssClass = "inputFocusError";
            }            
            if (m_EffectiveDateTo == string.Empty)
            {
                msg += "Effective Date To |";
                flagmsg = true;
                this.txtEffectiveDateTo.CssClass = "inputFocusError";
            }            
            if (m_CountryOfDestination == "โปรดเลือก")
            {
                msg += "Country Of Destination |";
                flagmsg = true;
            }
            if (m_PlanID == "0000")
            {
                msg += "Insurance Plan |";
                flagmsg = true;
            }
            if (flagmsg)
            {
                this.lblErrorMessage.Text = msg + " ห้ามเป็นค่าว่าง";
                this.lblInformMessage.Text = "";
                return;
            }

            //-------------------------------------------------------------------------------------------------------------
            //BEGIN VARIABLE-TRANSPOLICY HOLDER
            //string m_JOBNO = "";
            string m_BranchNo = this.txtBranchNo.Value.Trim();
            string m_Language = this.ddlLanguage.SelectedValue;
            string m_ClientType = "";
            string m_ClientTitle = this.ddlPolicyHolderTitle.SelectedValue.Trim();
            string m_ClientName = this.txtName.Value.Trim();
            string m_ClientSurName = this.txtSurname.Value.Trim();
            string m_ClientAddress1 = this.txtAddress1.Value.Trim();
            string m_ClientAddress2 = this.txtAddress2.Value.Trim();
            string m_Province = this.ddlProvine.SelectedItem.Text.Trim();  //Our customer need to keep name of province,change value same as text on dropdownlist  ,change date 2012-06-09
            string m_Amphur = this.ddlAmphure.SelectedItem.Text.Trim(); //Our customer need to keep name of amphur,change value same as text on dropdownlist  ,change date 2012-06-09
            string m_Tumbol = this.ddlTumbon.SelectedItem.Text.Trim(); //Our customer need to keep name of tumbol,change value same as text on dropdownlist  ,change date 2012-06-09
            string m_Postcode = this.txtZipCode.Value.Trim();
            string m_Birthday = this.txtBirthday.Value.Trim().Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtBirthday.Value.Trim()); //30/05/2012 to 2012-05-30
            string m_IdCard = this.txtIDCard.Text.Trim();
            string m_Tel = this.txtTel.Value.Trim();
            string m_Email = this.txtEmail.Value.Trim();

            //END VARIABLE-TRANSPOLICY HOLDER
            //-------------------------------------------------------------------------------------------------------------

            //START GET TA GET AGE BY POLICY TYPE,TRAVEL PLAN,PLAN ID
            TAPlanPackageBLL clsplanpackage = new TAPlanPackageBLL();
            TAGetAge getage = clsplanpackage.GetTAGetAge(m_PolicyType, m_TravelPlan, m_PlanID);
            int m_AgeOfTravelerFrom = Convert.ToInt32(getage.AgeOfTravelerFrom);
            int m_AgeOfTravelerTo = Convert.ToInt32(getage.AgeOfTravelerTo);
            //END GET TA GET AGE

            DateTime dt1 = new DateTime();
            DateTime dt2 = new DateTime();
            bool ret = false;
            string policyholdertype = ""; //CHECK POLICY HOLDER TYPE
            foreach (ListItem item in rdoTaxInvoiceType.Items)
            {
                if (item.Selected == true)
                {
                    policyholdertype = item.Value.Trim();  //Private ,Commercial
                }
            }
            msg = "";
            flagmsg = false;
            if (policyholdertype == "Private")
            {
                //Private
                if (m_ClientName == string.Empty)
                {
                    msg += "Name |";
                    flagmsg = true;
                    this.txtName.Attributes["class"] = "inputFocusError";
                }                

                if (m_ClientSurName == string.Empty)
                {
                    msg += "Family name |";
                    flagmsg = true;
                    this.txtSurname.Attributes["class"] = "inputFocusError";
                }                

                if (m_Birthday == string.Empty)
                {
                    msg += "Birthday |";
                    flagmsg = true;
                    this.txtBirthday.Attributes["class"] = "inputFocusError";
                }
                if (m_IdCard == string.Empty)
                {
                    msg += "ID Card/ Tax ID |";
                    flagmsg = true;
                    this.txtIDCard.CssClass = "inputFocusError"; 
                }
                if (m_Tel == string.Empty)
                {
                    msg += "Tel |";
                    flagmsg = true;
                    this.txtTel.Attributes["class"] = "inputFocusError";
                }
                if (m_ClientAddress1 == string.Empty)
                {
                    msg += "Address 1 |";
                    flagmsg = true;
                    this.txtAddress1.Attributes["class"] = "inputFocusError";
                }
                if (m_Province == "โปรดเลือก" || m_Province == "Please Selected")
                {
                    msg += "Provine |";
                    flagmsg = true;
                }
                if (m_Amphur == "โปรดเลือก" || m_Amphur == "Please Selected")
                {
                    msg += "District |";
                    flagmsg = true;
                }
                if (m_Tumbol == "โปรดเลือก" || m_Tumbol == "Please Selected")
                {
                    msg += "Sub District |";
                    flagmsg = true;
                }
                if (m_Postcode == string.Empty)
                {
                    msg += "Zip Code  |";
                    flagmsg = true;
                    this.txtZipCode.Attributes["class"] = "inputFocusError";
                }
                if (flagmsg)
                {
                    this.lblErrorMessage.Text = msg + " on Policy Holder ห้ามเป็นค่าว่าง";
                    this.lblInformMessage.Text = "";
                    return;
                }

                //CHECK BIRTHDAY ON POLICY HOLDER
                dt1 = Convert.ToDateTime(m_Birthday);
                dt2 = Convert.ToDateTime(m_EffectiveDateFrom);
                //ret = this.IsBirthDayOverLimitOfEffectiveDate(1, 70, dt1, dt2);
                ret = this.IsBirthDayOverLimitOfEffectiveDate(m_AgeOfTravelerFrom, m_AgeOfTravelerTo, dt1, dt2);
                if (ret)
                {
                    //this.lblErrorMessage.Text = "Birthday on Policy Holder ไม่อยู่ในช่วง 1-70 ปี นับจากวันที่เดินทาง";
                    this.lblErrorMessage.Text = "Birthday on Policy Holder ไม่อยู่ในช่วง " + m_AgeOfTravelerFrom + "-" + m_AgeOfTravelerTo + " ปี นับจากวันที่เดินทาง";
                    this.lblInformMessage.Text = "";
                    return;
                }

                this.txtBranchNo.Value = "";
                m_BranchNo = "";
            }
            else //Commercial
            {
                if (m_ClientName == string.Empty)
                {
                    msg += "Name |";
                    flagmsg = true;
                    this.txtName.Attributes["class"] = "inputFocusError";
                }
                /*if (m_ClientSurName == string.Empty)
                {
                    msg += "Name 2 |";
                    flagmsg = true;
                    this.txtSurname.Attributes["class"] = "inputFocusError";
                }*/
                if (m_IdCard == string.Empty)
                {
                    msg += "ID Card/ Corporate Tax ID |";
                    flagmsg = true;
                    this.txtIDCard.CssClass = "inputFocusError";
                }
                if (m_Tel == string.Empty)
                {
                    msg += "Tel |";
                    flagmsg = true;
                    this.txtTel.Attributes["class"] = "inputFocusError";
                }
                if (m_ClientAddress1 == string.Empty)
                {
                    msg += "Address 1 |";
                    flagmsg = true;
                    this.txtAddress1.Attributes["class"] = "inputFocusError";
                }
                if (m_Province == "โปรดเลือก" || m_Province == "Please Selected")
                {
                    msg += "Provine |";
                    flagmsg = true;
                }
                if (m_Amphur == "โปรดเลือก" || m_Amphur == "Please Selected")
                {
                    msg += "District |";
                    flagmsg = true;
                }
                if (m_Tumbol == "โปรดเลือก" || m_Tumbol == "Please Selected")
                {
                    msg += "Sub District |";
                    flagmsg = true;
                }
                if (m_Postcode == string.Empty)
                {
                    msg += "Zip Code  |";
                    flagmsg = true;
                    this.txtZipCode.Attributes["class"] = "inputFocusError";
                }
                if (flagmsg)
                {
                    this.lblErrorMessage.Text = msg + " on Policy Holder ห้ามเป็นค่าว่าง";
                    this.lblInformMessage.Text = "";
                    return;
                }
            }



            //-------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------
            //CHECK TRAVELER 1
            string m_Traveler1ClientName = this.txtTraveler1Name.Value.Trim();
            string m_Traveler1ClientSurName = this.txtTraveler1Surname.Value.Trim();
            string m_Traveler1Birthday = this.txtTraveler1Birthday.Value.Trim();
            string m_Traveler1PassportNo = this.txtTraveler1PassportNo.Value.Trim();
            string m_Traveler1Tel = this.txtTraveler1Tel.Value.Trim();
            bool chkTraveler1Hier = this.chkTraveler1BeneficialyHeir.Checked;

            msg = "";
            flagmsg = false;
            if (m_Traveler1ClientName == string.Empty)
            {
                msg += "Name |";
                flagmsg = true;
                this.txtTraveler1Name.Attributes["class"] = "inputFocusError";
            }
            if (m_Traveler1ClientSurName == string.Empty)
            {
                msg += "Family name |";
                flagmsg = true;
                this.txtTraveler1Surname.Attributes["class"] = "inputFocusError";
            }
            if (m_Traveler1Birthday == string.Empty)
            {
                msg += "Birthday |";
                flagmsg = true;
                this.txtTraveler1Birthday.Attributes["class"] = "inputFocusError";
            }

            if (m_Traveler1PassportNo == string.Empty)
            {
                msg += "Passport No |";
                flagmsg = true;
                this.txtTraveler1PassportNo.Attributes["class"] = "inputFocusError";
            }
            if (m_Traveler1Tel == string.Empty)
            {
                msg += "Tel |";
                flagmsg = true;
                this.txtTraveler1Tel.Attributes["class"] = "inputFocusError";
            }
            //CHECK BENEFICIARY
            if (chkTraveler1Hier == false)
            {
                if (string.IsNullOrEmpty(txtTraveler1BeneficialyName1.Value.Trim()) || string.IsNullOrEmpty(txtTraveler1BeneficialySurname1.Value.Trim()))
                {
                    msg += "Beneficiary Name and Family name | ";
                    flagmsg = true;
                    this.txtTraveler1BeneficialyName1.Attributes["class"] = "inputFocusError";
                }
            }
            //END CHECK
            if (flagmsg)
            {
                this.lblErrorMessage.Text = msg + " on Traveler 1 ห้ามเป็นค่าว่าง";
                this.lblInformMessage.Text = "";
                return;
            }


            //DEFAULT EFFECTTIVE DATE FROM
            dt2 = Convert.ToDateTime(m_EffectiveDateFrom);

            //CHECK BIRTHDAY ON TRAVELER 1
            //string m_traveler1_birthday = this.txtTraveler1Birthday.Value.Trim();
            string m_traveler1_birthday = this.txtTraveler1Birthday.Value.Trim().Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtTraveler1Birthday.Value.Trim()); //30/05/2012 to 2012-05-30;
            if (!m_traveler1_birthday.Equals(string.Empty))
            {
                dt1 = Convert.ToDateTime(m_traveler1_birthday);
                //ret = this.IsBirthDayOverLimitOfEffectiveDate(1, 70, Convert.ToDateTime(dt1), Convert.ToDateTime(dt2));
                //ret = this.IsBirthDayOverLimitOfEffectiveDate(1, 70, dt1, dt2);
                ret = this.IsBirthDayOverLimitOfEffectiveDate(m_AgeOfTravelerFrom, m_AgeOfTravelerTo, dt1, dt2);
                if (ret)
                {
                    //this.lblErrorMessage.Text = "Birthday on Traveler 1 ไม่อยู่ในช่วง 1-70 ปี นับจากวันที่เดินทาง";
                    //this.lblErrorMessage.Text = "กรุณาติดต่อ บริษัท เนื่องจากอายุผู้เดินทางเกิน 70ปี / Please contact AXA helpdesk as age is over 70 ";
                    this.lblErrorMessage.Text = "กรุณาติดต่อ บริษัท เนื่องจากอายุผู้เดินทางเกิน " + m_AgeOfTravelerTo + "ปี / Please contact AXA helpdesk as age is over " + m_AgeOfTravelerTo;

                    this.lblInformMessage.Text = "";
                    return;
                }
            }
            else
            {
                this.lblErrorMessage.Text = "Birthday on Traveler 1 | ห้ามเป็นค่าว่าง";
                this.lblInformMessage.Text = "";
                return;
            }

            //VALIDATE RATIO IS 100 ON TRAVELER1
            int traveler1Ratio1 = 0;
            int traveler1Ratio2 = 0;
            int traveler1Ratio3 = 0;

            if (chkTraveler1Hier == false)
            {
                if (!string.IsNullOrEmpty(txtTraveler1BeneficialyName1.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler1BeneficialySurname1.Value.Trim()))
                {
                    traveler1Ratio1 = txtTraveler1BeneficialyRatio1.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler1BeneficialyRatio1.Value.Trim());
                }

                if (!string.IsNullOrEmpty(txtTraveler1BeneficialyName2.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler1BeneficialySurname2.Value.Trim()))
                {
                    traveler1Ratio2 = txtTraveler1BeneficialyRatio2.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler1BeneficialyRatio2.Value.Trim());
                }

                if (!string.IsNullOrEmpty(txtTraveler1BeneficialyName3.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler1BeneficialySurname3.Value.Trim()))
                {
                    traveler1Ratio3 = txtTraveler1BeneficialyRatio3.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler1BeneficialyRatio3.Value.Trim());
                }

                if (traveler1Ratio1 + traveler1Ratio2 + traveler1Ratio3 != 100)
                {
                    this.lblErrorMessage.Text = "Sum of Beneficiary Ratio on Traveler1 Must be 100!!! ";
                    this.lblInformMessage.Text = "";
                    return;
                }
            }

            //END VALIDATE

            //-------------------------------------------------------------------------------------------------------------
            if (m_PolicyType == TA.TAUtilities.PolicyType.Family.ToString())
            {
                //CHECK TRAVER 2
                string m_Traveler2ClientName = this.txtTraveler2Name.Value.Trim();
                string m_Traveler2ClientSurName = this.txtTraveler2Surname.Value.Trim();
                string m_Traveler2Birthday = this.txtTraveler2Birthday.Value.Trim();
                string m_Traveler2PassportNo = this.txtTraveler2PassportNo.Value.Trim();
                string m_Traveler2Tel = this.txtTraveler2Tel.Value.Trim();
                bool chkTraveler2Hier = this.chkTraveler2BeneficialyHeir.Checked;

                msg = "";
                flagmsg = false;
                if (m_Traveler2ClientName == string.Empty)
                {
                    msg += "Name |";
                    flagmsg = true;
                    this.txtTraveler2Name.Attributes["class"] = "inputFocusError";
                }
                if (m_Traveler2ClientSurName == string.Empty)
                {
                    msg += "Family name |";
                    flagmsg = true;
                    this.txtTraveler2Surname.Attributes["class"] = "inputFocusError";
                }
                if (m_Traveler2Birthday == string.Empty)
                {
                    msg += "Birthday |";
                    flagmsg = true;
                    this.txtTraveler2Birthday.Attributes["class"] = "inputFocusError";
                }

                if (m_Traveler2PassportNo == string.Empty)
                {
                    msg += "Passport No |";
                    flagmsg = true;
                    this.txtTraveler2PassportNo.Attributes["class"] = "inputFocusError";
                }
                if (m_Traveler2Tel == string.Empty)
                {
                    msg += "Tel |";
                    flagmsg = true;
                    this.txtTraveler2Tel.Attributes["class"] = "inputFocusError";
                }
                //CHECK BENEFICIARY
                if (chkTraveler2Hier == false)
                {
                    if (string.IsNullOrEmpty(txtTraveler2BeneficialyName1.Value.Trim()) || string.IsNullOrEmpty(txtTraveler2BeneficialySurname1.Value.Trim()))
                    {
                        msg += "Beneficiary Name and Family name | ";
                        flagmsg = true;
                        this.txtTraveler2BeneficialyName1.Attributes["class"] = "inputFocusError";
                    }
                }
                //END CHECK
                if (flagmsg)
                {
                    this.lblErrorMessage.Text = msg + " on Traveler 2 ห้ามเป็นค่าว่าง";
                    this.lblInformMessage.Text = "";
                    return;
                }
                //CHECK BIRTHDAY ON TRAVELER 2
                //string m_traveler2_birthday = this.txtTraveler2Birthday.Value.Trim();
                string m_traveler2_birthday = this.txtTraveler2Birthday.Value.Trim().Equals(string.Empty) ? "" : TA.TAUtilities.ConvertDateFieldToDB(this.txtTraveler2Birthday.Value.Trim()); //30/05/2012 to 2012-05-30;
                if (!m_traveler2_birthday.Equals(string.Empty))
                {
                    dt1 = Convert.ToDateTime(m_traveler2_birthday);
                    //ret = this.IsBirthDayOverLimitOfEffectiveDate(1, 70, Convert.ToDateTime(dt1), Convert.ToDateTime(dt2));
                    //ret = this.IsBirthDayOverLimitOfEffectiveDate(1, 70, dt1, dt2);
                    ret = this.IsBirthDayOverLimitOfEffectiveDate(m_AgeOfTravelerFrom, m_AgeOfTravelerTo, dt1, dt2);

                    if (ret)
                    {
                        //this.lblErrorMessage.Text = "Birthday on Traveler 2 ไม่อยู่ในช่วง 1-70 ปี นับจากวันที่เดินทาง";
                        //this.lblErrorMessage.Text = "กรุณาติดต่อ บริษัท เนื่องจากอายุผู้เดินทางเกิน 70ปี / Please contact AXA helpdesk as age is over 70 ";
                        this.lblErrorMessage.Text = "กรุณาติดต่อ บริษัท เนื่องจากอายุผู้เดินทางเกิน " + m_AgeOfTravelerTo + "ปี / Please contact AXA helpdesk as age is over " + m_AgeOfTravelerTo;

                        this.lblInformMessage.Text = "";
                        return;
                    }
                }
                else
                {
                    this.lblErrorMessage.Text = "Birthday on Traveler 2 | ห้ามเป็นค่าว่าง";
                    this.lblInformMessage.Text = "";
                    return;
                }

                //VALIDATE RATIO IS 100 ON TRAVELER1
                int traveler2Ratio1 = 0;
                int traveler2Ratio2 = 0;
                int traveler2Ratio3 = 0;

                if (chkTraveler2Hier == false)
                {
                    if (!string.IsNullOrEmpty(txtTraveler2BeneficialyName1.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler2BeneficialySurname1.Value.Trim()))
                    {
                        traveler2Ratio1 = txtTraveler2BeneficialyRatio1.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler2BeneficialyRatio1.Value.Trim());
                    }

                    if (!string.IsNullOrEmpty(txtTraveler2BeneficialyName2.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler2BeneficialySurname2.Value.Trim()))
                    {
                        traveler2Ratio2 = txtTraveler2BeneficialyRatio2.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler2BeneficialyRatio2.Value.Trim());
                    }

                    if (!string.IsNullOrEmpty(txtTraveler1BeneficialyName3.Value.Trim()) && !string.IsNullOrEmpty(txtTraveler1BeneficialySurname3.Value.Trim()))
                    {
                        traveler2Ratio3 = txtTraveler2BeneficialyRatio3.Value.Trim().Equals(string.Empty) ? 0 : Convert.ToInt32(txtTraveler2BeneficialyRatio3.Value.Trim());
                    }

                    if (traveler2Ratio1 + traveler2Ratio2 + traveler2Ratio3 != 100)
                    {
                        this.lblErrorMessage.Text = "Sum of Beneficiary Ratio on Traveler2 Must be 100!!! ";
                        this.lblInformMessage.Text = "";
                        return;
                    }
                }

                //END VALIDATE


                //CHECK CHILD (1,2) 
                int m_allpeople = (int)m_NumbersOfChildren + 2;
                //string m_msgofchild = "";
                //bool m_flagmsg = false;
                if (m_allpeople > 2)
                {
                    //CHECK CHILD 
                    for (int ch = 3; ch <= m_allpeople; ch++)
                    {

                        //CHECK EMPTY ON TRAVELER 3 UP -----
                        string id_clientname = "ctl00$MainContent$txtTraveler" + ch + "Name";
                        string m_TravelerChildClientName = Request.Form[id_clientname].Trim();
                        string id_clientsurname = "ctl00$MainContent$txtTraveler" + ch + "SurName";
                        string m_TravelerChildClientSurName = Request.Form[id_clientsurname].Trim();
                        string id_birthday = "ctl00$MainContent$txtTraveler" + ch + "Birthday";
                        string m_TravelerChildBirthday = Request.Form[id_birthday].Trim();
                        string id_passportid = "ctl00$MainContent$txtTraveler" + ch + "PassportNo";
                        string m_TravelerChildPassportID = Request.Form[id_passportid];
                        string id_tel = "ctl00$MainContent$txtTraveler" + ch + "Tel";
                        string m_TravelerChildTel = Request.Form[id_tel];

                        msg = "";
                        flagmsg = false;
                        if (m_TravelerChildClientName == string.Empty)
                        {
                            msg += "Name |";
                            flagmsg = true;                           
                        }
                        if (m_TravelerChildClientSurName == string.Empty)
                        {
                            msg += "Family name |";
                            flagmsg = true;
                        }
                        if (m_TravelerChildBirthday == string.Empty)
                        {
                            msg += "Birthday |";
                            flagmsg = true;
                        }
                        if (m_TravelerChildPassportID == string.Empty)
                        {
                            msg += "Passport No |";
                            flagmsg = true;
                        }
                        if (m_TravelerChildTel == string.Empty)
                        {
                            msg += "Tel |";
                            flagmsg = true;
                        }

                        //CHECK BENEFICIARY
                        string m_BeneficiaryName = "";
                        string m_BeneficiarySurName = "";
                        string id_BeneficiaryName = "ctl00$MainContent$txtTraveler" + ch + "BeneficialyName1";
                        m_BeneficiaryName = Request.Form[id_BeneficiaryName];
                        string id_BeneficiarySurName = "ctl00$MainContent$txtTraveler" + ch + "BeneficialySurname1";
                        m_BeneficiarySurName = Request.Form[id_BeneficiarySurName];
                        string id_BeneficiaryHier = "ctl00$MainContent$chkTraveler" + ch + "BeneficialyHeir";
                        string m_BeneficiaryHier = Request.Form[id_BeneficiaryHier];
                        if (m_BeneficiaryHier == "on")
                        {

                        }
                        else
                        {
                            if (string.IsNullOrEmpty(m_BeneficiaryName) && string.IsNullOrEmpty(m_BeneficiarySurName))
                            {
                                msg += "Name and Family name |";
                                flagmsg = true;
                            }
                        }
                        //END CHECK

                        if (flagmsg)
                        {
                            msg += " on Traveler " + ch + " ห้ามเป็นค่าว่าง";
                            break;
                        }

                        //CHECK BIRTHDAY ON TRAVELER 3 UP -----
                        msg = "";
                        flagmsg = false;
                        if (!string.IsNullOrEmpty(Request.Form[id_birthday]))
                        {
                            string m_travelerchild_birthday = TA.TAUtilities.ConvertDateFieldToDB(Request.Form[id_birthday]);
                            dt1 = Convert.ToDateTime(m_travelerchild_birthday);
                            ret = this.IsBirthDayOverLimitOfEffectiveDate(1, 21, dt1, dt2);
                            if (ret)
                            {
                                msg += "Traveler " + ch + " Birthday ไม่อยู่ในช่วง 1-21 ปี นับจากวันที่เดินทาง | <br>";
                                flagmsg = true;
                                break;
                            }
                            else
                            {
                                //1-21
                                dt1 = Convert.ToDateTime(m_travelerchild_birthday);
                                ret = this.IsBirthDayOverLimitOfEffectiveDate(1, 18, dt1, dt2);
                                if (ret)
                                {
                                    string id_isStudent = "ctl00$MainContent$chkTraveler" + ch + "Occupation";
                                    int m_isStudent = 0;
                                    if (!string.IsNullOrEmpty(Request.Form[id_isStudent]))
                                    {
                                        m_isStudent = 1; //on = true = selected
                                    }
                                    string id_isSingle = "ctl00$MainContent$chkTraveler" + ch + "Status";
                                    int m_isSingle = 0;
                                    if (!string.IsNullOrEmpty(Request.Form[id_isSingle]))
                                    {
                                        m_isSingle = 1;
                                    }
                                    if (m_isStudent == 0 || m_isSingle == 0)
                                    {
                                        msg += "Traveler " + ch + " Birthday ไม่อยู่ในช่วง 1-18 ปี นับจากวันที่เดินทาง ไม่เป็นนักศึกษาและสถานะภาพไม่โสด | <br>";
                                        flagmsg = true;
                                        break;
                                    }
                                }
                            }
                        }

                        //VALIDATE RATIO IS 100 ON TRAVELER1
                        int travelerxRatio = 0;

                        for (int j = 1; j < 4; j++)
                        {

                            string msub_BeneficiaryName = "";
                            string msub_BeneficiarySurName = "";
                            string msub_BeneficiaryRatio = "";

                            string idsub_BeneficiaryName = "ctl00$MainContent$txtTraveler" + ch + "BeneficialyName" + j.ToString();
                            msub_BeneficiaryName = Request.Form[idsub_BeneficiaryName];

                            string idsub_BeneficiarySurName = "ctl00$MainContent$txtTraveler" + ch + "BeneficialySurname" + j.ToString();
                            msub_BeneficiarySurName = Request.Form[idsub_BeneficiarySurName];

                            string idsub_BeneficiaryRatio = "ctl00$MainContent$txtTraveler" + ch + "BeneficialyRatio" + j.ToString();
                            msub_BeneficiaryRatio = Request.Form[idsub_BeneficiaryRatio];

                            if (m_BeneficiaryHier == "on")
                            {

                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(msub_BeneficiaryName) && !string.IsNullOrEmpty(msub_BeneficiarySurName))
                                {
                                    travelerxRatio += msub_BeneficiaryRatio.Equals(string.Empty) ? 0 : Convert.ToInt32(msub_BeneficiaryRatio.Trim());
                                }
                            }
                        }

                        if (travelerxRatio != 100 && m_BeneficiaryHier != "on")
                        {
                            this.lblErrorMessage.Text = "Sum of Beneficiary Ratio on Traveler " + ch + " Must be 100!!! ";
                            this.lblInformMessage.Text = "";
                            return;
                        }
                        //END VALIDATE
                    }
                    if (flagmsg)
                    {
                        this.lblErrorMessage.Text = msg;
                        this.lblInformMessage.Text = "";
                        return;
                    }
                }
            }

            //
            //VARIABLE LONGNAME-------------------------------------------------------------------------------------------------------------
            //string m_JobNo = "";
            string m_LongName1 = this.txtLongName1.Value.Trim();
            string m_LongName2 = this.txtLongName2.Value.Trim();
            //string m_LongName3 = this.txtLongName3.Value.Trim();
            //string m_LongName4 = this.txtLongName4.Value.Trim();
            string m_temp = string.Concat(m_LongName1, m_LongName2);
            if (m_temp != string.Empty)
            {
                m_isLongName = 1;
            }

            #endregion

            //SET TA POLICY ALL PROCESS 
            string planID = this.ddlInsurancePlan.SelectedValue;
            string travelPlanType = this.rdoTravelPlan.SelectedValue.Trim();
            int duration = 0;

            if (!string.IsNullOrEmpty(this.txtDuration.Value.Trim()))
                duration = Convert.ToInt32(this.txtDuration.Value.Trim());

            TAPlanPremuimBLL planpremium = new TAPlanPremuimBLL();
            TAPremuim premium = planpremium.GetTAPremuim(planID, duration, travelPlanType);
            double m_d_netpremium = double.Parse(premium.NetPremium.Trim());
            double m_d_tax = double.Parse(premium.TAX.Trim());
            double m_d_stamp = double.Parse(premium.Stamp.Trim());
            double m_d_total = double.Parse(premium.Total.Trim());

            #region "GET/SET JOB NUMBER (NOW NONE TRANSACTION)"
            //GET/SET JOB NUMBER
            //string m_JobNo = "AXA-TA-20120500007";
            TAJobRunningBLL clsjobrunning = new TAJobRunningBLL();
            string m_JobNo = string.Empty;

            string qry_mode = Request.QueryString["mode"];
            string qry_jobno = Request.QueryString["JobNo"];

            if (!string.IsNullOrEmpty(qry_mode) && !string.IsNullOrEmpty(qry_jobno))
            {
                if (string.Compare(qry_mode.Trim(), "edit") == 0)
                {
                    m_JobNo = qry_jobno.Trim();
                }
                else
                {
                    m_JobNo = clsjobrunning.GetTAJobRunningNumber();

                    if (string.IsNullOrEmpty(m_JobNo))
                    {
                        throw new Exception("เกิดข้อผิดพลาดในการสร้างหมายเลข Job Number กรุณาทดลองบันทึกงานอีกครั้งหรือติดต่อผู้ดูแลระบบ");
                    }
                }
            }
            else
            {
                m_JobNo = clsjobrunning.GetTAJobRunningNumber();

                if (string.IsNullOrEmpty(m_JobNo))
                {
                    throw new Exception("เกิดข้อผิดพลาดในการสร้างหมายเลข Job Number กรุณาทดลองบันทึกงานอีกครั้งหรือติดต่อผู้ดูแลระบบ");
                }
            }

            //m_JobNo = clsjobrunning.GetTAJobRunningNumber();
            //if (string.IsNullOrEmpty(m_JobNo))
            //{
            //    throw new Exception("เกิดข้อผิดพลาดในการสร้างหมายเลข Job Number กรุณาทดลองบันทึกงานอีกครั้งหรือติดต่อผู้ดูแลระบบ");
            //}
            #endregion

            #region "OPEN DB"
            //OPEN DB
            DbProviderHelper.OpenDb();
            #endregion

            #region "OPEN TRANSACTION"
            //TRANSACTION BEGIN
            dbTransaction = DbProviderHelper.BeginTransaction();
            #endregion

            #region "#1-INSERT/UPDATE TRANSPOLICY"
            //#1-INSERT/UPDATE TRANSPOLICY

            TATransPolicyBLL clstranspolicy = new TATransPolicyBLL();
            //clstranspolicy.SetTATransPolicy("AXA-TA-20120500001", "", "Annual", "Individual", 0, "0001", "2012-05-23", "2013-05-23", "TH", "", "", 0, 0, 0, 0, 0, 0, "", "BA347", dbTransaction);
            string ip = System.Web.HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (string.IsNullOrEmpty(ip))
            {
                ip = System.Web.HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
            }

            clstranspolicy.SetTATransPolicy(m_JobNo, m_PolicyNo, m_TravelPlan, m_PolicyType, m_NumbersOfChildren, m_PlanID, m_EffectiveDateFrom, m_EffectiveDateTo, m_CountryOfDestination, m_ContryOther, m_AgentCode, m_OccupatnCode, m_NetPremium, m_Stamp, m_SBT, m_TotalPremium, m_isLongName, m_isBeneficiary, m_CreateUser , m_GroupBrokerID, ip, dbTransaction);

            #endregion

            #region "#2-INSERT/UPDATE TRANSCOVERAGE"
            //#2-INSERT/UPDATE TRANSCOVERAGE
            //VARIABLE
            //string m_JobNo = "";
            float m_PersonalAccident = (float)Utilities.ExactNumber(this.lblPersonalAccidentValue.Text.Trim());
            string m_PlanId = this.ddlInsurancePlan.SelectedValue.Trim();

            TATransCoverageBLL clstranscoverage = new TATransCoverageBLL();
            //clstranscoverage.SetTATransCoverage("AXA-TA-20120500001", (float)1000000, "0001", dbTransaction);
            clstranscoverage.SetTATransCoverage(m_JobNo, m_PersonalAccident, m_PlanId, dbTransaction);
            #endregion

            #region "#3-INSERT/UPDATE TRANSPOLICYHOLDER"
            //#3-INSERT/UPDATE TRANSPOLICYHOLDER
            policyholdertype = ""; //CHECK POLICY HOLDER TYPE
            foreach (ListItem item in rdoTaxInvoiceType.Items)
            {
                if (item.Selected == true)
                {
                    policyholdertype = item.Value.Trim();  //Private ,Commercial
                }
            }
            TATransPolicyHolderBLL clstranspolicyholder = new TATransPolicyHolderBLL();
            if (policyholdertype == "Private")
            {
                //Private
                m_ClientType = "P";
                clstranspolicyholder.SetTATransPolicyHolder(m_JobNo, m_ClientType, m_ClientTitle, m_ClientName, m_ClientSurName, m_ClientAddress1, m_ClientAddress2, m_Province, m_Amphur, m_Tumbol, m_Postcode, m_Birthday, m_IdCard, m_Tel, m_Email, m_Language, m_BranchNo, dbTransaction);
            }
            else
            {
                //Commercial
                m_ClientType = "C";
                clstranspolicyholder.SetTATransPolicyHolder(m_JobNo, m_ClientType, "", m_ClientName, m_ClientSurName, m_ClientAddress1, m_ClientAddress2, m_Province, m_Amphur, m_Tumbol, m_Postcode, "", m_IdCard, m_Tel, m_Email, m_Language, m_BranchNo, dbTransaction);
            }

            #endregion

            #region "#4-INSERT/UPDATE TRANSTRAVELER"
            //#4-INSERT/UPDATE TRANSTRAVELER
            //VARIABLE            
            int numberofchid = int.Parse(this.txtNumberOfChilden.Text.Trim());

            if (numberofchid == 0 && m_PolicyType == "Individual")
                numberofchid = -1;

            for (int c = 1; c <= (numberofchid + 2); c++)
            {
                //string m_JobNo = "";
                int m_TravelerId = c;
                //string m_ClientTitle = "";
                //string m_ClientName  = "";
                //string m_ClientSurName  = "";
                //string m_Birthday = null;
                string m_PassportID = "";
                Nullable<sbyte> m_isStudent = null;
                Nullable<sbyte> m_isSingle = null;
                //string m_Tel  = "";

                string id_title = "ctl00$MainContent$ddlTraveler" + c + "Title";     //ctl00$MainContent$ddlTraveler1Title
                m_ClientTitle = Request.Form[id_title];                             //Values
                string id_clientname = "ctl00$MainContent$txtTraveler" + c + "Name";
                m_ClientName = Request.Form[id_clientname];
                string id_clientsurname = "ctl00$MainContent$txtTraveler" + c + "SurName";
                m_ClientSurName = Request.Form[id_clientsurname];
                string id_birthday = "ctl00$MainContent$txtTraveler" + c + "Birthday";
                m_Birthday = "";
                if (!string.IsNullOrEmpty(Request.Form[id_birthday]))
                {
                    //m_Birthday = TA.TAUtilities.ConvertDateFieldToDB(m_Birthday);
                    m_Birthday = TA.TAUtilities.ConvertDateFieldToDB(Request.Form[id_birthday]);
                }
                string id_passportid = "ctl00$MainContent$txtTraveler" + c + "PassportNo";
                m_PassportID = Request.Form[id_passportid];
                string id_isStudent = "ctl00$MainContent$chkTraveler" + c + "Occupation";
                m_isStudent = 0;
                if (!string.IsNullOrEmpty(Request.Form[id_isStudent]))
                {
                    m_isStudent = 1; //on = true = selected
                }
                string id_isSingle = "ctl00$MainContent$chkTraveler" + c + "Status";
                m_isSingle = 0;
                if (!string.IsNullOrEmpty(Request.Form[id_isSingle]))
                {
                    m_isSingle = 1; //on = true = selected
                }
                string id_tel = "ctl00$MainContent$txtTraveler" + c + "Tel";
                m_Tel = Request.Form[id_tel];

                //กรณี Family ลูก ๆ จะได้รับ PA คุ้มครอง 50% 2012-06-05
                float travelerPA = 0;
                if (m_TravelerId > 2)
                    travelerPA = m_PersonalAccident / 2;
                else
                    travelerPA = m_PersonalAccident;

                //Process Get Each Traveler Net Premium , Tax , Stamp , Total Premium 2012-06-05
                Nullable<decimal> travelerNetPremium = null;
                Nullable<int> travelerStamp = null;
                Nullable<int> travelerSBT = null;
                Nullable<decimal> travelerTotalPremium = null;

                if (m_TravelerId > 2)
                {
                    if (m_TravelerId > 4)
                    {
                        travelerNetPremium = (decimal)m_d_netpremium / 2;
                        travelerStamp = (int)m_d_stamp / 2;
                        travelerSBT = (int)m_d_tax / 2;
                        travelerTotalPremium = (decimal)m_d_total / 2;
                    }
                    else
                    {
                        travelerNetPremium = 0;
                        travelerStamp = 0;
                        travelerSBT = 0;
                        travelerTotalPremium = 0;
                    }
                }
                else
                {
                    travelerNetPremium = (decimal)m_d_netpremium;
                    travelerStamp = (int)m_d_stamp;
                    travelerSBT = (int)m_d_tax;
                    travelerTotalPremium = (decimal)m_d_total;
                }
                //End 

                //EXEC PROCEDURE
                TATransTravelerBLL clstranstraveler = new TATransTravelerBLL();
                //clstranstraveler.SetTATransTraveler(m_JobNo, m_TravelerId, m_ClientTitle, m_ClientName, m_ClientSurName, m_Birthday, m_PassportID, m_Tel, m_isStudent, m_isSingle, null, dbTransaction);
                clstranstraveler.SetTATransTraveler(m_JobNo, m_TravelerId, m_ClientTitle, m_ClientName, m_ClientSurName, m_Birthday, m_PassportID, m_Tel, m_isStudent, m_isSingle, Convert.ToDecimal(travelerPA), travelerNetPremium, travelerStamp, travelerSBT, travelerTotalPremium, null, dbTransaction);

                #region "#5-INSERT/UPDATE TRANSBENEFICIARY"
                //#5-INSERT/UPDATE TRANSBENEFICIARY

                for (int j = 1; j < 4; j++)
                {
                    //string m_JobNo = "";
                    int m_TravelerID = c;
                    int m_Seq = j;
                    string m_BeneficiaryTitle = "";
                    string m_BeneficiaryName = "";
                    string m_BeneficiarySurName = "";
                    string m_BeneficiaryRelation = "";
                    string m_BeneficiaryRatio = "";
                    string m_BeneficiaryTel = "";

                    string id_BeneficiaryTitle = "ctl00$MainContent$ddlTraveler" + c + "BeneficialyTitle" + j.ToString();
                    m_BeneficiaryTitle = Request.Form[id_BeneficiaryTitle];

                    string id_BeneficiaryName = "ctl00$MainContent$txtTraveler" + c + "BeneficialyName" + j.ToString();
                    m_BeneficiaryName = Request.Form[id_BeneficiaryName];

                    string id_BeneficiarySurName = "ctl00$MainContent$txtTraveler" + c + "BeneficialySurname" + j.ToString();
                    m_BeneficiarySurName = Request.Form[id_BeneficiarySurName];

                    string id_BeneficiaryRelation = "ctl00$MainContent$ddlTraveler" + c + "BeneficialyRelationShip" + j.ToString();
                    m_BeneficiaryRelation = Request.Form[id_BeneficiaryRelation];

                    string id_BeneficiaryRatio = "ctl00$MainContent$txtTraveler" + c + "BeneficialyRatio" + j.ToString();
                    m_BeneficiaryRatio = Request.Form[id_BeneficiaryRatio];

                    string id_BeneficiaryTel = "ctl00$MainContent$txtTraveler" + c + "BeneficialyTel" + j.ToString();
                    m_BeneficiaryTel = Request.Form[id_BeneficiaryTel];

                    string id_BeneficiaryHier = "ctl00$MainContent$chkTraveler" + c + "BeneficialyHeir";
                    string m_BeneficiaryHier = Request.Form[id_BeneficiaryHier];
                    if (m_BeneficiaryHier == "on")
                    {

                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(m_BeneficiaryName) && !string.IsNullOrEmpty(m_BeneficiarySurName))
                        {
                            TATransBeneficiaryBLL clstransbeneficiary = new TATransBeneficiaryBLL();
                            clstransbeneficiary.SetTATransBeneficiary(m_JobNo, c, j, m_BeneficiaryTitle, m_BeneficiaryName, m_BeneficiarySurName, m_BeneficiaryRelation, m_BeneficiaryRatio, m_BeneficiaryTel, dbTransaction);
                        }
                    }
                }

                #endregion

            }
            #endregion

            #region "#6-INSERT/UPDATE TRANSLONGNAME"
            //#6-INSERT/UPDATE TRANSLONGNAME
            if (m_temp != string.Empty)
            {
                TATransLongNameBLL clstranslongname = new TATransLongNameBLL();
                clstranslongname.SetTATransLongName(m_JobNo, m_LongName1, m_LongName2, dbTransaction);
            }


            #endregion

            #region "COMMIT DB"
            //COMMIT DB
            //DbProviderHelper.CommitTransaction(dbTransaction);
            #endregion

            #region "CLOSE DB"
            //CLOSE DB
            DbProviderHelper.CloseDb();
            #endregion

            #region "ISSUED TA POLICY"

            //Bind Job no
            this.lblJobnoValue.Text = m_JobNo;

            //Bind Message
            this.lblErrorMessage.Text = "";
            this.lblInformMessage.Text = "บันทึกข้อมูลลงฐานข้อมูลเรียบร้อย";

       

            //Call Web Services to Issued TA Policy.
            //
            //

            #endregion
        }
        catch (Exception ex)
        {
            //Utilities.LogError(ex);
            if (dbTransaction != null)
            {
                #region "ROLLBACK DB"
                //ROLLBACK DB
                DbProviderHelper.RollbackTransaction(dbTransaction);
                #endregion

                #region "CLOSE DB"
                //CLOSE DB
                DbProviderHelper.CloseDb();
                #endregion
            }

            this.lblErrorMessage.Text = ex.Message.ToString();
            this.lblInformMessage.Text = "";
        }

        if (this.lblJobnoValue.Text != "[Auto Generate]" )
        {
            Response.Redirect("Default.aspx?mode=edit&JobNo=" + this.lblJobnoValue.Text);
        }
    }

    #endregion

    #region "BIND DROPDOWN LIST"
    //PROCESS SET COUNTRY TO DROPDOWNLIST FROM TABLE "TATBCountry" 
    protected void SetCountryToDropdownList(DropDownList ddl)
    {
        try
        {
            //PROCESS GET DATA
            TATBCountryBLL clscountry = new TATBCountryBLL();
            DataTable dt = clscountry.GetDtTATBCountrys(); //GET ALL
            DataRow dr = dt.NewRow();
            dr["CountryName"] = "โปรดเลือก";
            dr["CountryCode"] = "00";
            dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "CountryName";
                ddl.DataValueField = "CountryCode";
                ddl.DataBind();
            }

        }
        catch (Exception ex)
        {
            Utilities.LogError(ex);
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    //PROCESS SET PLANID TO DROPDOWNLIST FROM TABLE "TATBPlanID" 
    protected void SetPlanIDToDropdownList(DropDownList ddl)
    {
        try
        {
            //PROCESS GET DATA
            TATBPlanIDBLL clsplanid = new TATBPlanIDBLL();
            DataTable dt = clsplanid.GetDtTATBPlanIDs(); //GET ALL
            DataRow dr = dt.NewRow();
            dr["PlanName"] = "โปรดเลือก";
            dr["PlanID"] = "0000";
            dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "PlanName";
                ddl.DataValueField = "PlanID";
                ddl.DataBind();
            }

        }
        catch (Exception ex)
        {
            Utilities.LogError(ex);
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    //PROCESS SET TITLE TO DROPDOWNLIST FROM TABLE "TATBTitle" 
    protected void SetTitleToDropdownList(DropDownList ddl)
    {
        try
        {
            //PROCESS GET DATA
            TATBTitleBLL clstitle = new TATBTitleBLL();
            DataTable dt = clstitle.GetDtTATBCountrys(); //GET ALL
            DataRow dr = dt.NewRow();
            //dr["TitleName"] = "โปรดเลือก";
            //dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "TitleName";
                ddl.DataValueField = "TitleName";
                ddl.DataBind();
            }

        }
        catch (Exception ex)
        {
            Utilities.LogError(ex);
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    protected void SetThaiTitleToDropdownList(DropDownList ddl)
    {
        try
        {
            //PROCESS GET DATA
            TATBTitleBLL clstitle = new TATBTitleBLL();
            DataTable dt = clstitle.GetDtTATBCountrysThai(); //GET ALL
            DataRow dr = dt.NewRow();
            //dr["TitleName"] = "โปรดเลือก";
            //dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "TitleName";
                ddl.DataValueField = "TitleName";
                ddl.DataBind();
            }

        }
        catch (Exception ex)
        {
            Utilities.LogError(ex);
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    //PROCESS SET TITLE TO DROPDOWNLIST FROM TABLE "TATBTitle" (LIST DDL)
    protected void SetTitleToDropdownList(DropDownList[] listddl)
    {
        try
        {
            //PROCESS GET DATA
            TATBTitleBLL clstitle = new TATBTitleBLL();
            DataTable dt = clstitle.GetDtTATBCountrys(); //GET ALL
            DataRow dr = dt.NewRow();
            //dr["TitleName"] = "โปรดเลือก";
            //dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                foreach (DropDownList ddl in listddl)
                {
                    ddl.DataSource = dt;
                    ddl.DataTextField = "TitleName";
                    ddl.DataValueField = "TitleName";
                    ddl.DataBind();
                }
            }

        }
        catch (Exception ex)
        {
            Utilities.LogError(ex);
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }

    //PROCESS SET THAI PROVINCE TO DROPDOWNLIST FROM QUICKLINK DB
    protected void SetThaiProvinceToDropdownList(DropDownList ddl)
    {
        try
        {
            //PROCESS GET DATA
            DataTable dt = Client.GetProvinceThaiLanguage(); //GET ALL
            DataRow dr = dt.NewRow();
            dr["Description"] = "โปรดเลือก";
            dr["ProvinceID"] = "00";  
            dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "Description";
                ddl.DataValueField = "ProvinceID"; 
                ddl.DataBind();
            }
        }
        catch (Exception ex)
        {
            Utilities.LogError(ex);
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    //PROCESS SET ENG PROVINCE TO DROPDOWNLIST FROM QUICKLINK DB
    protected void SetEngProvinceToDropdownList(DropDownList ddl)
    {
        try
        {
            //PROCESS GET DATA
            DataTable dt = Client.GetProvinceEngLanguage(); //GET ALL
            DataRow dr = dt.NewRow();
            dr["Description_EN"] = "Please Selected";
            dr["ProvinceID"] = "00"; 
            dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "Description_EN";
                ddl.DataValueField = "ProvinceID"; 
                ddl.DataBind();
            }
        }
        catch (Exception ex)
        {
            Utilities.LogError(ex);
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    //PROCESS SET THAI AMPHUR TO DROPDOWNLIST FROM QUICKLINK DB
    protected void SetThaiAmphurToDropdownList(DropDownList ddl, string provinceid)
    {
        try
        {
            //PROCESS GET DATA
            DataTable dt = Client.GetAmphurByProvinceThai(provinceid); //GET ALL
            DataRow dr = dt.NewRow();
            dr["Amphur"] = "โปรดเลือก";
            dr["AmphurID"] = "00";  
            dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "Amphur";
                ddl.DataValueField = "AmphurID"; 
                ddl.DataBind();
            }
        }
        catch (Exception ex)
        {
            Utilities.LogError(ex);
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    //PROCESS SET ENG AMPHUR TO DROPDOWNLIST FROM QUICKLINK DB
    protected void SetEngAmphurToDropdownList(DropDownList ddl, string provinceid)
    {
        try
        {
            //PROCESS GET DATA
            DataTable dt = Client.GetAmphurByProvinceEng(provinceid); //GET ALL
            DataRow dr = dt.NewRow();
            dr["Amphur_EN"] = "Please Selected";
            dr["AmphurID"] = "00";  
            dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "Amphur_EN";
                ddl.DataValueField = "AmphurID"; 
                ddl.DataBind();
            }
        }
        catch (Exception ex)
        {
            Utilities.LogError(ex);
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    //PROCESS SET THAI TUMBOL TO DROPDOWNLIST FROM QUICKLINK DB
    protected void SetThaiTumbolToDropdownList(DropDownList ddl, string provinceid, string amphurid)
    {
        try
        {
            //PROCESS GET DATA
            DataTable dt = Client.GetTumbolByProvinceAndAmphurThai(provinceid, amphurid); //GET ALL
            DataRow dr = dt.NewRow();
            dr["Tumbol"] = "โปรดเลือก";
            dr["TumbolID"] = "00"; 
            dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "Tumbol";
                ddl.DataValueField = "TumbolID"; 
                ddl.DataBind();
            }
        }
        catch (Exception ex)
        {
            Utilities.LogError(ex);
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    //PROCESS SET ENG TUMBOL TO DROPDOWNLIST FROM QUICKLINK DB
    protected void SetEngTumbolToDropdownList(DropDownList ddl, string provinceid, string amphurid)
    {
        try
        {
            //PROCESS GET DATA
            DataTable dt = Client.GetTumbolByProvinceAndAmphurEng(provinceid, amphurid); //GET ALL
            DataRow dr = dt.NewRow();
            dr["Tumbol_EN"] = "Please Selected";
            dr["TumbolID"] = "00"; 
            dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "Tumbol_EN";
                ddl.DataValueField = "TumbolID"; 
                ddl.DataBind();
            }
        }
        catch (Exception ex)
        {
            Utilities.LogError(ex);
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    //PROCESS SET RELATION TO DROPDOWNLIST FROM  TABLE "TATBRelation" 
    protected void SetRelationToDropdownList(DropDownList ddl, string Lang)
    {
        try
        {
            //PROCESS GET DATA
            TATBRelationBLL clsrelation = new TATBRelationBLL();
            DataTable dt = clsrelation.GetDtTATBRelations(Lang); //GET ALL
            DataRow dr = dt.NewRow();
            if (Lang == "T")
            {
                dr["Relation"] = "โปรดเลือก";
            }
            else { 
                dr["Relation"] = "Please Selected"; 
            }
            dr["ID"] = "00";
            dt.Rows.InsertAt(dr, 0);
            if (dt.Rows.Count > 0)
            {
                ddl.DataSource = dt;
                ddl.DataTextField = "Relation";
                //ddl.DataValueField = "ID";
                ddl.DataValueField = "Relation";
                ddl.DataBind();
            }
        }
        catch (Exception ex)
        {
            Utilities.LogError(ex);
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }

    #endregion

    #region "BIND SET DEFAULT VALUES PREMIUM/COVARAGE"
    //PROCESS SET DEFAULT PREMIUM
    protected void SetDefaultPremium(string planid, int duration, string travelplan)
    {
        try
        {
            //TAPlanPremuimBLL planpremium = new TAPlanPremuimBLL();
            //TAPremuim premium = planpremium.GetTAPremuim(planid, duration, travelplan);
            //this.lblNetPremiumValue.Text = Utilities.StringFormatWithCommaEng(premium.NetPremium.Trim());
            //this.lblTaxValue.Text = Utilities.StringFormatWithCommaEng(premium.TAX.Trim());
            //this.lblStampDiutyValue.Text = Utilities.StringFormatWithCommaEng(premium.Stamp.Trim());
            //this.lblTotlaPremiumValue.Text = Utilities.StringFormatWithCommaEng(premium.Total.Trim());
            //this.lblPersonalAccidentValue.Text = Utilities.StringFormatWithCommaEng(premium.PersonalAccident.Trim());

            this.lblNetPremiumValue.Text = "";
            this.lblTaxValue.Text = "";
            this.lblStampDiutyValue.Text = "";
            this.lblTotlaPremiumValue.Text = "";
            this.lblPersonalAccidentValue.Text = "";

            TAPlanPremuimBLL planpremium = new TAPlanPremuimBLL();
            TAPremuim premium = planpremium.GetTAPremuim(planid, duration, travelplan);

            if (string.Concat(premium.NetPremium, premium.TAX, premium.Stamp, premium.Total) != string.Empty)
            {
                this.lblPersonalAccidentValue.Text = Utilities.StringFormatWithCommaEng(premium.PersonalAccident.Trim());

                double m_d_netpremium = double.Parse(premium.NetPremium.Trim());
                double m_d_tax = double.Parse(premium.TAX.Trim());
                double m_d_stamp = double.Parse(premium.Stamp.Trim());
                double m_d_total = double.Parse(premium.Total.Trim());

                double m_t_netpremium = m_d_netpremium;
                double m_t_tax = m_d_tax;
                double m_t_stamp = m_d_stamp;
                double m_t_total = m_d_total;

                string m_PolicyType = "";
                foreach (ListItem item in rdoPolicyType.Items)
                {
                    if (item.Selected)
                    {
                        m_PolicyType = item.Value.Trim();
                    }
                }

                if (m_PolicyType == TA.TAUtilities.PolicyType.Family.ToString())
                {

                    m_t_netpremium = m_d_netpremium * 2.00;
                    m_t_tax = m_d_tax * 2.00;
                    m_t_stamp = m_d_stamp * 2.00;
                    m_t_total = m_d_total * 2.00;

                    int m_allpeople = int.Parse(this.txtNumberOfChilden.Text) + 2;
                    if (m_allpeople > 4)
                    {
                        for (int p = 5; p <= m_allpeople; p++)
                        {
                            m_t_netpremium += m_d_netpremium / 2.00;
                            m_t_tax += m_d_tax / 2.00;
                            m_t_stamp += m_d_stamp / 2.00;
                            m_t_total += m_d_total / 2.00;
                        }
                    }
                }

                this.lblNetPremiumValue.Text = Utilities.StringFormatWithCommaEng(m_t_netpremium.ToString());
                this.lblTaxValue.Text = Utilities.StringFormatWithCommaEng(m_t_tax.ToString());
                this.lblStampDiutyValue.Text = Utilities.StringFormatWithCommaEng(m_t_stamp.ToString());
                this.lblTotlaPremiumValue.Text = Utilities.StringFormatWithCommaEng(m_t_total.ToString());
            }
        }
        catch (Exception ex)
        {
            Utilities.LogError(ex);
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }

    }
    //PROCESS SET DEFAULT COVERAGE
    protected void SetDefaultPlanCoverage(string planid)
    {
        try
        {
            TAPlanCoverageBLL plancoverage = new TAPlanCoverageBLL();
            DataTable dt = plancoverage.GetDtTAPlanCoverages(planid);
            if (dt.Rows.Count > 0)
            {
                DataTable dtageement = new DataTable();
                dtageement.Columns.Add("CoverageType", typeof(string));
                dtageement.Columns.Add("CoverageLine", typeof(string));
                dtageement.Columns.Add("CoverageDetailEN", typeof(string));
                dtageement.Columns.Add("CoverageDetailTH", typeof(string));
                dtageement.Columns.Add("CoveragePlan", typeof(string));

                foreach (DataRow dr in dt.Rows)
                {
                    if (dr["CoverageType"].ToString().Trim() == "AGREEMENT")
                    {
                        dtageement.Rows.Add(dr["CoverageType"], dr["CoverageLine"], dr["CoverageDetailEN"], dr["CoverageDetailTH"], dr["CoveragePlan"]);
                    }
                    else
                    {
                        //INSERT TABLE REMARKS
                        TableRow tr = new TableRow();
                        TableCell tc = new TableCell();
                        tc.Text = dr["CoverageDetailTH"].ToString() + "<br>" + dr["CoverageDetailEN"].ToString();
                        tr.Cells.Add(tc);
                        tblCoverageRemark.Rows.Add(tr);
                    }
                }
                gdvCoverage.DataSource = dtageement;//dt;
                gdvCoverage.DataBind();
            }
            else
            {
                gdvCoverage.DataSource = null;
                gdvCoverage.DataBind();
            }
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    #endregion

    #region "Gennerate Traveler by Number of Childen"
    protected void btnNumberOfChilden_ServerClick(object sender, EventArgs e)
    {

    }
    private void GenerateDynamicTraveler()
    {
        this.divTravelerParent.Controls.Clear();
        if (this.txtNumberOfChilden.Text.Trim() == string.Empty) return;

        if (!string.IsNullOrEmpty(this.txtNumberOfChilden.Text))
        {
            if (this.txtNumberOfChilden.Text.Trim() == "0" || Convert.ToInt32(this.txtNumberOfChilden.Text.Trim()) == 0)
            {
                return;
            }
            else
            {
                int NumberOfChilden = Convert.ToInt32(this.txtNumberOfChilden.Text);
                for (int i = 0; i < NumberOfChilden; i++)
                {
                    int code = i + 3;

                    HtmlGenericControl h6 = new HtmlGenericControl("h6");
                    h6.InnerText = "Traveler " + code + " /ผู้เดินทางคนที่ " + code;

                    this.divTravelerParent.Controls.Add(h6);

                    HtmlGenericControl div = new HtmlGenericControl("div");
                    this.divTravelerParent.Controls.Add(div);

                    HtmlTable tableTaveler = new HtmlTable();
                    tableTaveler.Align = "center";
                    tableTaveler.Width = "98%";

                    div.Controls.Add(tableTaveler);

                    #region Table Traveler
                    HtmlTableRow tableTaveler_tr = new HtmlTableRow();
                    tableTaveler.Controls.Add(tableTaveler_tr);

                    //-------------- TravelerTitle ----------------------
                    HtmlTableCell tableTaveler_tdTitle = new HtmlTableCell();
                    tableTaveler_tdTitle.Align = "left";

                    Label lblTravelerTitle = new Label();
                    lblTravelerTitle.Font.Bold = true;
                    lblTravelerTitle.ID = "lblTraveler" + code + "Title";
                    lblTravelerTitle.Text = "<font color=red>*</font>&nbsp;" + "Title : <br />&nbsp;&nbsp;&nbsp;";

                    Label lblTravelerTitleTh = new Label();
                    lblTravelerTitleTh.Font.Bold = true;
                    lblTravelerTitleTh.Font.Size = FontUnit.Point(8);
                    lblTravelerTitleTh.ID = "lblTraveler" + code + "Title_th";
                    lblTravelerTitleTh.Text = "คำนำหน้าชื่อ <br />";

                    DropDownList ddlTravelerTitle = new DropDownList();
                    ddlTravelerTitle.Width = 110;
                    ddlTravelerTitle.ID = "ddlTraveler" + code + "Title";
                    if (this.ddlLanguage.SelectedValue == "E")
                    {
                        SetTitleToDropdownList(ddlTravelerTitle);
                    }
                    else
                    {
                        SetThaiTitleToDropdownList(ddlTravelerTitle);
                    }
                    ddlTravelerTitle.SelectedValue = Request.Form["ctl00$MainContent$ddlTraveler" + code + "Title"];

                    //-------VVVVVVVVVVVVVVVVVVVVVVVVVVV------------
                   

                    tableTaveler_tdTitle.Controls.Add(lblTravelerTitle);
                    tableTaveler_tdTitle.Controls.Add(lblTravelerTitleTh);
                    tableTaveler_tdTitle.Controls.Add(ddlTravelerTitle);

                    tableTaveler_tr.Controls.Add(tableTaveler_tdTitle);

                    //-------------- TravelerName -----------------------
                    HtmlTableCell tableTaveler_tdName = new HtmlTableCell();
                    tableTaveler_tdName.Align = "left";

                    Label lblTravelerName = new Label();
                    lblTravelerName.Font.Bold = true;
                    lblTravelerName.ID = "lblTraveler" + code + "Name";
                    lblTravelerName.Text = "<font color=red>*</font>&nbsp;" + "Name : <br/>&nbsp;&nbsp;&nbsp;";

                    Label lblTravelerNameTh = new Label();
                    lblTravelerNameTh.Font.Bold = true;
                    lblTravelerNameTh.Font.Size = FontUnit.Point(8);
                    lblTravelerNameTh.ID = "lblTraveler" + code + "Name_th";
                    lblTravelerNameTh.Text = "ชื่อ <br />";

                    HtmlInputText txtTravelerName = new HtmlInputText();
                    txtTravelerName.MaxLength = 60;
                    txtTravelerName.Style.Add("width", "195px");
                    txtTravelerName.ID = "txtTraveler" + code + "Name";
                    txtTravelerName.Value = Request.Form["ctl00$MainContent$ddlTraveler" + code + "Name"];

                    tableTaveler_tdName.Controls.Add(lblTravelerName);
                    tableTaveler_tdName.Controls.Add(lblTravelerNameTh);
                    tableTaveler_tdName.Controls.Add(txtTravelerName);

                    tableTaveler_tr.Controls.Add(tableTaveler_tdName);

                    //-------------- TravelerSurname -----------------------
                    HtmlTableCell tableTaveler_tdSurname = new HtmlTableCell();
                    tableTaveler_tdSurname.Align = "left";

                    Label lblTravelerSurname = new Label();
                    lblTravelerSurname.Font.Bold = true;
                    lblTravelerSurname.ID = "lblTraveler" + code + "Surname";
                    lblTravelerSurname.Text = "Family name : <br/>";

                    Label lblTravelerSurnameTh = new Label();
                    lblTravelerSurnameTh.Font.Bold = true;
                    lblTravelerSurnameTh.Font.Size = FontUnit.Point(8);
                    lblTravelerSurnameTh.ID = "lblTraveler" + code + "Surname_th";
                    lblTravelerSurnameTh.Text = "นามสกุล <br />";

                    HtmlInputText txtTravelerSurname = new HtmlInputText();
                    txtTravelerSurname.MaxLength = 60;
                    txtTravelerSurname.Style.Add("width", "195px");
                    txtTravelerSurname.ID = "txtTraveler" + code + "Surname";
                    txtTravelerSurname.Value = Request.Form["ctl00$MainContent$ddlTraveler" + code + "Surname"];

                    tableTaveler_tdSurname.Controls.Add(lblTravelerSurname);
                    tableTaveler_tdSurname.Controls.Add(lblTravelerSurnameTh);
                    tableTaveler_tdSurname.Controls.Add(txtTravelerSurname);

                    tableTaveler_tr.Controls.Add(tableTaveler_tdSurname);

                    //-------------- TravelerBirthday -----------------------
                    HtmlTableCell tableTaveler_tdBirthday = new HtmlTableCell();
                    tableTaveler_tdBirthday.Align = "left";

                    Label lblTravelerBirthday = new Label();
                    lblTravelerBirthday.Font.Bold = true;
                    lblTravelerBirthday.ID = "lblTraveler" + code + "Birthday";
                    lblTravelerBirthday.Text = "<font color=red>*</font>&nbsp;" + "DOB : <br/>&nbsp;&nbsp;&nbsp;";

                    Label lblTravelerBirthdayTh = new Label();
                    lblTravelerBirthdayTh.Font.Bold = true;
                    lblTravelerBirthdayTh.Font.Size = FontUnit.Point(8);
                    lblTravelerBirthdayTh.ID = "lblTraveler" + code + "Birthday_th";
                    lblTravelerBirthdayTh.Text = "วัน เดือน ปี เกิด <br />";

                    HtmlInputText txtTravelerBirthday = new HtmlInputText();
                    txtTravelerBirthday.ID = "txtTraveler" + code + "Birthday";
                    txtTravelerBirthday.MaxLength = 10;
                    txtTravelerBirthday.Style.Add("width", "80px");
                    txtTravelerBirthday.Value = Request.Form["ctl00$MainContent$ddlTraveler" + code + "Birthday"];

                    tableTaveler_tdBirthday.Controls.Add(lblTravelerBirthday);
                    tableTaveler_tdBirthday.Controls.Add(lblTravelerBirthdayTh);
                    tableTaveler_tdBirthday.Controls.Add(txtTravelerBirthday);

                    tableTaveler_tr.Controls.Add(tableTaveler_tdBirthday);

                    //--------------  TravelerPassportNo -----------------------
                    HtmlTableCell tableTaveler_tdPassportNo = new HtmlTableCell();
                    tableTaveler_tdPassportNo.Align = "left";

                    Label lblTravelerPassportNo = new Label();
                    lblTravelerPassportNo.Font.Bold = true;
                    lblTravelerPassportNo.ID = "lblTraveler" + code + "PassportNo";
                    lblTravelerPassportNo.Text = "<font color=red>*</font>&nbsp;" + "Passport No : <br/>&nbsp;&nbsp;&nbsp;";

                    Label lblTravelerPassportNoTh = new Label();
                    lblTravelerPassportNoTh.Font.Bold = true;
                    lblTravelerPassportNoTh.Font.Size = FontUnit.Point(8);
                    lblTravelerPassportNoTh.ID = "lblTraveler" + code + "PassportNo_th";
                    lblTravelerPassportNoTh.Text = "เลขที่หนังสือเดินทาง <br />";

                    HtmlInputText txtTravelerPassportNo = new HtmlInputText();
                    txtTravelerPassportNo.ID = "txtTraveler" + code + "PassportNo";
                    txtTravelerPassportNo.Style.Add("width", "120px");
                    txtTravelerPassportNo.MaxLength = 13;
                    txtTravelerPassportNo.Value = Request.Form["ctl00$MainContent$ddlTraveler" + code + "PassportNo"];

                    tableTaveler_tdPassportNo.Controls.Add(lblTravelerPassportNo);
                    tableTaveler_tdPassportNo.Controls.Add(lblTravelerPassportNoTh);
                    tableTaveler_tdPassportNo.Controls.Add(txtTravelerPassportNo);

                    tableTaveler_tr.Controls.Add(tableTaveler_tdPassportNo);

                    //--------------  TravelerTel -----------------------
                    HtmlTableCell tableTaveler_tdTel = new HtmlTableCell();
                    tableTaveler_tdTel.Align = "left";

                    Label lblTravelerTel = new Label();
                    lblTravelerTel.Font.Bold = true;
                    lblTravelerTel.ID = "lblTraveler" + code + "Tel";
                    lblTravelerTel.Text = "<font color=red>*</font>&nbsp;" + "Tel : <br/>&nbsp;&nbsp;&nbsp;";

                    Label lblTravelerTelTh = new Label();
                    lblTravelerTelTh.Font.Bold = true;
                    lblTravelerTelTh.Font.Size = FontUnit.Point(8);
                    lblTravelerTelTh.ID = "lblTraveler" + code + "Tel_th";
                    lblTravelerTelTh.Text = "เบอร์โทรศัพท์ <br />";

                    HtmlInputText txtTravelerTel = new HtmlInputText();
                    txtTravelerTel.ID = "txtTraveler" + code + "Tel";
                    txtTravelerTel.Style.Add("width", "120px");
                    txtTravelerTel.MaxLength = 30;
                    txtTravelerTel.Value = Request.Form["ctl00$MainContent$ddlTraveler" + code + "Tel"];

                    tableTaveler_tdTel.Controls.Add(lblTravelerTel);
                    tableTaveler_tdTel.Controls.Add(lblTravelerTelTh);
                    tableTaveler_tdTel.Controls.Add(txtTravelerTel);

                    tableTaveler_tr.Controls.Add(tableTaveler_tdTel);

                    //--------------  lblTraveler1Email -----------------------
                    //HtmlTableCell tableTaveler_tdEmail = new HtmlTableCell();
                    //tableTaveler_tdEmail.Align = "left";

                    //Label lblTravelerEmail = new Label();
                    //lblTravelerEmail.Font.Bold = true;
                    //lblTravelerEmail.ID = "lblTraveler" + code + "Email";
                    //lblTravelerEmail.Text = "Email : ";

                    //HtmlInputText txtTravelerEmail = new HtmlInputText();
                    //txtTravelerEmail.ID = "txtTraveler" + code + "Email";
                    //txtTravelerEmail.Style.Add("width", "80px");
                    //txtTravelerEmail.MaxLength = 30;

                    //tableTaveler_tdEmail.Controls.Add(lblTravelerEmail);
                    //tableTaveler_tdEmail.Controls.Add(txtTravelerEmail);

                    //tableTaveler_tr.Controls.Add(tableTaveler_tdEmail);

                    //>>>>>>>>>>>>>>>  new rows -----------------------

                    HtmlTableRow tableTaveler_tr2 = new HtmlTableRow();
                    tableTaveler.Controls.Add(tableTaveler_tr2);

                    HtmlTableCell tableTaveler_td6 = new HtmlTableCell();
                    tableTaveler_td6.ColSpan = 6;
                    tableTaveler_td6.Align = "right";
                    tableTaveler_tr2.Controls.Add(tableTaveler_td6);

                    //-------------- TravelerOccupation -----------------------

                   
                    HtmlTable tableTravelerOcc = new HtmlTable();
                    tableTravelerOcc.CellPadding = 2;
                    tableTravelerOcc.CellSpacing = 0;

                    tableTaveler_td6.Controls.Add(tableTravelerOcc);

                    HtmlTableRow tableTravelerOcc_row = new HtmlTableRow();
                    tableTravelerOcc.Controls.Add(tableTravelerOcc_row);

                    HtmlTableCell tableTaveler_tdOccupation1 = new HtmlTableCell();
                    tableTaveler_tdOccupation1.Align = "right";


                    Label lblTravelerOccupation = new Label();
                    lblTravelerOccupation.Font.Bold = true;
                    lblTravelerOccupation.ID = "lblTraveler" + code + "Occupation";
                    lblTravelerOccupation.Text = "Occupation : <br/>";

                    Label lblTravelerOccupationTh = new Label();
                    lblTravelerOccupationTh.Font.Bold = true;
                    lblTravelerOccupationTh.Font.Size = FontUnit.Point(8);
                    lblTravelerOccupationTh.ID = "lblTraveler" + code + "Occupation_th";
                    lblTravelerOccupationTh.Text = "อาชีพ";

                    HtmlTableCell tableTaveler_tdOccupation2 = new HtmlTableCell();
                    tableTaveler_tdOccupation2.Align = "left";
                    tableTaveler_tdOccupation2.VAlign = "top";

                    CheckBox chkTravelerOccupation = new CheckBox();
                    chkTravelerOccupation.ID = "chkTraveler" + code + "Occupation";
                    chkTravelerOccupation.Text = "Student";
                    if (!string.IsNullOrEmpty(Request.Form["ctl00$MainContent$chkTraveler" + code + "Occupation"]))
                    {
                        chkTravelerOccupation.Checked = true;
                    }
                    else
                    {
                        chkTravelerOccupation.Checked = false;
                    }

                    HtmlAnchor br = new HtmlAnchor();
                    br.InnerHtml = "<br/>";

                    tableTaveler_tdOccupation1.Controls.Add(lblTravelerOccupation);
                    tableTaveler_tdOccupation1.Controls.Add(lblTravelerOccupationTh);

                    tableTaveler_tdOccupation2.Controls.Add(chkTravelerOccupation);

                    tableTravelerOcc_row.Controls.Add(tableTaveler_tdOccupation1);
                    tableTravelerOcc_row.Controls.Add(tableTaveler_tdOccupation2);

                    //-------------- TravelerStatus -----------------------
                    HtmlTableRow tableTravelerStatus_row = new HtmlTableRow();
                    tableTravelerOcc.Controls.Add(tableTravelerStatus_row);

                    HtmlTableCell tableTaveler_tdStatus1 = new HtmlTableCell();
                    tableTaveler_tdStatus1.Align = "right";

                    Label lblTravelerStatus = new Label();
                    lblTravelerStatus.Font.Bold = true;
                    lblTravelerStatus.ID = "lblTraveler" + code + "Status";
                    lblTravelerStatus.Text = "Status : <br/>";

                    Label lblTravelerStatusTh = new Label();
                    lblTravelerStatusTh.Font.Bold = true;
                    lblTravelerStatusTh.Font.Size = FontUnit.Point(8);
                    lblTravelerStatusTh.ID = "lblTraveler" + code + "Status_th";
                    lblTravelerStatusTh.Text = "สถานะ ";

                    HtmlTableCell tableTaveler_tdStatus2 = new HtmlTableCell();
                    tableTaveler_tdStatus2.Align = "left";
                    tableTaveler_tdStatus2.VAlign = "top";
                    tableTaveler_tdStatus2.Width = "80px";

                    CheckBox chkTravelerStatus = new CheckBox();
                    chkTravelerStatus.ID = "chkTraveler" + code + "Status";
                    chkTravelerStatus.Text = "Single";
                    if (!string.IsNullOrEmpty(Request.Form["ctl00$MainContent$chkTraveler" + code + "Status"]))
                    {
                        chkTravelerStatus.Checked = true;
                    }
                    else
                    {
                        chkTravelerStatus.Checked = false;
                    }

                    tableTaveler_tdStatus1.Controls.Add(lblTravelerStatus);
                    tableTaveler_tdStatus1.Controls.Add(lblTravelerStatusTh);
                    tableTaveler_tdStatus2.Controls.Add(chkTravelerStatus);

                    tableTravelerStatus_row.Controls.Add(tableTaveler_tdStatus1);
                    tableTravelerStatus_row.Controls.Add(tableTaveler_tdStatus2);

                    //-----------------end table 1-----------------------------
                    #endregion

                    //------------------table Beneficialy---------------------
                    HtmlTable tableBeneficialy1 = new HtmlTable();
                    tableBeneficialy1.Align = "center";
                    tableBeneficialy1.Width = "80%";

                    div.Controls.Add(tableBeneficialy1);

                    #region Table Beneficialy 1
                    //-------------- Beneficialy row 1----------------------
                    HtmlTableRow tableBeneficialy1_tr = new HtmlTableRow();

                    tableBeneficialy1.Controls.Add(tableBeneficialy1_tr);

                    HtmlTableCell tableBeneficialy1_tdBeneficialy = new HtmlTableCell();
                    tableBeneficialy1_tdBeneficialy.Align = "left";
                    tableBeneficialy1_tdBeneficialy.Width = "90px";

                    Label lblTravelerBeneficialy = new Label();
                    lblTravelerBeneficialy.ID = "lblTraveler" + code + "Beneficialy";
                    lblTravelerBeneficialy.Font.Bold = true;
                    lblTravelerBeneficialy.Text = "Beneficiary :";

                    HtmlAnchor tagA = new HtmlAnchor();
                    tagA.InnerHtml = "<br/>";

                    Label lblTravelerBeneficialyTh = new Label();
                    lblTravelerBeneficialyTh.ID = "lblTraveler" + code + "Beneficialy_th";
                    lblTravelerBeneficialyTh.Font.Bold = true;
                    lblTravelerBeneficialyTh.Font.Size = FontUnit.Point(8);
                    lblTravelerBeneficialyTh.Text = "ผู้รับประโยชน์";

                    tableBeneficialy1_tdBeneficialy.Controls.Add(lblTravelerBeneficialy);
                    tableBeneficialy1_tdBeneficialy.Controls.Add(tagA);
                    tableBeneficialy1_tdBeneficialy.Controls.Add(lblTravelerBeneficialyTh);

                    tableBeneficialy1_tr.Controls.Add(tableBeneficialy1_tdBeneficialy);

                    HtmlTableCell tableBeneficialy1_tdBeneficialyHeir = new HtmlTableCell();
                    tableBeneficialy1_tdBeneficialyHeir.Align = "left";
                    tableBeneficialy1_tdBeneficialyHeir.VAlign = "top";

                    CheckBox chkTravelerBeneficialyHeir = new CheckBox();
                    chkTravelerBeneficialyHeir.ID = "chkTraveler" + code +"BeneficialyHeir";

                    chkTravelerBeneficialyHeir.Text = "&nbsp;Estate of the Insured person /กองมรดกของผู้เอาประกันภัย";

                    if (Request.Form["ctl00$MainContent$chkTraveler" + code + "BeneficialyHeir"] == "")
                    {
                        chkTravelerBeneficialyHeir.Checked = Convert.ToBoolean(Request.Form["ctl00$MainContent$chkTraveler" + code + "BeneficialyHeir"]);
                    }
                    else
                    {
                        chkTravelerBeneficialyHeir.Checked = true;
                    }

                    tableBeneficialy1_tdBeneficialyHeir.Controls.Add(chkTravelerBeneficialyHeir);

                    tableBeneficialy1_tr.Controls.Add(tableBeneficialy1_tdBeneficialyHeir);

                    #endregion

                    #region Table Beneficialy 2
                    //----------------Beneficialy row 2---------------------

                    HtmlTable tableBeneficialy2 = new HtmlTable();
                    tableBeneficialy2.Align = "center";
                    tableBeneficialy2.Width = "80%";

                    div.Controls.Add(tableBeneficialy2);

                    HtmlTableRow tableBeneficialy2_tr = new HtmlTableRow();

                    tableBeneficialy2.Controls.Add(tableBeneficialy2_tr);
                    for (int j = 1; j < 4; j++)
                    {
                        HtmlTableRow tableBeneficialy2_tr2 = new HtmlTableRow();
                        tableBeneficialy2.Controls.Add(tableBeneficialy2_tr2);

                        //---------------------- lblTraveler1BeneficialyTitle1- ---------------
                        HtmlTableCell tableBeneficialy2_tdBeneficialyTitle = new HtmlTableCell();
                        tableBeneficialy2_tdBeneficialyTitle.Align = "left";

                        Label lblTravelerBeneficialyTitle = new Label();
                        lblTravelerBeneficialyTitle.ID = "lblTraveler" + code + "BeneficialyTitle" + j.ToString();
                        lblTravelerBeneficialyTitle.Font.Bold = true;
                        lblTravelerBeneficialyTitle.Text = "<font color=red>*</font>&nbsp;" + "Title : <br/>&nbsp;&nbsp;&nbsp;";

                        Label lblTravelerBeneficialyTitleTh = new Label();
                        lblTravelerBeneficialyTitleTh.ID = "lblTraveler" + code + "BeneficialyTitle" + j.ToString() + "_th";
                        lblTravelerBeneficialyTitleTh.Font.Bold = true;
                        lblTravelerBeneficialyTitleTh.Font.Size = FontUnit.Point(8);
                        lblTravelerBeneficialyTitleTh.Text = "คำนำหน้าชื่อ <br/>";

                        DropDownList ddlTravelerBeneficialyTitle = new DropDownList();
                        ddlTravelerBeneficialyTitle.Width = 110;
                        ddlTravelerBeneficialyTitle.ID = "ddlTraveler" + code + "BeneficialyTitle" + j.ToString();
                        if (this.ddlLanguage.SelectedValue == "E")
                        {
                            SetTitleToDropdownList(ddlTravelerBeneficialyTitle);
                        }
                        else
                        {
                            SetThaiTitleToDropdownList(ddlTravelerBeneficialyTitle);
                        }
                        ddlTravelerBeneficialyTitle.SelectedValue = Request.Form["ctl00$MainContent$ddlTraveler" + code + "BeneficialyTitle" + j.ToString()];

                        //-------VVVVVVVVVVVVVVVVVVVVVVVVVVV------------
                        
                        if (j == 1)
                        {
                            tableBeneficialy2_tdBeneficialyTitle.Controls.Add(lblTravelerBeneficialyTitle);
                            tableBeneficialy2_tdBeneficialyTitle.Controls.Add(lblTravelerBeneficialyTitleTh);
                            //br = new HtmlAnchor();
                            //br.InnerHtml = "<br/>";
                            //tableBeneficialy_tdBeneficialyTitle.Controls.Add(br);
                        }
                        tableBeneficialy2_tdBeneficialyTitle.Controls.Add(ddlTravelerBeneficialyTitle);

                        tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyTitle);

                        //---------------------- lblTraveler1BeneficialyName1- ---------------
                        HtmlTableCell tableBeneficialy2_tdBeneficialyName = new HtmlTableCell();
                        tableBeneficialy2_tdBeneficialyName.Align = "left";

                        Label lblTravelerBeneficialyName = new Label();
                        lblTravelerBeneficialyName.ID = "lblTraveler" + code + "BeneficialyName" + j.ToString();
                        lblTravelerBeneficialyName.Font.Bold = true;
                        lblTravelerBeneficialyName.Text = "<font color=red>*</font>&nbsp;" + "Name : <br/>&nbsp;&nbsp;&nbsp;";

                        Label lblTravelerBeneficialyNameTh = new Label();
                        lblTravelerBeneficialyNameTh.ID = "lblTraveler" + code + "BeneficialyName" + j.ToString() + "_th";
                        lblTravelerBeneficialyNameTh.Font.Bold = true;
                        lblTravelerBeneficialyNameTh.Font.Size = FontUnit.Point(8);
                        lblTravelerBeneficialyNameTh.Text = "ชื่อ <br/>";

                        HtmlInputText txtTravelerBeneficialyName = new HtmlInputText();
                        txtTravelerBeneficialyName.MaxLength = 100;
                        txtTravelerBeneficialyName.Style.Add("width", "195px");
                        txtTravelerBeneficialyName.ID = "txtTraveler" + code + "BeneficialyName" + j.ToString();
                        txtTravelerBeneficialyName.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialyName" + j.ToString()];

                        if (j == 1)
                        {
                            tableBeneficialy2_tdBeneficialyName.Controls.Add(lblTravelerBeneficialyName);
                            tableBeneficialy2_tdBeneficialyName.Controls.Add(lblTravelerBeneficialyNameTh);
                            //br = new HtmlAnchor();
                            //br.InnerHtml = "<br/>";
                            //tableBeneficialy_tdBeneficialyName.Controls.Add(br);
                        }
                        tableBeneficialy2_tdBeneficialyName.Controls.Add(txtTravelerBeneficialyName);

                        tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyName);

                        //---------------------- lblTraveler1BeneficialySurname1- ---------------
                        HtmlTableCell tableBeneficialy2_tdBeneficialySurname = new HtmlTableCell();
                        tableBeneficialy2_tdBeneficialySurname.Align = "left";

                        Label lblTravelerBeneficialySurname = new Label();
                        lblTravelerBeneficialySurname.ID = "lblTraveler" + code + "BeneficialySurname" + j.ToString();
                        lblTravelerBeneficialySurname.Font.Bold = true;
                        lblTravelerBeneficialySurname.Text = "<font color=red>*</font>&nbsp;" + "Family name : <br/>&nbsp;&nbsp;&nbsp;";

                        Label lblTravelerBeneficialySurnameTh = new Label();
                        lblTravelerBeneficialySurnameTh.ID = "lblTraveler" + code + "BeneficialySurname" + j.ToString() + "_th";
                        lblTravelerBeneficialySurnameTh.Font.Bold = true;
                        lblTravelerBeneficialySurnameTh.Font.Size = FontUnit.Point(8);
                        lblTravelerBeneficialySurnameTh.Text = "นามสกุล <br/>";

                        HtmlInputText txtTravelerBeneficialySurname = new HtmlInputText();
                        txtTravelerBeneficialySurname.Style.Add("width", "195px");
                        txtTravelerBeneficialySurname.ID = "txtTraveler" + code + "BeneficialySurname" + j.ToString();
                        txtTravelerBeneficialySurname.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialySurname" + j.ToString()];


                        if (j == 1)
                        {
                            tableBeneficialy2_tdBeneficialySurname.Controls.Add(lblTravelerBeneficialySurname);
                            tableBeneficialy2_tdBeneficialySurname.Controls.Add(lblTravelerBeneficialySurnameTh);
                            //br = new HtmlAnchor();
                            //br.InnerHtml = "<br/>";
                            //tableBeneficialy_tdBeneficialySurname.Controls.Add(br);
                        }
                        tableBeneficialy2_tdBeneficialySurname.Controls.Add(txtTravelerBeneficialySurname);

                        tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialySurname);

                        //---------------------- lblTraveler1BeneficialyRelationShip1- ---------------
                        HtmlTableCell tableBeneficialy2_tdBeneficialyRelationShip = new HtmlTableCell();
                        tableBeneficialy2_tdBeneficialyRelationShip.Align = "left";

                        Label lblTravelerBeneficialyRelationShip = new Label();
                        lblTravelerBeneficialyRelationShip.ID = "lblTraveler" + code + "BeneficialyRelationShip" + j.ToString();
                        lblTravelerBeneficialyRelationShip.Font.Bold = true;
                        lblTravelerBeneficialyRelationShip.Text = "RelationShip : <br/>";

                        Label lblTravelerBeneficialyRelationShipTh = new Label();
                        lblTravelerBeneficialyRelationShipTh.ID = "lblTraveler" + code + "BeneficialyRelationShip" + j.ToString() + "_th";
                        lblTravelerBeneficialyRelationShipTh.Font.Bold = true;
                        lblTravelerBeneficialyRelationShipTh.Font.Size = FontUnit.Point(8);
                        lblTravelerBeneficialyRelationShipTh.Text = "ความสัมพันธ์<br/>";

                        DropDownList ddlTravelerBeneficialyRelationShip = new DropDownList();
                        ddlTravelerBeneficialyRelationShip.ID = "ddlTraveler" + code + "BeneficialyRelationShip" + j.ToString();
                        ddlTravelerBeneficialyRelationShip.Style.Add("width", "150px");

                        SetRelationToDropdownList(ddlTravelerBeneficialyRelationShip, ddlLanguage.SelectedValue.ToString());
                        ddlTravelerBeneficialyRelationShip.SelectedValue = Request.Form["ctl00$MainContent$ddlTraveler" + code + "BeneficialyRelationShip" + j.ToString()];
                        //-------VVVVVVVVVVVVVVVVVVVVVVVVVVV------------
                        

                        if (j == 1)
                        {
                            tableBeneficialy2_tdBeneficialyRelationShip.Controls.Add(lblTravelerBeneficialyRelationShip);
                            tableBeneficialy2_tdBeneficialyRelationShip.Controls.Add(lblTravelerBeneficialyRelationShipTh);
                            //br = new HtmlAnchor();
                            //br.InnerHtml = "<br/>";
                            //tableBeneficialy_tdBeneficialyRelationShip.Controls.Add(br);
                        }
                        tableBeneficialy2_tdBeneficialyRelationShip.Controls.Add(ddlTravelerBeneficialyRelationShip);

                        tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyRelationShip);

                        #region #//Part of Traveler Beneficiary Ratio
                        HtmlTableCell tableBeneficialy2_tdBeneficialyRatio = new HtmlTableCell();
                        tableBeneficialy2_tdBeneficialyRatio.Align = "left";

                        Label lblTravelerBeneficialyRatio = new Label();
                        lblTravelerBeneficialyRatio.ID = "lblTraveler" + code + "BeneficialyRatio" + j.ToString();
                        lblTravelerBeneficialyRatio.Font.Bold = true;
                        lblTravelerBeneficialyRatio.Text = "<font color=red>*</font>&nbsp;" + "Ratio : <br/>";
                         
                        Label lblTravelerBeneficialyRatioTh = new Label();
                        lblTravelerBeneficialyRatioTh.ID = "lblTraveler" + code + "BeneficialyRatio" + j.ToString() + "_th";
                        lblTravelerBeneficialyRatioTh.Font.Bold = true;
                        lblTravelerBeneficialyRatioTh.Font.Size = FontUnit.Point(8);
                        lblTravelerBeneficialyRatioTh.Text = "&nbsp;&nbsp;&nbsp;&nbsp;สัดส่วน(%)<br/>";

                        HtmlInputText txtTravelerBeneficialyRatio = new HtmlInputText();
                        txtTravelerBeneficialyRatio.ID = "txtTraveler" + code + "BeneficialyRatio" + j.ToString();
                        txtTravelerBeneficialyRatio.Style.Add("width", "70px");
                        txtTravelerBeneficialyRatio.MaxLength = 3;
                        txtTravelerBeneficialyRatio.Attributes.Add("onkeypress", "return numbersonly(event);");
                        txtTravelerBeneficialyRatio.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialyRatio" + j.ToString()];

                        if (j == 1)
                        {
                            tableBeneficialy2_tdBeneficialyRatio.Controls.Add(lblTravelerBeneficialyRatio);
                            tableBeneficialy2_tdBeneficialyRatio.Controls.Add(lblTravelerBeneficialyRatioTh);                            
                        }

                        tableBeneficialy2_tdBeneficialyRatio.Controls.Add(txtTravelerBeneficialyRatio);

                        tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyRatio);

                        #endregion

                        //---------------------- lblTraveler1BeneficialyTel1- ---------------
                        HtmlTableCell tableBeneficialy2_tdBeneficialyTel = new HtmlTableCell();
                        tableBeneficialy2_tdBeneficialyTel.Align = "left";

                        Label lblTravelerBeneficialyTel = new Label();
                        lblTravelerBeneficialyTel.ID = "lblTraveler" + code + "BeneficialyTel" + j.ToString();
                        lblTravelerBeneficialyTel.Font.Bold = true;
                        lblTravelerBeneficialyTel.Text = "Tel : <br/>";

                        Label lblTravelerBeneficialyTelTh = new Label();
                        lblTravelerBeneficialyTelTh.ID = "lblTraveler" + code + "BeneficialyTel" + j.ToString() + "_th";
                        lblTravelerBeneficialyTelTh.Font.Bold = true;
                        lblTravelerBeneficialyTelTh.Font.Size = FontUnit.Point(8);
                        lblTravelerBeneficialyTelTh.Text = "เบอร์โทรศัพท์<br/>";

                        HtmlInputText txtTravelerBeneficialyTel = new HtmlInputText();
                        txtTravelerBeneficialyTel.ID = "txtTraveler" + code + "BeneficialyTel" + j.ToString();
                        txtTravelerBeneficialyTel.Style.Add("width", "120px");
                        txtTravelerBeneficialyTel.MaxLength = 100;
                        txtTravelerBeneficialyTel.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialyTel" + j.ToString()];


                        if (j == 1)
                        {
                            tableBeneficialy2_tdBeneficialyTel.Controls.Add(lblTravelerBeneficialyTel);
                            tableBeneficialy2_tdBeneficialyTel.Controls.Add(lblTravelerBeneficialyTelTh);
                            //br = new HtmlAnchor();
                            //br.InnerHtml = "<br/>";
                            //tableBeneficialy_tdBeneficialyTel.Controls.Add(br);
                        }
                        tableBeneficialy2_tdBeneficialyTel.Controls.Add(txtTravelerBeneficialyTel);

                        tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyTel);

                    }

                    #endregion

                }

                
            }
        }
    }
    private void RemoveDynamicTravelerControl()
    {
        this.divTravelerParent.Controls.Clear();
        ViewState["test"] = null;
        
    }
    #endregion

    #region "Condition Method Zone"
    protected void ValidateRelationofTravelPlanAndPolicyType()
    {
        if (string.Compare(this.rdoTravelPlan.SelectedValue.Trim(), "Annual") == 0)
        {
            if (string.Compare(this.rdoPolicyType.SelectedValue.Trim(), "Family") == 0)
            {
                //this.lblErrorMessage.Text = "กรณีเลือก Travel Plan เป็นแบบ Annual ไม่สามารถเลือก Policy Type แบบ Family ได้!!!";
                //this.lblInformMessage.Text = "";
                this.rdoPolicyType.SelectedValue = "Individual";
                this.lblValidateRelationofTravelPlanAndPolicyTypeShow.Visible = true;
                this.lblValidateRelationofTravelPlanAndPolicyTypeShow.Text = "***กรณีเลือก Travel Plan เป็นแบบ Annual ไม่สามารถเลือก Policy Type แบบ Family ได้!!!";
                return;
            }
        }
    }
    protected void ValidateSingleTripNumOfDays()
    {
        if (string.Compare(this.rdoTravelPlan.SelectedValue.Trim(), "Single") == 0)
        {
            if (!string.IsNullOrEmpty(this.txtEffectiveDateFrom.Text) && !string.IsNullOrEmpty(this.txtEffectiveDateTo.Text))
            {
                DateTime dt1 = TA.TAUtilities.CheckCultureAndConvertToDateTime(this.txtEffectiveDateFrom.Text.Trim());
                DateTime dt2 = TA.TAUtilities.CheckCultureAndConvertToDateTime(this.txtEffectiveDateTo.Text.Trim());

                long numOfDays = TA.TAUtilities.DateDiff(TA.TAUtilities.DateInterval.Day, dt1, dt2);
				
                if (numOfDays > 180)  //change from 90 to 180 @ 2013-10-24
                {
                    this.lblValidateSingleTripNumOfDays.Visible = true;
                    this.lblValidateSingleTripNumOfDays.Text = "***กรณี Single Trip ไม่สามารถเดินทางเกิน 180 วันได้!!!";
                    this.txtEffectiveDateTo.Text = "";
                    this.txtDuration.Value = "";
                }
            }
        }
    }
    protected void ShowHideTraveler2Zone()
    {
        if (this.rdoPolicyType.SelectedValue.Trim() == "Individual")
        {
            this.headTraveler2.Visible = false;
            this.traveler2Zone.Visible = false;
            this.txtNumberOfChilden.Text = "0";
            this.txtNumberOfChilden.Enabled = false;
        }
        else
        {
            this.headTraveler2.Visible = true;
            this.traveler2Zone.Visible = true;
            this.txtNumberOfChilden.Enabled = true;
        }
    }
    protected bool IsBirthDayOverLimitOfEffectiveDate(int nminday, int nmaxday, DateTime birthday, DateTime effdatefrom)
    {
        bool ret = false;
        long numOfDays = TA.TAUtilities.DateDiff(TA.TAUtilities.DateInterval.Year, birthday, effdatefrom);
        if (nminday <= numOfDays && numOfDays <= nmaxday)
        {
            ret = false;
        }
        else
        {
            ret = true;
        }
        return ret;
    }
    private void ValidateBackCurrentDate(string dateValue)
    {
        bool isBackCurrentDate = false;

        isBackCurrentDate = TA.TAUtilities.CheckIsBackDate(dateValue);

        if (isBackCurrentDate == true)
        {
            this.lblValidateSingleTripNumOfDays.Visible = true;
            this.lblValidateSingleTripNumOfDays.Text = "***ไม่สามารถระบุวันที่ย้อนหลังได้ กรุณาระบุใหม่อีกครั้ง!!!";
            this.txtEffectiveDateFrom.Text = "";
            this.txtEffectiveDateTo.Text = "";
            this.txtDuration.Value = "";
        }
    }
    private void ValidateEffectiveBackDate(string effFromDate, string effTodate)
    {
        bool isBacktDate = false;

        isBacktDate = TA.TAUtilities.CheckIsBackDate(effFromDate, effTodate);

        if (isBacktDate == false)
        {
            this.lblValidateSingleTripNumOfDays.Visible = true;
            this.lblValidateSingleTripNumOfDays.Text = "***คุณระบุวันที่ไม่ถูกต้อง(วันที่สิ้นสุดต้องมีค่ามากกว่าวันที่เริ่มคุ้มครอง กรุณาระบุใหม่อีกครั้ง!!!";
            this.txtEffectiveDateFrom.Text = "";
            this.txtEffectiveDateTo.Text = "";
            this.txtDuration.Value = "";
        }
    }
    #endregion

    #region "Text Or SelectedIndex Changed Zone"
    protected void ddlInsurancePlan_SelectedIndexChanged(object sender, EventArgs e)
    {
        //CLEARE CHECKED
        string planID = this.ddlInsurancePlan.SelectedValue;
        string travelPlanType = this.rdoTravelPlan.SelectedValue.Trim();
        int duration = 0;

        if (!string.IsNullOrEmpty(this.txtDuration.Value.Trim()))
            duration = Convert.ToInt32(this.txtDuration.Value.Trim());

        //if (!string.IsNullOrEmpty(this.txtNumberOfChilden.Text))
        //{
        //    if (Convert.ToInt32(this.txtNumberOfChilden.Text.Trim()) > 0)
        //        this.GenerateDynamicTraveler();

        //}

        this.chkSameAsPolicyHolder.Checked = false;

        //Bind dropdown list "ddlPolicyHolderTitle"
        //this.SetTitleToDropdownList(ddlPolicyHolderTitle);
        //Bind dropdown list "ddlProvine"
        //if (this.rdoLanguage.SelectedValue == "E")
        //{
        //    this.SetEngProvinceToDropdownList(ddlProvine);
        //}
        //else { this.SetThaiProvinceToDropdownList(ddlProvine); }

        //Bind dropdown list Title "Traveler 1"
        //this.SetTitleToDropdownList(ddlTraveler1Title);
        //this.SetTitleToDropdownList(ddlTraveler1BeneficialyTitle1);
        //this.SetTitleToDropdownList(ddlTraveler1BeneficialyTitle2);
        //this.SetTitleToDropdownList(ddlTraveler1BeneficialyTitle3);
        ////Bind dropdown list Relation "Traveler 1"
        //this.SetRelationToDropdownList(ddlTraveler1BeneficialyRelationShip1);
        //this.SetRelationToDropdownList(ddlTraveler1BeneficialyRelationShip2);
        //this.SetRelationToDropdownList(ddlTraveler1BeneficialyRelationShip3);

        ////Bind dropdown list Title "Traveler 2"
        //this.SetTitleToDropdownList(ddlTraveler2Title);
        //this.SetTitleToDropdownList(ddlTraveler2BeneficialyTitle1);
        //this.SetTitleToDropdownList(ddlTraveler2BeneficialyTitle2);
        //this.SetTitleToDropdownList(ddlTraveler2BeneficialyTitle3);
        ////Bind dropdown list Relation "Traveler 2"
        //this.SetRelationToDropdownList(ddlTraveler2BeneficialyRelationShip1);
        //this.SetRelationToDropdownList(ddlTraveler2BeneficialyRelationShip2);
        //this.SetRelationToDropdownList(ddlTraveler2BeneficialyRelationShip3);


        if (this.ddlInsurancePlan.SelectedValue == "0000")
        {
            //CLEAR COVERAGE TABLE
            this.lblNetPremiumValue.Text = "";
            this.lblTaxValue.Text = "";
            this.lblStampDiutyValue.Text = "";
            this.lblTotlaPremiumValue.Text = "";
            this.lblPersonalAccidentValue.Text = "";

            this.gdvCoverage.DataSource = null;
            this.gdvCoverage.DataBind();
        }
        else
        {
            //Bind default premium area
            this.SetDefaultPremium(planID, duration, travelPlanType);
            //Bind default coveage area
            this.SetDefaultPlanCoverage(planID);
        }

        //this.RemoveDynamicTravelerControl();
        //this.GenerateDynamicTraveler();

    }
    protected void ddlProvine_SelectedIndexChanged(object sender, EventArgs e)
    {
        //Bind dropdown list "ddlAmphure"

        if (this.ddlLanguage.SelectedValue == "E")
        {

            this.SetEngAmphurToDropdownList(ddlAmphure, ddlProvine.SelectedValue);
 
        }
        else
        {

            //Bind dropdown list "ddlAmphure"
            this.SetThaiAmphurToDropdownList(ddlAmphure, ddlProvine.SelectedValue);
  
        }
      
        this.SetDefaultPlanCoverage(this.ddlInsurancePlan.SelectedValue);

        //this.RemoveDynamicTravelerControl();
        //this.GenerateDynamicTraveler();
    }
    protected void ddlAmphure_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (this.ddlLanguage.SelectedValue == "E")
        {
            //Bind dropdown list "ddlTumbon"
            this.SetEngTumbolToDropdownList(ddlTumbon, ddlProvine.SelectedValue, ddlAmphure.SelectedValue);
        }
        else {
            this.SetThaiTumbolToDropdownList(ddlTumbon, ddlProvine.SelectedValue, ddlAmphure.SelectedValue);
        }
        this.SetDefaultPlanCoverage(this.ddlInsurancePlan.SelectedValue);

        //this.RemoveDynamicTravelerControl();
        //this.GenerateDynamicTraveler();
    }
    protected void chkSameAsPolicyHolder_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            if (chkSameAsPolicyHolder.Checked)
            {
                this.ddlTraveler1Title.SelectedValue = this.ddlPolicyHolderTitle.SelectedValue;
                this.txtTraveler1Name.Value = this.txtName.Value;
                this.txtTraveler1Surname.Value = this.txtSurname.Value;
                this.txtTraveler1Birthday.Value = this.txtBirthday.Value;
                this.txtTraveler1PassportNo.Value = "";
                this.txtTraveler1Tel.Value = this.txtTel.Value;
                //this.txtTraveler1Email.Value = this.txtEmail.Value;

                if (this.txtIDCard.Text.Length != 13)
                {
                    this.txtTraveler1PassportNo.Value = this.txtIDCard.Text.Trim();
                }
                this.ClearCssClassFocusError();
            }
            else
            {
                this.ddlTraveler1Title.SelectedIndex = 0;
                this.txtTraveler1Name.Value = "";
                this.txtTraveler1Surname.Value = "";
                this.txtTraveler1Birthday.Value = "";
                this.txtTraveler1PassportNo.Value = "";
                this.txtTraveler1Tel.Value = "";
                //this.txtTraveler1Email.Value = "";
                this.txtTraveler1PassportNo.Value = "";
            }

            this.SetDefaultPlanCoverage(this.ddlInsurancePlan.SelectedValue);
            
            
            //this.RemoveDynamicTravelerControl();
            //this.GenerateDynamicTraveler();

        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    protected void rdoPolicyType_SelectedIndexChanged(object sender, EventArgs e)
    {
        
        this.lblValidateRelationofTravelPlanAndPolicyTypeShow.Visible = false;
        this.ValidateRelationofTravelPlanAndPolicyType();

        //this.RemoveDynamicTravelerControl();
        //this.GenerateDynamicTraveler();

        //
        this.ProcessCalPremiumAndShowCoverage();

        this.ShowHideTraveler2Zone();

        if (this.rdoPolicyType.SelectedValue.Trim() == "Individual")
        {
            this.RemoveDynamicTravelerControl();
        }

    }
    protected void rdoTravelPlan_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.lblValidateRelationofTravelPlanAndPolicyTypeShow.Visible = false;
        this.ValidateRelationofTravelPlanAndPolicyType();

        if (string.Compare(this.rdoTravelPlan.SelectedValue.Trim(), "Annual") == 0)
        {
            this.txtEffectiveDateTo.Enabled = false;
        }
        else
        {
            this.txtEffectiveDateTo.Enabled = true;
        }

        this.txtEffectiveDateFrom.Text = "";
        this.txtEffectiveDateTo.Text = "";
        this.txtDuration.Value = "";

        this.ShowHideTraveler2Zone();

        //this.RemoveDynamicTravelerControl();
        //this.GenerateDynamicTraveler();
    }
    protected void txtEffectiveDateFrom_TextChanged(object sender, EventArgs e)
    {
        this.txtEffectiveDateFrom.CssClass = "";
        this.lblValidateSingleTripNumOfDays.Text = "";
        //Check Is BackDate
        this.ValidateBackCurrentDate(this.txtEffectiveDateFrom.Text.Trim());
        //End Check

        if (string.Compare(this.rdoTravelPlan.SelectedValue.Trim(), "Annual") == 0)
        {
            if (!string.IsNullOrEmpty(this.txtEffectiveDateFrom.Text))
            {
                this.txtEffectiveDateTo.Text = TA.TAUtilities.CheckCultureAndConvertToDateTime(this.txtEffectiveDateFrom.Text.Trim()).AddYears(1).ToString("dd/MM/yyyy");
                this.txtEffectiveDateTo.Enabled = false;
            }
        }
        else
        {
            this.txtEffectiveDateTo.Enabled = true;

            if (string.IsNullOrEmpty(this.txtEffectiveDateTo.Text))
            {
                if (!string.IsNullOrEmpty(this.txtEffectiveDateFrom.Text.Trim()))
                    this.txtEffectiveDateTo.Text = TA.TAUtilities.CheckCultureAndConvertToDateTime(this.txtEffectiveDateFrom.Text.Trim()).AddDays(1).ToString("dd/MM/yyyy");
            }
        }

        this.ValidateSingleTripNumOfDays();

        if (!string.IsNullOrEmpty(this.txtEffectiveDateFrom.Text) && !string.IsNullOrEmpty(this.txtEffectiveDateTo.Text))
        {
            DateTime dt1 = TA.TAUtilities.CheckCultureAndConvertToDateTime(this.txtEffectiveDateFrom.Text.Trim());
            DateTime dt2 = TA.TAUtilities.CheckCultureAndConvertToDateTime(this.txtEffectiveDateTo.Text.Trim());
            this.txtDuration.Value = this.CalculateTripDuration(dt1, dt2).ToString();

            this.ValidateEffectiveBackDate(this.txtEffectiveDateFrom.Text.Trim(), this.txtEffectiveDateTo.Text.Trim());
        }

        this.ProcessCalPremiumAndShowCoverage();

        //this.RemoveDynamicTravelerControl();
        //this.GenerateDynamicTraveler();
    }
    protected void txtEffectiveDateTo_TextChanged(object sender, EventArgs e)
    {
        this.txtEffectiveDateTo.CssClass = "";
        this.lblValidateSingleTripNumOfDays.Text = "";
        this.lblValidateSingleTripNumOfDays.Visible = false;
        this.ValidateSingleTripNumOfDays();

        //Check Is BackDate
        this.ValidateBackCurrentDate(this.txtEffectiveDateTo.Text.Trim());
        //End Check

        if (!string.IsNullOrEmpty(this.txtEffectiveDateFrom.Text) && !string.IsNullOrEmpty(this.txtEffectiveDateTo.Text))
        {
            DateTime dt1 = TA.TAUtilities.CheckCultureAndConvertToDateTime(this.txtEffectiveDateFrom.Text.Trim());
            DateTime dt2 = TA.TAUtilities.CheckCultureAndConvertToDateTime(this.txtEffectiveDateTo.Text.Trim());
            this.txtDuration.Value = this.CalculateTripDuration(dt1, dt2).ToString();

            this.ValidateEffectiveBackDate(this.txtEffectiveDateFrom.Text.Trim(), this.txtEffectiveDateTo.Text.Trim());
        }

        this.ProcessCalPremiumAndShowCoverage();

        //this.RemoveDynamicTravelerControl();
        //this.GenerateDynamicTraveler();
    }
    protected void txtNumberOfChilden_TextChanged(object sender, EventArgs e)
    {
        if (!string.IsNullOrEmpty(this.txtNumberOfChilden.Text))
        {
            if (Convert.ToInt32(this.txtNumberOfChilden.Text.Trim()) > 0)
                this.GenerateDynamicTraveler();

            //
            this.ProcessCalPremiumAndShowCoverage();
        }

    }
    protected void txtIDCard_TextChanged(object sender, EventArgs e)
    {
        string policyholdertype = ""; //CHECK POLICY HOLDER TYPE
        foreach (ListItem item in rdoTaxInvoiceType.Items)
        {
            if (item.Selected == true)
            {
                policyholdertype = item.Value.Trim();  //Private ,Commercial
            }
        }

        if (!string.IsNullOrEmpty(this.txtIDCard.Text.Trim()))
        {
            if (string.Compare(policyholdertype, "Private") == 0)
            {

                if (txtIDCard.Text.Trim().Length == 13)
                {
                    if (TA.TAUtilities.ChkIDNO(txtIDCard.Text.Trim()) == true)
                    {
                        this.txtTel.Focus();
                    }
                    else
                    {
                        TA.TAUtilities.msgBOX(this.Page, "เลขที่บัตรประชาชนไม่ถูกต้อง");
                        this.txtIDCard.Text = "";
                    }
                }
                else
                {
                    //Pending Check Passport Logic

                    //TA.TAUtilities.msgBOX(this.Page, "เลขที่บัตรประชาชนไม่ถูกต้อง (13 หลัก)");
                    //this.txtIDCard.Text = "";
                }
            }
            else
            {
                //กรณี Commercial
                this.txtTel.Focus();
            }
        }
        else
        {
            TA.TAUtilities.msgBOX(this.Page, "กรุณาระบุเลขที่บัตรประชาชน/Passport No./Tax ID");
            this.txtIDCard.Focus();
        }        
    }
    #endregion

    protected void DefaultPageRegisterClientScript()
    {
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptScrolling", "MenuScroll();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptTxtFocus", "setFocusTextbox();", true);
        //ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDrawCorner", "DrawDivCorner();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDisplayMsg", "DisplayWarning();", true);
        //ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDatePicker", "<script type='text/javascript' language='javascript'>$(document).ready(function () { $('.TRAVEL').find('img').attr('src', '../Images/Index/TA1.png');$('.TRAVEL').find('a').css('color', '#922d3d');$('.TRAVEL').hover(function () {$(this).find('img').attr('src', '../Images/Index/TA1.png'); },function () {$(this).find('img').attr('src', '../Images/Index/TA1.png');}); addSubMenu('hdnTa', '.subNavigate', 'สร้างกรมธรรม์ Travel', '');$('[id$=txtEffectiveDateFrom]').datepicker({ dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true  }); $('[id$=txtEffectiveDateTo]').datepicker({ dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true });$('[id$=txtBirthday]').datepicker({ dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true,yearRange: '1900:' });for (i = 1; i < parseInt($('[id$=txtNumberOfChilden]').val()) + 3; i++) {$('[id$=txtTraveler' + i + 'Birthday]').datepicker({ dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true,yearRange: '1900:' });}  Accordion('.wizard', 'hdnCriteriaStep');AccordionSub1('.wizardSub', 'hdnCriteriaStep');PolicyType();$('[name$=rdoTaxInvoiceType]').click( function () {PolicyType();}); $('[id$=BeneficialyHeir]').click( function(){ hideBeneficialy(this); }); $('[id$=BeneficialyHeir]').filter(function(){ hideBeneficialy(this);}); }); function PolicyType() {$('[name$=rdoTaxInvoiceType]').filter(function () {$('[name$=noCommercial]').css('display', 'block');$('[id$=lblSurname]').text('Family name : ');$('[id$=lblSurname_th]').text('นามสกุล');$('[id$=lblIDCard]').text('ID Card/ Passport No : ');$('[id$=lblIDCard_th]').text('เลขที่บัตรประชาชน/ หนังสือเดินทาง');$('[id$=txtName]').css('width','195px');$('[id$=txtSurname]').css('width','195px');$('[id$=chkSameAsPolicyHolder]').css('display','');$('label[for$=chkSameAsPolicyHolder]').css('display','');if ($(this).attr('checked') == 'checked') {$('[name$=noCommercial]').css('display', 'none');$('[id$=lblSurname]').text('Name 2 : ');$('[id$=lblSurname_th]').text('ชื่อ 2 : ');$('[id$=lblIDCard]').text('Corporate Tax ID : ');$('[id$=lblIDCard_th]').text('เลขที่ผู้เสียภาษี');$('[id$=txtName]').css('width','320px');$('[id$=txtSurname]').css('width','320px');$('[id$=chkSameAsPolicyHolder]').css('display','none');$('label[for$=chkSameAsPolicyHolder]').css('display','none');return;} }); } function hideBeneficialy(control){ if( $(control).attr('checked') == 'checked'){ $(control).parent().parent().parent().parent().next().css('display','none');}else{ $(control).parent().parent().parent().parent().next().css('display','block');} } </script>", false);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDatePicker", "<script type='text/javascript' language='javascript'> "
            + "$(document).ready(function () { "
            + " $('.TRAVEL').find('img').attr('src', '../Images/Index/TA1.png'); "
            + " $('.TRAVEL').find('a').css('color', '#922d3d'); "
            + " $('.TRAVEL').hover(function () { "
            + "    $(this).find('img').attr('src', '../Images/Index/TA1.png'); "
            + " },function () {$(this).find('img').attr('src', '../Images/Index/TA1.png');}); "
            + " addSubMenu('hdnTa', '.subNavigate', 'Issue Policy', ''); "
            + " $('[id$=txtEffectiveDateFrom]').datepicker({ dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true  }); "
            + " $('[id$=txtEffectiveDateTo]').datepicker({ dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true });"
            + " $('[id$=txtBirthday]').datepicker({ dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true,yearRange: '1900:' }); "
            + " for (i = 1; i < parseInt($('[id$=txtNumberOfChilden]').val()) + 3; i++) { "
            + "     $('[id$=txtTraveler' + i + 'Birthday]').datepicker({ dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true,yearRange: '1900:' });}  "
            + " Accordion('.wizard', 'hdnCriteriaStep');AccordionSub1('.wizardSub', 'hdnCriteriaStep'); "
            + " PolicyTypeTA();$('[name$=rdoTaxInvoiceType]').click( function () { PolicyTypeTA();}); "
            + " $('[id$=BeneficialyHeir]').click( function(){ hideBeneficialy(this); }); $('[id$=BeneficialyHeir]').filter(function(){ hideBeneficialy(this);}); });  </script>", false);

        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptsetKeyboardLanguage", "setKeyboardLanguage();", true);
    }
    protected int  CalculateTripDuration(DateTime dt1, DateTime dt2)
    {
        int retValue = 0;
        long numOfDays = 0;

        if (string.Compare(this.rdoTravelPlan.SelectedValue.Trim(), "Single") == 0)
        {
            numOfDays = TA.TAUtilities.DateDiff(TA.TAUtilities.DateInterval.Day, dt1, dt2);
            retValue = Convert.ToInt32(numOfDays) + 1;
        }

        if (string.Compare(this.rdoTravelPlan.SelectedValue.Trim(), "Annual") == 0)
        {
            numOfDays = TA.TAUtilities.DateDiff(TA.TAUtilities.DateInterval.Day, dt1, dt2);
            retValue = Convert.ToInt32(numOfDays);
        }

        return retValue;
    }
    protected void ProcessCalPremiumAndShowCoverage()
    {
        string planID = this.ddlInsurancePlan.SelectedValue;
        string travelPlanType = this.rdoTravelPlan.SelectedValue.Trim();
        int duration = 0;

        if (!string.IsNullOrEmpty(this.txtDuration.Value.Trim()))
            duration = Convert.ToInt32(this.txtDuration.Value.Trim());

        if (planID == "0000" || duration == 0)
        {
            //CLEAR COVERAGE TABLE
            this.lblNetPremiumValue.Text = "";
            this.lblTaxValue.Text = "";
            this.lblStampDiutyValue.Text = "";
            this.lblTotlaPremiumValue.Text = "";
            this.lblPersonalAccidentValue.Text = "";

            this.gdvCoverage.DataSource = null;
            this.gdvCoverage.DataBind();
        }
        else
        {
            //Bind default premium area
            this.SetDefaultPremium(planID, duration, travelPlanType);
            //Bind default coveage area
            this.SetDefaultPlanCoverage(planID);
        }
    }

    #region "BIND COPY TA POLICY"
    protected void GetBindPackagePolicy(string JobNo, string GroupBrokerID)
    {
        try
        { 
            TATransPolicyBLL clstranspolicy = new TATransPolicyBLL();
            TAGetBindPackagePolicy getbindpackagepolicy = clstranspolicy.GetTATransPolicy(JobNo, GroupBrokerID);
            if (!string.IsNullOrEmpty(getbindpackagepolicy.JobNo))
            {
                //HAVE DATA
                //getbindpackagepolicy.JobNo.Trim();
                //getbindpackagepolicy.PolicyNo.Trim();
                this.rdoTravelPlan.SelectedValue = getbindpackagepolicy.TravelPlan.Trim(); //Single or Annual

                if (string.Compare(this.rdoTravelPlan.SelectedValue.Trim(), "Annual") == 0)
                {
                    this.txtEffectiveDateTo.Enabled = false;
                }
                else
                {
                    this.txtEffectiveDateTo.Enabled = true;
                }

                this.rdoPolicyType.SelectedValue = getbindpackagepolicy.PolicyType.Trim(); //Individual or Family
                this.txtNumberOfChilden.Text = getbindpackagepolicy.NumbersOfChildren.Trim();
                
                if (Convert.ToDateTime(getbindpackagepolicy.EffectiveDateFrom.Trim()) < DateTime.Today)
                {
                    this.txtEffectiveDateFrom.Text = TA.TAUtilities.ConvertDateTimeToEnShowDateString(DateTime.Today);
                    this.txtEffectiveDateTo.Text = TA.TAUtilities.ConvertDateTimeToEnShowDateString(DateTime.Today);
                    this.txtDuration.Value = "1";
                
                }
                else
                {
                    this.txtEffectiveDateFrom.Text = TA.TAUtilities.ConvertDateTimeToEnShowDateString(Convert.ToDateTime(getbindpackagepolicy.EffectiveDateFrom.Trim()));
                    this.txtEffectiveDateTo.Text = TA.TAUtilities.ConvertDateTimeToEnShowDateString(Convert.ToDateTime(getbindpackagepolicy.EffectiveDateTo.Trim()));
                    this.txtDuration.Value = (TA.TAUtilities.DateDiff(Convert.ToDateTime(getbindpackagepolicy.EffectiveDateFrom.Trim()), Convert.ToDateTime(getbindpackagepolicy.EffectiveDateTo.Trim())) + 1).ToString();
                }
                
                //this.txtEffectiveDateFrom.Text = TA.TAUtilities.ConvertDateTimeToEnShowDateString(Convert.ToDateTime(getbindpackagepolicy.EffectiveDateFrom.Trim()));
                //this.txtEffectiveDateTo.Text = TA.TAUtilities.ConvertDateTimeToEnShowDateString(Convert.ToDateTime(getbindpackagepolicy.EffectiveDateTo.Trim()));
                //this.txtDuration.Value = (TA.TAUtilities.DateDiff(Convert.ToDateTime(getbindpackagepolicy.EffectiveDateFrom.Trim()), Convert.ToDateTime(getbindpackagepolicy.EffectiveDateTo.Trim()))+1).ToString();
                this.ddlCountryOfDestination.SelectedValue = findDropdownValueByText(this.ddlCountryOfDestination, getbindpackagepolicy.CountryOfDestination.Trim());
                //this.ddlCountryOfDestination.SelectedItem.Text = getbindpackagepolicy.CountryOfDestination.Trim(); //BURKINA FASO
                this.txtCountryOfDestinationOther.Value = getbindpackagepolicy.CounterOther.Trim();
                this.ddlInsurancePlan.SelectedValue = getbindpackagepolicy.InsurancePlan.Trim();
                //this.ddlInsurancePlan.SelectedValue = getbindpackagepolicy.InsurancePlan.Trim(); //0003
                //getbindpackagepolicy.PlanCode.Trim();
                //getbindpackagepolicy.ContractType.Trim();
                //getbindpackagepolicy.AgentCode.Trim();
                this.lblNetPremiumValue.Text = Utilities.StringFormatWithCommaEng(getbindpackagepolicy.NetPremium.Trim());
                this.lblTaxValue.Text = Utilities.StringFormatWithCommaEng(getbindpackagepolicy.SBT.Trim());
                this.lblStampDiutyValue.Text = Utilities.StringFormatWithCommaEng(getbindpackagepolicy.Stamp.Trim());
                this.lblTotlaPremiumValue.Text = Utilities.StringFormatWithCommaEng(getbindpackagepolicy.TotalPremium.Trim());
                //getbindpackagepolicy.IsLongName.Trim();
                //getbindpackagepolicy.IsBeneficiary.Trim();
                //getbindpackagepolicy.GroupBrokerId.Trim();
                this.txtLongName1.Value = getbindpackagepolicy.LongName1.Trim();
                this.txtLongName2.Value = getbindpackagepolicy.LongName2.Trim();
                //this.txtLongName3.Value = getbindpackagepolicy.LongName3.Trim();
                //this.txtLongName4.Value = getbindpackagepolicy.LongName4.Trim();

                //Bind default coveage area
                //this.SetDefaultPlanCoverage(getbindpackagepolicy.InsurancePlan.Trim());
                this.ProcessCalPremiumAndShowCoverage();

                if (string.Compare(getbindpackagepolicy.CountryOfDestination.Trim(), "Other") == 0) 
                {
                    this.txtCountryOfDestinationOther.Visible = true;
                }
  
            }
        }
        catch (Exception ex)
        {
            Utilities.LogError(ex);
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    protected void GetBindPolicyHolder(string JobNo)
    {
        try
        {
            TATransPolicyHolderBLL clstranspolicyholder = new TATransPolicyHolderBLL();
            TATransPolicyHolder transpolicyholder = clstranspolicyholder.GetTATransPolicyHolder(JobNo);
            if (!string.IsNullOrEmpty(transpolicyholder.JobNo))
            {
                //HAVE DATA
                switch (transpolicyholder.ClientType.Trim())
                {
                    case "P":
                        //Bind data "Private"
                        this.rdoTaxInvoiceType.SelectedIndex = 0;
                       
                        this.txtName.Value = transpolicyholder.ClientName.Trim();
                        this.txtSurname.Value = transpolicyholder.ClientSurName.Trim();
                        this.txtAddress1.Value = transpolicyholder.ClientAddress1.Trim();
                        this.txtAddress2.Value = transpolicyholder.ClientAddress2.Trim();
                        this.ddlLanguage.SelectedValue = transpolicyholder.Language;

                        if (this.ddlLanguage.SelectedValue == "E")
                        {
                            //Bind dropdown list "ddlProvine"
                            this.SetEngProvinceToDropdownList(ddlProvine);
                            this.findDropdownValueByText(this.ddlProvine, transpolicyholder.Province.Trim());
                            //this.ddlProvine.SelectedItem.Text = transpolicyholder.Province.Trim();

                            //Bind dropdown list "ddlAmphure"
                            this.SetEngAmphurToDropdownList(ddlAmphure, this.ddlProvine.SelectedValue);
                            this.findDropdownValueByText(this.ddlAmphure, transpolicyholder.Amphur.Trim());
                            //this.ddlAmphure.SelectedItem.Text = transpolicyholder.Amphur.Trim();

                            //Bind dropdown list "ddlTumbon"
                            this.SetEngTumbolToDropdownList(ddlTumbon, this.ddlProvine.SelectedValue, this.ddlAmphure.SelectedValue);
                            this.findDropdownValueByText(this.ddlTumbon, transpolicyholder.Tumbol.Trim());
                            //this.ddlTumbon.SelectedItem.Text = transpolicyholder.Tumbol.Trim();

                            //Bind dropdown list "ddlPolicyHolderTitle"
                            this.SetTitleToDropdownList(ddlPolicyHolderTitle);
                            this.ddlPolicyHolderTitle.SelectedValue = this.findDropdownValueByText(this.ddlPolicyHolderTitle, transpolicyholder.ClientTitle.Trim());
                            //this.ddlPolicyHolderTitle.SelectedValue = transpolicyholder.ClientTitle.Trim();

                        }
                        else {
                            //Bind dropdown list "ddlProvine"
                            this.SetThaiProvinceToDropdownList(ddlProvine);
                            string Province = transpolicyholder.Province.Trim();
                            Province = Province.Replace("จังหวัด", "");
                            this.findDropdownValueByText(this.ddlProvine, Province);
                            //this.ddlProvine.SelectedItem.Text = transpolicyholder.Province.Trim();

                            //Bind dropdown list "ddlAmphure"
                            this.SetThaiAmphurToDropdownList(ddlAmphure, this.ddlProvine.SelectedValue);
                            string Amphur = transpolicyholder.Amphur.Trim();
                            Amphur = Amphur.Replace("อำเภอ", "");
                            this.findDropdownValueByText(this.ddlAmphure, Amphur);
                            //this.ddlAmphure.SelectedItem.Text = transpolicyholder.Amphur.Trim();

                            //Bind dropdown list "ddlTumbon"
                            this.SetThaiTumbolToDropdownList(ddlTumbon, this.ddlProvine.SelectedValue, this.ddlAmphure.SelectedValue);
                            string Tumbol = transpolicyholder.Tumbol.Trim();
                            Tumbol = Tumbol.Replace("ตำบล", "");
                            this.findDropdownValueByText(this.ddlTumbon, Tumbol);
                            //this.ddlTumbon.SelectedItem.Text = transpolicyholder.Tumbol.Trim();

                            //Bind dropdown list "ddlPolicyHolderTitle"
                            this.SetThaiTitleToDropdownList(ddlPolicyHolderTitle);
                            this.findDropdownValueByText(this.ddlPolicyHolderTitle, transpolicyholder.ClientTitle.Trim());
                            //this.ddlPolicyHolderTitle.SelectedValue = transpolicyholder.ClientTitle.Trim();
                        }
                       


                        this.txtZipCode.Value = transpolicyholder.PostCode.Trim();
                        this.txtBirthday.Value = TA.TAUtilities.ConvertDateTimeToEnShowDateString(Convert.ToDateTime(transpolicyholder.Birthday.Trim()));
                        this.txtIDCard.Text = transpolicyholder.IDCard.Trim();
                        this.txtTel.Value = transpolicyholder.Tel.Trim();
                        this.txtEmail.Value = transpolicyholder.Email.Trim();
                        break;
                    case "C":
                        //Bind data "Commercial"
                        this.rdoTaxInvoiceType.SelectedIndex = 1;

                        this.txtName.Value = transpolicyholder.ClientName.Trim();
                        this.txtSurname.Value = transpolicyholder.ClientSurName.Trim();
                        this.txtAddress1.Value = transpolicyholder.ClientAddress1.Trim();
                        this.txtAddress2.Value = transpolicyholder.ClientAddress2.Trim();
                        this.ddlLanguage.SelectedValue = transpolicyholder.Language;

                        this.txtBranchNo.Value = transpolicyholder.BranchNo.Trim();
                        if (this.ddlLanguage.SelectedValue == "E")
                        {
                            //Bind dropdown list "ddlProvine"
                            this.SetEngProvinceToDropdownList(ddlProvine);
                            this.findDropdownValueByText(this.ddlProvine, transpolicyholder.Province.Trim());
                            //this.ddlProvine.SelectedItem.Text = transpolicyholder.Province.Trim();

                            //Bind dropdown list "ddlAmphure"
                            this.SetEngAmphurToDropdownList(ddlAmphure, this.ddlProvine.SelectedValue);
                            this.findDropdownValueByText(this.ddlAmphure, transpolicyholder.Amphur.Trim());
                            //this.ddlAmphure.SelectedItem.Text = transpolicyholder.Amphur.Trim();

                            //Bind dropdown list "ddlTumbon"
                            this.SetEngTumbolToDropdownList(ddlTumbon, this.ddlProvine.SelectedValue, this.ddlAmphure.SelectedValue);
                            this.findDropdownValueByText(this.ddlTumbon, transpolicyholder.Tumbol.Trim());
                            //this.ddlTumbon.SelectedItem.Text = transpolicyholder.Tumbol.Trim();

                        }
                        else
                        {
                            //Bind dropdown list "ddlProvine"
                            this.SetThaiProvinceToDropdownList(ddlProvine);
                            string Province = transpolicyholder.Province.Trim();
                            Province = Province.Replace("จังหวัด", "");
                            this.findDropdownValueByText(this.ddlProvine, Province);
                            //this.ddlProvine.SelectedItem.Text = transpolicyholder.Province.Trim();

                            //Bind dropdown list "ddlAmphure"
                            this.SetThaiAmphurToDropdownList(ddlAmphure, this.ddlProvine.SelectedValue);
                            string Amphur = transpolicyholder.Amphur.Trim();
                            Amphur = Amphur.Replace("อำเภอ", "");
                            this.findDropdownValueByText(this.ddlAmphure, Amphur);
                            //this.ddlAmphure.SelectedItem.Text = transpolicyholder.Amphur.Trim();

                            //Bind dropdown list "ddlTumbon"
                            this.SetThaiTumbolToDropdownList(ddlTumbon, this.ddlProvine.SelectedValue, this.ddlAmphure.SelectedValue);
                            string Tumbol = transpolicyholder.Tumbol.Trim();
                            Tumbol = Tumbol.Replace("ตำบล", "");
                            this.findDropdownValueByText(this.ddlTumbon, Tumbol);
                            //this.ddlTumbon.SelectedItem.Text = transpolicyholder.Tumbol.Trim();
                        }

                        //this.ddlProvine.SelectedItem.Text = transpolicyholder.Province.Trim();

                        ////Bind dropdown list "ddlAmphure"
                        //this.SetEngAmphurToDropdownList(ddlAmphure, "01");
                        //this.ddlAmphure.SelectedItem.Text = transpolicyholder.Amphur.Trim();

                        ////Bind dropdown list "ddlTumbon"
                        //this.SetEngTumbolToDropdownList(ddlTumbon, "01", "0101");
                        //this.ddlTumbon.SelectedItem.Text = transpolicyholder.Tumbol.Trim();

                        this.txtZipCode.Value = transpolicyholder.PostCode.Trim();
                        this.txtIDCard.Text = transpolicyholder.TaxID.Trim();
                        this.txtTel.Value = transpolicyholder.Tel.Trim();
                        this.txtEmail.Value = transpolicyholder.Email.Trim();

                        break;
                    default: break;
                }

            }
        }
        catch (Exception ex)
        {
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    }
    protected void GetBindTraveler(string JobNo)
    {
        try
        {
            TATransTravelerBLL clstranstraveler = new TATransTravelerBLL();
            DataTable dt = clstranstraveler.GetDtTATransTraveler(JobNo);

            //---------------default traveler 1-2---------------------------
            this.ShowHideTraveler2Zone();

            if (this.ddlLanguage.SelectedValue == "E")
            {
                this.SetTitleToDropdownList(ddlTraveler1Title);
                this.SetTitleToDropdownList(ddlTraveler2Title);

                this.SetTitleToDropdownList(ddlTraveler1BeneficialyTitle1);
                this.SetTitleToDropdownList(ddlTraveler1BeneficialyTitle2);
                this.SetTitleToDropdownList(ddlTraveler1BeneficialyTitle3);

                this.SetTitleToDropdownList(ddlTraveler2BeneficialyTitle1);
                this.SetTitleToDropdownList(ddlTraveler2BeneficialyTitle2);
                this.SetTitleToDropdownList(ddlTraveler2BeneficialyTitle3);
            }
            else
            {
                this.SetThaiTitleToDropdownList(ddlTraveler1Title);
                this.SetThaiTitleToDropdownList(ddlTraveler2Title);

                 this.SetThaiTitleToDropdownList(ddlTraveler1BeneficialyTitle1);
                 this.SetThaiTitleToDropdownList(ddlTraveler1BeneficialyTitle2);
                 this.SetThaiTitleToDropdownList(ddlTraveler1BeneficialyTitle3);

                this.SetThaiTitleToDropdownList(ddlTraveler2BeneficialyTitle1);
                this.SetThaiTitleToDropdownList(ddlTraveler2BeneficialyTitle2);
                this.SetThaiTitleToDropdownList(ddlTraveler2BeneficialyTitle3);
            }

            this.SetRelationToDropdownList(ddlTraveler1BeneficialyRelationShip1, this.ddlLanguage.SelectedValue.ToString());
            this.SetRelationToDropdownList(ddlTraveler1BeneficialyRelationShip2, this.ddlLanguage.SelectedValue.ToString());
            this.SetRelationToDropdownList(ddlTraveler1BeneficialyRelationShip3, this.ddlLanguage.SelectedValue.ToString());
  
            this.SetRelationToDropdownList(ddlTraveler2BeneficialyRelationShip1, this.ddlLanguage.SelectedValue.ToString());
            this.SetRelationToDropdownList(ddlTraveler2BeneficialyRelationShip2, this.ddlLanguage.SelectedValue.ToString());
            this.SetRelationToDropdownList(ddlTraveler2BeneficialyRelationShip3, this.ddlLanguage.SelectedValue.ToString());
       
            if (dt.Rows.Count > 0)
            {
                //HAVE DATA
                
                
                this.ddlTraveler1Title.SelectedValue = dt.Rows[0]["ClientTitle"].ToString().Trim();
                this.txtTraveler1Name.Value = dt.Rows[0]["ClientName"].ToString().Trim();
                this.txtTraveler1Surname.Value = dt.Rows[0]["ClientSurName"].ToString().Trim();
                this.txtTraveler1Birthday.Value = TA.TAUtilities.ConvertDateTimeToEnShowDateString(Convert.ToDateTime(dt.Rows[0]["Birthday"].ToString().Trim()));
                this.txtTraveler1PassportNo.Value = dt.Rows[0]["PassportID"].ToString().Trim();
                this.txtTraveler1Tel.Value = dt.Rows[0]["Tel"].ToString().Trim();

                //Benefit 
                TATransBeneficiaryBLL clstransbenefit = new TATransBeneficiaryBLL();
                DataTable dtbenefit = clstransbenefit.GetDtTATransBeneficiary(JobNo);

                if (dtbenefit.Rows.Count > 0)
                {
                    //HAVE DATA

                    //Benefit Groop 1 Only

                    
                    foreach (DataRow row in dtbenefit.Rows)
                    {
                        string m_travelerid = row["TravelerID"].ToString().Trim();
                        string m_seq = row["Seq"].ToString().Trim();
                        if (m_travelerid == "1")
                        { 
                            //Bind Benefit
                            this.chkTraveler1BeneficialyHeir.Checked = false;
                            switch (m_seq)
                            {
                                case "1":
                                    this.ddlTraveler1BeneficialyTitle1.SelectedValue = row["BeneficiaryTitle"].ToString().Trim();
                                    this.txtTraveler1BeneficialyName1.Value = row["BeneficiaryName"].ToString().Trim();
                                    this.txtTraveler1BeneficialySurname1.Value = row["BeneficiarySurName"].ToString().Trim();
                                    this.ddlTraveler1BeneficialyRelationShip1.SelectedValue = row["BeneficiaryRelation"].ToString().Trim();
                                    this.txtTraveler1BeneficialyRatio1.Value = row["BeneficiaryRatio"].ToString().Trim();
                                    this.txtTraveler1BeneficialyTel1.Value = row["BeneficiaryTel"].ToString().Trim();
                                    break;
                                case "2":
                                    this.ddlTraveler1BeneficialyTitle2.SelectedValue = row["BeneficiaryTitle"].ToString().Trim();
                                    this.txtTraveler1BeneficialyName2.Value = row["BeneficiaryName"].ToString().Trim();
                                    this.txtTraveler1BeneficialySurname2.Value = row["BeneficiarySurName"].ToString().Trim();
                                    this.ddlTraveler1BeneficialyRelationShip2.SelectedValue = row["BeneficiaryRelation"].ToString().Trim();
                                    this.txtTraveler1BeneficialyRatio2.Value = row["BeneficiaryRatio"].ToString().Trim();
                                    this.txtTraveler1BeneficialyTel2.Value = row["BeneficiaryTel"].ToString().Trim();
                                    break;
                                case "3":
                                    this.ddlTraveler1BeneficialyTitle3.SelectedValue = row["BeneficiaryTitle"].ToString().Trim();
                                    this.txtTraveler1BeneficialyName3.Value = row["BeneficiaryName"].ToString().Trim();
                                    this.txtTraveler1BeneficialySurname3.Value = row["BeneficiarySurName"].ToString().Trim();
                                    this.ddlTraveler1BeneficialyRelationShip3.SelectedValue = row["BeneficiaryRelation"].ToString().Trim();
                                    this.txtTraveler1BeneficialyRatio3.Value = row["BeneficiaryRatio"].ToString().Trim();
                                    this.txtTraveler1BeneficialyTel3.Value = row["BeneficiaryTel"].ToString().Trim();
                                    break;
                            }
                        }
                    }
                }



                if (dt.Rows.Count > 1)
                {
                    
                    this.ddlTraveler2Title.SelectedValue = dt.Rows[1]["ClientTitle"].ToString().Trim();
                    this.txtTraveler2Name.Value = dt.Rows[1]["ClientName"].ToString().Trim();
                    this.txtTraveler2Surname.Value = dt.Rows[1]["ClientSurName"].ToString().Trim();
                    this.txtTraveler2Birthday.Value = TA.TAUtilities.ConvertDateTimeToEnShowDateString(Convert.ToDateTime(dt.Rows[1]["Birthday"].ToString().Trim()));
                    this.txtTraveler2PassportNo.Value = dt.Rows[1]["PassportID"].ToString().Trim();
                    this.txtTraveler2Tel.Value = dt.Rows[1]["Tel"].ToString().Trim();


                    //Benefit Groop 2 Only
                    if (dtbenefit.Rows.Count > 0)
                    {
                        //HAVE DATA
                       
                        foreach (DataRow row in dtbenefit.Rows)
                        {
                            string m_travelerid = row["TravelerID"].ToString().Trim();
                            string m_seq = row["Seq"].ToString().Trim();
                            if (m_travelerid == "2")
                            {
                                //Bind Benefit
                                this.chkTraveler2BeneficialyHeir.Checked = false;
                                switch (m_seq)
                                {
                                    case "1":
                                        this.ddlTraveler2BeneficialyTitle1.SelectedValue = row["BeneficiaryTitle"].ToString().Trim();
                                        this.txtTraveler2BeneficialyName1.Value = row["BeneficiaryName"].ToString().Trim();
                                        this.txtTraveler2BeneficialySurname1.Value = row["BeneficiarySurName"].ToString().Trim();
                                        this.ddlTraveler2BeneficialyRelationShip1.SelectedValue = row["BeneficiaryRelation"].ToString().Trim();
                                        this.txtTraveler2BeneficialyRatio1.Value = row["BeneficiaryRatio"].ToString().Trim();
                                        this.txtTraveler2BeneficialyTel1.Value = row["BeneficiaryTel"].ToString().Trim();
                                        break;
                                    case "2":
                                        this.ddlTraveler2BeneficialyTitle2.SelectedValue = row["BeneficiaryTitle"].ToString().Trim();
                                        this.txtTraveler2BeneficialyName2.Value = row["BeneficiaryName"].ToString().Trim();
                                        this.txtTraveler2BeneficialySurname2.Value = row["BeneficiarySurName"].ToString().Trim();
                                        this.ddlTraveler2BeneficialyRelationShip2.SelectedValue = row["BeneficiaryRelation"].ToString().Trim();
                                        this.txtTraveler2BeneficialyRatio2.Value = row["BeneficiaryRatio"].ToString().Trim();
                                        this.txtTraveler2BeneficialyTel2.Value = row["BeneficiaryTel"].ToString().Trim();
                                        break;
                                    case "3":
                                        this.ddlTraveler2BeneficialyTitle3.SelectedValue = row["BeneficiaryTitle"].ToString().Trim();
                                        this.txtTraveler2BeneficialyName3.Value = row["BeneficiaryName"].ToString().Trim();
                                        this.txtTraveler2BeneficialySurname3.Value = row["BeneficiarySurName"].ToString().Trim();
                                        this.ddlTraveler2BeneficialyRelationShip3.SelectedValue = row["BeneficiaryRelation"].ToString().Trim();
                                        this.txtTraveler2BeneficialyRatio3.Value = row["BeneficiaryRatio"].ToString().Trim();
                                        this.txtTraveler2BeneficialyTel3.Value = row["BeneficiaryTel"].ToString().Trim();
                                        break;
                                }
                            }
                        }
                    }
                    //Generage Another Traveler
                    this.GenerateDynamicTraveler(dt,JobNo); 
                }     
            }
        }
        catch (Exception ex)
        {
            Utilities.LogError(ex);
            this.lblErrorMessage.Text = ex.ToString();
            this.lblInformMessage.Text = "";
        }
    } 
    protected void GenerateDynamicTraveler(DataTable dt, string JobNo)
    {
        this.divTravelerParent.Controls.Clear();
        if (this.txtNumberOfChilden.Text.Trim() == string.Empty) return;

        if (!string.IsNullOrEmpty(this.txtNumberOfChilden.Text))
        {
            if (this.txtNumberOfChilden.Text.Trim() == "0" || Convert.ToInt32(this.txtNumberOfChilden.Text.Trim()) == 0)
            {
                return;
            }
            else
            {
                int NumberOfChilden = Convert.ToInt32(this.txtNumberOfChilden.Text);
                for (int i = 0; i < NumberOfChilden; i++)
                {
                    int code = i + 3;
                    int index = i + 2;
                    HtmlGenericControl h6 = new HtmlGenericControl("h6");
                    h6.InnerText = "Traveler " + code + " /ผู้เดินทางคนที่ " + code;

                    this.divTravelerParent.Controls.Add(h6);

                    HtmlGenericControl div = new HtmlGenericControl("div");
                    this.divTravelerParent.Controls.Add(div);

                    HtmlTable tableTaveler = new HtmlTable();
                    tableTaveler.Align = "center";
                    tableTaveler.Width = "98%";

                    div.Controls.Add(tableTaveler);

                    #region Table Traveler
                    HtmlTableRow tableTaveler_tr = new HtmlTableRow();
                    tableTaveler.Controls.Add(tableTaveler_tr);

                    //-------------- TravelerTitle ----------------------
                    HtmlTableCell tableTaveler_tdTitle = new HtmlTableCell();
                    tableTaveler_tdTitle.Align = "left";

                    Label lblTravelerTitle = new Label();
                    lblTravelerTitle.Font.Bold = true;
                    lblTravelerTitle.ID = "lblTraveler" + code + "Title";
                    lblTravelerTitle.Text = "<font color=red>*</font>&nbsp;" + "Title : <br />&nbsp;&nbsp;&nbsp;";

                    Label lblTravelerTitleTh = new Label();
                    lblTravelerTitleTh.Font.Bold = true;
                    lblTravelerTitleTh.Font.Size = FontUnit.Point(8);
                    lblTravelerTitleTh.ID = "lblTraveler" + code + "Title_th";
                    lblTravelerTitleTh.Text = "คำนำหน้าชื่อ <br />";

                    DropDownList ddlTravelerTitle = new DropDownList();
                    ddlTravelerTitle.Width = 110;
                    ddlTravelerTitle.ID = "ddlTraveler" + code + "Title";
                    if (this.ddlLanguage.SelectedValue == "E")
                    {
                        SetTitleToDropdownList(ddlTravelerTitle);
                    }
                    else
                    {
                        SetThaiTitleToDropdownList(ddlTravelerTitle);
                    }
                    ddlTravelerTitle.SelectedValue = dt.Rows[index]["ClientTitle"].ToString().Trim();
                    //-------VVVVVVVVVVVVVVVVVVVVVVVVVVV------------
                    

                    tableTaveler_tdTitle.Controls.Add(lblTravelerTitle);
                    tableTaveler_tdTitle.Controls.Add(lblTravelerTitleTh);
                    tableTaveler_tdTitle.Controls.Add(ddlTravelerTitle);

                    tableTaveler_tr.Controls.Add(tableTaveler_tdTitle);

                    //-------------- TravelerName -----------------------
                    HtmlTableCell tableTaveler_tdName = new HtmlTableCell();
                    tableTaveler_tdName.Align = "left";

                    Label lblTravelerName = new Label();
                    lblTravelerName.Font.Bold = true;
                    lblTravelerName.ID = "lblTraveler" + code + "Name";
                    lblTravelerName.Text = "<font color=red>*</font>&nbsp;" + "Name : <br/>&nbsp;&nbsp;&nbsp;";

                    Label lblTravelerNameTh = new Label();
                    lblTravelerNameTh.Font.Bold = true;
                    lblTravelerNameTh.Font.Size = FontUnit.Point(8);
                    lblTravelerNameTh.ID = "lblTraveler" + code + "Name_th";
                    lblTravelerNameTh.Text = "ชื่อ <br />";

                    HtmlInputText txtTravelerName = new HtmlInputText();
                    txtTravelerName.MaxLength = 60;
                    txtTravelerName.Style.Add("width", "195px");
                    txtTravelerName.ID = "txtTraveler" + code + "Name";
                    txtTravelerName.Value = dt.Rows[index]["ClientName"].ToString().Trim();//Request.Form["ctl00$MainContent$ddlTraveler" + code + "Name"];

                    tableTaveler_tdName.Controls.Add(lblTravelerName);
                    tableTaveler_tdName.Controls.Add(lblTravelerNameTh);
                    tableTaveler_tdName.Controls.Add(txtTravelerName);

                    tableTaveler_tr.Controls.Add(tableTaveler_tdName);

                    //-------------- TravelerSurname -----------------------
                    HtmlTableCell tableTaveler_tdSurname = new HtmlTableCell();
                    tableTaveler_tdSurname.Align = "left";

                    Label lblTravelerSurname = new Label();
                    lblTravelerSurname.Font.Bold = true;
                    lblTravelerSurname.ID = "lblTraveler" + code + "Surname";
                    lblTravelerSurname.Text = "Family name : <br/>";

                    Label lblTravelerSurnameTh = new Label();
                    lblTravelerSurnameTh.Font.Bold = true;
                    lblTravelerSurnameTh.Font.Size = FontUnit.Point(8);
                    lblTravelerSurnameTh.ID = "lblTraveler" + code + "Surname_th";
                    lblTravelerSurnameTh.Text = "นามสกุล <br />";

                    HtmlInputText txtTravelerSurname = new HtmlInputText();
                    txtTravelerSurname.MaxLength = 60;
                    txtTravelerSurname.Style.Add("width", "195px");
                    txtTravelerSurname.ID = "txtTraveler" + code + "Surname";
                    txtTravelerSurname.Value = dt.Rows[index]["ClientSurName"].ToString().Trim();//Request.Form["ctl00$MainContent$ddlTraveler" + code + "Surname"];

                    tableTaveler_tdSurname.Controls.Add(lblTravelerSurname);
                    tableTaveler_tdSurname.Controls.Add(lblTravelerSurnameTh);
                    tableTaveler_tdSurname.Controls.Add(txtTravelerSurname);

                    tableTaveler_tr.Controls.Add(tableTaveler_tdSurname);

                    //-------------- TravelerBirthday -----------------------
                    HtmlTableCell tableTaveler_tdBirthday = new HtmlTableCell();
                    tableTaveler_tdBirthday.Align = "left";

                    Label lblTravelerBirthday = new Label();
                    lblTravelerBirthday.Font.Bold = true;
                    lblTravelerBirthday.ID = "lblTraveler" + code + "Birthday";
                    lblTravelerBirthday.Text = "<font color=red>*</font>&nbsp;" + "DOB : <br/>&nbsp;&nbsp;&nbsp;";

                    Label lblTravelerBirthdayTh = new Label();
                    lblTravelerBirthdayTh.Font.Bold = true;
                    lblTravelerBirthdayTh.Font.Size = FontUnit.Point(8);
                    lblTravelerBirthdayTh.ID = "lblTraveler" + code + "Birthday_th";
                    lblTravelerBirthdayTh.Text = "วัน เดือน ปี เกิด <br />";

                    HtmlInputText txtTravelerBirthday = new HtmlInputText();
                    txtTravelerBirthday.ID = "txtTraveler" + code + "Birthday";
                    txtTravelerBirthday.MaxLength = 10;
                    txtTravelerBirthday.Style.Add("width", "80px");
                    txtTravelerBirthday.Value = TA.TAUtilities.ConvertDateTimeToEnShowDateString(Convert.ToDateTime(dt.Rows[index]["Birthday"].ToString().Trim()));   //Request.Form["ctl00$MainContent$ddlTraveler" + code + "Birthday"];

                    tableTaveler_tdBirthday.Controls.Add(lblTravelerBirthday);
                    tableTaveler_tdBirthday.Controls.Add(lblTravelerBirthdayTh);
                    tableTaveler_tdBirthday.Controls.Add(txtTravelerBirthday);

                    tableTaveler_tr.Controls.Add(tableTaveler_tdBirthday);

                    //--------------  TravelerPassportNo -----------------------
                    HtmlTableCell tableTaveler_tdPassportNo = new HtmlTableCell();
                    tableTaveler_tdPassportNo.Align = "left";

                    Label lblTravelerPassportNo = new Label();
                    lblTravelerPassportNo.Font.Bold = true;
                    lblTravelerPassportNo.ID = "lblTraveler" + code + "PassportNo";
                    lblTravelerPassportNo.Text = "<font color=red>*</font>&nbsp;" + "Passport No : <br/>&nbsp;&nbsp;&nbsp;";

                    Label lblTravelerPassportNoTh = new Label();
                    lblTravelerPassportNoTh.Font.Bold = true;
                    lblTravelerPassportNoTh.Font.Size = FontUnit.Point(8);
                    lblTravelerPassportNoTh.ID = "lblTraveler" + code + "PassportNo_th";
                    lblTravelerPassportNoTh.Text = "เลขที่หนังสือเดินทาง <br />";

                    HtmlInputText txtTravelerPassportNo = new HtmlInputText();
                    txtTravelerPassportNo.ID = "txtTraveler" + code + "PassportNo";
                    txtTravelerPassportNo.Style.Add("width", "120px");
                    txtTravelerPassportNo.MaxLength = 13;
                    txtTravelerPassportNo.Value = dt.Rows[index]["PassportID"].ToString().Trim();//Request.Form["ctl00$MainContent$ddlTraveler" + code + "PassportNo"];

                    tableTaveler_tdPassportNo.Controls.Add(lblTravelerPassportNo);
                    tableTaveler_tdPassportNo.Controls.Add(lblTravelerPassportNoTh);
                    tableTaveler_tdPassportNo.Controls.Add(txtTravelerPassportNo);

                    tableTaveler_tr.Controls.Add(tableTaveler_tdPassportNo);

                    //--------------  TravelerTel -----------------------
                    HtmlTableCell tableTaveler_tdTel = new HtmlTableCell();
                    tableTaveler_tdTel.Align = "left";

                    Label lblTravelerTel = new Label();
                    lblTravelerTel.Font.Bold = true;
                    lblTravelerTel.ID = "lblTraveler" + code + "Tel";
                    lblTravelerTel.Text = "<font color=red>*</font>&nbsp;" + "Tel : <br/>&nbsp;&nbsp;&nbsp;";

                    Label lblTravelerTelTh = new Label();
                    lblTravelerTelTh.Font.Bold = true;
                    lblTravelerTelTh.Font.Size = FontUnit.Point(8);
                    lblTravelerTelTh.ID = "lblTraveler" + code + "Tel_th";
                    lblTravelerTelTh.Text = "เบอร์โทรศัพท์ <br />";

                    HtmlInputText txtTravelerTel = new HtmlInputText();
                    txtTravelerTel.ID = "txtTraveler" + code + "Tel";
                    txtTravelerTel.Style.Add("width", "120px");
                    txtTravelerTel.MaxLength = 30;
                    txtTravelerTel.Value = dt.Rows[index]["Tel"].ToString().Trim();//Request.Form["ctl00$MainContent$ddlTraveler" + code + "Tel"];

                    tableTaveler_tdTel.Controls.Add(lblTravelerTel);
                    tableTaveler_tdTel.Controls.Add(lblTravelerTelTh);
                    tableTaveler_tdTel.Controls.Add(txtTravelerTel);

                    tableTaveler_tr.Controls.Add(tableTaveler_tdTel);

                    //--------------  lblTraveler1Email -----------------------
                    //HtmlTableCell tableTaveler_tdEmail = new HtmlTableCell();
                    //tableTaveler_tdEmail.Align = "left";

                    //Label lblTravelerEmail = new Label();
                    //lblTravelerEmail.Font.Bold = true;
                    //lblTravelerEmail.ID = "lblTraveler" + code + "Email";
                    //lblTravelerEmail.Text = "Email : ";

                    //HtmlInputText txtTravelerEmail = new HtmlInputText();
                    //txtTravelerEmail.ID = "txtTraveler" + code + "Email";
                    //txtTravelerEmail.Style.Add("width", "80px");
                    //txtTravelerEmail.MaxLength = 30;

                    //tableTaveler_tdEmail.Controls.Add(lblTravelerEmail);
                    //tableTaveler_tdEmail.Controls.Add(txtTravelerEmail);

                    //tableTaveler_tr.Controls.Add(tableTaveler_tdEmail);

                    //>>>>>>>>>>>>>>>  new rows -----------------------

                    HtmlTableRow tableTaveler_tr2 = new HtmlTableRow();
                    tableTaveler.Controls.Add(tableTaveler_tr2);

                    HtmlTableCell tableTaveler_td6 = new HtmlTableCell();
                    tableTaveler_td6.ColSpan = 6;
                    tableTaveler_td6.Align = "right";
                    tableTaveler_tr2.Controls.Add(tableTaveler_td6);

                    //-------------- TravelerOccupation -----------------------


                    HtmlTable tableTravelerOcc = new HtmlTable();
                    tableTravelerOcc.CellPadding = 2;
                    tableTravelerOcc.CellSpacing = 0;

                    tableTaveler_td6.Controls.Add(tableTravelerOcc);

                    HtmlTableRow tableTravelerOcc_row = new HtmlTableRow();
                    tableTravelerOcc.Controls.Add(tableTravelerOcc_row);

                    HtmlTableCell tableTaveler_tdOccupation1 = new HtmlTableCell();
                    tableTaveler_tdOccupation1.Align = "right";


                    Label lblTravelerOccupation = new Label();
                    lblTravelerOccupation.Font.Bold = true;
                    lblTravelerOccupation.ID = "lblTraveler" + code + "Occupation";
                    lblTravelerOccupation.Text = "Occupation : <br/>";

                    Label lblTravelerOccupationTh = new Label();
                    lblTravelerOccupationTh.Font.Bold = true;
                    lblTravelerOccupationTh.Font.Size = FontUnit.Point(8);
                    lblTravelerOccupationTh.ID = "lblTraveler" + code + "Occupation_th";
                    lblTravelerOccupationTh.Text = "อาชีพ";

                    HtmlTableCell tableTaveler_tdOccupation2 = new HtmlTableCell();
                    tableTaveler_tdOccupation2.Align = "left";
                    tableTaveler_tdOccupation2.VAlign = "top";

                    CheckBox chkTravelerOccupation = new CheckBox();
                    chkTravelerOccupation.ID = "chkTraveler" + code + "Occupation";
                    chkTravelerOccupation.Text = "Student";



                    if (!string.IsNullOrEmpty(dt.Rows[index]["isStudent"].ToString().Trim()))
                    {
                        if (dt.Rows[index]["isStudent"].ToString().Trim() == "0")
                        {
                            chkTravelerOccupation.Checked = false;
                        }
                        else
                        {
                            chkTravelerOccupation.Checked = true;
                        }

                    }


                    HtmlAnchor br = new HtmlAnchor();
                    br.InnerHtml = "<br/>";

                    tableTaveler_tdOccupation1.Controls.Add(lblTravelerOccupation);
                    tableTaveler_tdOccupation1.Controls.Add(lblTravelerOccupationTh);

                    tableTaveler_tdOccupation2.Controls.Add(chkTravelerOccupation);

                    tableTravelerOcc_row.Controls.Add(tableTaveler_tdOccupation1);
                    tableTravelerOcc_row.Controls.Add(tableTaveler_tdOccupation2);

                    //-------------- TravelerStatus -----------------------
                    HtmlTableRow tableTravelerStatus_row = new HtmlTableRow();
                    tableTravelerOcc.Controls.Add(tableTravelerStatus_row);

                    HtmlTableCell tableTaveler_tdStatus1 = new HtmlTableCell();
                    tableTaveler_tdStatus1.Align = "right";

                    Label lblTravelerStatus = new Label();
                    lblTravelerStatus.Font.Bold = true;
                    lblTravelerStatus.ID = "lblTraveler" + code + "Status";
                    lblTravelerStatus.Text = "Status : <br/>";

                    Label lblTravelerStatusTh = new Label();
                    lblTravelerStatusTh.Font.Bold = true;
                    lblTravelerStatusTh.Font.Size = FontUnit.Point(8);
                    lblTravelerStatusTh.ID = "lblTraveler" + code + "Status_th";
                    lblTravelerStatusTh.Text = "สถานะ ";

                    HtmlTableCell tableTaveler_tdStatus2 = new HtmlTableCell();
                    tableTaveler_tdStatus2.Align = "left";
                    tableTaveler_tdStatus2.VAlign = "top";
                    tableTaveler_tdStatus2.Width = "80px";

                    CheckBox chkTravelerStatus = new CheckBox();
                    chkTravelerStatus.ID = "chkTraveler" + code + "Status";
                    chkTravelerStatus.Text = "Single";
                    if (!string.IsNullOrEmpty(dt.Rows[index]["isSingle"].ToString().Trim()))
                    {
                        if (dt.Rows[index]["isSingle"].ToString().Trim() == "0")
                        {
                            chkTravelerStatus.Checked = false;
                        }
                        else
                        {
                            chkTravelerStatus.Checked = true;
                        }

                    }


                    tableTaveler_tdStatus1.Controls.Add(lblTravelerStatus);
                    tableTaveler_tdStatus1.Controls.Add(lblTravelerStatusTh);
                    tableTaveler_tdStatus2.Controls.Add(chkTravelerStatus);

                    tableTravelerStatus_row.Controls.Add(tableTaveler_tdStatus1);
                    tableTravelerStatus_row.Controls.Add(tableTaveler_tdStatus2);

                    //-----------------end table 1-----------------------------
                    #endregion

                    //------------------table Beneficialy---------------------
                    HtmlTable tableBeneficialy1 = new HtmlTable();
                    tableBeneficialy1.Align = "center";
                    tableBeneficialy1.Width = "80%";

                    div.Controls.Add(tableBeneficialy1);


                    #region Table Beneficialy 
                    
                    //Bind benefit traveler
                    TATransBeneficiaryBLL clstransbenefit = new TATransBeneficiaryBLL();
                    DataTable dtbenefit = clstransbenefit.GetDtTATransBeneficiary(JobNo,code);

                    //Benefit Group by TravelerID
                    if (dtbenefit.Rows.Count > 0)
                    {
                        #region Table Beneficialy 1
                        //-------------- Beneficialy row 1----------------------
                        HtmlTableRow tableBeneficialy1_tr = new HtmlTableRow();

                        tableBeneficialy1.Controls.Add(tableBeneficialy1_tr);

                        HtmlTableCell tableBeneficialy1_tdBeneficialy = new HtmlTableCell();
                        tableBeneficialy1_tdBeneficialy.Align = "left";
                        tableBeneficialy1_tdBeneficialy.Width = "80px";

                        Label lblTravelerBeneficialy = new Label();
                        lblTravelerBeneficialy.ID = "lblTraveler" + code + "Beneficialy";
                        lblTravelerBeneficialy.Font.Bold = true;
                        lblTravelerBeneficialy.Text = "Beneficiary :";

                        Label lblTravelerBeneficialyTh = new Label();
                        lblTravelerBeneficialyTh.ID = "lblTraveler" + code + "Beneficialy_th";
                        lblTravelerBeneficialyTh.Font.Bold = true;
                        lblTravelerBeneficialyTh.Font.Size = FontUnit.Point(8);
                        lblTravelerBeneficialyTh.Text = "ผู้รับประโยชน์";

                        tableBeneficialy1_tdBeneficialy.Controls.Add(lblTravelerBeneficialy);
                        tableBeneficialy1_tdBeneficialy.Controls.Add(lblTravelerBeneficialyTh);

                        tableBeneficialy1_tr.Controls.Add(tableBeneficialy1_tdBeneficialy);

                        HtmlTableCell tableBeneficialy1_tdBeneficialyHeir = new HtmlTableCell();
                        tableBeneficialy1_tdBeneficialyHeir.Align = "left";
                        tableBeneficialy1_tdBeneficialyHeir.VAlign = "top";

                        CheckBox chkTravelerBeneficialyHeir = new CheckBox();
                        chkTravelerBeneficialyHeir.ID = "chkTraveler" + code + "BeneficialyHeir";

                        chkTravelerBeneficialyHeir.Text = "&nbsp;Estate of the Insured person /กองมรดกของผู้เอาประกันภัย";

                        chkTravelerBeneficialyHeir.Checked = false;
                        
                        tableBeneficialy1_tdBeneficialyHeir.Controls.Add(chkTravelerBeneficialyHeir);

                        tableBeneficialy1_tr.Controls.Add(tableBeneficialy1_tdBeneficialyHeir);

                        #endregion

                        HtmlTable tableBeneficialy2 = new HtmlTable();
                        tableBeneficialy2.Align = "center";
                        tableBeneficialy2.Width = "80%";

                        div.Controls.Add(tableBeneficialy2);

                        HtmlTableRow tableBeneficialy2_tr = new HtmlTableRow();

                        tableBeneficialy2.Controls.Add(tableBeneficialy2_tr);

                        //HAVE DATA
                        int loopcount = 0;
                        foreach (DataRow row in dtbenefit.Rows)
                        {
                            loopcount += 1;
                            string m_travelerid = row["TravelerID"].ToString().Trim();
                            string m_seq = row["Seq"].ToString().Trim();
                            for (int j = 1; j < 4; j++)
                            {
                                if (m_seq == j.ToString()) //1 == 1
                                {
                                    #region "Bind Benefit from DB"
                                    HtmlTableRow tableBeneficialy2_tr2 = new HtmlTableRow();
                                    tableBeneficialy2.Controls.Add(tableBeneficialy2_tr2);

                                    //---------------------- lblTraveler1BeneficialyTitle1- ---------------
                                    HtmlTableCell tableBeneficialy2_tdBeneficialyTitle = new HtmlTableCell();
                                    tableBeneficialy2_tdBeneficialyTitle.Align = "left";

                                    Label lblTravelerBeneficialyTitle = new Label();
                                    lblTravelerBeneficialyTitle.ID = "lblTraveler" + code + "BeneficialyTitle" + j.ToString();
                                    lblTravelerBeneficialyTitle.Font.Bold = true;
                                    lblTravelerBeneficialyTitle.Text = "<font color=red>*</font>&nbsp;" + "Title : <br/>&nbsp;&nbsp;&nbsp;";

                                    Label lblTravelerBeneficialyTitleTh = new Label();
                                    lblTravelerBeneficialyTitleTh.ID = "lblTraveler" + code + "BeneficialyTitle" + j.ToString() + "_th";
                                    lblTravelerBeneficialyTitleTh.Font.Bold = true;
                                    lblTravelerBeneficialyTitleTh.Font.Size = FontUnit.Point(8);
                                    lblTravelerBeneficialyTitleTh.Text = "คำนำหน้าชื่อ <br/>";

                                    DropDownList ddlTravelerBeneficialyTitle = new DropDownList();
                                    ddlTravelerBeneficialyTitle.Width = 110;
                                    ddlTravelerBeneficialyTitle.ID = "ddlTraveler" + code + "BeneficialyTitle" + j.ToString();
                                    if (this.ddlLanguage.SelectedValue == "E")
                                    {
                                        SetTitleToDropdownList(ddlTravelerBeneficialyTitle);
                                    }
                                    else
                                    {
                                        SetThaiTitleToDropdownList(ddlTravelerBeneficialyTitle);
                                    }
                                    ddlTravelerBeneficialyTitle.SelectedValue = row["BeneficiaryTitle"].ToString().Trim();

                                    //-------VVVVVVVVVVVVVVVVVVVVVVVVVVV------------
                                    
                                    if (j == 1)
                                    {
                                        tableBeneficialy2_tdBeneficialyTitle.Controls.Add(lblTravelerBeneficialyTitle);
                                        tableBeneficialy2_tdBeneficialyTitle.Controls.Add(lblTravelerBeneficialyTitleTh);

                                    }
                                    tableBeneficialy2_tdBeneficialyTitle.Controls.Add(ddlTravelerBeneficialyTitle);

                                    tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyTitle);

                                    //---------------------- lblTraveler1BeneficialyName1- ---------------
                                    HtmlTableCell tableBeneficialy2_tdBeneficialyName = new HtmlTableCell();
                                    tableBeneficialy2_tdBeneficialyName.Align = "left";

                                    Label lblTravelerBeneficialyName = new Label();
                                    lblTravelerBeneficialyName.ID = "lblTraveler" + code + "BeneficialyName" + j.ToString();
                                    lblTravelerBeneficialyName.Font.Bold = true;
                                    lblTravelerBeneficialyName.Text = "<font color=red>*</font>&nbsp;" + "Name : <br/>&nbsp;&nbsp;&nbsp;";

                                    Label lblTravelerBeneficialyNameTh = new Label();
                                    lblTravelerBeneficialyNameTh.ID = "lblTraveler" + code + "BeneficialyName" + j.ToString() + "_th";
                                    lblTravelerBeneficialyNameTh.Font.Bold = true;
                                    lblTravelerBeneficialyNameTh.Font.Size = FontUnit.Point(8);
                                    lblTravelerBeneficialyNameTh.Text = "ชื่อ <br/>";

                                    HtmlInputText txtTravelerBeneficialyName = new HtmlInputText();
                                    txtTravelerBeneficialyName.MaxLength = 100;
                                    txtTravelerBeneficialyName.Style.Add("width", "195px");
                                    txtTravelerBeneficialyName.ID = "txtTraveler" + code + "BeneficialyName" + j.ToString();
                                    txtTravelerBeneficialyName.Value = row["BeneficiaryName"].ToString().Trim(); //Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialyName" + j.ToString()];

                                    if (j == 1)
                                    {
                                        tableBeneficialy2_tdBeneficialyName.Controls.Add(lblTravelerBeneficialyName);
                                        tableBeneficialy2_tdBeneficialyName.Controls.Add(lblTravelerBeneficialyNameTh);
                                        //br = new HtmlAnchor();
                                        //br.InnerHtml = "<br/>";
                                        //tableBeneficialy_tdBeneficialyName.Controls.Add(br);
                                    }
                                    tableBeneficialy2_tdBeneficialyName.Controls.Add(txtTravelerBeneficialyName);

                                    tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyName);

                                    //---------------------- lblTraveler1BeneficialySurname1- ---------------
                                    HtmlTableCell tableBeneficialy2_tdBeneficialySurname = new HtmlTableCell();
                                    tableBeneficialy2_tdBeneficialySurname.Align = "left";

                                    Label lblTravelerBeneficialySurname = new Label();
                                    lblTravelerBeneficialySurname.ID = "lblTraveler" + code + "BeneficialySurname" + j.ToString();
                                    lblTravelerBeneficialySurname.Font.Bold = true;
                                    lblTravelerBeneficialySurname.Text = "<font color=red>*</font>&nbsp;" + "Family name : <br/>&nbsp;&nbsp;&nbsp;";

                                    Label lblTravelerBeneficialySurnameTh = new Label();
                                    lblTravelerBeneficialySurnameTh.ID = "lblTraveler" + code + "BeneficialySurname" + j.ToString() + "_th";
                                    lblTravelerBeneficialySurnameTh.Font.Bold = true;
                                    lblTravelerBeneficialySurnameTh.Font.Size = FontUnit.Point(8);
                                    lblTravelerBeneficialySurnameTh.Text = "นามสกุล <br/>";

                                    HtmlInputText txtTravelerBeneficialySurname = new HtmlInputText();
                                    txtTravelerBeneficialySurname.Style.Add("width", "195px");
                                    txtTravelerBeneficialySurname.ID = "txtTraveler" + code + "BeneficialySurname" + j.ToString();
                                    txtTravelerBeneficialySurname.Value = row["BeneficiarySurName"].ToString().Trim(); //Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialySurname" + j.ToString()];


                                    if (j == 1)
                                    {
                                        tableBeneficialy2_tdBeneficialySurname.Controls.Add(lblTravelerBeneficialySurname);
                                        tableBeneficialy2_tdBeneficialySurname.Controls.Add(lblTravelerBeneficialySurnameTh);
                                        //br = new HtmlAnchor();
                                        //br.InnerHtml = "<br/>";
                                        //tableBeneficialy_tdBeneficialySurname.Controls.Add(br);
                                    }
                                    tableBeneficialy2_tdBeneficialySurname.Controls.Add(txtTravelerBeneficialySurname);

                                    tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialySurname);

                                    //---------------------- lblTraveler1BeneficialyRelationShip1- ---------------
                                    HtmlTableCell tableBeneficialy2_tdBeneficialyRelationShip = new HtmlTableCell();
                                    tableBeneficialy2_tdBeneficialyRelationShip.Align = "left";

                                    Label lblTravelerBeneficialyRelationShip = new Label();
                                    lblTravelerBeneficialyRelationShip.ID = "lblTraveler" + code + "BeneficialyRelationShip" + j.ToString();
                                    lblTravelerBeneficialyRelationShip.Font.Bold = true;
                                    lblTravelerBeneficialyRelationShip.Text = "RelationShip : <br/>";

                                    Label lblTravelerBeneficialyRelationShipTh = new Label();
                                    lblTravelerBeneficialyRelationShipTh.ID = "lblTraveler" + code + "BeneficialyRelationShip" + j.ToString() + "_th";
                                    lblTravelerBeneficialyRelationShipTh.Font.Bold = true;
                                    lblTravelerBeneficialyRelationShipTh.Font.Size = FontUnit.Point(8);
                                    lblTravelerBeneficialyRelationShipTh.Text = "ความสัมพันธ์กับผู้เอาประกันภัย<br/>";

                                    DropDownList ddlTravelerBeneficialyRelationShip = new DropDownList();
                                    ddlTravelerBeneficialyRelationShip.ID = "ddlTraveler" + code + "BeneficialyRelationShip" + j.ToString();
                                    ddlTravelerBeneficialyRelationShip.Style.Add("width", "150px");
                                    SetRelationToDropdownList(ddlTravelerBeneficialyRelationShip, this.ddlLanguage.SelectedValue.ToString());
                                    ddlTravelerBeneficialyRelationShip.SelectedValue = row["BeneficiaryRelation"].ToString().Trim(); //Request.Form["ctl00$MainContent$ddlTraveler" + code + "BeneficialyRelationShip" + j.ToString()];
                                    //-------VVVVVVVVVVVVVVVVVVVVVVVVVVV------------
                                    

                                    if (j == 1)
                                    {
                                        tableBeneficialy2_tdBeneficialyRelationShip.Controls.Add(lblTravelerBeneficialyRelationShip);
                                        tableBeneficialy2_tdBeneficialyRelationShip.Controls.Add(lblTravelerBeneficialyRelationShipTh);
                                        //br = new HtmlAnchor();
                                        //br.InnerHtml = "<br/>";
                                        //tableBeneficialy_tdBeneficialyRelationShip.Controls.Add(br);
                                    }
                                    tableBeneficialy2_tdBeneficialyRelationShip.Controls.Add(ddlTravelerBeneficialyRelationShip);

                                    tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyRelationShip);

                                    #region #//Part of Traveler Beneficiary Ratio
                                    HtmlTableCell tableBeneficialy2_tdBeneficialyRatio = new HtmlTableCell();
                                    tableBeneficialy2_tdBeneficialyRatio.Align = "left";

                                    Label lblTravelerBeneficialyRatio = new Label();
                                    lblTravelerBeneficialyRatio.ID = "lblTraveler" + code + "BeneficialyRatio" + j.ToString();
                                    lblTravelerBeneficialyRatio.Font.Bold = true;
                                    lblTravelerBeneficialyRatio.Text = "<font color=red>*</font>&nbsp;" + "Ratio : <br/>";

                                    Label lblTravelerBeneficialyRatioTh = new Label();
                                    lblTravelerBeneficialyRatioTh.ID = "lblTraveler" + code + "BeneficialyRatio" + j.ToString() + "_th";
                                    lblTravelerBeneficialyRatioTh.Font.Bold = true;
                                    lblTravelerBeneficialyRatioTh.Font.Size = FontUnit.Point(8);
                                    lblTravelerBeneficialyRatioTh.Text = "สัดส่วน<br/>";

                                    HtmlInputText txtTravelerBeneficialyRatio = new HtmlInputText();
                                    txtTravelerBeneficialyRatio.ID = "txtTraveler" + code + "BeneficialyRatio" + j.ToString();
                                    txtTravelerBeneficialyRatio.Style.Add("width", "70px");
                                    txtTravelerBeneficialyRatio.MaxLength = 3;
                                    txtTravelerBeneficialyRatio.Attributes.Add("onkeypress", "return numbersonly(event);");
                                    txtTravelerBeneficialyRatio.Value = row["BeneficiaryRatio"].ToString().Trim();//Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialyRatio" + j.ToString()];

                                    if (j == 1)
                                    {
                                        tableBeneficialy2_tdBeneficialyRatio.Controls.Add(lblTravelerBeneficialyRatio);
                                        tableBeneficialy2_tdBeneficialyRatio.Controls.Add(lblTravelerBeneficialyRatioTh);
                                    }

                                    tableBeneficialy2_tdBeneficialyRatio.Controls.Add(txtTravelerBeneficialyRatio);

                                    tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyRatio);

                                    #endregion

                                    //---------------------- lblTraveler1BeneficialyTel1- ---------------
                                    HtmlTableCell tableBeneficialy2_tdBeneficialyTel = new HtmlTableCell();
                                    tableBeneficialy2_tdBeneficialyTel.Align = "left";

                                    Label lblTravelerBeneficialyTel = new Label();
                                    lblTravelerBeneficialyTel.ID = "lblTraveler" + code + "BeneficialyTel" + j.ToString();
                                    lblTravelerBeneficialyTel.Font.Bold = true;
                                    lblTravelerBeneficialyTel.Text = "Tel : <br/>";

                                    Label lblTravelerBeneficialyTelTh = new Label();
                                    lblTravelerBeneficialyTelTh.ID = "lblTraveler" + code + "BeneficialyTel" + j.ToString() + "_th";
                                    lblTravelerBeneficialyTelTh.Font.Bold = true;
                                    lblTravelerBeneficialyTelTh.Font.Size = FontUnit.Point(8);
                                    lblTravelerBeneficialyTelTh.Text = "เบอร์โทรศัพท์<br/>";

                                    HtmlInputText txtTravelerBeneficialyTel = new HtmlInputText();
                                    txtTravelerBeneficialyTel.ID = "txtTraveler" + code + "BeneficialyTel" + j.ToString();
                                    txtTravelerBeneficialyTel.Style.Add("width", "120px");
                                    txtTravelerBeneficialyTel.MaxLength = 100;
                                    txtTravelerBeneficialyTel.Value = row["BeneficiaryTel"].ToString().Trim(); //Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialyTel" + j.ToString()];


                                    if (j == 1)
                                    {
                                        tableBeneficialy2_tdBeneficialyTel.Controls.Add(lblTravelerBeneficialyTel);
                                        tableBeneficialy2_tdBeneficialyTel.Controls.Add(lblTravelerBeneficialyTelTh);
                                        //br = new HtmlAnchor();
                                        //br.InnerHtml = "<br/>";
                                        //tableBeneficialy_tdBeneficialyTel.Controls.Add(br);
                                    }

                                    tableBeneficialy2_tdBeneficialyTel.Controls.Add(txtTravelerBeneficialyTel);

                                    tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyTel);
                                    #endregion
                                }
                            }    
                        }
                        if (loopcount < 3)
                        {
                            for (int j = loopcount+1; j < 4 ; j++)
                            {
                                #region "Bind Benefit default"
                                HtmlTableRow tableBeneficialy2_tr2 = new HtmlTableRow();
                                tableBeneficialy2.Controls.Add(tableBeneficialy2_tr2);

                                //---------------------- lblTraveler1BeneficialyTitle1- ---------------
                                HtmlTableCell tableBeneficialy2_tdBeneficialyTitle = new HtmlTableCell();
                                tableBeneficialy2_tdBeneficialyTitle.Align = "left";

                                Label lblTravelerBeneficialyTitle = new Label();
                                lblTravelerBeneficialyTitle.ID = "lblTraveler" + code + "BeneficialyTitle" + j.ToString();
                                lblTravelerBeneficialyTitle.Font.Bold = true;
                                lblTravelerBeneficialyTitle.Text = "<font color=red>*</font>&nbsp;" + "Title : <br/>&nbsp;&nbsp;&nbsp;";

                                Label lblTravelerBeneficialyTitleTh = new Label();
                                lblTravelerBeneficialyTitleTh.ID = "lblTraveler" + code + "BeneficialyTitle" + j.ToString() + "_th";
                                lblTravelerBeneficialyTitleTh.Font.Bold = true;
                                lblTravelerBeneficialyTitleTh.Font.Size = FontUnit.Point(8);
                                lblTravelerBeneficialyTitleTh.Text = "คำนำหน้าชื่อ <br/>";

                                DropDownList ddlTravelerBeneficialyTitle = new DropDownList();
                                ddlTravelerBeneficialyTitle.Width = 110;
                                ddlTravelerBeneficialyTitle.ID = "ddlTraveler" + code + "BeneficialyTitle" + j.ToString();
                                if (this.ddlLanguage.SelectedValue == "E")
                                {
                                    SetTitleToDropdownList(ddlTravelerBeneficialyTitle);
                                }
                                else
                                {
                                    SetThaiTitleToDropdownList(ddlTravelerBeneficialyTitle);
                                }
                                ddlTravelerBeneficialyTitle.SelectedValue = Request.Form["ctl00$MainContent$ddlTraveler" + code + "BeneficialyTitle" + j.ToString()];

                                //-------VVVVVVVVVVVVVVVVVVVVVVVVVVV------------
                                
                                if (j == 1)
                                {
                                    tableBeneficialy2_tdBeneficialyTitle.Controls.Add(lblTravelerBeneficialyTitle);
                                    tableBeneficialy2_tdBeneficialyTitle.Controls.Add(lblTravelerBeneficialyTitleTh);
                                    //br = new HtmlAnchor();
                                    //br.InnerHtml = "<br/>";
                                    //tableBeneficialy_tdBeneficialyTitle.Controls.Add(br);
                                }
                                tableBeneficialy2_tdBeneficialyTitle.Controls.Add(ddlTravelerBeneficialyTitle);

                                tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyTitle);

                                //---------------------- lblTraveler1BeneficialyName1- ---------------
                                HtmlTableCell tableBeneficialy2_tdBeneficialyName = new HtmlTableCell();
                                tableBeneficialy2_tdBeneficialyName.Align = "left";

                                Label lblTravelerBeneficialyName = new Label();
                                lblTravelerBeneficialyName.ID = "lblTraveler" + code + "BeneficialyName" + j.ToString();
                                lblTravelerBeneficialyName.Font.Bold = true;
                                lblTravelerBeneficialyName.Text = "<font color=red>*</font>&nbsp;" + "Name : <br/>&nbsp;&nbsp;&nbsp;";

                                Label lblTravelerBeneficialyNameTh = new Label();
                                lblTravelerBeneficialyNameTh.ID = "lblTraveler" + code + "BeneficialyName" + j.ToString() + "_th";
                                lblTravelerBeneficialyNameTh.Font.Bold = true;
                                lblTravelerBeneficialyNameTh.Font.Size = FontUnit.Point(8);
                                lblTravelerBeneficialyNameTh.Text = "ชื่อ <br/>";

                                HtmlInputText txtTravelerBeneficialyName = new HtmlInputText();
                                txtTravelerBeneficialyName.MaxLength = 100;
                                txtTravelerBeneficialyName.Style.Add("width", "195px");
                                txtTravelerBeneficialyName.ID = "txtTraveler" + code + "BeneficialyName" + j.ToString();
                                txtTravelerBeneficialyName.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialyName" + j.ToString()];

                                if (j == 1)
                                {
                                    tableBeneficialy2_tdBeneficialyName.Controls.Add(lblTravelerBeneficialyName);
                                    tableBeneficialy2_tdBeneficialyName.Controls.Add(lblTravelerBeneficialyNameTh);
                                    //br = new HtmlAnchor();
                                    //br.InnerHtml = "<br/>";
                                    //tableBeneficialy_tdBeneficialyName.Controls.Add(br);
                                }
                                tableBeneficialy2_tdBeneficialyName.Controls.Add(txtTravelerBeneficialyName);

                                tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyName);

                                //---------------------- lblTraveler1BeneficialySurname1- ---------------
                                HtmlTableCell tableBeneficialy2_tdBeneficialySurname = new HtmlTableCell();
                                tableBeneficialy2_tdBeneficialySurname.Align = "left";

                                Label lblTravelerBeneficialySurname = new Label();
                                lblTravelerBeneficialySurname.ID = "lblTraveler" + code + "BeneficialySurname" + j.ToString();
                                lblTravelerBeneficialySurname.Font.Bold = true;
                                lblTravelerBeneficialySurname.Text = "<font color=red>*</font>&nbsp;" + "Family name : <br/>&nbsp;&nbsp;&nbsp;";

                                Label lblTravelerBeneficialySurnameTh = new Label();
                                lblTravelerBeneficialySurnameTh.ID = "lblTraveler" + code + "BeneficialySurname" + j.ToString() + "_th";
                                lblTravelerBeneficialySurnameTh.Font.Bold = true;
                                lblTravelerBeneficialySurnameTh.Font.Size = FontUnit.Point(8);
                                lblTravelerBeneficialySurnameTh.Text = "นามสกุล <br/>";

                                HtmlInputText txtTravelerBeneficialySurname = new HtmlInputText();
                                txtTravelerBeneficialySurname.Style.Add("width", "195px");
                                txtTravelerBeneficialySurname.ID = "txtTraveler" + code + "BeneficialySurname" + j.ToString();
                                txtTravelerBeneficialySurname.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialySurname" + j.ToString()];


                                if (j == 1)
                                {
                                    tableBeneficialy2_tdBeneficialySurname.Controls.Add(lblTravelerBeneficialySurname);
                                    tableBeneficialy2_tdBeneficialySurname.Controls.Add(lblTravelerBeneficialySurnameTh);
                                    //br = new HtmlAnchor();
                                    //br.InnerHtml = "<br/>";
                                    //tableBeneficialy_tdBeneficialySurname.Controls.Add(br);
                                }
                                tableBeneficialy2_tdBeneficialySurname.Controls.Add(txtTravelerBeneficialySurname);

                                tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialySurname);

                                //---------------------- lblTraveler1BeneficialyRelationShip1- ---------------
                                HtmlTableCell tableBeneficialy2_tdBeneficialyRelationShip = new HtmlTableCell();
                                tableBeneficialy2_tdBeneficialyRelationShip.Align = "left";

                                Label lblTravelerBeneficialyRelationShip = new Label();
                                lblTravelerBeneficialyRelationShip.ID = "lblTraveler" + code + "BeneficialyRelationShip" + j.ToString();
                                lblTravelerBeneficialyRelationShip.Font.Bold = true;
                                lblTravelerBeneficialyRelationShip.Text = "RelationShip : <br/>";

                                Label lblTravelerBeneficialyRelationShipTh = new Label();
                                lblTravelerBeneficialyRelationShipTh.ID = "lblTraveler" + code + "BeneficialyRelationShip" + j.ToString() + "_th";
                                lblTravelerBeneficialyRelationShipTh.Font.Bold = true;
                                lblTravelerBeneficialyRelationShipTh.Font.Size = FontUnit.Point(8);
                                lblTravelerBeneficialyRelationShipTh.Text = "ความสัมพันธ์กับผู้เอาประกันภัย<br/>";

                                DropDownList ddlTravelerBeneficialyRelationShip = new DropDownList();
                                ddlTravelerBeneficialyRelationShip.ID = "ddlTraveler" + code + "BeneficialyRelationShip" + j.ToString();
                                ddlTravelerBeneficialyRelationShip.Style.Add("width", "150px");
                                SetRelationToDropdownList(ddlTravelerBeneficialyRelationShip, this.ddlLanguage.SelectedValue.ToString());
                                ddlTravelerBeneficialyRelationShip.SelectedValue = Request.Form["ctl00$MainContent$ddlTraveler" + code + "BeneficialyRelationShip" + j.ToString()];
                                //-------VVVVVVVVVVVVVVVVVVVVVVVVVVV------------
                                

                                if (j == 1)
                                {
                                    tableBeneficialy2_tdBeneficialyRelationShip.Controls.Add(lblTravelerBeneficialyRelationShip);
                                    tableBeneficialy2_tdBeneficialyRelationShip.Controls.Add(lblTravelerBeneficialyRelationShipTh);
                                    //br = new HtmlAnchor();
                                    //br.InnerHtml = "<br/>";
                                    //tableBeneficialy_tdBeneficialyRelationShip.Controls.Add(br);
                                }
                                tableBeneficialy2_tdBeneficialyRelationShip.Controls.Add(ddlTravelerBeneficialyRelationShip);

                                tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyRelationShip);

                                #region #//Part of Traveler Beneficiary Ratio
                                HtmlTableCell tableBeneficialy2_tdBeneficialyRatio = new HtmlTableCell();
                                tableBeneficialy2_tdBeneficialyRatio.Align = "left";

                                Label lblTravelerBeneficialyRatio = new Label();
                                lblTravelerBeneficialyRatio.ID = "lblTraveler" + code + "BeneficialyRatio" + j.ToString();
                                lblTravelerBeneficialyRatio.Font.Bold = true;
                                lblTravelerBeneficialyRatio.Text = "<font color=red>*</font>&nbsp;" + "Ratio : <br/>";

                                Label lblTravelerBeneficialyRatioTh = new Label();
                                lblTravelerBeneficialyRatioTh.ID = "lblTraveler" + code + "BeneficialyRatio" + j.ToString() + "_th";
                                lblTravelerBeneficialyRatioTh.Font.Bold = true;
                                lblTravelerBeneficialyRatioTh.Font.Size = FontUnit.Point(8);
                                lblTravelerBeneficialyRatioTh.Text = "สัดส่วน<br/>";

                                HtmlInputText txtTravelerBeneficialyRatio = new HtmlInputText();
                                txtTravelerBeneficialyRatio.ID = "txtTraveler" + code + "BeneficialyRatio" + j.ToString();
                                txtTravelerBeneficialyRatio.Style.Add("width", "70px");
                                txtTravelerBeneficialyRatio.MaxLength = 3;
                                txtTravelerBeneficialyRatio.Attributes.Add("onkeypress", "return numbersonly(event);");
                                txtTravelerBeneficialyRatio.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialyRatio" + j.ToString()];

                                if (j == 1)
                                {
                                    tableBeneficialy2_tdBeneficialyRatio.Controls.Add(lblTravelerBeneficialyRatio);
                                    tableBeneficialy2_tdBeneficialyRatio.Controls.Add(lblTravelerBeneficialyRatioTh);
                                }

                                tableBeneficialy2_tdBeneficialyRatio.Controls.Add(txtTravelerBeneficialyRatio);

                                tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyRatio);

                                #endregion

                                //---------------------- lblTraveler1BeneficialyTel1- ---------------
                                HtmlTableCell tableBeneficialy2_tdBeneficialyTel = new HtmlTableCell();
                                tableBeneficialy2_tdBeneficialyTel.Align = "left";

                                Label lblTravelerBeneficialyTel = new Label();
                                lblTravelerBeneficialyTel.ID = "lblTraveler" + code + "BeneficialyTel" + j.ToString();
                                lblTravelerBeneficialyTel.Font.Bold = true;
                                lblTravelerBeneficialyTel.Text = "Tel : <br/>";

                                Label lblTravelerBeneficialyTelTh = new Label();
                                lblTravelerBeneficialyTelTh.ID = "lblTraveler" + code + "BeneficialyTel" + j.ToString() + "_th";
                                lblTravelerBeneficialyTelTh.Font.Bold = true;
                                lblTravelerBeneficialyTelTh.Font.Size = FontUnit.Point(8);
                                lblTravelerBeneficialyTelTh.Text = "เบอร์โทรศัพท์<br/>";

                                HtmlInputText txtTravelerBeneficialyTel = new HtmlInputText();
                                txtTravelerBeneficialyTel.ID = "txtTraveler" + code + "BeneficialyTel" + j.ToString();
                                txtTravelerBeneficialyTel.Style.Add("width", "120px");
                                txtTravelerBeneficialyTel.MaxLength = 100;
                                txtTravelerBeneficialyTel.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialyTel" + j.ToString()];


                                if (j == 1)
                                {
                                    tableBeneficialy2_tdBeneficialyTel.Controls.Add(lblTravelerBeneficialyTel);
                                    tableBeneficialy2_tdBeneficialyTel.Controls.Add(lblTravelerBeneficialyTelTh);
                                    //br = new HtmlAnchor();
                                    //br.InnerHtml = "<br/>";
                                    //tableBeneficialy_tdBeneficialyTel.Controls.Add(br);
                                }

                                tableBeneficialy2_tdBeneficialyTel.Controls.Add(txtTravelerBeneficialyTel);

                                tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyTel);
                                #endregion
                            }
                        }
                    }
                    else
                    {
                        /// No benefit
                        #region Table Beneficialy 1
                        //-------------- Beneficialy row 1----------------------
                        HtmlTableRow tableBeneficialy1_tr = new HtmlTableRow();

                        tableBeneficialy1.Controls.Add(tableBeneficialy1_tr);

                        HtmlTableCell tableBeneficialy1_tdBeneficialy = new HtmlTableCell();
                        tableBeneficialy1_tdBeneficialy.Align = "left";
                        tableBeneficialy1_tdBeneficialy.Width = "80px";

                        Label lblTravelerBeneficialy = new Label();
                        lblTravelerBeneficialy.ID = "lblTraveler" + code + "Beneficialy";
                        lblTravelerBeneficialy.Font.Bold = true;
                        lblTravelerBeneficialy.Text = "Beneficiary :";

                        Label lblTravelerBeneficialyTh = new Label();
                        lblTravelerBeneficialyTh.ID = "lblTraveler" + code + "Beneficialy_th";
                        lblTravelerBeneficialyTh.Font.Bold = true;
                        lblTravelerBeneficialyTh.Font.Size = FontUnit.Point(8);
                        lblTravelerBeneficialyTh.Text = "ผู้รับประโยชน์";

                        tableBeneficialy1_tdBeneficialy.Controls.Add(lblTravelerBeneficialy);
                        tableBeneficialy1_tdBeneficialy.Controls.Add(lblTravelerBeneficialyTh);

                        tableBeneficialy1_tr.Controls.Add(tableBeneficialy1_tdBeneficialy);

                        HtmlTableCell tableBeneficialy1_tdBeneficialyHeir = new HtmlTableCell();
                        tableBeneficialy1_tdBeneficialyHeir.Align = "left";
                        tableBeneficialy1_tdBeneficialyHeir.VAlign = "top";

                        CheckBox chkTravelerBeneficialyHeir = new CheckBox();
                        chkTravelerBeneficialyHeir.ID = "chkTraveler" + code + "BeneficialyHeir";

                        chkTravelerBeneficialyHeir.Text = "&nbsp;Estate of the Insured person /กองมรดกของผู้เอาประกันภัย";

                        if (Request.Form["ctl00$MainContent$chkTraveler" + code + "BeneficialyHeir"] == "")
                        {
                            chkTravelerBeneficialyHeir.Checked = Convert.ToBoolean(Request.Form["ctl00$MainContent$chkTraveler" + code + "BeneficialyHeir"]);
                        }
                        else
                        {
                            chkTravelerBeneficialyHeir.Checked = true;
                        }

                        tableBeneficialy1_tdBeneficialyHeir.Controls.Add(chkTravelerBeneficialyHeir);

                        tableBeneficialy1_tr.Controls.Add(tableBeneficialy1_tdBeneficialyHeir);

                        #endregion

                        HtmlTable tableBeneficialy2 = new HtmlTable();
                        tableBeneficialy2.Align = "center";
                        tableBeneficialy2.Width = "80%";

                        div.Controls.Add(tableBeneficialy2);

                        HtmlTableRow tableBeneficialy2_tr = new HtmlTableRow();

                        tableBeneficialy2.Controls.Add(tableBeneficialy2_tr);

                        for (int j = 1; j < 4; j++)
                        {
                            HtmlTableRow tableBeneficialy2_tr2 = new HtmlTableRow();
                            tableBeneficialy2.Controls.Add(tableBeneficialy2_tr2);

                            //---------------------- lblTraveler1BeneficialyTitle1- ---------------
                            HtmlTableCell tableBeneficialy2_tdBeneficialyTitle = new HtmlTableCell();
                            tableBeneficialy2_tdBeneficialyTitle.Align = "left";

                            Label lblTravelerBeneficialyTitle = new Label();
                            lblTravelerBeneficialyTitle.ID = "lblTraveler" + code + "BeneficialyTitle" + j.ToString();
                            lblTravelerBeneficialyTitle.Font.Bold = true;
                            lblTravelerBeneficialyTitle.Text = "<font color=red>*</font>&nbsp;" + "Title : <br/>&nbsp;&nbsp;&nbsp;";

                            Label lblTravelerBeneficialyTitleTh = new Label();
                            lblTravelerBeneficialyTitleTh.ID = "lblTraveler" + code + "BeneficialyTitle" + j.ToString() + "_th";
                            lblTravelerBeneficialyTitleTh.Font.Bold = true;
                            lblTravelerBeneficialyTitleTh.Font.Size = FontUnit.Point(8);
                            lblTravelerBeneficialyTitleTh.Text = "คำนำหน้าชื่อ <br/>";

                            DropDownList ddlTravelerBeneficialyTitle = new DropDownList();
                            ddlTravelerBeneficialyTitle.Width = 110;
                            ddlTravelerBeneficialyTitle.ID = "ddlTraveler" + code + "BeneficialyTitle" + j.ToString();
                            if (this.ddlLanguage.SelectedValue == "E")
                            {
                                SetTitleToDropdownList(ddlTravelerBeneficialyTitle);
                            }
                            else
                            {
                                SetThaiTitleToDropdownList(ddlTravelerBeneficialyTitle);
                            }
                            ddlTravelerBeneficialyTitle.SelectedValue = Request.Form["ctl00$MainContent$ddlTraveler" + code + "BeneficialyTitle" + j.ToString()];

                            //-------VVVVVVVVVVVVVVVVVVVVVVVVVVV------------
                            
                            if (j == 1)
                            {
                                tableBeneficialy2_tdBeneficialyTitle.Controls.Add(lblTravelerBeneficialyTitle);
                                tableBeneficialy2_tdBeneficialyTitle.Controls.Add(lblTravelerBeneficialyTitleTh);
                                //br = new HtmlAnchor();
                                //br.InnerHtml = "<br/>";
                                //tableBeneficialy_tdBeneficialyTitle.Controls.Add(br);
                            }
                            tableBeneficialy2_tdBeneficialyTitle.Controls.Add(ddlTravelerBeneficialyTitle);

                            tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyTitle);

                            //---------------------- lblTraveler1BeneficialyName1- ---------------
                            HtmlTableCell tableBeneficialy2_tdBeneficialyName = new HtmlTableCell();
                            tableBeneficialy2_tdBeneficialyName.Align = "left";

                            Label lblTravelerBeneficialyName = new Label();
                            lblTravelerBeneficialyName.ID = "lblTraveler" + code + "BeneficialyName" + j.ToString();
                            lblTravelerBeneficialyName.Font.Bold = true;
                            lblTravelerBeneficialyName.Text = "<font color=red>*</font>&nbsp;" + "Name : <br/>&nbsp;&nbsp;&nbsp;";

                            Label lblTravelerBeneficialyNameTh = new Label();
                            lblTravelerBeneficialyNameTh.ID = "lblTraveler" + code + "BeneficialyName" + j.ToString() + "_th";
                            lblTravelerBeneficialyNameTh.Font.Bold = true;
                            lblTravelerBeneficialyNameTh.Font.Size = FontUnit.Point(8);
                            lblTravelerBeneficialyNameTh.Text = "ชื่อ <br/>";

                            HtmlInputText txtTravelerBeneficialyName = new HtmlInputText();
                            txtTravelerBeneficialyName.MaxLength = 100;
                            txtTravelerBeneficialyName.Style.Add("width", "195px");
                            txtTravelerBeneficialyName.ID = "txtTraveler" + code + "BeneficialyName" + j.ToString();
                            txtTravelerBeneficialyName.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialyName" + j.ToString()];

                            if (j == 1)
                            {
                                tableBeneficialy2_tdBeneficialyName.Controls.Add(lblTravelerBeneficialyName);
                                tableBeneficialy2_tdBeneficialyName.Controls.Add(lblTravelerBeneficialyNameTh);
                                //br = new HtmlAnchor();
                                //br.InnerHtml = "<br/>";
                                //tableBeneficialy_tdBeneficialyName.Controls.Add(br);
                            }
                            tableBeneficialy2_tdBeneficialyName.Controls.Add(txtTravelerBeneficialyName);

                            tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyName);

                            //---------------------- lblTraveler1BeneficialySurname1- ---------------
                            HtmlTableCell tableBeneficialy2_tdBeneficialySurname = new HtmlTableCell();
                            tableBeneficialy2_tdBeneficialySurname.Align = "left";

                            Label lblTravelerBeneficialySurname = new Label();
                            lblTravelerBeneficialySurname.ID = "lblTraveler" + code + "BeneficialySurname" + j.ToString();
                            lblTravelerBeneficialySurname.Font.Bold = true;
                            lblTravelerBeneficialySurname.Text = "<font color=red>*</font>&nbsp;" + "Family name : <br/>&nbsp;&nbsp;&nbsp;";

                            Label lblTravelerBeneficialySurnameTh = new Label();
                            lblTravelerBeneficialySurnameTh.ID = "lblTraveler" + code + "BeneficialySurname" + j.ToString() + "_th";
                            lblTravelerBeneficialySurnameTh.Font.Bold = true;
                            lblTravelerBeneficialySurnameTh.Font.Size = FontUnit.Point(8);
                            lblTravelerBeneficialySurnameTh.Text = "นามสกุล <br/>";

                            HtmlInputText txtTravelerBeneficialySurname = new HtmlInputText();
                            txtTravelerBeneficialySurname.Style.Add("width", "195px");
                            txtTravelerBeneficialySurname.ID = "txtTraveler" + code + "BeneficialySurname" + j.ToString();
                            txtTravelerBeneficialySurname.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialySurname" + j.ToString()];


                            if (j == 1)
                            {
                                tableBeneficialy2_tdBeneficialySurname.Controls.Add(lblTravelerBeneficialySurname);
                                tableBeneficialy2_tdBeneficialySurname.Controls.Add(lblTravelerBeneficialySurnameTh);
                                //br = new HtmlAnchor();
                                //br.InnerHtml = "<br/>";
                                //tableBeneficialy_tdBeneficialySurname.Controls.Add(br);
                            }
                            tableBeneficialy2_tdBeneficialySurname.Controls.Add(txtTravelerBeneficialySurname);

                            tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialySurname);

                            //---------------------- lblTraveler1BeneficialyRelationShip1- ---------------
                            HtmlTableCell tableBeneficialy2_tdBeneficialyRelationShip = new HtmlTableCell();
                            tableBeneficialy2_tdBeneficialyRelationShip.Align = "left";

                            Label lblTravelerBeneficialyRelationShip = new Label();
                            lblTravelerBeneficialyRelationShip.ID = "lblTraveler" + code + "BeneficialyRelationShip" + j.ToString();
                            lblTravelerBeneficialyRelationShip.Font.Bold = true;
                            lblTravelerBeneficialyRelationShip.Text = "RelationShip : <br/>";

                            Label lblTravelerBeneficialyRelationShipTh = new Label();
                            lblTravelerBeneficialyRelationShipTh.ID = "lblTraveler" + code + "BeneficialyRelationShip" + j.ToString() + "_th";
                            lblTravelerBeneficialyRelationShipTh.Font.Bold = true;
                            lblTravelerBeneficialyRelationShipTh.Font.Size = FontUnit.Point(8);
                            lblTravelerBeneficialyRelationShipTh.Text = "ความสัมพันธ์กับผู้เอาประกันภัย<br/>";

                            DropDownList ddlTravelerBeneficialyRelationShip = new DropDownList();
                            ddlTravelerBeneficialyRelationShip.ID = "ddlTraveler" + code + "BeneficialyRelationShip" + j.ToString();
                            ddlTravelerBeneficialyRelationShip.Style.Add("width", "150px");
                            SetRelationToDropdownList(ddlTravelerBeneficialyRelationShip, this.ddlLanguage.SelectedValue.ToString());
                            ddlTravelerBeneficialyRelationShip.SelectedValue = Request.Form["ctl00$MainContent$ddlTraveler" + code + "BeneficialyRelationShip" + j.ToString()];


                            if (j == 1)
                            {
                                tableBeneficialy2_tdBeneficialyRelationShip.Controls.Add(lblTravelerBeneficialyRelationShip);
                                tableBeneficialy2_tdBeneficialyRelationShip.Controls.Add(lblTravelerBeneficialyRelationShipTh);
                                //br = new HtmlAnchor();
                                //br.InnerHtml = "<br/>";
                                //tableBeneficialy_tdBeneficialyRelationShip.Controls.Add(br);
                            }
                            tableBeneficialy2_tdBeneficialyRelationShip.Controls.Add(ddlTravelerBeneficialyRelationShip);

                            tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyRelationShip);

                            #region #//Part of Traveler Beneficiary Ratio
                            HtmlTableCell tableBeneficialy2_tdBeneficialyRatio = new HtmlTableCell();
                            tableBeneficialy2_tdBeneficialyRatio.Align = "left";

                            Label lblTravelerBeneficialyRatio = new Label();
                            lblTravelerBeneficialyRatio.ID = "lblTraveler" + code + "BeneficialyRatio" + j.ToString();
                            lblTravelerBeneficialyRatio.Font.Bold = true;
                            lblTravelerBeneficialyRatio.Text = "<font color=red>*</font>&nbsp;" + "Ratio : <br/>";

                            Label lblTravelerBeneficialyRatioTh = new Label();
                            lblTravelerBeneficialyRatioTh.ID = "lblTraveler" + code + "BeneficialyRatio" + j.ToString() + "_th";
                            lblTravelerBeneficialyRatioTh.Font.Bold = true;
                            lblTravelerBeneficialyRatioTh.Font.Size = FontUnit.Point(8);
                            lblTravelerBeneficialyRatioTh.Text = "สัดส่วน<br/>";

                            HtmlInputText txtTravelerBeneficialyRatio = new HtmlInputText();
                            txtTravelerBeneficialyRatio.ID = "txtTraveler" + code + "BeneficialyRatio" + j.ToString();
                            txtTravelerBeneficialyRatio.Style.Add("width", "70px");
                            txtTravelerBeneficialyRatio.MaxLength = 3;
                            txtTravelerBeneficialyRatio.Attributes.Add("onkeypress", "return numbersonly(event);");
                            txtTravelerBeneficialyRatio.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialyRatio" + j.ToString()];

                            if (j == 1)
                            {
                                tableBeneficialy2_tdBeneficialyRatio.Controls.Add(lblTravelerBeneficialyRatio);
                                tableBeneficialy2_tdBeneficialyRatio.Controls.Add(lblTravelerBeneficialyRatioTh);
                            }

                            tableBeneficialy2_tdBeneficialyRatio.Controls.Add(txtTravelerBeneficialyRatio);

                            tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyRatio);

                            #endregion

                            //---------------------- lblTraveler1BeneficialyTel1- ---------------
                            HtmlTableCell tableBeneficialy2_tdBeneficialyTel = new HtmlTableCell();
                            tableBeneficialy2_tdBeneficialyTel.Align = "left";

                            Label lblTravelerBeneficialyTel = new Label();
                            lblTravelerBeneficialyTel.ID = "lblTraveler" + code + "BeneficialyTel" + j.ToString();
                            lblTravelerBeneficialyTel.Font.Bold = true;
                            lblTravelerBeneficialyTel.Text = "Tel : <br/>";

                            Label lblTravelerBeneficialyTelTh = new Label();
                            lblTravelerBeneficialyTelTh.ID = "lblTraveler" + code + "BeneficialyTel" + j.ToString() + "_th";
                            lblTravelerBeneficialyTelTh.Font.Bold = true;
                            lblTravelerBeneficialyTelTh.Font.Size = FontUnit.Point(8);
                            lblTravelerBeneficialyTelTh.Text = "เบอร์โทรศัพท์<br/>";

                            HtmlInputText txtTravelerBeneficialyTel = new HtmlInputText();
                            txtTravelerBeneficialyTel.ID = "txtTraveler" + code + "BeneficialyTel" + j.ToString();
                            txtTravelerBeneficialyTel.Style.Add("width", "120px");
                            txtTravelerBeneficialyTel.MaxLength = 100;
                            txtTravelerBeneficialyTel.Value = Request.Form["ctl00$MainContent$txtTraveler" + code + "BeneficialyTel" + j.ToString()];


                            if (j == 1)
                            {
                                tableBeneficialy2_tdBeneficialyTel.Controls.Add(lblTravelerBeneficialyTel);
                                tableBeneficialy2_tdBeneficialyTel.Controls.Add(lblTravelerBeneficialyTelTh);
                                //br = new HtmlAnchor();
                                //br.InnerHtml = "<br/>";
                                //tableBeneficialy_tdBeneficialyTel.Controls.Add(br);
                            }

                            tableBeneficialy2_tdBeneficialyTel.Controls.Add(txtTravelerBeneficialyTel);

                            tableBeneficialy2_tr2.Controls.Add(tableBeneficialy2_tdBeneficialyTel);
                        }
                    }

                    #endregion

                }


            }
        }
    }
    #endregion

    private void BindJobNoFromQry2Text()
    {
        string m_JobNo = Request.QueryString["JobNo"];
        string m_mode = Request.QueryString["mode"];

        if (!string.IsNullOrEmpty(m_JobNo))
        {
            //Edit Mode
            if (!string.IsNullOrEmpty(m_mode))
            {
                if (string.Compare(m_mode.Trim(), "edit") == 0)
                {
                    this.lblJobnoValue.Text = m_JobNo.Trim();
                }
            }
            //End Edit Mode            
        }
    }
    protected void ddlCountryOfDestination_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (this.ddlCountryOfDestination.SelectedValue.Trim() == "99")
        {
            this.txtCountryOfDestinationOther.Visible = true;
        }
        else
        {
            this.txtCountryOfDestinationOther.Visible = false;
        }
    }
    protected void ClearCssClassFocusError()
    {
        if (this.txtEffectiveDateFrom.Text == string.Empty)
        {
            this.txtEffectiveDateFrom.CssClass = "inputFocusError";
        }
        else
        {
            this.txtEffectiveDateFrom.CssClass = "";
        }

        if (this.txtEffectiveDateTo.Text == string.Empty)
        {
            this.txtEffectiveDateTo.CssClass = "inputFocusError";
        }
        else
        {
            this.txtEffectiveDateTo.CssClass = "";
        }
        
        if (this.txtName.Value == string.Empty)
        {
            this.txtName.Attributes["class"] = "inputFocusError";
        }
        else
        {
            this.txtName.Attributes["class"] = "";
        }

        if (this.txtSurname.Value == string.Empty && this.rdoTaxInvoiceType.SelectedIndex == 0)
        {
            this.txtSurname.Attributes["class"] = "inputFocusError";
        }
        else
        {
            this.txtSurname.Attributes["class"] = "";
        }

        if (this.txtBirthday.Value == string.Empty)
        {
            this.txtBirthday.Attributes["class"] = "inputFocusError";
        }
        else
        {
            this.txtBirthday.Attributes["class"] = "";
        }

        if (this.txtIDCard.Text == string.Empty)
        {
            this.txtIDCard.CssClass = "inputFocusError";
        }
        else
        {
            this.txtIDCard.CssClass = "";
        }

        if (this.txtTel.Value == string.Empty)
        {
            this.txtTel.Attributes["class"] = "inputFocusError";
        }
        else
        {
            this.txtTel.Attributes["class"] = "";
        }

        if (this.txtAddress1.Value == string.Empty)
        {
            this.txtAddress1.Attributes["class"] = "inputFocusError";
        }
        else
        {
            this.txtAddress1.Attributes["class"] = "";
        }

        if (this.txtZipCode.Value == string.Empty)
        {
            this.txtZipCode.Attributes["class"] = "inputFocusError";
        }
        else
        {
            this.txtZipCode.Attributes["class"] = "";
        }


        if (this.txtTraveler1Name.Value == string.Empty)
        {
            this.txtTraveler1Name.Attributes["class"] = "inputFocusError";
        }
        else
        {
            this.txtTraveler1Name.Attributes["class"] = "";
        }

        if (this.txtTraveler1Surname.Value == string.Empty)
        {
            this.txtTraveler1Surname.Attributes["class"] = "inputFocusError";
        }
        else
        {
            this.txtTraveler1Surname.Attributes["class"] = "";
        }

        if (this.txtTraveler1Birthday.Value == string.Empty)
        {
            this.txtTraveler1Birthday.Attributes["class"] = "inputFocusError";
        }
        else
        {
            this.txtTraveler1Birthday.Attributes["class"] = "";
        }

        if (this.txtTraveler1PassportNo.Value == string.Empty)
        {
            this.txtTraveler1PassportNo.Attributes["class"] = "inputFocusError";
        }
        else
        {
            this.txtTraveler1PassportNo.Attributes["class"] = "";
        }

        if (this.txtTraveler1Tel.Value == string.Empty)
        {
            this.txtTraveler1Tel.Attributes["class"] = "inputFocusError";
        }
        else
        {
            this.txtTraveler1Tel.Attributes["class"] = "";
        }

        //CHECK BENEFICIARY
        if (this.chkTraveler1BeneficialyHeir.Checked == false)
        {
            if (string.IsNullOrEmpty(txtTraveler1BeneficialyName1.Value.Trim()) || string.IsNullOrEmpty(txtTraveler1BeneficialySurname1.Value.Trim()))
            {
                this.txtTraveler1BeneficialyName1.Attributes["class"] = "inputFocusError";
                this.txtTraveler1BeneficialySurname1.Attributes["class"] = "inputFocusError";
            }
            else
            {
                this.txtTraveler1BeneficialyName1.Attributes["class"] = "";
                this.txtTraveler1BeneficialySurname1.Attributes["class"] = "";
            }
            int travelerxRatio = 0;

                for (int j = 1; j < 4; j++)
                {

                    string msub_BeneficiaryName = "";
                    string msub_BeneficiarySurName = "";
                    string msub_BeneficiaryRatio = "";

                    string idsub_BeneficiaryName = "ctl00$MainContent$txtTraveler1BeneficialyName" + j.ToString();
                    msub_BeneficiaryName = Request.Form[idsub_BeneficiaryName];

                    string idsub_BeneficiarySurName = "ctl00$MainContent$txtTraveler1BeneficialySurname" + j.ToString();
                    msub_BeneficiarySurName = Request.Form[idsub_BeneficiarySurName];

                    string idsub_BeneficiaryRatio = "ctl00$MainContent$txtTraveler1BeneficialyRatio" + j.ToString();
                    msub_BeneficiaryRatio = Request.Form[idsub_BeneficiaryRatio];

                    if (this.chkTraveler1BeneficialyHeir.Checked == true)
                    {

                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(msub_BeneficiaryName) && !string.IsNullOrEmpty(msub_BeneficiarySurName))
                        {
                            travelerxRatio += msub_BeneficiaryRatio.Equals(string.Empty) ? 0 : Convert.ToInt32(msub_BeneficiaryRatio.Trim());
                        }
                    }
                }

                if (travelerxRatio != 100 && this.chkTraveler1BeneficialyHeir.Checked == false)
                {
                    //this.lblErrorMessage.Text = "Sum of Beneficiary Ratio on Traveler " + ch + " Must be 100!!! ";
                    //this.lblInformMessage.Text = "";

                    this.txtTraveler1BeneficialyRatio1.Attributes["class"] = "inputFocusError";
                    return;
                }
                else
                {
                    this.txtTraveler1BeneficialyRatio1.Attributes["class"] = "";
                }
        }

        if (this.txtTraveler2Name.Value == string.Empty)
        {
            this.txtTraveler2Name.Attributes["class"] = "inputFocusError";
        }
        else
        {
            this.txtTraveler2Name.Attributes["class"] = "";
        }

        if (this.txtTraveler2Surname.Value == string.Empty)
        {
            this.txtTraveler2Surname.Attributes["class"] = "inputFocusError";
        }
        else
        {
            this.txtTraveler2Surname.Attributes["class"] = "";
        }

        if (this.txtTraveler2Birthday.Value == string.Empty)
        {
            this.txtTraveler2Birthday.Attributes["class"] = "inputFocusError";
        }
        else
        {
            this.txtTraveler2Birthday.Attributes["class"] = "";
        }

        if (this.txtTraveler2PassportNo.Value == string.Empty)
        {
            this.txtTraveler2PassportNo.Attributes["class"] = "inputFocusError";
        }
        else
        {
            this.txtTraveler2PassportNo.Attributes["class"] = "";
        }

        if (this.txtTraveler2Tel.Value == string.Empty)
        {
            this.txtTraveler2Tel.Attributes["class"] = "inputFocusError";
        }
        else
        {
            this.txtTraveler2Tel.Attributes["class"] = "";
        }
        //CHECK BENEFICIARY
        if (this.chkTraveler2BeneficialyHeir.Checked == false)
        {
            if (string.IsNullOrEmpty(txtTraveler2BeneficialyName1.Value.Trim()) || string.IsNullOrEmpty(txtTraveler2BeneficialySurname1.Value.Trim()))
            {
                this.txtTraveler2BeneficialyName1.Attributes["class"] = "inputFocusError";
                this.txtTraveler2BeneficialySurname1.Attributes["class"] = "inputFocusError";
            }
            else
            {
                this.txtTraveler2BeneficialyName1.Attributes["class"] = "";
                this.txtTraveler2BeneficialySurname1.Attributes["class"] = "";
            }
            int travelerxRatio = 0;

            for (int j = 1; j < 4; j++)
            {

                string msub_BeneficiaryName = "";
                string msub_BeneficiarySurName = "";
                string msub_BeneficiaryRatio = "";

                string idsub_BeneficiaryName = "ctl00$MainContent$txtTraveler2BeneficialyName" + j.ToString();
                msub_BeneficiaryName = Request.Form[idsub_BeneficiaryName];

                string idsub_BeneficiarySurName = "ctl00$MainContent$txtTraveler2BeneficialySurname" + j.ToString();
                msub_BeneficiarySurName = Request.Form[idsub_BeneficiarySurName];

                string idsub_BeneficiaryRatio = "ctl00$MainContent$txtTraveler2BeneficialyRatio" + j.ToString();
                msub_BeneficiaryRatio = Request.Form[idsub_BeneficiaryRatio];

                if (this.chkTraveler2BeneficialyHeir.Checked == true)
                {

                }
                else
                {
                    if (!string.IsNullOrEmpty(msub_BeneficiaryName) && !string.IsNullOrEmpty(msub_BeneficiarySurName))
                    {
                        travelerxRatio += msub_BeneficiaryRatio.Equals(string.Empty) ? 0 : Convert.ToInt32(msub_BeneficiaryRatio.Trim());
                    }
                }
            }

            if (travelerxRatio != 100 && this.chkTraveler2BeneficialyHeir.Checked == false)
            {
                //this.lblErrorMessage.Text = "Sum of Beneficiary Ratio on Traveler " + ch + " Must be 100!!! ";
                //this.lblInformMessage.Text = "";

                this.txtTraveler2BeneficialyRatio1.Attributes["class"] = "inputFocusError";
                return;
            }
            else
            {
                this.txtTraveler2BeneficialyRatio1.Attributes["class"] = "";
            }
        }


        #region "#4-DYNAMIC TRANSTRAVELER"
        //#4-INSERT/UPDATE TRANSTRAVELER
        //VARIABLE            
        int numberofchid = int.Parse(this.txtNumberOfChilden.Text.Trim());

        if (numberofchid == 0)
            numberofchid = -1;

        for (int c = 1; c <= (numberofchid + 2); c++)
        {            
            int m_TravelerId = c;
                   
            string id_clientname = "ctl00$MainContent$txtTraveler" + c + "Name";            
            HtmlInputText txtTraveler = (HtmlInputText)Page.FindControl(id_clientname);

            if (string.IsNullOrEmpty(Request.Form["ctl00$MainContent$txtTraveler" + c + "Name"]))
            {
                txtTraveler.Attributes["class"] = "inputFocusError";
            }
            else
            {
                txtTraveler.Attributes["class"] = "";
            }
            
            string id_clientsurname = "ctl00$MainContent$txtTraveler" + c + "SurName";
            HtmlInputText txtTravelerSurName = (HtmlInputText)Page.FindControl(id_clientsurname);
            if (string.IsNullOrEmpty(Request.Form[id_clientsurname]))
            {
                txtTravelerSurName.Attributes["class"] = "inputFocusError";
            }
            else
            {
                txtTravelerSurName.Attributes["class"] = "";
            }
            
            string id_birthday = "ctl00$MainContent$txtTraveler" + c + "Birthday";
            HtmlInputText txtTravelerBirthday = (HtmlInputText)Page.FindControl(id_birthday);
            if (string.IsNullOrEmpty(Request.Form[id_birthday]))
            {
                txtTravelerBirthday.Attributes["class"] = "inputFocusError";
            }
            else
            {
                txtTravelerBirthday.Attributes["class"] = "";
            }
            
            string id_passportid = "ctl00$MainContent$txtTraveler" + c + "PassportNo";
            HtmlInputText txtTravelerPassportNo = (HtmlInputText)Page.FindControl(id_passportid);
            if (string.IsNullOrEmpty(Request.Form[id_passportid]))
            {
                txtTravelerPassportNo.Attributes["class"] = "inputFocusError";
            }
            else
            {
                txtTravelerPassportNo.Attributes["class"] = "";
            }
                        
            string id_tel = "ctl00$MainContent$txtTraveler" + c + "Tel";
            HtmlInputText txtTravelerTel = (HtmlInputText)Page.FindControl(id_tel);
            if (string.IsNullOrEmpty(Request.Form[id_tel]))
            {
                txtTravelerTel.Attributes["class"] = "inputFocusError";
            }
            else
            {
                txtTravelerTel.Attributes["class"] = "";
            }            
        }
        #endregion        
    }

    //protected void rdoLanguage_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    if (this.rdoLanguage.SelectedValue == "E")
    //    {
    //        //Bind dropdown list "ddlProvine"
    //        this.SetEngProvinceToDropdownList(ddlProvine);
 

    //        //Bind dropdown list "ddlAmphure"
    //        this.SetEngAmphurToDropdownList(ddlAmphure, "01");
  

    //        //Bind dropdown list "ddlTumbon"
    //        this.SetEngTumbolToDropdownList(ddlTumbon, "01", "0101");
 

    //    }
    //    else
    //    {
    //        //Bind dropdown list "ddlProvine"
    //        this.SetThaiProvinceToDropdownList(ddlProvine);
 

    //        //Bind dropdown list "ddlAmphure"
    //        this.SetThaiAmphurToDropdownList(ddlAmphure, "01");
 

    //        //Bind dropdown list "ddlTumbon"
    //        this.SetThaiTumbolToDropdownList(ddlTumbon, "01", "0101");
  
    //    }
    //}

    void ddlLanguage_SelectedIndexChanged(object sender, EventArgs e)
    {
        SetLanguageToAllControl();
    }
    private void SetLanguageToAllControl()
    {
        if (this.ddlLanguage.SelectedValue == "E")
        {
            //Bind dropdown list "ddlProvine"
            this.SetEngProvinceToDropdownList(ddlProvine);


            //Bind dropdown list "ddlAmphure"
            this.SetEngAmphurToDropdownList(ddlAmphure, "01");


            //Bind dropdown list "ddlTumbon"
            this.SetEngTumbolToDropdownList(ddlTumbon, "01", "0101");

            this.SetTitleToDropdownList(ddlPolicyHolderTitle);

            ////Bind dropdown list Title "Traveler 2"
            this.SetTitleToDropdownList(ddlTraveler1Title);
            this.SetTitleToDropdownList(ddlTraveler1BeneficialyTitle1);
            this.SetTitleToDropdownList(ddlTraveler1BeneficialyTitle2);
            this.SetTitleToDropdownList(ddlTraveler1BeneficialyTitle3);
            ////Bind dropdown list Relation "Traveler 1"
            this.SetRelationToDropdownList(ddlTraveler1BeneficialyRelationShip1, this.ddlLanguage.SelectedValue.ToString());
            this.SetRelationToDropdownList(ddlTraveler1BeneficialyRelationShip2, this.ddlLanguage.SelectedValue.ToString());
            this.SetRelationToDropdownList(ddlTraveler1BeneficialyRelationShip3, this.ddlLanguage.SelectedValue.ToString());

            ////Bind dropdown list Title "Traveler 2"
            this.SetTitleToDropdownList(ddlTraveler2Title);
            this.SetTitleToDropdownList(ddlTraveler2BeneficialyTitle1);
            this.SetTitleToDropdownList(ddlTraveler2BeneficialyTitle2);
            this.SetTitleToDropdownList(ddlTraveler2BeneficialyTitle3);
            ////Bind dropdown list Relation "Traveler 2"
            this.SetRelationToDropdownList(ddlTraveler2BeneficialyRelationShip1, this.ddlLanguage.SelectedValue.ToString());
            this.SetRelationToDropdownList(ddlTraveler2BeneficialyRelationShip2, this.ddlLanguage.SelectedValue.ToString());
            this.SetRelationToDropdownList(ddlTraveler2BeneficialyRelationShip3, this.ddlLanguage.SelectedValue.ToString());

        }
        else if(this.ddlLanguage.SelectedValue == "T")
        {
            //Bind dropdown list "ddlProvine"
            this.SetThaiProvinceToDropdownList(ddlProvine);


            //Bind dropdown list "ddlAmphure"
            this.SetThaiAmphurToDropdownList(ddlAmphure, "01");


            //Bind dropdown list "ddlTumbon"
            this.SetThaiTumbolToDropdownList(ddlTumbon, "01", "0101");

            this.SetThaiTitleToDropdownList(ddlPolicyHolderTitle);
            ////Bind dropdown list Title "Traveler 2"
            this.SetThaiTitleToDropdownList(ddlTraveler1Title);
            this.SetThaiTitleToDropdownList(ddlTraveler1BeneficialyTitle1);
            this.SetThaiTitleToDropdownList(ddlTraveler1BeneficialyTitle2);
            this.SetThaiTitleToDropdownList(ddlTraveler1BeneficialyTitle3);
            ////Bind dropdown list Relation "Traveler 1"
            this.SetRelationToDropdownList(ddlTraveler1BeneficialyRelationShip1, this.ddlLanguage.SelectedValue.ToString());
            this.SetRelationToDropdownList(ddlTraveler1BeneficialyRelationShip2, this.ddlLanguage.SelectedValue.ToString());
            this.SetRelationToDropdownList(ddlTraveler1BeneficialyRelationShip3, this.ddlLanguage.SelectedValue.ToString());

            ////Bind dropdown list Title "Traveler 2"
            this.SetThaiTitleToDropdownList(ddlTraveler2Title);
            this.SetThaiTitleToDropdownList(ddlTraveler2BeneficialyTitle1);
            this.SetThaiTitleToDropdownList(ddlTraveler2BeneficialyTitle2);
            this.SetThaiTitleToDropdownList(ddlTraveler2BeneficialyTitle3);
            ////Bind dropdown list Relation "Traveler 2"
            this.SetRelationToDropdownList(ddlTraveler2BeneficialyRelationShip1, this.ddlLanguage.SelectedValue.ToString());
            this.SetRelationToDropdownList(ddlTraveler2BeneficialyRelationShip2, this.ddlLanguage.SelectedValue.ToString());
            this.SetRelationToDropdownList(ddlTraveler2BeneficialyRelationShip3, this.ddlLanguage.SelectedValue.ToString());

        }
    }
    private string findDropdownValueByText(DropDownList sender, string selected)
    {
        for (int i = 0; i < sender.Items.Count; i++)
        {
            if (sender.Items[i].Text == selected)
            {
                sender.Items[i].Selected = true;
                return sender.Items[i].Value;
            }
        }
        return "";
    }
 
}