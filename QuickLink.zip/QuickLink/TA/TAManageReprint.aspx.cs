﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

//ADDITIONAL USING REFERENCE
using TA.BLL;
using TA.BusinessObjects;
using TA.DAL;
using System.Data;
using System.Data.Common;
using System.Globalization;
using System.IO;
using WSQuickLinkTA;
using WSQuickLinkTAReport;

public partial class TA_TAManageReprint : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.hideBtnCancel.ServerClick += new EventHandler(hideBtnCancel_ServerClick);


       

    }


    protected void hideBtnCancel_ServerClick(object sender, EventArgs e)
    {
        try
        {
            string m_policyno = this.hidePolicyno.Value.Trim().Equals("&nbsp;") ? "" : this.hidePolicyno.Value.Trim();
            string m_endtno = this.hideEndtno.Value.Trim().Equals("&nbsp;") ? "" : this.hideEndtno.Value.Trim();
            string m_jobno = this.hideJobno.Value.Trim().Equals("&nbsp;") ? "" : this.hideJobno.Value.Trim();
            string m_Agent = this.hideAgent.Value.Trim().Equals("&nbsp;") ? "" : this.hideAgent.Value.Trim();
            string m_Group = this.hideGroup.Value.Trim().Equals("&nbsp;") ? "" : this.hideGroup.Value.Trim();
            string m_UserWeb =  this.hideUser.Value.Trim().Equals("&nbsp;") ? "" : this.hideUser.Value.Trim();
                        //string m_UserWeb = Utilities.GetUsername();

            if (m_endtno == "0")
            {

            #region Call Method SetTransTaxInvoince.
            TATransPolicyBLL SetTransTaxInvoince = new TATransPolicyBLL();
            SetTransTaxInvoince.SetTATransTaxInvoince(m_policyno, m_jobno, m_UserWeb, "0");



            #endregion
            
            #region Call Web Services getTADocument
            WSQuickLinkTAReport.Box_Document[] BoxDocument = new Box_Document[1];

            WSQuickLinkTAReport.Box_Message[] BoxMessage;

            WSQuickLinkTAReport.TADocumentService getTADocument = new WSQuickLinkTAReport.TADocumentService();

            Box_Document BoxDocuemtDetail = new Box_Document();
            BoxDocuemtDetail.PolicyNo = m_policyno;
            BoxDocuemtDetail.Document = "RTHSBTDR";
            BoxDocuemtDetail.Flag = true;

            BoxDocument[0] = BoxDocuemtDetail;
            string tempUserHostName = "";
            string tempUserHostPassword = "";
            if (Session["UserHostName"].ToString().Substring(0, 2) == "QL")
            {
                tempUserHostName = "QLAPP"; tempUserHostPassword = Session["UserHostPassword"].ToString().Trim();
            }
            else { tempUserHostName = "QAAPP"; tempUserHostPassword = Session["UserHostPassword"].ToString().Trim(); }
            

            BoxMessage = getTADocument.getTADocument(BoxDocument,tempUserHostName,tempUserHostPassword);

            if (BoxMessage.Length < 1)
            {
                throw new System.ArgumentException("Issued Success,Policy No : " + m_policyno + ",But have some problem in Tax Invoice Process.");

            }
            else
            {
                if (BoxMessage[0].Success != "true")
                {
                    //throw new System.ArgumentException(BoxMessage[0].Error);
                    throw new System.ArgumentException("Issued Success,Policy No : " + m_policyno + ",But have some problem in Tax Invoice Process.");
                }
            }
            #endregion

            #region Call Method SetTranPrint.
            TATransPolicyBLL SetTranPrint = new TATransPolicyBLL();
            SetTransTaxInvoince.SetTATransPrint(m_policyno, m_jobno, "", m_Agent, m_Group, m_UserWeb);
            #endregion

            } else {
            
            #region Call Method SetTransTaxInvoince.
            TATransPolicyBLL SetTransTaxInvoince = new TATransPolicyBLL();
            SetTransTaxInvoince.SetTATransTaxInvoince(m_policyno, m_jobno, m_UserWeb, "1");
            #endregion

            #region Call Web Services getTADocument CREADIT
            WSQuickLinkTAReport.Box_Document[] BoxDocument = new Box_Document[1];

            WSQuickLinkTAReport.Box_Message[] BoxMessage;

            WSQuickLinkTAReport.TADocumentService getTADocument = new WSQuickLinkTAReport.TADocumentService();

            Box_Document BoxDocuemtDetail = new Box_Document();
            BoxDocuemtDetail.PolicyNo = m_policyno;
            BoxDocuemtDetail.Document = "RTHSBTCR";
            BoxDocuemtDetail.Flag = true;

            BoxDocument[0] = BoxDocuemtDetail;
            string tempUserHostName = "";
            string tempUserHostPassword = "";
            if (Session["UserHostName"].ToString().Substring(0, 2) == "QL")
            {
                tempUserHostName = "QLAPP"; tempUserHostPassword = Session["UserHostPassword"].ToString().Trim();
            }
            else { tempUserHostName = "QAAPP"; tempUserHostPassword = Session["UserHostPassword"].ToString().Trim(); }


            BoxMessage = getTADocument.getTADocument(BoxDocument, tempUserHostName, tempUserHostPassword);

            //BoxMessage = getTADocument.getTADocument(BoxDocument, "QAAPP", "PASSWORD");

            if (BoxMessage[0].Success != "true")
            {
                throw new System.ArgumentException(BoxMessage[0].Error);
            }
            #endregion

            #region Call Web Services getTADocument ENDT
            WSQuickLinkTAReport.Box_Document[] BoxDocumentENDT = new Box_Document[1];

            WSQuickLinkTAReport.Box_Message[] BoxMessageENDT;

            WSQuickLinkTAReport.TADocumentService getTADocumentENDT = new WSQuickLinkTAReport.TADocumentService();

            Box_Document BoxDocuemtDetailENDT = new Box_Document();
            BoxDocuemtDetailENDT.PolicyNo = m_policyno;
            BoxDocuemtDetailENDT.Document = "TMIS007";
            BoxDocuemtDetailENDT.Flag = true;

            BoxDocumentENDT[0] = BoxDocuemtDetailENDT;
             tempUserHostName = "";
             tempUserHostPassword = "";
            if (Session["UserHostName"].ToString().Substring(0, 2) == "QL")
            {
                tempUserHostName = "QLAPP"; tempUserHostPassword = Session["UserHostPassword"].ToString().Trim();
            }
            else { tempUserHostName = "QAAPP"; tempUserHostPassword = Session["UserHostPassword"].ToString().Trim(); }


            BoxMessageENDT = getTADocument.getTADocument(BoxDocumentENDT, tempUserHostName, tempUserHostPassword);
            //BoxMessageENDT = getTADocumentENDT.getTADocument(BoxDocumentENDT, "QAAPP", "PASSWORD");

            if (BoxMessageENDT[0].Success != "true")
            {
                throw new System.ArgumentException(BoxMessageENDT[0].Error);
            }
            #endregion

            #region Call Method SetTranPrint.
            TATransPolicyBLL SetTranPrint = new TATransPolicyBLL();
            SetTransTaxInvoince.SetTATransPrint(m_policyno, m_jobno, "1", m_Agent, m_Group, m_UserWeb);
            #endregion
            
            }


        }
        catch { }
    }

           protected void gvEditQuotation_RowDataBound(object sender, GridViewRowEventArgs e)
        {
          
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    string m_jobno = e.Row.Cells[1].Text.Trim(); //jobno
                    string m_policyno = e.Row.Cells[2].Text.Trim(); //policyno
                    string m_endtno = e.Row.Cells[3].Text.Trim(); //endtno
                    string m_Agent = e.Row.Cells[8].Text.Trim(); //CreateUser
                    string m_Group = e.Row.Cells[9].Text.Trim(); //CreateUser
                    string m_User = e.Row.Cells[10].Text.Trim(); //CreateUser
                    
                    HtmlInputButton btnSelect = (HtmlInputButton)e.Row.FindControl("btnSelect");
                    btnSelect.Attributes.Add("onclick", "gotoCancelPopup('" + m_jobno + "','" + m_policyno + "','" + m_endtno  + "','" + m_Agent + "','" + m_Group + "','" + m_User + "')");
                    //int r = (int)e.Row.RowIndex;
                }        
              
   
            
        }
        

}