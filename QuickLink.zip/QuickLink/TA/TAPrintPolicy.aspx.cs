﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;  
using TA.BLL;

public partial class TA_TAPrintPolicy : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            lblMassage.Text = "";
            DefaultPageRegisterClientScript();
            this.btnSearchPolicy.ServerClick += new EventHandler(btnSearchPolicy_ServerClick);
            this.gdvReprint.PageIndexChanging +=new GridViewPageEventHandler(gdvReprint_PageIndexChanging);

            AutoGotoListPrint();
        }
        catch (Exception err)
        {
            Utilities.LogError(err);
            this.lblErrorMessage.Text = err.Message;
            this.lblInformMessage.Text = "";
        }
    }
    protected void gdvReprint_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdvReprint.PageIndex = e.NewPageIndex;
        string GroupBrokerID = Utilities.GetGroupBrokerID();
        this.GetTranPolicy(this.txtPolicyFrom.Text, this.txtPolicyTo.Text, this.txtIssuedDateFrom.Text, this.txtIssuedDateTo.Text, this.rblSearchType.SelectedValue, GroupBrokerID);
    }
    protected void DefaultPageRegisterClientScript()
    {
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptScrolling", "MenuScroll();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptTxtFocus", "setFocusTextbox();", true);
        //ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDrawCorner", "DrawDivCorner();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDisplayMsg", "DisplayWarning();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptMenu", "<script type='text/javascript' language='javascript'>$(document).ready(function () { $('.TRAVEL').find('img').attr('src', '../Images/Index/TA1.png');$('.TRAVEL').find('a').css('color', '#922d3d');$('.TRAVEL').hover(function () {$(this).find('img').attr('src', '../Images/Index/TA1.png'); },function () {$(this).find('img').attr('src', '../Images/Index/TA1.png');}); addSubMenu('hdnTa', '.subNavigate', 'Print Policy', '');$('[id$=txtIssuedDateFrom]').datepicker({ dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true  });$('[id$=txtIssuedDateTo]').datepicker({ dateFormat: 'dd/mm/yy',changeMonth: true,changeYear: true  }); Accordion('.wizard', 'hdnCriteriaStep');}); </script>", false);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptFunction", "<script type='text/javascript' language='javscript'>function RedirectToPage(PolicyNo, PolicyType, PlanId, endtno,jobno,insured_name) {if (endtno == '') {endtno = '0';}$('[name=printframe]').attr('src','Print/ListPrint.aspx?policyno=' + PolicyNo + '&policytype=' + PolicyType + '&planid=' + PlanId + '&endtno=' + endtno + '&jobno=' + jobno + '&insured_name=' + insured_name);}</script>", false);
      
    }
    protected void btnSearchPolicy_ServerClick(object sender, EventArgs e)
    {

        if (this.txtIssuedDateFrom.Text.Length >= 1 && this.txtIssuedDateFrom.Text.Length <= 8)
        {
            this.lblMassage.Text = "Format วันที่ ของ Issued Date ไม่ถูกต้อง ที่ถูกต้องเป็น dd/mm/yyyy";
            this.txtIssuedDateFrom.Text = "";
            this.txtIssuedDateTo.Text = "";
        }
        else { this.lblMassage.Text = ""; }

        string GroupBrokerID = Utilities.GetGroupBrokerID();
        this.GetTranPolicy(this.txtPolicyFrom.Text, this.txtPolicyTo.Text, GetFormateDateYMD(this.txtIssuedDateFrom.Text), GetFormateDateYMD(this.txtIssuedDateTo.Text),this.rblSearchType.SelectedValue, GroupBrokerID);
        DefaultPageRegisterClientScript();
    }
    private void GetTranPolicy(string PolicyFrom,string PolicyTo,string IssuredDateFrom,string IssuedDateTo,string EndtNo, string GroupBrokerID)
    {
        TATransPolicyBLL getListPolicy = new TATransPolicyBLL();

        DataTable DTable = new DataTable();
        DTable = getListPolicy.GetTAListPrintPolicy(PolicyFrom, PolicyTo, IssuredDateFrom, IssuedDateTo, EndtNo, GroupBrokerID);

        if (DTable.Rows.Count > 0)
        {
            this.lblTotalRecord.Text = "แสดงรายการข้อมูล [จำนวนข้อมูลทั้งหมด " + DTable.Rows.Count + " รายการ]";

            gdvReprint.DataSource = DTable;
            gdvReprint.DataBind();
        }
        else
        {
            this.lblTotalRecord.Text = "แสดงรายการข้อมูล [จำนวนข้อมูลทั้งหมด " + 0 + " รายการ]";
            gdvReprint.DataSource = null;
            gdvReprint.DataBind();
        }

        this.lblErrorMessage.Text = "";
        this.lblInformMessage.Text = "";
    }
    private void AutoGotoListPrint()
    {
        try
        {
            if ( Request.QueryString["policyno"].ToString().Trim() != "")
            {
            string PolicyNo = Request.QueryString["policyno"].ToString().Trim();
            string EndtNo = Request.QueryString["endtno"].ToString().Trim();

            this.txtPolicyFrom.Text = PolicyNo;
            this.rblSearchType.SelectedValue = EndtNo;

            string GroupBrokerID = Utilities.GetGroupBrokerID();
            this.GetTranPolicy(PolicyNo, "", "", "", EndtNo, GroupBrokerID);
            DefaultPageRegisterClientScript();
            }
        }
        catch (Exception err)
        {
            //Utilities.LogError(err);
        }

    }
    private string GetFormateDateYMD(string date)
    {
        if (string.IsNullOrEmpty(date))
        {
            return "";
        }
        else
        {

            string[] DatePart = date.Split('/');
            return DatePart[2] + '-' + DatePart[1] + '-' + DatePart[0];
        }

    }
}