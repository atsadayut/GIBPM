﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using TA.BLL;

public partial class TA_TAManagePlanCoverage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.gdvPlanCoverage.PageIndexChanging += new GridViewPageEventHandler(gdvPlanCoverage_PageIndexChanging);
        this.gdvPlanCoverage.RowUpdating += new GridViewUpdateEventHandler(gdvPlanCoverage_RowUpdating);
        this.gdvPlanCoverage.RowEditing += new GridViewEditEventHandler(gdvPlanCoverage_RowEditing);
        this.gdvPlanCoverage.RowCancelingEdit += new GridViewCancelEditEventHandler(gdvPlanCoverage_RowCancelingEdit);
        //this.gdvPlanCoverage.RowDataBound += new GridViewRowEventHandler(gdvPlanCoverage_RowDataBound);

        if (!Page.IsPostBack)
        {
            getPlanCoverage();
        }
    }
    void gdvPlanCoverage_RowEditing(object sender, GridViewEditEventArgs e)
    {

        gdvPlanCoverage.EditIndex = e.NewEditIndex;
        BindDataToGridView();
    }
    void gdvPlanCoverage_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gdvPlanCoverage.EditIndex = -1;
        BindDataToGridView();
    }
    void gdvPlanCoverage_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {

        HiddenField hdnID = (HiddenField)gdvPlanCoverage.Rows[e.RowIndex].FindControl("hdnID");
        TextBox txtCoveragePlan1 = (TextBox)gdvPlanCoverage.Rows[e.RowIndex].FindControl("txtCoveragePlan1");
        TextBox txtCoveragePlan2 = (TextBox)gdvPlanCoverage.Rows[e.RowIndex].FindControl("txtCoveragePlan2");
        TextBox txtCoveragePlan3 = (TextBox)gdvPlanCoverage.Rows[e.RowIndex].FindControl("txtCoveragePlan3");
        TextBox txtCoveragePlan4 = (TextBox)gdvPlanCoverage.Rows[e.RowIndex].FindControl("txtCoveragePlan4");
        TextBox txtCoveragePlan5 = (TextBox)gdvPlanCoverage.Rows[e.RowIndex].FindControl("txtCoveragePlan5");
        string m_UserWeb = Utilities.GetUsername().Trim();

        TAPlanCoverageBLL SetTATransCoverage = new TAPlanCoverageBLL();
        SetTATransCoverage.SetTAPlanCoverage(Convert.ToInt16(hdnID.Value), txtCoveragePlan1.Text, txtCoveragePlan2.Text, txtCoveragePlan3.Text, txtCoveragePlan4.Text, txtCoveragePlan5.Text,m_UserWeb);

        gdvPlanCoverage.EditIndex = -1;

        getPlanCoverage();

        this.lblInformMessage.Text = "แก้ไขข้อมูลเรียบร้อยแล้ว";
        this.lblErrorMessage.Text = "";
    }

    private void getPlanCoverage()
    {
        TAPlanCoverageBLL GetDtAllTAPlanCoverages = new TAPlanCoverageBLL();
        Session["getPlanCoverage"] = GetDtAllTAPlanCoverages.GetDtAllTAPlanCoverages();
        BindDataToGridView();

    }
    protected void BindDataToGridView()
    {

        DataTable lst = (DataTable)Session["getPlanCoverage"];
        gdvPlanCoverage.DataSource = lst;
        gdvPlanCoverage.DataBind();
        if (lst == null)
        {
            this.lblTotalRecord.Text = "แสดงรายการข้อมูล [จำนวนข้อมูลทั้งหมด " + 0 + " รายการ]";
        }
        else
        {
            this.lblTotalRecord.Text = "แสดงรายการข้อมูล [จำนวนข้อมูลทั้งหมด " + lst.Rows.Count + " รายการ]";
        }
        this.lblInformMessage.Text = "";
        this.lblErrorMessage.Text = "";

    }
    void gdvPlanCoverage_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdvPlanCoverage.PageIndex = e.NewPageIndex;
        BindDataToGridView();

        this.lblInformMessage.Text = "";
        this.lblErrorMessage.Text = "";
    }
}