using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Upload_Upload : System.Web.UI.Page
{
    public string BrokerCode;
    public string urlFileUpload;
    protected void Page_Load(object sender, EventArgs e)
    {
        //src ="http://localhost/QuickLinkUpload/UPload.aspx?broker=<%=BrokerCode%>"
        urlFileUpload = QuickLinkConfiguration.UrlFileUpload.Trim();
        DropDownList ddl1 = (DropDownList)this.Master.FindControl("cmdBrokerInGroup");
        ddl1.SelectedIndexChanged += new EventHandler(MasterCmdBrokerInGroup_SelectedIndexChanged);

        this.BrokerCode = Utilities.BrokerCode();//"BR204";
    }
    protected void MasterCmdBrokerInGroup_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList ddl2 = (DropDownList)sender;
        this.BrokerCode = ddl2.SelectedValue.Trim();
        Session["BrokerCode"] = this.BrokerCode;
        Server.Transfer("../Upload/Upload.aspx");
    }

}
