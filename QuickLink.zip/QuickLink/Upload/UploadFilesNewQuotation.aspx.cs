﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Configuration;

public partial class UploadFilesNewQuotation : System.Web.UI.Page
{
    //DataSet ds;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        string tempBrokerCode = Utilities.BrokerCode();
        this.txbHdBrokerCode.Text = tempBrokerCode;
        string jscript = "function UploadComplete(){" + ClientScript.GetPostBackEventReference(LinkButton1, "") + "};";
        Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "FileCompleteUpload", jscript, true);
        
        //FlashUpload.Visible = true;

        string JobNo = Request.QueryString["JobNo"];
        //string BrokerCode = Request.QueryString["BrokerCode"];
        string BrokerCode = tempBrokerCode;
        string MakeModel = Request.QueryString["MakeModel"];

        Session.Add("JobNumber", JobNo);
        Session.Add("BrokerCode", BrokerCode);
        Session.Add("MakeModel", MakeModel);
        
        this.lblAgent.Text = BrokerCode;
        this.lbJobNo.Text = JobNo;
        this.lbAgentName.Text  = Broker.GetBrokerName2(BrokerCode);

        this.Process(JobNo, BrokerCode);
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        gvFileData.Visible = true;
        gvFileData.DataBind();
    }
    protected void Process(string JobNo,string BrokerCode)
    {
        lblErrorMsg.Text = "";
        int countFiles = 0;
        string uploadMainPath = Server.MapPath(Request.ApplicationPath + "/UploadFiles/");
        try
        {
            DirectoryInfo di = Directory.CreateDirectory(uploadMainPath + BrokerCode);
            //Create Folder Name by Job No.
            di.CreateSubdirectory(JobNo);
            //End Create Folder          
        }
        catch (Exception myEx)
        {
            lblErrorMsg.Text = "เกิดข้อผิดพลาดขึ้นขณะระบบกำลังประมวลผล!!!";
            lblErrorMsg.Text += "<br>" + myEx.Message;
        }
        finally
        {
            countFiles = UploadData.CountFilesDB(BrokerCode, JobNo);
            if (countFiles >= 10)
            {
                FlashUpload.Visible = false;
                lblErrorMsg.Text = "ขณะนี้ไฟล์ที่ท่าน Upload เกินจำนวนไฟล์ที่กำหนด ระบบไม่อนุญาตให้ทำการ Upload!!!กรุณาติดต่อ AXA HelpDesk";
                lblErrorMsg.Visible = true;
            }
            else
            {
                FlashUpload.Visible = true;
            }
        }
    }
    protected void gvFileData_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            int fileID = (int)gvFileData.DataKeys[e.RowIndex].Value;
            string fileName = UploadData.GetFileName(fileID);

            string JobNo = Request.QueryString["JobNo"];
            string BrokerCode = Utilities.BrokerCode();//Request.QueryString["BrokerCode"];


            string uploadMainPath = Server.MapPath(Request.ApplicationPath + "/UploadFiles/");
            string fullPathOfFile = uploadMainPath + "/" + BrokerCode + "/" + JobNo;
            if (!((BrokerCode == string.Empty) && (JobNo == string.Empty)))
            {
                DirectoryInfo di = new DirectoryInfo(fullPathOfFile);
                FileInfo[] fiArr = di.GetFiles();

                foreach (FileInfo fi in fiArr)
                {
                    if (fi.Name == fileName)
                    {
                        fi.Delete();
                    }
                }
            }
        }
        catch (Exception myEx)
        {
            lblErrorMsg.Text = "เกิดข้อผิดพลาดขึ้นขณะลบไฟล์!!!กรุณาติดต่อ AXA HelpDesk";
            lblErrorMsg.Text += "<br>" + myEx.Message;
        }
    }
    protected void gvFileData_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        
    }
}
