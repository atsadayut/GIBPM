﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

public partial class UploadViewImage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string temp = Request.QueryString["FileID"];
        string fullPath = "";
        
        if (!(temp == string.Empty || temp == ""))
        {
            int fileId = Convert.ToInt32(temp);
            //string[] arrTemp = new string[8];
            //char tempChar = '\\';
            
            //UploadData.UpdateFlagDownload(fileId);
            //fullPath = UploadData.GetFilePathNumber(fileId);
            fullPath = UploadData.GetPathShow(fileId);
            string path = fullPath.Substring(1, (fullPath.Length - 1));
            //arrTemp = fullPath.Split(tempChar);
                        
            //string urlPath = "http://" + Request.ServerVariables["Server_Name"] + "/" + arrTemp[3] + "/" + arrTemp[4] + "/" + arrTemp[5] + "/" + arrTemp[6] + "/" + arrTemp[7] ;
            string urlPath = "http://" + Request.ServerVariables["Server_Name"] + "/" + "QuickLink" + "/" + path ;
            Response.Redirect(urlPath);            
        }
        
    }
}
