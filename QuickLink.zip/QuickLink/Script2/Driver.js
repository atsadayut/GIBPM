﻿// JScript File
function DeleteDriver(DriverID,DriverName,DriverLicense,DriverDate,HDDriverID,HDDriverName,HDDriverLicense,HDDriverDate){
    document.getElementById(DriverID).value = document.getElementById(HDDriverID).value = "";
    document.getElementById(DriverName).value = document.getElementById(HDDriverName).value = "";
    document.getElementById(DriverLicense).value = document.getElementById(HDDriverLicense).value = "";
    document.getElementById(DriverDate).value = document.getElementById(HDDriverDate).value = "";
}

