﻿
function xfocus(x){
    x.style.color ='green';x.style.backgroundColor='#FFE0C0';
}
function xleave(x,y){
        if(y % 2 !=0)
        {
            x.style.color ='green';x.style.backgroundColor='#FFFFFF';
        }
        else
        {
            x.style.color ='green';x.style.backgroundColor='#EFF3FB';
        }
}
function xclick(x,y) {
         x.style.color ='green';x.style.backgroundColor = '#FFC0C0';  
         var lsString;  
         lsString=y;	
         //window.opener.parent.aspnetForm['" & "ctl00_phMain_txbCustomerNo" & "'].value=lsString  #EFF3FB #8bc8dd; 
         //window.opener.parent.aspnetForm['ctl00_phMain_txbCustomerNo'].value=lsString; 
         window.opener.parent.document.getElementById("txbContactOwner").value=lsString;
         window.close();
}




