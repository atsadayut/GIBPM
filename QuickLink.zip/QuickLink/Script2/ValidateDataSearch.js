﻿//-----------------------------------------------------------------------------------
//-----------------Trim ตัดช่องว่างข้างหน้า และตัดช่องว่างข้างหลัง -----------------------------
//-----------------------------------------------------------------------------------
function LTrim(str){
    if (str==null){
        return null;
    }
    for(i=0;str.charAt(i)==" ";i++);
    return str.substring(i,str.length);
}
function RTrim(str){
    if (str==null){
        return null;
    }
    for(i=str.length-1;str.charAt(i)==" ";i--);
    return str.substring(0,i+1);
}
function Trim(str){
    return LTrim(RTrim(str));
}
//------------------------------------------------------------------------------------
//                 ตรวจสอบว่า ผู้ใช้กำลังใช้ keyword อะไรในการค้นหา
//------------------------------------------------------------------------------------
function SearchByClientNumberOrID(txt1,txt2,lbl){
    document.getElementById(txt1).value = Trim(document.getElementById(txt1).value);
    var ltxt1 = document.getElementById(txt1).value.length;
    var ltxt2 = 0;
    if(document.getElementById(txt2) == null ){
        ltxt2 = -1;
    }else{
        document.getElementById(txt2).value = Trim(document.getElementById(txt2).value);
        ltxt2 = document.getElementById(txt2).value.length;
    }
    if(ltxt1 > 0 || ltxt2 > 0 ){
        document.getElementById(lbl).innerText = "คุณกำลังค้นหาโดยใช้";
        if(ltxt1 > 0){
            document.getElementById(lbl).innerText += " รหัสลูกค้า ";
        }
        if(ltxt1 > 0 && ltxt2 > 0){
            document.getElementById(lbl).innerText += "และ";
        }
        if(ltxt2 > 0){
            document.getElementById(lbl).innerText += " หมายเลขบัตรประชาชน ";
        }
    }else{
        document.getElementById(lbl).innerText = ""; 
    }
}
function isdigit(txt){
        //0-9
        if(txt < 48 || txt >57){
            return false;
        }
    return true;
}
function isEng(txt){
    // A-Z,a-z
    if(txt < 65 || txt > 122){
        return false;
    }
    return true;
}
function isThai(txt){
    // 3585 - 3630  3631 - 3659
    //   ก    -  ฮ            ฯ     -  ๋
    if(txt >3585 && txt <  3659){
        return true;
    }
    return false;
}
function CheckClient(txt,msg,btn){
document.getElementById(txt).value = Trim(document.getElementById(txt).value);
         if(document.getElementById(txt).value.length < 8){
                //document.getElementById(btn).disabled =true;
                if(document.getElementById(txt).value.length == 0){
                    document.getElementById(msg).innerText = "";
                }
                else{
                    document.getElementById(msg).innerText = "\nความยาว รหัสลูกค้า ต้องเท่ากับ 8 หลัก";
                }
                return 0;
         }
    for(i=0;i<document.getElementById(txt).value.length;i++){
        if(i==0){ // ตรวจสอบเมื่อ CllientNumber มีรูปแบบที่ต้องขึ้นต้นด้วยตัวอักษรอะไรก็ได้
            if( !isEng(document.getElementById(txt).value.charCodeAt(i)) &&
            !isdigit(document.getElementById(txt).value.charCodeAt(i)) ){
                document.getElementById(msg).innerText = "\nคุณระบุรูปแบบ รหัสลูกค้า ไม่ถูกต้อง!!";
                //document.getElementById(btn).disabled =true;
                return 0;
            }   
        }else{
            if( !isdigit(document.getElementById(txt).value.charCodeAt(i))){
                document.getElementById(msg).innerText = "\nคุณระบุรูปแบบ รหัสลูกค้า ไม่ถูกต้อง!!";
                //document.getElementById(btn).disabled =true;
                return 0;
            }  
        }
    }
    //document.getElementById(btn).disabled =false;
    document.getElementById(msg).innerText = "";
}
//---------------------------------------------------------------------
//              ตรวจสอบความถูกต้องของบัตรประชาชน
//---------------------------------------------------------------------
function CheckID(txt,msg,btn){
document.getElementById(txt).value = Trim(document.getElementById(txt).value);
   if(document.getElementById(txt).value.length < 13){
           //document.getElementById(btn).disabled =true;
           if(document.getElementById(txt).value.length == 0){
                    document.getElementById(msg).innerText = "";
            }
            else{
                    document.getElementById(msg).innerText = " \nความยาว หมายเลขบัตรประชาชน ต้องเท่ากับ 13 หลัก ";
            }
            return false;
    }
    for(i=0;i<document.getElementById(txt).value.length;i++){
            if( !isdigit(document.getElementById(txt).value.charCodeAt(i))){
                document.getElementById(msg).innerText = "\nคุณระบุรูปแบบหมายเลขบัตรประชาชน ไม่ถูกต้อง!";
                //document.getElementById(btn).disabled =true;
                return false;
            } 
     }
     var sum =0;
     //ตรวจสอบว่า เป็นเลขบัตรประชาชนที่ถูกต้องจริงหรือไม่ ตรวจสอบเลขตัวเลขว่าอยู่ในช่วง 1-8 หรือไม่
     if(document.getElementById(txt).value.charAt(0) < 1 
        || document.getElementById(txt).value.charAt(0) > 8){
            document.getElementById(msg).innerText = "\nคุณระบุรูปแบบหมายเลขบัตรประชาชน ไม่ถูกต้อง!";
        return false
     }
     for(i=0; i < 12; i++){
        sum += document.getElementById(txt).value.charAt(i)*(13-i);
     }
     sum = (11 - (sum%11))%10;
     if( sum == document.getElementById(txt).value.charAt(12)){
        //document.getElementById(btn).disabled = false;
        document.getElementById(msg).innerText = "";
        return true;
     }else{
        document.getElementById(msg).innerText = "\nคุณระบุรูปแบบหมายเลขบัตรประชาชน ไม่ถูกต้อง!!";
        return false
        //document.getElementById(btn).disabled =true;
     }
}
//-----------------------------------------------------------------------------
//                  ตรวจสอบความถูกต้องของชื่อ
//-----------------------------------------------------------------------------
function checkName(txt,msg,btn){
document.getElementById(txt).value = Trim(document.getElementById(txt).value);
    for(i=0;i<document.getElementById(txt).value.length;i++){
            if( !isEng(document.getElementById(txt).value.charCodeAt(i))){
                document.getElementById(msg).innerText = "\nคุณระบุรูปแบบชื่อ ไม่ถูกต้อง!!";
                //document.getElementById(btn).disabled =true;
                return 0;
            } 
     }
     //document.getElementById(btn).disabled =false;
     document.getElementById(msg).innerText = "";
}
//function CheckMsg(msg1,msg2,msg3,btn){
//    var lmsg1 = document.getElementById(msg1).innerText;
//    var lmsg2 = document.getElementById(msg2).innerText;
//    var lmsg3 = document.getElementById(msg3).innerText;
//    if(lmsg1 == "" && lmsg2 == "" && lmsg3 == "" ){
//        //กดไม่ได้
//        document.getElementById(btn).disabled = true;
//    }else{
//        if(lmsg1 != "" && lmsg3 == "" && lmsg2 == ""){
//            document.getElementById(btn).disabled =false;
//        }else{
//            if(lmsg1 != "" && (lmsg3 != "" || lmsg2 != "") ){
//            document.getElementById(btn).disabled =true;
//        }
//        }
//     }
//}
function CheckMsg(msg1,msg2,msg3,btn){
    var lmsg1 = document.getElementById(msg1).innerText;
    var lmsg2 = document.getElementById(msg2).innerText;
    var lmsg3 = document.getElementById(msg3).innerText;
    if(lmsg1 == "" && lmsg2 == "" && lmsg3 == "" ){
        //กดไม่ได้
        document.getElementById(btn).disabled = true;
        document.getElementById(msg1).style.color = "Red";
    }else{
        if(lmsg1 != "" && lmsg2 == "" && lmsg3 == ""){
            document.getElementById(btn).disabled =false;
            document.getElementById(msg1).style.color = "#00C000";
        }else{
            if(lmsg1 != "" && (lmsg2 != "" || lmsg3 != "") ){
            document.getElementById(btn).disabled =true;
            document.getElementById(msg1).style.color = "Red";
        }
        }
     }
}
