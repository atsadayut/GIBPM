﻿function calGrossPrems(ID,Gross0,Stamp0,Vat0,Gross1,Stamp1,Vat1,Gross2,Stamp2,Vat2,txbStamp1,txbVat1,txbStamp2,txbVat2,check){
    var BaseGrossID = "ctl00_"+ID+"_"+Gross0;
    var BaseGross = document.getElementById(BaseGrossID);
    var BaseStampID = "ctl00_"+ID+"_"+Stamp0;
    var BaseStamp = document.getElementById(BaseStampID);
    var BaseVatId = "ctl00_"+ID+"_"+Vat0;
    var BaseVat = document.getElementById(BaseVatId);
    
    var Gross1ID = "ctl00_"+ID+"_"+Gross1;
    var GrossNo1 = document.getElementById(Gross1ID);
    var Stamp1ID = "ctl00_"+ID+"_"+Stamp1;
    var StampNo1 = document.getElementById(Stamp1ID);
    var Vat1ID = "ctl00_"+ID+"_"+Vat1;
    var VatNo1 = document.getElementById(Vat1ID);
   
    var Gross2ID = "ctl00_"+ID+"_"+Gross2;
    var GrossNo2 = document.getElementById(Gross2ID);
    var Stamp2ID = "ctl00_"+ID+"_"+Stamp2;
    var StampNo2 = document.getElementById(Stamp2ID);
    var Vat2ID = "ctl00_"+ID+"_"+Vat2;
    var VatNo2 = document.getElementById(Vat2ID);
    
    //รับ ค่า Base Gross กับ Stamp จาก lable
    var GrossBasic = parseFloat(xSplitValue(BaseGross.innerText)).toFixed(2);
    var StampBasic = parseFloat(xSplitValue(BaseStamp.innerText)).toFixed(2);
    //alert(GrossBasic);
    //alert(StampBasic);
    
    var txbStamp1ID = "ctl00_"+ID+"_"+txbStamp1;
    var txbStamp2ID = "ctl00_"+ID+"_"+txbStamp2;
    var txbVat1ID = "ctl00_"+ID+"_"+txbVat1;
    var txbVat2ID = "ctl00_"+ID+"_"+txbVat2;
    
    var textboxStamp1 = document.getElementById(txbStamp1ID);
    var textboxStamp2 = document.getElementById(txbStamp2ID);
    var textboxVat1 = document.getElementById(txbVat1ID);
    var textboxVat2 = document.getElementById(txbVat2ID);
    
    GrossNo1.value = parseFloat(xSplitValue(GrossNo1.value)).toFixed(2);    
    //UPDATE 2009-08-06
    //alert(GrossNo1);
//    if(GrossNo1.value == "NaN")
//    {
//        GrossNo1.value = 0.00;
//    }
    if(GrossNo1.value == "NaN")
    {
        GrossNo1.value = 0.00;
    }else if(GrossNo1.value > 0 && GrossNo1.value < 1){
        GrossNo1.value = 1.00;
    }
    //**************************************************8
    if(parseFloat(GrossNo1.value) > GrossBasic)
    {
        GrossNo1.value = GrossBasic;
    }
//    //Bind Gross1,2
//    document.getElementById(Gross1).value = calGross1;
//    
      GrossNo2.value = GrossBasic - GrossNo1.value;
//    document.getElementById(Gross2).value = parseFloat(calGross2);

    
// --------------ปรับ STAMP DUTY------------------     
    var tmp1 = GrossNo1.value *0.004;
    var tmp2 = GrossNo2.value *0.004;
    //--------ถ้าเลือกใส่ input จาก Gross แถวแรก ทำ if ถ้าไม่ใช้ ทำ else----------
    if(check == true){  
        tmp1 = Math.ceil(tmp1);
        
        if((tmp1+tmp2) > BaseStamp.innerText)
        {
            tmp2 = Math.floor(tmp2);
        }
        else
        {
            tmp2 = Math.ceil(tmp2);
        }
    }else{
        tmp2 = Math.ceil(tmp2);   
        if((tmp1+tmp2) > BaseStamp.innerText)
        {
            tmp1 = Math.floor(tmp1);
        }
        else
        {
            tmp1 = Math.ceil(tmp1);
        }
    }
    
//----------------------------------------------    
//    //Bind Stamp1,2 and VAT1,2
    StampNo1.innerText = tmp1;
    StampNo2.innerText = tmp2;
    
    //สำหรับ Hidden
    textboxStamp1.value = tmp1;
    textboxStamp2.value = tmp2;
    //
    tmp1 = (parseFloat(GrossNo1.value) + tmp1)*0.07; 
    VatNo1.innerText = tmp1.toFixed(2);
    tmp2 = (parseFloat(GrossNo2.value) + tmp2)*0.07;
    VatNo2.innerText = tmp2.toFixed(2);
    
    //สำหรับ Hidden
    textboxVat1.value = tmp1.toFixed(2);
    textboxVat2.value = tmp2.toFixed(2);
    //
    //BaseVat.innerText = parseFloat(VatNo1.innerText) +parseFloat(VatNo2.innerText);
    //---------เปลี่ยน Fomate แสดง ตัวเลข------------
    GrossNo1.value = addNumber(GrossNo1.value);
    GrossNo2.value = addNumber(GrossNo2.value);
    BaseVat.innerText = addNumber(BaseVat.innerText);
    
    //UPDATE 2009-08-05 UPDATE TO CLEAR VALUE 0.00 to Empty
    //*******************************************************
    if(GrossNo1.value == 0.00){
        GrossNo1.value = "";
        StampNo1.innerText = "";
        textboxStamp1.value = "";
        VatNo1.innerText = "";
        textboxVat1.value = "";
    }
    if(GrossNo2.value == 0.00){
        GrossNo2.value = "";
        StampNo2.innerText = "";
        textboxStamp2.value = "";
        VatNo2.innerText = "";
        textboxVat2.value = "";
    }
    //*******************************************************
  
}
//------------------------------------------------------------------------------------
function calGrossPremsBoth(ID,Gross0,Stamp0,Vat0,Gross1,Stamp1,Vat1,Gross2,Stamp2,Vat2,txbStamp1,txbVat1,txbStamp2,txbVat2,check){
    var BaseGrossID = "ctl00_"+ID+"_"+Gross0;
    var BaseGross = document.getElementById(BaseGrossID);
    var BaseStampID = "ctl00_"+ID+"_"+Stamp0;
    var BaseStamp = document.getElementById(BaseStampID);
    var BaseVatId = "ctl00_"+ID+"_"+Vat0;
    var BaseVat = document.getElementById(BaseVatId);
    
    var Gross1ID = "ctl00_"+ID+"_"+Gross1;
    var GrossNo1 = document.getElementById(Gross1ID);
    var Stamp1ID = "ctl00_"+ID+"_"+Stamp1;
    var StampNo1 = document.getElementById(Stamp1ID);
    var Vat1ID = "ctl00_"+ID+"_"+Vat1;
    var VatNo1 = document.getElementById(Vat1ID);
   
    var Gross2ID = "ctl00_"+ID+"_"+Gross2;
    var GrossNo2 = document.getElementById(Gross2ID);
    var Stamp2ID = "ctl00_"+ID+"_"+Stamp2;
    var StampNo2 = document.getElementById(Stamp2ID);
    var Vat2ID = "ctl00_"+ID+"_"+Vat2;
    var VatNo2 = document.getElementById(Vat2ID);
    
    //รับ ค่า Base Gross กับ Stamp จาก lable
    var GrossBasic = parseFloat(xSplitValue(BaseGross.innerText)).toFixed(2);
    var StampBasic = parseFloat(xSplitValue(BaseStamp.innerText)).toFixed(2);
    //alert(GrossBasic);
    //alert(StampBasic);
    
    var txbStamp1ID = "ctl00_"+ID+"_"+txbStamp1;
    var txbStamp2ID = "ctl00_"+ID+"_"+txbStamp2;
    var txbVat1ID = "ctl00_"+ID+"_"+txbVat1;
    var txbVat2ID = "ctl00_"+ID+"_"+txbVat2;
    
    var textboxStamp1 = document.getElementById(txbStamp1ID);
    var textboxStamp2 = document.getElementById(txbStamp2ID);
    var textboxVat1 = document.getElementById(txbVat1ID);
    var textboxVat2 = document.getElementById(txbVat2ID);
    
    GrossNo1.value = parseFloat(xSplitValue(GrossNo1.value)).toFixed(2);    
    //alert(GrossNo1);
        if(GrossNo1.value == "NaN")
    {
        GrossNo1.value = 0.00;
    }
    if(parseFloat(GrossNo1.value) > GrossBasic)
    {
        GrossNo1.value = GrossBasic;
    }
//    //Bind Gross1,2
//    document.getElementById(Gross1).value = calGross1;
//    
      GrossNo2.value = GrossBasic - GrossNo1.value;
//    document.getElementById(Gross2).value = parseFloat(calGross2);
    if(GrossNo2.value == 0.00){
        GrossNo2.value = "";
        StampNo2.innerText = "";
        textboxStamp2.value = "";
        VatNo2.innerText = "";
        textboxVat2.value = "";
    }

    
// --------------ปรับ STAMP DUTY------------------     
    var tmp1 = GrossNo1.value *0.004;
    var tmp2 = GrossNo2.value *0.004;
    //--------ถ้าเลือกใส่ input จาก Gross แถวแรก ทำ if ถ้าไม่ใช้ ทำ else----------
    if(check == true){  
        tmp1 = Math.ceil(tmp1);
        
        if((tmp1+tmp2) > BaseStamp.innerText)
        {
            tmp2 = Math.floor(tmp2);
        }
        else
        {
            tmp2 = Math.ceil(tmp2);
        }
    }else{
        tmp2 = Math.ceil(tmp2);   
        if((tmp1+tmp2) > BaseStamp.innerText)
        {
            tmp1 = Math.floor(tmp1);
        }
        else
        {
            tmp1 = Math.ceil(tmp1);
        }
    }
    
//----------------------------------------------    
//    //Bind Stamp1,2 and VAT1,2
    StampNo1.innerText = tmp1;
    StampNo2.innerText = tmp2;
    
    //สำหรับ Hidden
    textboxStamp1.value = tmp1;
    textboxStamp2.value = tmp2;
    //
    tmp1 = (parseFloat(GrossNo1.value) + tmp1)*0.07; 
    VatNo1.innerText = tmp1.toFixed(2);
    tmp2 = (parseFloat(GrossNo2.value) + tmp2)*0.07;
    VatNo2.innerText = tmp2.toFixed(2);
    
    //สำหรับ Hidden
    textboxVat1.value = tmp1.toFixed(2);
    textboxVat2.value = tmp2.toFixed(2);
    //
    //BaseVat.innerText = parseFloat(VatNo1.innerText) +parseFloat(VatNo2.innerText);
    //---------เปลี่ยน Fomate แสดง ตัวเลข------------
    GrossNo1.value = addNumber(GrossNo1.value);
    GrossNo2.value = addNumber(GrossNo2.value);
    BaseVat.innerText = addNumber(BaseVat.innerText);
    
  
}
//-----------------------------------------------------------------------------------------------
function xSplitValue(x)
{
    var arr = new Array();
    var item ;
    var result;
    arr = (x).split(",");
    //alert(tempGross0[0]);
    //alert(tempGross0[1]);
    var done=true;
    for (item in arr)
    {
        if (done)
        {
            result=arr[item];
            done=false;
        }
        else
        {
            result +=arr[item];
        }
    }
    
    return (result) ;
}

function addNumber(Number){
    /* ถ้าต้องการใช้ เรียกใช้ใน หน้า asp ต้องเปลี่ยน parameter เป็น (ID,Text)
    และเปลี่ยน Number เป็น Number.value
    var NumClientID = "ctl00_"+ID+"_"+Text;
    //alert(document.getElementById(NumClientID));
    var Number = document.getElementById(NumClientID);*/
    
    var OutputNumber = "";
    var tmp="";
    var FloatingPoint = ".00";
    
    Number = cutSemi(Number);
    if(getfloatingPoint(Number) == -1){
        FloatingPoint = ".00";
    }else{
        
        FloatingPoint = getfloatingPoint(Number);
        FloatingPoint = parseFloat(FloatingPoint).toFixed(2);
        FloatingPoint = getfloatingPoint(FloatingPoint);
    }
    Number = cutFloatingPoint(Number);
    
    Number = revert(Number);
    
    for(var i=0;i<Number.length;i++){
        tmp += Number.charAt(i);
        if(((i+1)%3) == 0){
            OutputNumber += tmp;
            OutputNumber += ",";
            tmp ="";
        }
    }
    OutputNumber += tmp;
    
    
    OutputNumber =revert(OutputNumber);
    if(OutputNumber.charAt(0) == ","){
        OutputNumber = OutputNumber.substr(1,OutputNumber.length);
    }
    OutputNumber += FloatingPoint;
    Number = OutputNumber;
    return Number;
    
}
function revert(text){
    var tmp = "";
    for(var i=text.length;i >= 0;i--){
        tmp += text.charAt(i);
    }
    return tmp;
}
function cutSemi(text){
var tmp = "";
    for(var i =0;i<text.length;i++){
        if(text.charAt(i) != ","){
            tmp += text.charAt(i);
        }
    }
    return tmp;
}

function cutFloatingPoint(text){
    var tmp = "";
    for(var i =0;i<text.length;i++){
        if(text.charAt(i) != "."){
            
            tmp += text.charAt(i);
        }else break;
        
    }
    return tmp;
}
function getfloatingPoint(text){
    var tmp = "";
    var i = 0;
    for(var i = 0;i<text.length;i++){
        if(text.charAt(i) == ".") break;
    }
    if(i == text.length){
        
        return -1;
    }
    
    for(var j = i;j<text.length;j++){
        tmp += text.charAt(j);
    }
    return tmp;
}