﻿//------------------------------------------------------------------
//--------------onfocus เปลี่ยนสี-------------------------
//------------------------------------------------------------------
function fnTxtFocus(varname)
        {
            var objTXT = document.getElementById(varname)
            objTXT.style.background = "#CCFFCC";
            objTXT.style.border = "1px Solid #008000";
        }
function fnTxtLostFocus(varname)
{
    var objTXT = document.getElementById(varname)
    objTXT.style.background = "White";
    objTXT.style.border = "1px Solid #007799";
}

function fnOnLoad()
{
    var t = document.getElementsByTagName('INPUT');
    var i;
    for(i=0;i<t.length;i++)
    {
        if(t[i].type == "text")
        {   t[i].style.border ="1px Solid #007799";
            t[i].style.height = "18px";
            t[i].attachEvent('onfocus', new Function("fnTxtFocus('"+t[i].id+ "')"));
            t[i].attachEvent('onblur', new Function("fnTxtLostFocus('"+t[i].id+ "')"));
        }
    }
}