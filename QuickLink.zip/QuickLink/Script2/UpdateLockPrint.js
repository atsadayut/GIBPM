﻿//------------------------------------------------------------------
//---------------ใช้สำหรับ ตรวจสอบ ว่าหมายเลขตัวถัง ซ้ำกันหรือไม่
//------------------------------------------------------------------
function AjaxGetData(url, responseHandler)
{
    if (window.XMLHttpRequest)
     {
         // browser has native support for XMLHttpRequest object
         req = new XMLHttpRequest();
     }
     else if (window.ActiveXObject)
     {
         // try XMLHTTP ActiveX (Internet Explorer) version
         req = new ActiveXObject("Microsoft.XMLHTTP");
     }
     
     if(req)
     {
         req.onreadystatechange = responseHandler;
         req.open('GET', url, true);
         req.setRequestHeader("content-type","application/x-www-form-urlencoded");
         req.send('');
     }
     else
     {
         alert('Your browser does not seem to support XMLHttpRequest.');
     }
 } 
function FunctionUpdateLockPrint(flagcolumnname,reportid,policynovolun,policynocompl)
{
    var flagColumnName = flagcolumnname;
    var reportId = reportid;
    var policyNoVolun = policynovolun;
    var policyNoCompl = policynocompl;
   
//    alert("aaaa");
//    return;
    
    URL = "UpdateLockPrint.ashx?FlagColumnName="+flagColumnName+"&ReportID="+reportId+"&PolicyNoVolun="+policyNoVolun+"&PolicyNoCompl="+policyNoCompl;
    
    AjaxGetData(URL,SendUpdateLockPrintToAJAX) ;
}

function FunctionCheckLockPrint(flagcolumnname,reportid,policynovolun,policynocompl)
{
    var flagColumnName = flagcolumnname;
    var reportId = reportid;
    var policyNoVolun = policynovolun;
    var policyNoCompl = policynocompl;
   
//    alert("aaaa");
//    return;
    
    URL = "CheckLockPrint.ashx?FlagColumnName="+flagColumnName+"&ReportID="+reportId+"&PolicyNoVolun="+policyNoVolun+"&PolicyNoCompl="+policyNoCompl;
    
    AjaxGetData(URL,SendCheckLockPrintToAJAX) ;
}


function SendUpdateLockPrintToAJAX()
{
    try
    {
        //readyState of 4 or 'complete' represents 
        //that data has been returned 
        if (req.readyState == 4 ||  req.readyState == 'complete')
        {
            var arr1 = new Array();
            var result = req.responseText;
            arr1 = result.split(",");
            if (arr1[0]!="")
            {
                //document.getElementById('ctl00_MainContent_lbMsgPrint').innerHTML = arr1[0].toString();
                //document.getElementById('lbMsgPrint').innerHTML = arr1[0].toString();
                //document.getElementById('ctl00_MainContent_txbHdPrintLockNum').value = "0";
            }
            else
            {
                
                //document.getElementById('ctl00_MainContent_lbMsgPrint').innerHTML = "";
                
                //document.getElementById('lbMsgPrint').innerHTML = "";
                //document.getElementById('ctl00_MainContent_txbHdPrintLockNum').value = arr1[1].toString();  //2 ครั้ง
            }
         }
    }
    catch(e){
        //alert('Error in Ajax respone');
    }
}
function SendCheckLockPrintToAJAX()
{
    try
    {
        //readyState of 4 or 'complete' represents 
        //that data has been returned 
        if (req.readyState == 4 ||  req.readyState == 'complete')
        {
            var arr1 = new Array();
            var result = req.responseText;
            arr1 = result.split(",");
            if (arr1[0]!="")
            {
                //document.getElementById('ctl00_MainContent_lbMsgPrint').innerHTML = arr1[0].toString();
                //document.getElementById('lbMsgPrint').innerHTML = arr1[0].toString();
                //document.getElementById('ctl00_MainContent_txbHdPrintLockNum').value = "0";
            }
            else
            {
                //document.getElementById('ctl00_MainContent_lbMsgPrint').innerHTML = "";
                //document.getElementById('lbMsgPrint').innerHTML = "";
                //document.getElementById('ctl00_MainContent_txbHdPrintLockNum').value = arr1[1].toString();  //2 ครั้ง
            }
         }
    }
    catch(e)
    {
        //alert('Error in Ajax respone');
    }
}
    
    
