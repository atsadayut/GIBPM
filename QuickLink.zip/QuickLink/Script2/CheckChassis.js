﻿//------------------------------------------------------------------
//---------------ใช้สำหรับ ตรวจสอบ ว่าหมายเลขตัวถัง ซ้ำกันหรือไม่
//------------------------------------------------------------------
function AjaxGetData(url, responseHandler)
{
    if (window.XMLHttpRequest)
     {
         // browser has native support for XMLHttpRequest object
         req = new XMLHttpRequest();
     }
     else if (window.ActiveXObject)
     {
         // try XMLHTTP ActiveX (Internet Explorer) version
         req = new ActiveXObject("Microsoft.XMLHTTP");
     }
     
     if(req)
     {
         req.onreadystatechange = responseHandler;
         req.open('GET', url, true);
         req.setRequestHeader("content-type","application/x-www-form-urlencoded");
         req.send('');
     }
     else
     {
         alert('Your browser does not seem to support XMLHttpRequest.');
     }
 } 
function CheckChassis(){
    var Chassis = document.getElementById('ctl00_MainContent_txbChassis').value;
    var radioPolicyType = document.getElementById('ctl00_MainContent_rdoPoliyType');
    var optionPolicyType = radioPolicyType.getElementsByTagName('input');
    var i =0;
    for (i = 0; i < radioPolicyType.rows[0].cells.length; i++) {
        if(optionPolicyType[i].checked){
            break;
        }
    }
    var PolicyType = optionPolicyType[i].value;
    if(PolicyType == "Voluntary"){
        PolicyType = "VOLUN";
    }else{
        if(PolicyType == "Compulsary"){
            PolicyType = "COMPL";
        }else{
            PolicyType = "BOTH";
        }
    }
    URL = "CheckChassis.ashx?Chessis="+Chassis+"&PolicyType="+PolicyType;
    AjaxGetData(URL,SendChassisToAJAX); 
}
function SendChassisToAJAX(){
    try{
        //readyState of 4 or 'complete' represents 
        //that data has been returned 
        if (req.readyState == 4 ||  req.readyState == 'complete')
        {
            var arr1 = new Array();
            var result = req.responseText;
     
            arr1 = result.split(",");
            if (arr1[0]=="YES")
            {
                document.getElementById('ctl00_MainContent_lbMessageSumInsure').innerHTML = "เลขที่ตัวถัง "+arr1[1]+" นี้ได้ถูกใช้แล้ว กรุณาติดต่อ AXA Helpdesk";
                document.getElementById('ctl00_MainContent_txbChassis').value = "";
            }else{
                document.getElementById('ctl00_MainContent_lbMessageSumInsure').innerHTML = "";
            }
         }
    }
    catch(e){
        //alert('Error in Ajax respone');
    }
}
