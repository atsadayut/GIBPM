﻿// JScript File

//function checkSplit(Rdo1,done){
//    var RadioList = document.getElementById(Rdo1);
//    //var chkbok = document.getElementById(chk);
//    var v ="";
//    for(var i=0;i<RadioList.rows.length;i++){
//        for(var j=0;j<RadioList.cells.length;j++){
//            var List = RadioList.rows[i].cells[j].childNodes[0];
//            if( List.checked){
//               v= List.value;
//               if (v =="Compulsary")
//               {
//                    setViewCheckbox(done,'SplitVATVolun');
//               }
//               else
//               {
//                    setViewCheckbox(done,'SplitVATBoth');
//               }
//            }
//        }
//    }
////setViewCheckbox(done,'SplitVATVolun'); 
////setViewCheckbox(done,'SplitVATBoth');
//}
function CheckPolicyType(){
    var PolicyType = valueOfPolicyType();
    document.getElementById('ctl00_MainContent_lbPolicyTypeTemp').innerText=PolicyType;
    document.getElementById('ctl00_MainContent_chkSplitVAT').checked = false;
    HideAllSplitVAT();
}
//-------------------------ฟังก์ชั่น นี้จะทำงานเมื่อ Checkbox ที่กดเมื่อต้องการแสดง Split VAT -----------------------------
//-----------------การทำงานคือ จะรับค่าจาก Radito Botton 'rdoPoliyType' มา แล้วตรวจสอบว่าเป็น Value อะไร---------------
//------------------จากนั้นค่อย ทำการ ซ่อน หรือ แสดง tag div ของ Split VAT แต่ละแบบ ---------------------------------
function CheckSplitVat(){

    if(document.getElementById('ctl00_MainContent_chkSplitVAT').checked){
        HideAllSplitVAT();
        var PolicyType = valueOfPolicyType();
        if(PolicyType == "Voluntary")
        {
                 document.getElementById('SplitVATVolun').style.display = "block";
                 document.getElementById('ctl00_MainContent_txbVolunGrossPremium_1').focus();
        }
        else
        {
            if(PolicyType == "Compulsary")
            {
                 document.getElementById('SplitVATCompulsary').style.display = "block";
                 document.getElementById('ctl00_MainContent_lbCompGrossPremium_1').focus();
            }
            else
            {
                if(PolicyType == "Both")
                {
                    document.getElementById('SplitVATBoth').style.display = "block";
                    document.getElementById('ctl00_MainContent_txbBothVolunGrossPremium_1').focus();
                }
            }
        }
    }
    else
    {
        HideAllSplitVAT();
    }
}
// ฟังก์ชั่น ซ่อน Split VAT ทั้ง สามแบบ เลย
function HideAllSplitVAT(){
    document.getElementById('SplitVATVolun').style.display = "none";
    document.getElementById('SplitVATBoth').style.display = "none";
    document.getElementById('SplitVATCompulsary').style.display = "none";
}
//-------ฟังก์ชั่น สำหร้บ ส่งค่าว่า Radio Botton ซึ่งจะส่งค่า Voluntary หรือ Compulsary หรือ Both ออกมา-------
function valueOfPolicyType() {
    var RadioList = document.getElementById('ctl00_MainContent_rdoPoliyType');
    for (var i = 0; i < RadioList.rows.length; i++) {
        for (var j = 0; j < RadioList.rows[i].cells.length; j++) {
            var List = RadioList.rows[i].cells[j].childNodes[0];
            if (List.checked) {
                return List.value;
            }
        }
    }

    RadioList = document.getElementById('ctl00_MainContent_rdoPoliyType2');
    for (var i = 0; i < RadioList.rows.length; i++) {
        for (var j = 0; j < RadioList.rows[i].cells.length; j++) {
            var List = RadioList.rows[i].cells[j].childNodes[0];
            if (List.checked) {
                return List.value;
            }
        }
    }
}
