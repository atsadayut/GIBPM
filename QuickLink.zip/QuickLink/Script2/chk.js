﻿function CheckMsg1(msg1,msg2,msg3,btn){
    var lmsg1 = document.getElementById(msg1).innerText;
    var lmsg2 = document.getElementById(msg2).innerText;
    var lmsg3 = document.getElementById(msg3).innerText;
    if(lmsg1 == "" && lmsg2 == "" && lmsg3 == "" ){
        //กดไม่ได้
        document.getElementById(btn).disabled = true;
        document.getElementById(msg1).style.color = "Red";
    }else{
        if(lmsg1 != "" && lmsg2 == "" && lmsg3 == ""){
            document.getElementById(btn).disabled =false;
            document.getElementById(msg1).style.color = "Green";
        }else{
            if(lmsg1 != "" && (lmsg2 != "" || lmsg3 != "") ){
            document.getElementById(btn).disabled =true;
            document.getElementById(msg1).style.color = "Red";
        }
        }
     }
}
function CheckMsg2(msg1,msg2,msg3,msg4,msg5,btn){
    var lmsg1 = document.getElementById(msg1).innerText;
    var lmsg2 = document.getElementById(msg2).innerText;
    var lmsg3 = document.getElementById(msg3).innerText;
    var lmsg4 = document.getElementById(msg4).innerText;
    var lmsg5 = document.getElementById(msg5).innerText;
    if(lmsg1 == "" && lmsg2 == "" && lmsg3 == "" && lmsg4 == "" && lmsg5 == ""){
        //กดไม่ได้
        document.getElementById(btn).disabled = true;
        document.getElementById(msg1).style.color = "Red";
    }else{
        if(lmsg1 != "" && lmsg2 == "" && lmsg3 == "" && lmsg4 == "" && lmsg5 == ""){
            document.getElementById(btn).disabled =false;
            document.getElementById(msg1).style.color = "Green";
        }else{
            if(lmsg1 != "" && (lmsg2 != "" || lmsg3 != "" || lmsg4 != "" || lmsg5 != "") ){
                document.getElementById(btn).disabled =true;
                document.getElementById(msg1).style.color = "Red";
            }
        }
     }
}
function CheckMsg3(msg1,msg2,msg3,btn){
    var lmsg1 = document.getElementById(msg1).innerText;
    var lmsg2 = document.getElementById(msg2).innerText;
    var lmsg3 = document.getElementById(msg3).innerText;
    if(lmsg1 == "" && lmsg2 == "" && lmsg3 == ""){
        //กดไม่ได้
        document.getElementById(btn).disabled = true;
        document.getElementById(msg1).style.color = "Red";
    }else{
        if(lmsg1 != "" && lmsg2 == "" && lmsg3 == ""){
            document.getElementById(btn).disabled =false;
            document.getElementById(msg1).style.color = "Green";
        }else{
            if(lmsg1 != "" && (lmsg2 != "" || lmsg3 != "") ){
                document.getElementById(btn).disabled =true;
                document.getElementById(msg1).style.color = "Red";
            }
        }
     }
}
//-----------------------------------------------------------------------------------
//-----------------Trim ตัดช่องว่างข้างหน้า และตัดช่องว่างข้างหลัง -----------------------------
//-----------------------------------------------------------------------------------
function LTrim(str){
    if (str==null){
        return null;
    }
    for(i=0;str.charAt(i)==" ";i++);
    return str.substring(i,str.length);
}
function RTrim(str){
    if (str==null){
        return null;
    }
    for(i=str.length-1;str.charAt(i)==" ";i--);
    return str.substring(0,i+1);
}
function Trim(str){
    return LTrim(RTrim(str));
}
//------------------------------------------------------------------------------------
//                 ตรวจสอบว่า ผู้ใช้กำลังใช้ keyword อะไรในการค้นหา
//------------------------------------------------------------------------------------
function SearchByClientNumberOrID(txt1,txt2,lbl){
    document.getElementById(txt1).value = Trim(document.getElementById(txt1).value);
    var ltxt1 = document.getElementById(txt1).value.length;
    var ltxt2 = 0;
    if(document.getElementById(txt2) == null ){
        ltxt2 = -1;
    }else{
        document.getElementById(txt2).value = Trim(document.getElementById(txt2).value);
        ltxt2 = document.getElementById(txt2).value.length;
    }
    if(ltxt1 > 0 || ltxt2 > 0 ){
        document.getElementById(lbl).innerText = "คุณกำลังค้นหาโดยใช้";
        if(ltxt1 > 0){
            document.getElementById(lbl).innerText += " รหัสลูกค้า ";
            //document.getElementById(txt1).style.background="#CCFFCC";
        }
        if(ltxt1 > 0 && ltxt2 > 0){
            document.getElementById(lbl).innerText += "และ";
        }
        if(ltxt2 > 0){
            document.getElementById(lbl).innerText += " หมายเลขบัตรประชาชน";
            //document.getElementById(txt2).style.background="#CCFFCC";
        }
    }else{
        //document.getElementById(txt1).style.background="";
        //document.getElementById(txt2).style.background="Transparent";
        document.getElementById(lbl).innerText = ""; 
    }
    
}
function isdigit(txt){
        //0-9
        if(txt < 48 || txt >57){
            return false;
        }
    return true;
}
function isEng(txt){
    //        65    -   90              97 -  122  
    //         A    -   Z,              a  -   z
    if( (txt < 65 || txt > 90) && (txt < 97 || txt > 122) ){
        return false;
    }
    return true;
}
function isThai(txt){
    // 3585 - 3630  3631 - 3659
    //   ก    -  ฮ            ฯ     -  ๋
    if(txt < 3585 || txt >  3659){
        return false;
    }
    return true;
}
//----------------------------------------------------------------------
//                      ตรวจสอบความถูกต้องของ รหัสลูกค้า
//----------------------------------------------------------------------
function CheckClient(txt,msg){
    //document.getElementById(txt).value = Trim(document.getElementById(txt).value);
         if(document.getElementById(txt).value.length < 8){
                if(document.getElementById(txt).value.length == 0){
                    document.getElementById(msg).innerText = "";
                }
                else{
                    document.getElementById(msg).innerText = "\nความยาว รหัสลูกค้า ต้องเท่ากับ 8";
                }
                return 0;
         }
    for(i=0;i<document.getElementById(txt).value.length;i++){
        if(i==0){ // ตรวจสอบเมื่อ CllientNumber มีรูปแบบที่ต้องขึ้นต้นด้วยตัวอักษรอะไรก็ได้
            if( !isEng(document.getElementById(txt).value.charCodeAt(i)) &&
            !isdigit(document.getElementById(txt).value.charCodeAt(i)) ){
                document.getElementById(msg).innerText = "\nรูปแบบการกรอก รหัสลูกค้า ไม่ถูกต้อง!!";
                return 0;
            }   
        }else{
            if( !isdigit(document.getElementById(txt).value.charCodeAt(i))){
                document.getElementById(msg).innerText = "\nรูปแบบการกรอก รหัสลูกค้า ไม่ถูกต้อง!!";
                return 0;
            }  
        }
    }
    document.getElementById(msg).innerText = "";
}
//----------------------------------------------------------------------
//              ตรวจสอบการกรอก หมายเลขบัตรประชาชน
//----------------------------------------------------------------------
function CheckID(txt,msg){
//document.getElementById(txt).value = Trim(document.getElementById(txt).value);
   if(document.getElementById(txt).value.length < 13){
           if(document.getElementById(txt).value.length == 0){
                    document.getElementById(msg).innerText = "";
            }
            else{
                    document.getElementById(msg).innerText = "\nความยาว หมายเลขบัตรประชาชน ต้องเท่ากับ 13";
            }
            return 0;
    }
    for(i=0;i<document.getElementById(txt).value.length;i++){
            if( !isdigit(document.getElementById(txt).value.charCodeAt(i))){
                document.getElementById(msg).innerText = "\nรูปแบบการกรอก หมายเลขบัตรประชาชน ไม่ถูกต้อง!!";
                return 0;
            } 
     }
     var sum =0;
     //ตรวจสอบว่า เป็นเลขบัตรประชาชนที่ถูกต้องจริงหรือไม่
     if(document.getElementById(txt).value.charAt(0) != 1
        && document.getElementById(txt).value.charAt(0) != 3){
        return document.getElementById(msg).innerText = "\nหมายเลขบัตรประชาชน ไม่ถูกต้อง!!";
     }
     for(i=0; i < 12; i++){
        sum += document.getElementById(txt).value.charAt(i)*(13-i);
     }
     sum = (11 - (sum%11))%10;
     if( sum == document.getElementById(txt).value.charAt(12)){
        document.getElementById(msg).innerText = "";
     }else{
        document.getElementById(msg).innerText = "\nหมายเลขบัตรประชาชน ไม่ถูกต้อง!!";
     }
}
//----------------------------------------------------------------------
//              ตรวจสอบการกรอก ชื่อ
//----------------------------------------------------------------------
//parameter txt = textbox, msg = labelmessage, btn = button
function isNameEngFormat(txt){
    if(!isEng(txt) && txt != 46){
        return false;
    }
    return true;
}
function CheckName(txt,msg){
    //document.getElementById(txt).value = Trim(document.getElementById(txt).value);
    var CheckEng = 1;
    var i = 0;
    //---------------------first Character---------------------
    if( i == 0){
        if(isEng(document.getElementById(txt).value.charCodeAt(0))){
               CheckEng = 1;
        }else{
            if(isThai(document.getElementById(txt).value.charCodeAt(0))){
                CheckEng = 0;
             }else{
                document.getElementById(msg).innerText = "\nรูปแบบการกรอก ชื่อ ไม่ถูกต้อง!!";
                return 0;
             }
        }
    }
    //--------------------two or more characters------------------
    for(i=1;i<document.getElementById(txt).value.length;i++){
    // ถ้าเราต้องการค้นชื่อเป็นภาษาอังกฤษ เราจะสามารถใช้ อักขระ '.' ได้ แต่ภาษาไทย ไม่ได้
        if(CheckEng == 1){
            if(!isNameEngFormat(document.getElementById(txt).value.charCodeAt(i)) ){
                document.getElementById(msg).innerText = "\nรูปแบบการกรอก ชื่อ ไม่ถูกต้อง!!";
                return 0;
            } 
        }else{
             if(!isThai(document.getElementById(txt).value.charCodeAt(i)) ){
                document.getElementById(msg).innerText = "\nรูปแบบการกรอก ชื่อ ไม่ถูกต้อง!!";
                return 0;
            } 
        }
     }
     document.getElementById(msg).innerText = "";
}
//----------------------------------------------------------------------
//              ตรวจสอบการกรอก นามสกุล
//----------------------------------------------------------------------
//parameter txt = textbox, msg = labelmessage, btn = button
function isSurNameFormat(txt){
    if(!isEng(txt) && !isThai(txt) && txt != 40 && txt != 41 && txt != 46 && txt != 32){
               return false;
    }
    return true;
}
function CheckSurName(txt,msg){
   // document.getElementById(txt).value = Trim(document.getElementById(txt).value);
    var i = 0;
    //---------------------first Character---------------------
    if( i == 0){
        if(!isEng(document.getElementById(txt).value.charCodeAt(0))
            && !isThai(document.getElementById(txt).value.charCodeAt(0))){
                document.getElementById(msg).innerText = "\nกรอกรูปแบบ นามสกุล ไม่ถูกต้อง!!";
                return 0;
         }
     }
    //--------------------two or more characters------------------
    for(i=1;i<document.getElementById(txt).value.length;i++){
    // ถ้าเราต้องการค้นนามสกุล เราสามารถ ใส่ ภาษาไทยและ ภาษาอังกฤษปนกันได้ และสามารถมี '(' '.' ')' ได้
        if(!isSurNameFormat(document.getElementById(txt).value.charCodeAt(i)) ){
               document.getElementById(msg).innerText = "\nกรอกรูปแบบ นามสกุล ไม่ถูกต้อง!!";
               return 0;
         }
    } 
     document.getElementById(msg).innerText = "";
}
//----------------------------------------------------------------------
//              ตรวจสอบว่า ความสอดคล้องกันระหว่าง ชื่อ และนามสกุล 
//          ชื่อ กับ นามสกุล ถ้าเป็น ภาษาไทย ต้อง ไทยทั้งคู่ ถ้าเป็นภาษาอังกฤษต้องอังกฤษทั้งคู่
//----------------------------------------------------------------------
// parameter  txt1 = Name, txt2 = SurName
function CheckNameAndSurName(txt1,txt2,msg1,msg2,msg3,msg4){
    var showHow = document.getElementById(msg1).innerText;
    var showMsg2 = document.getElementById(msg2).innerText;
    var showMsg3 = document.getElementById(msg3).innerText;
    if(document.getElementById(txt1).value.length > 0 && document.getElementById(txt2).value.length > 0){
        if(showHow != "" && showMsg2 == "" && showMsg3 == ""){
            if(!isNameEngFormat(document.getElementById(txt1).value.charCodeAt(0))
                && !isSurNameFormat(document.getElementById(txt2).value.charCodeAt(0)) ){
                document.getElementById(msg4).innerText = "\nรูปแบบข้อมูลของ ชื่อ และ นามสกุล ไม่สอดคล้องกัน";
                return 0;   
            }else{
                if(!isThai(document.getElementById(txt1).value.charCodeAt(0))
                    && !isEng(document.getElementById(txt2).value.charCodeAt(0)) ){
                    document.getElementById(msg4).innerText = "\nรูปแบบข้อมูลของ ชื่อ และ นามสกุล ไม่สอดคล้องกัน";
                    return 0;   
                }else{
                    document.getElementById(msg4).innerText = "";
                }    
            }
        }
    }
   document.getElementById(msg4).innerText = "";  
}
//----------------------------------------------------------------------
//              ตรวจสอบว่า เลขที่อยู่ถูกต้องหรือไม่ตามรูปแบบที่สั้นที่สุดคือ 1/1-1
//----------------------------------------------------------------------
function CheckAddress(txt,msg){
    //document.getElementById(txt).value = Trim(document.getElementById(txt).value);
    var i = 0;
    var maxlength = document.getElementById(txt).value.length;
    if(maxlength == 0){
        document.getElementById(msg).innerText = "";
        return 0;
    }
    // 1. check digit
    while( i < maxlength){
        if( isdigit(document.getElementById(txt).value.charCodeAt(i)) ){
            i++;
        }else{
            break;
        }
    }
    if(i == maxlength){
        document.getElementById(msg).innerText = "";
        return 0;
    }
    //2. check back slash
    if(document.getElementById(txt).value.charCodeAt(i) == 47){
        i++;
        
        if(i == maxlength){
            document.getElementById(msg).innerText = "\nรูปแบบการกรอก เลขที่อยู่ ไม่ถูกต้อง!!";
            return 0;
        }else{
        //3. check digit behind back slash
            while( i < maxlength){
            
                if( isdigit(document.getElementById(txt).value.charCodeAt(i)) ){
                    i++;
                }else{
                     break;
                }
            }
            
           if(i == maxlength){
                document.getElementById(msg).innerText = "";
                return 0;
            }else{
                   //4. check subtract
                if(document.getElementById(txt).value.charCodeAt(i) == 45){
                    i++;
                    if(i == maxlength){
                        document.getElementById(msg).innerText = "\nรูปแบบการกรอก เลขที่อยู่ ไม่ถูกต้อง!!";
                        return 0;
                    }else{
                    //5. check All digit behid substract
                        while( i < maxlength){
                            if(isdigit(document.getElementById(txt).value.charCodeAt(i))){
                                i++;
                            }else{
                                break;
                            }
                        }//end while
                        if(i == maxlength){
                            document.getElementById(msg).innerText = "";
                            return 0;  
                        }else{
                            document.getElementById(msg).innerText = "\nรูปแบบการกรอก เลขที่อยู่ ไม่ถูกต้อง!!";
                            return 0;
                        }    
                    }//end else check substact
                }else{
                    document.getElementById(msg).innerText = "\nรูปแบบการกรอก เลขที่อยู่ ไม่ถูกต้อง!!";
                    return 0;
                }
              }//end else digit behind back slash
        }//end else check back slas
    }else{//end else 47
        document.getElementById(msg).innerText = "\nรูปแบบการกรอก ที่อยู่ เลขไม่ถูกต้อง!!";
        return 0;
    }
}
//----------------------------------------------------------------------
//              ตรวจสอบว่า ผู้ใช้กำลังใช้ keyword อะไรในการค้นหา
//                          ชื่อ นามสกุล เลขที่อยู่
//----------------------------------------------------------------------
function SearchByNameSurNameOrAdd(txt1,txt2,txt3,lbl){
    //txt1 = ชื่อ , txt2 = นามสกุล , txt3 = ที่อยู่
    document.getElementById(txt1).value = LTrim(document.getElementById(txt1).value);
    document.getElementById(txt2).value = LTrim(document.getElementById(txt2).value);
    document.getElementById(txt3).value = LTrim(document.getElementById(txt3).value);
    var ltxt1 = document.getElementById(txt1).value.length;
    var ltxt2 = document.getElementById(txt2).value.length;
    var ltxt3 = document.getElementById(txt3).value.length;
    //ต้องมี ชื่อ หรือ นามสกุล อย่างใดอย่างหนึ่ง หรือทั้ง สองอย่าง
    if(ltxt1 > 0 || ltxt2 > 0 ){
        document.getElementById(lbl).innerText = "คุณกำลังค้นหาโดยใช้";
        if(ltxt1 > 0){
            document.getElementById(lbl).innerText += " ชื่อ ";
        }
        if(ltxt1 > 0 && ltxt2 > 0){
            document.getElementById(lbl).innerText += "และ";
        }else{
            if(ltxt1 > 0 && ltxt2 > 0){
                document.getElementById(lbl).innerText += ",";
            }
        }
        if(ltxt2 > 0){
            document.getElementById(lbl).innerText += " นามสกุล";
        }
        document.getElementById(txt3).disabled = false;
        //ถ้ามี ชื่อ หรือ นามสกุล อย่างใดอย่างหนึ่ง หรือทั้ง สองอย่าง
       if((ltxt1 > 0 || ltxt2 > 0) && ltxt3 > 0){
            document.getElementById(lbl).innerText += " และเลขที่อยู่";
       }
    }else{
        //ถ้า ไม่ได้ใส่ทั้งชื่อ และนามสกุล ให้ออก
        document.getElementById(txt3).disabled = true;
        document.getElementById(lbl).innerText = "";
        if(ltxt3 != 0){
            document.getElementById(txt3).value = "";
            return 0;
        }
    }
}
//----------------------------------------------------------------------
//              ตรวจสอบว่า ผู้ใช้กำลังใช้ keyword อะไรในการค้นหา
//                          ชื่อบริษัท เลขที่อยู่
//----------------------------------------------------------------------
function SearchByCorNameAndAddress(txt1,txt2,lbl){
    //txt1 = ชื่อ , txt2 = นามสกุล , txt3 = ที่อยู่
    document.getElementById(txt1).value = LTrim(document.getElementById(txt1).value);
    document.getElementById(txt2).value = LTrim(document.getElementById(txt2).value);
    var ltxt1 = document.getElementById(txt1).value.length;
    var ltxt2 = document.getElementById(txt2).value.length;
    //ต้องมี ชื่อ หรือ นามสกุล อย่างใดอย่างหนึ่ง หรือทั้ง สองอย่าง
    if(ltxt1 > 0){
        document.getElementById(txt2).disabled = false;
        document.getElementById(lbl).innerText = "คุณกำลังค้นหาโดยใช้ ชื่อบริษัท ";
        //ถ้ามี ชื่อ หรือ นามสกุล อย่างใดอย่างหนึ่ง หรือทั้ง สองอย่าง
       if(ltxt1 > 0 && ltxt2 > 0){
            document.getElementById(lbl).innerText += " และเลขที่อยู่";
       }
    }else{
        //ถ้า ไม่ได้ใส่ทั้งชื่อ และนามสกุล ให้ออก
        document.getElementById(lbl).innerText = "";
        document.getElementById(txt2).disabled = true;
        if(ltxt2 != 0){
            document.getElementById(txt2).value = "";
            return 0;
        }
    }
    
}
//----------------------------------------------------------------------
//              ตรวจสอบว่า ชื่อบริษัท ว่าถูกต้องตาม รูปแบบที่กำหนดหรือไม่
//          สามารถมี @ # , & . - _ ( ) [ ] { } / และเว้นวรรคได้                
//----------------------------------------------------------------------
function isCorperateFormat(txt){
    if(!isEng(txt) && !isThai(txt) && !isdigit(txt)){
        switch(txt){
            case 32 : 
            case 35 : 
            case 38 : 
            case 40 : 
            case 41 : 
            case 44 : 
            case 45 : 
            case 46 : 
            case 47 : 
            case 64 : 
            case 91 : 
            case 93 : 
            case 95 :  
            case 123 : 
            case 125 : return true;
            default : return false;
        }
               return false;
    }
    return true;
}
function CheckCorperateName(txt,msg){

var i = 0;
    //---------------------first Character---------------------
   /* if( i == 0){
        if(!isEng(document.getElementById(txt).value.charCodeAt(0))
            && !isThai(document.getElementById(txt).value.charCodeAt(0))
            && !isdigit(document.getElementById(txt).value.charCodeAt(0))){
                document.getElementById(msg).innerText = "รูปแบบการกรอก ชื่อบริษัท ไม่ถูกต้อง!!";
                return 0;
         }
     }*/
    //--------------------two or more characters------------------
    for(i=0;i<document.getElementById(txt).value.length;i++){
    // ถ้าเราต้องการค้นชื่อบริษัท เราสามารถ ใส่ ภาษาไทยและ ภาษาอังกฤษปนกันได้ และสามารถมี @ # , & . - _ ( ) [ ] { } / ได้
        if(!isCorperateFormat(document.getElementById(txt).value.charCodeAt(i)) ){
               document.getElementById(msg).innerText = "\nรูปแบบการกรอก ชื่อบริษัท ไม่ถูกต้อง!!";
               return 0;
         }
    } 
     document.getElementById(msg).innerText = "";
}