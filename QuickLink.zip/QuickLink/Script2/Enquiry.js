﻿// JScript File Enquriy.js

           function xfocus(x){
                x.style.color ='blue' ; x.style.backgroundColor = '#c3c3ff';  
           }
           function xleave(x){
                x.style.color ='black'; x.style.backgroundColor = 'white'  ;  
           }
           function xclick(x){
                x.style.color ='green'; x.style.backgroundColor = '#FFC0C0';  
           }
           function xfocusTextboxin(x){
                x.style.color ='red'  ; x.style.backgroundColor = '00cd66'  ;  
           }
           function  xfocusTextboxoutLn(x){       
                if (x.style) x.style.cssText = "" ;
                x.style.color ='blue' ;
                x.style.width ='50px';
           }
           function  xfocusTextboxoutQty(x){       
                if (x.style) x.style.cssText = "" ;
                x.style.color ='blue' ;
                x.style.width ='100px';
           }
           function popWinSearch(llInp){	
                win = window.open('ClentAll.aspx','s1','status=yes,resizable=no,width=580,height=340;');
                win.moveTo(screen.availWidth/2-175,screen.availHeight/2-100);			
                return false;		
           }		
//           function popWinSearchKey(llInp){
//                win = window.open('SearchCustomer.aspx?Optionc=2','s2','status=yes,resizable=no,width=520,height=550;');			
//                win.moveTo(screen.availWidth/2-175,screen.availHeight/2-100);
//                return false;
//                //scrollbars=yes		
//           }
//           function hideBtnSave(){
//             var  BUTTONSAVE = document.getElementById('ctl00$phMain$btnSave')
//             if (!(BUTTONSAVE == null))
//                {
//                  document.getElementById('ctl00$phMain$btnSave').style.display ='none'
//                }
//           }	
           function clear_textbox(){
                document.getElementById("txbContactOwner").value ="";
           }
           
           function ResetValue()
           {
           //
	       // New Business //
             document.getElementById("txbContactOwner").value ="";
             document.getElementById("txbInception").value ="";
             document.getElementById("txbExpiry").value ="";
             document.getElementById("txbAgent").value ="";
             document.getElementById("txbAgentCommissionType").value ="";
             document.getElementById("txbStaff").value ="";
             document.getElementById("txbPayPlan").value ="";
             //
	         // New Business Create //
             document.getElementById("txbMakeCode").value ="";
             document.getElementById("txbMakeDesc").value ="";
	         document.getElementById("txbVehCls").value ="";
	         document.getElementById("txbCover").value ="";
	         document.getElementById("txbEngine").value ="";
	         document.getElementById("txbChassis").value ="";
        	 
	         document.getElementById("txbSeats").value ="";
	         document.getElementById("txbRegNo").value ="";
	         document.getElementById("txbYrManuf_RegYear").value ="";
	         document.getElementById("txbBody").value ="";
	         document.getElementById("txbDP").value ="";
	         document.getElementById("txbCC").value ="";

	         //
 	         // Thai Motor Details //
	         document.getElementById("txbProvince").value ="";
	         document.getElementById("txbSpecEqpt").value ="";
	         document.getElementById("txbCode").value ="";
	         document.getElementById("txbCodeDesc").value ="";
	         document.getElementById("txbPrmCls").value ="";
	         document.getElementById("txbFleetDisc").value ="";
	         document.getElementById("txbNCDDisc").value ="";
	         document.getElementById("txbLoadOnBadClm").value ="";
	         document.getElementById("txbOtherDisc").value ="";

	         document.getElementById("txbCoSi").value ="";
	         document.getElementById("txbClienExpRate").value ="";
	 

	         //document.getElementById("").value ="";
	         //document.getElementById("").value ="";
	 
      }
      function xPopup() {alert('ไม่อนุญาติให้ทำการแก้ไข / Not allow to change value!');}
           