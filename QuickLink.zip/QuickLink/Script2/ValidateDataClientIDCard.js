﻿//-----------------------------------------------------------------------------------
//-----------------Trim ตัดช่องว่างข้างหน้า และตัดช่องว่างข้างหลัง -----------------------------
//-----------------------------------------------------------------------------------
function LTrim(str){
    if (str==null){
        return null;
    }
    for(i=0;str.charAt(i)==" ";i++);
    return str.substring(i,str.length);
}
function RTrim(str){
    if (str==null){
        return null;
    }
    for(i=str.length-1;str.charAt(i)==" ";i--);
    return str.substring(0,i+1);
}
function Trim(str){
    return LTrim(RTrim(str));
}

function isdigit(txt){
        //0-9
        if(txt < 48 || txt >57){
            return false;
        }
    return true;
}
function isEng(txt){
    // A-Z,a-z
    if(txt < 65 || txt > 122){
        return false;
    }
    return true;
}
function isThai(txt){
    // 3585 - 3630  3631 - 3659
    //   ก    -  ฮ            ฯ     -  ๋
    if(txt >3585 && txt <  3659){
        return true;
    }
    return false;
}
//---------------------------------------------------------------------
//              ตรวจสอบความถูกต้องของบัตรประชาชน
//---------------------------------------------------------------------
function CheckID1(txt,msg,btn){
document.getElementById(txt).value = Trim(document.getElementById(txt).value);
   if(document.getElementById(txt).value.length < 13){
           //document.getElementById(btn).disabled =true;
           if(document.getElementById(txt).value.length == 0){
                    document.getElementById(msg).innerText = "";
            }
            else{
                    document.getElementById(msg).innerText = " \nคุณระบุรูปแบบหมายเลขบัตรประชาชน ไม่ถูกต้อง! ความยาวต้องเท่ากับ 13 หลัก!";
            }
            return false;
    }
    if(document.getElementById(txt).value == "9999999999999"){
        document.getElementById(msg).innerText = "";
        return true;
    }
    for(i=0;i<document.getElementById(txt).value.length;i++){
            if( !isdigit(document.getElementById(txt).value.charCodeAt(i))){
                document.getElementById(msg).innerText = "\nคุณระบุรูปแบบหมายเลขบัตรประชาชน ไม่ถูกต้อง!";
                //document.getElementById(btn).disabled =true;
                return false;
            } 
     }
     var sum =0;
     //ตรวจสอบว่า เป็นเลขบัตรประชาชนที่ถูกต้องจริงหรือไม่ ตรวจสอบเลขตัวเลขว่าอยู่ในช่วง 1-8 หรือไม่
     if(document.getElementById(txt).value.charAt(0) < 1 
        || document.getElementById(txt).value.charAt(0) > 8){
            document.getElementById(msg).innerText = "\nคุณระบุรูปแบบหมายเลขบัตรประชาชน ไม่ถูกต้อง!";
        return false
     }
     for(i=0; i < 12; i++){
        sum += document.getElementById(txt).value.charAt(i)*(13-i);
     }
     sum = (11 - (sum%11))%10;
     if( sum == document.getElementById(txt).value.charAt(12)){
        //document.getElementById(btn).disabled = false;
        document.getElementById(msg).innerText = "";
        return true;
     }else{
        document.getElementById(msg).innerText = "\nคุณระบุรูปแบบหมายเลขบัตรประชาชน ไม่ถูกต้อง!";
        return false
        //document.getElementById(btn).disabled =true;
     }
}
//-----------------------------------------------------------------------------
//                  ตรวจสอบความถูกต้องของ หมายเลขบัตรประชาชนของ Client
//-----------------------------------------------------------------------------
function CheckIDClient(Nation,textID,msgError,btnCheck){
var Nationality = document.getElementById(Nation);
var IDNumber = document.getElementById(textID);
var MsgError = document.getElementById(msgError);
var Button = document.getElementById(btnCheck);
   if(Nationality.value == "TH" || Nationality.value == "THA"){
            if(IDNumber.value.length > 13){
                IDNumber.value = IDNumber.value.substr(0,13);
            }
            IDNumber.setAttribute('maxLength',13);
            if(CheckID1(textID,msgError,btnCheck) == true){
                //Button.disabled = false;
                MsgError.innerText = "";
                return true;
            }else{
                //IDNumber.focus();
                //Button.disabled =true;
                //MsgError.innerText = "\nหมายเลขบัตรประชาชนไม่ถูกต้อง";
                return false;
            }
    }else{
        //Button.disabled =false;
        MsgError.innerText = "";
        IDNumber.setAttribute('maxLength',20);
        return true;
    }
}
