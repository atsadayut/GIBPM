﻿
function xfocus(x){
    x.style.color ='#00cc00';x.style.backgroundColor='#FFE0C0';
}
function xleave(x,y){
        if(y % 2 !=0)
        {
            x.style.color ='#333333';x.style.backgroundColor='#FFFFFF';
        }
        else
        {
            x.style.color ='#333333';x.style.backgroundColor='#EFF3FB';
        }
}

function xclick(t, c1, c3, c2, c4, c5, c6, c7, c8, c9, btn) {	
         if(btn=="btnMotor")
         {
             window.opener.parent.document.getElementById("ctl00_MainContent_txbMakeCode").value = c1;
             window.opener.parent.document.getElementById("ctl00_MainContent_txbRegYear").value = c2;
             window.opener.parent.document.getElementById("ctl00_MainContent_txbHdMake").value = c3;
             window.opener.parent.document.getElementById("ctl00_MainContent_lbMakeDesc").innerText = c4;
             window.opener.parent.document.getElementById("ctl00_MainContent_txbHdMakeDesc").value = c4;


             window.opener.parent.document.getElementById("ctl00_MainContent_txbHdMotorBody_C1").value = c5;
             window.opener.parent.document.getElementById("ctl00_MainContent_txbHdMotorSeat_C1").value = c6;
             window.opener.parent.document.getElementById("ctl00_MainContent_txbHdMotorPD_C1").value = c7;
             window.opener.parent.document.getElementById("ctl00_MainContent_txbHdMotorCC_C1").value = c8;
             window.opener.parent.document.getElementById("ctl00_MainContent_txbHdMotorTong_C1").value = c9;

             window.opener.parent.document.getElementById("ctl00_MainContent_txbVehicleKey").value = c9;

             //Clear year
             //window.opener.parent.document.getElementById("ctl00_MainContent_txbRegYear").innerText="";
             //window.opener.parent.document.getElementById("ctl00_MainContent_txbMakeCode").focus();

             window.opener.parent.document.getElementById('ctl00_MainContent_chkCompreh').checked = false;
             window.opener.parent.document.getElementById('ctl00_MainContent_chkClass1BML').checked = false;
             window.opener.parent.document.getElementById('ctl00_MainContent_txbSumInsure').disabled = true;
             if (window.opener.parent.document.getElementById('ctl00_MainContent_txbISBML').value == "1" && window.opener.parent.document.getElementById('ctl00_MainContent_txbHdMake').value == "BMW") {

                 window.opener.parent.document.getElementById('nonBML').style.display = "none";
                 window.opener.parent.document.getElementById('isBML').style.display = "block";
                 
             }
             else {

                 window.opener.parent.document.getElementById('nonBML').style.display = "block";
                 window.opener.parent.document.getElementById('isBML').style.display = "none";
                 
             }


             window.opener.parent.document.getElementById("ctl00_MainContent_txbRegYear").focus();

     
             window.close();
             
         }
         else if(btn=="btnMotor_C2")
         {
//             window.opener.parent.document.getElementById("ctl00_MainContent_txbMakeCode_C2").value=c1;
//             window.opener.parent.document.getElementById("ctl00_MainContent_lbMakeDesc_C2").innerText=c3;
//             
//             window.opener.parent.document.getElementById("ctl00_MainContent_hdMotorBody_C2").innerText=c4;
//             window.opener.parent.document.getElementById("ctl00_MainContent_hdMotorSeat_C2").innerText=c5;
//             window.opener.parent.document.getElementById("ctl00_MainContent_hdMotorPD_C2").innerText=c6;
//             window.opener.parent.document.getElementById("ctl00_MainContent_hdMotorCC_C2").innerText=c7;
//             
//             window.opener.parent.document.getElementById("ctl00_MainContent_txbMakeCode_C2").focus();
//             window.opener.parent.document.getElementById("ctl00_MainContent_txbRegYear_C2").focus();
//             window.close();
         }
         else if(btn=="btnMotor_C3")
         {
//             window.opener.parent.document.getElementById("ctl00_MainContent_txbMakeCode_C3").value=c1;
//             window.opener.parent.document.getElementById("ctl00_MainContent_lbMakeDesc_C3").innerText=c3;
//             window.opener.parent.document.getElementById("ctl00_MainContent_hdMotorBody_C3").innerText=c4;
//             window.opener.parent.document.getElementById("ctl00_MainContent_hdMotorSeat_C3").innerText=c5;
//             window.opener.parent.document.getElementById("ctl00_MainContent_hdMotorPD_C3").innerText=c6;
//             window.opener.parent.document.getElementById("ctl00_MainContent_hdMotorCC_C3").innerText=c7;
//             
//             window.opener.parent.document.getElementById("ctl00_MainContent_txbMakeCode_C3").focus();
//             window.opener.parent.document.getElementById("ctl00_MainContent_txbEngine_C3").focus();
//             window.close();
         }
         else if (btn == "btnAXACode") 
         {
             window.opener.parent.document.getElementById("txbAXACode").value = c1;
             window.close();
         }
         else if (btn == "btnAXACodeEdit") {
             window.opener.parent.document.getElementById("ctl00_MainContent_txbAXACode").value = c1;
             window.close();
         }
         else
         {
            alert("error");
         }       
}


function xClickNameDriver(btn) {

         var cCode = document.getElementById("txbClientNo").value;
         var cfullname = document.getElementById("txbFullname").value;
         var cLicenseDriver = document.getElementById("txbLicenseDriver").value;
         var cDOB = document.getElementById("txbDOB").value;
         //var btn = document.getElementById(btn1).innerText;
         //alert(cCode + cfullname + cLicenseDriver+cDOB);        
         if(btn=="btnNewClient_L1C1")
         {
            //SHOW
             window.opener.parent.document.getElementById("ctl00_MainContent_lbND_ClientNo_L1C1").value = cCode;
             window.opener.parent.document.getElementById("ctl00_MainContent_lbND_Name_L1C1").value = cfullname;
             window.opener.parent.document.getElementById("ctl00_MainContent_lbND_LicenseDriver_L1C1").value = cLicenseDriver;
             window.opener.parent.document.getElementById("ctl00_MainContent_lbND_DOB_L1C1").value = cDOB
            
            //HIDE
            window.opener.parent.document.getElementById("ctl00_MainContent_txbND_ClientNo_L1C1").value=cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_txbND_Name_L1C1").value = cfullname;
            window.opener.parent.document.getElementById("ctl00_MainContent_txbND_LicenseDriver_L1C1").value = cLicenseDriver;
            window.opener.parent.document.getElementById("ctl00_MainContent_txbND_DOB_L1C1").value = cDOB;
            
            
            window.close();
         }
         else if(btn=="btnNewClient_L2C1")
         {

             window.opener.parent.document.getElementById("ctl00_MainContent_lbND_ClientNo_L2C1").value = cCode;
             window.opener.parent.document.getElementById("ctl00_MainContent_lbND_Name_L2C1").value = cfullname;
             window.opener.parent.document.getElementById("ctl00_MainContent_lbND_LicenseDriver_L2C1").value = cLicenseDriver;
             window.opener.parent.document.getElementById("ctl00_MainContent_lbND_DOB_L2C1").value = cDOB;
            
            //HIDE
            window.opener.parent.document.getElementById("ctl00_MainContent_txbND_ClientNo_L2C1").value = cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_txbND_Name_L2C1").value = cfullname;
            window.opener.parent.document.getElementById("ctl00_MainContent_txbND_LicenseDriver_L2C1").value = cLicenseDriver;
            window.opener.parent.document.getElementById("ctl00_MainContent_txbND_DOB_L2C1").value = cDOB;
            
            window.close();
         }
         else if(btn=="btnNewClient_L1C2")
         {
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_ClientNo_L1C2").innerText=cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_Name_L1C2").innerText=cfullname;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_LicenseDriver_L1C2").innerText=cLicenseDriver;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_DOB_L1C2").innerText=cDOB;
            window.close();
         }
         else if(btn=="btnNewClient_L2C2")
         {
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_ClientNo_L2C2").innerText=cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_Name_L2C2").innerText=cfullname;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_LicenseDriver_L2C2").innerText=cLicenseDriver;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_DOB_L2C2").innerText=cDOB;
            window.close();
         }
         else if(btn=="btnNewClient_L1C3")
         {
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_ClientNo_L1C3").innerText=cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_Name_L1C3").innerText=cfullname;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_LicenseDriver_L1C3").innerText=cLicenseDriver;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_DOB_L1C3").innerText=cDOB;
            window.close();
         }
         else if(btn=="btnNewClient_L2C3")
         {
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_ClientNo_L2C3").innerText=cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_Name_L2C3").innerText=cfullname;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_LicenseDriver_L2C3").innerText=cLicenseDriver;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_DOB_L2C3").innerText=cDOB;
            
            window.close();
         }
         else
         {
            alert("error");
         }       
}
function xClickNameDriverSearch(cCode,cfullname,cDOB,cLicenseDriver,btn) {
         //var btn = document.getElementById(btn1).innerText;
         //alert(cCode + cfullname + cLicenseDriver+cDOB);        
         if(btn=="btnSearchClient_L1C1")
         {
            
	    if(cLicenseDriver=="&nbsp;")
            {
                alert("ไม่สามารถใช้ client นี้ได้เนื่องจากไม่มีหมายเลขใบขับขี่ โปรดติดต่อทาง AXA หากต้องการแก้ไขข้อมูล!");
                return;
                //window.opener.parent.document.getElementById("ctl00_MainContent_lbND_LicenseDriver_L1C1").innerText="";
                //window.opener.parent.document.getElementById("ctl00_MainContent_txbND_LicenseDriver_L1C1").innerText="";
            }
            else
            {
		//SHOW
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_ClientNo_L1C1").value=cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_Name_L1C1").value = cfullname;
            //HIDE
            window.opener.parent.document.getElementById("ctl00_MainContent_txbND_ClientNo_L1C1").value = cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_txbND_Name_L1C1").value = cfullname;

            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_LicenseDriver_L1C1").value = cLicenseDriver;
                window.opener.parent.document.getElementById("ctl00_MainContent_txbND_LicenseDriver_L1C1").value = cLicenseDriver;
            }
            if(cDOB=="&nbsp;")
            {
                alert("ไม่สามารถใช้ client นี้ได้เนื่องจากไม่มีวันเดือนปีเกิด โปรดติดต่อทาง AXA หากต้องการแก้ไขข้อมูล!");
                return;
            }
            else
            {
		//SHOW
                window.opener.parent.document.getElementById("ctl00_MainContent_lbND_ClientNo_L1C1").value = cCode;
                window.opener.parent.document.getElementById("ctl00_MainContent_lbND_Name_L1C1").value = cfullname;
            //HIDE
            window.opener.parent.document.getElementById("ctl00_MainContent_txbND_ClientNo_L1C1").value = cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_txbND_Name_L1C1").value = cfullname;

            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_DOB_L1C1").value = cDOB;
                window.opener.parent.document.getElementById("ctl00_MainContent_txbND_DOB_L1C1").value = cDOB;
            }
            

             
            
            window.close();
         }
         else if(btn=="btnSearchClient_L2C1")
         {
            

            if(cLicenseDriver=="&nbsp;")
            {
                alert("ไม่สามารถใช้ client นี้ได้เนื่องจากไม่มีหมายเลขใบขับขี่ โปรดติดต่อทาง AXA หากต้องการแก้ไขข้อมูล!");
                return;
                //window.opener.parent.document.getElementById("ctl00_MainContent_lbND_LicenseDriver_L2C1").innerText="";
                //window.opener.parent.document.getElementById("ctl00_MainContent_txbND_LicenseDriver_L2C1").innerText="";
            }
            else
            {
		//SHOW
                window.opener.parent.document.getElementById("ctl00_MainContent_lbND_ClientNo_L2C1").value = cCode;
                window.opener.parent.document.getElementById("ctl00_MainContent_lbND_Name_L2C1").value = cfullname;
            //HIDE
            window.opener.parent.document.getElementById("ctl00_MainContent_txbND_ClientNo_L2C1").value = cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_txbND_Name_L2C1").value = cfullname;

            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_LicenseDriver_L2C1").value = cLicenseDriver;
                window.opener.parent.document.getElementById("ctl00_MainContent_txbND_LicenseDriver_L2C1").value = cLicenseDriver;
            }
            if(cDOB=="&nbsp;")
            {
                alert("ไม่สามารถใช้ client นี้ได้เนื่องจากไม่มีวันเดือนปีเกิด โปรดติดต่อทาง AXA หากต้องการแก้ไขข้อมูล!");
                return;
                //window.opener.parent.document.getElementById("ctl00_MainContent_lbND_DOB_L2C1").innerText="";
            }
            else
            {
		//SHOW
                window.opener.parent.document.getElementById("ctl00_MainContent_lbND_ClientNo_L2C1").value = cCode;
                window.opener.parent.document.getElementById("ctl00_MainContent_lbND_Name_L2C1").value = cfullname;
            //HIDE
            window.opener.parent.document.getElementById("ctl00_MainContent_txbND_ClientNo_L2C1").value = cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_txbND_Name_L2C1").value = cfullname;

            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_DOB_L2C1").value = cDOB;
                window.opener.parent.document.getElementById("ctl00_MainContent_txbND_DOB_L2C1").value = cDOB;
            }

            
            
            window.close();
         }
         else if(btn=="btnSearchClient_L1C2")
         {
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_ClientNo_L1C2").innerText=cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_Name_L1C2").innerText=cfullname;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_LicenseDriver_L1C2").innerText=cLicenseDriver;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_DOB_L1C2").innerText=cDOB;
            window.close();
         }
         else if(btn=="btnSearchClient_L2C2")
         {
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_ClientNo_L2C2").innerText=cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_Name_L2C2").innerText=cfullname;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_LicenseDriver_L2C2").innerText=cLicenseDriver;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_DOB_L2C2").innerText=cDOB;
            window.close();
         }
         else if(btn=="btnSearchClient_L1C3")
         {
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_ClientNo_L1C3").innerText=cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_Name_L1C3").innerText=cfullname;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_LicenseDriver_L1C3").innerText=cLicenseDriver;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_DOB_L1C3").innerText=cDOB;
            window.close();
         }
         else if(btn=="btnSearchClient_L2C3")
         {
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_ClientNo_L2C3").innerText=cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_Name_L2C3").innerText=cfullname;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_LicenseDriver_L2C3").innerText=cLicenseDriver;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_DOB_L2C3").innerText=cDOB;
            window.close();
         }
         else
         {
            alert("error");
         }       
}
function xClickClientSplitSearch(cCode,cfullname,cDOBb,btn) {
         //var btn = document.getElementById(btn1).innerText;
         //alert(cCode + cfullname + cLicenseDriver+cDOB);        
         if(btn=="btnVolunBrowse_1")
         {
            //LABEL 
            window.opener.parent.document.getElementById("ctl00_MainContent_lbVolunClientCode_1").innerText=cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbVolunName_1").innerText=cfullname;
            //TEXTBOX
            window.opener.parent.document.getElementById("ctl00_MainContent_txbVolunClientCode_1").value = cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_txbVolunName_1").value = cfullname;
//            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_LicenseDriver_L1C1").innerText=cLicenseDriver;
//            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_DOB_L1C1").innerText=cDOB;
            window.close();
            
            
         }
         else if(btn=="btnVolunBrowse_2")
         {
            //LABEL
            window.opener.parent.document.getElementById("ctl00_MainContent_lbVolunClientCode_2").innerText=cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbVolunName_2").innerText=cfullname;
            
            //TEXTBOX
            window.opener.parent.document.getElementById("ctl00_MainContent_txbVolunClientCode_2").value = cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_txbVolunName_2").value = cfullname;
//            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_LicenseDriver_L2C1").innerText=cLicenseDriver;
//            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_DOB_L2C1").innerText=cDOB;
            window.close();
         }
         else if(btn=="btnCompBrowse_1")
         {
            //COMPULSARY
            //LABEL 
            window.opener.parent.document.getElementById("ctl00_MainContent_lbCompClientCode_1").innerText=cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbCompName_1").innerText=cfullname;
            
            //TEXTBOX
            window.opener.parent.document.getElementById("ctl00_MainContent_txbCompClientCode_1").value = cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_txbCompName_1").value = cfullname;
//            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_LicenseDriver_L2C1").innerText=cLicenseDriver;
//            window.opener.parent.document.getElementById("ctl00_MainContent_lbND_DOB_L2C1").innerText=cDOB;
            window.close();
         }
         else if(btn=="btnBothVolunBrowse_1")
         {
            //BOTH
            //LABEL 
            window.opener.parent.document.getElementById("ctl00_MainContent_lbBothVolunClientCode_1").innerText=cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbBothVolunName_1").innerText=cfullname;
            
            //TEXTBOX
            window.opener.parent.document.getElementById("ctl00_MainContent_txbBothVolunClientCode_1").value = cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_txbBothVolunName_1").value = cfullname;
            //window.opener.parent.document.getElementById("ctl00_MainContent_lbND_LicenseDriver_L2C1").innerText=cLicenseDriver;
            //window.opener.parent.document.getElementById("ctl00_MainContent_lbND_DOB_L2C1").innerText=cDOB;
            window.close();
         }
         else if(btn=="btnBothVolunBrowse_2")
         {
            //BOTH
            //LABEL 
            window.opener.parent.document.getElementById("ctl00_MainContent_lbBothVolunClientCode_2").innerText=cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbBothVolunName_2").innerText=cfullname;
            
            //TEXTBOX
            window.opener.parent.document.getElementById("ctl00_MainContent_txbBothVolunClientCode_2").value = cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_txbBothVolunName_2").value = cfullname;
            //window.opener.parent.document.getElementById("ctl00_MainContent_lbND_LicenseDriver_L2C1").innerText=cLicenseDriver;
            //window.opener.parent.document.getElementById("ctl00_MainContent_lbND_DOB_L2C1").innerText=cDOB;
            window.close();
         }
         else if(btn=="btnBothCompBrowse_1")
         {
            //BOTH
            //LABEL 
            window.opener.parent.document.getElementById("ctl00_MainContent_lbBothCompClientCode_1").innerText=cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_lbBothCompName_1").innerText=cfullname;
            
            //TEXTBOX
            window.opener.parent.document.getElementById("ctl00_MainContent_txbBothCompClientCode_1").value = cCode;
            window.opener.parent.document.getElementById("ctl00_MainContent_txbBothCompName_1").value = cfullname;
            //window.opener.parent.document.getElementById("ctl00_MainContent_lbND_LicenseDriver_L2C1").innerText=cLicenseDriver;
            //window.opener.parent.document.getElementById("ctl00_MainContent_lbND_DOB_L2C1").innerText=cDOB;
            window.close();
         }
         else
         {
            alert("error");
         }       
}
function OpenMotorDetail(sField,sField1) {
         var vFieldName = sField;
         var vFieldName1 = sField1;         
         var win = window.open("../Enquiry/PolicyMotorDetails.aspx?CHDRNUM=" + vFieldName + "&MAKECODE=" + vFieldName1, "MotorDetail", "left=200,top=50,width=800,height=500,status=no,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=yes");
         win.focus();
     }

 function OpenMotorDetail1(sField, sField1) {
         var vFieldName = sField;
         var vFieldName1 = sField1;
         var win = window.open("../Enquiry/EnquiryMotorDetails.aspx?PN=" + vFieldName + "&LIST=" + vFieldName1, "MotorDetail", "left=200,top=50,width=800,height=500,status=no,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=yes");
         win.focus();
     }

 function OpenClaimDetail(sField, sField1) {
         var vFieldName = sField;
         var vFieldName1 = sField1;
         var win = window.open("../Enquiry/EnquiryClaimDetail.aspx?PN=" + vFieldName + "&LIST=" + vFieldName1, "MotorDetail", "left=200,top=50,width=800,height=500,status=no,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=yes");
         win.focus();
     }




