using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Data.Common;
using Microsoft.VisualBasic;

public partial class Report_listPrint : System.Web.UI.Page
{
    string volunpolicy = "";
    string complpolicy = "";

    string tmpPolicyNo = "";
    string brokercode = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        //this.GridViewDocument.RowDataBound += new GridViewRowEventHandler(GridViewDocument_RowDataBound);
        DefaultPageRegisterClientScript();
        DropDownList cmdBrokerInGroup = (DropDownList)this.Page.Master.FindControl("cmdBrokerInGroup");
        cmdBrokerInGroup.Enabled = false;

        //Boolean result = false;
        lbMsgPrint.Visible = false;
        GridViewDocument.Visible = true;

        //string brokercode = "BR301";
        brokercode = Utilities.BrokerCode();
        if (brokercode == "")
        {
            ShowMessage("�������ö����¡���� ���ͧ�ҡ�ѧ������������к�");
            GridViewDocument.Visible = false;
        }
        else
        {
            try
            {
                volunpolicy = Request.QueryString["volun"].ToString().Trim();
                complpolicy = Request.QueryString["compl"].ToString().Trim();

                tmpPolicyNo = volunpolicy;


                if (volunpolicy.Equals("") && complpolicy.Equals(""))
                {
                    ShowMessage("�������ö����¡���� ���ͧ�ҡ����բ����š��������� !");
                   
                    GridViewDocument.Visible = false;
                    return;
                }
                if (volunpolicy.Equals(""))
                {
                    tmpPolicyNo = complpolicy;
                    //lbPolicyText.Text = "�Ҥ�ѧ�Ѻ : " + complpolicy;
                    lbPolicyReturnCompl.Text = "<center>" + complpolicy + "</center>";
                }
                else if (complpolicy.Equals(""))
                {
                    //lbPolicyText.Text = "�Ҥ��Ѥ�� : " + volunpolicy;
                    lbPolicyReturnVolun.Text = "<center>" + volunpolicy + "</center>";
                }
                else
                {
                    //lbPolicyText.Text = "�Ҥ�ѧ�Ѻ : " + complpolicy + " ����Ҥ��Ѥ�� : " + volunpolicy;
                    lbPolicyReturnCompl.Text = "<center>" + complpolicy + "</center>";
                    lbPolicyReturnVolun.Text = "<center>" + volunpolicy + "</center>";
                }

                //brokercode = "BR301";
                //result = PolicyReprint.chkPolicyAllowBroker(volunpolicy, complpolicy);
                //if (!result)
                //{
                //    ShowMessage("�������ö����¡���� ���ͧ�ҡ�����š����������١��ͧ !");
                    
                //    GridViewDocument.Visible = false;
                //    return;
                //}

            }
            catch (Exception ex)
            {
                lbMsgPrint.Text = "�������ö����¡���� ���ͧ�Դ��ͼԴ��Ҵ㹡�����¡������";
                lbMsgPrint.ForeColor = System.Drawing.Color.Black;
                lbMsgPrint.Font.Bold = true;

                GridViewDocument.Visible = false;
            }
        }
    }
    protected void GridViewDocument_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        string url = "";
        string policyno = "";
        string type = "";
        if (e.Row.RowIndex >= 0)
        {

            //CHECKREPORT 
            //11=��ѡ�ҹ��õ�ͷ���¹ 14=�����/㺡ӡѺ���� (�Ҥ�ѧ�Ѻ) 4 =�Ҥ�ѧ�Ѻ
            string tmpReportID = e.Row.Cells[6].Text.Trim();
            if (tmpReportID == "11" | tmpReportID == "14" | tmpReportID == "4")
            {
                tmpPolicyNo = complpolicy;
            }
            else
            {
                tmpPolicyNo = volunpolicy;
            }

            //e.Row.Cells[1].Text = "<input type='button' value = 'Print(" + e.Row.Cells[4].Text + ")' Style=\"width:100px;\" onClick = \"if (confirm('Are you sure you want to print?')==false) return;window.location = 'print.aspx?flag=FlagOriginal&amp;policy=" + Request.QueryString["volun"] + "&amp;report=" + e.Row.Cells[7].Text + "&amp;reportid=" + e.Row.Cells[6].Text + "&amp;volun=" + volunpolicy + "&amp;compl=" + complpolicy + "' \" >";

            //e.Row.Cells[1].Text = "<input type='button' value = 'Print(" + e.Row.Cells[4].Text + ")' Style=\"width:100px;\" onClick = \"if (confirm('Are you sure you want to print?')==false) return;FunctionUpdateLockPrint('FlagOriginal','" + e.Row.Cells[6].Text + "','" + volunpolicy + "','" + complpolicy + "'); window.location = '" + QuickLinkConfiguration.UrlReportingService + e.Row.Cells[7].Text + "&amp;rs:Format=PDF&amp;Policy=" + tmpPolicyNo + "' ;setTimeout('window.location.reload(true)'," + QuickLinkConfiguration.LimitPrintTimeOut.ToString() + ");\">";
            url = QuickLinkConfiguration.UrlReportingServiceNew + e.Row.Cells[7].Text + "&rs:Format=pdf&rs:command=render&Policy=" + tmpPolicyNo;
           
            policyno = tmpPolicyNo;
            type = tmpReportID;
            printMotorPolicy(url, policyno, type.ToString());
            e.Row.Cells[1].Text = "<input type='button' value = 'Print(" + e.Row.Cells[4].Text + ")' Style=\"width:100px;\" onClick = \"if (confirm('Are you sure you want to print?')==false) return;FunctionUpdateLockPrint('FlagOriginal','" + e.Row.Cells[6].Text + "','" + volunpolicy + "','" + complpolicy + "');window.location.reload(); window.open('" + @"../Report/MOTOR/" + policyno + @"/" + policyno + type + @".pdf','_blank' );" + "  \">";
            //"window.open( '" + @"/MOTOR/" + policyno + @"/" + policyno + type + @".pdf"  + "', null, 'height=400,width=800,status=yes,toolbar=no,menubar=no,location=no' );", true);
            //e.Row.Cells[2].Text = "<input type='button' value = 'Print(" + e.Row.Cells[5].Text + ")' Style=\"width:100px;\" onClick = \"if (confirm('Are you sure you want to print?')==false) return;FunctionUpdateLockPrint('FlagCopy','" + e.Row.Cells[6].Text + "','" + volunpolicy + "','" + complpolicy + "');window.location = 'http://10.16.8.4/ReportServer?%2fQuicklink%2f" + e.Row.Cells[8].Text + "&amp;rs:Format=PDF&amp;Policy=" + tmpPolicyNo + "';setTimeout('window.location.reload(true)',10000);\">";

            // e.Row.Cells[2].Text = "<input type='button' value = 'Print(" + e.Row.Cells[5].Text + ")' Style=\"width:100px;\" onClick = \"if (confirm('Are you sure you want to print?')==false) return;FunctionUpdateLockPrint('FlagCopy','" + e.Row.Cells[6].Text + "','" + volunpolicy + "','" + complpolicy + "');window.location = '" + QuickLinkConfiguration.UrlReportingService + e.Row.Cells[8].Text + "&amp;rs:Format=PDF&amp;Policy=" + tmpPolicyNo + "' ;setTimeout('window.location.reload(true)'," + QuickLinkConfiguration.LimitPrintTimeOut.ToString() + ");\">";
            url = QuickLinkConfiguration.UrlReportingServiceNew + e.Row.Cells[8].Text + "&rs:Format=pdf&rs:command=render&Policy=" + tmpPolicyNo;
            policyno = tmpPolicyNo;
            type = tmpReportID + "-2";
            printMotorPolicy(url, policyno, type.ToString());
            e.Row.Cells[2].Text = "<input type='button' value = 'Print(" + e.Row.Cells[5].Text + ")' Style=\"width:100px;\" onClick = \"if (confirm('Are you sure you want to print?')==false) return;FunctionUpdateLockPrint('FlagCopy','" + e.Row.Cells[6].Text + "','" + volunpolicy + "','" + complpolicy + "');window.location.reload(); window.open('" + @"../Report/MOTOR/" + policyno + @"/" + policyno + type + @".pdf','_blank' );" + "  \">";


            //e.Row.Cells[3].Text = "<input type='button' value = 'View' Style=\"width:100px;\" onClick = \"window.location = 'http://10.16.8.4/ReportServer?%2fQuicklink%2f" + e.Row.Cells[9].Text + "&amp;rs:Format=PDF&amp;Policy=" + Request.QueryString["volun"] + "'  \">";
            //e.Row.Cells[3].Text = "<input type='button' value = 'View' Style=\"width:100px;\" onClick = \"window.location = '" + QuickLinkConfiguration.UrlReportingService + e.Row.Cells[9].Text + "&amp;rs:Format=PDF&amp;Policy=" + tmpPolicyNo + "'  \">";
            //@"/MOTOR/DOC/" + policyno + @"/" +policyno +type+ @".pdf" + "', null, 'height=400,width=800,status=yes,toolbar=no,menubar=no,location=no' );
            url = QuickLinkConfiguration.UrlReportingServiceNew + e.Row.Cells[9].Text + "&rs:Format=pdf&rs:command=render&Policy=" + tmpPolicyNo;
            policyno = tmpPolicyNo;
            type = tmpReportID + "-3";
            printMotorPolicy(url, policyno, type.ToString());
            e.Row.Cells[3].Text = "<input type='button' value = 'View' Style=\"width:100px;\" onClick = \" window.open('" + @"../Report/MOTOR/" + policyno + @"/" + policyno + type + @".pdf','_blank' )" + "  \">";

            //window.open("webpage.htm", "_self"); 

            if (e.Row.Cells[4].Text == "0")
            {
                e.Row.Cells[1].Text = "<input type='button' disabled value = 'Print(" + e.Row.Cells[4].Text + ")' Style=\"width:100px;\">";
            }

            if (e.Row.Cells[5].Text == "0")
            {
                e.Row.Cells[2].Text = "<input type='button' disabled value = 'Print(" + e.Row.Cells[5].Text + ")' Style=\"width:100px;\">";
            }
        }
        // hidden Colums
        e.Row.Cells[4].Visible = false;
        e.Row.Cells[5].Visible = false;
        e.Row.Cells[6].Visible = false;
        e.Row.Cells[7].Visible = false; //ORIG
        e.Row.Cells[8].Visible = false; //COPY
        e.Row.Cells[9].Visible = false; //VIEW
    }
    private void ShowMessage(string msg)
    {
        lbMsgPrint.Visible = true;
        lbMsgPrint.Text = msg;
        lbMsgPrint.ForeColor = System.Drawing.Color.White;
        lbMsgPrint.BackColor = System.Drawing.Color.Red;
        lbMsgPrint.Font.Bold = true;
    }


    public void printMotorPolicy(string url, string policyno, string type)
    {
        string Command = "Render";
        string Format = "PDF";

        System.Net.NetworkCredential Credentials = new System.Net.NetworkCredential();
        Credentials.UserName = "quicklink";
        Credentials.Password = "Password1";
        Credentials.Domain = "bkk.dom";
        //We can get values of these parameters from Request object.

        string URL = url; 


        // URL = URL + "&rs:Command=" + Command + "&rs:Format=" + Format + "&Policy=" + Policy + "&PolicyTo=" + PolicyTo + "&IssueDateFrom=" + IssueDateFrom + "&IssueDateTo=" + IssueDateTo + "&BrokerCode=" + BrokerCode;


        //Specify the path for saving.
        System.IO.DirectoryInfo di = new DirectoryInfo(@"C:\Inetpub\wwwroot\QuickLink\Report\MOTOR\" + policyno);
        if (!di.Exists)
        {
            System.IO.Directory.CreateDirectory(@"C:\Inetpub\wwwroot\QuickLink\Report\MOTOR\" + policyno);
        }

        string path = @"C:\Inetpub\wwwroot\QuickLink\Report\MOTOR\" + policyno + @"\" + policyno + type + @".pdf";

        if (!File.Exists(path))
            {
                // File.Delete(path);
            }

            System.Net.HttpWebRequest Req = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(URL);
            Req.Credentials = Credentials; // System.Net.CredentialCache.DefaultCredentials;
            Req.ContentType = " text/html";


            Req.Method = "GET";


            System.Net.HttpWebResponse objResponse = (System.Net.HttpWebResponse)Req.GetResponse();

            System.IO.FileStream fs = new System.IO.FileStream(path, System.IO.FileMode.Create);

            System.IO.Stream stream = objResponse.GetResponseStream();

            byte[] buf = new byte[1024];

            int len = stream.Read(buf, 0, 1024);

            while (len > 0)
            {

                fs.Write(buf, 0, len);

                len = stream.Read(buf, 0, 1024);

            }

            stream.Close();

            fs.Close();
        
    }

    protected void DefaultPageRegisterClientScript()
    {
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptScrolling", "MenuScroll();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptTxtFocus", "setFocusTextbox();", true);
        //ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDrawCorner", "DrawDivCorner();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDisplayMsg", "DisplayWarning();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDatePicker", "<script type='text/javascript' language='javascript'>  $(document).ready(function () {  $('.MOTOR').find('img').attr('src', '../Images/Index/MOTOR1.png');  $('.MOTOR').find('a').css('color', '#922d3d'); $('.MOTOR').hover( function () { $(this).find('img').attr('src', '../Images/Index/MOTOR1.png'); } , function () { $(this).find('img').attr('src', '../Images/Index/MOTOR1.png'); } );addSubMenu('hdnMotor', '.subNavigate', '���ҧ��������', '');Accordion('.wizard', 'hdnCriteriaStep');});</script>", false);
    }
}

  