﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.IO;
using System.Text.RegularExpressions;
using System.Text;
using System.Web.UI.HtmlControls;
public partial class Report_SummaryReport : System.Web.UI.Page
{
    DataTable dt;
    DataView dv;
  
    protected void Page_Load(object sender, EventArgs e)
    {
        this.btnSearch.ServerClick +=new EventHandler(btnSearch_ServerClick);
        this.btnImgExcel1.Click += new ImageClickEventHandler(btnImgExcel1_Click);
        this.btnImgExcel2.Click +=new ImageClickEventHandler(btnImgExcel2_Click);    

        if (!IsPostBack)
        {
            //SHOW HIDE RESULT SEARCH
            divResultSearch.Style["display"] = "none";
            this.txbGroupBroker.Text = System.Web.HttpContext.Current.Session["GroupBrokerID"].ToString(); 
        }
    }
    //
    private void btnSearch_ServerClick(object sender, EventArgs e)
    {   //SHOW HIDE RESULT SEARCH
        divResultSearch.Style["display"] = "block";

        //CLEAR MESSAGE
        this.lbMessageHead.Text = "";

        //CLEAR DATA IN GRID VIEW
        ClearDataInGridSummaryReport();
        ClearDataInGridSummaryReportDetail();



        string strTransDateFrom = txbTransDateFrom.CalendarDateString.ToString();//.Substring(7, 4);// + "-" + txbIssuedDateFrom.CalendarDateString.ToString().Substring(4, 2) + "-" + txbIssuedDateFrom.CalendarDateString.ToString().Substring(1, 2);
        string strTransDateTo = txbTransDateTo.CalendarDateString.ToString();//.Substring(7, 4); //+ "-" + txbIssuedDateTo.CalendarDateString.ToString().Substring(4, 2) + "-" + txbIssuedDateTo.CalendarDateString.ToString().Substring(1, 2);
        if (strTransDateFrom.Length > 0 && strTransDateTo.Length > 0)
        {
            strTransDateFrom = strTransDateFrom.Substring(6, 4) + strTransDateFrom.Substring(3, 2) +  strTransDateFrom.Substring(0, 2);
            strTransDateTo = strTransDateTo.Substring(6, 4) +  strTransDateTo.Substring(3, 2) + strTransDateTo.Substring(0, 2);
        }
        //return;
        string GroupBroker = txbGroupBroker.Text.Trim();
        string PolicyType = "";
        string ContractType = cmbContractType.SelectedValue.Equals("โปรดเลือก") ? "" : cmbContractType.SelectedValue;
        string EffDateFrom = "";
        string EffDateTo = "";
        string TransDateFrom = strTransDateFrom;
        string TransDateTo = strTransDateTo;
        string BizType = cmbBizType.SelectedValue.Equals("โปรดเลือก") ? "" : cmbBizType.SelectedValue;
        string ReportType = cmbReportType.SelectedValue.Equals("โปรดเลือก") ? "" : cmbReportType.SelectedValue;
        //PART SUMMARY REPORT
        try
        {
            dt = new DataTable();
            dt = ReportsSummary.GetSummaryReport(GroupBroker, PolicyType, ContractType, EffDateFrom, EffDateTo, TransDateFrom, TransDateTo, BizType, ReportType);
            if (dt.Rows.Count > 0)
            {
                dv = dt.DefaultView;
                Session["SummaryReportData"] = dv;
                gvSummaryReport.PageIndex = 0;
                BindDataToGridSummaryReport();
                btnImgExcel1.Visible = true;
            }
            else
            {
                ClearDataInGridSummaryReport();
                btnImgExcel1.Visible = false;
            }
        }
        catch (Exception ex)
        {
            this.lbMessageHead.Text = "เกิดข้อผิดพลาดในการดึงข้อมูลส่วน Summary Report ของโปรแกรม!." + ex.Message.ToString().Trim();
            this.lbMessageHead.ForeColor = System.Drawing.Color.Red;
            this.lbMessageHead.Font.Bold = true;
            ClearDataInGridSummaryReport();
            return;
        }

        //PART SUMMARY REPORT DETAILS
        try
        {
            dt = new DataTable();
            dt = ReportsSummary.GetSummaryReportDetails(GroupBroker, PolicyType, ContractType, EffDateFrom, EffDateTo, TransDateFrom, TransDateTo, BizType, ReportType);
            if (dt.Rows.Count > 0)
            {
                dv = dt.DefaultView;
                Session["SummaryReportDetailData"] = dv;
                gvSummaryReportDetails.PageIndex = 0;
                BindDataToGridSummaryReportDetail();
                btnImgExcel2.Visible = true;
            }
            else
            {
                ClearDataInGridSummaryReportDetail();
                btnImgExcel1.Visible = false;
            }
        }
        catch (Exception ex)
        {
            this.lbMessageHead.Text = "เกิดข้อผิดพลาดในการดึงข้อมูลส่วน Summary Report Details ของโปรแกรม!." + ex.Message.ToString().Trim();
            this.lbMessageHead.ForeColor = System.Drawing.Color.Red;
            this.lbMessageHead.Font.Bold = true;
            ClearDataInGridSummaryReportDetail();
            return;
        }




    }
    //
    private void btnImgExcel1_Click(object sender, EventArgs e)
    {
        try
        {
            DataTable dataTable = new DataTable();
            dv = (DataView)Session["SummaryReportData"];

            dataTable = dv.ToTable();
            if (dataTable.Rows.Count > 0)
            {
                string attachment = "attachment; filename=Summary Report.xls";
                Response.ClearContent();
                Response.Charset = Encoding.UTF8.ToString();
                Response.AddHeader("content-disposition", attachment);
                Response.Cache.SetCacheability(HttpCacheability.NoCache);
                Response.ContentType = "application/ms-excel";
                Response.ContentEncoding = Encoding.UTF8;

                StringWriter stw = new StringWriter();
                HtmlTextWriter htextw = new HtmlTextWriter(stw);
                GridView gvTempSummaryReport = new GridView();
                gvTempSummaryReport.DataSource = dataTable;
                gvTempSummaryReport.DataBind();
                gvTempSummaryReport.RenderControl(htextw);
                Response.Write(stw.ToString());
                Response.End();
            }
            else
            {
                this.lbMessageHead.Text = "ไม่พบข้อมูล";
                this.lbMessageHead.ForeColor = System.Drawing.Color.Red;
                this.lbMessageHead.Font.Bold = true;
            }
        }
        catch (Exception ex)
        {
            this.lbMessageHead.Text = "เกิดข้อผิดพลาดในการดึงข้อมูลลง Microsoft Excel ของโปรแกรม!." + ex.Message.ToString().Trim();
            this.lbMessageHead.ForeColor = System.Drawing.Color.Red;
            this.lbMessageHead.Font.Bold = true;
            return;
        }
    }
    //
    private void btnImgExcel2_Click(object sender, EventArgs e)
    {
        try
        {
            DataTable dataTable = new DataTable();
            //dv = (DataView)Session["SummaryReportData"];
            dv = (DataView)Session["SummaryReportDetailData"];

            dataTable = dv.ToTable();
            if (dataTable.Rows.Count > 0)
            {
                string attachment = "attachment; filename=Summary Report Details.xls";
                Response.ClearContent();
                Response.Charset = Encoding.UTF8.ToString();
                Response.AddHeader("content-disposition", attachment);
                Response.Cache.SetCacheability(HttpCacheability.NoCache);
                Response.ContentType = "application/ms-excel";
                Response.ContentEncoding = Encoding.UTF8;

                StringWriter stw = new StringWriter();
                HtmlTextWriter htextw = new HtmlTextWriter(stw);
                

                GridView gvTempSummaryReportDetails = new GridView();
                gvTempSummaryReportDetails.DataSource = dataTable;
                gvTempSummaryReportDetails.DataBind();
                gvTempSummaryReportDetails.RenderControl(htextw);
                Response.Write(stw.ToString());
                Response.End();
            }
            else
            {
                this.lbMessageHead.Text = "ไม่พบข้อมูล";
                this.lbMessageHead.ForeColor = System.Drawing.Color.Red;
                this.lbMessageHead.Font.Bold = true;
            }
        }
        catch (Exception ex)
        {
            this.lbMessageHead.Text = "เกิดข้อผิดพลาดในการดึงข้อมูลลง Microsoft Excel ของโปรแกรม!." + ex.Message.ToString().Trim();
            this.lbMessageHead.ForeColor = System.Drawing.Color.Red;
            this.lbMessageHead.Font.Bold = true;
            return;
        }
    }
    //
    private void ClearDataInGridSummaryReport()
    {
        Session["SummaryReportData"] = null;
        BindDataToGridSummaryReport();
    }
    //
    private void ClearDataInGridSummaryReportDetail()
    {
        Session["SummaryReportDetailData"] = null;
        BindDataToGridSummaryReportDetail();
    }
    //
    private void BindDataToGridSummaryReport()
    {
        dv = (DataView)Session["SummaryReportData"];
        this.gvSummaryReport.DataSource = dv;
        this.gvSummaryReport.DataBind();
    }
    //
    private void BindDataToGridSummaryReportDetail()
    {
        dv = (DataView)Session["SummaryReportDetailData"];
        this.gvSummaryReportDetails.DataSource = dv;
        this.gvSummaryReportDetails.DataBind();
    }

    #region "FOR GRIDVIEW MAIN"
    //FOR GRIDVIEW MAIN
    private void GoPage(Int16 xPage)
    {
        gvSummaryReport.PageIndex = xPage;
        BindDataToGridSummaryReport();
    }
    private void FirstPage(object sender, EventArgs e)
    {
        this.GoPage(0);
    }
    private void PrePage(object sender, EventArgs e)
    {
        this.GoPage(Convert.ToInt16(gvSummaryReport.PageIndex - 1));
    }
    private void NextPage(object sender, EventArgs e)
    {
        this.GoPage(Convert.ToInt16(gvSummaryReport.PageIndex + 1));
    }
    private void LastPage(object sender, EventArgs e)
    {
        this.GoPage(Convert.ToInt16(gvSummaryReport.PageCount - 1));
    }
    #endregion

    #region "FOR GRIDVIEW DETAIL"
    //FOR GRIDVIEW DETAIL
    private void GoPage1(Int16 xPage)
    {
        gvSummaryReportDetails.PageIndex = xPage;
        BindDataToGridSummaryReportDetail();
    }
    private void FirstPage1(object sender, EventArgs e)
    {
        this.GoPage1(0);
    }
    private void PrePage1(object sender, EventArgs e)
    {
        this.GoPage1(Convert.ToInt16(gvSummaryReportDetails.PageIndex - 1));
    }
    private void NextPage1(object sender, EventArgs e)
    {
        this.GoPage1(Convert.ToInt16(gvSummaryReportDetails.PageIndex + 1));
    }
    private void LastPage1(object sender, EventArgs e)
    {
        this.GoPage1(Convert.ToInt16(gvSummaryReportDetails.PageCount - 1));
    }
    #endregion

    protected void gvSummaryReportDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvSummaryReportDetails.PageIndex = e.NewPageIndex;
        BindDataToGridSummaryReportDetail();
        //CLEAR MESSAGE
        this.lbMessageHead.Text = "";
    }
    protected void gvSummaryReportDetails_RowCreated(object sender, GridViewRowEventArgs e)
    {
        TableCell td = e.Row.Cells[0];
        Boolean Y = false;
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            if (gvSummaryReportDetails.PageIndex > 0)
            {
                LinkButton L1 = new LinkButton();
                Image M1 = new Image();
                M1.ImageUrl = "../Images/Backward.gif";
                //L1.Text = "First";
                //AddHandler L1.Click, AddressOf NextClick
                L1.Click += new EventHandler(FirstPage1);
                L1.Controls.Add(M1);
                td.Controls.Add(L1);

                Y = true;
                //separate
                Literal L2 = new Literal();
                L2.Text = "&nbsp&nbsp";
                td.Controls.Add(L2);

                L1 = new LinkButton();
                M1 = new Image();
                M1.ImageUrl = "../Images/Previous.gif";
                //L1.Text = "Pre";
                L1.Click += new EventHandler(PrePage1);
                L1.Controls.Add(M1);
                td.Controls.Add(L1);
            }
            if (gvSummaryReportDetails.PageIndex < gvSummaryReportDetails.PageCount - 1)
            {
                Literal L2 = new Literal();
                if (Y == true)
                {
                    // created first & pre
                    L2 = new Literal();
                    L2.Text = " &nbsp;&nbsp";
                    td.Controls.Add(L2);
                }
                LinkButton L1 = new LinkButton();
                Image M1 = new Image();
                M1.ImageUrl = "../Images/Next.gif";
                L1.Click += new EventHandler(NextPage1);
                //L1.Text = "Next";
                L1.Controls.Add(M1);
                td.Controls.Add(L1);

                L2 = new Literal();
                L2.Text = "&nbsp&nbsp";
                td.Controls.Add(L2);

                L1 = new LinkButton();
                M1 = new Image();
                M1.ImageUrl = "../Images/Forward.gif";
                //L1.Text = "Last";
                L1.Click += new EventHandler(LastPage1);
                L1.Controls.Add(M1);
                td.Controls.Add(L1);
            }
        }
    }
    protected void gvSummaryReport_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvSummaryReport.PageIndex = e.NewPageIndex;
        BindDataToGridSummaryReport();
        //CLEAR MESSAGE
        this.lbMessageHead.Text = "";
    }
    protected void gvSummaryReport_RowCreated(object sender, GridViewRowEventArgs e)
    {
        TableCell td = e.Row.Cells[0];
        Boolean Y = false;
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            if (gvSummaryReportDetails.PageIndex > 0)
            {
                LinkButton L1 = new LinkButton();
                Image M1 = new Image();
                M1.ImageUrl = "../Images/Backward.gif";
                //L1.Text = "First";
                //AddHandler L1.Click, AddressOf NextClick
                L1.Click += new EventHandler(FirstPage);
                L1.Controls.Add(M1);
                td.Controls.Add(L1);

                Y = true;
                //separate
                Literal L2 = new Literal();
                L2.Text = "&nbsp&nbsp";
                td.Controls.Add(L2);

                L1 = new LinkButton();
                M1 = new Image();
                M1.ImageUrl = "../Images/Previous.gif";
                //L1.Text = "Pre";
                L1.Click += new EventHandler(PrePage);
                L1.Controls.Add(M1);
                td.Controls.Add(L1);
            }
            if (gvSummaryReportDetails.PageIndex < gvSummaryReportDetails.PageCount - 1)
            {
                Literal L2 = new Literal();
                if (Y == true)
                {
                    // created first & pre
                    L2 = new Literal();
                    L2.Text = " &nbsp;&nbsp";
                    td.Controls.Add(L2);
                }
                LinkButton L1 = new LinkButton();
                Image M1 = new Image();
                M1.ImageUrl = "../Images/Next.gif";
                L1.Click += new EventHandler(NextPage);
                //L1.Text = "Next";
                L1.Controls.Add(M1);
                td.Controls.Add(L1);

                L2 = new Literal();
                L2.Text = "&nbsp&nbsp";
                td.Controls.Add(L2);

                L1 = new LinkButton();
                M1 = new Image();
                M1.ImageUrl = "../Images/Forward.gif";
                //L1.Text = "Last";
                L1.Click += new EventHandler(LastPage);
                L1.Controls.Add(M1);
                td.Controls.Add(L1);
            }
        }
    }

    protected void gvSummaryReport_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            for (int i = 1; i < 5; i++)
            {
                e.Row.Cells[i].Text = Microsoft.VisualBasic.Strings.FormatNumber(e.Row.Cells[i].Text.ToString().Trim(), 0);    
            }
        }
    }
    protected void gvSummaryReportDetails_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            for (int i = 4; i <= 5; i++)
            {
                e.Row.Cells[i].Text = Microsoft.VisualBasic.Strings.FormatNumber(e.Row.Cells[i].Text.ToString().Trim(), 0); 
            }
        }
    }
}