﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Data;
using PA.BLL;

public partial class Report_ReportGroupBML : System.Web.UI.Page
{
    DataTable dt;
    protected void Page_Load(object sender, EventArgs e)
    {
        this.btnSearchReport.ServerClick += new EventHandler(btnSearchReport_ServerClick);
        this.btnExportToExcel.ServerClick += new EventHandler(btnExportToExcel_ServerClick);
        this.gdvReport.PageIndexChanging += new GridViewPageEventHandler(gdvReport_PageIndexChanging);
        
        DefaultPageRegisterClientScript();
        if (!Page.IsPostBack)
        {
            BindResultBrokerCode(ddlGBrokerCode);
            BindResultPackage(ddlPackageType);
            Session.Remove("BMLReporting");
        }

    }

    void btnExportToExcel_ServerClick(object sender, EventArgs e)
    {
        ExprotToExcel((DataTable)Session["BMLReporting"]);
    }

    private void BindResultBrokerCode(DropDownList ddlBrokerCode)
    {

        dt = Motor.GetGBrokerCodeBML();
        DataRow dr = dt.NewRow();
        dr["GROUPBROKERID"] = "ALL";
        dr["GROUPBROKERNAME"] = "เลือกทั้งหมด";
        dt.Rows.InsertAt(dr, 0);

        //VEHICLE 
        ddlBrokerCode.DataSource = dt;
        ddlBrokerCode.DataTextField = "GROUPBROKERNAME";
        ddlBrokerCode.DataValueField = "GROUPBROKERID";
        ddlBrokerCode.DataBind();
        dt.Clear();
    }
    private void BindResultPackage(DropDownList ddlPackageType)
    {

        dt = Motor.GetPackageTypeBML();
        DataRow dr = dt.NewRow();
        dr["PackageType"] = "ALL";
        dt.Rows.InsertAt(dr, 0);

        //VEHICLE 
        ddlPackageType.DataSource = dt;
        ddlPackageType.DataTextField = "PackageType";
        ddlPackageType.DataValueField = "PackageType";
        ddlPackageType.DataBind();
        dt.Clear();
    }

    protected void btnSearchReport_ServerClick(object sender, EventArgs e)
    {
        if (this.txtTransactionDateFrom.Value.Length >= 1 && this.txtTransactionDateFrom.Value.Length <= 9)
        {
            this.lblMassage.Text = "Format วันที่ ของ Date From/To ไม่ถูกต้อง ที่ถูกต้องเป็น dd/mm/yyyy";
            this.txtTransactionDateFrom.Value = "";
            this.txtTransactionDateTo.Value = "";
        }
        else { this.lblMassage.Text = ""; }

        if (this.txtTransactionDateTo.Value.Length >= 1 && this.txtTransactionDateTo.Value.Length <= 9)
        {
            this.lblMassage.Text = "Format วันที่ ของ Date From/To ไม่ถูกต้อง ที่ถูกต้องเป็น dd/mm/yyyy";
            this.txtTransactionDateFrom.Value = "";
            this.txtTransactionDateTo.Value = "";
        }
        else { this.lblMassage.Text = ""; }

        if (this.txtEffectiveDateFrom.Value.Length >= 1 && this.txtEffectiveDateFrom.Value.Length <= 9)
        {
            this.lblMassage.Text = "Format วันที่ ของ Date From/To ไม่ถูกต้อง ที่ถูกต้องเป็น dd/mm/yyyy";
            this.txtEffectiveDateFrom.Value = "";
            this.txtEffectiveDateTo.Value = "";
        }
        else { this.lblMassage.Text = ""; }

        if (this.txtTransactionDateTo.Value.Length >= 1 && this.txtTransactionDateTo.Value.Length <= 9)
        {
            this.lblMassage.Text = "Format วันที่ ของ Date From/To ไม่ถูกต้อง ที่ถูกต้องเป็น dd/mm/yyyy";
            this.txtEffectiveDateFrom.Value = "";
            this.txtEffectiveDateTo.Value = "";
        }
        else { this.lblMassage.Text = ""; }


        GetReport(GetFormateDateYMD(this.txtTransactionDateFrom.Value.Trim()), GetFormateDateYMD(this.txtTransactionDateTo.Value.Trim()), GetFormateDateYMD(this.txtEffectiveDateFrom.Value.Trim()), GetFormateDateYMD(this.txtEffectiveDateTo.Value.Trim()));
    }
    protected void gdvReport_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

        this.gdvReport.PageIndex = e.NewPageIndex;
        gdvReport.DataSource = (DataTable)Session["BMLReporting"];
        gdvReport.DataBind();

    }


    private void GetReport(string TransDateFrom, string TransDateTo, string EffectiveDateFrom, string EffectiveDateTo)
    {
        string l_AgentCode = Utilities.BrokerCode();
        string l_GroupBrokerID = ddlGBrokerCode.SelectedValue.ToString();
        string PolicyType = ddlPackageType.SelectedValue.ToString();
        DataTable result = new DataTable();
        //Session.Remove("PAReporting");


        result = ReportsSummary.GetBMLReport(l_GroupBrokerID, PolicyType, EffectiveDateFrom, EffectiveDateTo, TransDateFrom, TransDateTo);
        Session.Add("BMLReporting", result);

        if (result.Rows.Count > 0)
        {
            this.btnExportToExcel.Visible = true;

            this.lblTotalRecord.Text = "แสดงรายการข้อมูล [จำนวนข้อมูลทั้งหมด " + result.Rows.Count + " รายการ]";


            this.gdvReport.DataSource = result;
            this.gdvReport.DataBind();

        }
        else
        {
            this.lblTotalRecord.Text = "แสดงรายการข้อมูล [จำนวนข้อมูลทั้งหมด " + 0 + " รายการ]";
            this.gdvReport.DataSource = null;
            this.gdvReport.DataBind();
            //this.gdvReport.Visible = false;
            //this.btnExportToExcel.Visible = false;
        }
    }
    private string GetFormateDateYMD(string date)
    {
        if (string.IsNullOrEmpty(date))
        {
            return "";
        }
        else
        {

            string[] DatePart = date.Split('/');
            return DatePart[2] + '-' + DatePart[1] + '-' + DatePart[0];
        }

    }

    private void ExprotToExcel(DataTable dt)
    {
        if (dt.Rows.Count > 0)
        {

            string filename = "BMLReport.xls";
            System.IO.StringWriter tw = new System.IO.StringWriter();
            System.Web.UI.Html32TextWriter hw = new Html32TextWriter(tw);
            DataGrid gdGrid = new DataGrid();
            gdGrid.DataSource = dt;
            gdGrid.DataBind();

            gdGrid.RenderControl(hw);
            //this.gdvReport.RenderControl(hw);

            Response.Clear();
            Response.Buffer = true;
            Response.Charset = "";
            this.EnableViewState = false;

            Response.ContentType = "application/vnd.ms-excel";
            Response.AppendHeader("Content-Disposition", "attachment;filename=" + filename + "");
            Response.ContentEncoding = System.Text.Encoding.UTF8;
            Response.Write(tw.ToString());
            Response.End();
        }

    }
    public override void VerifyRenderingInServerForm(Control control)
    {

    }
    protected void DefaultPageRegisterClientScript()
    {
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptScrolling", "MenuScroll();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptTxtFocus", "setFocusTextbox();", true);
        //ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDrawCorner", "DrawDivCorner();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDisplayMsg", "DisplayWarning();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDatePicker", "<script type='text/javascript' language='javascript'>  $(document).ready(function () {  $('.MOTOR').find('img').attr('src', '../Images/Index/MOTOR1.png');  $('.MOTOR').find('a').css('color', '#922d3d'); $('.MOTOR').hover( function () { $(this).find('img').attr('src', '../Images/Index/MOTOR1.png'); } , function () { $(this).find('img').attr('src', '../Images/Index/MOTOR1.png'); } );addSubMenu('hdnMotor', '.subNavigate', 'สร้างกรมธรรม์', '');Accordion('.wizard', 'hdnCriteriaStep');});</script>", false);
    }
}