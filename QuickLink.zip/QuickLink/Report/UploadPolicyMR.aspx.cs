﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Configuration;
using Microsoft.SqlServer.Dts.Runtime;
using System.Text;
using System.Data.Common;

public partial class Admin_UploadPolicyMR : System.Web.UI.Page
{     private string Msg = "";
        private string msg2 = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        DefaultPageRegisterClientScript();
        DropDownList cmdBrokerInGroup = (DropDownList)this.Page.Master.FindControl("cmdBrokerInGroup");
        cmdBrokerInGroup.Enabled = false;
    }

        protected void btnUploadPolicyMR_Click(object sender, EventArgs e)
        {

            if ((ddlBrokerChange.SelectedValue.ToString() == "Y" && txbBrokerCode.Text.Length < 5) || (ddlBrokerChange.SelectedValue.ToString() == "Y" &&  txbBrokerCode.Text.Length > 7))
            {
                lbSearchPrintMsg.Text = "กรุณาใส่รหัสตัวแทนใหม่ที่เปลี่ยนด้วยค่ะ";
                
            }
            else
            {
                //P0779852
                if (txbPolicyNo.Text.Length == 8)
                {
                    try
                    {
                        setPolicyMR_NO(txbPolicyNo.Text);
                        sentEmailTD(txbBrokerCode.Text, txtEmail.Text);
                        lbSearchPrintMsg.Text = Msg;
                        lbStatus.Text = msg2;
                    }

                    catch (Exception myEx)
                    {
                        lbSearchPrintMsg.Text = "เกิดข้อผิดพลาดขึ้นขณะ Import ไฟล์!!!กรุณาติดต่อผู้ดูแลระบบ";
                        lbSearchPrintMsg.Text += "<br>" + myEx.Message;
                    }
                }
            }



        

        }

        public  void  setPolicyMR_NO(string policyNo)
        {

            //clsHelper clsHelper = new clsHelper();
            //dsPackageTypeNew dsPackageTypeNew = new dsPackageTypeNew();
            SqlTransaction tx;
            SqlCommand command;
            SqlCommand command2;
            //SqlDataAdapter dataAdapter;
            clsConn clsConn = new clsConn();
            clsHelper clsHelper = new clsHelper();



            using (SqlConnection conn = clsConn.GetDataconnection(clsConn.Database.TestDBProductionConnectionString))
            {
                conn.Open();

                try
                {


                   // command2 = new SqlCommand("sp_getPolicyNoForTRPolicyMR", conn);
                   // command2.CommandType = CommandType.StoredProcedure;

                   // SqlParameter spReturnValue = new SqlParameter("@PolicyNo", SqlDbType.VarChar, 50);
                   // spReturnValue.Direction = ParameterDirection.InputOutput;
                   // spReturnValue.Value = policyNo;
                   //command2.Parameters.Add(spReturnValue);
                   // command2.ExecuteNonQuery();
                   // string ck = command2.Parameters["@PolicyNo"].Value.ToString();
                   // if (ck == "0")
                   // {

                        command = new SqlCommand("sp_setPolicyNoForTRPolicyMR", conn);
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add("@PolicyNo", SqlDbType.NVarChar, 50).Value = policyNo;
                        command.ExecuteNonQuery();


                        SqlConnection jobConnection;
                        SqlCommand jobCommand;
                        SqlParameter jobReturnValue;
                        SqlParameter jobParameter;
                        int jobResult;
                        jobConnection = new SqlConnection("data source=10.16.8.9; initial catalog= msdb; persist security info=False; user id=sa; password=12345; packet size=4096");
                       // jobConnection = new SqlConnection("data source=10.16.8.9;Initial Catalog=msdb;Integrated Security=SSPI");
                        jobCommand = new SqlCommand("sp_start_job", jobConnection);
                        jobCommand.CommandType = CommandType.StoredProcedure;

                        jobReturnValue = new SqlParameter("@RETURN_VALUE", SqlDbType.Int);
                        jobReturnValue.Direction = ParameterDirection.ReturnValue;
                        jobCommand.Parameters.Add(jobReturnValue);

                        jobParameter = new SqlParameter("@job_name", SqlDbType.VarChar);
                        jobParameter.Direction = ParameterDirection.Input;
                        jobCommand.Parameters.Add(jobParameter);
                        jobParameter.Value = "PolicyMRByQLHD";

                        jobConnection.Open();
                        jobCommand.ExecuteNonQuery();
                        jobResult = (Int32)jobCommand.Parameters["@RETURN_VALUE"].Value;
                        jobConnection.Close();

                        switch (jobResult)
                        {
                            case 0:
                                this.Msg = "โปรดรอประมาณ 2-5 นาที ขณะนี้กำลังดึงข้อมูลจากระบบ AS400 เข้าระบบ QuickLink. ";
                                this.msg2 = "ท่านสามารถตรวจสอบ Upload ได้ โดยคลิกปุ่ม \"ตรวจสอบการ Upload\" ";
                                break;
                            default:
                                this.Msg = "เกิดข้อผิดพลาดขึ้นขณะ Import ไฟล์!!!กรุณาติดต่อผู้ดูแลระบบ"; 
                                break;
                        }
                        //   Console.Read();

                        //if (jobResult == 0)
                        //{

                        //    command = new SqlCommand("sp_setPolicyNoForTRPolicyMR", conn);
                        //    command.CommandType = CommandType.StoredProcedure;
                        //    command.Parameters.Add("@PolicyNo", SqlDbType.NVarChar, 50).Value = policyNo;
                        //    command.ExecuteNonQuery();
                        //}

                    //}
                    //else { this.Msg = "เรียบร้อยค่ะ เนื่องจากมีกรมธรรม์นี้ในระบบ QuickLink แล้วค่ะ"; }
                }

                catch (Exception ex)
                {
                    this.Msg = "เกิดข้อผิดพลาดขึ้นขณะ Import ไฟล์!!!กรุณาติดต่อผู้ดูแลระบบ ";
                    this.Msg += "<br> " + ex.Message;
                    throw ex;
                    //return;
                }
                finally
                {
                    conn.Close();
                }


                //return true;
            }
        }

        protected void btnCheckComplete_Click(object sender, EventArgs e)
        {
            SqlTransaction tx;
            SqlCommand command;
            SqlCommand command2;
            //SqlDataAdapter dataAdapter;
            clsConn clsConn = new clsConn();
            clsHelper clsHelper = new clsHelper();

            using (SqlConnection conn = clsConn.GetDataconnection(clsConn.Database.TestDBProductionConnectionString))
            {
                conn.Open();

                try
                {


                    command2 = new SqlCommand("sp_getPolicyNoForTRPolicyMR", conn);
                    command2.CommandType = CommandType.StoredProcedure;

                    SqlParameter spReturnValue = new SqlParameter("@PolicyNo", SqlDbType.VarChar, 50);
                    spReturnValue.Direction = ParameterDirection.InputOutput;
                    spReturnValue.Value = txbPolicyNo.Text;
                    command2.Parameters.Add(spReturnValue);
                    command2.ExecuteNonQuery();
                    string ck = command2.Parameters["@PolicyNo"].Value.ToString();
                    if (ck == "1")
                    {
                        lbStatus.Text = "Upload เรียบร้อยแล้วค่ะ ";
                        
                        if (ddlBrokerChange.SelectedValue.ToString() == "Y")
                        {
                            lbSearchPrintMsg.Text = "กรณีเปลี่ยนรหัสตัวแทน ให้ท่านรอ Email ตอบกับจาก SITO-TD Service Desk เพื่อ Sanction ให้เรียบร้อยก่อน ท่านจึงจะสามารถต่ออายุได้ค่ะ";
                        }
                        else
                        {
                            Msg = "";
                        }

                    }
                    else
                    {
                        lbStatus.Text = "โปรดรอสักครู่ค่ะ";
                    }
                }
                catch (Exception ex)
                {
                    this.Msg = "เกิดข้อผิดพลาดขึ้นขณะ Import ไฟล์!!!กรุณาติดต่อผู้ดูแลระบบ";
                    this.Msg += "<br>" + ex.Message;
                    throw ex;
                    //return;
                }
                finally
                {
                    conn.Close();
                }

            }
        }

        protected void ddlBrokerChange_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlBrokerChange.SelectedValue.ToString() == "Y")
            {

                this.dPlay.Style["display"] = "block";
            }
            else
            {
                this.dPlay.Style["display"] = "none";
            }

        }
        public void sentEmailTD(string brokercode, string emailfrom)
        {
            SqlTransaction tx;
            SqlCommand command;
            SqlCommand command2;
            //SqlDataAdapter dataAdapter;
            clsConn clsConn = new clsConn();
            clsHelper clsHelper = new clsHelper();

            using (SqlConnection conn = clsConn.GetDataconnection(clsConn.Database.LocalSqlServerAXA))
            {
                DbCommand comm = GenericDataAccess.CreateStorePCommand();
                comm.Connection.Open();

                try
                {

                    string str = "sp_getUserHostName";


                   // DbCommand comm = GenericDataAccess.CreateStorePCommand();
                    //comm.CommandText = str;

                    DbParameter param = comm.CreateParameter();

                    param = comm.CreateParameter();
                    param.ParameterName = "@BrokerCode";
                    param.Value = brokercode;
                    param.DbType = DbType.String;
                    comm.Parameters.Add(param);

                    //  DataTable dt = GenericDataAccess.ExecuteSelectCommand(comm);
                    comm.CommandText = str;
                    DbDataReader reader = comm.ExecuteReader();
                    string UserHostName = "";
                    while (reader.Read())
                    {
                        UserHostName += reader.GetValue(reader.GetOrdinal("USERHOSTNAME")).ToString() + ", ";

                    }


                    string from = emailfrom.ToString();//"QuickLinKHelpdesk@axa.co.th";//
                    string to = "ITServiceDesk@axa.co.th";// +EmailCCApprovel; // QuickLinkConfiguration.ApprovalEmail;
                    string cc = emailfrom.ToString();// "namcyber@gmail.com";
                    string subject = QuickLinkConfiguration.SiteName + " Run Sanction ";
                    string body = "Dear IT Service Desk, \n\n";
                    body += "Please kindly run sanction job name is P1ENTSANC for user-id  of " + UserHostName;
                    body += "and reply when you run complete \n\n****** \n";
                    body += "(This Email is automatically generated by QuickLink system.) ";
                    Utilities.SendMail(from, to, subject, body, cc);

                }
                catch (Exception ex)
                {
                    this.Msg = "เกิดข้อผิดพลาดขึ้นขณะ Import ไฟล์!!!กรุณาติดต่อผู้ดูแลระบบ";
                    this.Msg += "<br>" + ex.Message;
                    throw ex;
                    //return;
                }
                finally
                {
                     comm.Connection.Close();
                }
            }
        }
        protected void DefaultPageRegisterClientScript()
        {
            ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptScrolling", "MenuScroll();", true);
            ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptTxtFocus", "setFocusTextbox();", true);
            //ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDrawCorner", "DrawDivCorner();", true);
            ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDisplayMsg", "DisplayWarning();", true);
            ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDatePicker", "<script type='text/javascript' language='javascript'>  $(document).ready(function () {  $('.MOTOR').find('img').attr('src', '../Images/Index/MOTOR1.png');  $('.MOTOR').find('a').css('color', '#922d3d'); $('.MOTOR').hover( function () { $(this).find('img').attr('src', '../Images/Index/MOTOR1.png'); } , function () { $(this).find('img').attr('src', '../Images/Index/MOTOR1.png'); } );addSubMenu('hdnMotor', '.subNavigate', 'สร้างกรมธรรม์', '');Accordion('.wizard', 'hdnCriteriaStep');});</script>", false);
        }
    }
