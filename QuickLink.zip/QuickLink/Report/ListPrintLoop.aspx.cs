using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Report_listPrintLoop : System.Web.UI.Page
{
    string volunpolicy = "";
    string complpolicy = "";

    string tmpPolicyNo = "";
    

    protected void Page_Load(object sender, EventArgs e)
    {
        DefaultPageRegisterClientScript();
        DropDownList cmdBrokerInGroup = (DropDownList)this.Page.Master.FindControl("cmdBrokerInGroup");
        cmdBrokerInGroup.Enabled = false;
        //Boolean result = false;
        if (!IsPostBack)
        {
            lbMsgPrint.Visible = false;
            GridViewDocument.Visible = true;
            ShowData.Visible = true;
           
        }
        
        string brokercode = "BR301";
//        brokercode = Utilities.BrokerCode();
        if (brokercode == "")
        {
            ShowMessage("�������ö����¡���� ���ͧ�ҡ�ѧ������������к�");
            GridViewDocument.Visible = false;
            ShowData.Visible = false;
            
        }
        else
        {
            try
            {
                volunpolicy = Request.QueryString["volun"].ToString().Trim();
                complpolicy = Request.QueryString["compl"].ToString().Trim();

                tmpPolicyNo = volunpolicy;


                

                //brokercode = "BR301";
                //result = PolicyReprint.chkPolicyAllowBroker(volunpolicy, complpolicy);
                //if (!result)
                //{
                //    ShowMessage("�������ö����¡���� ���ͧ�ҡ�����š����������١��ͧ !");
                    
                //    GridViewDocument.Visible = false;
                //    return;
                //}

            }
            catch (Exception ex)
            {
                lbMsgPrint.Text = "�������ö����¡���� ���ͧ�Դ��ͼԴ��Ҵ㹡�����¡������";
                lbMsgPrint.ForeColor = System.Drawing.Color.Black;
                lbMsgPrint.Font.Bold = true;

                GridViewDocument.Visible = false;
                ShowData.Visible = false;
            }
        }
    }
    protected void GridViewDocument_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if(e.Row.RowIndex >= 0)
        {
            string strName = "";
            //check for use find report name
                switch (cmbPoilcyName.SelectedValue)
                {
                    case "Volun":
                        if (cmbPolicyType.SelectedValue == "5")
                        {
                            if (e.Row.Cells[7].Text == "2")
                                strName = "re_";
                            else
                                strName = "re_class5_";
                            break;
                        }
                        else
                        {
                            if (e.Row.Cells[7].Text == "1")
                                strName = "re_";
                            else
                                strName = "re_class1_";
                            break;
                        }
                        break;
                    case "Compl":
                        if (e.Row.Cells[7].Text == "14")
                            strName= "re_compuls_";
                        else
                            strName = "re_";
                        break;
                    case "BOTH":
                        if (cmbPolicyType.SelectedValue == "5")
                        {
                            if (e.Row.Cells[7].Text == "9")
                                strName = "re_";
                            else
                                if (e.Row.Cells[7].Text == "14")
                                    strName = "re_compuls5_";
                                else
                                    strName = "re_combine5_";
                            break;
                        }
                        else
                        {
                            if (e.Row.Cells[7].Text == "10")
                                strName = "re_";
                            else
                                if (e.Row.Cells[7].Text == "14")
                                    strName = "re_compuls1_";
                                else
                                    strName = "re_combine1_3_";
                            break;
                        }
                        break;
                }
        //    //CHECKREPORT 
        //    //11=��ѡ�ҹ��õ�ͷ���¹ 14=�����/㺡ӡѺ���� (�Ҥ�ѧ�Ѻ) 4 =�Ҥ�ѧ�Ѻ
        //    string tmpReportID = e.Row.Cells[6].Text.Trim();
        //    if (tmpReportID == "11" | tmpReportID == "14" | tmpReportID == "4")
        //    {
        //        tmpPolicyNo = complpolicy;
        //    }
        //    else
        //    {
        //        tmpPolicyNo = volunpolicy;
        //    }

        //    //e.Row.Cells[1].Text = "<input type='button' value = 'Print(" + e.Row.Cells[4].Text + ")' Style=\"width:100px;\" onClick = \"if (confirm('Are you sure you want to print?')==false) return;window.location = 'print.aspx?flag=FlagOriginal&amp;policy=" + Request.QueryString["volun"] + "&amp;report=" + e.Row.Cells[7].Text + "&amp;reportid=" + e.Row.Cells[6].Text + "&amp;volun=" + volunpolicy + "&amp;compl=" + complpolicy + "' \" >";

                e.Row.Cells[1].Text = "<input type='button' value = 'Print(" + e.Row.Cells[4].Text + ")' Style=\"width:150px;\" onClick = \"if (confirm('Are you sure you want to print?')==false) return; window.location = '" + WebConfigurationManager.AppSettings["UrlReportingService"].ToString() + strName + e.Row.Cells[4].Text + "&rs:Format=PDF&PolicyFrom=" + txbPolicyFrom.Text.Trim() + "&PolicyTo=" + txbPolicyTo.Text.Trim() + "';\">";
                e.Row.Cells[2].Text = "<input type='button' value = 'Print(" + e.Row.Cells[5].Text + ")' Style=\"width:150px;\" onClick = \"if (confirm('Are you sure you want to print?')==false) return; window.location = '" + WebConfigurationManager.AppSettings["UrlReportingService"].ToString() + strName + e.Row.Cells[5].Text + "&rs:Format=PDF&PolicyFrom=" + txbPolicyFrom.Text.Trim() + "&PolicyTo=" + txbPolicyTo.Text.Trim() + "';\">";
                e.Row.Cells[3].Text = "<input type='button' value = 'Print(" + e.Row.Cells[6].Text + ")' Style=\"width:150px;\" onClick = \"if (confirm('Are you sure you want to print?')==false) return; window.location = '" + WebConfigurationManager.AppSettings["UrlReportingService"].ToString() + strName + e.Row.Cells[6].Text + "&rs:Format=PDF&PolicyFrom=" + txbPolicyFrom.Text.Trim() + "&PolicyTo=" + txbPolicyTo.Text.Trim() + "';\">";

        //    //e.Row.Cells[2].Text = "<input type='button' value = 'Print(" + e.Row.Cells[5].Text + ")' Style=\"width:100px;\" onClick = \"if (confirm('Are you sure you want to print?')==false) return;window.location = 'http://10.16.8.4/ReportServer?%2fQuicklink%2f" + e.Row.Cells[8].Text + "&amp;rs:Format=PDF&amp;Policy=" + tmpPolicyNo + "';setTimeout('window.location.reload(true)',10000);\">";

                //    e.Row.Cells[2].Text = "<input type='button' value = 'Print(" + e.Row.Cells[5].Text + ")' Style=\"width:100px;\" onClick = \"if (confirm('Are you sure you want to print?')==false) return;window.location = '" + QuickLinkConfiguration.UrlReportingService + e.Row.Cells[8].Text + "&amp;rs:Format=PDF&amp;Policy=" + tmpPolicyNo + "' ;setTimeout('window.location.reload(true)'," + WebConfigurationManager.AppSettings["LimitPrintTimeOut"].ToString() + ");\">";


        //    //e.Row.Cells[3].Text = "<input type='button' value = 'View' Style=\"width:100px;\" onClick = \"window.location = 'http://10.16.8.4/ReportServer?%2fQuicklink%2f" + e.Row.Cells[9].Text + "&amp;rs:Format=PDF&amp;Policy=" + Request.QueryString["volun"] + "'  \">";

        //    e.Row.Cells[3].Text = "<input type='button' value = 'View' Style=\"width:100px;\" onClick = \"window.location = '" + QuickLinkConfiguration.UrlReportingService + e.Row.Cells[9].Text + "&amp;rs:Format=PDF&amp;Policy=" + tmpPolicyNo + "'  \">";

        //    if (e.Row.Cells[4].Text == "0")
        //    {
        //        e.Row.Cells[1].Text = "<input type='button' disabled value = 'Print(" + e.Row.Cells[4].Text + ")' Style=\"width:100px;\">";
        //    }

        //    if (e.Row.Cells[5].Text == "0")
        //    {
            //        e.Row.Cells[5].Text = "<input type='button' disabled value = 'Print(" + e.Row.Cells[5].Text + ")' Style=\"width:100px;\">";
        //    }
        }
        //// hidden Colums
        e.Row.Cells[4].Visible = false;
        e.Row.Cells[5].Visible = false;
        e.Row.Cells[6].Visible = false;
        e.Row.Cells[7].Visible = false;//ReportID
        e.Row.Cells[8].Visible = false;//Class
        e.Row.Cells[9].Visible = false;//Name
        e.Row.Cells[10].Visible = false;//Priority
    }
    private void ShowMessage(string msg)
    {
        lbMsgPrint.Visible = true;
        lbMsgPrint.Text = msg;
        lbMsgPrint.ForeColor = System.Drawing.Color.White;
        lbMsgPrint.BackColor = System.Drawing.Color.Red;
        lbMsgPrint.Font.Bold = true;
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
//        select DISTINCT PolicyType,Class,ReportPackage.ReportID,ReportName
//from ReportPackage,Report
//where PolicyType like '%BOTH%'
//and (Class like '%1%' or Class like 'Compuls')
//and ReportPackage.ReportID = Report.ReportID
//order by Class
        documentprint();
    }
    private void documentprint()
    {
        
        string sql = "";
        sql = " select DISTINCT ReportName,ReportCopyName,ReportViewName,Report.ReportID,Class,Name, Report.Priority ";
        sql += " from ReportPackage,Report ";
        sql += " where PolicyType like '%" + cmbPoilcyName.SelectedValue + "%' ";
        if (cmbPoilcyName.SelectedValue == "Volun")
        {
            sql += " and(Class like '%" + cmbPolicyType.SelectedValue + "%' )";
        }
        else if (cmbPoilcyName.SelectedValue == "BOTH")
        {
            sql += " and(Class like '%" + cmbPolicyType.SelectedValue + "%' or Class like 'Compuls')";
        }
        sql += " and ReportPackage.ReportID = Report.ReportID ";
        sql += " order by Report.Priority DESC";

        
        
        SqlConnection connection = new SqlConnection( WebConfigurationManager.ConnectionStrings["QuickLinkReportConnectionString"].ConnectionString);
        if (connection.State == ConnectionState.Open) connection.Close();
        connection.Open();

        SqlDataAdapter Adapter = new SqlDataAdapter(sql, connection);
        DataSet DSet = new DataSet();
        Adapter.Fill(DSet, "Report");
        this.GridViewDocument.DataSource = DSet.Tables["Report"];
        this.GridViewDocument.DataBind();
        GridViewDocument.Visible = true;
        ShowData.Visible = true;
        ShowData.Style.Add("visibility", "visiable");
    }
    protected void DefaultPageRegisterClientScript()
    {
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptScrolling", "MenuScroll();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptTxtFocus", "setFocusTextbox();", true);
        //ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDrawCorner", "DrawDivCorner();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDisplayMsg", "DisplayWarning();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDatePicker", "<script type='text/javascript' language='javascript'>  $(document).ready(function () {  $('.MOTOR').find('img').attr('src', '../Images/Index/MOTOR1.png');  $('.MOTOR').find('a').css('color', '#922d3d'); $('.MOTOR').hover( function () { $(this).find('img').attr('src', '../Images/Index/MOTOR1.png'); } , function () { $(this).find('img').attr('src', '../Images/Index/MOTOR1.png'); } );addSubMenu('hdnMotor', '.subNavigate', '���ҧ��������', '');Accordion('.wizard', 'hdnCriteriaStep');});</script>", false);
    }
}
