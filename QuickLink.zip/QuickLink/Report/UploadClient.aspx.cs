﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Configuration;
using Microsoft.SqlServer.Dts.Runtime;
using System.Text;
using System.Data.Common;
using WFQuickLink;


public partial class Admin_UploadClient : System.Web.UI.Page
{
    private string Msg = "";
    private string msg2 = "";
    private string Username="";
    private string Password = "";
    private string ClientType = "";

    QuickLinkService ClientService = new QuickLinkService();
  
    
    protected void Page_Load(object sender, EventArgs e)
    {
        DefaultPageRegisterClientScript();
        DropDownList cmdBrokerInGroup = (DropDownList)this.Page.Master.FindControl("cmdBrokerInGroup");
        cmdBrokerInGroup.Enabled = false;
    }
    protected void btnUploadClient_Click(object sender, EventArgs e)
    {
        if (txbBrokerCode.Text.Length > 7 || txbBrokerCode.Text.Length < 5)
        {
            Msg = "กรุณาใส่รหัสตัวแทนค่ะ";
           
        }
        else if (txbClientNo.Text.Length == 8)
        {
            try
            {
                setClient_NO(txbClientNo.Text, txbBrokerCode.Text, txbLicDrv.Text);

                SqlTransaction tx;
                SqlCommand command;
                SqlCommand command2;
                clsConn clsConn = new clsConn();
                clsHelper clsHelper = new clsHelper();

                using (SqlConnection conn = clsConn.GetDataconnection(clsConn.Database.TestDBProductionConnectionString))
                {
                    conn.Open();

                    try
                    {
                        command2 = new SqlCommand("sp_getClientTypeForTR", conn);
                        command2.CommandType = CommandType.StoredProcedure;

                        SqlParameter spReturnValue = new SqlParameter("@ClientNo", SqlDbType.VarChar, 50);
                        spReturnValue.Direction = ParameterDirection.InputOutput;
                        spReturnValue.Value = txbClientNo.Text;
                        command2.Parameters.Add(spReturnValue);
                        command2.ExecuteNonQuery();
                        ClientType = command2.Parameters["@ClientNo"].Value.ToString();


                        using (SqlConnection conn2 = clsConn.GetDataconnection(clsConn.Database.LocalSqlServerAXA))
                        {
                            DbCommand comm = GenericDataAccess.CreateStorePCommand();
                            comm.Connection.Open();

                            try
                            {

                                string str = "sp_getUserHostName";


                                // DbCommand comm = GenericDataAccess.CreateStorePCommand();
                                //comm.CommandText = str;

                                DbParameter param = comm.CreateParameter();

                                param = comm.CreateParameter();
                                param.ParameterName = "@BrokerCode";
                                param.Value = txbBrokerCode.Text;
                                param.DbType = DbType.String;
                                comm.Parameters.Add(param);

                                //  DataTable dt = GenericDataAccess.ExecuteSelectCommand(comm);
                                comm.CommandText = str;
                                DbDataReader reader = comm.ExecuteReader();

                                while (reader.Read())
                                {
                                    Username = reader.GetValue(reader.GetOrdinal("USERHOSTNAME")).ToString();

                                    setSanctionClient(Username, "PASSWORD", txbClientNo.Text, ClientType);


                                }
                            }
                            catch (Exception ex)
                            {
                                this.Msg = "เกิดข้อผิดพลาดขึ้นขณะ Import ไฟล์!!!กรุณาติดต่อผู้ดูแลระบบ";
                                this.Msg += "<br>" + ex.Message;
                                throw ex;
                                //return;
                            }
                            finally
                            {
                                comm.Connection.Close();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        this.Msg = "เกิดข้อผิดพลาดขึ้นขณะ Import ไฟล์!!!กรุณาติดต่อผู้ดูแลระบบ";
                        this.Msg += "<br>" + ex.Message;
                        throw ex;
                        //return;
                    }
                    finally
                    {
                        conn.Close();
                    }

                }


                lbSearchPrintMsg.Text = Msg;
                lbStatus.Text = msg2;
            }

            catch (Exception myEx)
            {
                lbSearchPrintMsg.Text = "เกิดข้อผิดพลาดขึ้นขณะ Import ไฟล์!!!กรุณาติดต่อผู้ดูแลระบบ";
                lbSearchPrintMsg.Text += "<br>" + myEx.Message;
            }
        }
        else
        {

            Msg = "กรุณาใส่รหัสลูกค้าค่ะ";
        }
        lbSearchPrintMsg.Text = Msg;
    }

    public void setClient_NO(string ClientNo, string BrokerCode, string LicDrv)
    {

        SqlTransaction tx;
        SqlCommand command;
        SqlCommand command2;
         clsConn clsConn = new clsConn();
        clsHelper clsHelper = new clsHelper();

        using (SqlConnection conn = clsConn.GetDataconnection(clsConn.Database.TestDBProductionConnectionString))
        {
            conn.Open();

            try
            {


                    command2 = new SqlCommand("sp_setClientNoForTR", conn);
                    command2.CommandType = CommandType.StoredProcedure;
                    command2.Parameters.Add("@ClientNo", SqlDbType.NVarChar, 50).Value = ClientNo;
                    command2.Parameters.Add("@BrokerCode", SqlDbType.NVarChar, 50).Value = BrokerCode;
   
                    command2.ExecuteNonQuery();


                    command = new SqlCommand("sp_setClientBrokerForTR", conn);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@ClientNo", SqlDbType.NVarChar, 50).Value = ClientNo;
                    command.Parameters.Add("@BrokerCode", SqlDbType.NVarChar, 50).Value = BrokerCode;
                    command.Parameters.Add("@LicDrv", SqlDbType.NVarChar, 50).Value = LicDrv;
                    command.ExecuteNonQuery();


                    SqlConnection jobConnection;
                    SqlCommand jobCommand;
                    SqlParameter jobReturnValue;
                    SqlParameter jobParameter;
                    int jobResult;
                    //data source=servername; initial catalog= msdb; persist security info=False; user id=sa; password=12345; packet size=4096
                    jobConnection = new SqlConnection("data source=10.16.8.9; initial catalog= msdb; persist security info=False; user id=sa; password=12345; packet size=4096");
                   // jobConnection = new SqlConnection("data source=10.16.8.9;Initial Catalog=msdb;Integrated Security=SSPI");
                    jobCommand = new SqlCommand("sp_start_job", jobConnection);
                    jobCommand.CommandType = CommandType.StoredProcedure;

                    jobReturnValue = new SqlParameter("@RETURN_VALUE", SqlDbType.Int);
                    jobReturnValue.Direction = ParameterDirection.ReturnValue;
                    jobCommand.Parameters.Add(jobReturnValue);

                    jobParameter = new SqlParameter("@job_name", SqlDbType.VarChar);
                    jobParameter.Direction = ParameterDirection.Input;
                    jobCommand.Parameters.Add(jobParameter);
                    jobParameter.Value = "ClientDailyTransfer";

                    jobConnection.Open();
                    jobCommand.ExecuteNonQuery();
                    jobResult = (Int32)jobCommand.Parameters["@RETURN_VALUE"].Value;
                    jobConnection.Close();

                    switch (jobResult)
                    {
                        case 0:
                            this.Msg = "โปรดรอประมาณ 2-5 นาที ขณะนี้กำลังดึงข้อมูลจากระบบ AS400 เข้าระบบ QuickLink. ";
                            this.msg2 = "ท่านสามารถตรวจสอบ Upload ได้ โดยคลิกปุ่ม \"ตรวจสอบการ Upload\" ";
                            break;
                        default:
                            this.Msg = "เกิดข้อผิดพลาดขึ้นขณะ Import ไฟล์!!!กรุณาติดต่อผู้ดูแลระบบ";
                            this.msg2 = "";
                            break;
                    }


                }
            

            catch (Exception ex)
            {
                this.Msg = "เกิดข้อผิดพลาดขึ้นขณะ Import ไฟล์!!!กรุณาติดต่อผู้ดูแลระบบ";
                this.Msg += "<br>" + ex.Message;
                throw ex;
                //return;
            }
            finally
            {
                conn.Close();
            }

        }
    }
    protected void btnCheckComplete_Click(object sender, EventArgs e)
    {
        SqlTransaction tx;
        SqlCommand command;
        SqlCommand command2;
        //SqlDataAdapter dataAdapter;
        clsConn clsConn = new clsConn();
        clsHelper clsHelper = new clsHelper();

        using (SqlConnection conn = clsConn.GetDataconnection(clsConn.Database.TestDBProductionConnectionString))
        {
            conn.Open();

            try
            {


                command2 = new SqlCommand("sp_getClientNoForTR", conn);
                command2.CommandType = CommandType.StoredProcedure;

                SqlParameter spReturnValue = new SqlParameter("@ClientNo", SqlDbType.VarChar, 50);
                spReturnValue.Direction = ParameterDirection.InputOutput;
                spReturnValue.Value = txbClientNo.Text;
                command2.Parameters.Add(spReturnValue);
                command2.Parameters.Add("@BrokerCode", SqlDbType.NVarChar, 50).Value = txbBrokerCode.Text;

                command2.ExecuteNonQuery();
                string ck = command2.Parameters["@ClientNo"].Value.ToString();

                if (ck == "1")
                {
                    lbStatus.Text = "Upload เรียบร้อยแล้วค่ะ ";
                    lbSearchPrintMsg.Text = "";
                }
                else
                {
                    lbStatus.Text = "รอสักครู่ค่ะ";
                }
            }
            catch (Exception ex)
            {
                this.Msg = "เกิดข้อผิดพลาดขึ้นขณะ Import ไฟล์!!!กรุณาติดต่อผู้ดูแลระบบ";
                this.Msg += "<br>" + ex.Message;
                throw ex;
                //return;
            }
            finally
            {
                conn.Close();
            }

        }
    }

    public void setSanctionClient(string Username, string Password, string ClientNo, string ClientType)
    {
        try
        {

            string Message = "";
            Message = ClientService.SanctionClient(Username, Password, ClientNo, ClientType, out Message);
            if (Message.Equals("SUCCESS"))
            {
                lbSearchPrintMsg.Text = "Sanction Client ในระบบ AS400 เรียบร้อยแล้ว";
            }
            else
            {
                lbSearchPrintMsg.Text = "เกิดข้อผิดพลาดเกิดขึ้นในการสร้างผู้ใช้รายใหม่  กรุณาติดต่อผู้ดูแลระบบ!!!";
                lbSearchPrintMsg.ForeColor = System.Drawing.Color.Red;
                lbSearchPrintMsg.Font.Bold = true;
                //CLEAR JOBNO
                //lbSearchPrintMsg.Text = "";
                return;
            }
        }
        catch
        {
            lbSearchPrintMsg.Text = "เกิดข้อผิดพลาดเกิดขึ้นในการสร้างผู้ใช้รายใหม่  กรุณาติดต่อผู้ดูแลระบบ!!!";
            lbSearchPrintMsg.ForeColor = System.Drawing.Color.Red;
            lbSearchPrintMsg.Font.Bold = true;
            //CLEAR JOBNO
            //lbJobNoContent.Text = "";
            return;
        }
        //***** END SANCTION AS/400 *****
    }
    protected void DefaultPageRegisterClientScript()
    {
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptScrolling", "MenuScroll();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptTxtFocus", "setFocusTextbox();", true);
        //ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDrawCorner", "DrawDivCorner();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDisplayMsg", "DisplayWarning();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDatePicker", "<script type='text/javascript' language='javascript'>  $(document).ready(function () {  $('.MOTOR').find('img').attr('src', '../Images/Index/MOTOR1.png');  $('.MOTOR').find('a').css('color', '#922d3d'); $('.MOTOR').hover( function () { $(this).find('img').attr('src', '../Images/Index/MOTOR1.png'); } , function () { $(this).find('img').attr('src', '../Images/Index/MOTOR1.png'); } );addSubMenu('hdnMotor', '.subNavigate', 'สร้างกรมธรรม์', '');Accordion('.wizard', 'hdnCriteriaStep');});</script>", false);
    }
}