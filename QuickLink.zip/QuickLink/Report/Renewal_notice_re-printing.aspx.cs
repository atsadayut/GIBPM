using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class report_Renewal_notice_re_printing : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.DefaultPageRegisterClientScript();

    }
    protected void GridViewDocument_RowDataBound(object sender, GridViewRowEventArgs e)
    {
    }
    private DataTable SearchBlinding()
    {

        string sql = "";
        sql = " select tbl_RenewalNotice.CHDRNUM as �����Ţ��������,tbl_RenewalNotice.CCDATE as �ѹ����ش����������ͧ,tbl_RenewalNotice.Z2INSNM as Insured_name,tbl_RenewalNotice.REGNO as �Ţ����¹ö ";
        sql += " from tbl_RenewalNotice INNER JOIN dbo.tbl_MainBrokerIndex d2 on tbl_RenewalNotice.AGNTNUM = d2.BROKERCODE  ";
        sql += "WHERE tbl_RenewalNotice.CHDRNUM <> '' ";
        if (txbPolicyFrom.Text.Length > 0)
        {
            sql += "AND tbl_RenewalNotice.CHDRNUM BETWEEN '" + this.txbPolicyFrom.Text + "' AND '" + this.txbPolicyTo.Text + "'";
        }
        if (this.DPExpiryDateFrom.CalendarDateString.Length > 0 && this.DPExpiryDateTo.CalendarDateString.Length > 0)
        {
            sql += "AND tbl_RenewalNotice.CCDATE BETWEEN '" + this.DPExpiryDateFrom.CalendarDateString.Substring(6, 4) + this.DPExpiryDateFrom.CalendarDateString.Substring(3, 2) + this.DPExpiryDateFrom.CalendarDateString.Substring(0, 2)
                + "' AND '" + this.DPExpiryDateTo.CalendarDateString.Substring(6, 4) + this.DPExpiryDateTo.CalendarDateString.Substring(3, 2) + this.DPExpiryDateTo.CalendarDateString.Substring(0, 2) + "'";
        }
        if (txbInsuredName.Text.Length > 0)
        {
            sql += " AND tbl_RenewalNotice.Z2INSNM like '%" + this.txbInsuredName.Text + "%' ";
        }
        if (txbPlateNumber.Text.Length > 0){
        sql += " AND tbl_RenewalNotice.REGNO like '%" + this.txbPlateNumber.Text + "%' ";}
        sql += " AND d2.GROUPBROKERID = '" + Utilities.GetGroupBrokerID().Trim() + "' GROUP BY tbl_RenewalNotice.CHDRNUM,tbl_RenewalNotice.CCDATE,tbl_RenewalNotice.Z2INSNM,tbl_RenewalNotice.REGNO ";


        SqlConnection connection = new SqlConnection(WebConfigurationManager.ConnectionStrings["LocalSqlServerAXA"].ConnectionString);
        if (connection.State == ConnectionState.Open) connection.Close();
        connection.Open();

        SqlDataAdapter DataAdapter = new SqlDataAdapter(sql, connection);
        DataTable table = new DataTable();

        DataAdapter.Fill(table);
        connection.Close();
        return table;
    }
    protected void GridViewDocument_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridViewDocument.PageIndex = e.NewPageIndex;
        GridViewDocument.DataBind();
        ShowGrid();
    }

    private void ShowGrid()
    {
        DataTable tempdt = SearchBlinding();
        if (tempdt.Rows.Count > 0)
        {
            ViewState["Table"] = tempdt;
            this.GridViewDocument.DataSource = (DataTable)ViewState["Table"];
            this.GridViewDocument.DataBind();
            GridViewDocument.Visible = true;
            ShowData.Style.Add("visibility", "visiable");
            for (int i = 0; i < GridViewDocument.Rows.Count; i++)
            {
                GridViewDocument.Rows[i].Cells[2].Text = GridViewDocument.Rows[i].Cells[2].Text.Substring(6, 2)+"/"+GridViewDocument.Rows[i].Cells[2].Text.Substring(4, 2)+"/"+GridViewDocument.Rows[i].Cells[2].Text.Substring(0, 4);
            }
        }
        else
        {
            this.GridViewDocument.DataSource = null;
            this.GridViewDocument.DataBind();
        }
        
    }
    private void GridViewHeader()
    {
        GridViewDocument.Columns[0].HeaderText = "�ô���͡";
   

    }
    protected void btnPrint_Click(object sender, EventArgs e)
    {

        

        string parameter = "";
        parameter += "&PolicyNoFrom=" + txbPolicyFrom.Text.Trim();
        parameter += "&PolicyNoTo=" + txbPolicyTo.Text.Trim();
        if (DPExpiryDateFrom.CalendarDateString.Length > 0)
        {
            parameter += "&ExprilyDateFrom=" + DPExpiryDateFrom.CalendarDateString.Substring(6, 4) + DPExpiryDateFrom.CalendarDateString.Substring(3, 2) + DPExpiryDateFrom.CalendarDateString.Substring(0, 2);
            parameter += "&ExprilyDateTo=" + DPExpiryDateTo.CalendarDateString.Substring(6, 4) + DPExpiryDateTo.CalendarDateString.Substring(3, 2) + DPExpiryDateTo.CalendarDateString.Substring(0, 2);
        }
        else {
            parameter += "&ExprilyDateFrom="; 
            parameter += "&ExprilyDateTo="; 
        }
        parameter += "&InsuredName=" + txbInsuredName.Text.Trim();
        parameter += "&LicenceNo=" + txbPlateNumber.Text.Trim();
        parameter += "&GroupBroker=" + Utilities.GetGroupBrokerID().Trim();


        //for (int i = 0; i < GridViewDocument.Rows.Count; i++)
        //{
        //    CheckBox tmp = (CheckBox)GridViewDocument.Rows[i].FindControl("ChkSelected");
        //    if (tmp.Checked)
        //    {
        //        parameter += "&PolicyNo" + (i+1) + "=" +GridViewDocument.Rows[i].Cells[1].Text;
        //    }
        //    else
        //    {
        //        parameter += "&PolicyNo" + (i + 1) + "=";
        //    }
           
        //}
        ClientScript.RegisterStartupScript(this.Page.GetType(),"",
        "window.open ('" + WebConfigurationManager.AppSettings["UrlReportingService"].ToString() + "re_renewal_notice2&rs:Format=PDF" + parameter + "')",true);
        this.DefaultPageRegisterClientScript();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        ShowGrid();
    }

    protected void DefaultPageRegisterClientScript()
    {
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptScrolling", "MenuScroll();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptTxtFocus", "setFocusTextbox();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDisplayMsg", "DisplayWarning();", true);
        ScriptManager.RegisterStartupScript(this.Page, typeof(string), "DefaultPageScriptDatePicker", "<script type='text/javascript' language='javascript'>  $(document).ready(function () {  $('.MOTOR').find('img').attr('src', '../Images/Index/MOTOR1.png');  $('.MOTOR').find('a').css('color', '#922d3d'); $('.MOTOR').hover( function () { $(this).find('img').attr('src', '../Images/Index/MOTOR1.png'); } , function () { $(this).find('img').attr('src', '../Images/Index/MOTOR1.png'); } );addSubMenu('hdnMotor', '.subNavigate', '��§ҹ', '');Accordion('.wizard', 'hdnCriteriaStep');});</script>", false);
    }
}
