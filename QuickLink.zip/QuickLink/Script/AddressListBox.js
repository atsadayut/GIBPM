﻿
function AjaxGetData(url, responseHandler)
{
    if (window.XMLHttpRequest)
     {
         // browser has native support for XMLHttpRequest object
         req = new XMLHttpRequest();
     }
     else if (window.ActiveXObject)
     {
         // try XMLHTTP ActiveX (Internet Explorer) version
         req = new ActiveXObject("Microsoft.XMLHTTP");
     }
     
     if(req)
     {
         req.onreadystatechange = responseHandler;
         req.open('GET', url, true);
         req.setRequestHeader("content-type","application/x-www-form-urlencoded");
         req.send('');
     }
     else
     {
         alert('Your browser does not seem to support XMLHttpRequest.');
     }
 } 
 function timeHandler()
 {
 try
    {
        //readyState of 4 or 'complete' represents 
        //that data has been returned 
        if (req.readyState == 4 || 
            req.readyState == 'complete')
        {
            //document.getElementById('Amphur').innerHTML = req.responseText; 
            AmphurAll = req.responseText
            AmphurList = AmphurAll.split('||');
            ClearItem("Amphure");            
            ClearItem("Tumbol");
            AddItemTumbol("","")
            for(i=0;i<AmphurList.length;i+=2){
                AddItem(AmphurList[i],AmphurList[i+1])
            }            
         }
    }
     catch(e)
     {
        //alert('Error in Ajax respone');
     }
}      
function timeHandlerTumbol()
 {
 try
    {
        //readyState of 4 or 'complete' represents 
        //that data has been returned 
        if (req.readyState == 4 || 
            req.readyState == 'complete')
        {
            //document.getElementById('TumbolT').innerHTML = req.responseText; 
            TumbolAll = req.responseText
            TumbolList = TumbolAll.split('||');
            ClearItem("Tumbol");
            for(i=0;i<TumbolList.length;i+=2){
                AddItemTumbol(TumbolList[i],TumbolList[i+1]);
            }
            
        }
    }
     catch(e)
     {
        //alert('Error in Ajax respone');
     }
}    
function getAmphur(provinceid){
    urlA = "ajax.ashx?what=time&provincid="+provinceid;
    //alert(urlX);
    AjaxGetData(urlA,timeHandler);

}
function getTumbol(Amphurid){
    urlT = "GetTumbol.ashx?what=time&amphurid="+Amphurid;
    //alert(urlT);
    AjaxGetData(urlT,timeHandlerTumbol);

}
 function AddItem(Text,Value)
    {
        // Create an Option object                
        var opt = document.createElement("option");

        // Add an Option object to Drop Down/List Box
        document.getElementById("Amphure").options.add(opt);        // Assign text and value to Option object
        opt.text = Text;
        opt.value = Value;

 }
  function AddItemTumbol(Text,Value)
    {
        // Create an Option object                
        var opt = document.createElement("option");

        // Add an Option object to Drop Down/List Box
        document.getElementById("Tumbol").options.add(opt);        // Assign text and value to Option object
        opt.text = Text;
        opt.value = Value;

 }
 function ClearItem(EleDropDownList){
     var len = document.getElementById(EleDropDownList).options.length
     for(i=len-1; i>=0; i--)
     {
        document.getElementById(EleDropDownList).options.remove(i);
     } 
 }
 
