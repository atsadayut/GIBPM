﻿
function AjaxGetData(url, responseHandler)
{
    if (window.XMLHttpRequest)
     {
         // browser has native support for XMLHttpRequest object
         req = new XMLHttpRequest();
     }
     else if (window.ActiveXObject)
     {
         // try XMLHTTP ActiveX (Internet Explorer) version
         req = new ActiveXObject("Microsoft.XMLHTTP");
     }
     
     if(req)
     {
         req.onreadystatechange = responseHandler;
         req.open('GET', url, true);
         req.setRequestHeader("content-type","application/x-www-form-urlencoded");
         req.send('');
     }
     else
     {
         alert('Your browser does not seem to support XMLHttpRequest.');
     }
 } 
 function timeHandler()
 {
 try
    {
        //readyState of 4 or 'complete' represents 
        //that data has been returned 
        if (req.readyState == 4 || 
            req.readyState == 'complete')
        {
            document.getElementById('Label1').innerHTML = req.responseText;     
         }
    }
     catch(e)
     {
        //alert('Error in Ajax respone');
     }
}      
  
function CheckID(txb){
    var txb = document.getElementById(txb);
    var code = txb.value;
    urlA = "CheckCode.ashx?what=time&code="+code;
    //alert(urlX);
    AjaxGetData(urlA,timeHandler);

}

 
