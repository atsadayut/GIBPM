﻿function setMultiview(showView,mView){
    arrView = mView.split(',');
    for(i=0;i<arrView.length;i++){
        document.getElementById(arrView[i]).style.display = "none";
    }
    document.getElementById(showView).style.display = "block";    
}
function setViewCheckbox(status,target){
    if(status){
        document.getElementById(target).style.display = "block";
    }
    else{
        document.getElementById(target).style.display = "none";
    }
}
function getTooltip(){
  var newdiv = document.createElement('div');
  var divIdName = 'myDiv';
  newdiv.setAttribute('id',divIdName);
  newdiv.innerHTML = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
  document.getElementById('jjj').innerHTML = "tessdfsdf";
}
//getTooltip()

function setViewShowOrHide(status,target){
    if(status){
        document.getElementById(target).style.display = "block";
    }
    else{
        document.getElementById(target).style.display = "none";
    }
}