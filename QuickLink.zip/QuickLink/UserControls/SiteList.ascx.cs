using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class SiteList : System.Web.UI.UserControl
{
    // Load menu details into the DataList
    DataTable dt;
    DataView dv;
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            // don't reload data during postbacks
            string UserName = Utilities.GetUsername();
            string[] r = null;
            r = Roles.GetRolesForUser(UserName);
            string rolename = "";
            if (!Page.IsPostBack)
            {
                if (r.Length > 0)
                {
                    rolename = r[0].ToString().Trim();
                    Session["role"] = rolename.Trim();


                    dt = new DataTable();
                    dt = MenuAccess.GetMenuListByRole2(rolename);
                    dv = dt.DefaultView;
                    Session.Add("DataViewSiteList", dv);
                    list.DataSource = dv;
                    // Needed to bind the data bound controls to the data source
                    list.DataBind();
                }
                else
                {
                    if (UserName.Trim().Equals(""))
                    {
                        list.DataSource = null;
                        list.DataBind();
                    }
                }
            }
            else
            {
                dv = (DataView)Session["DataViewSiteList"];
                list.DataSource = dv;
                list.DataBind();
            }
        }
        catch
        {
            // for error 
        }
    }
}
