using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class MenuList : System.Web.UI.UserControl
{
    public string groupmenuName;
    protected void Page_Load(object sender, EventArgs e)
    {
        // don't reload data during postbacks
        if (!IsPostBack)
        {
            // Obtain the ID of the selected Group ID
            string GroupMenuId = Request.QueryString["GroupMenuId"];
            // Continue only if Group ID exists in the query string
            if (GroupMenuId != null)
            {
                // category data, which is displayed by the DataList
                list.DataSource = MenuAccess.GetMenuInGroupMenu(GroupMenuId);
                // Needed to bind the data bound controls to the data source
                list.DataBind();
                groupmenuName = MenuAccess.GetGroupMenuNameByGroupMenuId(GroupMenuId);

            }
        }
    }
}
