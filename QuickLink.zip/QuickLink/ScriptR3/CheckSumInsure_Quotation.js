﻿
function AjaxGetData(url, responseHandler)
{
    if (window.XMLHttpRequest)
     {
         // browser has native support for XMLHttpRequest object
         req = new XMLHttpRequest();
     }
     else if (window.ActiveXObject)
     {
         // try XMLHTTP ActiveX (Internet Explorer) version
         req = new ActiveXObject("Microsoft.XMLHTTP");
     }
     
     if(req)
     {
         req.onreadystatechange = responseHandler;
         req.open('GET', url, true);
         req.setRequestHeader("content-type","application/x-www-form-urlencoded");
         req.send('');
     }
     else
     {
         alert('Your browser does not seem to support XMLHttpRequest.');
     }
 } 
 function timeHandler1() {
 var ClassType = "Class 1";
 try
    {
        //readyState of 4 or 'complete' represents 
        //that data has been returned 
        if (req.readyState == 4 || 
            req.readyState == 'complete')
        { 
                
                var result = req.responseText;
                arrInsure = result.split(",");
   
                document.getElementById('ctl00_MainContent_txbSumInsure').value = arrInsure[0];      
                document.getElementById('ctl00_MainContent_lbMessageSumInsure').innerHTML = arrInsure[1];         

                if(ClassType.substring(0,7) == "Class 1" )
                {
                    document.getElementById('ctl00_MainContent_txbHdOD_CoSi').value = arrInsure[0];;
                    document.getElementById('ctl00_MainContent_txbHdFT_TfSi').value = arrInsure[0];;
                    document.getElementById('ctl00_MainContent_txbHdODSI').value = "0";                   
                }  
        }
    }
     catch(e)
     {
        //alert('Error in Ajax respone');
     }
} 

function timeHandlerBasic1()
 {
 var ClassType = "Class 1";  //Fiexd
 try
    {
        //readyState of 4 or 'complete' represents 
        //that data has been returned 
        if (req.readyState == 4 || 
            req.readyState == 'complete')
        {
            var arr1 = new Array();
            var result = req.responseText;
            arr1 = result.split(",");
            //document.write(result);

            if (arr1[0]=="default")
            {
                  //----------------------Bind SumInsure 85%---------------------------------
                  document.getElementById('ctl00_MainContent_txbSumInsure').value =arr1[1];
                  //----------------------Bind SumInsusre 100%-------------------------------
                  document.getElementById('ctl00_MainContent_txbHdNetSumInsure').value = arr1[11];

                  if(ClassType.substring(0,7) == "Class 1" ){
                    document.getElementById('ctl00_MainContent_lbMessageSumInsure').innerHTML = "ทุนประกันเริ่มต้น 80% ของราคาตลาด";
                   
                    
                    document.getElementById('ctl00_MainContent_txbHdOD_CoSi').value = arr1[1];
                    document.getElementById('ctl00_MainContent_txbHdFT_TfSi').value = arr1[1];
                    document.getElementById('ctl00_MainContent_txbHdODSI').value = "0";
                    
                  }

                  //-----------------------------------------------------------------------
                  //----------------------------------FILL ค่า--------- --------------------
                  //-----------------------------------------------------------------------

                  document.getElementById('ctl00_MainContent_lbMakeDesc').innerText = arr1[2];

                  document.getElementById('ctl00_MainContent_txbHdMakeDesc').value = arr1[2];

                  document.getElementById('ctl00_MainContent_txbHdMinimumPremium_C1').value = arr1[3];
                  document.getElementById('ctl00_MainContent_txbHdMotorBody_C1').value = arr1[4];
                  document.getElementById('ctl00_MainContent_txbHdMotorSeat_C1').value = arr1[5];
                  document.getElementById('ctl00_MainContent_txbHdMotorPD_C1').value = arr1[6];
                  document.getElementById('ctl00_MainContent_txbHdMotorCC_C1').value = arr1[7];
                  document.getElementById('ctl00_MainContent_txbHdMotorTong_C1').value = arr1[8];
                  document.getElementById('ctl00_MainContent_txbHdOtherDiscount_C1').value = arr1[9];
                  document.getElementById('ctl00_MainContent_txbVehicleKey').value = arr1[12];
                  
            }
            else
            {
                  document.getElementById('ctl00_MainContent_lbMessageSumInsure').innerHTML = req.responseText; 
                  document.getElementById('ctl00_MainContent_txbSumInsure').value =""; 
                  document.getElementById('ctl00_MainContent_lbMakeDesc').innerText = "";                    
            }
            if(req.responseText=="ท่านเลือกรถ หรือ ปีรุ่น ไม่ถูกต้อง")
            {
                document.getElementById('ctl00_MainContent_txbHdMotorBody_C1').value = "";
                document.getElementById('ctl00_MainContent_txbHdMotorSeat_C1').value = "";
                document.getElementById('ctl00_MainContent_txbHdMotorPD_C1').value = "";
                document.getElementById('ctl00_MainContent_txbHdMotorCC_C1').value = "";
                document.getElementById('ctl00_MainContent_txbHdMotorTong_C1').value = "";
                document.getElementById('ctl00_MainContent_txbHdMinimumPremium_C1').value = "";
                document.getElementById('ctl00_MainContent_txbHdOtherDiscount_C1').value = "";
                document.getElementById('ctl00_MainContent_txbVehicleKey').value = "";
            }
        }
    }
     catch(e)
     {
        //alert('Error in Ajax respone');
     }
}

function CheckPremiumSumInsure(txb,makecode,val,year,ncb){
//-------------------------------------------------------------
//------ฟังก์ชั่นไว้ส่งค่าไปคำนวณค่า SumInsure ใน Class CheckSumInsure_Quotation
    //-------------------------------------------------------------

    
    var makecode = document.getElementById(makecode).value;
    var modelyear = document.getElementById(year).value;
    if (makecode == "" && modelyear == "") {
        document.getElementById('ctl00_MainContent_lbMessageSumInsure').innerHTML = "กรุณาเลือกรถยนต์/รุ่น";
    }
    else {
        var vNcb = document.getElementById(ncb).value;
        //---------------------------------------------------------
        var txb = document.getElementById(txb);
        var motorcode = makecode;
        var premium = txb.value;
        //---------------------------------------------------------
        //แก้ไข-วันที่ 2010-08-14
        //var PackageType = document.getElementById('ctl00_MainContent_cmbPackageType').value.substring(0, 7);
        var PackageType = "Class 1";
        //แก้ไข-วันที่ 2010-08-14
        //var motorGarage = document.getElementById('ctl00_MainContent_txbHdMotorGarageType_C1').value;
        var motorGarage = "อู่ห้าง";
        //แก้ไข-วันที่ 2010-08-14
        //var vehicle = document.getElementById('ctl00_MainContent_txbHdVehicleTypeValue').value;
        var vehicle = "Sedan";
        //แก้ไข-วันที่ 2010-08-14
        //----------------------------------------------------------

        if (motorGarage == "อู่ห้าง") {
            motorGarage = "1";
        }
        else {
            if (motorGarage == "อู่ประกัน") {
                motorGarage = "2";
            } else {
                //ไม่มีหรือไม่เลือก
                motorGarage = "3";
            }
        }
        //----------------------------------
        urlA = "CheckSumInsure_Quotation.ashx?what=time&motorcode=" + motorcode + "&year=" + modelyear + "&premium=" + premium + "&packagetype=" + PackageType + "&motorgarage=" + motorGarage + "&vehicle=" + vehicle + "&NCB=" + vNcb;
        //alert(urlX);
        
        if (val == '1') {
            AjaxGetData(urlA, timeHandler1);
        }
    }
}

function CheckPremiumSumInsureBasic(makecode, val, year, ncb) {
    //-------------------------------------------------------------
    //------ฟังก์ชั่นไว้ส่งค่าไปคำนวณค่า SumInsure ใน Class CheckSumInsureBasic_Quotation
    //-------------------------------------------------------------
    
    var makecode = document.getElementById(makecode).value;
    var modelyear = document.getElementById(year).value;
    if (makecode == "" && modelyear == "") {
        document.getElementById('ctl00_MainContent_lbMessageSumInsure').innerHTML = "กรุณาเลือกรถยนต์/รุ่น";
    }
    else {
   
        var vNcb = document.getElementById(ncb).value;
        //แก้ไข-วันที่ 2010-08-14
       
         
        var PackageType = "Class 1";
        //แก้ไข-วันที่ 2010-08-14
        var motorGarage = "อู่ห้าง";
        //แก้ไข-วันที่ 2010-08-14
        var vehicle = "Sedan";
        //แก้ไข-วันที่ 2010-08-14

        if (motorGarage == "อู่ห้าง") {
            motorGarage = "1";
        }
        else {
            if (motorGarage == "อู่ประกัน") {
                motorGarage = "2";
            } else {
                motorGarage = "3";
            }
        }
        var motorcode = makecode;
        urlA = "CheckSumInsureBasic_Quotation.ashx?what=time&motorcode=" + motorcode + "&year=" + modelyear + "&packagetype=" + PackageType + "&motorgarage=" + motorGarage + "&vehicle=" + vehicle + "&NCB=" + vNcb;
        //alert(urlX);

        //แก้ไข-วันที่ 2010-08-14
        if (CheckMakeCodeSmartDrive5(PackageType, modelyear, motorGarage)) {
            if (val == '1') {
                AjaxGetData(urlA, timeHandlerBasic1);
            }
        }
    }
}

//----------------------------------------------------------------------------
//------------------ต่อไปนี้คือ ฟังก์ชั่น ที่ใช้ในการใส่ ',' ให้ตัวเลข--------------------------
//----------------------------------------------------------------------------
function addNumber(Number){
    /* ถ้าต้องการใช้ เรียกใช้ใน หน้า asp ต้องเปลี่ยน parameter เป็น (ID,Text)
    และเปลี่ยน Number เป็น Number.value
    var NumClientID = "ctl00_"+ID+"_"+Text;
    //alert(document.getElementById(NumClientID));
    var Number = document.getElementById(NumClientID);*/
    
    var OutputNumber = "";
    var tmp="";
    var FloatingPoint = ".00";
    
    Number = cutSemi(Number);
    if(getfloatingPoint(Number) == -1){
        FloatingPoint = ".00";
    }else{
        
        FloatingPoint = getfloatingPoint(Number);
        FloatingPoint = parseFloat(FloatingPoint).toFixed(2);
        FloatingPoint = getfloatingPoint(FloatingPoint);
    }
    Number = cutFloatingPoint(Number);
    
    Number = revert(Number);
    
    for(var i=0;i<Number.length;i++){
        tmp += Number.charAt(i);
        if(((i+1)%3) == 0){
            OutputNumber += tmp;
            OutputNumber += ",";
            tmp ="";
        }
    }
    OutputNumber += tmp;
    
    
    OutputNumber =revert(OutputNumber);
    if(OutputNumber.charAt(0) == ","){
        OutputNumber = OutputNumber.substr(1,OutputNumber.length);
    }
    OutputNumber += FloatingPoint;
    Number = OutputNumber;
    return Number;
    
}
function revert(text){
    var tmp = "";
    for(var i=text.length;i >= 0;i--){
        tmp += text.charAt(i);
    }
    return tmp;
}
function cutSemi(text){
var tmp = "";
    for(var i =0;i<text.length;i++){
        if(text.charAt(i) != ","){
            tmp += text.charAt(i);
        }
    }
    return tmp;
}

function cutFloatingPoint(text){
    var tmp = "";
    for(var i =0;i<text.length;i++){
        if(text.charAt(i) != "."){
            
            tmp += text.charAt(i);
        }else break;
        
    }
    return tmp;
}
function getfloatingPoint(text){
    var tmp = "";
    var i = 0;
    for(var i = 0;i<text.length;i++){
        if(text.charAt(i) == ".") break;
    }
    if(i == text.length){
        
        return -1;
    }
    
    for(var j = i;j<text.length;j++){
        tmp += text.charAt(j);
    }
    return tmp;
}
 
//----------------------------------------------------------------------------
//------------------------ต่อไปนี้คือ ฟังก์ชั่น ที่เล่นกับ PD OD----------------------------
//----------------------------------------------------------------------------
function CheckOD_PD(combobox,label){
//cmbOD_Deduct
//cmbPD_Deduct
//lbPD_Deduct_C1
//lbOD_Deduct_C1
    var cmbSelect = document.getElementById(combobox);
    var showMoney = document.getElementById(label);
    var NetPremium = document.getElementById('ctl00_MainContent_txbHdNetSumInsure').value;

//    if(eval(cmbSelect.value) > eval(NetPremium))
//    {
//        window.alert("ค่าที่คุณเลือกมีค่ามากกว่า ราคารถ");
//        document.getElementById('ctl00_MainContent_lbPD_Deduct_C1').innerText = "0.00";
//        document.getElementById('ctl00_Maincontent_lbOD_Deduct_C1').innerText = "0.00";
//    }
    //else
    //{
        showMoney.innerText = addNumber(cmbSelect.value);
    //}
}

function CheckPremiumSumInsureSmartDrive5(cmbODSIandFT){
    var SumInsureSelected = document.getElementById(cmbODSIandFT).value;
    var makecode = document.getElementById('ctl00_MainContent_txbVehicleKey').value;
    var modelyear = document.getElementById('ctl00_MainContent_txbRegYear').value;   
    var PackageType = document.getElementById('ctl00_MainContent_cmbPackageType').value;
    var motorGarage = "อู่ห้าง";
    var vehicleType = "";
    if (document.getElementById('ctl00_MainContent_txbHdMotorBody_C1').value == "TRUCK") { document.getElementById('ctl00_MainContent_txbHdMotorBody_C1').value = "PICKUP" }

    if (document.getElementById('ctl00_MainContent_txbHdMotorCC_C1').value > 2000) {
        if (document.getElementById('ctl00_MainContent_txbHdMotorBody_C1').value == "SEDAN")
        { vehicleType = "Sedan (2+1)>2000cc"; }
        else if (document.getElementById('ctl00_MainContent_txbHdMotorBody_C1').value == "PICKUP") 
        { vehicleType = "Pickup (2+1)"; }
        else { vehicleType = "Van(2 + 1"; }
    } else {
    if (document.getElementById('ctl00_MainContent_txbHdMotorBody_C1').value == "SEDAN")
    { vehicleType = "Sedan (2+1)<=2000cc"; }
    else if (document.getElementById('ctl00_MainContent_txbHdMotorBody_C1').value == "PICKUP")
    { vehicleType = "Pickup (2+1)"; }
    else { vehicleType = "Van(2 + 1"; }
     }


    var vehicleType = "txbHdMotorCC_C1"; //document.getElementById('ctl00_MainContent_cmbVehicle').value;
    var useOfVehicle = document.getElementById('ctl00_MainContent_rdoAction').value;
    //alert(vehicleType.substr(0,5));
    if(motorGarage == "อู่ห้าง"){
        motorGarage = "1";
    }
    else
    {
        if(motorGarage == "อู่ประกัน")
        {
            motorGarage = "2";
        }else
        {
            motorGarage = "3";
        }
    }
    urlA = "CheckSumInsureSmartDrive5_Quotation.ashx?what=time&motorcode="+makecode+"&year="+modelyear+"&packagetype="+PackageType;
    urlA += "&motorGarage="+motorGarage+"&vehicleType="+vehicleType+"&useOfVehicle="+useOfVehicle+"&SumInsureSelected="+SumInsureSelected;
    //alert(urlX);
    
    //UPDATE 2009-=08-05
//    if(cmbODSIandFT == 'ctl00_MainContent_cmbSumInsureODSI'){
//        AjaxGetData(urlA,FillDataSmartDrive5ODSI); 
//    }else{
//        AjaxGetData(urlA,FillDataSmartDrive5FTSI);
//    }
      if(CheckMakeCodeSumInsureSmartDrive5(PackageType.substring(0,7),modelyear,motorGarage))
      {
          if (cmbODSIandFT == 'ctl00_MainContent_cmbSmartDriive5') {
            AjaxGetData(urlA,FillDataSmartDrive5ODSI); 
        }else{
            AjaxGetData(urlA,FillDataSmartDrive5FTSI);
        }
      }
    else {
        var strTmp = document.getElementById('ctl00_MainContent_txbSumInsure').value; //((parseInt(document.getElementById('ctl00_MainContent_txbSumInsure').value) / 50000) * 50000) - 50000;

        var IndexValue = document.getElementById(cmbODSIandFT);
        var varODandFT = IndexValue.options[IndexValue.selectedIndex].text;
        if (parseInt(varODandFT) >= parseInt(strTmp)) {
            if (cmbODSIandFT == 'ctl00_MainContent_cmbSmartDriive5') {
                AjaxGetData(urlA, FillDataSmartDrive5ODSI);
            } else {
                AjaxGetData(urlA, FillDataSmartDrive5FTSI);
            }

//            document.getElementById(cmbODSIandFT).value = "200000";
//            alert("OD SI หรือ F&T SI ไม่เกิน 85% ของราคารถ ไม่เกิน " + strTmp + " บาท");
        }
        //document.getElementById('ctl00_MainContent_cmbSumInsureFTSI').value = "0";
//        document.getElementById('ctl00_MainContent_txbHdPremiumSmartDrive5').value = "0";
//        document.getElementById('ctl00_MainContent_lbODSI_C1').innerText = "0.00";
//        document.getElementById('ctl00_MainContent_lbFT_C1').innerText = "0.00";
//        document.getElementById('ctl00_MainContent_txbHdOtherDiscount_C1').innerText="0";
//        document.getElementById('ctl00_MainContent_txbHdOD_CoSi').value = "0";
//        document.getElementById('ctl00_MainContent_txbHdFT_TfSi').value = "0";
//        document.getElementById('ctl00_MainContent_txbHdODSI').value = "0";
     }
}
function FillDataSmartDrive5ODSI(){
    var ClassType = "Class 5 (2+1)"; //document.getElementById('ctl00_MainContent_cmbPackageType').value;
 try
    {
        //readyState of 4 or 'complete' represents 
        //that data has been returned 
        if (req.readyState == 4 ||  req.readyState == 'complete')
        {
            var arr1 = new Array();
            var result = req.responseText;
            arr1 = result.split(",");
            var ODSI;
            if (arr1[0]=="default")
            {
                //-----------------------------------------------------------------------
                //----------------------Bind SumInsure 85%---------------------------------
                ODSI = document.getElementById('ctl00_MainContent_cmbSmartDriive5').value;

                //----------------------Bind SumInsusre 100%-------------------------------
                document.getElementById('ctl00_MainContent_txbHdNetSumInsure').value = arr1[2];

                //----------ตรวจสอบว่า ข้อมูลรถนี้ เป็นของ Class 5 (2+1) ไม่แสดงข้อความ บอก ค่าเริ่มต้น
                //--------- OD = 0, FT = sumInsur, ODSI = sumInsure;
                //----------------------------------------------------------------
                //----------ตรวจสอบว่า ข้อมูลรถนี้ เป็นของ Class 5 (3+1) ไม่แสดงข้อความ บอก ค่าเริ่มต้น
                //--------- OD = 0, FT = 0, ODSI = sumInsure;
                document.getElementById('ctl00_MainContent_lbMessageSumInsure').innerHTML = "";
                if(ClassType.substring(0,13) == "Class 5 (2+1)")
                {
                    document.getElementById('ctl00_MainContent_txbHdOD_CoSi').value = "0";    
                    document.getElementById('ctl00_MainContent_txbHdFT_TfSi').value = ODSI;
                    document.getElementById('ctl00_MainContent_cmbSmartDriive5').value = ODSI;
                    document.getElementById('ctl00_MainContent_txbHdODSI').value = ODSI;
                }
                else
                {
                    if(ClassType.substring(0,13) == "Class 5 (3+1)")
                    { 
                        document.getElementById('ctl00_MainContent_txbHdOD_CoSi').value = "0";
                        document.getElementById('ctl00_MainContent_txbHdFT_TfSi').value = "0";
                        document.getElementById('ctl00_MainContent_cmbSmartDriive5FTSI').value = "0";
                        document.getElementById('ctl00_MainContent_txbHdODSI').value = ODSI;
                    }
                    else
                    {
                        document.getElementById('ctl00_MainContent_txbHdOD_CoSi').value = "0";
                        document.getElementById('ctl00_MainContent_txbHdFT_TfSi').value = "0";
                        document.getElementById('ctl00_MainContent_txbHdODSI').value = "0";
                    }
                }  
              //-----------------------------------------------------------------------
              //----------------------------------FILL ค่า--------- --------------------
              //-----------------------------------------------------------------------
//              document.getElementById('ctl00_MainContent_lbOD_C1').innerText = addNumber(document.getElementById('ctl00_MainContent_txbHdOD_CoSi').value);
//              document.getElementById('ctl00_MainContent_lbFT_C1').innerText = addNumber(document.getElementById('ctl00_MainContent_txbHdFT_TfSi').value);
//              document.getElementById('ctl00_MainContent_lbODSI_C1').innerText = addNumber(document.getElementById('ctl00_MainContent_txbHdODSI').value);

              //-----------------------------------------------------------------------

              document.getElementById('ctl00_MainContent_txbHdPremiumSmartDrive5').value = arr1[4];

              document.getElementById('ctl00_MainContent_txbHdOtherDiscount_C1').value = arr1[5];
    
            }
            else
            {
                  document.getElementById('ctl00_MainContent_lbMessageSumInsure').innerHTML = req.responseText; 
                  //document.getElementById('ctl00_MainContent_txbSumInsure').value =""; 
                  document.getElementById('ctl00_MainContent_cmbSmartDriive5').value = "100000";
                  document.getElementById('ctl00_MainContent_cmbSmartDriive5FTSI').value = "100000";
//                  document.getElementById('ctl00_MainContent_lbODSI_C1').innerText = "0.00";
//                  document.getElementById('ctl00_MainContent_lbFT_C1').innerText = "0.00";
//                  document.getElementById('ctl00_MainContent_txbHdOtherDiscount_C1').innerText="0";
//                  document.getElementById('ctl00_MainContent_txbHdOD_CoSi').value = "0";
//                  document.getElementById('ctl00_MainContent_txbHdFT_TfSi').value = "0";
//                  document.getElementById('ctl00_MainContent_txbHdODSI').value = "0";
//                  document.getElementById('ctl00_MainContent_txbHdNetSumInsure').value = "0";
//                  document.getElementById('ctl00_MainContent_txbHdPremiumSmartDrive5').value= "0";
                  
                  //document.getElementById('ctl00_MainContent_hdMinimumPremium_C1').innerText = "";
                  
            }
            if(req.responseText=="คุณระบุเลือกรถ หรือ ปีรุ่น ไม่ถูกต้อง")
            {
                document.getElementById('ctl00_MainContent_txbHdPremiumSmartDrive5').value= "0";
                document.getElementById('ctl00_MainContent_txbHdOtherDiscount_C1').value = "0";
                document.getElementById('ctl00_MainContent_txbHdOD_CoSi').value = "0";
                document.getElementById('ctl00_MainContent_txbHdFT_TfSi').value = "0";
                document.getElementById('ctl00_MainContent_txbHdODSI').value = "0";
            }
        }
    }
    catch(e)
    {
        //alert('Error in Ajax respone');
    }
}
function FillDataSmartDrive5FTSI(){
    var ClassType = "Class 5 (3+1)";// document.getElementById('ctl00_MainContent_cmbPackageType').value;
 try
    {
        //readyState of 4 or 'complete' represents 
        //that data has been returned 
        if (req.readyState == 4 ||  req.readyState == 'complete')
        {
            var arr1 = new Array();
            var result = req.responseText;
            arr1 = result.split(",");
            var FTSI;
            if (arr1[0]=="default")
            {
                //-----------------------------------------------------------------------
                //----------------------Bind SumInsure 85%---------------------------------
                FTSI = document.getElementById('ctl00_MainContent_cmbSmartDriive5FTSI').value;

                //----------------------Bind SumInsusre 100%-------------------------------
                document.getElementById('ctl00_MainContent_txbHdNetSumInsure').value = arr1[2];

                //----------ตรวจสอบว่า ข้อมูลรถนี้ เป็นของ Class 5 (2+1) ไม่แสดงข้อความ บอก ค่าเริ่มต้น
                //--------- OD = 0, FT = sumInsur, ODSI = sumInsure;

                document.getElementById('ctl00_MainContent_lbMessageSumInsure').innerHTML = "";
                if(ClassType.substring(0,13) == "Class 5 (2+1)")
                {
                    document.getElementById('ctl00_MainContent_txbHdOD_CoSi').value = "0";    
                    document.getElementById('ctl00_MainContent_txbHdFT_TfSi').value = FTSI;
                }
                else
                {
                        document.getElementById('ctl00_MainContent_txbHdOD_CoSi').value = "0";
                        document.getElementById('ctl00_MainContent_txbHdFT_TfSi').value = "0";
                }  
                //-----------------------------------------------------------------------
                //----------------------------------FILL ค่า--------- --------------------
                //-----------------------------------------------------------------------
//                document.getElementById('ctl00_MainContent_lbOD_C1').innerText = addNumber(document.getElementById('ctl00_MainContent_txbHdOD_CoSi').value);
//                document.getElementById('ctl00_MainContent_lbFT_C1').innerText = addNumber(document.getElementById('ctl00_MainContent_txbHdFT_TfSi').value);


                //-----------------------------------------------------------------------
                //document.getElementById('ctl00_MainContent_txbHdPremiumSmartDrive5').value = arr1[4];
                document.getElementById('ctl00_MainContent_txbHdOtherDiscount_C1').value=arr1[5];
    
            }
            else
            {
                  document.getElementById('ctl00_MainContent_lbMessageSumInsure').innerHTML = req.responseText; 
                  //document.getElementById('ctl00_MainContent_txbSumInsure').value =""; 
                  document.getElementById('ctl00_MainContent_cmbSmartDriive5FTSI').value = "100000";
//                  document.getElementById('ctl00_MainContent_lbFT_C1').innerText = "0.00";
//                  document.getElementById('ctl00_MainContent_txbHdOD_CoSi').value = "0";
//                  document.getElementById('ctl00_MainContent_txbHdFT_TfSi').value = "0";
//                  document.getElementById('ctl00_MainContent_txbHdODSI').value = "0";
//                  document.getElementById('ctl00_MainContent_txbHdNetSumInsure').value = "0";
//                  document.getElementById('ctl00_MainContent_txbHdOtherDiscount_C1').innerText="0";
//                  document.getElementById('ctl00_MainContent_txbHdPremiumSmartDrive5').value= "0";
//                  //document.getElementById('ctl00_MainContent_hdMinimumPremium_C1').innerText = "";
                  
            }
            if(req.responseText=="คุณระบุเลือกรถ หรือ ปีรุ่น ไม่ถูกต้อง")
            {
                document.getElementById('ctl00_MainContent_txbHdPremiumSmartDrive5').value= "0";
                document.getElementById('ctl00_MainContent_txbHdOtherDiscount_C1').value="0";
                document.getElementById('ctl00_MainContent_txbHdOD_CoSi').value = "0";
                document.getElementById('ctl00_MainContent_txbHdFT_TfSi').value = "0";
            }
        }
    }
    catch(e)
    {
        //alert('Error in Ajax respone');
    }
}
function CheckMakeCodeSmartDrive5(PackageType,Year,Garage){
    var makecode = document.getElementById('ctl00_MainContent_txbMakeCode').value;
    var thisYear = new Date();
    var Error = false;
    var ErrorMessage = "";
    if(PackageType == "Class 5"){
        if(Year=="" || makecode=="")
        {
            ErrorMessage = "คุณระบุรถ หรือ ปีรุ่น ไม่ถูกต้อง กรุณาระบุใหม่อีกครั้ง !";
            Error = true;
        }
        else if(Year > thisYear.getFullYear()){
            ErrorMessage = "อายุรถเกินกว่า ปีปัจจุบัน กรุณาระบุอายุรถใหม่";    
            Error = true;
        }else{
            if(Math.abs(Year-thisYear.getFullYear()) > 19){
                ErrorMessage = "อายุรถเกิน 20 ปี ไม่สามารถรับประกันภัยแบบประเภท 5 ได้";
                Error = true;
            }else{
                if(Math.abs(Year-thisYear.getFullYear()) > 4 && Garage == "1"){
                    ErrorMessage = "อายุรถเกิน 5 ปี ซ่อมอู่ห้าง ไม่สามารถรับประกันภัยแบบประเภท 5 ได้";
                    Error = true;
                }
                else{
                    Error = false;
                }
            }
        }
    }else{
        Error = false;
    }
    //แก้ไขวันที่ 2010-08-14
    //document.getElementById('ctl00_MainContent_cmbSumInsureODSI').value = "0";
    //document.getElementById('ctl00_MainContent_cmbSumInsureFTSI').value = "0";
    document.getElementById('ctl00_MainContent_txbHdPremiumSmartDrive5').value = "0";
    //แก้ไขวันที่ 2010-08-14
    //document.getElementById('ctl00_MainContent_lbODSI_C1').innerText = "0.00";
    //document.getElementById('ctl00_MainContent_lbFT_C1').innerText = "0.00";
    document.getElementById('ctl00_MainContent_txbHdOtherDiscount_C1').value = "0";
    document.getElementById('ctl00_MainContent_txbHdOD_CoSi').value = "0";
    document.getElementById('ctl00_MainContent_txbHdFT_TfSi').value = "0";
    document.getElementById('ctl00_MainContent_txbHdODSI').value = "0";
    if(Error){
        document.getElementById('ctl00_MainContent_lbMessageSumInsure').innerHTML= ErrorMessage;
        return false;
    }else{
        return true;
    }
    
}
function CheckMakeCodeSumInsureSmartDrive5(PackageType,Year,Garage){
    var makecode = document.getElementById('ctl00_MainContent_txbMakeCode').value;
    var thisYear = new Date();
    var Error = false;
    var ErrorMessage = "";
    if(PackageType == "Class 5"){
        if(Year=="" || makecode=="")
        {
            ErrorMessage = "คุณระบุรถ หรือ ปีรุ่น ไม่ถูกต้อง กรุณาระบุใหม่อีกครั้ง !";
            Error = true;
        }
        else if(Year > thisYear.getFullYear()){
            ErrorMessage = "อายุรถเกินกว่า ปีปัจจุบัน กรุณาระบุอายุรถใหม่";    
            Error = true;
        }else{
            if(Math.abs(Year-thisYear.getFullYear()) > 19){
                ErrorMessage = "อายุรถเกิน 20 ปี ไม่สามารถรับประกันภัยแบบประเภท 5 ได้";
                Error = true;
            }else{
                if(Math.abs(Year-thisYear.getFullYear()) > 4 && Garage == "1"){
                    ErrorMessage = "อายุรถเกิน 5 ปี ซ่อมอู่ห้าง ไม่สามารถรับประกันภัยแบบประเภท 5 ได้";
                    Error = true;
                }
                else{
                    Error = false;
                }
            }
        }
    }else{
        Error = false;
    }
    if(Error){
        document.getElementById('ctl00_MainContent_lbMessageSumInsure').innerHTML= ErrorMessage;
        return false;
    }else{
        return true;
    }
}