﻿//------------------------------------------------------------------
//---------------ใช้สำหรับ ตรวจสอบ ว่าหมายเลขตัวถัง ซ้ำกันหรือไม่
//------------------------------------------------------------------
function AjaxGetData(url, responseHandler)
{
    if (window.XMLHttpRequest)
     {
         // browser has native support for XMLHttpRequest object
         req = new XMLHttpRequest();
     }
     else if (window.ActiveXObject)
     {
         // try XMLHTTP ActiveX (Internet Explorer) version
         req = new ActiveXObject("Microsoft.XMLHTTP");
     }
     
     if(req)
     {
         req.onreadystatechange = responseHandler;
         req.open('GET', url, true);
         req.setRequestHeader("content-type","application/x-www-form-urlencoded");
         req.send('');
     }
     else
     {
         alert('Your browser does not seem to support XMLHttpRequest.');
     }
 }
 function GetPremiumPolicyTypeByJobAndPackagePolicyType(job, lbTypeGarageId, standardFlagMotor, standardvalue, suminsure, suminsure5, ncbindex) {

     var HdGroupBrokerID = document.getElementById('ctl00_MainContent_txbHdGroupBrokerID').value;
     URL = "GetListPremiumPolicyType.ashx?JobNo=" + job + "&lbTypeGarageId=" + lbTypeGarageId + "&StandardFlagMotor=" + standardFlagMotor + "&StandardValue=" + standardvalue + "&SumInsure=" + suminsure + "&SumInsure5=" + suminsure5 + "&NcbIndex=" + ncbindex + "&hdGroupBrokerID=" + HdGroupBrokerID;
     AjaxGetData(URL, SendToAJAX1);
}

function SendToAJAX1(){
    try{
        //readyState of 4 or 'complete' represents 
        //that data has been returned 
        if (req.readyState == 4 ||  req.readyState == 'complete')
        {
            var arr1 = new Array();
            var result = req.responseText;

            arr1 = result.split(",");            

            //arr1[0] = YES/NO
            if (arr1[0]=="YES")
            {
                //document.getElementById('ctl00_MainContent_lbMessageSumInsure').innerHTML = "เลขที่ตัวถัง "+arr1[1]+" นี้ได้ถูกใช้แล้ว กรุณาติดต่อ AXA Helpdesk";
                //document.getElementById('ctl00_MainContent_txbChassis').value = "";

                //document.getElementById('ctl00_MainContent_txbChassis').value = "";

                //==========================
                //
                //lbAmountPremium
                //cmbAmountDeductibleOD
                //cmbAmountDeductiblePD
                //txbAmountCommercialCredit
                //txbPercenCommercialCredit
                //lbNetPremium
                //

                //==========================
                //HIDE TABLE CONTRACT
                var controltbl1 = document.getElementById('ctl00_MainContent_lbInsureDetails');
                controltbl1.style.display = "none";
                controltbl1.style.visibility = "hidden";
                var controltbl2 = document.getElementById('ctl00_MainContent_lbGroupButtonPrintPropersal');
                controltbl2.style.visibility = "hidden";
                //=========================

                var IsContractOrDealer = arr1[1];
                var JobNo = arr1[2];
                var PackagePolicyType = arr1[3];

                switch (PackagePolicyType) {
                    case "Class 1":
                        document.getElementById('ctl00_MainContent_cmbAmountDeductibleOD').disabled = false;
                        document.getElementById('ctl00_MainContent_cmbAmountDeductiblePD').disabled = false;
                        break;
                    case "Class 2":
                        document.getElementById('ctl00_MainContent_cmbAmountDeductibleOD').disabled = false;
                        document.getElementById('ctl00_MainContent_cmbAmountDeductiblePD').disabled = false;
                        break;
                    case "Class 3":
                        document.getElementById('ctl00_MainContent_cmbAmountDeductibleOD').disabled = true;
                        document.getElementById('ctl00_MainContent_cmbAmountDeductiblePD').disabled = false;
                        break;
                    case "Class 5 (2+1)":
                        document.getElementById('ctl00_MainContent_cmbAmountDeductibleOD').disabled = true;
                        document.getElementById('ctl00_MainContent_cmbAmountDeductiblePD').disabled = true;
                        break;
                    case "Class 5 (3+1)":
                        document.getElementById('ctl00_MainContent_cmbAmountDeductibleOD').disabled = true;
                        document.getElementById('ctl00_MainContent_cmbAmountDeductiblePD').disabled = true;
                        break;
                    case "Class 5 (2+1) deduct":
                        document.getElementById('ctl00_MainContent_cmbAmountDeductibleOD').disabled = true;
                        document.getElementById('ctl00_MainContent_cmbAmountDeductiblePD').disabled = true;
                        break;
                    case "Class 5 (3+1) deduct":
                        document.getElementById('ctl00_MainContent_cmbAmountDeductibleOD').disabled = true;
                        document.getElementById('ctl00_MainContent_cmbAmountDeductiblePD').disabled = true;
                        break;
                    case "AXA 3 Free":
                        document.getElementById('ctl00_MainContent_cmbAmountDeductibleOD').disabled = true;
                        document.getElementById('ctl00_MainContent_cmbAmountDeductiblePD').disabled = false;
                        break;                    
                };
                
                
                //arr1[1] = Y/N
                if (IsContractOrDealer == 'Y') {
                    //Contract
                    //======================
                    var Garage_Contract = arr1[4];
                    var NetPremium_Contract = arr1[5];
                    var Stampduty_Contract = arr1[6];
                    var Vat_Contract = arr1[7];
                    var TotalPremium_Contract = arr1[8];
                    var CommercailCredit_Contract = arr1[9];
                    var OD_Deduct_Contract = arr1[10];
                    var PD_Deduct_Contract = arr1[11];
                    //========================

                    document.getElementById('ctl00_MainContent_lbAmountPremium').innerHTML = addNumber(NetPremium_Contract);
                    document.getElementById('ctl00_MainContent_cmbAmountDeductibleOD').value = OD_Deduct_Contract;
                    document.getElementById('ctl00_MainContent_cmbAmountDeductiblePD').value = PD_Deduct_Contract;
                    //UPDATE 2010-11-11
                    document.getElementById('ctl00_MainContent_lbStamp').innerHTML = addNumber(Stampduty_Contract);
                    document.getElementById('ctl00_MainContent_lbTax').innerHTML = addNumber(Vat_Contract);
                    

                    if (arr1[24] == "YES") {
                        //======================
                        var control1 = document.getElementById('ctl00_MainContent_lbCommercialCredit');
                        var control2 = document.getElementById('ctl00_MainContent_txbAmountCommercialCredit');
                        var control3 = document.getElementById('ctl00_MainContent_txbPercenCommercialCredit');
                        //======================
//                        control1.style.visibility = "visible";
//                        control2.style.visibility = "visible";
//                        control3.style.visibility = "visible";
                        control1.disabled = false;
                        control2.disabled = false;
                        control3.disabled = false;

                        document.getElementById('ctl00_MainContent_txbAmountCommercialCredit').value = CommercailCredit_Contract;                        
                    } else {
                         //======================
                         var control1 = document.getElementById('ctl00_MainContent_lbCommercialCredit');
                         var control2 = document.getElementById('ctl00_MainContent_txbAmountCommercialCredit');
                         var control3 = document.getElementById('ctl00_MainContent_txbPercenCommercialCredit');
                         //======================
                         document.getElementById('ctl00_MainContent_txbAmountCommercialCredit').value = 0.00;
                         document.getElementById('ctl00_MainContent_txbPercenCommercialCredit').value = 0.00;
                         //control1.style.visibility = "hidden";
                         //control2.style.visibility = "hidden";
                         //control3.style.visibility = "hidden";
//                         control1.style.visibility = "visible";
//                         control2.style.visibility = "visible";
//                         control3.style.visibility = "visible";
                         control1.disabled = true;
                         control2.disabled = true;
                         control3.disabled = true;


                    }
                    //===============================
                    //document.getElementById('ctl00_MainContent_txbPercenCommercialCredit').innerHTML = CommercailCredit_Contract;
                    document.getElementById('ctl00_MainContent_lbNetPremium').innerHTML = addNumber(TotalPremium_Contract);
                    //
                    //======================FOR HIDDEN
                    document.getElementById('ctl00_MainContent_txbHdAmountPremium').value = NetPremium_Contract;
                    document.getElementById('ctl00_MainContent_txbHdAmountDeductibleOD').value = OD_Deduct_Contract;
                    document.getElementById('ctl00_MainContent_txbHdAmountDeductiblePD').value = PD_Deduct_Contract;
                    document.getElementById('ctl00_MainContent_txbHdAmountCommercialCredit').value = CommercailCredit_Contract;
                    document.getElementById('ctl00_MainContent_txbHdPercenCommercialCredit').value = CommercailCredit_Contract; //ต้องทำใหม่
                    document.getElementById('ctl00_MainContent_txbHdNetPremium').value = TotalPremium_Contract;
                    //UPDATE 2010-11-11
                    document.getElementById('ctl00_MainContent_txbHdStampV').value = Stampduty_Contract;
                    document.getElementById('ctl00_MainContent_txbHdTaxV').value = Vat_Contract;

                    //CALCULATE TOTAL PREMIUM
                    var chk = document.getElementById('ctl00_MainContent_chkCompulsaryYes_R7C2').checked;
                    if (chk) {

                        var netcompl = document.getElementById('ctl00_MainContent_txbHdNetPremiumC').value;
                        var netvolun = document.getElementById('ctl00_MainContent_txbHdNetPremium').value;
                        netcompl = parseFloat(netcompl);
                        netvolun = parseFloat(netvolun);
                        var totalpremium = netcompl + netvolun;

                        document.getElementById('ctl00_MainContent_txbHdTotalPremiumVC').value = parseFloat(totalpremium).toFixed(2);
                        totalpremium = document.getElementById('ctl00_MainContent_txbHdTotalPremiumVC').value;
                        document.getElementById('ctl00_MainContent_lbTotalPremium').innerHTML = addNumber(totalpremium);

                    }
                    else {
                    //CLEAR
                        document.getElementById('ctl00_MainContent_txbHdTotalPremiumVC').value = "0";
                        document.getElementById('ctl00_MainContent_lbTotalPremium').innerHTML = "&nbsp;";
                    }

                    //=======================
                } else {//Dealer 
                    //======================
                    var Garage_Dealer = arr1[12];
                    var NetPremium_Dealer = arr1[13];
                    var Stampduty_Dealer = arr1[14];
                    var Vat_Dealer = arr1[15];
                    var TotalPremium_Dealer = arr1[16];
                    var CommerCailCredit_Dealer = arr1[17];
                    var OD_Deduct_Dealer = arr1[18];
                    var PD_Deduct_Dealer = arr1[19];
                    
                    document.getElementById('ctl00_MainContent_lbAmountPremium').innerHTML = addNumber(NetPremium_Dealer);
                    document.getElementById('ctl00_MainContent_cmbAmountDeductibleOD').value = OD_Deduct_Dealer;
                    document.getElementById('ctl00_MainContent_cmbAmountDeductiblePD').value = PD_Deduct_Dealer;

                    //UPDATE 2010-11-11
                    document.getElementById('ctl00_MainContent_lbStamp').innerHTML = addNumber(Stampduty_Dealer);
                    document.getElementById('ctl00_MainContent_lbTax').innerHTML = addNumber(Vat_Dealer);

                    if (arr1[24] == "YES") { // //
                        //======================
                        //
                        var control1 = document.getElementById('ctl00_MainContent_lbCommercialCredit');
                        var control2 = document.getElementById('ctl00_MainContent_txbAmountCommercialCredit');
                        var control3 = document.getElementById('ctl00_MainContent_txbPercenCommercialCredit');
                        //
                        //=====================
//                        control1.style.visibility = "visible";
//                        control2.style.visibility = "visible";
//                        control3.style.visibility = "visible";
                        control1.disabled = false;
                        control2.disabled = false;
                        control3.disabled = false;
                        document.getElementById('ctl00_MainContent_txbAmountCommercialCredit').value = CommerCailCredit_Dealer;                        
                    } else {
                        //======================
                        //
                        var control1 = document.getElementById('ctl00_MainContent_lbCommercialCredit');
                        var control2 = document.getElementById('ctl00_MainContent_txbAmountCommercialCredit');
                        var control3 = document.getElementById('ctl00_MainContent_txbPercenCommercialCredit');
                        //
                        //=====================
                        document.getElementById('ctl00_MainContent_txbAmountCommercialCredit').value = 0.00;
                        document.getElementById('ctl00_MainContent_txbPercenCommercialCredit').value = 0.00;
                        //control1.style.visibility = "hidden";
                        //control2.style.visibility = "hidden";
                        //control3.style.visibility = "hidden"; 
//                        control1.style.visibility = "visible";
//                        control2.style.visibility = "visible";
//                        control3.style.visibility = "visible";
                        control1.disabled = true;
                        control2.disabled = true;
                        control3.disabled = true;

                    }
                    //document.getElementById('ctl00_MainContent_txbPercenCommercialCredit').innerHTML = CommerCailCredit_Dealer;
                    document.getElementById('ctl00_MainContent_lbNetPremium').innerHTML = addNumber(TotalPremium_Dealer);
                    //
                    //======================FOR HIDDEN
                    document.getElementById('ctl00_MainContent_txbHdAmountPremium').value = NetPremium_Dealer;
                    document.getElementById('ctl00_MainContent_txbHdAmountDeductibleOD').value = OD_Deduct_Dealer;
                    document.getElementById('ctl00_MainContent_txbHdAmountDeductiblePD').value = PD_Deduct_Dealer;
                    document.getElementById('ctl00_MainContent_txbHdAmountCommercialCredit').value = CommerCailCredit_Dealer;
                    document.getElementById('ctl00_MainContent_txbHdPercenCommercialCredit').value = CommerCailCredit_Dealer;
                    document.getElementById('ctl00_MainContent_txbHdNetPremium').value = TotalPremium_Dealer;
                    //======================
                    //UPDATE 2010-11-11
                    document.getElementById('ctl00_MainContent_txbHdStampV').value = Stampduty_Dealer;
                    document.getElementById('ctl00_MainContent_txbHdTaxV').value = Vat_Dealer;
                    

                  
                    //CALCULATE TOTAL PREMIUM
                    var chk = document.getElementById('ctl00_MainContent_chkCompulsaryYes_R7C2').checked;
                    if (chk) {
                        var netcompl = document.getElementById('ctl00_MainContent_txbHdNetPremiumC').value;
                        var netvolun = document.getElementById('ctl00_MainContent_txbHdNetPremium').value;
                        netcompl = parseFloat(netcompl);
                        netvolun = parseFloat(netvolun);
                        var totalpremium = netcompl + netvolun;

                        document.getElementById('ctl00_MainContent_txbHdTotalPremiumVC').value = parseFloat(totalpremium).toFixed(2);
                        totalpremium = document.getElementById('ctl00_MainContent_txbHdTotalPremiumVC').value;
                        document.getElementById('ctl00_MainContent_lbTotalPremium').innerHTML = addNumber(totalpremium);
                    }
                    else {
                        //CLEAR
                        document.getElementById('ctl00_MainContent_txbHdTotalPremiumVC').value = "0";
                        document.getElementById('ctl00_MainContent_lbTotalPremium').innerHTML = "&nbsp;";

                    }
                }
                document.getElementById('ctl00_MainContent_lbMessageHead').innerHTML = "";

            }
            else
            {
                document.getElementById('ctl00_MainContent_lbMessageHead').innerHTML = "รายการนี้ไม่สามารถสร้างกรมธรรม์ได้";
                document.getElementById('ctl00_MainContent_lbAmountPremium').innerHTML = "";
                document.getElementById('ctl00_MainContent_cmbAmountDeductibleOD').value = "0";
                document.getElementById('ctl00_MainContent_cmbAmountDeductiblePD').value = "0";
                document.getElementById('ctl00_MainContent_lbStamp').innerHTML = "";
                document.getElementById('ctl00_MainContent_lbTax').innerHTML = "";
                document.getElementById('ctl00_MainContent_lbNetPremium').innerHTML = "";
                document.getElementById('ctl00_MainContent_lbTotalPremium').innerHTML = "&nbsp;";

                document.getElementById('ctl00_MainContent_txbHdPremiumC').value = "";
                document.getElementById('ctl00_MainContent_txbHdStampC').value = "";
                document.getElementById('ctl00_MainContent_txbHdTaxC').value = "";
                document.getElementById('ctl00_MainContent_txbHdNetPremiumC').value = "";

            }

            if (arr1[20] == "YES") {

                if (arr1[21] == "0") {//Non Standard 


                    document.getElementById('ctl00_MainContent_imgStandard').src = "../ImagesR3/emotion_sad_1.gif";
                    document.getElementById('ctl00_MainContent_lbStandard').innerHTML = "รายการนี้ต้องขออนุมัติค่ะ ";

                    //======================FOR HIDDEN
                    document.getElementById('ctl00_MainContent_txbHdStandardFlag').value = 0;
                    //======================FOR STATUS QUOTATION
                    document.getElementById('ctl00_MainContent_lbStatusQuotation').innerHTML = "รายการนี้ต้องขออนุมัติค่ะ...!";
                    //======================

                    try 
                    {
                        document.getElementById('ctl00_MainContent_lbEditMode_BodyMails').style.display = "block";
                    }
                    catch (e) {
                        //alert('Error in Ajax respone ' + e);
                    }

                    var controlbtnUpload = document.getElementById('ctl00_MainContent_btnUpload');
                    controlbtnUpload.disabled = false;
                    controlbtnUpload.style.display = "inline";
                    controlbtnUpload.style.width = "250px";
                    
                    var controltblApproval = document.getElementById('ctl00_MainContent_btnApproval');
                    controltblApproval.disabled = false;
                    controltblApproval.style.display = "inline";
                    controltblApproval.style.width = "120px";

                    var controltblIssueProposal = document.getElementById('ctl00_MainContent_btnIssueProposal');
                    controltblIssueProposal.disabled = true;
                    controltblIssueProposal.style.display = "none";
                    controltblIssueProposal.style.width = "120px";

                             


                } else {  //1 Standard

                    document.getElementById('ctl00_MainContent_imgStandard').src = "../ImagesR3/emotion_smile_1.gif";
                    document.getElementById('ctl00_MainContent_lbStandard').innerHTML = "ขอแสดงความยินดีด้วย ท่านสามารถออกกรมธรรม์ตามรายการนี้ได้";

                    //======================FOR HIDDEN
                    document.getElementById('ctl00_MainContent_txbHdStandardFlag').value = 1;
                    //======================FOR STATUS QUOTATION
                    document.getElementById('ctl00_MainContent_lbStatusQuotation').innerHTML = "ขอแสดงความยินดีด้วย ท่านสามารถออกกรมธรรม์ตามรายการนี้ได้";
                    //======================
                    var controlbtnUpload = document.getElementById('ctl00_MainContent_btnUpload');
                    //controlbtnUpload.style.visibility = "hidden";
                    controlbtnUpload.disabled = true;
                    controlbtnUpload.style.display = "none";
                    controlbtnUpload.style.width = "250px";

                    var controltblApproval = document.getElementById('ctl00_MainContent_btnApproval');
                    //controltblApproval.style.visibility = "hidden";
                    controltblApproval.disabled = true;
                    controltblApproval.style.display = "none";
                    controltblApproval.style.width = "120px";
                    
                    var controltblIssueProposal = document.getElementById('ctl00_MainContent_btnIssueProposal');
                    //controltblIssueProposal.style.visibility = "visible";
                    controltblIssueProposal.disabled = false;
                    controltblIssueProposal.style.display = "inline";
                    controltblIssueProposal.style.width = "120px";

                    try 
                    {
                        document.getElementById('ctl00_MainContent_lbEditMode_BodyMails').style.display = "none";
                    }
                    catch(e){
                            //alert('Error in Ajax respone ' + e);
                    }

                }
            } else {
                document.getElementById('ctl00_MainContent_lbMessageHead').innerHTML = "เกิดข้อผิดพลาดในการดึงข้อมูลหรือไม่สามารถตรวจสอบข้อมูลนี้ได้";
            }
            //SET HIDDEN FOR USER SELECT POLICY VOLUNTARY TYPE
            document.getElementById('ctl00_MainContent_txbHdSelectPolicyType').value = arr1[22];
            document.getElementById('ctl00_MainContent_txbHdSelectPolicyTypeGarage').value = arr1[23];
         }
    }
    catch(e){
        //alert('Error in Ajax respone ' + e);
    }
}


/////////////////
//=========================================
function xSplitValue(x) {
    var arr = new Array();
    var item;
    var result;
    arr = (x).split(",");
    //alert(tempGross0[0]);
    //alert(tempGross0[1]);
    var done = true;
    for (item in arr) {
        if (done) {
            result = arr[item];
            done = false;
        }
        else {
            result += arr[item];
        }
    }

    return (result);
}

//UPDATE 2010-11-11
//===============================================
function addNumber(Number) {
    /* ถ้าต้องการใช้ เรียกใช้ใน หน้า asp ต้องเปลี่ยน parameter เป็น (ID,Text)
    และเปลี่ยน Number เป็น Number.value
    var NumClientID = "ctl00_"+ID+"_"+Text;
    //alert(document.getElementById(NumClientID));
    var Number = document.getElementById(NumClientID);*/

    var OutputNumber = "";
    var tmp = "";
    var FloatingPoint = ".00";

    Number = cutSemi(Number);
    if (getfloatingPoint(Number) == -1) {
        FloatingPoint = ".00";
    } else {

        FloatingPoint = getfloatingPoint(Number);
        FloatingPoint = parseFloat(FloatingPoint).toFixed(2);
        FloatingPoint = getfloatingPoint(FloatingPoint);
    }
    Number = cutFloatingPoint(Number);

    Number = revert(Number);

    for (var i = 0; i < Number.length; i++) {
        tmp += Number.charAt(i);
        if (((i + 1) % 3) == 0) {
            OutputNumber += tmp;
            OutputNumber += ",";
            tmp = "";
        }
    }
    OutputNumber += tmp;


    OutputNumber = revert(OutputNumber);
    if (OutputNumber.charAt(0) == ",") {
        OutputNumber = OutputNumber.substr(1, OutputNumber.length);
    }
    OutputNumber += FloatingPoint;
    Number = OutputNumber;
    return Number;

}
function revert(text) {
    var tmp = "";
    for (var i = text.length; i >= 0; i--) {
        tmp += text.charAt(i);
    }
    return tmp;
}
function cutSemi(text) {
    var tmp = "";
    for (var i = 0; i < text.length; i++) {
        if (text.charAt(i) != ",") {
            tmp += text.charAt(i);
        }
    }
    return tmp;
}

function cutFloatingPoint(text) {
    var tmp = "";
    for (var i = 0; i < text.length; i++) {
        if (text.charAt(i) != ".") {

            tmp += text.charAt(i);
        } else break;

    }
    return tmp;
}
function getfloatingPoint(text) {
    var tmp = "";
    var i = 0;
    for (var i = 0; i < text.length; i++) {
        if (text.charAt(i) == ".") break;
    }
    if (i == text.length) {

        return -1;
    }

    for (var j = i; j < text.length; j++) {
        tmp += text.charAt(j);
    }
    return tmp;
}


