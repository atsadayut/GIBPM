﻿function MessageCommercialCredit() {
    var commercial = document.getElementById('ctl00_MainContent_txbAmountCommercialCredit');
    commercial.value = parseFloat(xSplitValue(commercial.value)).toFixed(2);
    //alert(GrossNo1);
    if ((commercial.value == "NaN")|(commercial.value == "")) {
        commercial.value = 0.00;
    }
    //    else {

    //        commercial.value = addNumber(commercial.value); //With Comma(,)

    //    }
    if (commercial.value > 0) {
        return true;
    }
    return false;
}

//=========================================
function xSplitValue(x) {
    var arr = new Array();
    var item;
    var result;
    arr = (x).split(",");
    //alert(tempGross0[0]);
    //alert(tempGross0[1]);
    var done = true;
    for (item in arr) {
        if (done) {
            result = arr[item];
            done = false;
        }
        else {
            result += arr[item];
        }
    }

    return (result);
}

//===============================================
function addNumber(Number) {
    /* ถ้าต้องการใช้ เรียกใช้ใน หน้า asp ต้องเปลี่ยน parameter เป็น (ID,Text)
    และเปลี่ยน Number เป็น Number.value
    var NumClientID = "ctl00_"+ID+"_"+Text;
    //alert(document.getElementById(NumClientID));
    var Number = document.getElementById(NumClientID);*/

    var OutputNumber = "";
    var tmp = "";
    var FloatingPoint = ".00";

    Number = cutSemi(Number);
    if (getfloatingPoint(Number) == -1) {
        FloatingPoint = ".00";
    } else {

        FloatingPoint = getfloatingPoint(Number);
        FloatingPoint = parseFloat(FloatingPoint).toFixed(2);
        FloatingPoint = getfloatingPoint(FloatingPoint);
    }
    Number = cutFloatingPoint(Number);

    Number = revert(Number);

    for (var i = 0; i < Number.length; i++) {
        tmp += Number.charAt(i);
        if (((i + 1) % 3) == 0) {
            OutputNumber += tmp;
            OutputNumber += ",";
            tmp = "";
        }
    }
    OutputNumber += tmp;


    OutputNumber = revert(OutputNumber);
    if (OutputNumber.charAt(0) == ",") {
        OutputNumber = OutputNumber.substr(1, OutputNumber.length);
    }
    OutputNumber += FloatingPoint;
    Number = OutputNumber;
    return Number;

}
function revert(text) {
    var tmp = "";
    for (var i = text.length; i >= 0; i--) {
        tmp += text.charAt(i);
    }
    return tmp;
}
function cutSemi(text) {
    var tmp = "";
    for (var i = 0; i < text.length; i++) {
        if (text.charAt(i) != ",") {
            tmp += text.charAt(i);
        }
    }
    return tmp;
}

function cutFloatingPoint(text) {
    var tmp = "";
    for (var i = 0; i < text.length; i++) {
        if (text.charAt(i) != ".") {

            tmp += text.charAt(i);
        } else break;

    }
    return tmp;
}
function getfloatingPoint(text) {
    var tmp = "";
    var i = 0;
    for (var i = 0; i < text.length; i++) {
        if (text.charAt(i) == ".") break;
    }
    if (i == text.length) {

        return -1;
    }

    for (var j = i; j < text.length; j++) {
        tmp += text.charAt(j);
    }
    return tmp;
}