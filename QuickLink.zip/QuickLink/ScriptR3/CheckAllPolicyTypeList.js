﻿function chkAllPolicyTypeList(status) {
    //var chk = document.getElementById('ctl00_MainContent_chkAll');
    if (status) {
        document.getElementById('ctl00_MainContent_chkCompreh').checked = true;
        document.getElementById('ctl00_MainContent_chkTPFirTh').checked = true;
        document.getElementById('ctl00_MainContent_chkTPOnlys').checked = true;
        document.getElementById('ctl00_MainContent_chkSmaDri521').checked = true;
        document.getElementById('ctl00_MainContent_chkSmaDri521Deduct').checked = true;
        document.getElementById('ctl00_MainContent_chkSmaDri531').checked = true;
        document.getElementById('ctl00_MainContent_chkSmaDri531Deduct').checked = true;
        document.getElementById('ctl00_MainContent_chkAxa3Fre').checked = true;
    }
    else {
        document.getElementById('ctl00_MainContent_chkCompreh').checked = false;
        document.getElementById('ctl00_MainContent_chkTPFirTh').checked = false;
        document.getElementById('ctl00_MainContent_chkTPOnlys').checked = false;
        document.getElementById('ctl00_MainContent_chkSmaDri521').checked = false;
        document.getElementById('ctl00_MainContent_chkSmaDri521Deduct').checked = false;
        document.getElementById('ctl00_MainContent_chkSmaDri531').checked = false;
        document.getElementById('ctl00_MainContent_chkSmaDri531Deduct').checked = false;
        document.getElementById('ctl00_MainContent_chkAxa3Fre').checked = false;
    }
}
