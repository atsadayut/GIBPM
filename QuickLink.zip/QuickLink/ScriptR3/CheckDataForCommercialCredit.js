﻿
function AjaxGetData(url, responseHandler)
{
    if (window.XMLHttpRequest)
     {
         // browser has native support for XMLHttpRequest object
         req = new XMLHttpRequest();
     }
     else if (window.ActiveXObject)
     {
         // try XMLHTTP ActiveX (Internet Explorer) version
         req = new ActiveXObject("Microsoft.XMLHTTP");
     }
     
     if(req)
     {
         req.onreadystatechange = responseHandler;
         req.open('GET', url, true);
         req.setRequestHeader("content-type","application/x-www-form-urlencoded");
         req.send('');
     }
     else
     {
         alert('Your browser does not seem to support XMLHttpRequest.');
     }
 }
 function GetIsEnableCommercialCredit(ctl) {
     //ctl 0:full ,1:percen
    //var JobNo = document.getElementById('ctl00_MainContent_lbJobNoContent').value;
     //var PackagePolicyType = document.getElementById('ctl00_MainContent_rdoPoliyType');
     var PackagePolicyType = document.getElementById('ctl00_MainContent_txbHdSelectPolicyType').value;
     var HdGroupBrokerID = document.getElementById('ctl00_MainContent_txbHdGroupBrokerID').value;

     URL = "CheckDataForCommercialCredit.ashx?packagePolicyType=" + PackagePolicyType + "&hdGroupBrokerID=" + HdGroupBrokerID + "&ctl=" + ctl;
     AjaxGetData(URL, SendToAJAX2);
}


function SendToAJAX2(){
    try
    {
        //readyState of 4 or 'complete' represents 
        //that data has been returned
        if (req.readyState == 4 ||  req.readyState == 'complete')
        {
            var arr1 = new Array();
            var result = req.responseText;

            arr1 = result.split(",");            

            //arr1[0] = YES/NO
            if (arr1[0]=="YES") 
            {
                var AmountPolicy = arr1[2];
                if (AmountPolicy > 0)
                {
                    var commercial = document.getElementById('ctl00_MainContent_txbAmountCommercialCredit');
                    var messageCommercialCredit = document.getElementById('ctl00_MainContent_lbMessageCommercialCredit');
                    var tmpcommercial = parseFloat(xSplitValue(commercial.value)).toFixed(2);
                    commercial.value = tmpcommercial;
                    var tmpAmountPolicy = parseFloat(xSplitValue(AmountPolicy)).toFixed(2);

                    //for percen
                    var commercialpercen = document.getElementById('ctl00_MainContent_txbPercenCommercialCredit');  //id
                    var tmpcommercialpercen = parseFloat(xSplitValue(commercialpercen.value)).toFixed(2);
                    var netpremium = document.getElementById('ctl00_MainContent_txbHdNetPremium');                  //id
                    var tmpnetpremium = parseFloat(xSplitValue(netpremium.value)).toFixed(2);                       //39660.00
                    var percenvalueamount = ((tmpcommercialpercen / 100.00) * tmpnetpremium).toFixed(2);            //(10/100)*10 = 10 บาท

                    var percenfromamountcommercial = ((tmpcommercial / tmpnetpremium) * 100.00).toFixed(2);         //(10 / 1000) * 100 = 0.1%

                    //balance <= 0 
                    var varCCBalance = document.getElementById('ctl00_MainContent_txbCCBanance');
                    var intCCBalance = parseFloat(xSplitValue(varCCBalance.value)).toFixed(2);
                    var tmpAmount = "";

                    var controltbl1 = document.getElementById('ctl00_MainContent_lbInsureDetails');
                    controltbl1.style.display = "none";
                    controltbl1.style.visibility = "hidden";
                    var controltbl2 = document.getElementById('ctl00_MainContent_lbGroupButtonPrintPropersal');
                    controltbl2.style.visibility = "hidden";

                    if (arr1[3] == "0") { //Using for Commercial Credit
                        if (netpremium.value == "0") {
                            commercial.value = 0.00;
                            commercialpercen.value = 0;
                            messageCommercialCredit.innerHTML = "ไม่สามารถใช้ Commercial Credit ได้เนื่องจาก Net Premium มีค่าเท่ากับ 0";
                        }
                        else
                        {
                            if ((commercial.value == "NaN") | (commercial.value == "")) {
                                commercial.value = 0.00;
                                //for percen
                                commercialpercen.value = 0;
                                messageCommercialCredit.innerHTML = "Commercial Credit ไม่สามารถเป็นค่าว่างได้.";
                                //commercial.value = addNumber(commercial.value); //With Comma(,)
                            }
                            else 
                            {
                                if (tmpcommercial > 0.00) {
                                  
                                    if ((parseFloat(tmpcommercial)) <= (parseFloat(tmpAmountPolicy)) &  (parseFloat(tmpcommercial)) <= (parseFloat(intCCBalance)))
                                        {
                                            //for percen
                                            commercial.value = tmpcommercial;   //10 บาท
                                            //for commercial
                                            if (netpremium.value == "0") {
                                                commercial.value = 0.00;
                                                commercialpercen.value = 0;
                                                messageCommercialCredit.innerHTML = "ไม่สามารถใช้ Commercial Credit ได้เนื่องจาก Net Premium มีค่าเท่ากับ 0";
                                            }
                                            else {
                                                commercialpercen.value = percenfromamountcommercial;  //set to percen commercial   0.1%
                                                messageCommercialCredit.innerHTML = "";
                                            }
                                            return true;
                                        }
                                        else {
                                            commercial.value = 0.00;
                                            //for percen
                                            commercialpercen.value = 0;
                                            if ((parseFloat(tmpAmountPolicy)) > (parseFloat(intCCBalance))) 
                                            { 
                                             tmpAmount = intCCBalance;
                                            } else {tmpAmount = tmpAmountPolicy;}
                                            
                                            messageCommercialCredit.innerHTML = "คุณระบุค่ามากกว่าที่ได้รับอนุญาต ระบุได้ไม่เกิน " + tmpAmount + " บาท.";
                                            return false;
                                        }
                                }
                                else {
//                                    commercial.value = 0.00;
//                                    //for percen
                                    //                                    commercialpercen.value = 0;
                                    if ((parseFloat(tmpcommercial)) >= (parseFloat(tmpAmountPolicy) - (parseFloat(tmpAmountPolicy) * 2))) {
                                        //for percen
                                        commercial.value = tmpcommercial;   //10 บาท
                                        //for commercial
                                        if (netpremium.value == "0") {
                                            commercial.value = 0.00;
                                            commercialpercen.value = 0;
                                            messageCommercialCredit.innerHTML = "ไม่สามารถใช้ Commercial Credit ได้เนื่องจาก Net Premium มีค่าเท่ากับ 0";
                                        }
                                        else {
                                            commercialpercen.value = percenfromamountcommercial;  //set to percen commercial   0.1%
                                            messageCommercialCredit.innerHTML = "";
                                        }
                                        return true;
                                    }
                                    else {
                                        commercial.value = 0.00;
                                        //for percen
                                        commercialpercen.value = 0;
                                        var tmpAmouth = parseFloat(tmpAmountPolicy) - (parseFloat(tmpAmountPolicy) * 2);
                                        messageCommercialCredit.innerHTML = "คุณระบุค่าน้อยกว่าที่ได้รับอนุญาต ระบุได้ไม่น้อยกว่า " + tmpAmouth + " บาท.";
                                        return false;
                                    }
                                }
                            }
                        }
                    }
                    else {
                        if (arr1[3] == "1") { //Using for Commercial Credit Percen
                            if (netpremium.value == "0") {
                                commercial.value = 0.00;
                                commercialpercen.value = 0;
                                messageCommercialCredit.innerHTML = "ไม่สามารถใช้ Commercial Credit ได้เนื่องจาก Net Premium มีค่าเท่ากับ 0";
                            }
                            else {
                                if ((commercialpercen.value == "NaN") | (commercialpercen.value == "")) {
                                    commercialpercen.value = 0;
                                    //for commercial
                                    commercial.value = 0.00;
                                    messageCommercialCredit.innerHTML = "Commercial Credit(%) ไม่สามารถเป็นค่าว่างได้.";
                                    //commercial.value = addNumber(commercial.value); //With Comma(,)
                                }
                                if (tmpcommercialpercen > 0.00) {
                                    if ((parseFloat(percenvalueamount)) <= (parseFloat(tmpAmountPolicy))) {
                                        commercial.value = percenvalueamount;
                                        //for percen
                                        messageCommercialCredit.innerHTML = "";
                                        return true;
                                    }
                                    else {
                                        commercialpercen.value = 0;
                                        //for commercial
                                        commercial.value = 0.00;
                                        messageCommercialCredit.innerHTML = "คุณระบุค่า Commercial Credit(%)มากกว่าที่ได้รับอนุญาต!";
                                        return false;
                                    }
                                }
                                else {
                                    commercial.value = 0.00;
                                    commercialpercen.value = 0;
                                }
                            }
                        }
                        else {
                            messageCommercialCredit.innerHTML = "เกิดข้อผิดพลาดในการคำนวณค่า commercial credit!";
                        }
                    }
                }
            } 
            else 
            {
                return false;
            }
        }
    }
    catch(e){
        //alert('Error in Ajax respone');
    }
}

//=========================================
function xSplitValue(x) {
    var arr = new Array();
    var item;
    var result;
    arr = (x).split(",");
    //alert(tempGross0[0]);
    //alert(tempGross0[1]);
    var done = true;
    for (item in arr) {
        if (done) {
            result = arr[item];
            done = false;
        }
        else {
            result += arr[item];
        }
    }

    return (result);
}

//===============================================
function addNumber(Number) {
    /* ถ้าต้องการใช้ เรียกใช้ใน หน้า asp ต้องเปลี่ยน parameter เป็น (ID,Text)
    และเปลี่ยน Number เป็น Number.value
    var NumClientID = "ctl00_"+ID+"_"+Text;
    //alert(document.getElementById(NumClientID));
    var Number = document.getElementById(NumClientID);*/

    var OutputNumber = "";
    var tmp = "";
    var FloatingPoint = ".00";

    Number = cutSemi(Number);
    if (getfloatingPoint(Number) == -1) {
        FloatingPoint = ".00";
    } else {

        FloatingPoint = getfloatingPoint(Number);
        FloatingPoint = parseFloat(FloatingPoint).toFixed(2);
        FloatingPoint = getfloatingPoint(FloatingPoint);
    }
    Number = cutFloatingPoint(Number);

    Number = revert(Number);

    for (var i = 0; i < Number.length; i++) {
        tmp += Number.charAt(i);
        if (((i + 1) % 3) == 0) {
            OutputNumber += tmp;
            OutputNumber += ",";
            tmp = "";
        }
    }
    OutputNumber += tmp;


    OutputNumber = revert(OutputNumber);
    if (OutputNumber.charAt(0) == ",") {
        OutputNumber = OutputNumber.substr(1, OutputNumber.length);
    }
    OutputNumber += FloatingPoint;
    Number = OutputNumber;
    return Number;

}
function revert(text) {
    var tmp = "";
    for (var i = text.length; i >= 0; i--) {
        tmp += text.charAt(i);
    }
    return tmp;
}
function cutSemi(text) {
    var tmp = "";
    for (var i = 0; i < text.length; i++) {
        if (text.charAt(i) != ",") {
            tmp += text.charAt(i);
        }
    }
    return tmp;
}

function cutFloatingPoint(text) {
    var tmp = "";
    for (var i = 0; i < text.length; i++) {
        if (text.charAt(i) != ".") {

            tmp += text.charAt(i);
        } else break;

    }
    return tmp;
}
function getfloatingPoint(text) {
    var tmp = "";
    var i = 0;
    for (var i = 0; i < text.length; i++) {
        if (text.charAt(i) == ".") break;
    }
    if (i == text.length) {

        return -1;
    }

    for (var j = i; j < text.length; j++) {
        tmp += text.charAt(j);
    }
    return tmp;
}
//==================================

