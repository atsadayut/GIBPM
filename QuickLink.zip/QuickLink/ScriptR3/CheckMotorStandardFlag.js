﻿//------------------------------------------------------------------
//---------------ใช้สำหรับ ตรวจสอบ ว่าหมายเลขตัวถัง ซ้ำกันหรือไม่
//------------------------------------------------------------------
function AjaxGetData(url, responseHandler)
{
    if (window.XMLHttpRequest)
     {
         // browser has native support for XMLHttpRequest object
         req = new XMLHttpRequest();
     }
     else if (window.ActiveXObject)
     {
         // try XMLHTTP ActiveX (Internet Explorer) version
         req = new ActiveXObject("Microsoft.XMLHTTP");
     }
     
     if(req)
     {
         req.onreadystatechange = responseHandler;
         req.open('GET', url, true);
         req.setRequestHeader("content-type","application/x-www-form-urlencoded");
         req.send('');
     }
     else
     {
         alert('Your browser does not seem to support XMLHttpRequest.');
     }
 }
 function CheckMotorStandardFlag(lbTypeGarageId, standardFlagMotor, standardvalue, suminsure, suminsure5, ncbindex) {

//     LbTypeGarageId = context.Request["lbTypeGarageId"];
//     standardFlagMotor = Convert.ToInt32(context.Request["StandardFlagMotor"].Trim());
//     standardvalue = Convert.ToInt32(context.Request["StandardValue"].Trim());
//     suminsure = Convert.ToInt32(context.Request["SumInsure"].Trim());
//     suminsure5 = Convert.ToInt32(context.Request["SumInsure5"].Trim());
//     ncbindex = Convert.ToInt32(context.Request["NcbIndex"].Trim());
     URL = "CheckMotorStandardFlag.ashx?lbTypeGarageId=" + lbTypeGarageId + "&StandardFlagMotor=" + standardFlagMotor + "&StandardValue=" + standardvalue + "&SumInsure=" + suminsure + "&SumInsure5=" + suminsure5 + "&NcbIndex=" + ncbindex;
     AjaxGetData(URL, SendToAJAX);
}


function SendToAJAX(){
    try{
        //readyState of 4 or 'complete' represents 
        //that data has been returned 
        if (req.readyState == 4 ||  req.readyState == 'complete')
        {
            var arr1 = new Array();
            var result = req.responseText;

            var tmp1 = document.getElementById('ctl00_MainContent_imgStandard').src;
            var tmp2 = document.getElementById('ctl00_MainContent_imgNoneStandard').src;

            var tempflag = document.getElementById('ctl00_MainContent_txbHdStandardFlag').value;
            arr1 = result.split(",");
            //arr1[0] = YES/NO
            if (arr1[0]=="YES")
            {

                if (arr1[1] == "0") {//Non Standard 


                    document.getElementById('ctl00_MainContent_imgStandard').src = "../ImagesR3/emotion_sad_1.gif";
                    document.getElementById('ctl00_MainContent_lbStandard').innerHTML = "รายการนี้ต้องขออนุมัติค่ะ ";
                    
                    //======================FOR HIDDEN
                    document.getElementById('ctl00_MainContent_txbHdStandardFlag').value = 0;
                    //=======================
                } else {  //1

                    document.getElementById('ctl00_MainContent_imgStandard').src = "../ImagesR3/emotion_smile_1.gif";
                    document.getElementById('ctl00_MainContent_lbStandard').innerHTML = "ขอแสดงความยินดีด้วย ท่านสามารถออกกรมธรรม์ตามรายการนี้ได้ ";
                    
                    //======================FOR HIDDEN
                    document.getElementById('ctl00_MainContent_txbHdStandardFlag').value = 1;

                    
                }
                


            }else{
                document.getElementById('ctl00_MainContent_lbMessageHead').innerHTML = "เกิดข้อผิดพลาดในการดึงข้อมูลหรือไม่สามารถตรวจสอบข้อมูลนี้ได้";
            }
         }
    }
    catch(e){
        //alert('Error in Ajax respone');
    }
}
