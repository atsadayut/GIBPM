﻿
function AjaxGetData(url, responseHandler)
{
    if (window.XMLHttpRequest)
     {
         // browser has native support for XMLHttpRequest object
         req = new XMLHttpRequest();
     }
     else if (window.ActiveXObject)
     {
         // try XMLHTTP ActiveX (Internet Explorer) version
         req = new ActiveXObject("Microsoft.XMLHTTP");
     }
     
     if(req)
     {
         req.onreadystatechange = responseHandler;
         req.open('GET', url, true);
         req.setRequestHeader("content-type","application/x-www-form-urlencoded");
         req.send('');
     }
     else
     {
         alert('Your browser does not seem to support XMLHttpRequest.');
     }
 }

function GetPremiumPolicyTypeCompulsory(job) {
    URL = "GetListPremiumPolicyTypeCompulsory.ashx?JobNo=" + job;
    AjaxGetData(URL, SendToAJAX2GetCompulsory);
}

function GetPremiumPolicyTypeCompulsoryClear(job) {

    //BIND PREMIUM COMPULSORY
    document.getElementById('ctl00_MainContent_lbAmountPremiumCompl').innerHTML = "&nbsp;";
    document.getElementById('ctl00_MainContent_lbStampCompl').innerHTML = "&nbsp;";
    document.getElementById('ctl00_MainContent_lbTaxCompl').innerHTML = "&nbsp;";
    document.getElementById('ctl00_MainContent_lbNetPremiumCompl').innerHTML = "&nbsp;";

    document.getElementById('ctl00_MainContent_lbTotalPremium').innerHTML = "&nbsp;";
    //======================FOR HIDDEN
    document.getElementById('ctl00_MainContent_txbHdPremiumC').value = "0";
    document.getElementById('ctl00_MainContent_txbHdStampC').value = "0";
    document.getElementById('ctl00_MainContent_txbHdTaxC').value = "0";
    document.getElementById('ctl00_MainContent_txbHdNetPremiumC').value = "0";

    document.getElementById('ctl00_MainContent_txbHdTotalPremiumVC').value = "0";
}

function SendToAJAX2GetCompulsory() {
    try {
        //readyState of 4 or 'complete' represents 
        //that data has been returned 
        if (req.readyState == 4 || req.readyState == 'complete') {

            var arr1 = new Array();
            var result = req.responseText;

            arr1 = result.split(",");

            //arr1[0] = YES/NO  //FOUND OR NOT 
            if (arr1[0] == "YES") {

                var JobNo = arr1[1];
                var PackagePolicyType = arr1[2];
                if (PackagePolicyType == "Compulsory") {
                    //======================
                    var Garage_Contract = arr1[3];
                    var NetPremium_Contract = arr1[4];
                    var Stampduty_Contract = arr1[5];
                    var Vat_Contract = arr1[6];
                    var TotalPremium_Contract = arr1[7];
                    var CommercailCredit_Contract = arr1[8];
                    var OD_Deduct_Contract = arr1[9];
                    var PD_Deduct_Contract = arr1[10];
                    //========================

                    //BIND PREMIUM COMPULSORY
                    document.getElementById('ctl00_MainContent_lbAmountPremiumCompl').innerHTML = addNumber(NetPremium_Contract);
                    document.getElementById('ctl00_MainContent_lbStampCompl').innerHTML = addNumber(Stampduty_Contract);
                    document.getElementById('ctl00_MainContent_lbTaxCompl').innerHTML = addNumber(Vat_Contract);
                    document.getElementById('ctl00_MainContent_lbNetPremiumCompl').innerHTML = addNumber(TotalPremium_Contract);

                    
                    //======================FOR HIDDEN
                    document.getElementById('ctl00_MainContent_txbHdPremiumC').value = NetPremium_Contract;
                    document.getElementById('ctl00_MainContent_txbHdStampC').value = Stampduty_Contract;
                    document.getElementById('ctl00_MainContent_txbHdTaxC').value = Vat_Contract;
                    document.getElementById('ctl00_MainContent_txbHdNetPremiumC').value = TotalPremium_Contract;

                    var netcompl = document.getElementById('ctl00_MainContent_txbHdNetPremiumC').value;
                    var netvolun = document.getElementById('ctl00_MainContent_txbHdNetPremium').value;
                    netcompl = parseFloat(netcompl);
                    netvolun = parseFloat(netvolun);
                    var totalpremium = netcompl + netvolun;

                    document.getElementById('ctl00_MainContent_txbHdTotalPremiumVC').value = parseFloat(totalpremium).toFixed(2);
                    totalpremium = document.getElementById('ctl00_MainContent_txbHdTotalPremiumVC').value;
                    document.getElementById('ctl00_MainContent_lbTotalPremium').innerHTML = addNumber(totalpremium);


                    var controltbl1 = document.getElementById('ctl00_MainContent_lbInsureDetails');
                    controltbl1.style.display = "none";
                    controltbl1.style.visibility = "hidden";
                    var controltbl2 = document.getElementById('ctl00_MainContent_lbGroupButtonPrintPropersal');
                    controltbl2.style.visibility = "hidden";
                 
                }
                else {
                    document.getElementById('ctl00_MainContent_lbMessageHead').innerHTML = "เกิดข้อผิดพลาดในการดึงข้อมูล Package ไม่ถูกต้อง.";
                }
            }
            else {
                document.getElementById('ctl00_MainContent_lbMessageHead').innerHTML = "เกิดข้อผิดพลาดในการดึงข้อมูลหรือไม่สามารถตรวจสอบข้อมูลนี้ได้";
            }
        }
    }
    catch (e) {
        alert('Error in Ajax2 respone');
    }
}


/////////////////
//=========================================
function xSplitValue(x) {
    var arr = new Array();
    var item;
    var result;
    arr = (x).split(",");
    //alert(tempGross0[0]);
    //alert(tempGross0[1]);
    var done = true;
    for (item in arr) {
        if (done) {
            result = arr[item];
            done = false;
        }
        else {
            result += arr[item];
        }
    }

    return (result);
}

//===============================================
function addNumber(Number) {
    /* ถ้าต้องการใช้ เรียกใช้ใน หน้า asp ต้องเปลี่ยน parameter เป็น (ID,Text)
    และเปลี่ยน Number เป็น Number.value
    var NumClientID = "ctl00_"+ID+"_"+Text;
    //alert(document.getElementById(NumClientID));
    var Number = document.getElementById(NumClientID);*/

    var OutputNumber = "";
    var tmp = "";
    var FloatingPoint = ".00";

    Number = cutSemi(Number);
    if (getfloatingPoint(Number) == -1) {
        FloatingPoint = ".00";
    } else {

        FloatingPoint = getfloatingPoint(Number);
        FloatingPoint = parseFloat(FloatingPoint).toFixed(2);
        FloatingPoint = getfloatingPoint(FloatingPoint);
    }
    Number = cutFloatingPoint(Number);

    Number = revert(Number);

    for (var i = 0; i < Number.length; i++) {
        tmp += Number.charAt(i);
        if (((i + 1) % 3) == 0) {
            OutputNumber += tmp;
            OutputNumber += ",";
            tmp = "";
        }
    }
    OutputNumber += tmp;


    OutputNumber = revert(OutputNumber);
    if (OutputNumber.charAt(0) == ",") {
        OutputNumber = OutputNumber.substr(1, OutputNumber.length);
    }
    OutputNumber += FloatingPoint;
    Number = OutputNumber;
    return Number;

}
function revert(text) {
    var tmp = "";
    for (var i = text.length; i >= 0; i--) {
        tmp += text.charAt(i);
    }
    return tmp;
}
function cutSemi(text) {
    var tmp = "";
    for (var i = 0; i < text.length; i++) {
        if (text.charAt(i) != ",") {
            tmp += text.charAt(i);
        }
    }
    return tmp;
}

function cutFloatingPoint(text) {
    var tmp = "";
    for (var i = 0; i < text.length; i++) {
        if (text.charAt(i) != ".") {

            tmp += text.charAt(i);
        } else break;

    }
    return tmp;
}
function getfloatingPoint(text) {
    var tmp = "";
    var i = 0;
    for (var i = 0; i < text.length; i++) {
        if (text.charAt(i) == ".") break;
    }
    if (i == text.length) {

        return -1;
    }

    for (var j = i; j < text.length; j++) {
        tmp += text.charAt(j);
    }
    return tmp;
}
