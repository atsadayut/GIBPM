USE [DBTAB2B]
GO

/****** Object:  Table [dbo].[TATransTraveler]    Script Date: 27/4/2016 11:05:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TATransTraveler](
	[JobNo] [nvarchar](30) NOT NULL,
	[TravelerId] [int] NOT NULL,
	[ClientCode] [nvarchar](20) NULL,
	[ClientTitle] [nvarchar](8) NULL,
	[ClientName] [nvarchar](60) NULL,
	[ClientSurName] [nvarchar](60) NULL,
	[Birthday] [datetime] NULL,
	[PassportID] [nvarchar](13) NULL,
	[Tel] [nvarchar](30) NULL,
	[SumInsuredPA] [numeric](18, 0) NULL,
	[NetPremium] [numeric](18, 2) NULL,
	[Stamp] [int] NULL,
	[SBT] [numeric](18, 2) NULL,
	[TotalPremium] [numeric](18, 2) NULL,
	[isStudent] [tinyint] NULL,
	[isSingle] [tinyint] NULL,
	[CreateDate] [datetime] NULL CONSTRAINT [DF_TATransTraveler_CreateDate]  DEFAULT (getdate()),
	[Message] [nvarchar](200) NULL,
 CONSTRAINT [PK_TATransTraveler] PRIMARY KEY CLUSTERED 
(
	[JobNo] ASC,
	[TravelerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


