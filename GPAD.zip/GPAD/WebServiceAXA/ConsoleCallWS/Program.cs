﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleCallWS
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceAXA.INF_AXATAWS serviceAXA = new ServiceAXA.INF_AXATAWS();
            try
            {
                string AGENTCODE = "BD039";
                string GROUPBROKERID = "BK004";
                string SERVICEPASSWORD = "Password@1";


                ServiceAXA.ObjAXATAListPlanPackage listPlanPackage = serviceAXA.GetAXATAPlanPackage(AGENTCODE, GROUPBROKERID, SERVICEPASSWORD, "INDIVIDUAL", "26/11/2015", "27/11/2015", "SCHENGEN");

                var headList = (from v in listPlanPackage._listPlanPackage
                                group v by v._TAPlanID into g
                                select new { PlanId = g.Key, Package = g.ToList() }).OrderBy(v => v.PlanId);

                listPlanPackage = serviceAXA.GetAXATAPlanPackage(AGENTCODE, GROUPBROKERID, SERVICEPASSWORD, "INDIVIDUAL", "26/11/2015", "27/11/2015", "JAPAN");

                headList = (from v in listPlanPackage._listPlanPackage
                                group v by v._TAPlanID into g
                                select new { PlanId = g.Key, Package = g.ToList() }).OrderBy(v => v.PlanId);

                ServiceAXA.ObjAXATAPolicyHolderDetail policyHolderDetail = new ServiceAXA.ObjAXATAPolicyHolderDetail();
                policyHolderDetail._amphurID = "06";
                policyHolderDetail._amphur = "NONG TAK YA";

                policyHolderDetail._province = "KANCHANABURI";
                policyHolderDetail._provinceID = "71";

                policyHolderDetail._clientAddress1 = "Test by krit";
                policyHolderDetail._clientAddress2 = "Test Sql Connection";

                policyHolderDetail._clientTitle = "Mr.";
                policyHolderDetail._clientName = "Choosak";
                policyHolderDetail._clientSurName = "Kerdphon";

                policyHolderDetail._clientType = "Audit";
                policyHolderDetail._discountCode = "";
                policyHolderDetail._email = "choosak.ke@axa.co.th";
                policyHolderDetail._idCard = "AB1234";
                policyHolderDetail._postCode = "10210";
                policyHolderDetail._tel = "0983825117";

                policyHolderDetail._tumbol = "TUMBON NONG TAK YA";
                policyHolderDetail._tumbolID = "1300";

                policyHolderDetail._birthday = "17/08/1983";


                ServiceAXA.ObjAXATATravellerDetail[] travellerDetail = new  ServiceAXA.ObjAXATATravellerDetail[2];
                travellerDetail[0] = new ServiceAXA.ObjAXATATravellerDetail();
                travellerDetail[0]._beneficiary = "0b a ce";
                travellerDetail[0]._beneficiaryRelation = "Dad";
                travellerDetail[0]._birthday = "17/08/1983";

                travellerDetail[0]._clientTitle = "0Mr.";
                travellerDetail[0]._clientName = "Surusak";
                travellerDetail[0]._clientSurName = "Kerdphon";
                travellerDetail[0]._passportID = "AB456798";

                travellerDetail[1] = new ServiceAXA.ObjAXATATravellerDetail();
                travellerDetail[1]._beneficiary = "1b a ce";
                travellerDetail[1]._beneficiaryRelation = "Dad";
                travellerDetail[1]._birthday = "17/08/1983";

                travellerDetail[1]._clientTitle = "1Mr.";
                travellerDetail[1]._clientName = "Surusak";
                travellerDetail[1]._clientSurName = "Kerdphon";
                travellerDetail[1]._passportID = "AB456798";

                //travellerDetail[2] = new ServiceAXA.ObjAXATATravellerDetail();
                //travellerDetail[2]._beneficiary = "2b a ce";
                //travellerDetail[2]._beneficiaryRelation = "Dad";
                //travellerDetail[2]._birthday = "17/08/1983";

                //travellerDetail[2]._clientTitle = "2Mr.";
                //travellerDetail[2]._clientName = "Surusak";
                //travellerDetail[2]._clientSurName = "Kerdphon";
                //travellerDetail[2]._passportID = "AB456798";

                //travellerDetail[3] = new ServiceAXA.ObjAXATATravellerDetail();
                //travellerDetail[3]._beneficiary = "3b a ce";
                //travellerDetail[3]._beneficiaryRelation = "Dad";
                //travellerDetail[3]._birthday = "17/08/1983";

                //travellerDetail[3]._clientTitle = "3Mr.";
                //travellerDetail[3]._clientName = "Surusak";
                //travellerDetail[3]._clientSurName = "Kerdphon";
                //travellerDetail[3]._passportID = "AB456798";

                //travellerDetail[4] = new ServiceAXA.ObjAXATATravellerDetail();
                //travellerDetail[4]._beneficiary = "4b a ce";
                //travellerDetail[4]._beneficiaryRelation = "Dad";
                //travellerDetail[4]._birthday = "17/08/1983";

                //travellerDetail[4]._clientTitle = "4Mr.";
                //travellerDetail[4]._clientName = "Surusak";
                //travellerDetail[4]._clientSurName = "Kerdphon";
                //travellerDetail[4]._passportID = "AB456798";

                //travellerDetail[5] = new ServiceAXA.ObjAXATATravellerDetail();
                //travellerDetail[5]._beneficiary = "5b a ce";
                //travellerDetail[5]._beneficiaryRelation = "Dad";
                //travellerDetail[5]._birthday = "17/08/1983";

                //travellerDetail[5]._clientTitle = "5Mr.";
                //travellerDetail[5]._clientName = "Surusak";
                //travellerDetail[5]._clientSurName = "Kerdphon";
                //travellerDetail[5]._passportID = "AB456798";

                ServiceAXA.ObjAXATATravellerDetail[] travellerChildeDetail = new ServiceAXA.ObjAXATATravellerDetail[0];

                //for(int i=0;i<=10;i++)
                //{
                //    ServiceAXA.ObjAXATAPolicyIssued result = serviceAXA.ProcessAXATAPolicyIssue(AGENTCODE, GROUPBROKERID, SERVICEPASSWORD, "E", "SCHENGEN", "26/11/2015", "27/11/2015", "INDIVIDUAL", "0004", policyHolderDetail, travellerDetail, travellerChildeDetail, "001", false, "", "", "", "choosak.ke@axa.co.th", false);

                //    if (result._msg == "SUCCESS")
                //    {

                //    }
                //    else
                //    {

                //    }
                //    Console.WriteLine(result._msg);
                //}

                ServiceAXA.ObjAXATAPolicyIssued[] result = serviceAXA.ProcessAXATAPolicyIndividualIssue(AGENTCODE, GROUPBROKERID, SERVICEPASSWORD, "E", "SCHENGEN", "09/03/2016", "11/03/2016", "INDIVIDUAL", "0004", policyHolderDetail, travellerDetail, "002", false, "", "", "", "choosak.ke@axa.co.th", false);
                foreach(var item in result)
                {
                    Console.WriteLine(item._policyNo);

                    Console.WriteLine(item._deliverDocMsg);

                    Console.WriteLine(item._msg);
                }
                Console.ReadLine();

            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
            finally
            {
                serviceAXA.Dispose();
            }
        }
    }
}
