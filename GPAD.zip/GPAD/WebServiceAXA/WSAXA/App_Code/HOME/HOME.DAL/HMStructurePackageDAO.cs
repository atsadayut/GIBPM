using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;

namespace HOME.DAL
{
	public class HMStructurePackageDAO
	{
        public HMStructurePackageDAO()
		{
            DbProviderHelper.GetConnection();
		}

        public DataTable GetHMStructurePackages(string Language, string AOBCode)
		{
			try
			{
                DataTable data = new DataTable();

                DbCommand comm = DbProviderHelper.CreateCommand("spHM_getStructurePackage", CommandType.StoredProcedure);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@Language", DbType.String, Language));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@AOBCode", DbType.String, AOBCode));

                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                DbProviderHelper.FillDataTable(adap);
                adap.Fill(data);
                // get data and return with DataTable object
                DbProviderHelper.CloseDb();
                return data;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		
	}
}
