using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;

namespace HOME.DAL
{
	public class HMPlanPackageDAO
	{
		public HMPlanPackageDAO()
		{
            DbProviderHelper.GetConnection();
		}
        public DataTable GetHMPlanPackages(string groupBrokerId,string Language, string AOBCode, string StructurePackageCode, Int64 BuildingSumInsured, Int64 ContentSumInsured)
		{
			try
			{
                DataTable data = new DataTable();

                DbCommand comm = DbProviderHelper.CreateCommand("spHM_getPlanPackage", CommandType.StoredProcedure);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@groupBrokerId", DbType.String, groupBrokerId));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@Language", DbType.String, Language));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@AOBCode", DbType.String, AOBCode));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@StructurePackageCode", DbType.String, StructurePackageCode));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@BuildingSumInsured", DbType.Int64, BuildingSumInsured));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@ContentSumInsured", DbType.Int64, ContentSumInsured));

                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                DbProviderHelper.FillDataTable(adap);
                adap.Fill(data);
                // get data and return with DataTable object
                DbProviderHelper.CloseDb();
                return data;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		
	}
}
