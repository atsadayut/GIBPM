using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;

namespace HOME.DAL
{
	public class HMJobRunningDAO
	{
		public HMJobRunningDAO()
		{
            DbProviderHelper.GetConnection();
		}
		public string GetHMJobRunnings()
		{
			try
			{
                DbCommand comm = DbProviderHelper.CreateCommand("spHM_setJobNo", CommandType.StoredProcedure);

                // create parameter and direction
                DbParameter param = comm.CreateParameter();
                param.ParameterName = "@GetJobNo";
                param.DbType = DbType.String;
                param.Size = 20;
                param.Direction = ParameterDirection.Output;
                comm.Parameters.Add(param);

                //execute command
                int ret = DbProviderHelper.ExecuteNonQuery(comm);
                //return jobno
                return param.Value.ToString();
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

	}
}
