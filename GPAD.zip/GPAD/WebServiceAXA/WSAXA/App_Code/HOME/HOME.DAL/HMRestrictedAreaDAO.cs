using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;

namespace HOME.DAL
{
	public class HMRestrictedAreaDAO
	{
		public HMRestrictedAreaDAO()
		{
            DbProviderHelper.GetConnection();
		}
        public bool CheckHMRestrictedAreas(string Address1, string Address2, string Road, string Tumbol, string Amphur, string Province)
		{
			try
			{
                DbCommand comm = DbProviderHelper.CreateCommand("spHM_chkRestrictedArea", CommandType.StoredProcedure);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@Address1", DbType.String, Address1));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@Address2", DbType.String, Address2));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@Road", DbType.String, Road));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@Tumbol", DbType.String, Tumbol));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@Amphur", DbType.String, Amphur));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@Province", DbType.String, Province));

                DbDataReader oDbDataReader = DbProviderHelper.ExecuteReader(comm);

                bool result = false;
				while (oDbDataReader.Read())
				{

                    if (oDbDataReader["IsRestrictedArea"] != DBNull.Value)
                        result = Convert.ToBoolean(oDbDataReader["IsRestrictedArea"]);

				}
				oDbDataReader.Close();
                return result;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		
	}
}
