using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;

namespace HOME.DAL
{
	public class HMLongTermRateDAO
	{
		public HMLongTermRateDAO()
		{
            DbProviderHelper.GetConnection();
		}
        public DataTable GetHMCoveredYears()
		{
            try
            {
                DataTable data = new DataTable();

                DbCommand comm = DbProviderHelper.CreateCommand("spHM_getDDLCoveredYears", CommandType.StoredProcedure);

                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                DbProviderHelper.FillDataTable(adap);
                adap.Fill(data);
                // get data and return with DataTable object
                DbProviderHelper.CloseDb();
                return data;
            }
            catch (Exception ex)
            {
                throw ex;
            }
		}
		
	}
}
