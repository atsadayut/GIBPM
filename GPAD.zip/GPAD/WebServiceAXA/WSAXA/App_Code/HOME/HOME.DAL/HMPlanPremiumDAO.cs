using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;

namespace HOME.DAL
{
	public class HMPlanPremiumDAO
	{
		public HMPlanPremiumDAO()
		{
            DbProviderHelper.GetConnection();
		}
        public DataTable GetHMPlanPremium(string AOBCode, string StructurePackageCode, string PackageID, Int64 BuildingSumInsured, Int64 ContentSumInsured)
		{
            try
            {

                DbCommand comm = DbProviderHelper.CreateCommand("spHM_getPlanPremium", CommandType.StoredProcedure);
                
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@AOBCode", DbType.String, AOBCode));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@StructurePackageCode", DbType.String, StructurePackageCode));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@PackageID", DbType.String, PackageID));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@BuildingSumInsured", DbType.Int64, BuildingSumInsured));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@ContentSumInsured", DbType.Int64, ContentSumInsured));

                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                
                //adap.Fill(data);
                // get data and return with DataTable object
                //DbProviderHelper.CloseDb();
                return DbProviderHelper.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                throw ex;
            }
		}
		
	}
}
