using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;

namespace HOME.DAL
{
	public class HMTransPolicyHolderDAO
	{
		public HMTransPolicyHolderDAO()
		{
            DbProviderHelper.GetConnection();
		}

        public int AddHMTransPolicyHolder(string JOBNO, string Language, string ClientType, string ClientTitle, string ClientName, string ClientSurName, string LongName, string BranchNo, string ClientAddress1, string ClientAddress2, string Province, string Amphur, string Tumbol, string Postcode, string Birthday, string IdCard, string Tel, string Email, DbTransaction dbTransaction)
		{
			try
			{

                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spHM_setTransPolicyHolder", CommandType.StoredProcedure, dbTransaction);
                if (JOBNO != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JOBNO", DbType.String, JOBNO));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JOBNO", DbType.String, DBNull.Value));
                if (Language != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Language", DbType.String, Language));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Language", DbType.String, DBNull.Value));
				if (ClientType!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientType",DbType.String,ClientType));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientType",DbType.String,DBNull.Value));
				if (ClientTitle!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientTitle",DbType.String,ClientTitle));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientTitle",DbType.String,DBNull.Value));
				if (ClientName!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientName",DbType.String,ClientName));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientName",DbType.String,DBNull.Value));
				if (ClientSurName!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSurName",DbType.String,ClientSurName));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSurName",DbType.String,DBNull.Value));
                if (LongName != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LongName", DbType.String, LongName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LongName", DbType.String, DBNull.Value));
                if (BranchNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BranchNo", DbType.String, BranchNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BranchNo", DbType.String, DBNull.Value));

                
				if (ClientAddress1!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientAddress1",DbType.String,ClientAddress1));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientAddress1",DbType.String,DBNull.Value));
				if (ClientAddress2!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientAddress2",DbType.String,ClientAddress2));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientAddress2",DbType.String,DBNull.Value));
				if (Province!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Province",DbType.String,Province));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Province",DbType.String,DBNull.Value));
				if (Amphur!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Amphur",DbType.String,Amphur));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Amphur",DbType.String,DBNull.Value));
				if (Tumbol!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tumbol",DbType.String,Tumbol));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tumbol",DbType.String,DBNull.Value));
                if (Postcode != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Postcode", DbType.String, Postcode));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Postcode", DbType.String, DBNull.Value));
				
				if (Birthday!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Birthday",DbType.String,Birthday));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Birthday",DbType.String,DBNull.Value));

                if (IdCard != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@IdCard", DbType.String, IdCard));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@IdCard", DbType.String, DBNull.Value));
				
				if (Tel!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tel",DbType.String,Tel));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tel",DbType.String,DBNull.Value));
				if (Email!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Email",DbType.String,Email));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Email",DbType.String,DBNull.Value));


                return DbProviderHelper.ExecuteNonQuery(oDbCommand, true);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
        public int AddHMTransPolicyInsured(string JOBNO, int InsuredId, string ClientTitle, string ClientName, string ClientSurName, Nullable<DateTime> Birthday, string IDCard, string Tel, Nullable<Int64> BuildingSumInsured, Nullable<Int64> ContentSumInsured, Nullable<Int64> NetPremium, Nullable<Int64> Stamp, Nullable<Int64> VAT, Nullable<Int64> TotalPremium, DbTransaction dbTransaction)
        {
            try
            {

                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spHM_setTransPolicyInsured", CommandType.StoredProcedure, dbTransaction);
                if (JOBNO != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JOBNO", DbType.String, JOBNO));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JOBNO", DbType.String, DBNull.Value));
                if (InsuredId != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@InsuredId", DbType.Int16, InsuredId));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@InsuredId", DbType.Int16, DBNull.Value));
                
                if (ClientTitle != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientTitle", DbType.String, ClientTitle));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientTitle", DbType.String, DBNull.Value));
                if (ClientName != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientName", DbType.String, ClientName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientName", DbType.String, DBNull.Value));
                if (ClientSurName != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSurName", DbType.String, ClientSurName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSurName", DbType.String, DBNull.Value));

                if (Birthday != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Birthday", DbType.DateTime, Birthday));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Birthday", DbType.DateTime, DBNull.Value));

                if (IDCard != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@IDCard", DbType.String, IDCard));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@IDCard", DbType.String, DBNull.Value));

                if (Tel != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tel", DbType.String, Tel));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tel", DbType.String, DBNull.Value));
                if (BuildingSumInsured.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BuildingSumInsured", DbType.Int64, BuildingSumInsured));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BuildingSumInsured", DbType.Int64, DBNull.Value));
                if (ContentSumInsured.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ContentSumInsured", DbType.Int64, ContentSumInsured));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ContentSumInsured", DbType.Int64, DBNull.Value));
                if (NetPremium.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NetPremium", DbType.Int64, NetPremium));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NetPremium", DbType.Int64, DBNull.Value));
                if (Stamp.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Stamp", DbType.Int64, Stamp));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Stamp", DbType.Int64, DBNull.Value));
                if (VAT.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@VAT", DbType.Int64, VAT));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@VAT", DbType.Int64, DBNull.Value));
                if (TotalPremium.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TotalPremium", DbType.Int64, TotalPremium));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TotalPremium", DbType.Int64, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand, true);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
		
	}
}
