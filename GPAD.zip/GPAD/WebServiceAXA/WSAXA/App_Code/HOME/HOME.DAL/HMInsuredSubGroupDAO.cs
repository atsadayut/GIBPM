using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;

namespace HOME.DAL
{
	public class HMInsuredSubGroupDAO
	{
		public HMInsuredSubGroupDAO()
		{
            DbProviderHelper.GetConnection();
		}
        public DataTable GetHMInsuredSubGroups(string Language)
		{
			try
			{
                DataTable data = new DataTable();

                DbCommand comm = DbProviderHelper.CreateCommand("spHM_getDDLAppearanceOfBuilding", CommandType.StoredProcedure);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@Language", DbType.String, Language));

                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                // get data and return with DataTable object
                adap.Fill(data);
                // get data and return with DataTable object
                DbProviderHelper.CloseDb();
                return data;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		
	}
}
