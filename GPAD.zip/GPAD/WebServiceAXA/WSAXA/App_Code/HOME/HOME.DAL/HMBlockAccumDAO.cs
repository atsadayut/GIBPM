using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;

namespace HOME.DAL
{
	public class HMBlockAccumDAO
	{
		public HMBlockAccumDAO()
		{
            DbProviderHelper.GetConnection();
		}

        public DataTable GetHMBlock(string tumbol,string amphur, string province)
        {
            try
            {

                DbCommand comm = DbProviderHelper.CreateCommand("spHM_getBlockAccum", CommandType.StoredProcedure);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@Tumbol", DbType.String, tumbol));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@Amphur", DbType.String, amphur));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@Province", DbType.String, province));

                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                
                return DbProviderHelper.FillDataTable(adap); ;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
		
	}
}
