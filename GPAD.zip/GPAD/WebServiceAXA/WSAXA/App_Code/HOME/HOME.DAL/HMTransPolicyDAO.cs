using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;

namespace HOME.DAL
{
	public class HMTransPolicyDAO
	{
		public HMTransPolicyDAO()
		{
            DbProviderHelper.GetConnection();
		}

        public int AddHMTransPolicy(string JobNo, string language, string InsuredSubGroupCode, string PackageCode, string PackageID, string EffectiveDateFrom, string CoveredYear, string GroupBrokerID, string AgentCode, Nullable<Decimal> NetPremium, Nullable<int> Stamp, Nullable<Decimal> VAT, Nullable<Decimal> TotalPremium, Nullable<bool> isLongName, Nullable<bool> isPA, string CreateUser)
		{
			try
			{
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spHM_setTransPolicy", CommandType.StoredProcedure);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (language != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Lang", DbType.String, language));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Lang", DbType.String, DBNull.Value));
                if (InsuredSubGroupCode != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@InsuredSubGroupCode", DbType.String, InsuredSubGroupCode));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@InsuredSubGroupCode", DbType.String, DBNull.Value));
				
				if (PackageCode!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PackageCode", DbType.String, PackageCode));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PackageCode", DbType.String, DBNull.Value));
				if (PackageID!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PackageID", DbType.String, PackageID));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PackageID", DbType.String, DBNull.Value));
				if (EffectiveDateFrom!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EffectiveDateFrom", DbType.String, EffectiveDateFrom));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EffectiveDateFrom", DbType.String, DBNull.Value));
                if (CoveredYear != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CoveredYear", DbType.Int16, CoveredYear));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CoveredYear", DbType.Int16, DBNull.Value));
                if (GroupBrokerID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerID", DbType.String, GroupBrokerID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerID", DbType.String, DBNull.Value));
				
                if (AgentCode!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AgentCode", DbType.String, AgentCode));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AgentCode", DbType.String, DBNull.Value));
				
				if (NetPremium.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NetPremium", DbType.Decimal, NetPremium));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NetPremium", DbType.Decimal, DBNull.Value));
				if (Stamp.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Stamp", DbType.Int32, Stamp));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Stamp", DbType.Int32, DBNull.Value));
				if (VAT.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@VAT", DbType.Decimal, VAT));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@VAT", DbType.Decimal, DBNull.Value));
				
				if (TotalPremium.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TotalPremium", DbType.Decimal, TotalPremium));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TotalPremium", DbType.Decimal, DBNull.Value));
				if (isLongName.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isLongName", DbType.Boolean, isLongName));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isLongName", DbType.Boolean, DBNull.Value));
				if (isPA.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isPA", DbType.Boolean, isPA));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isPA", DbType.Boolean, DBNull.Value));
				
				if (CreateUser!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreateUser", DbType.String, CreateUser));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreateUser", DbType.String, DBNull.Value));
				

                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
        public int AddHMTransPolicy(string JobNo, string language, string InsuredSubGroupCode, string PackageCode, string PackageID, string EffectiveDateFrom, string CoveredYear, string GroupBrokerID, string AgentCode, Nullable<Decimal> NetPremium, Nullable<int> Stamp, Nullable<Decimal> VAT, Nullable<Decimal> TotalPremium, Nullable<bool> isLongName, Nullable<bool> isPA, string CreateUser, DbTransaction dbTransaction)
        {
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spHM_setTransPolicy", CommandType.StoredProcedure, dbTransaction);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (language != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Lang", DbType.String, language));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Lang", DbType.String, DBNull.Value));

                if (InsuredSubGroupCode != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@InsuredSubGroupCode", DbType.String, InsuredSubGroupCode));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@InsuredSubGroupCode", DbType.String, DBNull.Value));

                if (PackageCode != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PackageCode", DbType.String, PackageCode));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PackageCode", DbType.String, DBNull.Value));
                if (PackageID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PackageID", DbType.String, PackageID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PackageID", DbType.String, DBNull.Value));
                if (EffectiveDateFrom != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EffectiveDateFrom", DbType.String, EffectiveDateFrom));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EffectiveDateFrom", DbType.String, DBNull.Value));
                if (CoveredYear != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CoveredYear", DbType.Int16, CoveredYear));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CoveredYear", DbType.Int16, DBNull.Value));
                if (GroupBrokerID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerID", DbType.String, GroupBrokerID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerID", DbType.String, DBNull.Value));

                if (AgentCode != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AgentCode", DbType.String, AgentCode));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AgentCode", DbType.String, DBNull.Value));

                if (NetPremium.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NetPremium", DbType.Decimal, NetPremium));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NetPremium", DbType.Decimal, DBNull.Value));
                if (Stamp.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Stamp", DbType.Int32, Stamp));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Stamp", DbType.Int32, DBNull.Value));
                if (VAT.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@VAT", DbType.Decimal, VAT));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@VAT", DbType.Decimal, DBNull.Value));

                if (TotalPremium.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TotalPremium", DbType.Decimal, TotalPremium));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TotalPremium", DbType.Decimal, DBNull.Value));
                if (isLongName.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isLongName", DbType.Boolean, isLongName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isLongName", DbType.Boolean, DBNull.Value));
                if (isPA.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isPA", DbType.Boolean, isPA));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isPA", DbType.Boolean, DBNull.Value));

                if (CreateUser != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@User", DbType.String, CreateUser));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@User", DbType.String, DBNull.Value));


                return DbProviderHelper.ExecuteNonQuery(oDbCommand, true);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //---------------------------------------------------------------------
        public int SetHMTransTaxInvoince(string PolicyNo, string JobNo, string UserID)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spHM_setTransTaxInvoince", CommandType.StoredProcedure);
                if (PolicyNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@POLICYNO", DbType.String, PolicyNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@POLICYNO", DbType.String, DBNull.Value));
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JOBNO", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JOBNO", DbType.String, DBNull.Value));
                if (UserID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@USERID", DbType.String, UserID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@USERID", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand, true);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public int SetHMTransPrint(string PolicyNo, string JobNo, string AgentCode, string GroupBrokerId, string CreatedUser)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spHM_SetTransPrint", CommandType.StoredProcedure);
                if (PolicyNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, PolicyNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, DBNull.Value));
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (AgentCode != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AgentCode", DbType.String, AgentCode));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AgentCode", DbType.String, DBNull.Value));
                if (GroupBrokerId != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId", DbType.String, GroupBrokerId));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId", DbType.String, DBNull.Value));
                if (CreatedUser != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreatedUser", DbType.String, CreatedUser));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreatedUser", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand, true);


            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        //---------------------------------------------------------------------
        public string spHM_setPolicyNo()
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand comm = DbProviderHelper.CreateCommand("spHM_setPolicyNo", CommandType.StoredProcedure);

                // create parameter and direction
                DbParameter param = comm.CreateParameter();
                param.ParameterName = "@PolicyNo";
                param.DbType = DbType.String;
                param.Size = 20;
                param.Direction = ParameterDirection.Output;
                comm.Parameters.Add(param);

                //execute command
                int ret = DbProviderHelper.ExecuteNonQuery(comm);

                //return jobno
                return param.Value.ToString();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public string spHM_setPolicyNo(string JobNo)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand comm = DbProviderHelper.CreateCommand("spHM_setPolicyNoByJobNo", CommandType.StoredProcedure);

                // create parameter and direction
                DbParameter param = comm.CreateParameter();
                param.ParameterName = "@PolicyNo";
                param.DbType = DbType.String;
                param.Size = 20;
                param.Direction = ParameterDirection.Output;
                comm.Parameters.Add(param);

                DbParameter param2 = comm.CreateParameter();
                param2.ParameterName = "@JobNo";
                param2.DbType = DbType.String;
                param2.Size = 200;
                param2.Value = JobNo;
                param2.Direction = ParameterDirection.Input;
                comm.Parameters.Add(param2);

                //execute command
                int ret = DbProviderHelper.ExecuteNonQuery(comm);

                //return jobno
                return param.Value.ToString();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        public int spHM_UpdatePolicyNoToJobNo(string JobNo, string PolicyNo, string RETURNINV)
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();

                DbCommand oDbCommand = DbProviderHelper.CreateCommand("UPDATE [HMTransPolicy] SET [PolicyNo]=@PolicyNo, [RETURNINV] = @RETURNINV WHERE [JobNo] = @JobNo", CommandType.Text);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (PolicyNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, PolicyNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, DBNull.Value));

                if (RETURNINV != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@RETURNINV", DbType.String, RETURNINV));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@RETURNINV", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetHMPrintListReportName(string PolicyNo)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand comm = DbProviderHelper.CreateCommand("spHM_GetPrintListReportName", CommandType.StoredProcedure);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, PolicyNo));


                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return DbProviderHelper.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
	}
}
