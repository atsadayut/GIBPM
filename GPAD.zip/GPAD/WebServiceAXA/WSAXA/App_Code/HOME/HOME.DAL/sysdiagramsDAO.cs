using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;

namespace HOME.DAL
{
	public class sysdiagramsDAO
	{
		public sysdiagramsDAO()
		{
			DbProviderHelper.GetConnection();
		}
		public List<sysdiagrams> Getsysdiagramss()
		{
			try
			{
				List<sysdiagrams> lstsysdiagramss = new List<sysdiagrams>();
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("SELECT [name],[principal_id],[diagram_id],[version],[definition] FROM [sysdiagrams]",CommandType.Text);
				DbDataReader oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					sysdiagrams osysdiagrams = new sysdiagrams();
					osysdiagrams.name = Convert.ToString(oDbDataReader["name"]);
					osysdiagrams.principal_id = Convert.ToInt32(oDbDataReader["principal_id"]);
					osysdiagrams.diagram_id = Convert.ToInt32(oDbDataReader["diagram_id"]);

					if(oDbDataReader["version"] != DBNull.Value)
						osysdiagrams.version = Convert.ToInt32(oDbDataReader["version"]);

					if(oDbDataReader["definition"] != DBNull.Value)
						osysdiagrams.definition = (Byte[])(oDbDataReader["definition"]);
					lstsysdiagramss.Add(osysdiagrams);
				}
				oDbDataReader.Close();
				return lstsysdiagramss;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public sysdiagrams Getsysdiagrams(int diagram_id)
		{
			try
			{
				sysdiagrams osysdiagrams = new sysdiagrams();
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("SELECT [name],[principal_id],[diagram_id],[version],[definition] FROM [sysdiagrams] WHERE [diagram_id]=@diagram_id",CommandType.Text);
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@diagram_id",DbType.Int32,diagram_id));
				DbDataReader oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					osysdiagrams.name = Convert.ToString(oDbDataReader["name"]);
					osysdiagrams.principal_id = Convert.ToInt32(oDbDataReader["principal_id"]);
					osysdiagrams.diagram_id = Convert.ToInt32(oDbDataReader["diagram_id"]);

					if(oDbDataReader["version"] != DBNull.Value)
						osysdiagrams.version = Convert.ToInt32(oDbDataReader["version"]);

					if(oDbDataReader["definition"] != DBNull.Value)
						osysdiagrams.definition = (Byte[])(oDbDataReader["definition"]);
				}
				oDbDataReader.Close();
				return osysdiagrams;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public int Addsysdiagrams(string name,int principal_id,Nullable<int> version,Byte[] definition)
		{
			try
			{
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("INSERT INTO [sysdiagrams]([name],[principal_id],[version],[definition])VALUES(@name,@principal_id,@version,@definition);SELECT SCOPE_IDENTITY();",CommandType.Text);
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@name",DbType.String,name));
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@principal_id",DbType.Int32,principal_id));
				if (version.HasValue)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@version",DbType.Int32,version));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@version",DbType.Int32,DBNull.Value));
				if (definition!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@definition",DbType.Binary,definition));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@definition",DbType.Binary,DBNull.Value));

				return Convert.ToInt32(DbProviderHelper.ExecuteScalar(oDbCommand));
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public int Updatesysdiagrams(string name,int principal_id,int diagram_id,Nullable<int> version,Byte[] definition)
		{

			try
			{
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("UPDATE [sysdiagrams] SET [name]=@name,[principal_id]=@principal_id,[version]=@version,[definition]=@definition WHERE [diagram_id]=@diagram_id",CommandType.Text);
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@name",DbType.String,name));
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@principal_id",DbType.Int32,principal_id));
				if (version.HasValue)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@version",DbType.Int32,version));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@version",DbType.Int32,DBNull.Value));
				if (definition!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@definition",DbType.Binary,definition));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@definition",DbType.Binary,DBNull.Value));
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@diagram_id",DbType.Int32,diagram_id));
				return DbProviderHelper.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public int Removesysdiagrams(int diagram_id)
		{

			try
			{
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("DELETE FROM [sysdiagrams] WHERE [diagram_id]=@diagram_id",CommandType.Text);
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@diagram_id",DbType.Int32,diagram_id));
				return DbProviderHelper.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}
