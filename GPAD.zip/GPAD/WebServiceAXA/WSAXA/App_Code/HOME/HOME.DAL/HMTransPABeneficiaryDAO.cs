using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;

namespace HOME.DAL
{
	public class HMTransPABeneficiaryDAO
	{
		public HMTransPABeneficiaryDAO()
		{
            DbProviderHelper.GetConnection();
		}

        public int AddHMTransPABeneficiary(string JobNo, int LocationNo, int PASeq, string PATitle, string PAName, string PASurName, string PAID, string PADOB, string PABeneficiary, string PARelation)
		{
			try
			{
                
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spHM_setTransPABeneficiary", CommandType.StoredProcedure);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, PATitle));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (LocationNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LocationNo", DbType.Int16, LocationNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LocationNo", DbType.Int16, DBNull.Value));
                if (PASeq != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PASeq", DbType.Int16, PASeq));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PASeq", DbType.Int16, DBNull.Value));
				if (PATitle!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PATitle",DbType.String,PATitle));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PATitle",DbType.String,DBNull.Value));
				if (PAName!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PAName",DbType.String,PAName));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PAName",DbType.String,DBNull.Value));
				if (PASurName!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PASurName",DbType.String,PASurName));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PASurName",DbType.String,DBNull.Value));
				if (PAID!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PAID",DbType.String,PAID));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PAID",DbType.String,DBNull.Value));
				if (PADOB != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PADOB", DbType.String, PADOB));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PADOB", DbType.String, DBNull.Value));
				if (PABeneficiary!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PABeneficiary",DbType.String,PABeneficiary));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PABeneficiary",DbType.String,DBNull.Value));
				if (PARelation!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PARelation",DbType.String,PARelation));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PARelation",DbType.String,DBNull.Value));

				return DbProviderHelper.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

        public int AddHMTransPABeneficiary(string JobNo, int LocationNo, int PASeq, string PATitle, string PAName, string PASurName, string PAID, string PADOB, string PABeneficiary, string PARelation, DbTransaction dbTransaction)
        {
            try
            {

                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spHM_setTransPABeneficiary", CommandType.StoredProcedure, dbTransaction);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (LocationNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LocationNo", DbType.Int16, LocationNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LocationNo", DbType.Int16, DBNull.Value));
                if (PASeq != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PASeq", DbType.Int16, PASeq));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PASeq", DbType.Int16, DBNull.Value));
                if (PATitle != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PATitle", DbType.String, PATitle));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PATitle", DbType.String, DBNull.Value));
                if (PAName != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PAName", DbType.String, PAName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PAName", DbType.String, DBNull.Value));
                if (PASurName != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PASurName", DbType.String, PASurName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PASurName", DbType.String, DBNull.Value));
                if (PAID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PAID", DbType.String, PAID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PAID", DbType.String, DBNull.Value));
                if (PADOB != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PADOB", DbType.String, PADOB));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PADOB", DbType.String, DBNull.Value));
                if (PABeneficiary != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PABeneficiary", DbType.String, PABeneficiary));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PABeneficiary", DbType.String, DBNull.Value));
                if (PARelation != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PARelation", DbType.String, PARelation));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PARelation", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand, true);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
		
	}
}
