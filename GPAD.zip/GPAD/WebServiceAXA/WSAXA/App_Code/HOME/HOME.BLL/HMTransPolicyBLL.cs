using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;
using HOME.DAL;

namespace HOME.BLL
{
	public class HMTransPolicyBLL
	{
		private HMTransPolicyDAO _HMTransPolicyDAO;

		public HMTransPolicyDAO HMTransPolicyDAO
		{
			get { return _HMTransPolicyDAO; }
			set { _HMTransPolicyDAO = value; }
		}

		public HMTransPolicyBLL()
		{
			HMTransPolicyDAO = new HMTransPolicyDAO();
		}

		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
        public int AddHMTransPolicy(string JobNo, string language, string InsuredSubGroupCode, string PackageCode, string PackageID, string EffectiveDateFrom, string CoveredYear, string GroupBrokerID, string AgentCode, Nullable<Decimal> NetPremium, Nullable<int> Stamp, Nullable<Decimal> VAT, Nullable<Decimal> TotalPremium, Nullable<bool> isLongName, Nullable<bool> isPA, string CreateUser)
		{
			try
			{
                return HMTransPolicyDAO.AddHMTransPolicy(JobNo, language, InsuredSubGroupCode, PackageCode, PackageID, EffectiveDateFrom, CoveredYear, GroupBrokerID, AgentCode, NetPremium, Stamp, VAT, TotalPremium, isLongName, isPA, CreateUser);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
        public int AddHMTransPolicy(string JobNo, string language, string InsuredSubGroupCode, string PackageCode, string PackageID, string EffectiveDateFrom, string CoveredYear, string GroupBrokerID, string AgentCode, Nullable<Decimal> NetPremium, Nullable<int> Stamp, Nullable<Decimal> VAT, Nullable<Decimal> TotalPremium, Nullable<bool> isLongName, Nullable<bool> isPA, string CreateUser, DbTransaction dbTransaction)
        {
            try
            {
                return HMTransPolicyDAO.AddHMTransPolicy(JobNo,language, InsuredSubGroupCode, PackageCode, PackageID, EffectiveDateFrom, CoveredYear, GroupBrokerID, AgentCode, NetPremium, Stamp, VAT, TotalPremium, isLongName, isPA, CreateUser, dbTransaction);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //---------------------------------------------------------------------
        public int SetHMTransTaxInvoince(string PolicyNo, string JobNo, string UserID)
        {
            try
            {
                return HMTransPolicyDAO.SetHMTransTaxInvoince( PolicyNo,  JobNo,  UserID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int SetHMTransPrint(string PolicyNo, string JobNo, string AgentCode, string GroupBrokerId, string CreatedUser)
        {
            try
            {
                return HMTransPolicyDAO.SetHMTransPrint( PolicyNo,  JobNo,  AgentCode,  GroupBrokerId,  CreatedUser);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //---------------------------------------------------------------------
        public string spHM_setPolicyNo()
        {
            try
            {
                return HMTransPolicyDAO.spHM_setPolicyNo();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string spHM_setPolicyNo(string JobNo)
        {
            try
            {
                return HMTransPolicyDAO.spHM_setPolicyNo(JobNo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetHMPrintListReportName(string PolicyNo)
        {
            try
            {
                return HMTransPolicyDAO.GetHMPrintListReportName(PolicyNo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
        public int spHM_UpdatePolicyNoToJobNo(string JobNo, string PolicyNo, string RETURNINV)
        {
            try
            {
                return HMTransPolicyDAO.spHM_UpdatePolicyNoToJobNo(JobNo, PolicyNo, RETURNINV);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
	}
}
