using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;
using HOME.DAL;

namespace HOME.BLL
{
	public class HMTransPolicyHolderBLL
	{
		private HMTransPolicyHolderDAO _HMTransPolicyHolderDAO;

		public HMTransPolicyHolderDAO HMTransPolicyHolderDAO
		{
			get { return _HMTransPolicyHolderDAO; }
			set { _HMTransPolicyHolderDAO = value; }
		}

		public HMTransPolicyHolderBLL()
		{
			HMTransPolicyHolderDAO = new HMTransPolicyHolderDAO();
		}
		
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
        public int AddHMTransPolicyHolder(string JOBNO, string Language, string ClientType, string ClientTitle, string ClientName, string ClientSurName, string LongName, string BranchNo, string ClientAddress1, string ClientAddress2, string Province, string Amphur, string Tumbol, string Postcode, string Birthday, string IdCard, string Tel, string Email, DbTransaction dbTransaction)
		{
			try
			{
				return HMTransPolicyHolderDAO.AddHMTransPolicyHolder( JOBNO,  Language,  ClientType,  ClientTitle,  ClientName,  ClientSurName,  LongName,  BranchNo,  ClientAddress1,  ClientAddress2,  Province,  Amphur,  Tumbol,  Postcode, Birthday,  IdCard,  Tel,  Email,  dbTransaction);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
        public int AddHMTransPolicyInsured(string JOBNO, int InsuredId, string ClientTitle, string ClientName, string ClientSurName, Nullable<DateTime> Birthday, string IDCard, string Tel, Nullable<Int64> BuildingSumInsured, Nullable<Int64> ContentSumInsured, Nullable<Int64> NetPremium, Nullable<Int64> Stamp, Nullable<Int64> VAT, Nullable<Int64> TotalPremium, DbTransaction dbTransaction)
        {
            try
            {
                return HMTransPolicyHolderDAO.AddHMTransPolicyInsured( JOBNO,  InsuredId,  ClientTitle,  ClientName,  ClientSurName, Birthday,  IDCard,  Tel,  BuildingSumInsured, ContentSumInsured,  NetPremium,  Stamp, VAT,  TotalPremium,  dbTransaction);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
		
	}
}
