using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;
using HOME.DAL;

namespace HOME.BLL
{
	public class HMTransPABeneficiaryBLL
	{
		private HMTransPABeneficiaryDAO _HMTransPABeneficiaryDAO;

		public HMTransPABeneficiaryDAO HMTransPABeneficiaryDAO
		{
			get { return _HMTransPABeneficiaryDAO; }
			set { _HMTransPABeneficiaryDAO = value; }
		}

		public HMTransPABeneficiaryBLL()
		{
			HMTransPABeneficiaryDAO = new HMTransPABeneficiaryDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
        public int AddHMTransPABeneficiary(string JobNo, int LocationNo, int PASeq, string PATitle, string PAName, string PASurName, string PAID, string PADOB, string PABeneficiary, string PARelation)
		{
			try
			{
                return HMTransPABeneficiaryDAO.AddHMTransPABeneficiary(JobNo, LocationNo, PASeq, PATitle, PAName, PASurName, PAID, PADOB, PABeneficiary, PARelation);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

        [System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
        public int AddHMTransPABeneficiary(string JobNo, int LocationNo, int PASeq, string PATitle, string PAName, string PASurName, string PAID, string PADOB, string PABeneficiary, string PARelation, DbTransaction dbTransaction)
		{
			try
			{
                return HMTransPABeneficiaryDAO.AddHMTransPABeneficiary(JobNo, LocationNo, PASeq, PATitle, PAName, PASurName, PAID, PADOB, PABeneficiary, PARelation , dbTransaction);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
        
		
	}
}
