﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

using TA.BLL;
using TA.BusinessObjects;
using TA.DAL;
using System.Data;
using System.Data.Common;
using System.IO;
using System.Globalization;
using System.Collections;
using System.Net;
using System.Web.Services.Protocols;
//using Microsoft.Web.Services3;

public class AuthenticationHeader : SoapHeader
{
    public string UserName;
    public string Password;
}

/// <summary>
/// Summary description for INF_AXATAWS
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class INF_AXATAWS : System.Web.Services.WebService {

    public INF_AXATAWS () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    public AuthenticationHeader AuthHeader;
        
    public class ObjAXATACountry
    {
        //public string countryCode { get; set; }
        public string countryName { get; set; }
        //public int isEurope { get; set; }
        //public int isEnable { get; set; }
    }

    public class ObjAXATAListCountry
    {
        public string _msg { get; set; }
        public List<ObjAXATACountry> _listCountry { get; set; }
    }
    
    public class ObjAXATAPlanPackage
    {
        public string _TAPlanID { get; set; }
        public string _TAPlanName { get; set; }
        public string _TAcoverageType { get; set; }
        public string _TAcoverageLine { get; set; }
        public string _TAcoverageDetailEN { get; set; }
        public string _TAcoverageDetailTH { get; set; }
        public string _TAcoveragePlan { get; set; }
        public double _TANetPremium { get; set; }       
        public double _TATotalPremium { get; set; }
        public decimal _TAPAValue { get; set; }
    }

    public class ObjAXATAListPlanPackage
    {
        public string _msg { get; set; }
        public List<ObjAXATAPlanPackage> _listPlanPackage { get; set; }
    }

    public class ObjAXATAPolicyHolderDetail
    {
        public string _clientType { get; set; }
        public string _clientTitle { get; set; }
        public string _clientName { get; set; }
        public string _clientSurName { get; set; }
        public string _birthday { get; set; }
        public string _idCard { get; set; }
        public string _branchNo { get; set; }
        //public string _gender { get; set; }
        //public string _maritalStatus { get; set; }
        //public string _nationlity { get; set; }

        public string _clientAddress1 { get; set; }
        public string _clientAddress2 { get; set; }
        public string _province { get; set; }
        public string _amphur { get; set; }
        public string _tumbol { get; set; }
        public string _provinceID { get; set; }
        public string _amphurID { get; set; }
        public string _tumbolID { get; set; }
        public string _postCode { get; set; }
        public string _email { get; set; }
        public string _tel { get; set; }
        public string _discountCode { get; set; }
    }

    public class ObjAXATATravellerDetail
    {
        //public string _clientTitleValue { get; set; }
        public string _clientTitle { get; set; }
        public string _clientName { get; set; }
        public string _clientSurName { get; set; }
        public string _birthday { get; set; }
        public string _passportID { get; set; }
        public string _beneficiary { get; set; }
        public string _beneficiaryRelation { get; set; }
    }

    public class ObjAXATAPolicyType
    {
        //public string policyTypeCode { get; set; }
        public string policyTypeName { get; set; }
    }

    public class ObjAXATAListPolicyType
    {
        public string _msg { get; set; }
        public List<ObjAXATAPolicyType> _listPolicyType { get; set; }
    }

    public class ObjAXATAPremiumPayment
    {
        public string _msg { get; set; }
        public double _netPremium { get; set; }
        public int _tax { get; set; }
        public int _stamp { get; set; }
        public double _totalPremium { get; set; }
        public int _percentDiscount { get; set; }
        public double _discount { get; set; }
    }

    public class ObjAXATAPolicyIssued
    {
        public string _msg { get; set; }
        public string _deliverDocMsg { get; set; }
        public string _policyNo { get; set; }
    }
        
    public class ObjAXAResendPolicy
    {
        public string policyNo { get; set; }
        public string policyType { get; set; }
        public string planId { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXATAListCountry GetAXATACountry(string agentCode, string groupBrokerId, string password)
    {                
        string retMsg = string.Empty;
        ObjAXATAListCountry objListCountry = new ObjAXATAListCountry();
        List<ObjAXATACountry> lstAXATACountry = new List<ObjAXATACountry>();
        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;            
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            #endregion

            if (isValidateOK == true)
            {
                TATBCountryBLL clscountry = new TATBCountryBLL();
                DataTable dt = clscountry.GetDtTATBCountrys();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (dt.Rows[i]["CountryCode"].ToString() != "99")
                    {
                        ObjAXATACountry countrys = new ObjAXATACountry();
                        //countrys.countryCode = dt.Rows[i]["CountryCode"].ToString();
                        countrys.countryName = dt.Rows[i]["CountryName"].ToString().Trim();
                        //countrys.isEurope = string.IsNullOrEmpty(dt.Rows[i]["isEurope"].ToString()) ? 0 : Convert.ToInt32(dt.Rows[i]["isEurope"].ToString());

                        lstAXATACountry.Add(countrys);
                    }
                }

                retMsg = "SUCCESS";
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        //msg = retMsg;
        //return lstAXATACountry.Cast<ObjAXATACountry>().ToList();
        objListCountry._msg = retMsg;
        objListCountry._listCountry = lstAXATACountry.Cast<ObjAXATACountry>().ToList();

        return objListCountry;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXATAListPolicyType GetAXATAPolicyType(string agentCode, string groupBrokerId, string password)
    {
        string retMsg = string.Empty;
        ObjAXATAListPolicyType objListPolicyType = new ObjAXATAListPolicyType();
        List<ObjAXATAPolicyType> lstAXATAPolicyType = new List<ObjAXATAPolicyType>();
        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            #endregion

            if (isValidateOK == true)
            {
                ObjAXATAPolicyType item1 = new ObjAXATAPolicyType();
                //item1.policyTypeCode = "INDIVIDUAL";
                item1.policyTypeName = "INDIVIDUAL";
                lstAXATAPolicyType.Add(item1);

                ObjAXATAPolicyType item2 = new ObjAXATAPolicyType();
                //item2.policyTypeCode = "FAMILY";
                item2.policyTypeName = "FAMILY";
                lstAXATAPolicyType.Add(item2);

                ObjAXATAPolicyType item3 = new ObjAXATAPolicyType();
                //item3.policyTypeCode = "GROUP";
                item3.policyTypeName = "GROUP";
                lstAXATAPolicyType.Add(item3);

                retMsg = "SUCCESS";
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        //msg = retMsg;
        //return lstAXATAPolicyType.Cast<ObjAXATAPolicyType>().ToList();
        objListPolicyType._msg = retMsg;
        objListPolicyType._listPolicyType = lstAXATAPolicyType.Cast<ObjAXATAPolicyType>().ToList();

        return objListPolicyType;
    }
    
    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="policyType"></param>
    /// <param name="departureDate"></param>
    /// <param name="returnDate"></param>
    /// <param name="countryName"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXATAListPlanPackage GetAXATAPlanPackage(string agentCode, string groupBrokerId, string password, string policyType, string departureDate, string returnDate, string countryName)
    {
        string retMsg = string.Empty;
        string travelPlan = "SINGLE";
        int duration = 0;
        int isEurope = 0;

        ObjAXATAListPlanPackage objListPlanPackage = new ObjAXATAListPlanPackage();
        List<ObjAXATAPlanPackage> lstAXATAPlanPackage = new List<ObjAXATAPlanPackage>();

        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            #endregion

            if (isValidateOK == true)
            {
                //Calulate duration
                duration = this.CalculateDuration(departureDate, returnDate);
                //End
 
                //Search country for get isEurope
                isEurope = this.GetIsEurope(countryName);
                //End Search
                
                if (!string.IsNullOrEmpty(policyType))
                    policyType = policyType.ToUpper().Trim();

                TATBPlanIDBLL clsTATBPlanIDBLL = new TATBPlanIDBLL();
                DataTable dt = clsTATBPlanIDBLL.GetDtTATBPlanIDs();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    //ObjAXATAPlanPackage item = new ObjAXATAPlanPackage();
                    string planID = dt.Rows[i]["PlanID"].ToString();
                    string planName = dt.Rows[i]["PlanName"].ToString();

                    TAPlanPremuimBLL clsTAPlanPremuimBLL = new TAPlanPremuimBLL();
                    TAPremuim getPlanPremium = new TAPremuim();
                    getPlanPremium = clsTAPlanPremuimBLL.GetTAPremuim(planID, duration, travelPlan);
                    double netpremium = string.IsNullOrEmpty(getPlanPremium.NetPremium.ToString()) ? 0 : Convert.ToDouble(getPlanPremium.NetPremium);
                    decimal PA = string.IsNullOrEmpty(getPlanPremium.PersonalAccident.ToString()) ? 0 : Convert.ToDecimal(getPlanPremium.PersonalAccident);

                    double totalPremium = this.CalculateTotalPremium(Convert.ToDouble(netpremium));


                    if (isEurope == 0)
                    {
                        //กรณีเดินทางภายนอก Europe ไม่ขาย Platinum Plan
                        if (string.Compare(planID, "0004") != 0)
                        {
                            TAPlanCoverageBLL clsTAPlanCoverageBLL = new TAPlanCoverageBLL();
                            DataTable dt1 = clsTAPlanCoverageBLL.GetDtTAPlanCoverages(planID);

                            for (int j = 0; j < dt1.Rows.Count; j++)
                            {
                                ObjAXATAPlanPackage item = new ObjAXATAPlanPackage();

                                string coverageType = dt1.Rows[j]["CoverageType"].ToString();
                                string coverageLine = dt1.Rows[j]["CoverageLine"].ToString();
                                string coverageDetailEN = dt1.Rows[j]["CoverageDetailEN"].ToString();
                                string coverageDetailTH = dt1.Rows[j]["CoverageDetailTH"].ToString();
                                string coveragePlan = dt1.Rows[j]["CoveragePlan"].ToString();

                                item._TAPlanID = planID;
                                item._TAPlanName = planName;
                                item._TANetPremium = netpremium;
                                item._TATotalPremium = totalPremium;
                                item._TAPAValue = PA;

                                item._TAcoverageType = coverageType;
                                item._TAcoverageLine = coverageLine;
                                item._TAcoverageDetailEN = coverageDetailEN;
                                item._TAcoverageDetailTH = coverageDetailTH;
                                item._TAcoveragePlan = coveragePlan;

                                lstAXATAPlanPackage.Add(item);
                            }
                        }
                    }
                    else
                    {
                        //กรณีเดินทางใน Europe ขายเฉพาะ Gold กับ Platinum Plan
                        if ((string.Compare(planID, "0003") == 0) || (string.Compare(planID, "0004") == 0))
                        {
                            TAPlanCoverageBLL clsTAPlanCoverageBLL = new TAPlanCoverageBLL();
                            DataTable dt1 = clsTAPlanCoverageBLL.GetDtTAPlanCoverages(planID);

                            for (int j = 0; j < dt1.Rows.Count; j++)
                            {
                                ObjAXATAPlanPackage item = new ObjAXATAPlanPackage();

                                string coverageType = dt1.Rows[j]["CoverageType"].ToString();
                                string coverageLine = dt1.Rows[j]["CoverageLine"].ToString();
                                string coverageDetailEN = dt1.Rows[j]["CoverageDetailEN"].ToString();
                                string coverageDetailTH = dt1.Rows[j]["CoverageDetailTH"].ToString();
                                string coveragePlan = dt1.Rows[j]["CoveragePlan"].ToString();

                                item._TAPlanID = planID;
                                item._TAPlanName = planName;
                                item._TANetPremium = netpremium;
                                item._TATotalPremium = totalPremium;
                                item._TAPAValue = PA;

                                item._TAcoverageType = coverageType;
                                item._TAcoverageLine = coverageLine;
                                item._TAcoverageDetailEN = coverageDetailEN;
                                item._TAcoverageDetailTH = coverageDetailTH;
                                item._TAcoveragePlan = coveragePlan;

                                lstAXATAPlanPackage.Add(item);
                            }
                        }
                    }
                }

                retMsg = "SUCCESS";
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        //msg = retMsg;
        //return lstAXATAPlanPackage.Cast<ObjAXATAPlanPackage>().ToList();
        objListPlanPackage._msg = retMsg;
        objListPlanPackage._listPlanPackage = lstAXATAPlanPackage.Cast<ObjAXATAPlanPackage>().ToList();

        return objListPlanPackage;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="policyType"></param>
    /// <param name="planID"></param>
    /// <param name="departureDate"></param>
    /// <param name="returnDate"></param>
    /// <param name="countryName"></param>
    /// <param name="numAdults"></param>
    /// <param name="numChilds"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXATAPremiumPayment GetAXATAPremiumPayment(string agentCode, string groupBrokerId, string password, string policyType, string planID, string departureDate, string returnDate, string countryName, int numAdults, int numChilds,bool isMember)
    {
        string retMsg = string.Empty;
        string travelPlan = "SINGLE";
        int duration = 0;
        int isEurope = 0; 

        int percentDiscount = 0;
        double getNetPremium = 0;
        double netPremium = 0;
        double totalPremium = 0;
        int tax = 0;
        int stamp = 0;

        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            #endregion

            if (isValidateOK == true)
            {
                //Calulate duration
                duration = this.CalculateDuration(departureDate, returnDate);
                //End

                //Search country for get isEurope
                isEurope = this.GetIsEurope(countryName);
                //End Search
                
                if (!string.IsNullOrEmpty(policyType))
                    policyType = policyType.ToUpper().Trim();

                TAPlanPremuimBLL clsTAPlanPremuimBLL = new TAPlanPremuimBLL();
                TAPlanCampaignBLL clsTAPlanCampaingBLL = new TAPlanCampaignBLL();

                //Discount Process Krit 2015-03-18
                percentDiscount = clsTAPlanCampaingBLL.spTA_GetCampaignDiscount(2, countryName);
                if (isMember && percentDiscount <=0)
                {
                    percentDiscount = clsTAPlanCampaingBLL.spTA_GetCampaignDiscount(1, String.Empty);
                }

                TAPremuim getPlanPremium = new TAPremuim();
                getPlanPremium = clsTAPlanPremuimBLL.GetTAPremuim(planID, duration, travelPlan);
                getNetPremium = string.IsNullOrEmpty(getPlanPremium.NetPremium.ToString()) ? 0 : Convert.ToDouble(getPlanPremium.NetPremium);

                if (string.Compare(policyType, "INDIVIDUAL") == 0)
                {
                    if (percentDiscount > 0)
                    {
                        netPremium = getNetPremium - Math.Floor(getNetPremium * percentDiscount / 100);
                    }
                    else
                    {
                        netPremium = getNetPremium;
                    }

                    totalPremium = this.CalculateTotalPremium(netPremium);
                    stamp = Convert.ToInt32(Math.Ceiling(netPremium * 0.004));
                    tax = Convert.ToInt32(Math.Ceiling(netPremium * 0.0));

                    if (numAdults > 1)
                    {
                        netPremium = netPremium * numAdults;
                        totalPremium = totalPremium * numAdults;
                        stamp = stamp * numAdults;
                        tax = tax * numAdults;
                    }

                    retMsg = "SUCCESS";
                }
                else if (string.Compare(policyType, "FAMILY") == 0)
                {
                    if (percentDiscount > 0)
                    {
                        netPremium = getNetPremium - Math.Floor(getNetPremium * percentDiscount / 100);
                    }
                    else
                    {
                        netPremium = getNetPremium;
                    }

                    stamp = Convert.ToInt32(Math.Ceiling(netPremium * 0.004));
                    tax = Convert.ToInt32(Math.Ceiling(netPremium * 0.0));
                    totalPremium = this.CalculateTotalPremium(netPremium);

                    
                    //-------child------------
                    if (numChilds > 2)
                    {
                        netPremium = netPremium * (numAdults + (numChilds - 2));
                        stamp = stamp * (numAdults + (numChilds - 2));
                        tax = tax * (numAdults + (numChilds - 2));
                        totalPremium = totalPremium * (numAdults + (numChilds - 2));
                    }
                    else
                    {
                        //------- parent--------
                        //netPremium = netPremium * 2;
                        //stamp = stamp * 2;
                        //tax = tax * 2;
                        //totalPremium = totalPremium * 2;

                        netPremium = netPremium * numAdults;
                        stamp = stamp * numAdults;
                        tax = tax * numAdults;
                        totalPremium = totalPremium * numAdults;
                    }

                    retMsg = "SUCCESS";
                }
                else if (string.Compare(policyType, "GROUP") == 0)
                {
                    if (percentDiscount > 0)
                    {
                        netPremium = getNetPremium - Math.Floor(getNetPremium * percentDiscount / 100);
                    }
                    else
                    {
                        netPremium = getNetPremium;
                    }

                    totalPremium = this.CalculateTotalPremium(netPremium);
                    stamp = Convert.ToInt32(Math.Ceiling(netPremium * 0.004));
                    tax = Convert.ToInt32(Math.Ceiling(netPremium * 0.0));

                    if (numAdults > 1)
                    {
                        netPremium = netPremium * numAdults;
                        totalPremium = totalPremium * numAdults;
                        stamp = stamp * numAdults;
                        tax = tax * numAdults;
                    }

                    retMsg = "SUCCESS";
                }
                else
                {
                    retMsg = "Policy Type must equal Individual/Family/Group!!!";
                }
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        //oNetPremium = netPremium;
        //oTax = tax;
        //oStamp = stamp;
        //oTotalPremium = totalPremium;

        //return retMsg;
        ObjAXATAPremiumPayment objPremiumPayment = new ObjAXATAPremiumPayment();
        objPremiumPayment._msg = retMsg;
        //objPremiumPayment._netPremium = netPremium;
        objPremiumPayment._netPremium = getNetPremium;
        objPremiumPayment._tax = tax;
        objPremiumPayment._stamp = stamp;
        objPremiumPayment._totalPremium = totalPremium;
        objPremiumPayment._percentDiscount = percentDiscount;
        objPremiumPayment._discount = Math.Floor(getNetPremium * percentDiscount / 100);

        return objPremiumPayment;
    }

    ///// <summary>
    ///// 
    ///// </summary>
    ///// <param name="agentCode"></param>
    ///// <param name="groupBrokerId"></param>
    ///// <param name="countryName"></param>
    ///// <param name="departureDate">dd/MM/yyyy(A.D.)</param>
    ///// <param name="returnDate">dd/MM/yyyy(A.D.)</param>
    ///// <param name="policyType">Family/Individual</param>
    ///// <param name="planID"></param>    
    ///// <param name="personalDetail"></param>
    ///// <param name="lstTravellerAdult"></param>
    ///// <param name="lstTravellerChild"></param>
    ///// <param name="refInv"></param>
    ///// <param name="isFTP"></param>
    ///// <param name="ftpServer"></param>
    ///// <param name="ftpUser"></param>
    ///// <param name="ftpPass"></param>
    ///// <param name="brokerEmail"></param>
    ///// <param name="msg">output -> SUCCESS</param>
    ///// <param name="deliverDocMsg">output -> SUCCESS</param>
    ///// <returns>List of Policy NO.</returns>
    //[WebMethod]
    //public List<string> ProcessAXATAPolicyIssue(string agentCode, string groupBrokerId, string password, string countryName, string departureDate, string returnDate, string policyType, string planID, ObjAXATAPolicyHolderDetail personalDetail, List<ObjAXATATravellerDetail> lstTravellerAdult, List<ObjAXATATravellerDetail> lstTravellerChild, string refInv, bool isFTP, string ftpServer, string ftpUser, string ftpPass, string brokerEmail, out string msg, out string deliverDocMsg)
    //{
    //    string retMsg = string.Empty;
    //    string retDeiverDoc = string.Empty;
    //    string travelPlan = "SINGLE";
    //    int percentDiscount = 0;
    //    string userID = string.Empty;
    //    bool isValidateOK = true;
    //    int duration = 0;
    //    int isEurope = 0;

    //    List<string> PolicyNoList = new List<string>();

    //    #region ###Validate Corect Data into Web Service
    //    if (string.IsNullOrEmpty(departureDate) || string.IsNullOrEmpty(returnDate))
    //    {
    //        isValidateOK = false;
    //        retMsg += " | Departure or Return Date Data Must be complete!!!";
    //    }
    //    else
    //    {
    //        string[] arrDateDeparture = departureDate.Split('/');
    //        string[] arrDateReturn = returnDate.Split('/');

    //        if (Int32.Parse(arrDateDeparture[2].Substring(0, 4)) > 2500)
    //        {
    //            isValidateOK = false;
    //            retMsg += " | Departure Date(Year) Value Must be A.D.!!!";
    //        }

    //        if (Int32.Parse(arrDateReturn[2].Substring(0, 4)) > 2500)
    //        {
    //            isValidateOK = false;
    //            retMsg += " | Return Date(Year) Value Must be A.D.!!!";
    //        }
    //    }

    //    if (string.IsNullOrEmpty(policyType))
    //    {
    //        isValidateOK = false;
    //        retMsg += " | Policy Type Must have value (Individual/Family/Group)!!!";
    //    }
    //    else
    //    {
    //        if ((string.Compare(policyType.ToUpper().Trim(), "INDIVIDUAL") == 0) || (string.Compare(policyType.ToUpper().Trim(), "FAMILY") == 0) || (string.Compare(policyType.ToUpper().Trim(), "GROUP") == 0))
    //        {

    //        }
    //        else
    //        {
    //            isValidateOK = false;
    //            retMsg += " | Policy Type Must have value (Individual/Family/Group)!!!";
    //        }
    //    }

    //    if ((isEurope == 1) || (isEurope == 0))
    //    {

    //    }
    //    else
    //    {
    //        isValidateOK = false;
    //        retMsg += " | Is Europe Must have integer value (1/0)!!!";
    //    }

    //    if (duration <= 0)
    //    {
    //        isValidateOK = false;
    //        retMsg += " | Duration value must more than zero!!!";
    //    }

    //    if (personalDetail == null)
    //    {
    //        isValidateOK = false;
    //        retMsg += " | Personal detail data can not be null value!!!";
    //    }
        
    //    if (lstTravellerAdult == null)
    //    {
    //        isValidateOK = false;
    //        retMsg += " | List of traveller adult can not be null value!!!";
    //    }

    //    if (lstTravellerChild == null)
    //    {
    //        isValidateOK = false;
    //        retMsg += " | List of traveller child can not be null value!!!";
    //    }
    //    else
    //    {
    //        if ((string.Compare(policyType.ToUpper().Trim(), "INDIVIDUAL") == 0) || (string.Compare(policyType.ToUpper().Trim(), "GROUP") == 0))
    //        {
    //            if (lstTravellerChild.Count > 0)
    //            {
    //                isValidateOK = false;
    //                retMsg += " | Policy Type Individual or Group -> List of traveller child must be empty(count 0) only!!!";
    //            }
    //        }
    //    }

    //    if (isFTP == true)
    //    {
    //        if (string.IsNullOrEmpty(ftpServer) || string.IsNullOrEmpty(ftpUser) || string.IsNullOrEmpty(ftpPass))
    //        {
    //            isValidateOK = false;
    //            retMsg += " | FTP Data Must be complete!!!";
    //        }
    //    }
    //    else
    //    {
    //        if (string.IsNullOrEmpty(brokerEmail))
    //        {
    //            isValidateOK = false;
    //            retMsg += " | Broker email Data Must be complete!!!";
    //        }
    //    }
    //    #endregion

    //    #region ###Validate security & authorization into Web Service        
    //    isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out retMsg);
    //    #endregion

    //    if (isValidateOK == true)
    //    {
    //        //Calulate duration
    //        duration = this.CalculateDuration(departureDate, returnDate);
    //        //End

    //        //Search country for get isEurope
    //        isEurope = this.GetIsEurope(countryName);
    //        //End Search
            
    //        int NumbersOfChildren = lstTravellerChild.Count;
    //        int NumbersOfAdult = lstTravellerAdult.Count;
    //        string EffectiveDateFrom = TA.TAUtilities.ConvertDateFieldToDB(departureDate);
    //        string EffectiveDateTo = TA.TAUtilities.ConvertDateFieldToDB(returnDate);
    //        string CountryOfDestination = countryName;

    //        if (!string.IsNullOrEmpty(policyType))
    //            policyType = policyType.ToUpper().Trim();

    //        TAPlanPremuimBLL clsTAPlanPremuimBLL = new TAPlanPremuimBLL();
    //        TAPremuim getPlanPremium = new TAPremuim();
    //        getPlanPremium = clsTAPlanPremuimBLL.GetTAPremuim(planID, duration, travelPlan);
    //        double getNetPremium = string.IsNullOrEmpty(getPlanPremium.NetPremium.ToString()) ? 0 : Convert.ToDouble(getPlanPremium.NetPremium);

    //        double netPremium = getNetPremium;
    //        int tax = int.Parse(getPlanPremium.TAX);
    //        int stamp = int.Parse(getPlanPremium.Stamp);
    //        double totalPremium = double.Parse(getPlanPremium.Total);
    //        float PersonalAccident = (float)Utilities.ExactNumber(getPlanPremium.PersonalAccident);

    //        double total_netpremuim = netPremium;
    //        int total_tax = tax;
    //        int total_stamp = stamp;
    //        double total_totalpremium = totalPremium;

    //        DbTransaction dbTransaction = null;

    //        int travellerCounter = 0;
    //        List<string> JobNoList = new List<string>();

    //        foreach (ObjAXATATravellerDetail item in lstTravellerAdult)
    //        {
    //            try
    //            {
    //                travellerCounter++;

    //                #region "GET/SET JOB NUMBER (NOW NONE TRANSACTION)"
    //                //GET/SET JOB NUMBER
    //                //string m_JobNo = "AXA-TA-20120500007";
    //                TAJobRunningBLL clsjobrunning = new TAJobRunningBLL();
    //                string JobNo = string.Empty;
    //                //JobNo = clsjobrunning.GetTAJobRunningNumber(dbTransaction);                
    //                JobNo = clsjobrunning.GetTAJobRunningNumber();
    //                if (string.IsNullOrEmpty(JobNo))
    //                {
    //                    throw new Exception("เกิดข้อผิดพลาดในการสร้างหมายเลข Job Number กรุณาทดลองบันทึกงานอีกครั้งหรือติดต่อผู้ดูแลระบบ");
    //                }
    //                #endregion

    //                #region "OPEN DB"
    //                //OPEN DB
    //                DbProviderHelper.OpenDb();
    //                #endregion

    //                #region "OPEN TRANSACTION"
    //                //TRANSACTION BEGIN
    //                dbTransaction = DbProviderHelper.BeginTransaction();
    //                #endregion

    //                #region "#1-INSERT/UPDATE TRANSPOLICY"

    //                //------ CALUCATE PREMIUM -------

    //                double tmpPYNetpremuim = 0;
    //                int tmpPYTax = 0;
    //                int tmpPYStamp = 0;
    //                double tmpPYTotalpremium = 0;

    //                tmpPYNetpremuim = (netPremium) - Convert.ToInt32(Math.Floor(netPremium * percentDiscount / 100));
    //                tmpPYStamp = Convert.ToInt32(Math.Ceiling(tmpPYNetpremuim * 0.004));
    //                tmpPYTax = Convert.ToInt32(Math.Ceiling(tmpPYNetpremuim * 0.0));
    //                tmpPYTotalpremium = tmpPYNetpremuim + tmpPYTax + tmpPYStamp;

    //                if (string.Compare(policyType, "FAMILY") == 0)
    //                {
    //                    if (NumbersOfChildren > 2)
    //                    {
    //                        tmpPYNetpremuim = tmpPYNetpremuim * (2 + (NumbersOfChildren - 2));
    //                        tmpPYStamp = tmpPYStamp * (2 + (NumbersOfChildren - 2));
    //                        tmpPYTax = tmpPYTax * (2 + (NumbersOfChildren - 2));
    //                        tmpPYTotalpremium = tmpPYTotalpremium * (2 + (NumbersOfChildren - 2));
    //                    }
    //                    else
    //                    {
    //                        tmpPYNetpremuim = tmpPYNetpremuim * 2;
    //                        tmpPYStamp = tmpPYStamp * 2;
    //                        tmpPYTax = tmpPYTax * 2;
    //                        tmpPYTotalpremium = tmpPYTotalpremium * 2;
    //                    }
    //                }
    //                else if (string.Compare(policyType, "GROUP") == 0)
    //                {
    //                    tmpPYNetpremuim = tmpPYNetpremuim * NumbersOfAdult;
    //                    tmpPYStamp = tmpPYStamp * NumbersOfAdult;
    //                    tmpPYTax = tmpPYTax * NumbersOfAdult;
    //                    tmpPYTotalpremium = tmpPYTotalpremium * NumbersOfAdult;
    //                }
    //                //------ END CALUCATE PREMIUM -------
    //                //#1-INSERT/UPDATE TRANSPOLICY                         
    //                TATransPolicyBLL clstranspolicy = new TATransPolicyBLL();
    //                //clstranspolicy.SetTATransPolicy("AXA-TA-20120500001", "", "Annual", "Individual", 0, "0001", "2012-05-23", "2013-05-23", "TH", "", "", 0, 0, 0, 0, 0, 0, "", "BA347", dbTransaction);
    //                clstranspolicy.SetTATransPolicy(JobNo, "", "Single", policyType, NumbersOfChildren, planID, EffectiveDateFrom, EffectiveDateTo, CountryOfDestination, "", agentCode, "", Convert.ToDecimal(tmpPYNetpremuim), tmpPYStamp, Convert.ToDecimal(tmpPYTax), Convert.ToDecimal(tmpPYTotalpremium), 0, 0, userID, groupBrokerId, dbTransaction);

    //                #endregion

    //                #region "#2-INSERT/UPDATE TRANSPOLICYHOLDER"
    //                //#3-INSERT/UPDATE TRANSPOLICYHOLDER
    //                string ClientType = "P";

    //                TATransPolicyHolderBLL clstranspolicyholder = new TATransPolicyHolderBLL();

    //                //---------if login policyholder = userlogin------------------
    //                //Traveller tmpPersonal = (Traveller)item;

    //                string ClientTitle = item._clientTitle;
    //                string ClientName = item._clientName;
    //                string ClientSurName = item._clientSurName;

    //                clstranspolicyholder.SetTATransPolicyHolder(JobNo, ClientType, ClientTitle, ClientName, ClientSurName, personalDetail._clientAddress1, personalDetail._clientAddress2, personalDetail._province, personalDetail._amphur, personalDetail._tumbol, personalDetail._postCode, TA.TAUtilities.ConvertDateFieldToDB(item._birthday), item._passportID, personalDetail._tel, personalDetail._email, "E", dbTransaction);

    //                #endregion

    //                #region "#3-INSERT/UPDATE TRANSCOVERAGE"
    //                //#3-INSERT/UPDATE TRANSCOVERAGE
    //                TATransCoverageBLL clstranscoverage = new TATransCoverageBLL();
    //                //clstranscoverage.SetTATransCoverage("AXA-TA-20120500001", (float)1000000, "0001", dbTransaction);
    //                clstranscoverage.SetTATransCoverage(JobNo, PersonalAccident, planID, dbTransaction);
    //                #endregion

    //                #region "#4-INSERT/UPDATE TRANSTRAVELER"
    //                //#4-INSERT/UPDATE TRANSTRAVELER

    //                if (string.Compare(policyType, "FAMILY") == 0)
    //                {
    //                    int TravelerId = 1;

    //                    double tmpNetpremuim = 0;
    //                    int tmpTax = 0;
    //                    int tmpStamp = 0;
    //                    double tmpTotalpremium = 0;

    //                    tmpNetpremuim = (netPremium) - Convert.ToInt32(Math.Floor(netPremium * percentDiscount / 100));
    //                    tmpStamp = Convert.ToInt32(Math.Ceiling(tmpNetpremuim * 0.004));
    //                    tmpTax = Convert.ToInt32(Math.Ceiling(tmpNetpremuim * 0.0));
    //                    tmpTotalpremium = tmpNetpremuim + tmpTax + tmpStamp;

    //                    foreach (ObjAXATATravellerDetail tmpAdults in lstTravellerAdult)
    //                    {
    //                        //Traveller tmpTraveller = (Traveller)tmpAdults;
    //                        TATransTravelerBLL clstranstraveler = new TATransTravelerBLL();
    //                        //clstranstraveler.SetTATransTraveler(m_JobNo, m_TravelerId, m_ClientTitle, m_ClientName, m_ClientSurName, m_Birthday, m_PassportID, m_Tel, m_isStudent, m_isSingle, null, dbTransaction);
    //                        clstranstraveler.SetTATransTraveler(JobNo, TravelerId, tmpAdults._clientTitleValue, tmpAdults._clientName, tmpAdults._clientSurName, TA.TAUtilities.ConvertDateFieldToDB(tmpAdults._birthday), tmpAdults._passportID, "", 0, 0, Convert.ToDecimal(PersonalAccident), Convert.ToDecimal(tmpNetpremuim), tmpStamp, tmpTax, Convert.ToDecimal(tmpTotalpremium), null, dbTransaction);


    //                        #region "#5-INSERT/UPDATE TRANSBENEFICIARY"

    //                        TATransBeneficiaryBLL clstransbeneficiary = new TATransBeneficiaryBLL();
    //                        clstransbeneficiary.SetTATransBeneficiary(JobNo, TravelerId, 1, "", tmpAdults._beneficiary, "", "", "100", "", dbTransaction);

    //                        #endregion

    //                        TravelerId++;
    //                    }

    //                    foreach (ObjAXATATravellerDetail tmpChild in lstTravellerChild)
    //                    {
    //                        tmpNetpremuim = 0;
    //                        tmpTax = 0;
    //                        tmpStamp = 0;
    //                        tmpTotalpremium = 0;
    //                        float tmpPersonalAccident = 0;

    //                        if (TravelerId < 5)
    //                        {
    //                            tmpNetpremuim = 0;
    //                            tmpTax = 0;
    //                            tmpStamp = 0;
    //                            tmpTotalpremium = 0;
    //                            tmpPersonalAccident = PersonalAccident / 2;
    //                        }
    //                        else
    //                        {
    //                            tmpNetpremuim = netPremium;
    //                            tmpNetpremuim = (tmpNetpremuim) - Convert.ToInt32(Math.Floor((tmpNetpremuim) * percentDiscount / 100));
    //                            tmpTax = tax;
    //                            tmpStamp = stamp;
    //                            tmpTotalpremium = totalPremium;
    //                            tmpPersonalAccident = PersonalAccident;
    //                        }

    //                        tmpStamp = Convert.ToInt32(Math.Ceiling(tmpNetpremuim * 0.004));
    //                        tmpTax = Convert.ToInt32(Math.Ceiling(tmpNetpremuim * 0.0));
    //                        tmpTotalpremium = tmpNetpremuim + tmpTax + tmpStamp;

    //                        //กรณี Family ลูก ๆ จะได้รับ PA คุ้มครอง 50% 2012-06-05
    //                        //Traveller tmpTraveller = (Traveller)tmpChild;
    //                        TATransTravelerBLL clstranstraveler = new TATransTravelerBLL();
    //                        //clstranstraveler.SetTATransTraveler(m_JobNo, m_TravelerId, m_ClientTitle, m_ClientName, m_ClientSurName, m_Birthday, m_PassportID, m_Tel, m_isStudent, m_isSingle, null, dbTransaction);
    //                        clstranstraveler.SetTATransTraveler(JobNo, TravelerId, tmpChild._clientTitleValue, tmpChild._clientName, tmpChild._clientSurName, TA.TAUtilities.ConvertDateFieldToDB(tmpChild._birthday), tmpChild._passportID, "", 0, 0, Convert.ToDecimal(tmpPersonalAccident), Convert.ToDecimal(tmpNetpremuim), tmpStamp, tmpTax, Convert.ToDecimal(tmpTotalpremium), null, dbTransaction);


    //                        #region "#5-INSERT/UPDATE TRANSBENEFICIARY"

    //                        TATransBeneficiaryBLL clstransbeneficiary = new TATransBeneficiaryBLL();
    //                        clstransbeneficiary.SetTATransBeneficiary(JobNo, TravelerId, 1, "", tmpChild._beneficiary, "", "", "100", "", dbTransaction);

    //                        #endregion

    //                        TravelerId++;
    //                    }
    //                }
    //                else if (string.Compare(policyType, "INDIVIDUAL") == 0)
    //                {

    //                    total_netpremuim = netPremium - Convert.ToInt32(Math.Floor(netPremium * (percentDiscount / 100)));
    //                    total_stamp = Convert.ToInt32(Math.Ceiling(total_netpremuim * 0.004));
    //                    total_tax = Convert.ToInt32(Math.Ceiling(total_netpremuim * 0.0));
    //                    total_totalpremium = total_netpremuim + total_tax + total_stamp;


    //                    TATransTravelerBLL clstranstraveler = new TATransTravelerBLL();
    //                    //clstranstraveler.SetTATransTraveler(m_JobNo, m_TravelerId, m_ClientTitle, m_ClientName, m_ClientSurName, m_Birthday, m_PassportID, m_Tel, m_isStudent, m_isSingle, null, dbTransaction);
    //                    clstranstraveler.SetTATransTraveler(JobNo, 1, item._clientTitleValue, item._clientName, item._clientSurName, TA.TAUtilities.ConvertDateFieldToDB(item._birthday), item._passportID, "", 0, 0, Convert.ToDecimal(PersonalAccident), Convert.ToDecimal(total_netpremuim), total_stamp, total_tax, Convert.ToDecimal(total_totalpremium), null, dbTransaction);

    //                    #region "#5-INSERT/UPDATE TRANSBENEFICIARY"

    //                    TATransBeneficiaryBLL clstransbeneficiary = new TATransBeneficiaryBLL();
    //                    clstransbeneficiary.SetTATransBeneficiary(JobNo, 1, 1, "", item._beneficiary, "", "", "100", "", dbTransaction);

    //                    #endregion
    //                }
    //                else if (string.Compare(policyType, "GROUP") == 0)
    //                {
    //                    int TravelerId = 1;

    //                    double tmpNetpremuim = 0;
    //                    int tmpTax = 0;
    //                    int tmpStamp = 0;
    //                    double tmpTotalpremium = 0;

    //                    tmpNetpremuim = (netPremium) - Convert.ToInt32(Math.Floor(netPremium * percentDiscount / 100));
    //                    tmpStamp = Convert.ToInt32(Math.Ceiling(tmpNetpremuim * 0.004));
    //                    tmpTax = Convert.ToInt32(Math.Ceiling(tmpNetpremuim * 0.0));
    //                    tmpTotalpremium = tmpNetpremuim + tmpTax + tmpStamp;

    //                    foreach (ObjAXATATravellerDetail tmpAdults in lstTravellerAdult)
    //                    {                            
    //                        TATransTravelerBLL clstranstraveler = new TATransTravelerBLL();                            
    //                        clstranstraveler.SetTATransTraveler(JobNo, TravelerId, tmpAdults._clientTitleValue, tmpAdults._clientName, tmpAdults._clientSurName, TA.TAUtilities.ConvertDateFieldToDB(tmpAdults._birthday), tmpAdults._passportID, "", 0, 0, Convert.ToDecimal(PersonalAccident), Convert.ToDecimal(tmpNetpremuim), tmpStamp, tmpTax, Convert.ToDecimal(tmpTotalpremium), null, dbTransaction);

    //                        #region "#5-INSERT/UPDATE TRANSBENEFICIARY"
    //                        TATransBeneficiaryBLL clstransbeneficiary = new TATransBeneficiaryBLL();
    //                        clstransbeneficiary.SetTATransBeneficiary(JobNo, TravelerId, 1, "", tmpAdults._beneficiary, "", "", "100", "", dbTransaction);
    //                        #endregion

    //                        TravelerId++;
    //                    }                        
    //                }
    //                #endregion

    //                #region 5-INSERT/NOT USER DISCOUNT
    //                //if (!String.IsNullOrEmpty(personalDetail._discountCode) && travellerCounter == 1)
    //                //{
    //                //    TAB2CDiscountBLL setDiscount = new TAB2CDiscountBLL();
    //                //    setDiscount.spTAB2C_SetUseDiscount(JobNo, personalDetail._discountCode, user.Email, dbTransaction);
    //                //}
    //                #endregion

    //                #region "COMMIT DB"
    //                //COMMIT DB
    //                DbProviderHelper.CommitTransaction(dbTransaction);
    //                #endregion

    //                #region "CLOSE DB"
    //                //CLOSE DB
    //                DbProviderHelper.CloseDb();
    //                dbTransaction.Dispose();
    //                dbTransaction = null;

    //                #endregion

    //                JobNoList.Add(JobNo);

    //                if ((string.Compare(policyType, "FAMILY") == 0) || (string.Compare(policyType, "GROUP") == 0))
    //                {
    //                    break;
    //                }

    //            }
    //            catch (Exception ex)
    //            {
    //                retMsg += ex.Message.ToString() + " | ";

    //                if (dbTransaction != null)
    //                {
    //                    #region "ROLLBACK DB"
    //                    //ROLLBACK DB
    //                    DbProviderHelper.RollbackTransaction(dbTransaction);
    //                    #endregion

    //                    #region "CLOSE DB"
    //                    //CLOSE DB
    //                    DbProviderHelper.CloseDb();
    //                    #endregion
    //                }
    //            }
    //        }

    //        if (retMsg == string.Empty)
    //            retMsg = "SUCCESS";

    //        string issueMsg = string.Empty;

    //        if (string.Compare(retMsg.ToUpper().Trim(), "SUCCESS") == 0)
    //        {
    //            PolicyNoList = this.SetAXATAPolicyIssue(agentCode, groupBrokerId, policyType, planID, refInv, JobNoList, out issueMsg);

    //            if (string.Compare(issueMsg.ToUpper().Trim(), "SUCCESS") == 0)
    //            {
    //                retMsg = "SUCCESS";

    //                #region ###Process Send E-mail or FTP Document
    //                if (isFTP == false)
    //                {
    //                    ObjAXATATravellerDetail PolicyHolder = (ObjAXATATravellerDetail)lstTravellerAdult[0];
    //                    string insuredName = PolicyHolder._clientTitle + " " + PolicyHolder._clientName + " " + PolicyHolder._clientSurName;
    //                    string msgSendMail = string.Empty;
                        
    //                    foreach (string policyNo in PolicyNoList)
    //                    {
    //                        msgSendMail = this.SendMail(policyNo, brokerEmail, insuredName);
    //                    }

    //                    if (string.Compare(msgSendMail.ToUpper().Trim(), "SUCCESS") == 0)
    //                    {
    //                        deliverDocMsg = "SUCCESS";
    //                    }
    //                }
    //                else
    //                {
    //                    string msgFTP = string.Empty;

    //                    foreach (string policyNo in PolicyNoList)
    //                    {
    //                        msgFTP = this.UploadFileToFTP(policyNo, ftpServer, ftpUser, ftpPass);
    //                    }

    //                    if (string.Compare(msgFTP.ToUpper().Trim(), "SUCCESS") == 0)
    //                    {
    //                        deliverDocMsg = "SUCCESS";
    //                    }
    //                }
                    
    //                #endregion
    //            }
    //            else
    //            {
    //                retMsg = issueMsg + " IN SET AXA POLICY ISSUE PROCESS!!!";
    //            }
    //        }
    //        else
    //        {
    //            retMsg += " IN SET AXA JOB PROCESS!!!";
    //        }
    //    }

    //    msg = retMsg;
    //    deliverDocMsg = retDeiverDoc;

    //    return PolicyNoList;
    //}
    
    ///// <summary>
    ///// 
    ///// </summary>
    ///// <param name="agentCode"></param>
    ///// <param name="groupBrokerId"></param>
    ///// <param name="countryCode"></param>
    ///// <param name="departureDate">dd/MM/yyyy(A.D.)</param>
    ///// <param name="returnDate">dd/MM/yyyy(A.D.)</param>
    ///// <param name="policyType">Family/Individual</param>
    ///// <param name="planID"></param>
    ///// <param name="duration"></param>
    ///// <param name="isEurope">1/0</param>
    ///// <param name="personalDetail"></param>
    ///// <param name="lstTravellerAdult"></param>
    ///// <param name="lstTravellerChild"></param>
    ///// <param name="referenceNo">output</param>
    ///// <returns>List of JOB NO.(Reference No.)</returns>
    //[WebMethod]
    //public List<string> SetAXATAJob(string agentCode, string groupBrokerId, string countryName, string departureDate, string returnDate, string policyType, string planID, int duration, int isEurope, ObjAXATAPolicyHolderDetail personalDetail, List<ObjAXATATravellerDetail> lstTravellerAdult, List<ObjAXATATravellerDetail> lstTravellerChild, out string referenceNo, out string msg)
    //{
    //    Session["TravellerAdults"] = lstTravellerAdult;
    //    Session["TravellerChilds"] = lstTravellerChild;
    //    Session["PersonalDetails"] = personalDetail;
        
    //    string retMsg = string.Empty;
    //    string travelPlan = "SINGLE";
    //    int percentDiscount = 0;
    //    string userID = string.Empty;

    //    int NumbersOfChildren = lstTravellerChild.Count;
    //    string EffectiveDateFrom = TA.TAUtilities.ConvertDateFieldToDB(departureDate);
    //    string EffectiveDateTo = TA.TAUtilities.ConvertDateFieldToDB(returnDate);
    //    string CountryOfDestination = countryName;

    //    if (!string.IsNullOrEmpty(policyType))
    //        policyType = policyType.ToUpper().Trim();

    //    TAPlanPremuimBLL clsTAPlanPremuimBLL = new TAPlanPremuimBLL();
    //    TAPremuim getPlanPremium = new TAPremuim();
    //    getPlanPremium = clsTAPlanPremuimBLL.GetTAPremuim(planID, duration, travelPlan);
    //    double getNetPremium = string.IsNullOrEmpty(getPlanPremium.NetPremium.ToString()) ? 0 : Convert.ToDouble(getPlanPremium.NetPremium);

    //    double netPremium = getNetPremium;
    //    int tax = int.Parse(getPlanPremium.TAX);
    //    int stamp = int.Parse(getPlanPremium.Stamp);
    //    double totalPremium = double.Parse(getPlanPremium.Total);
    //    float PersonalAccident = (float)Utilities.ExactNumber(getPlanPremium.PersonalAccident);

    //    double total_netpremuim = netPremium;
    //    int total_tax = tax;
    //    int total_stamp = stamp;
    //    double total_totalpremium = totalPremium;

    //    DbTransaction dbTransaction = null;

    //    int travellerCounter = 0;
    //    List<string> JobNoList = new List<string>();

    //    foreach (ObjAXATATravellerDetail item in lstTravellerAdult)
    //    {
    //        try
    //        {
    //            travellerCounter++;

    //            #region "GET/SET JOB NUMBER (NOW NONE TRANSACTION)"
    //            //GET/SET JOB NUMBER
    //            //string m_JobNo = "AXA-TA-20120500007";
    //            TAJobRunningBLL clsjobrunning = new TAJobRunningBLL();
    //            string JobNo = string.Empty;
    //            //JobNo = clsjobrunning.GetTAJobRunningNumber(dbTransaction);                
    //            JobNo = clsjobrunning.GetTAJobRunningNumber();
    //            if (string.IsNullOrEmpty(JobNo))
    //            {
    //                throw new Exception("เกิดข้อผิดพลาดในการสร้างหมายเลข Job Number กรุณาทดลองบันทึกงานอีกครั้งหรือติดต่อผู้ดูแลระบบ");
    //            }
    //            #endregion

    //            #region "OPEN DB"
    //            //OPEN DB
    //            DbProviderHelper.OpenDb();
    //            #endregion

    //            #region "OPEN TRANSACTION"
    //            //TRANSACTION BEGIN
    //            dbTransaction = DbProviderHelper.BeginTransaction();
    //            #endregion

    //            #region "#1-INSERT/UPDATE TRANSPOLICY"
    //            //#1-INSERT/UPDATE TRANSPOLICY                         
    //            TATransPolicyBLL clstranspolicy = new TATransPolicyBLL();
    //            //clstranspolicy.SetTATransPolicy("AXA-TA-20120500001", "", "Annual", "Individual", 0, "0001", "2012-05-23", "2013-05-23", "TH", "", "", 0, 0, 0, 0, 0, 0, "", "BA347", dbTransaction);
    //            clstranspolicy.SetTATransPolicy(JobNo, "", "Single", policyType, NumbersOfChildren, planID, EffectiveDateFrom, EffectiveDateTo, CountryOfDestination, "", agentCode, "", Convert.ToDecimal(netPremium), stamp, Convert.ToDecimal(tax), Convert.ToDecimal(totalPremium), 0, 0, userID, groupBrokerId, dbTransaction);

    //            #endregion

    //            #region "#2-INSERT/UPDATE TRANSPOLICYHOLDER"
    //            //#3-INSERT/UPDATE TRANSPOLICYHOLDER
    //            string ClientType = "P";

    //            TATransPolicyHolderBLL clstranspolicyholder = new TATransPolicyHolderBLL();

    //            //---------if login policyholder = userlogin------------------
    //            //Traveller tmpPersonal = (Traveller)item;

    //            string ClientTitle = item._clientTitle;
    //            string ClientName = item._clientName;
    //            string ClientSurName = item._clientSurName;

    //            clstranspolicyholder.SetTATransPolicyHolder(JobNo, ClientType, ClientTitle, ClientName, ClientSurName, personalDetail._clientAddress1, personalDetail._clientAddress2, personalDetail._province, personalDetail._amphur, personalDetail._tumbol, personalDetail._postCode, TA.TAUtilities.ConvertDateFieldToDB(item._birthday), item._passportID, personalDetail._tel, personalDetail._email, "E", dbTransaction);

    //            #endregion

    //            #region "#3-INSERT/UPDATE TRANSCOVERAGE"
    //            //#3-INSERT/UPDATE TRANSCOVERAGE
    //            TATransCoverageBLL clstranscoverage = new TATransCoverageBLL();
    //            //clstranscoverage.SetTATransCoverage("AXA-TA-20120500001", (float)1000000, "0001", dbTransaction);
    //            clstranscoverage.SetTATransCoverage(JobNo, PersonalAccident, planID, dbTransaction);
    //            #endregion

    //            #region "#4-INSERT/UPDATE TRANSTRAVELER"
    //            //#4-INSERT/UPDATE TRANSTRAVELER

    //            if (string.Compare(policyType, "FAMILY") == 0)
    //            {
    //                int TravelerId = 1;

    //                double tmpNetpremuim = 0;
    //                int tmpTax = 0;
    //                int tmpStamp = 0;
    //                double tmpTotalpremium = 0;

    //                tmpNetpremuim = (netPremium) - Convert.ToInt32(Math.Floor(netPremium * percentDiscount / 100));
    //                tmpStamp = Convert.ToInt32(Math.Ceiling(tmpNetpremuim * 0.004));
    //                tmpTax = Convert.ToInt32(Math.Ceiling(tmpNetpremuim * 0.0));
    //                tmpTotalpremium = tmpNetpremuim + tmpTax + tmpStamp;

    //                foreach (ObjAXATATravellerDetail tmpAdults in lstTravellerAdult)
    //                {
    //                    //Traveller tmpTraveller = (Traveller)tmpAdults;
    //                    TATransTravelerBLL clstranstraveler = new TATransTravelerBLL();
    //                    //clstranstraveler.SetTATransTraveler(m_JobNo, m_TravelerId, m_ClientTitle, m_ClientName, m_ClientSurName, m_Birthday, m_PassportID, m_Tel, m_isStudent, m_isSingle, null, dbTransaction);
    //                    clstranstraveler.SetTATransTraveler(JobNo, TravelerId, tmpAdults._clientTitleValue, tmpAdults._clientName, tmpAdults._clientSurName, TA.TAUtilities.ConvertDateFieldToDB(tmpAdults._birthday), tmpAdults._passportID, "", 0, 0, Convert.ToDecimal(PersonalAccident), Convert.ToDecimal(tmpNetpremuim), tmpStamp, tmpTax, Convert.ToDecimal(tmpTotalpremium), null, dbTransaction);


    //                    #region "#5-INSERT/UPDATE TRANSBENEFICIARY"

    //                    TATransBeneficiaryBLL clstransbeneficiary = new TATransBeneficiaryBLL();
    //                    clstransbeneficiary.SetTATransBeneficiary(JobNo, TravelerId, 1, "", tmpAdults._beneficiary, "", "", "100", "", dbTransaction);

    //                    #endregion

    //                    TravelerId++;
    //                }

    //                foreach (ObjAXATATravellerDetail tmpChild in lstTravellerChild)
    //                {
    //                    tmpNetpremuim = 0;
    //                    tmpTax = 0;
    //                    tmpStamp = 0;
    //                    tmpTotalpremium = 0;
    //                    float tmpPersonalAccident = 0;

    //                    if (TravelerId < 5)
    //                    {
    //                        tmpNetpremuim = 0;
    //                        tmpTax = 0;
    //                        tmpStamp = 0;
    //                        tmpTotalpremium = 0;
    //                        tmpPersonalAccident = PersonalAccident / 2;
    //                    }
    //                    else
    //                    {
    //                        tmpNetpremuim = netPremium;
    //                        tmpNetpremuim = (tmpNetpremuim) - Convert.ToInt32(Math.Floor((tmpNetpremuim) * percentDiscount / 100));
    //                        tmpTax = tax;
    //                        tmpStamp = stamp;
    //                        tmpTotalpremium = totalPremium;
    //                        tmpPersonalAccident = PersonalAccident;
    //                    }

    //                    tmpStamp = Convert.ToInt32(Math.Ceiling(tmpNetpremuim * 0.004));
    //                    tmpTax = Convert.ToInt32(Math.Ceiling(tmpNetpremuim * 0.0));
    //                    tmpTotalpremium = tmpNetpremuim + tmpTax + tmpStamp;

    //                    //กรณี Family ลูก ๆ จะได้รับ PA คุ้มครอง 50% 2012-06-05
    //                    //Traveller tmpTraveller = (Traveller)tmpChild;
    //                    TATransTravelerBLL clstranstraveler = new TATransTravelerBLL();
    //                    //clstranstraveler.SetTATransTraveler(m_JobNo, m_TravelerId, m_ClientTitle, m_ClientName, m_ClientSurName, m_Birthday, m_PassportID, m_Tel, m_isStudent, m_isSingle, null, dbTransaction);
    //                    clstranstraveler.SetTATransTraveler(JobNo, TravelerId, tmpChild._clientTitleValue, tmpChild._clientName, tmpChild._clientSurName, TA.TAUtilities.ConvertDateFieldToDB(tmpChild._birthday), tmpChild._passportID, "", 0, 0, Convert.ToDecimal(tmpPersonalAccident), Convert.ToDecimal(tmpNetpremuim), tmpStamp, tmpTax, Convert.ToDecimal(tmpTotalpremium), null, dbTransaction);


    //                    #region "#5-INSERT/UPDATE TRANSBENEFICIARY"

    //                    TATransBeneficiaryBLL clstransbeneficiary = new TATransBeneficiaryBLL();
    //                    clstransbeneficiary.SetTATransBeneficiary(JobNo, TravelerId, 1, "", tmpChild._beneficiary, "", "", "100", "", dbTransaction);

    //                    #endregion

    //                    TravelerId++;
    //                }
    //            }
    //            else
    //            {

    //                total_netpremuim = netPremium - Convert.ToInt32(Math.Floor(netPremium * (percentDiscount / 100)));
    //                total_stamp = Convert.ToInt32(Math.Ceiling(total_netpremuim * 0.004));
    //                total_tax = Convert.ToInt32(Math.Ceiling(total_netpremuim * 0.0));
    //                total_totalpremium = total_netpremuim + total_tax + total_stamp;


    //                TATransTravelerBLL clstranstraveler = new TATransTravelerBLL();
    //                //clstranstraveler.SetTATransTraveler(m_JobNo, m_TravelerId, m_ClientTitle, m_ClientName, m_ClientSurName, m_Birthday, m_PassportID, m_Tel, m_isStudent, m_isSingle, null, dbTransaction);
    //                clstranstraveler.SetTATransTraveler(JobNo, 1, item._clientTitleValue, item._clientName, item._clientSurName, TA.TAUtilities.ConvertDateFieldToDB(item._birthday), item._passportID, "", 0, 0, Convert.ToDecimal(PersonalAccident), Convert.ToDecimal(total_netpremuim), total_stamp, total_tax, Convert.ToDecimal(total_totalpremium), null, dbTransaction);

    //                #region "#5-INSERT/UPDATE TRANSBENEFICIARY"

    //                TATransBeneficiaryBLL clstransbeneficiary = new TATransBeneficiaryBLL();
    //                clstransbeneficiary.SetTATransBeneficiary(JobNo, 1, 1, "", item._beneficiary, "", "", "100", "", dbTransaction);

    //                #endregion
    //            }
    //            #endregion

    //            #region 5-INSERT/NOT USER DISCOUNT
    //            //if (!String.IsNullOrEmpty(personalDetail._discountCode) && travellerCounter == 1)
    //            //{
    //            //    TAB2CDiscountBLL setDiscount = new TAB2CDiscountBLL();
    //            //    setDiscount.spTAB2C_SetUseDiscount(JobNo, personalDetail._discountCode, user.Email, dbTransaction);
    //            //}
    //            #endregion

    //            #region "COMMIT DB"
    //            //COMMIT DB
    //            DbProviderHelper.CommitTransaction(dbTransaction);
    //            #endregion

    //            #region "CLOSE DB"
    //            //CLOSE DB
    //            DbProviderHelper.CloseDb();
    //            dbTransaction.Dispose();
    //            dbTransaction = null;

    //            #endregion

    //            JobNoList.Add(JobNo);

    //            if (string.Compare(policyType, "FAMILY") == 0)
    //            {
    //                break;
    //            }

    //        }
    //        catch (Exception ex)
    //        {
    //            retMsg += ex.Message.ToString() + " | ";

    //            if (dbTransaction != null)
    //            {
    //                #region "ROLLBACK DB"
    //                //ROLLBACK DB
    //                DbProviderHelper.RollbackTransaction(dbTransaction);
    //                #endregion

    //                #region "CLOSE DB"
    //                //CLOSE DB
    //                DbProviderHelper.CloseDb();
    //                #endregion
    //            }
    //        }
    //    }

    //    referenceNo = JobNoList[0];

    //    if (retMsg == string.Empty)
    //        retMsg = "SUCCESS";

    //    msg = retMsg;

    //    return JobNoList;
    //}

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="countryName"></param>
    /// <param name="departureDate"></param>
    /// <param name="returnDate"></param>
    /// <param name="policyType"></param>
    /// <param name="planID"></param>
    /// <param name="policyHolderDetail"></param>
    /// <param name="lstTravellerAdult"></param>
    /// <param name="lstTravellerChild"></param>
    /// <param name="referenceCode"></param>
    /// <param name="isFTP"></param>
    /// <param name="ftpServer"></param>
    /// <param name="ftpUser"></param>
    /// <param name="ftpPass"></param>
    /// <param name="brokerEmail"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXATAPolicyIssued ProcessAXATAPolicyIssue(string agentCode, string groupBrokerId, string password,string language, string countryName, string departureDate, string returnDate, string policyType, string planID, ObjAXATAPolicyHolderDetail policyHolderDetail, List<ObjAXATATravellerDetail> lstTravellerAdult, List<ObjAXATATravellerDetail> lstTravellerChild, string referenceCode, bool isFTP, string ftpServer, string ftpUser, string ftpPass, string brokerEmail,bool isMember)
    {
        language = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();

        string retMsg = string.Empty;
        string retDeiverDoc = string.Empty;
        string travelPlan = "SINGLE";
        int percentDiscount = 0;
        string userID = string.Empty;
        bool isValidateOK = true;
        int duration = 0;
        int isEurope = 0;

        List<string> PolicyNoList = new List<string>();        

        #region ###Validate Corect Data into Web Service


        if ( (string.IsNullOrEmpty(departureDate) || string.IsNullOrEmpty(returnDate))
            || (departureDate.Length < 10 || returnDate.Length < 10))
        {
            isValidateOK = false;
            retMsg += " | Departure or Return Date Data Must be complete!!!";
        }
        else
        {
            string[] arrDateDeparture = departureDate.Split('/');
            string[] arrDateReturn = returnDate.Split('/');

            if (Int32.Parse(arrDateDeparture[2].Substring(0, 4)) > 2500)
            {
                isValidateOK = false;
                retMsg += " | Departure Date(Year) Value Must be A.D.!!!";
            }

            if (Int32.Parse(arrDateReturn[2].Substring(0, 4)) > 2500)
            {
                isValidateOK = false;
                retMsg += " | Return Date(Year) Value Must be A.D.!!!";
            }

            //Calulate duration
            duration = this.CalculateDuration(departureDate, returnDate);
            //End
        }

        if (string.IsNullOrEmpty(policyType))
        {
            isValidateOK = false;
            retMsg += " | Policy Type Must have value (Individual/Family/Group)!!!";
        }
        else
        {
            if ((string.Compare(policyType.ToUpper().Trim(), "INDIVIDUAL") == 0) || (string.Compare(policyType.ToUpper().Trim(), "FAMILY") == 0) || (string.Compare(policyType.ToUpper().Trim(), "GROUP") == 0))
            {

            }
            else
            {
                isValidateOK = false;
                retMsg += " | Policy Type Must have value (Individual/Family/Group)!!!";
            }
        }

        //if ((isEurope != 1) && (isEurope != 0))
        //{
        //    isValidateOK = false;
        //    retMsg += " | Is Europe Must have integer value (1/0)!!!";
        //}

        if (duration <= 0)
        {
            isValidateOK = false;
            retMsg += " | Duration value must more than zero!!!";
        }

        if (policyHolderDetail == null)
        {
            isValidateOK = false;
            retMsg += " | Personal detail data can not be null value!!!";
        }

        if (lstTravellerAdult == null || lstTravellerAdult[0] == null)
        {
            isValidateOK = false;
            retMsg += " | List of traveller adult can not be null value!!!";
        }

        if (lstTravellerChild == null)
        {
            isValidateOK = false;
            retMsg += " | List of traveller child can not be null value!!!";
        }
        else
        {
            if ((string.Compare(policyType.ToUpper().Trim(), "INDIVIDUAL") == 0) || (string.Compare(policyType.ToUpper().Trim(), "GROUP") == 0))
            {
                if (lstTravellerChild.Count > 0)
                {
                    isValidateOK = false;
                    retMsg += " | Policy Type Individual or Group -> List of traveller child must be empty(count 0) only!!!";
                }
            }
        }

        if (isFTP == true)
        {
            if (string.IsNullOrEmpty(ftpServer) || string.IsNullOrEmpty(ftpUser) || string.IsNullOrEmpty(ftpPass))
            {
                isValidateOK = false;
                retMsg += " | FTP Data Must be complete!!!";
            }
        }
        else
        {
            if (string.IsNullOrEmpty(brokerEmail))
            {
                isValidateOK = false;
                retMsg += " | Broker email Data Must be complete!!!";
            }
        }

        //20150731 : validate address as400 format
        string str_validateAddressFmtAS4001 = this.validateAddressFmtAS400(policyHolderDetail._clientAddress1);
        if(str_validateAddressFmtAS4001.Length>0){
            isValidateOK = false;
            retMsg += " | clientAddress1 :" + str_validateAddressFmtAS4001;
        }

        string str_validateAddressFmtAS4002 = this.validateAddressFmtAS400(policyHolderDetail._clientAddress2);
        if (str_validateAddressFmtAS4002.Length > 0)
        {
            isValidateOK = false;
            retMsg += " | clientAddress2 :" + str_validateAddressFmtAS4002;
        }


        string str_validateBirthDay = this.validateDateFormat(policyHolderDetail._birthday);
        if (str_validateBirthDay.Length > 0)
        {
            isValidateOK = false;
            retMsg += " | clientBirthDay :" + str_validateBirthDay;
        }
          

        #endregion

        #region ###Validate security & authorization into Web Service
        if (isValidateOK == true)
        {

            string retMsgSecur = "";
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out retMsgSecur);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            if (isValidateOK == false)
            {
                retMsg += retMsgSecur;
            }
        }
        #endregion

        if (isValidateOK == true)
        {
            //Search country for get isEurope
            isEurope = this.GetIsEurope(countryName);
            //End Search

            int NumbersOfChildren = lstTravellerChild.Count;
            int NumbersOfAdult = lstTravellerAdult.Count;
            string EffectiveDateFrom = TA.TAUtilities.ConvertDateFieldToDB(departureDate);
            string EffectiveDateTo = TA.TAUtilities.ConvertDateFieldToDB(returnDate);
            string CountryOfDestination = countryName;

            if (!string.IsNullOrEmpty(policyType))
                policyType = policyType.ToUpper().Trim();

            //Discount Process Krit 2015-03-18
            TAPlanCampaignBLL clsTAPlanCampaingBLL = new TAPlanCampaignBLL();
            percentDiscount = clsTAPlanCampaingBLL.spTA_GetCampaignDiscount(2, countryName);
            if (isMember && percentDiscount <= 0)
            {
                percentDiscount = clsTAPlanCampaingBLL.spTA_GetCampaignDiscount(1, String.Empty);
            }            

            TAPlanPremuimBLL clsTAPlanPremuimBLL = new TAPlanPremuimBLL();
            TAPremuim getPlanPremium = new TAPremuim();
            getPlanPremium = clsTAPlanPremuimBLL.GetTAPremuim(planID, duration, travelPlan);
            double getNetPremium = string.IsNullOrEmpty(getPlanPremium.NetPremium.ToString()) ? 0 : Convert.ToDouble(getPlanPremium.NetPremium);

            double netPremium = getNetPremium;
            int tax = int.Parse(getPlanPremium.TAX);
            int stamp = int.Parse(getPlanPremium.Stamp);
            double totalPremium = double.Parse(getPlanPremium.Total);
            float PersonalAccident = (float)Utilities.ExactNumber(getPlanPremium.PersonalAccident);

            double total_netpremuim = netPremium;
            int total_tax = tax;
            int total_stamp = stamp;
            double total_totalpremium = totalPremium;

            DbTransaction dbTransaction = null;

            int travellerCounter = 0;
            List<string> JobNoList = new List<string>();

            foreach (ObjAXATATravellerDetail item in lstTravellerAdult)
            {
                try
                {
                    travellerCounter++;

                    #region "GET/SET JOB NUMBER (NOW NONE TRANSACTION)"
                    //GET/SET JOB NUMBER
                    //string m_JobNo = "AXA-TA-20120500007";
                    TAJobRunningBLL clsjobrunning = new TAJobRunningBLL();
                    string JobNo = string.Empty;
                    //JobNo = clsjobrunning.GetTAJobRunningNumber(dbTransaction);                
                    JobNo = clsjobrunning.GetTAJobRunningNumber();
                    if (string.IsNullOrEmpty(JobNo))
                    {
                        throw new Exception("เกิดข้อผิดพลาดในการสร้างหมายเลข Job Number กรุณาทดลองบันทึกงานอีกครั้งหรือติดต่อผู้ดูแลระบบ");
                    }
                    #endregion

                    #region "OPEN DB"
                    //OPEN DB
                    DbProviderHelper.OpenDb();
                    #endregion

                    #region "OPEN TRANSACTION"
                    //TRANSACTION BEGIN
                    dbTransaction = DbProviderHelper.BeginTransaction();
                    #endregion

                    #region "#1-INSERT/UPDATE TRANSPOLICY"

                    //------ CALUCATE PREMIUM -------

                    double tmpPYNetpremuim = 0;
                    int tmpPYTax = 0;
                    int tmpPYStamp = 0;
                    double tmpPYTotalpremium = 0;

                    tmpPYNetpremuim = (netPremium) - Convert.ToInt32(Math.Floor(netPremium * percentDiscount / 100));
                    tmpPYStamp = Convert.ToInt32(Math.Ceiling(tmpPYNetpremuim * 0.004));
                    tmpPYTax = Convert.ToInt32(Math.Ceiling(tmpPYNetpremuim * 0.0));
                    tmpPYTotalpremium = tmpPYNetpremuim + tmpPYTax + tmpPYStamp;

                    if (string.Compare(policyType, "FAMILY") == 0)
                    {
                        if (NumbersOfChildren > 2)
                        {
                            tmpPYNetpremuim = tmpPYNetpremuim * (2 + (NumbersOfChildren - 2));
                            tmpPYStamp = tmpPYStamp * (2 + (NumbersOfChildren - 2));
                            tmpPYTax = tmpPYTax * (2 + (NumbersOfChildren - 2));
                            tmpPYTotalpremium = tmpPYTotalpremium * (2 + (NumbersOfChildren - 2));
                        }
                        else
                        {
                            tmpPYNetpremuim = tmpPYNetpremuim * 2;
                            tmpPYStamp = tmpPYStamp * 2;
                            tmpPYTax = tmpPYTax * 2;
                            tmpPYTotalpremium = tmpPYTotalpremium * 2;
                        }
                    }
                    else if (string.Compare(policyType, "GROUP") == 0)
                    {
                        tmpPYNetpremuim = tmpPYNetpremuim * NumbersOfAdult;
                        tmpPYStamp = tmpPYStamp * NumbersOfAdult;
                        tmpPYTax = tmpPYTax * NumbersOfAdult;
                        tmpPYTotalpremium = tmpPYTotalpremium * NumbersOfAdult;
                    }
                    //------ END CALUCATE PREMIUM -------
                    //#1-INSERT/UPDATE TRANSPOLICY                         
                    TATransPolicyBLL clstranspolicy = new TATransPolicyBLL();
                    //clstranspolicy.SetTATransPolicy("AXA-TA-20120500001", "", "Annual", "Individual", 0, "0001", "2012-05-23", "2013-05-23", "TH", "", "", 0, 0, 0, 0, 0, 0, "", "BA347", dbTransaction);
                    clstranspolicy.SetTATransPolicy(JobNo, "", "Single", policyType, NumbersOfChildren, planID, EffectiveDateFrom, EffectiveDateTo, CountryOfDestination, "", agentCode, "", Convert.ToDecimal(tmpPYNetpremuim), tmpPYStamp, Convert.ToDecimal(tmpPYTax), Convert.ToDecimal(tmpPYTotalpremium), 0, 0, userID, groupBrokerId, dbTransaction);

                    #region "COMMIT DB"
                    //COMMIT DB
                    DbProviderHelper.CommitTransaction(dbTransaction);
                    #endregion

                    #region "CLOSE DB"
                    //CLOSE DB
                    DbProviderHelper.CloseDb();
                    dbTransaction.Dispose();
                    dbTransaction = null;

                    #endregion


                    #endregion

                    #region "OPEN DB"
                    //OPEN DB
                    DbProviderHelper.OpenDb();
                    #endregion

                    #region "OPEN TRANSACTION"
                    //TRANSACTION BEGIN
                    dbTransaction = DbProviderHelper.BeginTransaction();
                    #endregion

                    #region "#2-INSERT/UPDATE TRANSPOLICYHOLDER"
                    //#3-INSERT/UPDATE TRANSPOLICYHOLDER
                    string ClientType = policyHolderDetail._clientType;

                    TATransPolicyHolderBLL clstranspolicyholder = new TATransPolicyHolderBLL();

                    //---------if login policyholder = userlogin------------------
                    //Traveller tmpPersonal = (Traveller)item;

                    string ClientTitle = policyHolderDetail._clientTitle;
                    string ClientName = policyHolderDetail._clientName;
                    string ClientSurName = policyHolderDetail._clientSurName;

                    clstranspolicyholder.SetTATransPolicyHolder(JobNo, ClientType, ClientTitle, ClientName, ClientSurName, policyHolderDetail._clientAddress1, policyHolderDetail._clientAddress2, policyHolderDetail._province, policyHolderDetail._amphur, policyHolderDetail._tumbol, policyHolderDetail._postCode, TA.TAUtilities.ConvertDateFieldToDB(policyHolderDetail._birthday), policyHolderDetail._idCard, policyHolderDetail._tel, policyHolderDetail._email, language,policyHolderDetail._branchNo, dbTransaction);

                    #endregion

                    #region "#3-INSERT/UPDATE TRANSCOVERAGE"
                    //#3-INSERT/UPDATE TRANSCOVERAGE
                    TATransCoverageBLL clstranscoverage = new TATransCoverageBLL();
                    //clstranscoverage.SetTATransCoverage("AXA-TA-20120500001", (float)1000000, "0001", dbTransaction);
                    clstranscoverage.SetTATransCoverage(JobNo, PersonalAccident, planID, dbTransaction);
                    #endregion

                    #region "#4-INSERT/UPDATE TRANSTRAVELER"
                    //#4-INSERT/UPDATE TRANSTRAVELER

                    if (string.Compare(policyType, "FAMILY") == 0)
                    {
                        int TravelerId = 1;

                        double tmpNetpremuim = 0;
                        int tmpTax = 0;
                        int tmpStamp = 0;
                        double tmpTotalpremium = 0;

                        tmpNetpremuim = (netPremium) - Convert.ToInt32(Math.Floor(netPremium * percentDiscount / 100));
                        tmpStamp = Convert.ToInt32(Math.Ceiling(tmpNetpremuim * 0.004));
                        tmpTax = Convert.ToInt32(Math.Ceiling(tmpNetpremuim * 0.0));
                        tmpTotalpremium = tmpNetpremuim + tmpTax + tmpStamp;

                        foreach (ObjAXATATravellerDetail tmpAdults in lstTravellerAdult)
                        {
                            //Traveller tmpTraveller = (Traveller)tmpAdults;
                            TATransTravelerBLL clstranstraveler = new TATransTravelerBLL();
                            //clstranstraveler.SetTATransTraveler(m_JobNo, m_TravelerId, m_ClientTitle, m_ClientName, m_ClientSurName, m_Birthday, m_PassportID, m_Tel, m_isStudent, m_isSingle, null, dbTransaction);
                            clstranstraveler.SetTATransTraveler(JobNo, TravelerId, tmpAdults._clientTitle, tmpAdults._clientName, tmpAdults._clientSurName, TA.TAUtilities.ConvertDateFieldToDB(tmpAdults._birthday), tmpAdults._passportID, "", 0, 0, Convert.ToDecimal(PersonalAccident), Convert.ToDecimal(tmpNetpremuim), tmpStamp, tmpTax, Convert.ToDecimal(tmpTotalpremium), null, dbTransaction);


                            #region "#5-INSERT/UPDATE TRANSBENEFICIARY"

                            TATransBeneficiaryBLL clstransbeneficiary = new TATransBeneficiaryBLL();
                            clstransbeneficiary.SetTATransBeneficiary(JobNo, TravelerId, 1, "", tmpAdults._beneficiary, "", tmpAdults._beneficiaryRelation, "100", "", dbTransaction);

                            #endregion

                            TravelerId++;

                            if (TravelerId == 3) break;
                        }

                        foreach (ObjAXATATravellerDetail tmpChild in lstTravellerChild)
                        {
                            if (tmpChild == null)
                            {
                                throw new Exception("| Child Insured is NULL OR Not Assigned?!!");
                            }
                            tmpNetpremuim = 0;
                            tmpTax = 0;
                            tmpStamp = 0;
                            tmpTotalpremium = 0;
                            float tmpPersonalAccident = 0;

                            if (TravelerId < 5)
                            {
                                tmpNetpremuim = 0;
                                tmpTax = 0;
                                tmpStamp = 0;
                                tmpTotalpremium = 0;
                                tmpPersonalAccident = PersonalAccident / 2;
                            }
                            else
                            {
                                tmpNetpremuim = netPremium;
                                tmpNetpremuim = (tmpNetpremuim) - Convert.ToInt32(Math.Floor((tmpNetpremuim) * percentDiscount / 100));
                                tmpTax = tax;
                                tmpStamp = stamp;
                                tmpTotalpremium = totalPremium;
                                tmpPersonalAccident = PersonalAccident;
                            }

                            tmpStamp = Convert.ToInt32(Math.Ceiling(tmpNetpremuim * 0.004));
                            tmpTax = Convert.ToInt32(Math.Ceiling(tmpNetpremuim * 0.0));
                            tmpTotalpremium = tmpNetpremuim + tmpTax + tmpStamp;

                            //กรณี Family ลูก ๆ จะได้รับ PA คุ้มครอง 50% 2012-06-05
                            //Traveller tmpTraveller = (Traveller)tmpChild;
                            TATransTravelerBLL clstranstraveler = new TATransTravelerBLL();
                            //clstranstraveler.SetTATransTraveler(m_JobNo, m_TravelerId, m_ClientTitle, m_ClientName, m_ClientSurName, m_Birthday, m_PassportID, m_Tel, m_isStudent, m_isSingle, null, dbTransaction);
                            clstranstraveler.SetTATransTraveler(JobNo, TravelerId, tmpChild._clientTitle, tmpChild._clientName, tmpChild._clientSurName, TA.TAUtilities.ConvertDateFieldToDB(tmpChild._birthday), tmpChild._passportID, "", 0, 0, Convert.ToDecimal(tmpPersonalAccident), Convert.ToDecimal(tmpNetpremuim), tmpStamp, tmpTax, Convert.ToDecimal(tmpTotalpremium), null, dbTransaction);


                            #region "#5-INSERT/UPDATE TRANSBENEFICIARY"

                            TATransBeneficiaryBLL clstransbeneficiary = new TATransBeneficiaryBLL();
                            clstransbeneficiary.SetTATransBeneficiary(JobNo, TravelerId, 1, "", tmpChild._beneficiary, "", tmpChild._beneficiaryRelation, "100", "", dbTransaction);

                            #endregion

                            TravelerId++;
                        }
                    }
                    else if (string.Compare(policyType, "INDIVIDUAL") == 0)
                    {

                        total_netpremuim = netPremium - Convert.ToInt32(Math.Floor(netPremium * percentDiscount / 100));//Fix bug by Krit 2015-04-20 total_netpremuim = netPremium - Convert.ToInt32(Math.Floor(netPremium * (percentDiscount / 100)));
                        total_stamp = Convert.ToInt32(Math.Ceiling(total_netpremuim * 0.004));
                        total_tax = Convert.ToInt32(Math.Ceiling(total_netpremuim * 0.0));
                        total_totalpremium = total_netpremuim + total_tax + total_stamp;

                        TATransTravelerBLL clstranstraveler = new TATransTravelerBLL();
                        //clstranstraveler.SetTATransTraveler(m_JobNo, m_TravelerId, m_ClientTitle, m_ClientName, m_ClientSurName, m_Birthday, m_PassportID, m_Tel, m_isStudent, m_isSingle, null, dbTransaction);
                        clstranstraveler.SetTATransTraveler(JobNo, 1, item._clientTitle, item._clientName, item._clientSurName, TA.TAUtilities.ConvertDateFieldToDB(item._birthday), item._passportID, "", 0, 0, Convert.ToDecimal(PersonalAccident), Convert.ToDecimal(total_netpremuim), total_stamp, total_tax, Convert.ToDecimal(total_totalpremium), null, dbTransaction);

                        #region "#5-INSERT/UPDATE TRANSBENEFICIARY"

                        TATransBeneficiaryBLL clstransbeneficiary = new TATransBeneficiaryBLL();
                        clstransbeneficiary.SetTATransBeneficiary(JobNo, 1, 1, "", item._beneficiary, "", item._beneficiaryRelation, "100", "", dbTransaction);

                        #endregion
                    }
                    else if (string.Compare(policyType, "GROUP") == 0)
                    {
                        int TravelerId = 1;

                        double tmpNetpremuim = 0;
                        int tmpTax = 0;
                        int tmpStamp = 0;
                        double tmpTotalpremium = 0;

                        tmpNetpremuim = (netPremium) - Convert.ToInt32(Math.Floor(netPremium * percentDiscount / 100));
                        tmpStamp = Convert.ToInt32(Math.Ceiling(tmpNetpremuim * 0.004));
                        tmpTax = Convert.ToInt32(Math.Ceiling(tmpNetpremuim * 0.0));
                        tmpTotalpremium = tmpNetpremuim + tmpTax + tmpStamp;

                        foreach (ObjAXATATravellerDetail tmpAdults in lstTravellerAdult)
                        {
                            TATransTravelerBLL clstranstraveler = new TATransTravelerBLL();
                            clstranstraveler.SetTATransTraveler(JobNo, TravelerId, tmpAdults._clientTitle, tmpAdults._clientName, tmpAdults._clientSurName, TA.TAUtilities.ConvertDateFieldToDB(tmpAdults._birthday), tmpAdults._passportID, "", 0, 0, Convert.ToDecimal(PersonalAccident), Convert.ToDecimal(tmpNetpremuim), tmpStamp, tmpTax, Convert.ToDecimal(tmpTotalpremium), null, dbTransaction);

                            #region "#5-INSERT/UPDATE TRANSBENEFICIARY"
                            TATransBeneficiaryBLL clstransbeneficiary = new TATransBeneficiaryBLL();
                            clstransbeneficiary.SetTATransBeneficiary(JobNo, TravelerId, 1, "", tmpAdults._beneficiary, "", tmpAdults._beneficiaryRelation, "100", "", dbTransaction);
                            #endregion

                            TravelerId++;
                        }
                    }
                    #endregion

                    #region 5-INSERT/NOT USER DISCOUNT
                    //if (!String.IsNullOrEmpty(personalDetail._discountCode) && travellerCounter == 1)
                    //{
                    //    TAB2CDiscountBLL setDiscount = new TAB2CDiscountBLL();
                    //    setDiscount.spTAB2C_SetUseDiscount(JobNo, personalDetail._discountCode, user.Email, dbTransaction);
                    //}
                    #endregion

                    #region "COMMIT DB"
                    //COMMIT DB
                    DbProviderHelper.CommitTransaction(dbTransaction);
                    #endregion

                    #region "CLOSE DB"
                    //CLOSE DB
                    DbProviderHelper.CloseDb();
                    dbTransaction.Dispose();
                    dbTransaction = null;

                    #endregion

                    JobNoList.Add(JobNo);

                    if ((string.Compare(policyType, "FAMILY") == 0) || (string.Compare(policyType, "GROUP") == 0) || (string.Compare(policyType, "INDIVIDUAL") == 0))
                    {
                        break;
                    }

                }
                catch (Exception ex)
                {
                    retMsg += ex.Message.ToString() + " | ";

                    if (dbTransaction != null)
                    {
                        #region "ROLLBACK DB"
                        //ROLLBACK DB
                        try
                        {
                            DbProviderHelper.RollbackTransaction(dbTransaction);
                        }
                        catch (Exception ex2)
                        {
                            // This catch block will handle any errors that may have occurred 
                            // on the server that would cause the rollback to fail, such as 
                            // a closed connection.
                            Console.WriteLine("Rollback Exception Type: {0}", ex2.GetType());
                            Console.WriteLine("  Message: {0}", ex2.Message);
                        }
                        throw;

                        #endregion

                        #region "CLOSE DB"
                        //CLOSE DB
                        DbProviderHelper.CloseDb();
                        #endregion
                    }
                }
            }

            if (retMsg == string.Empty)
                retMsg = "SUCCESS";

            string issueMsg = string.Empty;

            if (string.Compare(retMsg.ToUpper().Trim(), "SUCCESS") == 0)
            {
                PolicyNoList = this.SetAXATAPolicyIssue(agentCode, groupBrokerId, policyType, planID, referenceCode, JobNoList, out issueMsg);

                if (string.Compare(issueMsg.ToUpper().Trim(), "SUCCESS") == 0)
                {
                    retMsg = "SUCCESS";

                    #region ###Process Send E-mail or FTP Document                    
                    if (isFTP == false)
                    {
                        ObjAXATATravellerDetail PolicyHolder = (ObjAXATATravellerDetail)lstTravellerAdult[0];
                        string insuredName = PolicyHolder._clientTitle + " " + PolicyHolder._clientName + " " + PolicyHolder._clientSurName;
                        string msgSendMail = string.Empty;

                        foreach (string policyNo in PolicyNoList)
                        {
                            msgSendMail = this.SendMail(policyNo, brokerEmail, insuredName);
                        }

                        if (string.Compare(msgSendMail.ToUpper().Trim(), "SUCCESS") == 0)
                        {
                            retDeiverDoc = "SUCCESS";
                        }
                    }
                    else
                    {
                        string msgFTP = string.Empty;

                        foreach (string policyNo in PolicyNoList)
                        {
                            msgFTP = this.UploadFileToFTP(policyNo, ftpServer, ftpUser, ftpPass);
                        }

                        if (string.Compare(msgFTP.ToUpper().Trim(), "SUCCESS") == 0)
                        {
                            retDeiverDoc = "SUCCESS";
                        }
                    }

                    #endregion
 
                }
                else
                {
                    retMsg = issueMsg + " IN SET AXA POLICY ISSUE PROCESS!!!";
                }
            }
            else
            {
                retMsg += " IN SET AXA JOB PROCESS!!!";
            }
        }
      
        ObjAXATAPolicyIssued objPolicyIssued = new ObjAXATAPolicyIssued();
        objPolicyIssued._msg = retMsg;
        objPolicyIssued._deliverDocMsg = retDeiverDoc;
        if (PolicyNoList.Count > 0)
        {
            objPolicyIssued._policyNo = PolicyNoList[0].ToString();
        }
        else
        {
            objPolicyIssued._policyNo = "";
        }

        return objPolicyIssued;
    }

    [WebMethod]//Krit Update 20150317
    public List<ObjAXATAPolicyIssued> ProcessAXATAPolicyIndividualIssue(string agentCode, string groupBrokerId, string password,string language, string countryName, string departureDate, string returnDate, string policyType, string planID, ObjAXATAPolicyHolderDetail policyHolderDetail, List<ObjAXATATravellerDetail> lstTravellerAdult, string referenceCode, bool isFTP, string ftpServer, string ftpUser, string ftpPass, string brokerEmail,bool isMember)
    {
        List<ObjAXATAPolicyIssued> result = new List<ObjAXATAPolicyIssued>();
        try
        {
            #region ###Validate security & authorization into Web Service

            bool isValidateOK = true;
            string retMsg = "";
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out retMsg);
            
            if (isValidateOK == false)
            {
                throw new Exception(retMsg);
            }
            
            #endregion

            foreach (ObjAXATATravellerDetail item in lstTravellerAdult)
            {
                ObjAXATAPolicyHolderDetail selectPolicyHolderDetail = new ObjAXATAPolicyHolderDetail();                
                selectPolicyHolderDetail._branchNo = policyHolderDetail._branchNo;
                selectPolicyHolderDetail._clientAddress1 = policyHolderDetail._clientAddress1;
                selectPolicyHolderDetail._clientAddress2 = policyHolderDetail._clientAddress2;
                selectPolicyHolderDetail._clientType = policyHolderDetail._clientType;
                selectPolicyHolderDetail._discountCode = policyHolderDetail._discountCode;
                selectPolicyHolderDetail._email = policyHolderDetail._email;                            
                selectPolicyHolderDetail._tel = policyHolderDetail._tel;

                selectPolicyHolderDetail._postCode = policyHolderDetail._postCode;
                selectPolicyHolderDetail._province = policyHolderDetail._province;
                selectPolicyHolderDetail._provinceID = policyHolderDetail._provinceID;
                selectPolicyHolderDetail._tumbol = policyHolderDetail._tumbol;
                selectPolicyHolderDetail._tumbolID = policyHolderDetail._tumbolID;
                selectPolicyHolderDetail._amphur = policyHolderDetail._amphur;
                selectPolicyHolderDetail._amphurID = policyHolderDetail._amphurID;

                selectPolicyHolderDetail._clientTitle = item._clientTitle;
                selectPolicyHolderDetail._clientName = item._clientName;
                selectPolicyHolderDetail._clientSurName = item._clientSurName;
                selectPolicyHolderDetail._birthday = item._birthday;
                selectPolicyHolderDetail._idCard = item._passportID;

                List<ObjAXATATravellerDetail> listSelectAdult = new List<ObjAXATATravellerDetail>();
                ObjAXATATravellerDetail adult = new ObjAXATATravellerDetail();
                adult._beneficiary = item._beneficiary;
                adult._beneficiaryRelation = item._beneficiaryRelation;
                adult._birthday = item._birthday;
                adult._clientName = item._clientName;
                adult._clientSurName = item._clientSurName;
                adult._clientTitle = item._clientTitle;
                adult._passportID = item._passportID;
                listSelectAdult.Add(adult);

                List<ObjAXATATravellerDetail> lstTravellerChild = new List<ObjAXATATravellerDetail>();

                ObjAXATAPolicyIssued objPolicyIssued = ProcessAXATAPolicyIssue(agentCode, groupBrokerId, password, language, countryName, departureDate, returnDate, policyType, planID, selectPolicyHolderDetail, listSelectAdult, lstTravellerChild, referenceCode, isFTP, ftpServer, ftpUser, ftpPass, brokerEmail, isMember);
                result.Add(objPolicyIssued);
            }

            return result;
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }

    [WebMethod]//Krit Update 20150421
    public bool ReSendAXATAPolicyIssue(string agentCode, string groupBrokerId, string password, string brokerEmail, string referenceCode, List<ObjAXATATravellerDetail> lstTravellerAdult)
    {
        try
        {
            bool result = false;
            bool isValidateOK = true;

            string retMsg = String.Empty;
            string msgSendMail = String.Empty;

            #region ###Validate security & authorization into Web Service

            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out retMsg);
            
            if (isValidateOK == false)
            {                
                throw new Exception(retMsg);
            }
            #endregion

            if (isValidateOK == true)
            {
                TAB2CPolicyNoBLL getPolicyNo = new TAB2CPolicyNoBLL();
                DataTable dt = getPolicyNo.spTAB2C_FindPolicyNoByRef(referenceCode);

                List<ObjAXAResendPolicy> policyNoList = new List<ObjAXAResendPolicy>();
                if(dt.Rows.Count > 0)
                {
                    foreach(DataRow row in dt.Rows)
                    {
                        ObjAXAResendPolicy resendPolicy = new ObjAXAResendPolicy();
                        resendPolicy.policyNo = row["PolicyNo"].ToString();
                        resendPolicy.policyType = row["PolicyType"].ToString();
                        resendPolicy.planId = row["InsurancePlan"].ToString();

                        policyNoList.Add(resendPolicy);
                    }
                }

                if (policyNoList.Count() > 0 && policyNoList.Count() >= lstTravellerAdult.Count())
                {
                    int i = 0;
                    foreach (ObjAXAResendPolicy resendPolicy in policyNoList)
                    {
                        string insuredName = String.Format("{0} {1} {2}", lstTravellerAdult[i]._clientTitle.ToUpper(), lstTravellerAdult[i]._clientName.ToUpper(), lstTravellerAdult[i]._clientSurName.ToUpper());

                        //Is have policy find document 
                        string type = "00";//Fix
                        string path = @Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/DOC/") + resendPolicy.policyNo + @"\" + resendPolicy.policyNo + type + @".pdf";

                        if (!System.IO.File.Exists(path))
                        {
                            DataTable DTAble = new DataTable();
                            TATransPolicyBLL getPrintListReportName = new TATransPolicyBLL();

                            DTAble = getPrintListReportName.GetTAPrintListReportName(resendPolicy.policyNo, "0");

                            string url = QuickLinkConfiguration.UrlReportingServiceNew + DTAble.Rows[0]["ReportName"].ToString() + "&rs:Format=pdf&rs:command=render&PolicyNo=" + resendPolicy.policyNo + "&PolicyType=" + resendPolicy.policyType + "&PlanId=" + resendPolicy.planId;
                            this.PrintTAPolicy(url, resendPolicy.policyNo, "00");

                            //Add signature
                            AddSignature(resendPolicy.policyNo, "00");
                        }                        
                        //send email
                        msgSendMail = this.SendMail(resendPolicy.policyNo, brokerEmail, insuredName);
                        result = true;
                        i++;
                    }
                }
                
            }

            return result;
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }

    [WebMethod]
    public void ReGeneratePolicyIssue(string agentCode, string groupBrokerId, string password, string referenceCode)
    {
        try
        {   
            bool isValidateOK = true;
            string retMsg = String.Empty;            

            #region ###Validate security & authorization into Web Service

            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out retMsg);

            if (isValidateOK == false)
            {
                throw new Exception(retMsg);
            }

            #endregion

            if (isValidateOK == true)
            {
                TAB2CPolicyNoBLL getPolicyNo = new TAB2CPolicyNoBLL();
                DataTable dt = getPolicyNo.spTAB2C_FindPolicyNoByRef(referenceCode);

                List<ObjAXAResendPolicy> policyNoList = new List<ObjAXAResendPolicy>();
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        ObjAXAResendPolicy resendPolicy = new ObjAXAResendPolicy();
                        resendPolicy.policyNo = row["PolicyNo"].ToString();
                        resendPolicy.policyType = row["PolicyType"].ToString();
                        resendPolicy.planId = row["InsurancePlan"].ToString();

                        policyNoList.Add(resendPolicy);
                    }
                }

                if (policyNoList.Count() > 0)
                {
                    foreach (ObjAXAResendPolicy resendPolicy in policyNoList)
                    {
                        string type = "00";//Fix
                        string path = @Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/DOC/") + resendPolicy.policyNo + @"\" + resendPolicy.policyNo + type + @".pdf";

                        if (!System.IO.File.Exists(path))
                        {
                            DataTable DTAble = new DataTable();
                            TATransPolicyBLL getPrintListReportName = new TATransPolicyBLL();

                            DTAble = getPrintListReportName.GetTAPrintListReportName(resendPolicy.policyNo, "0");

                            string url = QuickLinkConfiguration.UrlReportingServiceNew + DTAble.Rows[0]["ReportName"].ToString() + "&rs:Format=pdf&rs:command=render&PolicyNo=" + resendPolicy.policyNo + "&PolicyType=" + resendPolicy.policyType + "&PlanId=" + resendPolicy.planId;
                            this.PrintTAPolicy(url, resendPolicy.policyNo, "00");

                            //Add signature
                            AddSignature(resendPolicy.policyNo, "00");
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    [WebMethod]//Krit Update 20150319
    public void SendEmailResetPassword(string agentCode, string groupBrokerId, string password,string email,string newpassword)
    {        
        try
        {            
            bool isValidateOK = true;

            string retMsg = String.Empty;
            string msgSendMail = String.Empty;

            #region ###Validate security & authorization into Web Service

            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out retMsg);

            if (isValidateOK == false)
            {
                throw new Exception(retMsg);
            }
            #endregion

            if (isValidateOK)
            {
                string emailFrom = "axatraveller@axa.co.th";
                string emailTo = email;
                string subject = "Reset You Password for AXA Thailand";

                string body = "เรียน ผู้ใช้บริการ<br/><br/>";
                body += "<p>บริษัท แอกซ่าประกันภัย จำกัด (มหาชน) ขอขอบคุณที่ท่านไว้วางใจให้บริษัทเป็นผู้ให้ความคุ้มครองแก่ลูกค้าของท่าน</p><br/><br/>";
                body += "<p>ดำเนินการเปลี่ยนรหัสผ่านให้ลูกค้าเรียบร้อยแล้ว</p><br/>";
                body += String.Format("<p>รหัสผ่านใหม่คือ {0}</p>", newpassword);

                body += "<p>ทั้งนี้ หากท่านมีข้อสงสัยประการใด สามารถติดต่อสอบถามกับเจ้าหน้าที่รับประกันภัยที่ดูแลท่านตลอดเวลาทำการ  </p><br/>";
                body += "<p>ขอแสดงความนับถือบริษัท<br/>แอกซ่าประกันภัย จำกัด (มหาชน)<br/>โทร. 02-118-8000</p>";
                body += "<p>บริการช่วยเหลือฉุกเฉิน 24 ชั่วโมง<br/>แอกซ่า ฮอตไลน์<br/>โทร. 02-642-6688, 02-206-5488<br/>เว็บไซด์ : <a href='http://www.axa.co.th' target='_blank'>www.axa.co.th</a></p>";

                Utilities.SendMail(emailFrom, emailTo, subject, body, true);
            }
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }

    [WebMethod]//Makkawat Add 2015-07-02
    public ObjAXATAPolicyIssued GetAXATAPolicy(string agentCode, string groupBrokerId, string password, string PassportID, string RefCode)
    {
        try
        {
            bool isValidateOK = true;
            string retMsg = String.Empty;
            ObjAXATAPolicyIssued objPolicyIssued = null;

            #region ###Validate security & authorization into Web Service

            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out retMsg);

            if (isValidateOK == false)
            {
                throw new Exception(retMsg);
            }

            #endregion

            if (isValidateOK == true)
            {
                //DbProviderHelper.OpenDb(); // OPEN DB
                TATransPolicyBLL clstranspolicy = new TATransPolicyBLL();
                DataTable dt = clstranspolicy.GetTATransPolicyByPassportIDAndReturn(PassportID, RefCode);
                //DbProviderHelper.CloseDb(); // CLOSE DB
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        if (dt.Rows[0]["PolicyNo"] != DBNull.Value)
                        {
                            objPolicyIssued = new ObjAXATAPolicyIssued();
                            objPolicyIssued._msg = "SUCCESS";
                            objPolicyIssued._deliverDocMsg = "SUCCESS";
                            objPolicyIssued._policyNo = dt.Rows[0]["PolicyNo"].ToString();
                        }
                    }
                }
            }

            return objPolicyIssued;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private List<string> SetAXATAPolicyIssue(string agentCode, string groupBrokerId, string policyType, string planID, string refInv, List<string> lstJobNo, out string msg)
    {
        string retMsg = string.Empty;
        string userID = string.Empty;

        List<string> PolicyNoList = new List<string>();

        try
        {
            if (!string.IsNullOrEmpty(policyType))
                policyType = policyType.ToUpper().Trim();

            List<string> JobNoList = lstJobNo;            

            foreach (string JobNo in JobNoList)
            {
                try
                {

                    #region #-1 GET POLIYNO
                    TAB2CPolicyNoBLL getPolicyNo = new TAB2CPolicyNoBLL();
                    string PolicyNo = getPolicyNo.spTAB2C_SetPolicyNo(JobNo);

                    #endregion

                    #region #-2 UPDATE POLICYNO TO JOBNO

                    getPolicyNo.spTAB2C_UpdatePolicyNoToJobNo(JobNo, PolicyNo, refInv);

                    #endregion

                    #region #-3 SetTransTaxInvoince
                    TATransPolicyBLL TATransPolicy = new TATransPolicyBLL();
                    TATransPolicy.spTAB2C_SetTransTaxInvoince(PolicyNo, JobNo, userID);

                    #endregion

                    #region #-4 SetTranPrint

                    TATransPolicy.SetTATransPrint(PolicyNo, JobNo, "", agentCode, groupBrokerId, "");

                    #endregion

                    #region #-5 SaveFile

                    DataTable DTAble = new DataTable();
                    TATransPolicyBLL getPrintListReportName = new TATransPolicyBLL();

                    DTAble = getPrintListReportName.GetTAPrintListReportName(PolicyNo, "0");

                    string url = QuickLinkConfiguration.UrlReportingServiceNew + DTAble.Rows[0]["ReportName"].ToString() + "&rs:Format=pdf&rs:command=render&PolicyNo=" + PolicyNo + "&PolicyType=" + policyType + "&PlanId=" + planID;
                    this.PrintTAPolicy(url, PolicyNo, "00");

                    //Add signature
                    AddSignature(PolicyNo, "00");

                    #endregion

                    PolicyNoList.Add(PolicyNo);
                }
                catch (Exception err)
                {
                    retMsg += err.Message.ToString() + " | ";
                }
            }
        }
        catch (Exception ex)
        {
            retMsg += ex.Message.ToString() + " | ";
        }

        if (retMsg == string.Empty)
            retMsg = "SUCCESS";

        msg = retMsg;

        return PolicyNoList;
    }

    private double CalculateTotalPremium(double NetPremium)
    {
        int stamp = Convert.ToInt32(Math.Ceiling(NetPremium * 0.004));
        int tax = Convert.ToInt32(Math.Ceiling(NetPremium * 0.0));
        double totalpremium = NetPremium + tax + stamp;

        return totalpremium;
    }


    public void PrintTAPolicy(string url, string policyno, string type)
    {
        string Command = "Render";
        string Format = "PDF";

        System.Net.NetworkCredential Credentials = new System.Net.NetworkCredential();
        Credentials.UserName = "quicklink";
        Credentials.Password = "Password1";
        Credentials.Domain = "bkk.dom";
        //We can get values of these parameters from Request object.

        string URL = url;

        //Specify the path for saving.
        System.IO.DirectoryInfo di = new DirectoryInfo(@Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/DOC/") + policyno);

        if (!di.Exists)
        {
            System.IO.Directory.CreateDirectory(@Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/DOC/") + policyno);

        }

        string path = @Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/DOC/") + policyno + @"\" + policyno + type + @".pdf";


        if (!File.Exists(path))
        {

            System.Net.HttpWebRequest Req = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(URL);
            Req.Credentials = Credentials;
            Req.ContentType = " text/html";


            Req.Method = "GET";


            System.Net.HttpWebResponse objResponse = (System.Net.HttpWebResponse)Req.GetResponse();

            System.IO.FileStream fs = new System.IO.FileStream(path, System.IO.FileMode.Create);

            System.IO.Stream stream = objResponse.GetResponseStream();

            byte[] buf = new byte[1024];

            int len = stream.Read(buf, 0, 1024);

            while (len > 0)
            {

                fs.Write(buf, 0, len);

                len = stream.Read(buf, 0, 1024);

            }

            stream.Close();

            fs.Close();
        }
    }

    private void AddSignature(string policyno, string type)
    {
        Spire.Pdf.PdfDocument pdfDoc = new Spire.Pdf.PdfDocument();
        try
        {
            string path = @Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/DOC/") + policyno + @"\" + policyno + type + @".pdf";            
            if (File.Exists(path))
            {
                pdfDoc.LoadFromFile(path);
                if(pdfDoc.Pages.Count == 3)//INDIVIDUAL
                {
                    Spire.Pdf.PdfPageBase page1 = pdfDoc.Pages[1];
                    Spire.Pdf.PdfPageBase page2 = pdfDoc.Pages[2];

                    DrawImage(page1);
                    DrawImage(page2);
                }
                else if (pdfDoc.Pages.Count == 4)//FAMILY
                {
                    Spire.Pdf.PdfPageBase page1 = pdfDoc.Pages[2];
                    Spire.Pdf.PdfPageBase page2 = pdfDoc.Pages[3];

                    DrawImage(page1);
                    DrawImage(page2);
                }

                pdfDoc.SaveToFile(path);
                pdfDoc.Close();
            }
        }
        catch(Exception ex)
        {
            throw ex;
        }
        finally
        {
            pdfDoc.Dispose();
        }
    }

    private void DrawImage(Spire.Pdf.PdfPageBase page)
    {
        string signature = @Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/Signature/") + "signature.png";
        Spire.Pdf.Graphics.PdfImage image = Spire.Pdf.Graphics.PdfImage.FromFile(signature);
        float width = image.Width * 0.75f;
        float height = image.Height * 0.75f;
        float x = (page.Canvas.ClientSize.Width - width) / 2;

        page.Canvas.DrawImage(image, 370, 500, width, height);
    }
    
    private string SendMail(string PolicyNo, string brokerEmail, string insuredName)
    {        
        string retMsg = string.Empty;
        string emailFrom = "axatraveller@axa.co.th";
        string emailTo = brokerEmail;
        string subject = "Confirmation of Travel Insurance Schedule";

        string emailPath = Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/Email/Travel.html");
        string body = System.IO.File.ReadAllText(emailPath);
        //body = String.Format(body, insuredName, PolicyNo);
        body = body.Replace("[SendName]", insuredName);
        body = body.Replace("[Policy]", PolicyNo);

        #region Email
        //string body = "เรียน ท่านนายหน้า/ผู้ออกกรมธรรม์<br/><br/>";
        //body += "<p>บริษัท แอกซ่าประกันภัย จำกัด (มหาชน) ขอขอบคุณที่ท่านไว้วางใจให้บริษัทเป็นผู้ให้ความคุ้มครองแก่ลูกค้าของท่าน</p><br/><br/>";
        //body += "<p>บริษัทฯ ขอเรียนให้ท่านทราบว่ากรมธรรม์คุณ " + insuredName + "ได้รับความคุ้มครองแล้ว กรมธรรม์เลขที่ " + PolicyNo + " ท่านสามารถพิมพ์กรมธรรม์ และเอกสารต่าง ๆ ที่แนบมากับอีเมล์ฉบับนี้ พร้อมกับแนบเอกสารเงื่อนไขความคุ้มครอง เพื่อจัดส่งให้กับลูกค้าของท่านต่อไป</p><br/>";
        //body += "<p>เอกสารที่ลูกค้าจะได้รับประกอบด้วย</p>";
        //body += "<ol>";
        //body += "<li>หน้าตารางกรมธรรม์</li>";
        //body += "<li>ใบแจ้งหนี้ หรือใบกำกับภาษี</li>";
        //body += "<li>เอกสารแนบกรมธรรม์ที่ระบุเงื่อนไขการความคุ้มครองโดยละเอียด</li>";
        //body += "<li>ซองใส่กรมธรรม์</li>";
        //body += "<li> ใบเสร็จรับเงิน (มอบให้กับลูกค้าเมื่อชำระเงินแล้ว พร้อมกับลงชื่อผู้รับเงิน)</li>";
        //body += "</ol><br/>";

        //body += "<p>บริษัทฯ มีความเชื่อมั่นว่า ท่านได้อธิบายเงื่อนไขความคุ้มครอง และประโยชน์ต่าง ๆ เกี่ยวกับกรมธรรม์ฉบับนี้ให้กับลูกค้าของท่านทราบก่อนตกลงทำประกันภัยแล้ว </p><br/>";

        //body += "<p>เพื่อเป็นการรักษาประโยชน์สูงสุดให้กับลูกค้าของท่าน ขอให้ท่านอธิบายเงื่อนความคุ้มครอง และประโยชน์ต่าง ๆ ที่ลูกค้าพึงจะได้รับโดยละเอียดอีกครั้งขณะนำกรมธรรม์ไปมอบให้ </p><br/>";

        //body += "<p>ทั้งนี้ หากท่านมีข้อสงสัยประการใด สามารถติดต่อสอบถามกับเจ้าหน้าที่รับประกันภัยที่ดูแลท่านตลอดเวลาทำการ  </p><br/>";

        //body += "<p>ขอแสดงความนับถือบริษัท<br/>แอกซ่าประกันภัย จำกัด (มหาชน)<br/>โทร. 02-118-8000</p>";
        //body += "<p>บริการช่วยเหลือฉุกเฉิน 24 ชั่วโมง<br/>แอกซ่า ฮอตไลน์<br/>โทร. 02-642-6688, 02-206-5488<br/>เว็บไซด์ : <a href='http://www.axa.co.th' target='_blank'>www.axa.co.th</a></p>";
        #endregion

        try
        {
            //string url = "";
            string type = "00";

            string path = path = Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/DOC/" + PolicyNo);

            string filePath = path + "\\" + PolicyNo + type + ".pdf";

            Utilities.SendMail(emailFrom, emailTo, subject, body, true, filePath);

            retMsg = "SUCCESS";

            //Response.End();
        }
        catch (Exception ex)
        {
            //Utilities.LogError(ex);
            //retMsg = ex.Message.ToString();
            throw ex;
        }

        return retMsg;

    }

    private string UploadFileToFTP(string PolicyNo, string _UploadPath, string _FTPUser, string _FTPPass)
    {
        string retMsg = string.Empty;
        
        try
        {
            string type = "00";
            string path = path = Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/DOC/" + PolicyNo);
            string filename = PolicyNo + type + ".pdf";
            string filePath = path + "\\" + filename;
                        
            FileStream stream = File.OpenRead(filePath);
            byte[] myData = new Byte[stream.Length];
            stream.Read(myData, 0, myData.Length);
            stream.Close();

            string ftpfullpath = _UploadPath + filename;
            FtpWebRequest ftp = (FtpWebRequest)FtpWebRequest.Create(ftpfullpath);
            ftp.Credentials = new NetworkCredential(_FTPUser, _FTPPass);

            ftp.KeepAlive = true;
            ftp.UseBinary = true;
            ftp.Timeout = 20000; // 20 sec
            ftp.Method = WebRequestMethods.Ftp.UploadFile;

            //FileStream fs = File.OpenRead(_FileName);
            //byte[] buffer = new byte[fs.Length];
            //fs.Read(buffer, 0, buffer.Length);
            //fs.Close();

            Stream ftpstream = ftp.GetRequestStream();
            ftpstream.Write(myData, 0, myData.Length);
            ftpstream.Close();

            retMsg = "SUCCESS";
        }
        catch (Exception ex)
        {
            Utilities.LogError(ex);
            retMsg = ex.Message.ToString();
        }

        return retMsg;
    }

    private int CalculateDuration(string departuredate, string returndate)
    {
        int retValue = 0;

        DateTime a = TA.TAUtilities.CheckCultureAndConvertToDateTime(departuredate);
        DateTime b = TA.TAUtilities.CheckCultureAndConvertToDateTime(returndate);
        long r = TA.TAUtilities.DateDiff(a, b);

        retValue = (int)r + 1;

        return retValue;
    }

    private int GetIsEurope(string countryName)
    {
        int retValue = 0;

        TATBCountryBLL clscountry = new TATBCountryBLL();
        DataTable dt = clscountry.GetDtTATBCountrys();

        for (int i = 0; i < dt.Rows.Count; i++)
        {
            if (dt.Rows[i]["CountryCode"].ToString() != "99")
            {
                if (string.Compare(countryName.ToLower().Trim(), dt.Rows[i]["CountryName"].ToString().ToLower().Trim()) == 0)
                {
                    retValue = string.IsNullOrEmpty(dt.Rows[i]["isEurope"].ToString()) ? 0 : Convert.ToInt32(dt.Rows[i]["isEurope"].ToString());
                }                                
            }
        }

        return retValue;
    }

    private string validateAddressFmtAS400(string input)
    {
        string output = "";
        string replace_input_comma = "";
        int index = 0;

        input = "%" + input;

        string formatAS400_1 = "  ";    // format wrong
        string formatAS400_2 = " - ";   // format wrong
        string formatAS400_3 = "\\";    // format wrong
        string formatAS400_4_1 = ",";   // format wrong
        string formatAS400_4_2 = ", ";  // for replace format true 


        index = input.IndexOf(formatAS400_1);
        if (index > 0)
        {
            return "parameter address cannot use 2 space";
        }


        index = input.IndexOf(formatAS400_2);
        if (index > 0)
        {
            return "parameter address cannot use space - space";
        }

        index = input.IndexOf(formatAS400_3);
        if (index > 0)
        {
            return "parameter address cannot use backspace";
        }

        replace_input_comma = input.Replace(formatAS400_4_2, "");
        index = replace_input_comma.IndexOf(formatAS400_4_1);
        if (index > 0)
        {
            return "you cann't use comma between text 'xxx,xxx' and can use 'xxx, xxx'.";
        }

        return output;
    }

    private string validateDateFormat(string strDate)
    {
        string str_output = "";
        try
        {
            string[] arrDate = strDate.Split('/');
            if (arrDate.Length != 3)
            {
                str_output = "Date Format incorrect";
            }
            else
            {
                int year = Convert.ToInt16(arrDate[2]);
                int month = Convert.ToInt16(arrDate[1]);
                int date = Convert.ToInt16(arrDate[0]);

                if (year > 2500)
                {
                    str_output = "Year of date incorrect";
                }

                if (month > 12)
                {
                    str_output = "Month of date incorrect";
                }

                if (date > 31)
                {
                    str_output = "Day of date incorrect";
                }

            }
        }
        catch ( Exception e) {
            str_output = "Date Format incorrect";
        }
        return str_output;
    }

        
}
