using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;
using PA.DAL;

namespace PA.BLL
{
    /// <summary>
    /// 
    /// </summary>
    /// <lastupdate>2012-08-24</lastupdate>
	public class PAPlanCoveragesBLL
	{
		private PAPlanCoveragesDAO _PAPlanCoveragesDAO;

		public PAPlanCoveragesDAO PAPlanCoveragesDAO
		{
			get { return _PAPlanCoveragesDAO; }
			set { _PAPlanCoveragesDAO = value; }
		}

		public PAPlanCoveragesBLL()
		{
			PAPlanCoveragesDAO = new PAPlanCoveragesDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
        public DataTable GetDtPAPlanCoverages(string PlanCode, string LANG)
        {
            try
            {
                return PAPlanCoveragesDAO.GetDtPAPlanCoverages(PlanCode, LANG);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetDtPAPlanCoverages(string PlanCode)
        {
            try
            {
                return PAPlanCoveragesDAO.GetDtPAPlanCoverages(PlanCode);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
	}
}
