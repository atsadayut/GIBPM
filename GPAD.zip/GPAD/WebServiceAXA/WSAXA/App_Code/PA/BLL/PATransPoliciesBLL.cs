using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;
using PA.DAL;

namespace PA.BLL
{
	public class PATransPoliciesBLL
	{
		private PATransPoliciesDAO _PATransPoliciesDAO;

		public PATransPoliciesDAO PATransPoliciesDAO
		{
			get { return _PATransPoliciesDAO; }
			set { _PATransPoliciesDAO = value; }
		}

		public PATransPoliciesBLL()
		{
			PATransPoliciesDAO = new PATransPoliciesDAO();
		}

        /// <summary>
        /// Get data from "spPA_getListPolicy"
        /// </summary>
        /// <param name="PolicyNo"></param>
        /// <param name="JobNo"></param>
        /// <param name="InsuredName"></param>
        /// <param name="PassportID"></param>
        /// <param name="TransDateFrom"></param>
        /// <param name="TransDateTo"></param>
        /// <param name="Lang"></param>
        /// <param name="GroupBrokerId"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-25</lastupdate>
        [System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
        public DataTable GetDtPAListPolicy(string PolicyNo, string JobNo, string InsuredName, string PassportID, string TransDateFrom, string TransDateTo, string Lang, string GroupBrokerId)
        {
            try
            {
                return PATransPoliciesDAO.GetDtPAListPolicy(PolicyNo, JobNo, InsuredName, PassportID, TransDateFrom, TransDateTo, Lang, GroupBrokerId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        
        }

        /// <summary>
        /// Set data by "spPA_setTransPolicy"
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="PackageID"></param>
        /// <param name="PlanCode"></param>
        /// <param name="InceptionDate"></param>
        /// <param name="ExpiryDate"></param>
        /// <param name="AgentCode"></param>
        /// <param name="StaffCode"></param>
        /// <param name="OccupatnClass"></param>
        /// <param name="OccupatnDestination"></param>
        /// <param name="NoOfChildren"></param>
        /// <param name="GrossPremium"></param>
        /// <param name="Stamp"></param>
        /// <param name="SBT"></param>
        /// <param name="TotalPremium"></param>
        /// <param name="isLongName"></param>
        /// <param name="GroupBrokerID"></param>
        /// <param name="User"></param>
        /// <param name="Lang"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-25</lastupdate>
        [System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
        public int SetPATransPolicy(string JobNo,string PackageID, string PlanCode, string InceptionDate, string ExpiryDate, string AgentCode, string StaffCode, string OccupatnClass, string OccupatnDestination, Nullable<int> NoOfChildren, Nullable<int> GrossPremium, Nullable<int> Stamp, Nullable<int> SBT, Nullable<int> TotalPremium, Nullable<SByte> isLongName, string GroupBrokerID, string User, string Lang)
        {
            try
            {
                return PATransPoliciesDAO.SetPATransPolicy(JobNo, PackageID, PlanCode, InceptionDate, ExpiryDate, AgentCode, StaffCode, OccupatnClass, OccupatnDestination, NoOfChildren, GrossPremium, Stamp, SBT, TotalPremium, isLongName, GroupBrokerID, User, Lang);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
	
        /// <summary>
        /// Set data by "spPA_setTransPolicy" with transaction
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="PackageID"></param>
        /// <param name="PlanCode"></param>
        /// <param name="InceptionDate"></param>
        /// <param name="ExpiryDate"></param>
        /// <param name="AgentCode"></param>
        /// <param name="StaffCode"></param>
        /// <param name="OccupatnClass"></param>
        /// <param name="OccupatnDestination"></param>
        /// <param name="NoOfChildren"></param>
        /// <param name="GrossPremium"></param>
        /// <param name="Stamp"></param>
        /// <param name="SBT"></param>
        /// <param name="TotalPremium"></param>
        /// <param name="isLongName"></param>
        /// <param name="GroupBrokerID"></param>
        /// <param name="User"></param>
        /// <param name="Lang"></param>
        /// <param name="dbTransaction"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-25</lastupdate>
        [System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
        public int SetPATransPolicy(string JobNo,string PackageID, string PlanCode, string InceptionDate, string ExpiryDate, string AgentCode, string StaffCode, string OccupatnClass, string OccupatnDestination, Nullable<int> NoOfChildren, Nullable<int> GrossPremium, Nullable<int> Stamp, Nullable<int> SBT, Nullable<int> TotalPremium, Nullable<SByte> isLongName, string GroupBrokerID, string User, string Lang,DbTransaction dbTransaction)
        {
            try
            {
                return PATransPoliciesDAO.SetPATransPolicy(JobNo, PackageID, PlanCode, InceptionDate, ExpiryDate, AgentCode, StaffCode, OccupatnClass, OccupatnDestination, NoOfChildren, GrossPremium, Stamp, SBT, TotalPremium, isLongName, GroupBrokerID, User, Lang, dbTransaction);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        // modify 2012/11/01 -YMD
        [System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
        public int SetPAAppxTransPrintRenew(string PolicyNo, string AgenCode, string GroupBrokerId, string CreatedUser,out string JobNo)
        {
            try
            {
                return PATransPoliciesDAO.SetPAAppxTransPrintRenew(PolicyNo, AgenCode, GroupBrokerId, CreatedUser,out JobNo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //modify 2012/11/13
        [System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
        public int SetTransPrintRenewal(string JobNo, int InsuredID, string InsuredName, string InsuredAge, string PlanCode, string NetPremium)
        {
            try
            {
                return PATransPoliciesDAO.SetTransPrintRenewal(JobNo, InsuredID, InsuredName, InsuredAge, PlanCode, NetPremium);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
        public int SetTransPrintRenewalBenefic(string JobNo, int InsuredID, int BeneficID, string Beneficiary)
        {
            try
            {
                return PATransPoliciesDAO.SetTransPrintRenewalBenefic(JobNo, InsuredID, BeneficID, Beneficiary);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string spPAB2C_SetPolicyNo()
        {
            try
            {
                return PATransPoliciesDAO.spPAB2C_SetPolicyNo();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string spPAB2C_SetPolicyNo(string JobNo)
        {
            try
            {
                return PATransPoliciesDAO.spPAB2C_SetPolicyNo(JobNo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int SetPATransTaxInvoince(string PolicyNo, string JobNo, string UserID, DbTransaction dbTransaction)
        {
            try
            {
                return PATransPoliciesDAO.SetPATransTaxInvoince( PolicyNo,  JobNo,  UserID,  dbTransaction);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int SetPATransPrint(string PolicyNo, string JobNo, string AgentCode, string GroupBrokerId, string CreatedUser, DbTransaction dbTransaction)
        {
            try
            {
                return PATransPoliciesDAO.SetPATransPrint( PolicyNo,  JobNo,  AgentCode,  GroupBrokerId,  CreatedUser,  dbTransaction);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int SetPATransTaxInvoince(string PolicyNo, string JobNo, string UserID)
        {
            try
            {
                return PATransPoliciesDAO.SetPATransTaxInvoince(PolicyNo, JobNo, UserID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int SetPATransPrint(string PolicyNo, string JobNo, string AgentCode, string GroupBrokerId, string CreatedUser)
        {
            try
            {
                return PATransPoliciesDAO.SetPATransPrint(PolicyNo, JobNo, AgentCode, GroupBrokerId, CreatedUser);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        public DataTable GetPAPrintListReportName(string PolicyNo)
        {
            try
            {
                return PATransPoliciesDAO.GetPAPrintListReportName(PolicyNo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetPATransPolicyByReturnINV(string RefCode)
        {
            try
            {
                return PATransPoliciesDAO.GetPATransPolicyByReturnINV(RefCode);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
