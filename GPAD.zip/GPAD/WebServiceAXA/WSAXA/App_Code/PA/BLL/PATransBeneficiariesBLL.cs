using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;
using PA.DAL;

namespace PA.BLL
{
    /// <summary>
    /// 
    /// </summary>
    /// <lastupdate>2012-08-25</lastupdate>
	public class PATransBeneficiariesBLL
	{
		private PATransBeneficiariesDAO _PATransBeneficiariesDAO;

		public PATransBeneficiariesDAO PATransBeneficiariesDAO
		{
			get { return _PATransBeneficiariesDAO; }
			set { _PATransBeneficiariesDAO = value; }
		}

		public PATransBeneficiariesBLL()
		{
			PATransBeneficiariesDAO = new PATransBeneficiariesDAO();
		}
		

        /// <summary>
        /// Set data by "spPA_SetTransBeneficiary"
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="InsuredID"></param>
        /// <param name="BeneficiaryID"></param>
        /// <param name="BeneficiaryTitle"></param>
        /// <param name="BeneficiaryName"></param>
        /// <param name="BeneficiarySurName"></param>
        /// <param name="BeneficiaryRelation"></param>
        /// <param name="BeneficiaryRatio"></param>
        /// <param name="BeneficiaryTel"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-26</lastupdate>
        public int SetPATransBeneficiary(string JobNo, int InsuredID, int BeneficiaryID, string BeneficiaryTitle, string BeneficiaryName, string BeneficiarySurName, string BeneficiaryRelation, string BeneficiaryRatio, string BeneficiaryTel)
        {
            try
            {
                return PATransBeneficiariesDAO.SetPATransBeneficiary(JobNo, InsuredID, BeneficiaryID, BeneficiaryTitle, BeneficiaryName, BeneficiarySurName, BeneficiaryRelation, BeneficiaryRatio, BeneficiaryTel);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        
        /// <summary>
        /// Set data by "spPA_SetTransBeneficiary" with transaction
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="InsuredID"></param>
        /// <param name="BeneficiaryID"></param>
        /// <param name="BeneficiaryTitle"></param>
        /// <param name="BeneficiaryName"></param>
        /// <param name="BeneficiarySurName"></param>
        /// <param name="BeneficiaryRelation"></param>
        /// <param name="BeneficiaryRatio"></param>
        /// <param name="BeneficiaryTel"></param>
        /// <param name="dbTransaction"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-26</lastupdate>
        public int SetPATransBeneficiary(string JobNo, int InsuredID, int BeneficiaryID, string BeneficiaryTitle, string BeneficiaryName, string BeneficiarySurName, string BeneficiaryRelation, string BeneficiaryRatio, string BeneficiaryTel, DbTransaction dbTransaction)
        {
            try
            {
                return PATransBeneficiariesDAO.SetPATransBeneficiary(JobNo, InsuredID, BeneficiaryID, BeneficiaryTitle, BeneficiaryName, BeneficiarySurName, BeneficiaryRelation, BeneficiaryRatio, BeneficiaryTel, dbTransaction);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
	}
}
