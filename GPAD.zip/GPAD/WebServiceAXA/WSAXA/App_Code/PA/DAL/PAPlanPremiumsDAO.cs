using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;

namespace PA.DAL
{
    /// <summary>
    /// 
    /// </summary>
    /// <lastupdate>2012-08-24</lastupdate>
	public class PAPlanPremiumsDAO
	{
		public PAPlanPremiumsDAO()
		{
            //DbProviderHelper dbHelper = new DbProviderHelper();
            DbProviderHelper.GetConnection();
		}

        /// <summary>
        /// GET
        /// </summary>
        /// <param name="PlanCode"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-24</lastupdate>
        public DataTable GetDtPAPlanPremiums(string PlanCode, string OccupationClass)
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();
                // get a configured & create DbCommand object
                DbCommand comm = DbProviderHelper.CreateCommand("spPA_getPlanPremium", CommandType.StoredProcedure);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@PlanCode", DbType.String, PlanCode));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@OccupationClass", DbType.String, OccupationClass));
        
                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return DbProviderHelper.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

	}
}
