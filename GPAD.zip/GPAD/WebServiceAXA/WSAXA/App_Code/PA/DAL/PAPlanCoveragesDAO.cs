using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;

namespace PA.DAL
{
    /// <summary>
    /// 
    /// </summary>
    /// <lastupdate>2012-08-24</lastupdate>
	public class PAPlanCoveragesDAO
	{
		public PAPlanCoveragesDAO()
		{
            //DbProviderHelper dbHelper = new DbProviderHelper();
            DbProviderHelper.GetConnection();
		}
	
        /// <summary>
        /// GET
        /// </summary>
        /// <param name="PlanCode"></param>
        /// <param name="LANG"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-24</lastupdate>
        public DataTable GetDtPAPlanCoverages(string PlanCode, string LANG)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();

                DbCommand comm = DbProviderHelper.CreateCommand("spPA_getPlanCoverage", CommandType.StoredProcedure);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@PlanCode", DbType.String, PlanCode));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@LANG", DbType.String, LANG));
                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return DbProviderHelper.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetDtPAPlanCoverages(string PlanCode)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();

                DbCommand comm = DbProviderHelper.CreateCommand("spPAB2C_getPlanCoverage", CommandType.StoredProcedure);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@PlanCode", DbType.String, PlanCode));
                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return DbProviderHelper.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
	}
}
