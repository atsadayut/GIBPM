using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;

namespace PA.DAL
{
    /// <summary>
    /// 
    /// </summary>
    /// <lastupdate>2012-08-25</lastupdate>
	public class PATransPolicyHoldersDAO
	{
		public PATransPolicyHoldersDAO()
		{
            //DbProviderHelper dbHelper = new DbProviderHelper();
            DbProviderHelper.GetConnection();
		}
		public List<PATransPolicyHolders> GetPATransPolicyHolderss()
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<PATransPolicyHolders> lstPATransPolicyHolderss = new List<PATransPolicyHolders>();
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("", CommandType.StoredProcedure);
                oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					PATransPolicyHolders oPATransPolicyHolders = new PATransPolicyHolders();
					oPATransPolicyHolders.JobNo = Convert.ToString(oDbDataReader["JobNo"]);

					if(oDbDataReader["ClientCode"] != DBNull.Value)
						oPATransPolicyHolders.ClientCode = Convert.ToString(oDbDataReader["ClientCode"]);

					if(oDbDataReader["ClientType"] != DBNull.Value)
						oPATransPolicyHolders.ClientType = Convert.ToString(oDbDataReader["ClientType"]);

					if(oDbDataReader["ClientTitle"] != DBNull.Value)
						oPATransPolicyHolders.ClientTitle = Convert.ToString(oDbDataReader["ClientTitle"]);

					if(oDbDataReader["ClientName"] != DBNull.Value)
						oPATransPolicyHolders.ClientName = Convert.ToString(oDbDataReader["ClientName"]);

					if(oDbDataReader["ClientSurName"] != DBNull.Value)
						oPATransPolicyHolders.ClientSurName = Convert.ToString(oDbDataReader["ClientSurName"]);

					if(oDbDataReader["AddressNo"] != DBNull.Value)
						oPATransPolicyHolders.AddressNo = Convert.ToString(oDbDataReader["AddressNo"]);

					if(oDbDataReader["Building"] != DBNull.Value)
						oPATransPolicyHolders.Building = Convert.ToString(oDbDataReader["Building"]);

					if(oDbDataReader["Soi"] != DBNull.Value)
						oPATransPolicyHolders.Soi = Convert.ToString(oDbDataReader["Soi"]);

					if(oDbDataReader["Road"] != DBNull.Value)
						oPATransPolicyHolders.Road = Convert.ToString(oDbDataReader["Road"]);

					if(oDbDataReader["Tumbol"] != DBNull.Value)
						oPATransPolicyHolders.Tumbol = Convert.ToString(oDbDataReader["Tumbol"]);

					if(oDbDataReader["Amphur"] != DBNull.Value)
						oPATransPolicyHolders.Amphur = Convert.ToString(oDbDataReader["Amphur"]);

					if(oDbDataReader["Province"] != DBNull.Value)
						oPATransPolicyHolders.Province = Convert.ToString(oDbDataReader["Province"]);

					if(oDbDataReader["PostCode"] != DBNull.Value)
						oPATransPolicyHolders.PostCode = Convert.ToString(oDbDataReader["PostCode"]);

					if(oDbDataReader["CountryCode"] != DBNull.Value)
						oPATransPolicyHolders.CountryCode = Convert.ToString(oDbDataReader["CountryCode"]);

					if(oDbDataReader["Birthday"] != DBNull.Value)
						oPATransPolicyHolders.Birthday = Convert.ToString(oDbDataReader["Birthday"]);

					if(oDbDataReader["ClientGender"] != DBNull.Value)
						oPATransPolicyHolders.ClientGender = Convert.ToString(oDbDataReader["ClientGender"]);

					if(oDbDataReader["ClientStatus"] != DBNull.Value)
						oPATransPolicyHolders.ClientStatus = Convert.ToString(oDbDataReader["ClientStatus"]);

					if(oDbDataReader["PassportID"] != DBNull.Value)
						oPATransPolicyHolders.PassportID = Convert.ToString(oDbDataReader["PassportID"]);

					if(oDbDataReader["IDCard"] != DBNull.Value)
						oPATransPolicyHolders.IDCard = Convert.ToString(oDbDataReader["IDCard"]);

					if(oDbDataReader["TaxID"] != DBNull.Value)
						oPATransPolicyHolders.TaxID = Convert.ToString(oDbDataReader["TaxID"]);

					if(oDbDataReader["Tel"] != DBNull.Value)
						oPATransPolicyHolders.Tel = Convert.ToString(oDbDataReader["Tel"]);

					if(oDbDataReader["Email"] != DBNull.Value)
						oPATransPolicyHolders.Email = Convert.ToString(oDbDataReader["Email"]);

					if(oDbDataReader["Language"] != DBNull.Value)
						oPATransPolicyHolders.Language = Convert.ToString(oDbDataReader["Language"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oPATransPolicyHolders.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);

					if(oDbDataReader["Message"] != DBNull.Value)
						oPATransPolicyHolders.Message = Convert.ToString(oDbDataReader["Message"]);
					lstPATransPolicyHolderss.Add(oPATransPolicyHolders);
				}
				oDbDataReader.Close();
				return lstPATransPolicyHolderss;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}
		public PATransPolicyHolders GetPATransPolicyHolders(string JobNo)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				PATransPolicyHolders oPATransPolicyHolders = new PATransPolicyHolders();
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("", CommandType.StoredProcedure);
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oPATransPolicyHolders.JobNo = Convert.ToString(oDbDataReader["JobNo"]);

					if(oDbDataReader["ClientCode"] != DBNull.Value)
						oPATransPolicyHolders.ClientCode = Convert.ToString(oDbDataReader["ClientCode"]);

					if(oDbDataReader["ClientType"] != DBNull.Value)
						oPATransPolicyHolders.ClientType = Convert.ToString(oDbDataReader["ClientType"]);

					if(oDbDataReader["ClientTitle"] != DBNull.Value)
						oPATransPolicyHolders.ClientTitle = Convert.ToString(oDbDataReader["ClientTitle"]);

					if(oDbDataReader["ClientName"] != DBNull.Value)
						oPATransPolicyHolders.ClientName = Convert.ToString(oDbDataReader["ClientName"]);

					if(oDbDataReader["ClientSurName"] != DBNull.Value)
						oPATransPolicyHolders.ClientSurName = Convert.ToString(oDbDataReader["ClientSurName"]);

					if(oDbDataReader["AddressNo"] != DBNull.Value)
						oPATransPolicyHolders.AddressNo = Convert.ToString(oDbDataReader["AddressNo"]);

					if(oDbDataReader["Building"] != DBNull.Value)
						oPATransPolicyHolders.Building = Convert.ToString(oDbDataReader["Building"]);

					if(oDbDataReader["Soi"] != DBNull.Value)
						oPATransPolicyHolders.Soi = Convert.ToString(oDbDataReader["Soi"]);

					if(oDbDataReader["Road"] != DBNull.Value)
						oPATransPolicyHolders.Road = Convert.ToString(oDbDataReader["Road"]);

					if(oDbDataReader["Tumbol"] != DBNull.Value)
						oPATransPolicyHolders.Tumbol = Convert.ToString(oDbDataReader["Tumbol"]);

					if(oDbDataReader["Amphur"] != DBNull.Value)
						oPATransPolicyHolders.Amphur = Convert.ToString(oDbDataReader["Amphur"]);

					if(oDbDataReader["Province"] != DBNull.Value)
						oPATransPolicyHolders.Province = Convert.ToString(oDbDataReader["Province"]);

					if(oDbDataReader["PostCode"] != DBNull.Value)
						oPATransPolicyHolders.PostCode = Convert.ToString(oDbDataReader["PostCode"]);

					if(oDbDataReader["CountryCode"] != DBNull.Value)
						oPATransPolicyHolders.CountryCode = Convert.ToString(oDbDataReader["CountryCode"]);

					if(oDbDataReader["Birthday"] != DBNull.Value)
						oPATransPolicyHolders.Birthday = Convert.ToString(oDbDataReader["Birthday"]);

					if(oDbDataReader["ClientGender"] != DBNull.Value)
						oPATransPolicyHolders.ClientGender = Convert.ToString(oDbDataReader["ClientGender"]);

					if(oDbDataReader["ClientStatus"] != DBNull.Value)
						oPATransPolicyHolders.ClientStatus = Convert.ToString(oDbDataReader["ClientStatus"]);

					if(oDbDataReader["PassportID"] != DBNull.Value)
						oPATransPolicyHolders.PassportID = Convert.ToString(oDbDataReader["PassportID"]);

					if(oDbDataReader["IDCard"] != DBNull.Value)
						oPATransPolicyHolders.IDCard = Convert.ToString(oDbDataReader["IDCard"]);

					if(oDbDataReader["TaxID"] != DBNull.Value)
						oPATransPolicyHolders.TaxID = Convert.ToString(oDbDataReader["TaxID"]);

					if(oDbDataReader["Tel"] != DBNull.Value)
						oPATransPolicyHolders.Tel = Convert.ToString(oDbDataReader["Tel"]);

					if(oDbDataReader["Email"] != DBNull.Value)
						oPATransPolicyHolders.Email = Convert.ToString(oDbDataReader["Email"]);

					if(oDbDataReader["Language"] != DBNull.Value)
						oPATransPolicyHolders.Language = Convert.ToString(oDbDataReader["Language"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oPATransPolicyHolders.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);

					if(oDbDataReader["Message"] != DBNull.Value)
						oPATransPolicyHolders.Message = Convert.ToString(oDbDataReader["Message"]);
				}
				oDbDataReader.Close();
				return oPATransPolicyHolders;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}
		public int AddPATransPolicyHolders(string JobNo,string ClientCode,string ClientType,string ClientTitle,string ClientName,string ClientSurName,string AddressNo,string Building,string Soi,string Road,string Tumbol,string Amphur,string Province,string PostCode,string CountryCode,string Birthday,string ClientGender,string ClientStatus,string PassportID,string IDCard,string TaxID,string Tel,string Email,string Language,Nullable<DateTime> CreateDate,string Message)
		{
			try
			{
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("", CommandType.StoredProcedure);
				if (ClientCode!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientCode", DbType.String, ClientCode));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientCode", DbType.String, DBNull.Value));
				if (ClientType!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientType", DbType.String, ClientType));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientType", DbType.String, DBNull.Value));
				if (ClientTitle!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientTitle", DbType.String, ClientTitle));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientTitle", DbType.String, DBNull.Value));
				if (ClientName!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientName", DbType.String, ClientName));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientName", DbType.String, DBNull.Value));
				if (ClientSurName!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSurName", DbType.String, ClientSurName));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSurName", DbType.String, DBNull.Value));
				if (AddressNo!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AddressNo", DbType.String, AddressNo));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AddressNo", DbType.String, DBNull.Value));
				if (Building!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Building", DbType.String, Building));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Building", DbType.String, DBNull.Value));
				if (Soi!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Soi", DbType.String, Soi));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Soi", DbType.String, DBNull.Value));
				if (Road!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Road", DbType.String, Road));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Road", DbType.String, DBNull.Value));
				if (Tumbol!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tumbol", DbType.String, Tumbol));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tumbol", DbType.String, DBNull.Value));
				if (Amphur!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Amphur", DbType.String, Amphur));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Amphur", DbType.String, DBNull.Value));
				if (Province!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Province", DbType.String, Province));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Province", DbType.String, DBNull.Value));
				if (PostCode!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PostCode", DbType.String, PostCode));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PostCode", DbType.String, DBNull.Value));
				if (CountryCode!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CountryCode", DbType.String, CountryCode));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CountryCode", DbType.String, DBNull.Value));
				if (Birthday!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Birthday", DbType.String, Birthday));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Birthday", DbType.String, DBNull.Value));
				if (ClientGender!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientGender", DbType.String, ClientGender));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientGender", DbType.String, DBNull.Value));
				if (ClientStatus!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientStatus", DbType.String, ClientStatus));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientStatus", DbType.String, DBNull.Value));
				if (PassportID!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PassportID", DbType.String, PassportID));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PassportID", DbType.String, DBNull.Value));
				if (IDCard!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@IDCard", DbType.String, IDCard));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@IDCard", DbType.String, DBNull.Value));
				if (TaxID!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TaxID", DbType.String, TaxID));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TaxID", DbType.String, DBNull.Value));
				if (Tel!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tel", DbType.String, Tel));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tel", DbType.String, DBNull.Value));
				if (Email!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Email", DbType.String, Email));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Email", DbType.String, DBNull.Value));
				if (Language!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Language", DbType.String, Language));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Language", DbType.String, DBNull.Value));
				if (CreateDate.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreateDate", DbType.DateTime, CreateDate));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreateDate", DbType.DateTime, DBNull.Value));
				if (Message!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Message", DbType.String, Message));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Message", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public int UpdatePATransPolicyHolders(string JobNo,string ClientCode,string ClientType,string ClientTitle,string ClientName,string ClientSurName,string AddressNo,string Building,string Soi,string Road,string Tumbol,string Amphur,string Province,string PostCode,string CountryCode,string Birthday,string ClientGender,string ClientStatus,string PassportID,string IDCard,string TaxID,string Tel,string Email,string Language,Nullable<DateTime> CreateDate,string Message)
		{

			try
			{
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("", CommandType.StoredProcedure);
				if (ClientCode!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientCode", DbType.String, ClientCode));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientCode", DbType.String, DBNull.Value));
				if (ClientType!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientType", DbType.String, ClientType));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientType", DbType.String, DBNull.Value));
				if (ClientTitle!=null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientTitle", DbType.String, ClientTitle));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientTitle",DbType.String,DBNull.Value));
				if (ClientName!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientName",DbType.String,ClientName));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientName",DbType.String,DBNull.Value));
				if (ClientSurName!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSurName",DbType.String,ClientSurName));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSurName",DbType.String,DBNull.Value));
				if (AddressNo!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AddressNo",DbType.String,AddressNo));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AddressNo",DbType.String,DBNull.Value));
				if (Building!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Building",DbType.String,Building));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Building",DbType.String,DBNull.Value));
				if (Soi!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Soi",DbType.String,Soi));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Soi",DbType.String,DBNull.Value));
				if (Road!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Road",DbType.String,Road));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Road",DbType.String,DBNull.Value));
				if (Tumbol!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tumbol",DbType.String,Tumbol));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tumbol",DbType.String,DBNull.Value));
				if (Amphur!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Amphur",DbType.String,Amphur));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Amphur",DbType.String,DBNull.Value));
				if (Province!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Province",DbType.String,Province));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Province",DbType.String,DBNull.Value));
				if (PostCode!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PostCode",DbType.String,PostCode));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PostCode",DbType.String,DBNull.Value));
				if (CountryCode!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CountryCode",DbType.String,CountryCode));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CountryCode",DbType.String,DBNull.Value));
				if (Birthday!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Birthday",DbType.String,Birthday));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Birthday",DbType.String,DBNull.Value));
				if (ClientGender!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientGender",DbType.String,ClientGender));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientGender",DbType.String,DBNull.Value));
				if (ClientStatus!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientStatus",DbType.String,ClientStatus));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientStatus",DbType.String,DBNull.Value));
				if (PassportID!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PassportID",DbType.String,PassportID));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PassportID",DbType.String,DBNull.Value));
				if (IDCard!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@IDCard",DbType.String,IDCard));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@IDCard",DbType.String,DBNull.Value));
				if (TaxID!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TaxID",DbType.String,TaxID));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TaxID",DbType.String,DBNull.Value));
				if (Tel!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tel",DbType.String,Tel));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tel",DbType.String,DBNull.Value));
				if (Email!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Email",DbType.String,Email));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Email",DbType.String,DBNull.Value));
				if (Language!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Language",DbType.String,Language));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Language",DbType.String,DBNull.Value));
				if (CreateDate.HasValue)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreateDate",DbType.DateTime,CreateDate));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreateDate",DbType.DateTime,DBNull.Value));
				if (Message!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Message",DbType.String,Message));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Message",DbType.String,DBNull.Value));
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo",DbType.String,JobNo));
				return DbProviderHelper.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public int RemovePATransPolicyHolders(string JobNo)
		{

			try
			{
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("",CommandType.StoredProcedure);
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo",DbType.String,JobNo));
				return DbProviderHelper.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public List<PATransPolicyHolders> GetPATransPolicyHolderssOfPATransPolicies(string JobNo)
		{
            DbDataReader oDbDataReader = null;
            try
			{
                //DbProviderHelper dbHelper = new DbProviderHelper();
                List<PATransPolicyHolders> lstPATransPolicyHolderss = new List<PATransPolicyHolders>();
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("",CommandType.StoredProcedure);
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo",DbType.String,JobNo));
				oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					PATransPolicyHolders oPATransPolicyHolders = new PATransPolicyHolders();
					oPATransPolicyHolders.JobNo = Convert.ToString(oDbDataReader["JobNo"]);

					if(oDbDataReader["ClientCode"] != DBNull.Value)
						oPATransPolicyHolders.ClientCode = Convert.ToString(oDbDataReader["ClientCode"]);

					if(oDbDataReader["ClientType"] != DBNull.Value)
						oPATransPolicyHolders.ClientType = Convert.ToString(oDbDataReader["ClientType"]);

					if(oDbDataReader["ClientTitle"] != DBNull.Value)
						oPATransPolicyHolders.ClientTitle = Convert.ToString(oDbDataReader["ClientTitle"]);

					if(oDbDataReader["ClientName"] != DBNull.Value)
						oPATransPolicyHolders.ClientName = Convert.ToString(oDbDataReader["ClientName"]);

					if(oDbDataReader["ClientSurName"] != DBNull.Value)
						oPATransPolicyHolders.ClientSurName = Convert.ToString(oDbDataReader["ClientSurName"]);

					if(oDbDataReader["AddressNo"] != DBNull.Value)
						oPATransPolicyHolders.AddressNo = Convert.ToString(oDbDataReader["AddressNo"]);

					if(oDbDataReader["Building"] != DBNull.Value)
						oPATransPolicyHolders.Building = Convert.ToString(oDbDataReader["Building"]);

					if(oDbDataReader["Soi"] != DBNull.Value)
						oPATransPolicyHolders.Soi = Convert.ToString(oDbDataReader["Soi"]);

					if(oDbDataReader["Road"] != DBNull.Value)
						oPATransPolicyHolders.Road = Convert.ToString(oDbDataReader["Road"]);

					if(oDbDataReader["Tumbol"] != DBNull.Value)
						oPATransPolicyHolders.Tumbol = Convert.ToString(oDbDataReader["Tumbol"]);

					if(oDbDataReader["Amphur"] != DBNull.Value)
						oPATransPolicyHolders.Amphur = Convert.ToString(oDbDataReader["Amphur"]);

					if(oDbDataReader["Province"] != DBNull.Value)
						oPATransPolicyHolders.Province = Convert.ToString(oDbDataReader["Province"]);

					if(oDbDataReader["PostCode"] != DBNull.Value)
						oPATransPolicyHolders.PostCode = Convert.ToString(oDbDataReader["PostCode"]);

					if(oDbDataReader["CountryCode"] != DBNull.Value)
						oPATransPolicyHolders.CountryCode = Convert.ToString(oDbDataReader["CountryCode"]);

					if(oDbDataReader["Birthday"] != DBNull.Value)
						oPATransPolicyHolders.Birthday = Convert.ToString(oDbDataReader["Birthday"]);

					if(oDbDataReader["ClientGender"] != DBNull.Value)
						oPATransPolicyHolders.ClientGender = Convert.ToString(oDbDataReader["ClientGender"]);

					if(oDbDataReader["ClientStatus"] != DBNull.Value)
						oPATransPolicyHolders.ClientStatus = Convert.ToString(oDbDataReader["ClientStatus"]);

					if(oDbDataReader["PassportID"] != DBNull.Value)
						oPATransPolicyHolders.PassportID = Convert.ToString(oDbDataReader["PassportID"]);

					if(oDbDataReader["IDCard"] != DBNull.Value)
						oPATransPolicyHolders.IDCard = Convert.ToString(oDbDataReader["IDCard"]);

					if(oDbDataReader["TaxID"] != DBNull.Value)
						oPATransPolicyHolders.TaxID = Convert.ToString(oDbDataReader["TaxID"]);

					if(oDbDataReader["Tel"] != DBNull.Value)
						oPATransPolicyHolders.Tel = Convert.ToString(oDbDataReader["Tel"]);

					if(oDbDataReader["Email"] != DBNull.Value)
						oPATransPolicyHolders.Email = Convert.ToString(oDbDataReader["Email"]);

					if(oDbDataReader["Language"] != DBNull.Value)
						oPATransPolicyHolders.Language = Convert.ToString(oDbDataReader["Language"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oPATransPolicyHolders.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);

					if(oDbDataReader["Message"] != DBNull.Value)
						oPATransPolicyHolders.Message = Convert.ToString(oDbDataReader["Message"]);
					lstPATransPolicyHolderss.Add(oPATransPolicyHolders);
				}
				oDbDataReader.Close();
				return lstPATransPolicyHolderss;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}
		public PATransPolicies GetPATransPoliciesOfPATransPolicyHolders(string JobNo)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				PATransPolicies oPATransPolicies = new PATransPolicies();
                //DbProviderHelper dbHelper = new DbProviderHelper();
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("",CommandType.StoredProcedure);
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo",DbType.String,JobNo));
				oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oPATransPolicies.JobNo = Convert.ToString(oDbDataReader["JobNo"]);

					if(oDbDataReader["PolicyNo"] != DBNull.Value)
						oPATransPolicies.PolicyNo = Convert.ToString(oDbDataReader["PolicyNo"]);

					if(oDbDataReader["PackageID"] != DBNull.Value)
						oPATransPolicies.PackageID = Convert.ToString(oDbDataReader["PackageID"]);

					if(oDbDataReader["PlanCode"] != DBNull.Value)
						oPATransPolicies.PlanCode = Convert.ToString(oDbDataReader["PlanCode"]);

					if(oDbDataReader["InceptionDate"] != DBNull.Value)
						oPATransPolicies.InceptionDate = Convert.ToString(oDbDataReader["InceptionDate"]);

					if(oDbDataReader["ExpiryDate"] != DBNull.Value)
						oPATransPolicies.ExpiryDate = Convert.ToString(oDbDataReader["ExpiryDate"]);

					if(oDbDataReader["ContractType"] != DBNull.Value)
						oPATransPolicies.ContractType = Convert.ToString(oDbDataReader["ContractType"]);

					if(oDbDataReader["RiskType"] != DBNull.Value)
						oPATransPolicies.RiskType = Convert.ToString(oDbDataReader["RiskType"]);

					if(oDbDataReader["PremiumClass"] != DBNull.Value)
						oPATransPolicies.PremiumClass = Convert.ToString(oDbDataReader["PremiumClass"]);

					if(oDbDataReader["AgentCode"] != DBNull.Value)
						oPATransPolicies.AgentCode = Convert.ToString(oDbDataReader["AgentCode"]);

					if(oDbDataReader["StaffCode"] != DBNull.Value)
						oPATransPolicies.StaffCode = Convert.ToString(oDbDataReader["StaffCode"]);

					if(oDbDataReader["OccupatnClass"] != DBNull.Value)
						oPATransPolicies.OccupatnClass = Convert.ToString(oDbDataReader["OccupatnClass"]);

					if(oDbDataReader["OccupatnDestination"] != DBNull.Value)
						oPATransPolicies.OccupatnDestination = Convert.ToString(oDbDataReader["OccupatnDestination"]);

					if(oDbDataReader["NoOfChildren"] != DBNull.Value)
						oPATransPolicies.NoOfChildren = Convert.ToInt32(oDbDataReader["NoOfChildren"]);

					if(oDbDataReader["GrossPremium"] != DBNull.Value)
						oPATransPolicies.GrossPremium = Convert.ToInt32(oDbDataReader["GrossPremium"]);

					if(oDbDataReader["Stamp"] != DBNull.Value)
						oPATransPolicies.Stamp = Convert.ToInt32(oDbDataReader["Stamp"]);

					if(oDbDataReader["SBT"] != DBNull.Value)
						oPATransPolicies.SBT = Convert.ToInt32(oDbDataReader["SBT"]);

					if(oDbDataReader["TotalPremium"] != DBNull.Value)
						oPATransPolicies.TotalPremium = Convert.ToInt32(oDbDataReader["TotalPremium"]);

					if(oDbDataReader["PreprintedClauses1"] != DBNull.Value)
						oPATransPolicies.PreprintedClauses1 = Convert.ToString(oDbDataReader["PreprintedClauses1"]);

					if(oDbDataReader["PreprintedClauses2"] != DBNull.Value)
						oPATransPolicies.PreprintedClauses2 = Convert.ToString(oDbDataReader["PreprintedClauses2"]);

					if(oDbDataReader["PreprintedClauses3"] != DBNull.Value)
						oPATransPolicies.PreprintedClauses3 = Convert.ToString(oDbDataReader["PreprintedClauses3"]);

					if(oDbDataReader["ClauseCodes1"] != DBNull.Value)
						oPATransPolicies.ClauseCodes1 = Convert.ToString(oDbDataReader["ClauseCodes1"]);

					if(oDbDataReader["ClauseCodes2"] != DBNull.Value)
						oPATransPolicies.ClauseCodes2 = Convert.ToString(oDbDataReader["ClauseCodes2"]);

					if(oDbDataReader["ClauseCodes3"] != DBNull.Value)
						oPATransPolicies.ClauseCodes3 = Convert.ToString(oDbDataReader["ClauseCodes3"]);

					if(oDbDataReader["isLongName"] != DBNull.Value)
						oPATransPolicies.isLongName = Convert.ToSByte(oDbDataReader["isLongName"]);

					if(oDbDataReader["GroupBrokerID"] != DBNull.Value)
						oPATransPolicies.GroupBrokerID = Convert.ToString(oDbDataReader["GroupBrokerID"]);

					if(oDbDataReader["CreatedDate"] != DBNull.Value)
						oPATransPolicies.CreatedDate = Convert.ToDateTime(oDbDataReader["CreatedDate"]);

					if(oDbDataReader["CreatedUser"] != DBNull.Value)
						oPATransPolicies.CreatedUser = Convert.ToString(oDbDataReader["CreatedUser"]);

					if(oDbDataReader["ModifiedDate"] != DBNull.Value)
						oPATransPolicies.ModifiedDate = Convert.ToDateTime(oDbDataReader["ModifiedDate"]);

					if(oDbDataReader["ModifiedUser"] != DBNull.Value)
						oPATransPolicies.ModifiedUser = Convert.ToString(oDbDataReader["ModifiedUser"]);

					if(oDbDataReader["Message"] != DBNull.Value)
						oPATransPolicies.Message = Convert.ToString(oDbDataReader["Message"]);
				}
				oDbDataReader.Close();
				return oPATransPolicies;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}

        /// <summary>
        /// SET
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="InsurerID"></param>
        /// <param name="ClientType"></param>
        /// <param name="ClientTitle"></param>
        /// <param name="ClientName"></param>
        /// <param name="ClientSurName"></param>
        /// <param name="AddressNo"></param>
        /// <param name="Building"></param>
        /// <param name="Soi"></param>
        /// <param name="Road"></param>
        /// <param name="Province"></param>
        /// <param name="Amphur"></param>
        /// <param name="Tumbol"></param>
        /// <param name="PostCode"></param>
        /// <param name="Birthday"></param>
        /// <param name="Gender"></param>
        /// <param name="Status"></param>
        /// <param name="Nationality"></param>
        /// <param name="IDCard"></param>
        /// <param name="Tel"></param>
        /// <param name="Email"></param>
        /// <param name="Lang"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-25</lastupdate>
        public int SetPATransPolicyHolders(string JobNo, int InsurerID, string ClientType, string ClientTitle, string ClientName, string ClientSurName, string AddressNo, string Building, string Soi, string Road, string Province, string Amphur, string Tumbol, string PostCode, string Birthday, string Gender, string Status, string Nationality, string IDCard, string Tel, string Email, string Lang, string BranchNo)
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spPA_SetTransPolicyHolder", CommandType.StoredProcedure);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JOBNO", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JOBNO", DbType.String, DBNull.Value));
                if (InsurerID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@InsurerID", DbType.Int32, InsurerID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@InsurerID", DbType.Int32, DBNull.Value));
                if (ClientType != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientType", DbType.String, ClientType));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientType", DbType.String, DBNull.Value));
                if (ClientTitle != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientTitle", DbType.String, ClientTitle));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientTitle", DbType.String, DBNull.Value));
                if (ClientName != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientName", DbType.String, ClientName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientName", DbType.String, DBNull.Value));
                if (ClientSurName != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSurName", DbType.String, ClientSurName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSurName", DbType.String, DBNull.Value));
                if (AddressNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AddressNo", DbType.String, AddressNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AddressNo", DbType.String, DBNull.Value));
                if (Building != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Building", DbType.String, Building));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Building", DbType.String, DBNull.Value));
                if (Soi != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Soi", DbType.String, Soi));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Soi", DbType.String, DBNull.Value));
                if (Road != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Road", DbType.String, Road));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Road", DbType.String, DBNull.Value));
                if (Tumbol != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tumbol", DbType.String, Tumbol));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tumbol", DbType.String, DBNull.Value));
                if (Amphur != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Amphur", DbType.String, Amphur));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Amphur", DbType.String, DBNull.Value));
                if (Province != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Province", DbType.String, Province));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Province", DbType.String, DBNull.Value));
                if (PostCode != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PostCode", DbType.String, PostCode));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PostCode", DbType.String, DBNull.Value));
                if (Birthday != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Birthday", DbType.String, Birthday));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Birthday", DbType.String, DBNull.Value));
                if (Gender != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Gender", DbType.String, Gender));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Gender", DbType.String, DBNull.Value));
                if (Status != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Status", DbType.String, Status));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Status", DbType.String, DBNull.Value));
                if (Nationality != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Nationality", DbType.String, Nationality));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Nationality", DbType.String, DBNull.Value));
                if (IDCard != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@IdCard", DbType.String, IDCard));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@IdCard", DbType.String, DBNull.Value));
                if (Tel != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tel", DbType.String, Tel));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tel", DbType.String, DBNull.Value));
                if (Email != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Email", DbType.String, Email));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Email", DbType.String, DBNull.Value));
                if (Lang != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Lang", DbType.String, Lang));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Lang", DbType.String, DBNull.Value));
                if (BranchNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BranchNo", DbType.String, BranchNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BranchNo", DbType.String, DBNull.Value));
                
                
                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// SET WITH TRANSACTION
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="InsurerID"></param>
        /// <param name="ClientType"></param>
        /// <param name="ClientTitle"></param>
        /// <param name="ClientName"></param>
        /// <param name="ClientSurName"></param>
        /// <param name="AddressNo"></param>
        /// <param name="Building"></param>
        /// <param name="Soi"></param>
        /// <param name="Road"></param>
        /// <param name="Province"></param>
        /// <param name="Amphur"></param>
        /// <param name="Tumbol"></param>
        /// <param name="PostCode"></param>
        /// <param name="Birthday"></param>
        /// <param name="Gender"></param>
        /// <param name="Status"></param>
        /// <param name="Nationality"></param>
        /// <param name="IDCard"></param>
        /// <param name="Tel"></param>
        /// <param name="Email"></param>
        /// <param name="Lang"></param>
        /// <param name="dbTransaction"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-25</lastupdate>
        public int SetPATransPolicyHolders(string JobNo, int InsurerID, string ClientType, string ClientTitle, string ClientName, string ClientSurName, string AddressNo, string Building, string Soi, string Road, string Province, string Amphur, string Tumbol, string PostCode, string Birthday, string Gender, string Status, string Nationality, string IDCard, string Tel, string Email, string Lang, string BranchNo, DbTransaction dbTransaction)
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spPA_SetTransPolicyHolder", CommandType.StoredProcedure, dbTransaction);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JOBNO", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JOBNO", DbType.String, DBNull.Value));
                if (InsurerID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@InsurerID", DbType.Int32, InsurerID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@InsurerID", DbType.Int32, DBNull.Value));
                if (ClientType != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientType", DbType.String, ClientType));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientType", DbType.String, DBNull.Value));
                if (ClientTitle != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientTitle", DbType.String, ClientTitle));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientTitle", DbType.String, DBNull.Value));
                if (ClientName != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientName", DbType.String, ClientName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientName", DbType.String, DBNull.Value));
                if (ClientSurName != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSurName", DbType.String, ClientSurName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSurName", DbType.String, DBNull.Value));
                if (AddressNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AddressNo", DbType.String, AddressNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AddressNo", DbType.String, DBNull.Value));
                if (Building != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Building", DbType.String, Building));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Building", DbType.String, DBNull.Value));
                if (Soi != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Soi", DbType.String, Soi));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Soi", DbType.String, DBNull.Value));
                if (Road != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Road", DbType.String, Road));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Road", DbType.String, DBNull.Value));
                if (Tumbol != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tumbol", DbType.String, Tumbol));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tumbol", DbType.String, DBNull.Value));
                if (Amphur != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Amphur", DbType.String, Amphur));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Amphur", DbType.String, DBNull.Value));
                if (Province != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Province", DbType.String, Province));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Province", DbType.String, DBNull.Value));
                if (PostCode != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PostCode", DbType.String, PostCode));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PostCode", DbType.String, DBNull.Value));
                if (Birthday != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Birthday", DbType.String, Birthday));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Birthday", DbType.String, DBNull.Value));
                if (Gender != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Gender", DbType.String, Gender));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Gender", DbType.String, DBNull.Value));
                if (Status != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Status", DbType.String, Status));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Status", DbType.String, DBNull.Value));
                if (Nationality != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Nationality", DbType.String, Nationality));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Nationality", DbType.String, DBNull.Value));
                if (IDCard != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@IdCard", DbType.String, IDCard));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@IdCard", DbType.String, DBNull.Value));
                if (Tel != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tel", DbType.String, Tel));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tel", DbType.String, DBNull.Value));
                if (Email != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Email", DbType.String, Email));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Email", DbType.String, DBNull.Value));
                if (Lang != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Lang", DbType.String, Lang));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Lang", DbType.String, DBNull.Value));
                if (BranchNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BranchNo", DbType.String, BranchNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BranchNo", DbType.String, DBNull.Value));
                
                return DbProviderHelper.ExecuteNonQuery(oDbCommand,true);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

	}
}
