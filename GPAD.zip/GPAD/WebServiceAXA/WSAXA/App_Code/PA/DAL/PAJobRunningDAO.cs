using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;

namespace PA.DAL
{
	public class PAJobRunningDAO
	{
		public PAJobRunningDAO()
		{
            //DbProviderHelper dbHelper = new DbProviderHelper();
            DbProviderHelper.GetConnection();
		}

        /// <summary>
        /// GET/SET JOBNO
        /// </summary>
        /// <returns></returns>
        public string GetPAJobRunningNumber()
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();
                // get a configured & create DbCommand object
                DbCommand comm = DbProviderHelper.CreateCommand("spPA_SetJobNo", CommandType.StoredProcedure);

                // create parameter and direction
                DbParameter param = comm.CreateParameter();
                param.ParameterName = "@GetJobNo";
                param.DbType = DbType.String;
                param.Size = 20;
                param.Direction = ParameterDirection.Output;
                comm.Parameters.Add(param);

                //execute command
                int ret = DbProviderHelper.ExecuteNonQuery(comm);

                //return jobno
                return param.Value.ToString();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public string GetPAJobRunningNumber(DbTransaction dbTransaction)
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();
                // get a configured & create DbCommand object
                DbCommand comm = DbProviderHelper.CreateCommand("spPA_SetJobNo", CommandType.StoredProcedure, dbTransaction);

                // create parameter and direction
                DbParameter param = comm.CreateParameter();
                param.ParameterName = "@GetJobNo";
                param.DbType = DbType.String;
                param.Size = 20;
                param.Direction = ParameterDirection.Output;
                comm.Parameters.Add(param);

                //execute command
                int ret = DbProviderHelper.ExecuteNonQuery(comm);

                //return jobno
                return param.Value.ToString();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
	}
}
