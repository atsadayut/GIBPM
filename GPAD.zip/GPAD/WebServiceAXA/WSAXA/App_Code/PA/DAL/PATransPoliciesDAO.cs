using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;

namespace PA.DAL
{
    /// <summary>
    /// 
    /// </summary>
    /// <lastupdate>2012-08-25</lastupdate>
	public class PATransPoliciesDAO
	{
		public PATransPoliciesDAO()
		{
            //DbProviderHelper dbHelper = new DbProviderHelper();
            DbProviderHelper.GetConnection();
		}

        /// <summary>
        /// GET 
        /// </summary>
        /// <param name="PolicyNo"></param>
        /// <param name="JobNo"></param>
        /// <param name="InsuredName"></param>
        /// <param name="PassportID"></param>
        /// <param name="TransDateFrom"></param>
        /// <param name="TransDateTo"></param>
        /// <param name="Lang"></param>
        /// <param name="GroupBrokerId"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-24</lastupdate>
        public DataTable GetDtPAListPolicy(string PolicyNo, string JobNo, string InsuredName, string PassportID, string TransDateFrom, string TransDateTo, string Lang, string GroupBrokerId)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand comm = DbProviderHelper.CreateCommand("spPA_getListPolicy", CommandType.StoredProcedure);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, PolicyNo));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@InsuredName", DbType.String, InsuredName));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@PassportID", DbType.String, PassportID));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@TransDateFrom", DbType.String, TransDateFrom));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@TransDateTo", DbType.String, TransDateTo));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@Lang", DbType.String, Lang));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId", DbType.String, GroupBrokerId));

                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return DbProviderHelper.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// SET
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="PackageID"></param>
        /// <param name="PlanCode"></param>
        /// <param name="InceptionDate"></param>
        /// <param name="ExpiryDate"></param>
        /// <param name="AgentCode"></param>
        /// <param name="StaffCode"></param>
        /// <param name="OccupatnClass"></param>
        /// <param name="OccupatnDestination"></param>
        /// <param name="NoOfChildren"></param>
        /// <param name="GrossPremium"></param>
        /// <param name="Stamp"></param>
        /// <param name="SBT"></param>
        /// <param name="TotalPremium"></param>
        /// <param name="isLongName"></param>
        /// <param name="GroupBrokerID"></param>
        /// <param name="User"></param>
        /// <param name="Lang"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-25</lastupdate>
        public int SetPATransPolicy(string JobNo,string PackageID, string PlanCode, string InceptionDate, string ExpiryDate, string AgentCode, string StaffCode, string OccupatnClass, string OccupatnDestination, Nullable<int> NoOfChildren, Nullable<int> GrossPremium, Nullable<int> Stamp, Nullable<int> SBT, Nullable<int> TotalPremium, Nullable<SByte> isLongName, string GroupBrokerID, string User, string Lang)
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spPA_setTransPolicy", CommandType.StoredProcedure);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (PackageID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PackageID", DbType.String, PackageID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PackageID", DbType.String, DBNull.Value));
                if (PlanCode != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PlanCode", DbType.String, PlanCode));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PlanCode", DbType.String, DBNull.Value));
                if (InceptionDate != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@InceptionDate", DbType.String, InceptionDate));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@InceptionDate", DbType.String, DBNull.Value));
                if (ExpiryDate != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ExpiryDate", DbType.String, ExpiryDate));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ExpiryDate", DbType.String, DBNull.Value));
                if (AgentCode != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AgentCode", DbType.String, AgentCode));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AgentCode", DbType.String, DBNull.Value));
                if (StaffCode != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@StaffCode", DbType.String, StaffCode));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@StaffCode", DbType.String, DBNull.Value));
                if (OccupatnClass != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@OccupatnClass", DbType.String, OccupatnClass));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@OccupatnClass", DbType.String, DBNull.Value));
                if (OccupatnDestination != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@OccupatnDestination", DbType.String, OccupatnDestination));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@OccupatnDestination", DbType.String, DBNull.Value));
                if (NoOfChildren.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NoOfChildren", DbType.Int32, NoOfChildren));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NoOfChildren", DbType.Int32, DBNull.Value));
                if (GrossPremium.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GrossPremium", DbType.Int32, GrossPremium));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GrossPremium", DbType.Int32, DBNull.Value));
                if (Stamp.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Stamp", DbType.Int32, Stamp));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Stamp", DbType.Int32, DBNull.Value));
                if (SBT.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@SBT", DbType.Int32, SBT));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@SBT", DbType.Int32, DBNull.Value));
                if (TotalPremium.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TotalPremium", DbType.Int32, TotalPremium));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TotalPremium", DbType.Int32, DBNull.Value));
                if (isLongName.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isLongName", DbType.Int16, isLongName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isLongName", DbType.Int16, DBNull.Value));
                if (GroupBrokerID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerID", DbType.String, GroupBrokerID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerID", DbType.String, DBNull.Value));            
                if (User != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@User", DbType.String, User));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@User", DbType.String, DBNull.Value));
                if (Lang != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Lang", DbType.String, Lang));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Lang", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// SET WITH TRANSACTION
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="PackageID"></param>
        /// <param name="PlanCode"></param>
        /// <param name="InceptionDate"></param>
        /// <param name="ExpiryDate"></param>
        /// <param name="AgentCode"></param>
        /// <param name="StaffCode"></param>
        /// <param name="OccupatnClass"></param>
        /// <param name="OccupatnDestination"></param>
        /// <param name="NoOfChildren"></param>
        /// <param name="GrossPremium"></param>
        /// <param name="Stamp"></param>
        /// <param name="SBT"></param>
        /// <param name="TotalPremium"></param>
        /// <param name="isLongName"></param>
        /// <param name="GroupBrokerID"></param>
        /// <param name="User"></param>
        /// <param name="Lang"></param>
        /// <param name="dbTransaction"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-25</lastupdate>
        public int SetPATransPolicy(string JobNo, string PackageID, string PlanCode, string InceptionDate, string ExpiryDate, string AgentCode, string StaffCode, string OccupatnClass, string OccupatnDestination, Nullable<int> NoOfChildren, Nullable<int> GrossPremium, Nullable<int> Stamp, Nullable<int> SBT, Nullable<int> TotalPremium, Nullable<SByte> isLongName, string GroupBrokerID, string User, string Lang, DbTransaction dbTransaction)
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spPA_setTransPolicy", CommandType.StoredProcedure, dbTransaction);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (PackageID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PackageID", DbType.String, PackageID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PackageID", DbType.String, DBNull.Value));
                if (PlanCode != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PlanCode", DbType.String, PlanCode));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PlanCode", DbType.String, DBNull.Value));
                if (InceptionDate != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@InceptionDate", DbType.String, InceptionDate));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@InceptionDate", DbType.String, DBNull.Value));
                if (ExpiryDate != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ExpiryDate", DbType.String, ExpiryDate));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ExpiryDate", DbType.String, DBNull.Value));
                if (AgentCode != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AgentCode", DbType.String, AgentCode));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AgentCode", DbType.String, DBNull.Value));
                if (StaffCode != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@StaffCode", DbType.String, StaffCode));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@StaffCode", DbType.String, DBNull.Value));
                if (OccupatnClass != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@OccupatnClass", DbType.String, OccupatnClass));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@OccupatnClass", DbType.String, DBNull.Value));
                if (OccupatnDestination != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@OccupatnDestination", DbType.String, OccupatnDestination));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@OccupatnDestination", DbType.String, DBNull.Value));
                if (NoOfChildren.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NoOfChildren", DbType.Int32, NoOfChildren));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NoOfChildren", DbType.Int32, DBNull.Value));
                if (GrossPremium.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GrossPremium", DbType.Int32, GrossPremium));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GrossPremium", DbType.Int32, DBNull.Value));
                if (Stamp.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Stamp", DbType.Int32, Stamp));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Stamp", DbType.Int32, DBNull.Value));
                if (SBT.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@SBT", DbType.Int32, SBT));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@SBT", DbType.Int32, DBNull.Value));
                if (TotalPremium.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TotalPremium", DbType.Int32, TotalPremium));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TotalPremium", DbType.Int32, DBNull.Value));
                if (isLongName.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isLongName", DbType.Int16, isLongName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isLongName", DbType.Int16, DBNull.Value));
                if (GroupBrokerID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerID", DbType.String, GroupBrokerID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerID", DbType.String, DBNull.Value));
                if (User != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@User", DbType.String, User));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@User", DbType.String, DBNull.Value));
                if (Lang != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Lang", DbType.String, Lang));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Lang", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand, true);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        // modify 2012/11/01 -YMD
        public int SetPAAppxTransPrintRenew(string PolicyNo, string AgenCode, string GroupBrokerId, string CreatedUser,out string JobNo)
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spPA_SetAppxTransPrintRenew", CommandType.StoredProcedure);
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, PolicyNo));
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AgentCode", DbType.String, AgenCode));
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId", DbType.String, GroupBrokerId));
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreatedUser", DbType.String, CreatedUser));
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, ""));
                oDbCommand.Parameters["@JobNo"].Size = 20;
                oDbCommand.Parameters["@JobNo"].Direction = ParameterDirection.Output;
                DbProviderHelper.ExecuteNonQuery(oDbCommand, true);
                JobNo = oDbCommand.Parameters["@JobNo"].Value.ToString();
                // create DataAdapter object
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //modify 2012/11/13
        public int SetTransPrintRenewal(string JobNo, int InsuredID, string InsuredName, string InsuredAge, string PlanCode, string NetPremium)
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spPA_SetTransPrintRenewal", CommandType.StoredProcedure);
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@InsuredID", DbType.Int32, InsuredID));
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@InsuredName", DbType.String, InsuredName));
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@InsuredAge", DbType.String, InsuredAge));
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PlanCode", DbType.String, PlanCode));
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NetPremium", DbType.String, NetPremium));

                // create DataAdapter object
                return DbProviderHelper.ExecuteNonQuery(oDbCommand, true);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int SetTransPrintRenewalBenefic(string JobNo, int InsuredID, int BeneficID, string Beneficiary)
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spPA_SetTransPrintRenewalBenefic", CommandType.StoredProcedure);
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@InsuredID", DbType.Int32, InsuredID));
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficID", DbType.Int32, BeneficID));
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Beneficiary", DbType.String, Beneficiary));

                // create DataAdapter object
                return DbProviderHelper.ExecuteNonQuery(oDbCommand, true);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //---------------------------------------------------------------------
        public string spPAB2C_SetPolicyNo()
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand comm = DbProviderHelper.CreateCommand("spPAB2C_SetPolicyNo", CommandType.StoredProcedure);

                // create parameter and direction
                DbParameter param = comm.CreateParameter();
                param.ParameterName = "@PolicyNo";
                param.DbType = DbType.String;
                param.Size = 20;
                param.Direction = ParameterDirection.Output;
                comm.Parameters.Add(param);

                //execute command
                int ret = DbProviderHelper.ExecuteNonQuery(comm);

                //return jobno
                return param.Value.ToString();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public string spPAB2C_SetPolicyNo(string JobNo)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand comm = DbProviderHelper.CreateCommand("spPAB2C_SetPolicyNoByJobNo", CommandType.StoredProcedure);

                // create parameter and direction
                DbParameter param = comm.CreateParameter();
                param.ParameterName = "@PolicyNo";
                param.DbType = DbType.String;
                param.Size = 20;
                param.Direction = ParameterDirection.Output;
                comm.Parameters.Add(param);

                DbParameter param2 = comm.CreateParameter();
                param2.ParameterName = "@JobNo";
                param2.DbType = DbType.String;
                param2.Size = 200;
                param2.Value = JobNo;
                param2.Direction = ParameterDirection.Input;
                comm.Parameters.Add(param2);

                //execute command
                int ret = DbProviderHelper.ExecuteNonQuery(comm);

                //return jobno
                return param.Value.ToString();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        public int SetPATransTaxInvoince(string PolicyNo, string JobNo, string UserID, DbTransaction dbTransaction)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spPAB2C_SetTransTaxInvoince", CommandType.StoredProcedure, dbTransaction);
                if (PolicyNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@POLICYNO", DbType.String, PolicyNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@POLICYNO", DbType.String, DBNull.Value));
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JOBNO", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JOBNO", DbType.String, DBNull.Value));
                if (UserID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@USERID", DbType.String, UserID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@USERID", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand, true);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public int SetPATransPrint(string PolicyNo, string JobNo, string AgentCode, string GroupBrokerId, string CreatedUser, DbTransaction dbTransaction)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spPAB2C_SetTransPrint", CommandType.StoredProcedure, dbTransaction);
                if (PolicyNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, PolicyNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, DBNull.Value));
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (AgentCode != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AgentCode", DbType.String, AgentCode));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AgentCode", DbType.String, DBNull.Value));
                if (GroupBrokerId != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId", DbType.String, GroupBrokerId));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId", DbType.String, DBNull.Value));
                if (CreatedUser != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreatedUser", DbType.String, CreatedUser));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreatedUser", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand, true);


            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        public int SetPATransTaxInvoince(string PolicyNo, string JobNo, string UserID)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spPAB2C_SetTransTaxInvoince", CommandType.StoredProcedure);
                if (PolicyNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@POLICYNO", DbType.String, PolicyNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@POLICYNO", DbType.String, DBNull.Value));
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JOBNO", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JOBNO", DbType.String, DBNull.Value));
                if (UserID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@USERID", DbType.String, UserID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@USERID", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand, true);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public int SetPATransPrint(string PolicyNo, string JobNo, string AgentCode, string GroupBrokerId, string CreatedUser)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spPAB2C_SetTransPrint", CommandType.StoredProcedure);
                if (PolicyNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, PolicyNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, DBNull.Value));
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (AgentCode != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AgentCode", DbType.String, AgentCode));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AgentCode", DbType.String, DBNull.Value));
                if (GroupBrokerId != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId", DbType.String, GroupBrokerId));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId", DbType.String, DBNull.Value));
                if (CreatedUser != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreatedUser", DbType.String, CreatedUser));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreatedUser", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand, true);


            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        public DataTable GetPAPrintListReportName(string PolicyNo)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand comm = DbProviderHelper.CreateCommand("spPAB2C_GetPrintListReportName", CommandType.StoredProcedure);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, PolicyNo));
                

                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return DbProviderHelper.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        ///<summary>
        /// GET Policy By PassportID And Return(RefCode)
        /// <param name="PassportID"></param>
        /// <param name="RefCode"></param>
        /// <return></return>
        /// Add By Makkawat 2015-07-02
        public DataTable GetPATransPolicyByReturnINV(string RefCode)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = DbProviderHelper.CreateCommand("spPA_GetPolicyByReturnINV", CommandType.StoredProcedure);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@i_RefCode", DbType.String, RefCode));

                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return DbProviderHelper.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
	}
}
