using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;

namespace PA.DAL
{
	public class PAB2CPolicyNoDAO
	{
		public PAB2CPolicyNoDAO()
		{
            //DbProviderHelper dbHelper = new DbProviderHelper();
            DbProviderHelper.GetConnection();
		}
        public string spPAB2C_SetPolicyNo()
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();
                // get a configured & create DbCommand object
                DbCommand comm = DbProviderHelper.CreateCommand("spPAB2C_SetPolicyNo", CommandType.StoredProcedure);

                // create parameter and direction
                DbParameter param = comm.CreateParameter();
                param.ParameterName = "@PolicyNo";
                param.DbType = DbType.String;
                param.Size = 20;
                param.Direction = ParameterDirection.Output;
                comm.Parameters.Add(param);

                //execute command
                int ret = DbProviderHelper.ExecuteNonQuery(comm);

                //return jobno
                return param.Value.ToString();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public string spPAB2C_SetPolicyNo(string JobNo)
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();
                // get a configured & create DbCommand object
                DbCommand comm = DbProviderHelper.CreateCommand("spPAB2C_SetPolicyNoByJobNo", CommandType.StoredProcedure);

                // create parameter and direction
                DbParameter param = comm.CreateParameter();
                param.ParameterName = "@PolicyNo";
                param.DbType = DbType.String;
                param.Size = 20;
                param.Direction = ParameterDirection.Output;
                comm.Parameters.Add(param);

                DbParameter param2 = comm.CreateParameter();
                param2.ParameterName = "@JobNo";
                param2.DbType = DbType.String;
                param2.Size = 200;
                param2.Value = JobNo;
                param2.Direction = ParameterDirection.Input;
                comm.Parameters.Add(param2);

                //execute command
                int ret = DbProviderHelper.ExecuteNonQuery(comm);

                //return jobno
                return param.Value.ToString();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public int spPAB2C_UpdatePolicyNoToJobNo(string JobNo, string PolicyNo, string RETURNINV)
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();

                DbCommand oDbCommand = DbProviderHelper.CreateCommand("UPDATE [PATransPolicies] SET [PolicyNo]=@PolicyNo, [RETURNINV] = @RETURNINV WHERE [JobNo] = @JobNo", CommandType.Text);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (PolicyNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, PolicyNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, DBNull.Value));

                if (RETURNINV != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@RETURNINV", DbType.String, RETURNINV));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@RETURNINV", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //Makkawat Update 20150811
        public DataTable spPAB2C_FindPolicyNoByRef(string RETURNINV)
        {
            DbDataReader oDbDataReader = null;
            try
            {
                DataTable result = new DataTable();
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("SELECT [JobNo],[PolicyNo],[PolicyType],[PlanCode] FROM [PATransPolicies] where RETURNINV = @RETURNINV", CommandType.Text);
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@RETURNINV", DbType.String, RETURNINV));
                oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);

                result.Load(oDbDataReader);

                oDbDataReader.Close();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //Makkawat Update 20150811
        public DataTable spPAB2C_FindPolicyHoldersNameByJobNo(string JobNo)
        {
            DbDataReader oDbDataReader = null;
            try
            {
                DataTable result = new DataTable();
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("SELECT [ClientTitle],[ClientName],[ClientSurName] FROM [PATransPolicyHolders] where [JobNo] = @JobNo", CommandType.Text);
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);

                result.Load(oDbDataReader);

                oDbDataReader.Close();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
	}
}
