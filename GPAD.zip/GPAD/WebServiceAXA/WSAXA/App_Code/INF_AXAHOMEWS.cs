﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

using HOME.BLL;
using HOME.BusinessObjects;
using HOME.DAL;
using System.Data;
using System.Data.Common;
using System.IO;
using System.Globalization;
using System.Collections;
using System.Net;
using System.Web.Services.Protocols;

/// <summary>
/// Summary description for INF_AXAHOMEWS
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class INF_AXAHOMEWS : System.Web.Services.WebService {

    public INF_AXAHOMEWS () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    public class ObjAXAHOMELongTermYear
    {
        public int _years { get; set; }
    }

    public class ObjAXAHOMEListLongTermYear
    {
        public string _msg { get; set; }
        public List<ObjAXAHOMELongTermYear> _listHOMELongTermYear { get; set; }
    }

    public class ObjAXAHOMEAppearanceOfBuilding
    {
        public string _code { get; set; }
        public string _appearanceOfBuilding { get; set; }
    }

    public class ObjAXAHOMEListAppearanceOfBuilding
    {
        public string _msg { get; set; }
        public List<ObjAXAHOMEAppearanceOfBuilding> _listHOMEAppearanceOfBuilding { get; set; }
    }

    public class ObjAXAHOMEStructurePackage
    {
        public string _structurePackage { get; set; }
        public string _structurePackageName { get; set; }
        public string _externalWall { get; set; }
        public string _upperFloor { get; set; }
        public string _roofBeam { get; set; }
        public string _roof { get; set; }
        public string _wall { get; set; }
        public string _loadBearingWall { get; set; }
        public string _beam { get; set; }
        public string _floor { get; set; }
    }

    public class ObjAXAHOMEListStructurePackage
    {
        public string _msg { get; set; }
        public List<ObjAXAHOMEStructurePackage> _listHOMEStructurePackage { get; set; }
    }

    public class ObjAXAHOMEPlanPackage
    {
        public string _packageID { get; set; }
        public string _packageName { get; set; }
        public int _minSumInsure { get; set; }
        public int _maxSumInsure { get; set; }
    }

    public class ObjAXAHOMEListPlanPackage
    {
        public string _msg { get; set; }
        public List<ObjAXAHOMEPlanPackage> _listHOMEPlanPackage { get; set; }
    }

    public class ObjAXAHOMEPlanCoverage
    {
        public string _coverageNameTH { get; set; }
        public string _coverageNameEN { get; set; }        
        public int _sumInsured { get; set; }
        public int _amountLimitPerOcc { get; set; }
        public int _amountLimitAggr { get; set; }
        public int _amountDeduct { get; set; }
    }

    public class ObjAXAHOMEListPlanCoverage
    {
        public string _msg { get; set; }
        public List<ObjAXAHOMEPlanCoverage> _listHOMEPlanCoverage { get; set; }
    }

    public class ObjAXAHOMEPremiumPayment
    {
        public string _msg { get; set; }
        public double _netPremium { get; set; }
        public int _tax { get; set; }
        public int _stamp { get; set; }
        public double _totalPremium { get; set; }
    }

    public class ObjAXAHOMEGetBlock
    {
        public string _msg { get; set; }
        public string _registerCode { get; set; }
        public string _block { get; set; }
    }

    public class ObjAXAHOMECheckRestrictedArea
    {
        public string _msg { get; set; }
        public bool _isRestrictedArea { get; set; }        
    }

    public class ObjAXAHOMEPropertyLocation
    {
        public Nullable<bool> _isVillage { get; set; }
        public string _houseCode { get; set; }
        public string _address1 { get; set; }
        public string _address2 { get; set; }
        public string _road { get; set; }
        public string _province { get; set; }
        public string _amphur { get; set; }
        public string _tumbol { get; set; }
        public string _postcode { get; set; }
        public string _latitude { get; set; }
        public string _longtitude { get; set; }
        public Nullable<bool> _istenant { get; set; }
        public Nullable<int> _floorCount { get; set; }
        public Nullable<int> _buildingCount { get; set; }
        public Nullable<int> _roomNo { get; set; }
        public Nullable<int> _floorNo { get; set; }
        public string _totalArea { get; set; }
    }

    public class ObjAXAHOMEPolicyHolder
    {
        public string _clientType { get; set; }
        public string _clientTitle { get; set; }
        public string _clientName { get; set; }
        public string _clientSurName { get; set; }
        public string _longName { get; set; }
        public string _branchNo { get; set; }
        public string _address1 { get; set; }
        public string _address2 { get; set; }
        public string _provinceID { get; set; }
        public string _amphurID { get; set; }
        public string _tumbolID { get; set; }
        public string _province { get; set; }
        public string _amphur { get; set; }
        public string _tumbol { get; set; }
        public string _postCode { get; set; }
        public string _birthday { get; set; }
        public string _idCard { get; set; }
        public string _tel { get; set; }
        public string _email { get; set; }
        public string _language { get; set; }                                                        
    }

    public class ObjAXAHOMEPABeneficialy
    {
        public int _PASeq { get; set; }
        public string _PATitle { get; set; }
        public string _PAName { get; set; }
        public string _PASurName { get; set; }
        public string _PAID { get; set; }
        public string _PADOB { get; set; }
        public string _PABeneficiary { get; set; }
        public string _PARelation { get; set; }
    }

    public class ObjAXAHOMEPolicyInsured
    {
        public int _insuredID { get; set; }
        public string _clientTitle { get; set; }
        public string _clientName { get; set; }
        public string _clientSurName { get; set; }
        public string _birthday { get; set; }
        public string _idCard { get; set; }
        public string _tel { get; set; }
    }
   
    public class ObjAXAHOMEPolicyIssued
    {
        public string _msg { get; set; }
        public string _deliverDocMsg { get; set; }
        public string _policyNo { get; set; }
    }


    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAHOMEListLongTermYear GetAXAHOMELongTermYear(string agentCode, string groupBrokerId, string password)
    {
        string retMsg = string.Empty;

        ObjAXAHOMEListLongTermYear objListLongTermYear = new ObjAXAHOMEListLongTermYear();
        List<ObjAXAHOMELongTermYear> lstAXAHOMELongTermYear = new List<ObjAXAHOMELongTermYear>();

        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);            
            #endregion

            #region ###Validate Data into Web Service

            #endregion

            if (isValidateOK == true)
            {

                HMLongTermRateBLL clsHMLongTermRateBLL = new HMLongTermRateBLL();
                DataTable dt = clsHMLongTermRateBLL.GetHMCoveredYears();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ObjAXAHOMELongTermYear item = new ObjAXAHOMELongTermYear();
                    int years = string.IsNullOrEmpty(dt.Rows[i]["years"].ToString()) ? 1 : Convert.ToInt32(dt.Rows[i]["years"].ToString());

                    item._years = years;

                    lstAXAHOMELongTermYear.Add(item);
                }

                retMsg = "SUCCESS";
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        objListLongTermYear._msg = retMsg;
        objListLongTermYear._listHOMELongTermYear = lstAXAHOMELongTermYear.Cast<ObjAXAHOMELongTermYear>().ToList();

        return objListLongTermYear;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="language"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAHOMEListAppearanceOfBuilding GetAXAHOMEAppearanceOfBuilding(string agentCode, string groupBrokerId, string password, string language)
    {
        string retMsg = string.Empty;
        language = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();

        ObjAXAHOMEListAppearanceOfBuilding objListAppearanceOfBuilding = new ObjAXAHOMEListAppearanceOfBuilding();
        List<ObjAXAHOMEAppearanceOfBuilding> lstAXAHOMEAppearanceOfBuilding = new List<ObjAXAHOMEAppearanceOfBuilding>();

        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            #endregion

            #region ###Validate Data into Web Service
            
            #endregion

            if (isValidateOK == true)
            {

                HMInsuredSubGroupBLL clsHMInsuredSubGroup = new HMInsuredSubGroupBLL();
                DataTable dt = clsHMInsuredSubGroup.GetHMInsuredSubGroups(language);

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ObjAXAHOMEAppearanceOfBuilding item = new ObjAXAHOMEAppearanceOfBuilding();
                    string code = dt.Rows[i]["Code"].ToString();
                    string name = dt.Rows[i]["AppearanceOfBuilding"].ToString();

                    item._code = code;
                    item._appearanceOfBuilding = name;

                    lstAXAHOMEAppearanceOfBuilding.Add(item);
                }

                retMsg = "SUCCESS";
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        objListAppearanceOfBuilding._msg = retMsg;
        objListAppearanceOfBuilding._listHOMEAppearanceOfBuilding = lstAXAHOMEAppearanceOfBuilding.Cast<ObjAXAHOMEAppearanceOfBuilding>().ToList();

        return objListAppearanceOfBuilding;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="language"></param>
    /// <param name="AOBCode">Appearance of Building Code</param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAHOMEListStructurePackage GetAXAHOMEStructurePackage(string agentCode, string groupBrokerId, string password, string language, string AOBCode)
    {
        string retMsg = string.Empty;
        language = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();

        ObjAXAHOMEListStructurePackage objListStructurePackage = new ObjAXAHOMEListStructurePackage();
        List<ObjAXAHOMEStructurePackage> lstAXAHOMEStructurePackage = new List<ObjAXAHOMEStructurePackage>();

        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);            
            #endregion

            #region ###Validate Data into Web Service

            #endregion

            if (isValidateOK == true)
            {

                HMStructurePackageBLL clsHMStructurePackage = new HMStructurePackageBLL();
                DataTable dt = clsHMStructurePackage.GetHMStructurePackages(language, AOBCode);

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ObjAXAHOMEStructurePackage item = new ObjAXAHOMEStructurePackage();
                    string package = dt.Rows[i]["StructurePackage"].ToString();
                    string structurePackageName = dt.Rows[i]["StructurePackageName"].ToString();
                    string externalwall = dt.Rows[i]["ExternalWall"].ToString();
                    string upperfloor = dt.Rows[i]["UpperFloor"].ToString();
                    string roofbeam = dt.Rows[i]["RoofBeam"].ToString();
                    string roof = dt.Rows[i]["Roof"].ToString();
                    string wall = dt.Rows[i]["Wall"].ToString();
                    string load = dt.Rows[i]["Column/LoadBearingWall"].ToString();
                    string beam = dt.Rows[i]["Beam"].ToString();
                    string floor = dt.Rows[i]["Floor"].ToString();                   

                    item._structurePackage = package;
                    item._structurePackageName = structurePackageName;
                    item._externalWall = externalwall;
                    item._upperFloor = upperfloor;
                    item._roofBeam = roofbeam;
                    item._roof = roof;
                    item._wall = wall;
                    item._loadBearingWall = load;
                    item._beam = beam;
                    item._floor = floor;

                    lstAXAHOMEStructurePackage.Add(item);
                }

                retMsg = "SUCCESS";
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        objListStructurePackage._msg = retMsg;
        objListStructurePackage._listHOMEStructurePackage = lstAXAHOMEStructurePackage.Cast<ObjAXAHOMEStructurePackage>().ToList();

        return objListStructurePackage;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="AOBCode">Appearance of Building Code</param>
    /// <param name="structurePackage">Structure Package</param>
    /// <param name="language"></param>
    /// <param name="buildingSumInsure"></param>
    /// <param name="contentSumInsure"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAHOMEListPlanPackage GetAXAHOMEPlanPackage(string agentCode, string groupBrokerId, string password, string AOBCode, string structurePackage, string language, int buildingSumInsure, int contentSumInsure)
    {
        string retMsg = string.Empty;
        language = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();       

        ObjAXAHOMEListPlanPackage objListPlanPackage = new ObjAXAHOMEListPlanPackage();
        List<ObjAXAHOMEPlanPackage> lstAXAHOMEPlanPackage = new List<ObjAXAHOMEPlanPackage>();

        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            #endregion

            #region ###Validate Data into Web Service

            #endregion

            if (isValidateOK == true)
            {

                HMPlanPackageBLL clsHMPlanPackage = new HMPlanPackageBLL();
                DataTable dt = clsHMPlanPackage.GetHMPlanPackages(groupBrokerId,language, AOBCode, structurePackage, buildingSumInsure, contentSumInsure);

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ObjAXAHOMEPlanPackage item = new ObjAXAHOMEPlanPackage();
                    string packageID = dt.Rows[i]["PackageID"].ToString();
                    string packageName = dt.Rows[i]["PackageName"].ToString();
                    int min = string.IsNullOrEmpty(dt.Rows[i]["MinSumInsured"].ToString()) ? 0 : Convert.ToInt32(dt.Rows[i]["MinSumInsured"].ToString());
                    int max = string.IsNullOrEmpty(dt.Rows[i]["MaxSumInsured"].ToString()) ? 0 : Convert.ToInt32(dt.Rows[i]["MaxSumInsured"].ToString());

                    item._packageID = packageID;
                    item._packageName = packageName;
                    item._minSumInsure = min;
                    item._maxSumInsure = max;

                    lstAXAHOMEPlanPackage.Add(item);
                }

                retMsg = "SUCCESS";
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        objListPlanPackage._msg = retMsg;
        objListPlanPackage._listHOMEPlanPackage = lstAXAHOMEPlanPackage.Cast<ObjAXAHOMEPlanPackage>().ToList();

        return objListPlanPackage;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="AOBCode">Appearance of Building Code</param>
    /// <param name="structurePackage"></param>
    /// <param name="packageID"></param>
    /// <param name="language"></param>
    /// <param name="buildingSumInsure"></param>
    /// <param name="contentSumInsure"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAHOMEListPlanCoverage GetAXAHOMEPlanCoverage(string agentCode, string groupBrokerId, string password, string AOBCode, string structurePackage, string packageID ,string language, int buildingSumInsure, int contentSumInsure)
    {
        string retMsg = string.Empty;
        language = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();

        ObjAXAHOMEListPlanCoverage objHOMEListPlanCoverage = new ObjAXAHOMEListPlanCoverage();
        List<ObjAXAHOMEPlanCoverage> lstAXAHOMEPlanCoverage = new List<ObjAXAHOMEPlanCoverage>();

        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);            
            #endregion

            if (isValidateOK == true)
            {               
                HMPlanCoverageBLL clsHMPlanCoverageBLL = new HMPlanCoverageBLL();
                DataTable dt = clsHMPlanCoverageBLL.GetHMPlanCoverages(AOBCode, structurePackage, packageID, buildingSumInsure, contentSumInsure);            

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ObjAXAHOMEPlanCoverage item = new ObjAXAHOMEPlanCoverage();
                    string coverageNameTH = dt.Rows[i]["CoverageNameTH"].ToString();
                    string coverageNameEN = dt.Rows[i]["CoverageNameEN"].ToString();
                    int sumInsured = string.IsNullOrEmpty(dt.Rows[i]["SumInsured"].ToString()) ? 0 : Convert.ToInt32(dt.Rows[i]["SumInsured"].ToString());
                    int amountPerOcc = string.IsNullOrEmpty(dt.Rows[i]["AmountLimitPerOcc"].ToString()) ? 0 : Convert.ToInt32(dt.Rows[i]["AmountLimitPerOcc"].ToString());
                    int amountAggr = string.IsNullOrEmpty(dt.Rows[i]["AmountLimitAggr"].ToString()) ? 0 : Convert.ToInt32(dt.Rows[i]["AmountLimitAggr"].ToString());
                    int amountDeduct = string.IsNullOrEmpty(dt.Rows[i]["AmountDeduct"].ToString()) ? 0 : Convert.ToInt32(dt.Rows[i]["AmountDeduct"].ToString());

                    item._coverageNameTH = coverageNameTH;
                    item._coverageNameEN = coverageNameEN;
                    item._sumInsured = sumInsured;
                    item._amountLimitPerOcc = amountPerOcc;
                    item._amountLimitAggr = amountAggr;
                    item._amountDeduct = amountDeduct;

                    lstAXAHOMEPlanCoverage.Add(item);
                }

                retMsg = "SUCCESS";
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        objHOMEListPlanCoverage._msg = retMsg;
        objHOMEListPlanCoverage._listHOMEPlanCoverage = lstAXAHOMEPlanCoverage.Cast<ObjAXAHOMEPlanCoverage>().ToList();

        return objHOMEListPlanCoverage;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="AOBCode">Appearance of Building Code</param>
    /// <param name="structurePackage"></param>
    /// <param name="packageID"></param>
    /// <param name="language"></param>
    /// <param name="buildingSumInsure"></param>
    /// <param name="contentSumInsure"></param>
    /// <param name="yearPeriod"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAHOMEPremiumPayment GetAXAHOMEPremiumPayment(string agentCode, string groupBrokerId, string password, string AOBCode, string structurePackage, string packageID, string language, int buildingSumInsure, int contentSumInsure, int yearPeriod)
    {
        string retMsg = string.Empty;
        double netPremium = 0;
        double totalPremium = 0;
        int tax = 0;
        int stamp = 0;

        language = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();
        ObjAXAHOMEPremiumPayment objPremiumPayment = new ObjAXAHOMEPremiumPayment();

        try
        {

            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);            
            #endregion            

            if (isValidateOK == true)
            {

                HMPlanPremiumBLL clsHMPlanPremiumBLL = new HMPlanPremiumBLL();
                DataTable dt = clsHMPlanPremiumBLL.GetHMPlanPremiums(AOBCode, structurePackage, packageID, buildingSumInsure, contentSumInsure);

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    netPremium = string.IsNullOrEmpty(dt.Rows[i]["NetPremium"].ToString()) ? 0 : Convert.ToInt32(dt.Rows[i]["NetPremium"].ToString());
                    tax = string.IsNullOrEmpty(dt.Rows[i]["Tax"].ToString()) ? 0 : Convert.ToInt32(dt.Rows[i]["Tax"].ToString());
                    stamp = string.IsNullOrEmpty(dt.Rows[i]["Stamp"].ToString()) ? 0 : Convert.ToInt32(dt.Rows[i]["Stamp"].ToString());
                    totalPremium = string.IsNullOrEmpty(dt.Rows[i]["Total"].ToString()) ? 0 : Convert.ToInt32(dt.Rows[i]["Total"].ToString());                                     
                }

                retMsg = "SUCCESS";

            }
            else
            {
                retMsg = secMsg;
            }

        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }
                             
        objPremiumPayment._msg = retMsg;
        objPremiumPayment._netPremium = netPremium;
        objPremiumPayment._tax = tax;
        objPremiumPayment._stamp = stamp;
        objPremiumPayment._totalPremium = totalPremium;

        return objPremiumPayment;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="amphur"></param>
    /// <param name="province"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAHOMEGetBlock GetAXAHOMEBlock(string agentCode, string groupBrokerId, string password,string tumbol, string amphur, string province)
    {
        string retMsg = string.Empty;
        string retRegisterCode = string.Empty;
        string retBlock = string.Empty;

        ObjAXAHOMEGetBlock objGetBlock = new ObjAXAHOMEGetBlock();

        try
        {

            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            #endregion

            if (isValidateOK == true)
            {

                HMBlockAccumBLL clsHMBlockAccumBLL = new HMBlockAccumBLL();
                DataTable dt = clsHMBlockAccumBLL.GetHMBlock(tumbol.Trim(),amphur.Trim(), province.Trim());

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    retRegisterCode = dt.Rows[i]["RegisterCode"].ToString();
                    retBlock = dt.Rows[i]["Block"].ToString();                    
                }

                retMsg = "SUCCESS";

            }
            else
            {
                retMsg = secMsg;
            }

        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        objGetBlock._msg = retMsg;
        objGetBlock._registerCode = retRegisterCode;
        objGetBlock._block = retBlock;


        return objGetBlock;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="address1"></param>
    /// <param name="address2"></param>
    /// <param name="province"></param>
    /// <param name="amphur"></param>
    /// <param name="tumbol"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAHOMECheckRestrictedArea CheckAXAHOMERestrictedArea(string agentCode, string groupBrokerId, string password, string address1, string address2,string road, string province, string amphur, string tumbol)
    {        
        string retMsg = string.Empty;
        bool isRestrictedArea = false;
        ObjAXAHOMECheckRestrictedArea objCheckRestrictedArea = new ObjAXAHOMECheckRestrictedArea();

        try
        {

            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            #endregion

            if (isValidateOK == true)
            {
                HMRestrictedAreaBLL clsHMRestrictedAreaBLL = new HMRestrictedAreaBLL();
                isRestrictedArea = clsHMRestrictedAreaBLL.CheckHMRestrictedAreas(address1.Trim(), address2.Trim(), road.Trim(), tumbol.Trim(), amphur.Trim(), province.Trim());
                
                retMsg = "SUCCESS";

            }
            else
            {
                retMsg = secMsg;
            }

        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        objCheckRestrictedArea._msg = retMsg;
        objCheckRestrictedArea._isRestrictedArea = isRestrictedArea;        

        return objCheckRestrictedArea;
    }

    [WebMethod]
    public ObjAXAHOMEPolicyIssued ProcessAXAHOMEPolicyIssue(string agentCode, string groupBrokerId, string password, string language, string effectiveDate, int termYear, string AOBCode, string structurePackage, string packageID, int buildingSumInsure, int contentSumInsure, ObjAXAHOMEPropertyLocation objPropertyLocation, ObjAXAHOMEPolicyHolder objPolicyHolder, List<ObjAXAHOMEPABeneficialy> lstObjPABeneficiary, string referenceCode, bool isFTP, string ftpServer, string ftpUser, string ftpPass, string brokerEmail)
    {
        language = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();

        string retMsg = string.Empty;
        string retDeiverDoc = string.Empty;        
        int percentDiscount = 0;
        string userID = agentCode;
        bool isValidateOK = true;
        int yearPeriod = 1;
        string registerCode = string.Empty;
        string block = string.Empty;

        string policyNo = string.Empty;
        string JobNo = string.Empty;

        #region ###Validate Corect Data into Web Service
        if ((string.IsNullOrEmpty(effectiveDate))
            || (effectiveDate.Length < 10 ))
        {
            isValidateOK = false;
            retMsg += " | Effective Date incorrect!!!";
        }
        else
        {
            string[] arrDateEffective = effectiveDate.Split('/');

            if (Int32.Parse(arrDateEffective[2].Substring(0, 4)) > 2500)
            {
                isValidateOK = false;
                retMsg += " | Effective Date(Year) Value Must be A.D.!!!";
            }


            //Calulate year perios
            yearPeriod = termYear;
            //End
        }

        if (yearPeriod < 1)
        {
            isValidateOK = false;
            retMsg += " | Year period value must equal 1 or more!!!";
        }

        if (objPropertyLocation == null)
        {
            isValidateOK = false;
            retMsg += " | Property detail data can not be null value!!!";
        }

        if (objPolicyHolder == null)
        {
            isValidateOK = false;
            retMsg += " | Policy holder data can not be null value!!!";
        }

        //if (lstObjPolicyInsured == null || lstObjPolicyInsured[0] == null)
        //{
        //    isValidateOK = false;
        //    retMsg += " | List of policy insured can not be null value!!!";
        //}

        if (lstObjPABeneficiary == null)
        {
            isValidateOK = false;
            retMsg += " | List of PA beneficiary can not be null value!!!";
        }        

        if (isFTP == true)
        {
            if (string.IsNullOrEmpty(ftpServer) || string.IsNullOrEmpty(ftpUser) || string.IsNullOrEmpty(ftpPass))
            {
                isValidateOK = false;
                retMsg += " | FTP Data Must be complete!!!";
            }
        }
        else
        {
            if (string.IsNullOrEmpty(brokerEmail))
            {
                isValidateOK = false;
                retMsg += " | Broker email Data Must be complete!!!";
            }
        }
        #endregion

        #region ###Validate security & authorization into Web Service
        if (isValidateOK == true)
        {

            string retMsgSecur = "";
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out retMsgSecur);            
            if (isValidateOK == false)
            {
                retMsg += retMsgSecur;
            }
        }
        #endregion

        #region Validate security package for sell
        if (isValidateOK == true)
        {
            HMPlanPackageBLL clsHMPlanPackage = new HMPlanPackageBLL();
            DataTable dt = clsHMPlanPackage.GetHMPlanPackages(groupBrokerId, language, AOBCode, structurePackage, buildingSumInsure, contentSumInsure);
            if (dt.Rows.Count == 0)
            {
                isValidateOK = false;
                retMsg += "| You are not authorized to sell this package.";
            }
        }
        #endregion

        #region ###Check Restricted Area
        bool isRestrictedArea = false;
        HMRestrictedAreaBLL clsHMRestrictedAreaBLL = new HMRestrictedAreaBLL();
        isRestrictedArea = clsHMRestrictedAreaBLL.CheckHMRestrictedAreas(objPropertyLocation._address1.Trim(), objPropertyLocation._address2.Trim(),objPropertyLocation._road.Trim(), objPropertyLocation._tumbol.Trim(), objPropertyLocation._amphur.Trim(), objPropertyLocation._province.Trim());
        if (isRestrictedArea == true)
        {
            isValidateOK = false;
            retMsg += " | This property is located in Restricted area!!!";
        }
        #endregion

        #region ###Check Block
        HMBlockAccumBLL clsHMBlockAccumBLL = new HMBlockAccumBLL();
        DataTable dt2 = clsHMBlockAccumBLL.GetHMBlock(objPropertyLocation._tumbol.Trim(), objPropertyLocation._amphur.Trim(), objPropertyLocation._province.Trim());

        for (int i = 0; i < dt2.Rows.Count; i++)
        {
            registerCode = dt2.Rows[i]["RegisterCode"].ToString();
            block = dt2.Rows[i]["Block"].ToString();
        }

        if (string.IsNullOrEmpty(registerCode) && string.IsNullOrEmpty(block))
        {
            isValidateOK = false;
            retMsg += " | Cannot find Block Data!!!";
        }
        #endregion

        #region ###Begin Transaction
        if (isValidateOK == true)
        {
            DbTransaction dbTransaction = null;
            try
            {
                string EffectiveDateFrom = TA.TAUtilities.ConvertDateFieldToDB(effectiveDate);
                //string EffectiveDateTo = TA.TAUtilities.ConvertDateFieldToDB(endDate);
                
                #region "GET/SET JOB NUMBER (NOW NONE TRANSACTION)"
                //GET/SET JOB NUMBER
                //string m_JobNo = "AXA-TA-20120500007";
                HMJobRunningBLL clsjobrunning = new HMJobRunningBLL();                
                JobNo = clsjobrunning.GetHMJobRunnings();
                if (string.IsNullOrEmpty(JobNo))
                {
                    throw new Exception("เกิดข้อผิดพลาดในการสร้างหมายเลข Job Number กรุณาทดลองบันทึกงานอีกครั้งหรือติดต่อผู้ดูแลระบบ");
                }

                #endregion

                #region GET PREMIUM

                INF_AXAHOMEWS service = new INF_AXAHOMEWS();
                ObjAXAHOMEPremiumPayment objPremium = new ObjAXAHOMEPremiumPayment();

                objPremium = service.GetAXAHOMEPremiumPayment(agentCode, groupBrokerId, password,
                                                              AOBCode, structurePackage, packageID,
                                                              language, buildingSumInsure, contentSumInsure, yearPeriod);

                #endregion

                #region "OPEN DB"
                //OPEN DB
                DbProviderHelper.OpenDb();
                #endregion

                #region "OPEN TRANSACTION"
                //TRANSACTION BEGIN
                dbTransaction = DbProviderHelper.BeginTransaction();
                #endregion

                #region "#1-INSERT/UPDATE TRANSPOLICY"
                //#1-INSERT/UPDATE TRANSPOLICY                         
                HMTransPolicyBLL clstranspolicy = new HMTransPolicyBLL();                
                
                
                clstranspolicy.AddHMTransPolicy(JobNo
                                                , language
                                                , AOBCode
                                                , structurePackage
                                                , packageID
                                                , EffectiveDateFrom
                                                , yearPeriod.ToString()
                                                , groupBrokerId
                                                , agentCode
                                                , (decimal)objPremium._netPremium
                                                , objPremium._stamp
                                                , objPremium._tax
                                                , (decimal)objPremium._totalPremium
                                                , false
                                                , true
                                                , userID
                                                , dbTransaction
                                                );                                                

                #endregion

                #region "#2-INSERT/UPDATE HMTransPolicyHolder"
                //#2-INSERT/UPDATE HMTransPolicyHolder
                HMTransPolicyHolderBLL clsHMTransPolicyHolderBLL = new HMTransPolicyHolderBLL();
                clsHMTransPolicyHolderBLL.AddHMTransPolicyHolder(JobNo
                                                                 , language
                                                                 , objPolicyHolder._clientType
                                                                 , objPolicyHolder._clientTitle
                                                                 , objPolicyHolder._clientName
                                                                 , objPolicyHolder._clientSurName
                                                                 , objPolicyHolder._longName
                                                                 , objPolicyHolder._branchNo
                                                                 , objPolicyHolder._address1
                                                                 , objPolicyHolder._address2
                                                                 , objPolicyHolder._province
                                                                 , objPolicyHolder._amphur
                                                                 , objPolicyHolder._tumbol
                                                                 , objPolicyHolder._postCode
                                                                 , TA.TAUtilities.ConvertDateFieldToDB(objPolicyHolder._birthday)
                                                                 , objPolicyHolder._idCard
                                                                 , objPolicyHolder._tel
                                                                 , objPolicyHolder._email
                                                                 , dbTransaction
                                                                 );
                                                                 
                #endregion

                #region "#3-INSERT/UPDATE HMTransPropertyLocation, HMTransPropertyDetail , HMTransCoverage"
                //#3-INSERT/UPDATE HMTransPropertyLocation , HMTransPropertyDetail , HMTransCoverage
                HMTransPropertyLocationBLL clsHMTransPropertyLocationBLL = new HMTransPropertyLocationBLL();
                clsHMTransPropertyLocationBLL.AddHMTransPropertyLocation(JobNo
                                                                        , language
                                                                        , 1
                                                                        , AOBCode
                                                                        , structurePackage
                                                                        , packageID
                                                                        , buildingSumInsure
                                                                        , contentSumInsure
                                                                        , objPropertyLocation._isVillage
                                                                        , objPropertyLocation._houseCode
                                                                        , objPropertyLocation._address1
                                                                        , objPropertyLocation._address2
                                                                        , objPropertyLocation._road
                                                                        , objPropertyLocation._province
                                                                        , objPropertyLocation._amphur
                                                                        , objPropertyLocation._tumbol
                                                                        , objPropertyLocation._postcode
                                                                        , objPropertyLocation._latitude
                                                                        , objPropertyLocation._longtitude
                                                                        , objPropertyLocation._istenant
                                                                        , objPropertyLocation._floorCount
                                                                        , objPropertyLocation._buildingCount
                                                                        , objPropertyLocation._roomNo
                                                                        , objPropertyLocation._floorNo
                                                                        , objPropertyLocation._totalArea
                                                                        , (decimal)objPremium._netPremium
                                                                        , objPremium._stamp
                                                                        , objPremium._tax
                                                                        , (decimal)objPremium._totalPremium
                                                                        , dbTransaction
                                                                        );
                                                                        

                #endregion               

                #region "#4-INSERT/UPDATE HMTransPABeneficiary"
                foreach (ObjAXAHOMEPABeneficialy item in lstObjPABeneficiary)
                {
                    HMTransPABeneficiaryBLL clsHMTransPABeneficiaryBLL = new HMTransPABeneficiaryBLL();
                    clsHMTransPABeneficiaryBLL.AddHMTransPABeneficiary(JobNo
                                                                        , 1
                                                                        , item._PASeq
                                                                        , item._PATitle
                                                                        , item._PAName
                                                                        , item._PASurName
                                                                        , item._PAID
                                                                        , item._PADOB
                                                                        , item._PABeneficiary
                                                                        , item._PARelation
                                                                        , dbTransaction
                                                                        );
                }
                #endregion

                #region #5-INSERT/NOT USER DISCOUNT

                #endregion

                #region "COMMIT DB"
                //COMMIT DB
                DbProviderHelper.CommitTransaction(dbTransaction);
                #endregion

                #region "CLOSE DB"
                //CLOSE DB
                DbProviderHelper.CloseDb();
                dbTransaction.Dispose();
                dbTransaction = null;
                #endregion
            }
            catch (Exception ex)
            {
                retMsg += ex.Message.ToString() + " | ";

                if (dbTransaction != null)
                {
                    #region "ROLLBACK DB"
                    //ROLLBACK DB
                    DbProviderHelper.RollbackTransaction(dbTransaction);
                    #endregion

                    #region "CLOSE DB"
                    //CLOSE DB
                    DbProviderHelper.CloseDb();
                    #endregion
                }
            }

            if (retMsg == string.Empty)
                retMsg = "SUCCESS";

            string issueMsg = string.Empty;

            if (string.Compare(retMsg.ToUpper().Trim(), "SUCCESS") == 0)
            {
                policyNo = this.SetAXATAPolicyIssue(agentCode, groupBrokerId, "F", packageID, referenceCode, JobNo, out issueMsg);

                if (string.Compare(issueMsg.ToUpper().Trim(), "SUCCESS") == 0)
                {
                    retMsg = "SUCCESS";

                    #region ###Process Send E-mail or FTP Document
                    if (isFTP == false)
                    {
                        string insuredName = objPolicyHolder._clientTitle + " " + objPolicyHolder._clientName + " " + objPolicyHolder._clientSurName;
                        string msgSendMail = string.Empty;

                        msgSendMail = this.SendMail(policyNo, brokerEmail, insuredName);

                        if (string.Compare(msgSendMail.ToUpper().Trim(), "SUCCESS") == 0)
                        {
                            retDeiverDoc = "SUCCESS";
                        }
                    }
                    else
                    {
                        string msgFTP = string.Empty;

                        msgFTP = this.UploadFileToFTP(policyNo, ftpServer, ftpUser, ftpPass);

                        if (string.Compare(msgFTP.ToUpper().Trim(), "SUCCESS") == 0)
                        {
                            retDeiverDoc = "SUCCESS";
                        }
                    }

                    #endregion

                }
                else
                {
                    retMsg = issueMsg + " IN SET AXA POLICY ISSUE PROCESS!!!";
                }
            }
            else
            {
                retMsg += " IN SET AXA JOB PROCESS!!!";
            }
        }

        #endregion        

        ObjAXAHOMEPolicyIssued objPolicyIssued = new ObjAXAHOMEPolicyIssued();
        objPolicyIssued._msg = retMsg;
        objPolicyIssued._deliverDocMsg = retDeiverDoc;
        objPolicyIssued._policyNo = policyNo;

        return objPolicyIssued;
    }
    
    private int CalculateYearPeriods(string effectivedate, string enddate)
    {
        int retValue = 0;
        
        DateTime a = TA.TAUtilities.CheckCultureAndConvertToDateTime(effectivedate);
        DateTime b = TA.TAUtilities.CheckCultureAndConvertToDateTime(enddate);
        long r = TA.TAUtilities.DateDiff(TA.TAUtilities.DateInterval.Year, a, b);

        retValue = (int)r + 1;

        return retValue;
    }

    private string SetAXATAPolicyIssue(string agentCode, string groupBrokerId, string policyType, string packageID, string refInv, string jobNo, out string msg)
    {
        string retMsg = string.Empty;
        string userID = agentCode;

        string policyNo = string.Empty;

        try
        {
            

                #region #-1 GET POLICYNO
                HMTransPolicyBLL getPolicyNo = new HMTransPolicyBLL();
                policyNo = getPolicyNo.spHM_setPolicyNo(jobNo);
                #endregion

                #region #-2 UPDATE POLICYNO TO JOBNO                
                getPolicyNo.spHM_UpdatePolicyNoToJobNo(jobNo, policyNo, refInv);                
                #endregion

                #region #-3 SetTransTaxInvoince                                
                HMTransPolicyBLL tranPolicy = new HMTransPolicyBLL();
                tranPolicy.SetHMTransTaxInvoince(policyNo, jobNo, agentCode);
                #endregion

                #region #-4 SetTransPrint                
                tranPolicy.SetHMTransPrint(policyNo, jobNo, agentCode, groupBrokerId, agentCode);
                #endregion

                #region #-5 SaveFile
                DataTable DTAble = new DataTable();
                HMTransPolicyBLL getPrintListReportName = new HMTransPolicyBLL();

                DTAble = tranPolicy.GetHMPrintListReportName(policyNo);

                string url = QuickLinkConfiguration.UrlReportingServiceNew + DTAble.Rows[0]["ReportName"].ToString() + "&rs:Format=pdf&rs:command=render&JobNo=" + jobNo ;
                this.PrintPolicy(url, policyNo, "00");
                #endregion                
            
        }
        catch (Exception ex)
        {
            retMsg += ex.Message.ToString() + " | ";
        }

        if (retMsg == string.Empty)
            retMsg = "SUCCESS";

        msg = retMsg;

        return policyNo;
    }

    public void PrintPolicy(string url, string policyno, string type)
    {
        string Command = "Render";
        string Format = "PDF";

        System.Net.NetworkCredential Credentials = new System.Net.NetworkCredential();
        Credentials.UserName = "quicklink";
        Credentials.Password = "Password1";
        Credentials.Domain = "bkk.dom";
        //We can get values of these parameters from Request object.

        string URL = url;

        //Specify the path for saving.
        System.IO.DirectoryInfo di = new DirectoryInfo(@Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/DOC/") + policyno);

        if (!di.Exists)
        {
            System.IO.Directory.CreateDirectory(@Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/DOC/") + policyno);

        }

        string path = @Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/DOC/") + policyno + @"\" + policyno + type + @".pdf";


        if (!File.Exists(path))
        {

            System.Net.HttpWebRequest Req = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(URL);
            Req.Credentials = Credentials;
            Req.ContentType = " text/html";


            Req.Method = "GET";


            System.Net.HttpWebResponse objResponse = (System.Net.HttpWebResponse)Req.GetResponse();

            System.IO.FileStream fs = new System.IO.FileStream(path, System.IO.FileMode.Create);

            System.IO.Stream stream = objResponse.GetResponseStream();

            byte[] buf = new byte[1024];

            int len = stream.Read(buf, 0, 1024);

            while (len > 0)
            {

                fs.Write(buf, 0, len);

                len = stream.Read(buf, 0, 1024);

            }

            stream.Close();

            fs.Close();
        }
    }

    private string SendMail(string PolicyNo, string brokerEmail, string insuredName)
    {
        string retMsg = string.Empty;
        string emailFrom = "axatraveller@axa-insurance.co.th";
        string emailTo = brokerEmail;
        string subject = "Confirmation of Home Insurance Schedule";

        string body = "เรียน ท่านนายหน้า/ผู้ออกกรมธรรม์<br/><br/>";
        body += "<p>บริษัท แอกซ่าประกันภัย จำกัด (มหาชน) ขอขอบคุณที่ท่านไว้วางใจให้บริษัทเป็นผู้ให้ความคุ้มครองแก่ลูกค้าของท่าน</p><br/><br/>";
        body += "<p>บริษัทฯ ขอเรียนให้ท่านทราบว่ากรมธรรม์คุณ " + insuredName + "ได้รับความคุ้มครองแล้ว กรมธรรม์เลขที่ " + PolicyNo + " ท่านสามารถพิมพ์กรมธรรม์ และเอกสารต่าง ๆ ที่แนบมากับอีเมล์ฉบับนี้ พร้อมกับแนบเอกสารเงื่อนไขความคุ้มครอง เพื่อจัดส่งให้กับลูกค้าของท่านต่อไป</p><br/>";
        body += "<ol>เอกสารที่ลูกค้าจะได้รับประกอบด้วย";
        body += "<li>หน้าตารางกรมธรรม์</li>";
        body += "<li>ใบแจ้งหนี้ หรือใบกำกับภาษี</li>";
        body += "<li>เอกสารแนบกรมธรรม์ที่ระบุเงื่อนไขการความคุ้มครองโดยละเอียด</li>";
        body += "<li>ซองใส่กรมธรรม์</li>";
        body += "<li> ใบเสร็จรับเงิน (มอบให้กับลูกค้าเมื่อชำระเงินแล้ว พร้อมกับลงชื่อผู้รับเงิน)</li>";
        body += "</ol><br/>";

        body += "<p>บริษัทฯ มีความเชื่อมั่นว่า ท่านได้อธิบายเงื่อนไขความคุ้มครอง และประโยชน์ต่าง ๆ เกี่ยวกับกรมธรรม์ฉบับนี้ให้กับลูกค้าของท่านทราบก่อนตกลงทำประกันภัยแล้ว </p><br/>";

        body += "<p>เพื่อเป็นการรักษาประโยชน์สูงสุดให้กับลูกค้าของท่าน ขอให้ท่านอธิบายเงื่อนความคุ้มครอง และประโยชน์ต่าง ๆ ที่ลูกค้าพึงจะได้รับโดยละเอียดอีกครั้งขณะนำกรมธรรม์ไปมอบให้ </p><br/>";

        body += "<p>ทั้งนี้ หากท่านมีข้อสงสัยประการใด สามารถติดต่อสอบถามกับเจ้าหน้าที่รับประกันภัยที่ดูแลท่านตลอดเวลาทำการ  </p><br/>";

        body += "<p>ขอแสดงความนับถือบริษัท<br/>แอกซ่าประกันภัย จำกัด (มหาชน)</p><br/>";
        body += "<p>โทร. 02-118-8000 </p><br/><br/>";
        body += "<p>บริการช่วยเหลือฉุกเฉิน 24 ชั่วโมง</p><br/>";
        body += "<p>แอกซ่า ฮอตไลน์</p><br/>";
        body += "<p>โทร. 02-642-6688, 02-206-5488</p><br/>";
        body += "<p>เว็บไซด์ : <a href='http://www.axa.co.th' target='_blank'>www.axa.co.th</a></p><br/>";


        try
        {
            //string url = "";
            string type = "00";

            string path = path = Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/DOC/" + PolicyNo);

            string filePath = path + "\\" + PolicyNo + type + ".pdf";

            Utilities.SendMail(emailFrom, emailTo, subject, body, true, filePath);

            retMsg = "SUCCESS";

            //Response.End();
        }
        catch (Exception ex)
        {
            Utilities.LogError(ex);
            retMsg = ex.Message.ToString();
        }

        return retMsg;

    }

    private string UploadFileToFTP(string PolicyNo, string _UploadPath, string _FTPUser, string _FTPPass)
    {
        string retMsg = string.Empty;

        try
        {
            string type = "00";
            string path = path = Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/DOC/" + PolicyNo);
            string filename = PolicyNo + type + ".pdf";
            string filePath = path + "\\" + filename;

            FileStream stream = File.OpenRead(filePath);
            byte[] myData = new Byte[stream.Length];
            stream.Read(myData, 0, myData.Length);
            stream.Close();

            string ftpfullpath = _UploadPath + filename;
            FtpWebRequest ftp = (FtpWebRequest)FtpWebRequest.Create(ftpfullpath);
            ftp.Credentials = new NetworkCredential(_FTPUser, _FTPPass);

            ftp.KeepAlive = true;
            ftp.UseBinary = true;
            ftp.Timeout = 20000; // 20 sec
            ftp.Method = WebRequestMethods.Ftp.UploadFile;

            //FileStream fs = File.OpenRead(_FileName);
            //byte[] buffer = new byte[fs.Length];
            //fs.Read(buffer, 0, buffer.Length);
            //fs.Close();

            Stream ftpstream = ftp.GetRequestStream();
            ftpstream.Write(myData, 0, myData.Length);
            ftpstream.Close();

            retMsg = "SUCCESS";
        }
        catch (Exception ex)
        {
            Utilities.LogError(ex);
            retMsg = ex.Message.ToString();
        }

        return retMsg;
    }


    
}
