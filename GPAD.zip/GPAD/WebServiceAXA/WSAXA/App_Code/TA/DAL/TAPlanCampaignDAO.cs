using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;

namespace TA.DAL
{
	public class TAPlanCampaignDAO
	{
		public TAPlanCampaignDAO()
		{
			DbProviderHelper.GetConnection();
		}
		public List<TAPlanCampaign> GetTAPlanCampaigns()
		{
			try
			{
				List<TAPlanCampaign> lstTAPlanCampaigns = new List<TAPlanCampaign>();
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("SELECT [CampaignCode],[CampaignName],[PercentDiscount],[StartDate],[EndDate],[CampaignType],[isEnabel],[CreatedUser],[CreatedDate] FROM [TAPlanCampaign]",CommandType.Text);
				DbDataReader oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					TAPlanCampaign oTAPlanCampaign = new TAPlanCampaign();
					oTAPlanCampaign.CampaignCode = Convert.ToString(oDbDataReader["CampaignCode"]);

					if(oDbDataReader["CampaignName"] != DBNull.Value)
						oTAPlanCampaign.CampaignName = Convert.ToString(oDbDataReader["CampaignName"]);

					if(oDbDataReader["PercentDiscount"] != DBNull.Value)
						oTAPlanCampaign.PercentDiscount = Convert.ToInt32(oDbDataReader["PercentDiscount"]);

					if(oDbDataReader["StartDate"] != DBNull.Value)
						oTAPlanCampaign.StartDate = Convert.ToDateTime(oDbDataReader["StartDate"]);

					if(oDbDataReader["EndDate"] != DBNull.Value)
						oTAPlanCampaign.EndDate = Convert.ToDateTime(oDbDataReader["EndDate"]);

					if(oDbDataReader["CampaignType"] != DBNull.Value)
						oTAPlanCampaign.CampaignType = Convert.ToInt32(oDbDataReader["CampaignType"]);

					if(oDbDataReader["isEnabel"] != DBNull.Value)
						oTAPlanCampaign.isEnabel = Convert.ToSByte(oDbDataReader["isEnabel"]);

					if(oDbDataReader["CreatedUser"] != DBNull.Value)
						oTAPlanCampaign.CreatedUser = Convert.ToString(oDbDataReader["CreatedUser"]);

					if(oDbDataReader["CreatedDate"] != DBNull.Value)
						oTAPlanCampaign.CreatedDate = Convert.ToDateTime(oDbDataReader["CreatedDate"]);
					lstTAPlanCampaigns.Add(oTAPlanCampaign);
				}
				oDbDataReader.Close();
				return lstTAPlanCampaigns;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public TAPlanCampaign GetTAPlanCampaign(string CampaignCode)
		{
			try
			{
				TAPlanCampaign oTAPlanCampaign = new TAPlanCampaign();
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("SELECT [CampaignCode],[CampaignName],[PercentDiscount],[StartDate],[EndDate],[CampaignType],[isEnabel],[CreatedUser],[CreatedDate] FROM [TAPlanCampaign] WHERE [CampaignCode]=@CampaignCode",CommandType.Text);
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CampaignCode",DbType.String,CampaignCode));
				DbDataReader oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oTAPlanCampaign.CampaignCode = Convert.ToString(oDbDataReader["CampaignCode"]);

					if(oDbDataReader["CampaignName"] != DBNull.Value)
						oTAPlanCampaign.CampaignName = Convert.ToString(oDbDataReader["CampaignName"]);

					if(oDbDataReader["PercentDiscount"] != DBNull.Value)
						oTAPlanCampaign.PercentDiscount = Convert.ToInt32(oDbDataReader["PercentDiscount"]);

					if(oDbDataReader["StartDate"] != DBNull.Value)
						oTAPlanCampaign.StartDate = Convert.ToDateTime(oDbDataReader["StartDate"]);

					if(oDbDataReader["EndDate"] != DBNull.Value)
						oTAPlanCampaign.EndDate = Convert.ToDateTime(oDbDataReader["EndDate"]);

					if(oDbDataReader["CampaignType"] != DBNull.Value)
						oTAPlanCampaign.CampaignType = Convert.ToInt32(oDbDataReader["CampaignType"]);

					if(oDbDataReader["isEnabel"] != DBNull.Value)
						oTAPlanCampaign.isEnabel = Convert.ToSByte(oDbDataReader["isEnabel"]);

					if(oDbDataReader["CreatedUser"] != DBNull.Value)
						oTAPlanCampaign.CreatedUser = Convert.ToString(oDbDataReader["CreatedUser"]);

					if(oDbDataReader["CreatedDate"] != DBNull.Value)
						oTAPlanCampaign.CreatedDate = Convert.ToDateTime(oDbDataReader["CreatedDate"]);
				}
				oDbDataReader.Close();
				return oTAPlanCampaign;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public int AddTAPlanCampaign(string CampaignCode,string CampaignName,Nullable<int> PercentDiscount,Nullable<DateTime> StartDate,Nullable<DateTime> EndDate,Nullable<int> CampaignType,Nullable<SByte> isEnabel,string CreatedUser,Nullable<DateTime> CreatedDate)
		{
			try
			{
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("INSERT INTO [TAPlanCampaign]([CampaignName],[PercentDiscount],[StartDate],[EndDate],[CampaignType],[isEnabel],[CreatedUser],[CreatedDate])VALUES(@CampaignName,@PercentDiscount,@StartDate,@EndDate,@CampaignType,@isEnabel,@CreatedUser,@CreatedDate)",CommandType.Text);
				if (CampaignName!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CampaignName",DbType.String,CampaignName));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CampaignName",DbType.String,DBNull.Value));
				if (PercentDiscount.HasValue)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PercentDiscount",DbType.Int32,PercentDiscount));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PercentDiscount",DbType.Int32,DBNull.Value));
				if (StartDate.HasValue)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@StartDate",DbType.DateTime,StartDate));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@StartDate",DbType.DateTime,DBNull.Value));
				if (EndDate.HasValue)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EndDate",DbType.DateTime,EndDate));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EndDate",DbType.DateTime,DBNull.Value));
				if (CampaignType.HasValue)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CampaignType",DbType.Int32,CampaignType));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CampaignType",DbType.Int32,DBNull.Value));
				if (isEnabel.HasValue)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isEnabel",DbType.SByte,isEnabel));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isEnabel",DbType.SByte,DBNull.Value));
				if (CreatedUser!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreatedUser",DbType.String,CreatedUser));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreatedUser",DbType.String,DBNull.Value));
				if (CreatedDate.HasValue)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreatedDate",DbType.DateTime,CreatedDate));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreatedDate",DbType.DateTime,DBNull.Value));

				return DbProviderHelper.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public int UpdateTAPlanCampaign(string CampaignCode,string CampaignName,Nullable<int> PercentDiscount,Nullable<DateTime> StartDate,Nullable<DateTime> EndDate,Nullable<int> CampaignType,Nullable<SByte> isEnabel,string CreatedUser,Nullable<DateTime> CreatedDate)
		{

			try
			{
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("UPDATE [TAPlanCampaign] SET [CampaignName]=@CampaignName,[PercentDiscount]=@PercentDiscount,[StartDate]=@StartDate,[EndDate]=@EndDate,[CampaignType]=@CampaignType,[isEnabel]=@isEnabel,[CreatedUser]=@CreatedUser,[CreatedDate]=@CreatedDate WHERE [CampaignCode]=@CampaignCode",CommandType.Text);
				if (CampaignName!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CampaignName",DbType.String,CampaignName));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CampaignName",DbType.String,DBNull.Value));
				if (PercentDiscount.HasValue)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PercentDiscount",DbType.Int32,PercentDiscount));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PercentDiscount",DbType.Int32,DBNull.Value));
				if (StartDate.HasValue)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@StartDate",DbType.DateTime,StartDate));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@StartDate",DbType.DateTime,DBNull.Value));
				if (EndDate.HasValue)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EndDate",DbType.DateTime,EndDate));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EndDate",DbType.DateTime,DBNull.Value));
				if (CampaignType.HasValue)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CampaignType",DbType.Int32,CampaignType));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CampaignType",DbType.Int32,DBNull.Value));
				if (isEnabel.HasValue)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isEnabel",DbType.SByte,isEnabel));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isEnabel",DbType.SByte,DBNull.Value));
				if (CreatedUser!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreatedUser",DbType.String,CreatedUser));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreatedUser",DbType.String,DBNull.Value));
				if (CreatedDate.HasValue)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreatedDate",DbType.DateTime,CreatedDate));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreatedDate",DbType.DateTime,DBNull.Value));
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CampaignCode",DbType.String,CampaignCode));
				return DbProviderHelper.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public int RemoveTAPlanCampaign(string CampaignCode)
		{

			try
			{
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("DELETE FROM [TAPlanCampaign] WHERE [CampaignCode]=@CampaignCode",CommandType.Text);
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CampaignCode",DbType.String,CampaignCode));
				return DbProviderHelper.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

        public int spTA_GetCampaignDiscount(int type, string country)
        {            
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = DbProviderHelper.CreateCommand("spTA_GetCampaignDiscount", CommandType.StoredProcedure);
                
                // create parameter and direction
                DbParameter param1 = comm.CreateParameter();
                param1.ParameterName = "@TYPE";
                param1.DbType = DbType.Int32;
                param1.Value = type;
                //param.Size = 20;
                param1.Direction = ParameterDirection.Input;
                comm.Parameters.Add(param1);

                DbParameter param2 = comm.CreateParameter();
                param2.ParameterName = "@Country";
                param2.DbType = DbType.String;
                param2.Size = 200;
                param2.Value = country;
                param2.Direction = ParameterDirection.Input;
                comm.Parameters.Add(param2);

                DbParameter param3 = comm.CreateParameter();
                param3.ParameterName = "@Percent";
                param3.DbType = DbType.Int32;                
                param3.Direction = ParameterDirection.Output;
                comm.Parameters.Add(param3);

                //execute command
                int ret = DbProviderHelper.ExecuteNonQuery(comm);

                //return jobno
                return Convert.ToInt32(comm.Parameters["@Percent"].Value.ToString());              
            }
            catch (Exception ex)
            {               
                Utilities.LogError(ex);
                throw ex;
            }
        }
	}
}
