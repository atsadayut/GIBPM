using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;

namespace TA.DAL
{
	public class TATransLongNameDAO
	{
		public TATransLongNameDAO()
		{
			DbProviderHelper.GetConnection();
		}
		public List<TATransLongName> GetTATransLongNames()
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<TATransLongName> lstTATransLongNames = new List<TATransLongName>();
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("",CommandType.StoredProcedure);
				oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					TATransLongName oTATransLongName = new TATransLongName();
					oTATransLongName.JobNo = Convert.ToString(oDbDataReader["JobNo"]);

					if(oDbDataReader["LongName1"] != DBNull.Value)
						oTATransLongName.LongName1 = Convert.ToString(oDbDataReader["LongName1"]);

					if(oDbDataReader["LongName2"] != DBNull.Value)
						oTATransLongName.LongName2 = Convert.ToString(oDbDataReader["LongName2"]);

					if(oDbDataReader["LongName3"] != DBNull.Value)
						oTATransLongName.LongName3 = Convert.ToString(oDbDataReader["LongName3"]);

					if(oDbDataReader["LongName4"] != DBNull.Value)
						oTATransLongName.LongName4 = Convert.ToString(oDbDataReader["LongName4"]);
					lstTATransLongNames.Add(oTATransLongName);
				}
				oDbDataReader.Close();
				return lstTATransLongNames;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}
		public TATransLongName GetTATransLongName(string JobNo)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				TATransLongName oTATransLongName = new TATransLongName();
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("",CommandType.StoredProcedure);
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo",DbType.String,JobNo));
				oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oTATransLongName.JobNo = Convert.ToString(oDbDataReader["JobNo"]);

					if(oDbDataReader["LongName1"] != DBNull.Value)
						oTATransLongName.LongName1 = Convert.ToString(oDbDataReader["LongName1"]);

					if(oDbDataReader["LongName2"] != DBNull.Value)
						oTATransLongName.LongName2 = Convert.ToString(oDbDataReader["LongName2"]);

					if(oDbDataReader["LongName3"] != DBNull.Value)
						oTATransLongName.LongName3 = Convert.ToString(oDbDataReader["LongName3"]);

					if(oDbDataReader["LongName4"] != DBNull.Value)
						oTATransLongName.LongName4 = Convert.ToString(oDbDataReader["LongName4"]);
				}
				oDbDataReader.Close();
				return oTATransLongName;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}
		public int AddTATransLongName(string JobNo,string LongName1,string LongName2,string LongName3,string LongName4)
		{
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                throw ex;
            }
		}
		public int UpdateTATransLongName(string JobNo,string LongName1,string LongName2,string LongName3,string LongName4)
		{
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                throw ex;
            }
		}
		public int RemoveTATransLongName(string JobNo)
		{
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                throw ex;
            }
		}

        /// <summary>
        /// INSERT/UPDATE
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="LongName1"></param>
        /// <param name="LongName2"></param>
        /// <param name="LongName3"></param>
        /// <param name="LongName4"></param>
        /// <returns></returns>
        public int SetTATransLongName(string JobNo, string LongName1, string LongName2, string LongName3, string LongName4)
        {
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spTA_SetLongName", CommandType.StoredProcedure);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (LongName1 != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LongName1", DbType.String, LongName1));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LongName1", DbType.String, DBNull.Value));
                if (LongName2 != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LongName2", DbType.String, LongName2));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LongName2", DbType.String, DBNull.Value));
                if (LongName3 != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LongName3", DbType.String, LongName3));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LongName3", DbType.String, DBNull.Value));
                if (LongName4 != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LongName4", DbType.String, LongName4));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LongName4", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// INSERT/UPDATE WITH TRANSACTION
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="LongName1"></param>
        /// <param name="LongName2"></param>
        /// <param name="LongName3"></param>
        /// <param name="LongName4"></param>
        /// <param name="dbTransaction"></param>
        /// <returns></returns>
        public int SetTATransLongName(string JobNo, string LongName1, string LongName2, string LongName3, string LongName4, DbTransaction dbTransaction)
        {
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spTA_SetLongName", CommandType.StoredProcedure, dbTransaction);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (LongName1 != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LongName1", DbType.String, LongName1));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LongName1", DbType.String, DBNull.Value));
                if (LongName2 != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LongName2", DbType.String, LongName2));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LongName2", DbType.String, DBNull.Value));
                if (LongName3 != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LongName3", DbType.String, LongName3));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LongName3", DbType.String, DBNull.Value));
                if (LongName4 != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LongName4", DbType.String, LongName4));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LongName4", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand,true);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        /// <summary>
        /// INSERT/UPDATE WITH TRANSACTION
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="LongName1"></param>
        /// <param name="LongName2"></param>
        /// <param name="LongName3"></param>
        /// <param name="LongName4"></param>
        /// <param name="dbTransaction"></param>
        /// <returns></returns>
        public int SetTATransLongName(string JobNo, string LongName1, string LongName2, DbTransaction dbTransaction)
        {
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spTA_SetLongName", CommandType.StoredProcedure, dbTransaction);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (LongName1 != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LongName1", DbType.String, LongName1));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LongName1", DbType.String, DBNull.Value));
                if (LongName2 != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LongName2", DbType.String, LongName2));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LongName2", DbType.String, DBNull.Value));
                
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LongName3", DbType.String, DBNull.Value));
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@LongName4", DbType.String, DBNull.Value));

                

                return DbProviderHelper.ExecuteNonQuery(oDbCommand, true);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        /// <summary>
        /// GET,NOW FUNCTION NOT COMPLETE
        /// </summary>
        /// <returns></returns>
        public DataTable GetDtTATransLongNames()
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = DbProviderHelper.CreateCommand("", CommandType.StoredProcedure);
                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return DbProviderHelper.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

	}
}
