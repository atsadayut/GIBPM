using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;

namespace TA.DAL
{
	public class TAB2CFamilyDAO
	{
		public TAB2CFamilyDAO()
		{
			DbProviderHelper.GetConnection();
		}
		public List<TAB2CFamily> GetTAB2CFamilys()
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<TAB2CFamily> lstTAB2CFamilys = new List<TAB2CFamily>();
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("SELECT [GroupBrokerId],[SEQ],[ClientCode],[ClientType],[ClientTitle],[ClientName],[ClientSurName],[ClientAddress1],[ClientAddress2],[Province],[Amphur],[Tumbol],[PostCode],[CountryCode],[Birthday],[ClientSEX],[ClientStatus],[PassportID],[IDCard],[TaxID],[Tel],[Email],[Language],[CreateDate],[Message] FROM [TAB2CFamily]",CommandType.Text);
				oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					TAB2CFamily oTAB2CFamily = new TAB2CFamily();
					oTAB2CFamily.GroupBrokerId = Convert.ToString(oDbDataReader["GroupBrokerId"]);
					oTAB2CFamily.SEQ = Convert.ToInt32(oDbDataReader["SEQ"]);

					if(oDbDataReader["ClientCode"] != DBNull.Value)
						oTAB2CFamily.ClientCode = Convert.ToString(oDbDataReader["ClientCode"]);

					if(oDbDataReader["ClientType"] != DBNull.Value)
						oTAB2CFamily.ClientType = Convert.ToString(oDbDataReader["ClientType"]);

					if(oDbDataReader["ClientTitle"] != DBNull.Value)
						oTAB2CFamily.ClientTitle = Convert.ToString(oDbDataReader["ClientTitle"]);

					if(oDbDataReader["ClientName"] != DBNull.Value)
						oTAB2CFamily.ClientName = Convert.ToString(oDbDataReader["ClientName"]);

					if(oDbDataReader["ClientSurName"] != DBNull.Value)
						oTAB2CFamily.ClientSurName = Convert.ToString(oDbDataReader["ClientSurName"]);

					if(oDbDataReader["ClientAddress1"] != DBNull.Value)
						oTAB2CFamily.ClientAddress1 = Convert.ToString(oDbDataReader["ClientAddress1"]);

					if(oDbDataReader["ClientAddress2"] != DBNull.Value)
						oTAB2CFamily.ClientAddress2 = Convert.ToString(oDbDataReader["ClientAddress2"]);

					if(oDbDataReader["Province"] != DBNull.Value)
						oTAB2CFamily.Province = Convert.ToString(oDbDataReader["Province"]);

					if(oDbDataReader["Amphur"] != DBNull.Value)
						oTAB2CFamily.Amphur = Convert.ToString(oDbDataReader["Amphur"]);

					if(oDbDataReader["Tumbol"] != DBNull.Value)
						oTAB2CFamily.Tumbol = Convert.ToString(oDbDataReader["Tumbol"]);

					if(oDbDataReader["PostCode"] != DBNull.Value)
						oTAB2CFamily.PostCode = Convert.ToString(oDbDataReader["PostCode"]);

					if(oDbDataReader["CountryCode"] != DBNull.Value)
						oTAB2CFamily.CountryCode = Convert.ToString(oDbDataReader["CountryCode"]);

					if(oDbDataReader["Birthday"] != DBNull.Value)
						oTAB2CFamily.Birthday = Convert.ToDateTime(oDbDataReader["Birthday"]);

					if(oDbDataReader["ClientSEX"] != DBNull.Value)
						oTAB2CFamily.ClientSEX = Convert.ToString(oDbDataReader["ClientSEX"]);

					if(oDbDataReader["ClientStatus"] != DBNull.Value)
						oTAB2CFamily.ClientStatus = Convert.ToString(oDbDataReader["ClientStatus"]);

					if(oDbDataReader["PassportID"] != DBNull.Value)
						oTAB2CFamily.PassportID = Convert.ToString(oDbDataReader["PassportID"]);

					if(oDbDataReader["IDCard"] != DBNull.Value)
						oTAB2CFamily.IDCard = Convert.ToString(oDbDataReader["IDCard"]);

					if(oDbDataReader["TaxID"] != DBNull.Value)
						oTAB2CFamily.TaxID = Convert.ToString(oDbDataReader["TaxID"]);

					if(oDbDataReader["Tel"] != DBNull.Value)
						oTAB2CFamily.Tel = Convert.ToString(oDbDataReader["Tel"]);

					if(oDbDataReader["Email"] != DBNull.Value)
						oTAB2CFamily.Email = Convert.ToString(oDbDataReader["Email"]);

					if(oDbDataReader["Language"] != DBNull.Value)
						oTAB2CFamily.Language = Convert.ToString(oDbDataReader["Language"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oTAB2CFamily.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);

					if(oDbDataReader["Message"] != DBNull.Value)
						oTAB2CFamily.Message = Convert.ToString(oDbDataReader["Message"]);
					lstTAB2CFamilys.Add(oTAB2CFamily);
				}
				oDbDataReader.Close();
				return lstTAB2CFamilys;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}
        public List<TAB2CFamily> GetTAB2CFamily(string GroupBrokerId)
        {
            DbDataReader oDbDataReader = null;
            try
            {
                List<TAB2CFamily> lstTAB2CFamilys = new List<TAB2CFamily>();
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("SELECT [GroupBrokerId],[SEQ],[ClientCode],[ClientType],[ClientTitle],[ClientName],[ClientSurName],[ClientAddress1],[ClientAddress2],[Province],[Amphur],[Tumbol],[PostCode],[CountryCode],[Birthday],[ClientSEX],[ClientStatus],[PassportID],[IDCard],[TaxID],[Tel],[Email],[Language],[CreateDate],[Message] FROM [TAB2CFamily] WHERE [GroupBrokerId] = @GroupBrokerId", CommandType.Text);
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId", DbType.String, GroupBrokerId));
                oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
                while (oDbDataReader.Read())
                {
                    TAB2CFamily oTAB2CFamily = new TAB2CFamily();
                    oTAB2CFamily.GroupBrokerId = Convert.ToString(oDbDataReader["GroupBrokerId"]);
                    oTAB2CFamily.SEQ = Convert.ToInt32(oDbDataReader["SEQ"]);

                    if (oDbDataReader["ClientCode"] != DBNull.Value)
                        oTAB2CFamily.ClientCode = Convert.ToString(oDbDataReader["ClientCode"]);

                    if (oDbDataReader["ClientType"] != DBNull.Value)
                        oTAB2CFamily.ClientType = Convert.ToString(oDbDataReader["ClientType"]);

                    if (oDbDataReader["ClientTitle"] != DBNull.Value)
                        oTAB2CFamily.ClientTitle = Convert.ToString(oDbDataReader["ClientTitle"]);

                    if (oDbDataReader["ClientName"] != DBNull.Value)
                        oTAB2CFamily.ClientName = Convert.ToString(oDbDataReader["ClientName"]);

                    if (oDbDataReader["ClientSurName"] != DBNull.Value)
                        oTAB2CFamily.ClientSurName = Convert.ToString(oDbDataReader["ClientSurName"]);

                    if (oDbDataReader["ClientAddress1"] != DBNull.Value)
                        oTAB2CFamily.ClientAddress1 = Convert.ToString(oDbDataReader["ClientAddress1"]);

                    if (oDbDataReader["ClientAddress2"] != DBNull.Value)
                        oTAB2CFamily.ClientAddress2 = Convert.ToString(oDbDataReader["ClientAddress2"]);

                    if (oDbDataReader["Province"] != DBNull.Value)
                        oTAB2CFamily.Province = Convert.ToString(oDbDataReader["Province"]);

                    if (oDbDataReader["Amphur"] != DBNull.Value)
                        oTAB2CFamily.Amphur = Convert.ToString(oDbDataReader["Amphur"]);

                    if (oDbDataReader["Tumbol"] != DBNull.Value)
                        oTAB2CFamily.Tumbol = Convert.ToString(oDbDataReader["Tumbol"]);

                    if (oDbDataReader["PostCode"] != DBNull.Value)
                        oTAB2CFamily.PostCode = Convert.ToString(oDbDataReader["PostCode"]);

                    if (oDbDataReader["CountryCode"] != DBNull.Value)
                        oTAB2CFamily.CountryCode = Convert.ToString(oDbDataReader["CountryCode"]);

                    if (oDbDataReader["Birthday"] != DBNull.Value)
                        oTAB2CFamily.Birthday = Convert.ToDateTime(oDbDataReader["Birthday"]);

                    if (oDbDataReader["ClientSEX"] != DBNull.Value)
                        oTAB2CFamily.ClientSEX = Convert.ToString(oDbDataReader["ClientSEX"]);

                    if (oDbDataReader["ClientStatus"] != DBNull.Value)
                        oTAB2CFamily.ClientStatus = Convert.ToString(oDbDataReader["ClientStatus"]);

                    if (oDbDataReader["PassportID"] != DBNull.Value)
                        oTAB2CFamily.PassportID = Convert.ToString(oDbDataReader["PassportID"]);

                    if (oDbDataReader["IDCard"] != DBNull.Value)
                        oTAB2CFamily.IDCard = Convert.ToString(oDbDataReader["IDCard"]);

                    if (oDbDataReader["TaxID"] != DBNull.Value)
                        oTAB2CFamily.TaxID = Convert.ToString(oDbDataReader["TaxID"]);

                    if (oDbDataReader["Tel"] != DBNull.Value)
                        oTAB2CFamily.Tel = Convert.ToString(oDbDataReader["Tel"]);

                    if (oDbDataReader["Email"] != DBNull.Value)
                        oTAB2CFamily.Email = Convert.ToString(oDbDataReader["Email"]);

                    if (oDbDataReader["Language"] != DBNull.Value)
                        oTAB2CFamily.Language = Convert.ToString(oDbDataReader["Language"]);

                    if (oDbDataReader["CreateDate"] != DBNull.Value)
                        oTAB2CFamily.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);

                    if (oDbDataReader["Message"] != DBNull.Value)
                        oTAB2CFamily.Message = Convert.ToString(oDbDataReader["Message"]);

                    lstTAB2CFamilys.Add(oTAB2CFamily);
                }
                oDbDataReader.Close();
                return lstTAB2CFamilys;
            }
            catch (Exception ex)
            {
                oDbDataReader.Close();
                throw ex;
            }
        }
		public TAB2CFamily GetTAB2CFamily(string GroupBrokerId,int SEQ)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				TAB2CFamily oTAB2CFamily = new TAB2CFamily();
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("SELECT [GroupBrokerId],[SEQ],[ClientCode],[ClientType],[ClientTitle],[ClientName],[ClientSurName],[ClientAddress1],[ClientAddress2],[Province],[Amphur],[Tumbol],[PostCode],[CountryCode],[Birthday],[ClientSEX],[ClientStatus],[PassportID],[IDCard],[TaxID],[Tel],[Email],[Language],[CreateDate],[Message] FROM [TAB2CFamily] WHERE [GroupBrokerId]=@GroupBrokerId AND [SEQ]=@SEQ",CommandType.Text);
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId",DbType.String,GroupBrokerId));
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@SEQ",DbType.Int32,SEQ));
				oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oTAB2CFamily.GroupBrokerId = Convert.ToString(oDbDataReader["GroupBrokerId"]);
					oTAB2CFamily.SEQ = Convert.ToInt32(oDbDataReader["SEQ"]);

					if(oDbDataReader["ClientCode"] != DBNull.Value)
						oTAB2CFamily.ClientCode = Convert.ToString(oDbDataReader["ClientCode"]);

					if(oDbDataReader["ClientType"] != DBNull.Value)
						oTAB2CFamily.ClientType = Convert.ToString(oDbDataReader["ClientType"]);

					if(oDbDataReader["ClientTitle"] != DBNull.Value)
						oTAB2CFamily.ClientTitle = Convert.ToString(oDbDataReader["ClientTitle"]);

					if(oDbDataReader["ClientName"] != DBNull.Value)
						oTAB2CFamily.ClientName = Convert.ToString(oDbDataReader["ClientName"]);

					if(oDbDataReader["ClientSurName"] != DBNull.Value)
						oTAB2CFamily.ClientSurName = Convert.ToString(oDbDataReader["ClientSurName"]);

					if(oDbDataReader["ClientAddress1"] != DBNull.Value)
						oTAB2CFamily.ClientAddress1 = Convert.ToString(oDbDataReader["ClientAddress1"]);

					if(oDbDataReader["ClientAddress2"] != DBNull.Value)
						oTAB2CFamily.ClientAddress2 = Convert.ToString(oDbDataReader["ClientAddress2"]);

					if(oDbDataReader["Province"] != DBNull.Value)
						oTAB2CFamily.Province = Convert.ToString(oDbDataReader["Province"]);

					if(oDbDataReader["Amphur"] != DBNull.Value)
						oTAB2CFamily.Amphur = Convert.ToString(oDbDataReader["Amphur"]);

					if(oDbDataReader["Tumbol"] != DBNull.Value)
						oTAB2CFamily.Tumbol = Convert.ToString(oDbDataReader["Tumbol"]);

					if(oDbDataReader["PostCode"] != DBNull.Value)
						oTAB2CFamily.PostCode = Convert.ToString(oDbDataReader["PostCode"]);

					if(oDbDataReader["CountryCode"] != DBNull.Value)
						oTAB2CFamily.CountryCode = Convert.ToString(oDbDataReader["CountryCode"]);

					if(oDbDataReader["Birthday"] != DBNull.Value)
						oTAB2CFamily.Birthday = Convert.ToDateTime(oDbDataReader["Birthday"]);

					if(oDbDataReader["ClientSEX"] != DBNull.Value)
						oTAB2CFamily.ClientSEX = Convert.ToString(oDbDataReader["ClientSEX"]);

					if(oDbDataReader["ClientStatus"] != DBNull.Value)
						oTAB2CFamily.ClientStatus = Convert.ToString(oDbDataReader["ClientStatus"]);

					if(oDbDataReader["PassportID"] != DBNull.Value)
						oTAB2CFamily.PassportID = Convert.ToString(oDbDataReader["PassportID"]);

					if(oDbDataReader["IDCard"] != DBNull.Value)
						oTAB2CFamily.IDCard = Convert.ToString(oDbDataReader["IDCard"]);

					if(oDbDataReader["TaxID"] != DBNull.Value)
						oTAB2CFamily.TaxID = Convert.ToString(oDbDataReader["TaxID"]);

					if(oDbDataReader["Tel"] != DBNull.Value)
						oTAB2CFamily.Tel = Convert.ToString(oDbDataReader["Tel"]);

					if(oDbDataReader["Email"] != DBNull.Value)
						oTAB2CFamily.Email = Convert.ToString(oDbDataReader["Email"]);

					if(oDbDataReader["Language"] != DBNull.Value)
						oTAB2CFamily.Language = Convert.ToString(oDbDataReader["Language"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oTAB2CFamily.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);

					if(oDbDataReader["Message"] != DBNull.Value)
						oTAB2CFamily.Message = Convert.ToString(oDbDataReader["Message"]);
				}
				oDbDataReader.Close();
				return oTAB2CFamily;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}
        public int AddTAB2CFamily(string GroupBrokerId, int SEQ, string ClientCode, string ClientType, string ClientTitle, string ClientName, string ClientSurName, string ClientAddress1, string ClientAddress2, string Province, string Amphur, string Tumbol, string PostCode, string CountryCode, string Birthday, string ClientSEX, string ClientStatus, string PassportID, string IDCard, string TaxID, string Tel, string Email, string Language, Nullable<DateTime> CreateDate, string Message)
		{
			try
			{
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("INSERT INTO [TAB2CFamily]([GroupBrokerId],[Seq],[ClientCode],[ClientType],[ClientTitle],[ClientName],[ClientSurName],[ClientAddress1],[ClientAddress2],[Province],[Amphur],[Tumbol],[PostCode],[CountryCode],[Birthday],[ClientSEX],[ClientStatus],[PassportID],[IDCard],[TaxID],[Tel],[Email],[Language],[CreateDate],[Message])VALUES(@GroupBrokerId,@SEQ,@ClientCode,@ClientType,@ClientTitle,@ClientName,@ClientSurName,@ClientAddress1,@ClientAddress2,@Province,@Amphur,@Tumbol,@PostCode,@CountryCode,@Birthday,@ClientSEX,@ClientStatus,@PassportID,@IDCard,@TaxID,@Tel,@Email,@Language,@CreateDate,@Message)", CommandType.Text);
                if (GroupBrokerId != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId", DbType.String, GroupBrokerId));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId", DbType.String, DBNull.Value));
                if (SEQ != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@SEQ", DbType.Int32, SEQ));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@SEQ", DbType.Int32, DBNull.Value));
				
				if (ClientCode!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientCode",DbType.String,ClientCode));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientCode",DbType.String,DBNull.Value));
				if (ClientType!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientType",DbType.String,ClientType));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientType",DbType.String,DBNull.Value));
				if (ClientTitle!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientTitle",DbType.String,ClientTitle));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientTitle",DbType.String,DBNull.Value));
				if (ClientName!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientName",DbType.String,ClientName));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientName",DbType.String,DBNull.Value));
				if (ClientSurName!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSurName",DbType.String,ClientSurName));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSurName",DbType.String,DBNull.Value));
				if (ClientAddress1!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientAddress1",DbType.String,ClientAddress1));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientAddress1",DbType.String,DBNull.Value));
				if (ClientAddress2!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientAddress2",DbType.String,ClientAddress2));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientAddress2",DbType.String,DBNull.Value));
				if (Province!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Province",DbType.String,Province));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Province",DbType.String,DBNull.Value));
				if (Amphur!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Amphur",DbType.String,Amphur));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Amphur",DbType.String,DBNull.Value));
				if (Tumbol!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tumbol",DbType.String,Tumbol));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tumbol",DbType.String,DBNull.Value));
				if (PostCode!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PostCode",DbType.String,PostCode));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PostCode",DbType.String,DBNull.Value));
				if (CountryCode!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CountryCode",DbType.String,CountryCode));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CountryCode",DbType.String,DBNull.Value));
				if (Birthday != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Birthday", DbType.String, Birthday));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Birthday", DbType.String, DBNull.Value));
				if (ClientSEX!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSEX",DbType.String,ClientSEX));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSEX",DbType.String,DBNull.Value));
				if (ClientStatus!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientStatus",DbType.String,ClientStatus));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientStatus",DbType.String,DBNull.Value));
				if (PassportID!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PassportID",DbType.String,PassportID));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PassportID",DbType.String,DBNull.Value));
				if (IDCard!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@IDCard",DbType.String,IDCard));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@IDCard",DbType.String,DBNull.Value));
				if (TaxID!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TaxID",DbType.String,TaxID));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TaxID",DbType.String,DBNull.Value));
				if (Tel!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tel",DbType.String,Tel));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tel",DbType.String,DBNull.Value));
				if (Email!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Email",DbType.String,Email));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Email",DbType.String,DBNull.Value));
				if (Language!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Language",DbType.String,Language));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Language",DbType.String,DBNull.Value));
				if (CreateDate.HasValue)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreateDate",DbType.DateTime,CreateDate));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreateDate",DbType.DateTime,DBNull.Value));
				if (Message!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Message",DbType.String,Message));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Message",DbType.String,DBNull.Value));

				return DbProviderHelper.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
        public int UpdateTAB2CFamily(string GroupBrokerId, int SEQ, string ClientCode, string ClientType, string ClientTitle, string ClientName, string ClientSurName, string ClientAddress1, string ClientAddress2, string Province, string Amphur, string Tumbol, string PostCode, string CountryCode, string Birthday, string ClientSEX, string ClientStatus, string PassportID, string IDCard, string TaxID, string Tel, string Email, string Language, Nullable<DateTime> CreateDate, string Message)
		{

			try
			{
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("UPDATE [TAB2CFamily] SET [ClientCode]=@ClientCode,[ClientType]=@ClientType,[ClientTitle]=@ClientTitle,[ClientName]=@ClientName,[ClientSurName]=@ClientSurName,[ClientAddress1]=@ClientAddress1,[ClientAddress2]=@ClientAddress2,[Province]=@Province,[Amphur]=@Amphur,[Tumbol]=@Tumbol,[PostCode]=@PostCode,[CountryCode]=@CountryCode,[Birthday]=@Birthday,[ClientSEX]=@ClientSEX,[ClientStatus]=@ClientStatus,[PassportID]=@PassportID,[IDCard]=@IDCard,[TaxID]=@TaxID,[Tel]=@Tel,[Email]=@Email,[Language]=@Language,[CreateDate]=@CreateDate,[Message]=@Message WHERE [GroupBrokerId]=@GroupBrokerId AND [SEQ]=@SEQ",CommandType.Text);
				if (ClientCode!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientCode",DbType.String,ClientCode));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientCode",DbType.String,DBNull.Value));
				if (ClientType!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientType",DbType.String,ClientType));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientType",DbType.String,DBNull.Value));
				if (ClientTitle!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientTitle",DbType.String,ClientTitle));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientTitle",DbType.String,DBNull.Value));
				if (ClientName!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientName",DbType.String,ClientName));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientName",DbType.String,DBNull.Value));
				if (ClientSurName!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSurName",DbType.String,ClientSurName));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSurName",DbType.String,DBNull.Value));
				if (ClientAddress1!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientAddress1",DbType.String,ClientAddress1));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientAddress1",DbType.String,DBNull.Value));
				if (ClientAddress2!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientAddress2",DbType.String,ClientAddress2));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientAddress2",DbType.String,DBNull.Value));
				if (Province!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Province",DbType.String,Province));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Province",DbType.String,DBNull.Value));
				if (Amphur!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Amphur",DbType.String,Amphur));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Amphur",DbType.String,DBNull.Value));
				if (Tumbol!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tumbol",DbType.String,Tumbol));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tumbol",DbType.String,DBNull.Value));
				if (PostCode!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PostCode",DbType.String,PostCode));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PostCode",DbType.String,DBNull.Value));
				if (CountryCode!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CountryCode",DbType.String,CountryCode));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CountryCode",DbType.String,DBNull.Value));
				if (Birthday != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Birthday", DbType.String, Birthday));
				else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Birthday", DbType.String, DBNull.Value));
				if (ClientSEX!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSEX",DbType.String,ClientSEX));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSEX",DbType.String,DBNull.Value));
				if (ClientStatus!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientStatus",DbType.String,ClientStatus));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientStatus",DbType.String,DBNull.Value));
				if (PassportID!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PassportID",DbType.String,PassportID));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PassportID",DbType.String,DBNull.Value));
				if (IDCard!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@IDCard",DbType.String,IDCard));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@IDCard",DbType.String,DBNull.Value));
				if (TaxID!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TaxID",DbType.String,TaxID));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TaxID",DbType.String,DBNull.Value));
				if (Tel!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tel",DbType.String,Tel));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tel",DbType.String,DBNull.Value));
				if (Email!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Email",DbType.String,Email));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Email",DbType.String,DBNull.Value));
				if (Language!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Language",DbType.String,Language));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Language",DbType.String,DBNull.Value));
				if (CreateDate.HasValue)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreateDate",DbType.DateTime,CreateDate));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreateDate",DbType.DateTime,DBNull.Value));
				if (Message!=null)
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Message",DbType.String,Message));
				else
					oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Message",DbType.String,DBNull.Value));
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId",DbType.String,GroupBrokerId));
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@SEQ",DbType.Int32,SEQ));
				return DbProviderHelper.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public int RemoveTAB2CFamily(string GroupBrokerId,int SEQ)
		{

			try
			{
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("DELETE FROM [TAB2CFamily] WHERE [GroupBrokerId]=@GroupBrokerId AND [SEQ]=@SEQ",CommandType.Text);
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId",DbType.String,GroupBrokerId));
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@SEQ",DbType.Int32,SEQ));
				return DbProviderHelper.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}
