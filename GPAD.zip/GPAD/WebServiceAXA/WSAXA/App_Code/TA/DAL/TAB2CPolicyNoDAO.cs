using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;

namespace TA.DAL
{
	public class TAB2CPolicyNoDAO
	{
		public TAB2CPolicyNoDAO()
		{
			DbProviderHelper.GetConnection();
		}
		public List<TAB2CPolicyNo> GetTAB2CPolicyNos()
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<TAB2CPolicyNo> lstTAB2CPolicyNos = new List<TAB2CPolicyNo>();
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("SELECT [PREFIX],[RUNNING] FROM [TAB2CPolicyNo]",CommandType.Text);
				oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					TAB2CPolicyNo oTAB2CPolicyNo = new TAB2CPolicyNo();
					oTAB2CPolicyNo.PREFIX = Convert.ToString(oDbDataReader["PREFIX"]);
					oTAB2CPolicyNo.RUNNING = Convert.ToInt32(oDbDataReader["RUNNING"]);
					lstTAB2CPolicyNos.Add(oTAB2CPolicyNo);
				}
				oDbDataReader.Close();
				return lstTAB2CPolicyNos;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}
		public TAB2CPolicyNo GetTAB2CPolicyNo(string PREFIX,int RUNNING)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				TAB2CPolicyNo oTAB2CPolicyNo = new TAB2CPolicyNo();
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("SELECT [PREFIX],[RUNNING] FROM [TAB2CPolicyNo] WHERE [PREFIX]=@PREFIX AND [RUNNING]=@RUNNING",CommandType.Text);
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PREFIX",DbType.String,PREFIX));
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@RUNNING",DbType.Int32,RUNNING));
				oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oTAB2CPolicyNo.PREFIX = Convert.ToString(oDbDataReader["PREFIX"]);
					oTAB2CPolicyNo.RUNNING = Convert.ToInt32(oDbDataReader["RUNNING"]);
				}
				oDbDataReader.Close();
				return oTAB2CPolicyNo;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}
		public int AddTAB2CPolicyNo(string PREFIX,int RUNNING)
		{
			try
			{
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("INSERT INTO [TAB2CPolicyNo]()VALUES()",CommandType.Text);

				return DbProviderHelper.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public int RemoveTAB2CPolicyNo(string PREFIX,int RUNNING)
		{

			try
			{
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("DELETE FROM [TAB2CPolicyNo] WHERE [PREFIX]=@PREFIX AND [RUNNING]=@RUNNING",CommandType.Text);
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PREFIX",DbType.String,PREFIX));
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@RUNNING",DbType.Int32,RUNNING));
				return DbProviderHelper.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

        public string spTAB2C_SetPolicyNo()
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = DbProviderHelper.CreateCommand("spTAB2C_SetPolicyNo", CommandType.StoredProcedure);

                // create parameter and direction
                DbParameter param = comm.CreateParameter();
                param.ParameterName = "@PolicyNo";
                param.DbType = DbType.String;
                param.Size = 20;
                param.Direction = ParameterDirection.Output;
                comm.Parameters.Add(param);

                //execute command
                int ret = DbProviderHelper.ExecuteNonQuery(comm);

                //return jobno
                return param.Value.ToString();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public string spTAB2C_SetPolicyNo(string JobNo)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = DbProviderHelper.CreateCommand("spTAB2C_SetPolicyNoByJobNo", CommandType.StoredProcedure);

                // create parameter and direction
                DbParameter param = comm.CreateParameter();
                param.ParameterName = "@PolicyNo";
                param.DbType = DbType.String;
                param.Size = 20;
                param.Direction = ParameterDirection.Output;
                comm.Parameters.Add(param);

                DbParameter param2 = comm.CreateParameter();
                param2.ParameterName = "@JobNo";
                param2.DbType = DbType.String;
                param2.Size = 200;
                param2.Value = JobNo;
                param2.Direction = ParameterDirection.Input;
                comm.Parameters.Add(param2);

                //execute command
                int ret = DbProviderHelper.ExecuteNonQuery(comm);

                //return jobno
                return param.Value.ToString();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public int spTAB2C_UpdatePolicyNoToJobNo(string JobNo, string PolicyNo, string RETURNINV)
        {
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("UPDATE [TATransPolicy] SET [PolicyNo]=@PolicyNo, [RETURNINV] = @RETURNINV WHERE [JobNo] = @JobNo", CommandType.Text);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (PolicyNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, PolicyNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, DBNull.Value));

                if (RETURNINV != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@RETURNINV", DbType.String, RETURNINV));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@RETURNINV", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //Krit Update 20150317
        public DataTable spTAB2C_FindPolicyNoByRef(string RETURNINV)
        {
            DbDataReader oDbDataReader = null;
            try
            {
                DataTable result = new DataTable();
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("SELECT [PolicyNo],[PolicyType],[InsurancePlan] FROM [TATransPolicy] where RETURNINV = @RETURNINV", CommandType.Text);
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@RETURNINV", DbType.String, RETURNINV));
                oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);

                result.Load(oDbDataReader);
                
                oDbDataReader.Close();

                return result;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

	}
}
