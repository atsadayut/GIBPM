using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;

namespace TA.DAL
{
	public class TAPlanPremuimDAO
	{
		public TAPlanPremuimDAO()
		{
			DbProviderHelper.GetConnection();
		}
		public List<TAPlanPremuim> GetTAPlanPremuims()
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<TAPlanPremuim> lstTAPlanPremuims = new List<TAPlanPremuim>();
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("",CommandType.StoredProcedure);
				oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					TAPlanPremuim oTAPlanPremuim = new TAPlanPremuim();
					oTAPlanPremuim.PlanID = Convert.ToString(oDbDataReader["PlanID"]);
					oTAPlanPremuim.PolicyType = Convert.ToString(oDbDataReader["PolicyType"]);
					oTAPlanPremuim.TravelPlan = Convert.ToString(oDbDataReader["TravelPlan"]);
					oTAPlanPremuim.DurationFrom = Convert.ToInt32(oDbDataReader["DurationFrom"]);
					oTAPlanPremuim.DurationTo = Convert.ToInt32(oDbDataReader["DurationTo"]);

					if(oDbDataReader["NetPremium"] != DBNull.Value)
						oTAPlanPremuim.NetPremium = Convert.ToDouble(oDbDataReader["NetPremium"]);

					if(oDbDataReader["isEnabel"] != DBNull.Value)
						oTAPlanPremuim.isEnabel = Convert.ToSByte(oDbDataReader["isEnabel"]);

					if(oDbDataReader["CreatedDate"] != DBNull.Value)
						oTAPlanPremuim.CreatedDate = Convert.ToDateTime(oDbDataReader["CreatedDate"]);

					if(oDbDataReader["CreatedUser"] != DBNull.Value)
						oTAPlanPremuim.CreatedUser = Convert.ToString(oDbDataReader["CreatedUser"]);
					lstTAPlanPremuims.Add(oTAPlanPremuim);
				}
				oDbDataReader.Close();
				return lstTAPlanPremuims;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public TAPlanPremuim GetTAPlanPremuim(string PlanID,string PolicyType,string TravelPlan,int DurationFrom,int DurationTo)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				TAPlanPremuim oTAPlanPremuim = new TAPlanPremuim();
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("",CommandType.StoredProcedure);
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PlanID",DbType.String,PlanID));
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyType",DbType.String,PolicyType));
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TravelPlan",DbType.String,TravelPlan));
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@DurationFrom",DbType.Int32,DurationFrom));
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@DurationTo",DbType.Int32,DurationTo));
				oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oTAPlanPremuim.PlanID = Convert.ToString(oDbDataReader["PlanID"]);
					oTAPlanPremuim.PolicyType = Convert.ToString(oDbDataReader["PolicyType"]);
					oTAPlanPremuim.TravelPlan = Convert.ToString(oDbDataReader["TravelPlan"]);
					oTAPlanPremuim.DurationFrom = Convert.ToInt32(oDbDataReader["DurationFrom"]);
					oTAPlanPremuim.DurationTo = Convert.ToInt32(oDbDataReader["DurationTo"]);

					if(oDbDataReader["NetPremium"] != DBNull.Value)
						oTAPlanPremuim.NetPremium = Convert.ToDouble(oDbDataReader["NetPremium"]);

					if(oDbDataReader["isEnabel"] != DBNull.Value)
						oTAPlanPremuim.isEnabel = Convert.ToSByte(oDbDataReader["isEnabel"]);

					if(oDbDataReader["CreatedDate"] != DBNull.Value)
						oTAPlanPremuim.CreatedDate = Convert.ToDateTime(oDbDataReader["CreatedDate"]);

					if(oDbDataReader["CreatedUser"] != DBNull.Value)
						oTAPlanPremuim.CreatedUser = Convert.ToString(oDbDataReader["CreatedUser"]);
				}
				oDbDataReader.Close();
				return oTAPlanPremuim;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public int AddTAPlanPremuim(string PlanID,string PolicyType,string TravelPlan,int DurationFrom,int DurationTo,Nullable<Double> NetPremium,Nullable<SByte> isEnabel,Nullable<DateTime> CreatedDate,string CreatedUser)
		{
			try
			{
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("",CommandType.StoredProcedure);
                //Add Parameters 
				return DbProviderHelper.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public int UpdateTAPlanPremuim(string PlanID,string PolicyType,string TravelPlan,int DurationFrom,int DurationTo,Nullable<Double> NetPremium,Nullable<SByte> isEnabel,Nullable<DateTime> CreatedDate,string CreatedUser)
		{

			try
			{
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("",CommandType.StoredProcedure);
                //Add Parameters 
				return DbProviderHelper.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public int RemoveTAPlanPremuim(string PlanID,string PolicyType,string TravelPlan,int DurationFrom,int DurationTo)
		{

			try
			{
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("",CommandType.StoredProcedure);
                //Add Parameters 
				return DbProviderHelper.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}

        /// <summary>
        /// INSERT/UPDATE
        /// </summary>
        /// <param name="PlanID"></param>
        /// <param name="PolicyType"></param>
        /// <param name="TravelPlan"></param>
        /// <param name="DurationFrom"></param>
        /// <param name="DurationTo"></param>
        /// <param name="NetPremium"></param>
        /// <param name="isEnabel"></param>
        /// <param name="CreatedDate"></param>
        /// <param name="CreatedUser"></param>
        /// <returns></returns>
        public int SetTAPlanPremuim(string PlanID, string PolicyType, string TravelPlan, int DurationFrom, int DurationTo, Nullable<Double> NetPremium, Nullable<SByte> isEnabel, Nullable<DateTime> CreatedDate, string CreatedUser)
        {
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        /// <summary>
        /// GET
        /// </summary>
        /// <param name="PlanID"></param>
        /// <param name="Duration"></param>
        /// <param name="TravelPlan"></param>
        /// <returns></returns>
        public DataTable GetDtTAPlanPremuims(string PlanID, int Duration, string TravelPlan)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = DbProviderHelper.CreateCommand("spTA_GetPremium", CommandType.StoredProcedure);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@PlanID", DbType.String, PlanID));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@Duration", DbType.Int32, Duration));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@TravelPlan", DbType.String, TravelPlan));      
                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return DbProviderHelper.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        /// <summary>
        /// GET
        /// </summary>
        /// <param name="PlanID"></param>
        /// <param name="Duration"></param>
        /// <param name="TravelPlan"></param>
        /// <returns></returns>
        public TAPremuim GetTAPremuim(string PlanID, int Duration, string TravelPlan)
        {
            DbDataReader oDbDataReader = null;
            try
            {
                // get a configured & create DbCommand object
                TAPremuim premium = new TAPremuim();
                DbCommand comm = DbProviderHelper.CreateCommand("spTA_GetPremium", CommandType.StoredProcedure);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@PlanID", DbType.String, PlanID));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@Duration", DbType.Int32, Duration));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@TravelPlan", DbType.String, TravelPlan));

                oDbDataReader = DbProviderHelper.ExecuteReader(comm);
                while (oDbDataReader.Read())
                {
                    premium.NetPremium = Convert.ToString(oDbDataReader["NetPremium"]);
                    premium.Stamp = Convert.ToString(oDbDataReader["Stamp"]);
                    premium.TAX = Convert.ToString(oDbDataReader["TAX"]);
                    premium.Total = Convert.ToString(oDbDataReader["Total"]);
                    premium.PersonalAccident = Convert.ToString(oDbDataReader["PersonalAccident"]);
                }
                oDbDataReader.Close();
                return premium;
            }
            catch (Exception ex)
            {
                oDbDataReader.Close();
                Utilities.LogError(ex);
                throw ex;
            }
        }

        //----------------------------------------------------------------------------------------------
        public DataTable GetAllTAPlanPremuim(string PlanID, string TravelPlan)
        {
            try
            {
                // get a configured & create DbCommand object
                TAPremuim premium = new TAPremuim();
                DbCommand comm = DbProviderHelper.CreateCommand("select * from [TAPlanPremuim] where [PlanID] = @PlanID and [TravelPlan] = @TravelPlan", CommandType.Text);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@PlanID", DbType.String, PlanID));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@TravelPlan", DbType.String, TravelPlan));

                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return DbProviderHelper.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        public int SetTAPlanPremuim(string PlanID, string PolicyType, string TravelPlan, int DurationFrom, int DurationTo, Nullable<Double> NetPremium, Nullable<SByte> isEnabel,  string CreatedUser)
        {
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("update [TAPlanPremuim] set [NetPremium] = @NetPremium, [isEnabel] = @isEnabel, [CreatedDate] = GETDATE(),[CreatedUser] = @CreatedUser where [PlanID] = @PlanID and [PolicyType]=@PolicyType and [TravelPlan]=@TravelPlan and [DurationFrom]=@DurationFrom and [DurationTo]=@DurationTo ", CommandType.Text);
                //Add Parameters 
                if (PlanID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PlanID", DbType.String, PlanID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PlanID", DbType.String, DBNull.Value));
                if (PolicyType != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyType", DbType.String, PolicyType));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyType", DbType.String, DBNull.Value));
                if (TravelPlan != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TravelPlan", DbType.String, TravelPlan));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TravelPlan", DbType.String, DBNull.Value));
                if (DurationFrom != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@DurationFrom", DbType.Int32, DurationFrom));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@DurationFrom", DbType.Int32, DBNull.Value));
                if (DurationTo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@DurationTo", DbType.Int32, DurationTo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@DurationTo", DbType.Int32, DBNull.Value));
                if (NetPremium != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NetPremium", DbType.Double, NetPremium));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NetPremium", DbType.Double, DBNull.Value));
                if (isEnabel != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isEnabel", DbType.Byte, isEnabel));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isEnabel", DbType.Byte, DBNull.Value));
                if (CreatedUser != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreatedUser", DbType.String, CreatedUser));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreatedUser", DbType.String, DBNull.Value));


                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        public DataTable spTAB2C_GetPremium(int Duration)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = DbProviderHelper.CreateCommand("spTAB2C_GetPremium", CommandType.StoredProcedure);                
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@Duration", DbType.Int32, Duration));                
                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return DbProviderHelper.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
       
	}
}
