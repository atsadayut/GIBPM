using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;

namespace TA.DAL
{
	public class TAB2CTAXNoDAO
	{
		public TAB2CTAXNoDAO()
		{
			DbProviderHelper.GetConnection();
		}
		public List<TAB2CTAXNo> GetTAB2CTAXNos()
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<TAB2CTAXNo> lstTAB2CTAXNos = new List<TAB2CTAXNo>();
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("SELECT [PREFIX],[RUNNING] FROM [TAB2CTAXNo]",CommandType.Text);
				oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					TAB2CTAXNo oTAB2CTAXNo = new TAB2CTAXNo();
					oTAB2CTAXNo.PREFIX = Convert.ToString(oDbDataReader["PREFIX"]);
					oTAB2CTAXNo.RUNNING = Convert.ToInt32(oDbDataReader["RUNNING"]);
					lstTAB2CTAXNos.Add(oTAB2CTAXNo);
				}
				oDbDataReader.Close();
				return lstTAB2CTAXNos;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}
		public int AddTAB2CTAXNo(string PREFIX,int RUNNING)
		{
			try
			{
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("INSERT INTO [TAB2CTAXNo]([PREFIX],[RUNNING])VALUES(@PREFIX,@RUNNING)",CommandType.Text);
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PREFIX",DbType.String,PREFIX));
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@RUNNING",DbType.Int32,RUNNING));

				return DbProviderHelper.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

        public string spTAB2C_SetTAXNo()
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = DbProviderHelper.CreateCommand("spTAB2C_SetTAXNo", CommandType.StoredProcedure);

                // create parameter and direction
                DbParameter param = comm.CreateParameter();
                param.ParameterName = "@TAXNo";
                param.DbType = DbType.String;
                param.Size = 20;
                param.Direction = ParameterDirection.Output;
                comm.Parameters.Add(param);

                //execute command
                int ret = DbProviderHelper.ExecuteNonQuery(comm);

                //return jobno
                return param.Value.ToString();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
	}
}
