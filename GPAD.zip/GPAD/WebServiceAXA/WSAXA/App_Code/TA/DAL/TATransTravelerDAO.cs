using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;

namespace TA.DAL
{
	public class TATransTravelerDAO
	{
		public TATransTravelerDAO()
		{
			DbProviderHelper.GetConnection();
		}
		public List<TATransTraveler> GetTATransTravelers()
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<TATransTraveler> lstTATransTravelers = new List<TATransTraveler>();
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("",CommandType.StoredProcedure);
				oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					TATransTraveler oTATransTraveler = new TATransTraveler();
					oTATransTraveler.JobNo = Convert.ToString(oDbDataReader["JobNo"]);
					oTATransTraveler.TravelerId = Convert.ToInt32(oDbDataReader["TravelerId"]);

					if(oDbDataReader["ClientTitle"] != DBNull.Value)
						oTATransTraveler.ClientTitle = Convert.ToString(oDbDataReader["ClientTitle"]);

					if(oDbDataReader["ClientName"] != DBNull.Value)
						oTATransTraveler.ClientName = Convert.ToString(oDbDataReader["ClientName"]);

					if(oDbDataReader["ClientSurName"] != DBNull.Value)
						oTATransTraveler.ClientSurName = Convert.ToString(oDbDataReader["ClientSurName"]);

					if(oDbDataReader["Birthday"] != DBNull.Value)
						oTATransTraveler.Birthday = Convert.ToString(oDbDataReader["Birthday"]);

					if(oDbDataReader["PassportID"] != DBNull.Value)
						oTATransTraveler.PassportID = Convert.ToString(oDbDataReader["PassportID"]);

					if(oDbDataReader["Tel"] != DBNull.Value)
						oTATransTraveler.Tel = Convert.ToString(oDbDataReader["Tel"]);

					if(oDbDataReader["isStudent"] != DBNull.Value)
						oTATransTraveler.isStudent = Convert.ToSByte(oDbDataReader["isStudent"]);

					if(oDbDataReader["isSingle"] != DBNull.Value)
						oTATransTraveler.isSingle = Convert.ToSByte(oDbDataReader["isSingle"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oTATransTraveler.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);
					lstTATransTravelers.Add(oTATransTraveler);
				}
				oDbDataReader.Close();
				return lstTATransTravelers;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public TATransTraveler GetTATransTraveler(string JobNo,int TravelerId)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				TATransTraveler oTATransTraveler = new TATransTraveler();
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("",CommandType.StoredProcedure);
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo",DbType.String,JobNo));
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TravelerId",DbType.Int32,TravelerId));
				oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oTATransTraveler.JobNo = Convert.ToString(oDbDataReader["JobNo"]);
					oTATransTraveler.TravelerId = Convert.ToInt32(oDbDataReader["TravelerId"]);

					if(oDbDataReader["ClientTitle"] != DBNull.Value)
						oTATransTraveler.ClientTitle = Convert.ToString(oDbDataReader["ClientTitle"]);

					if(oDbDataReader["ClientName"] != DBNull.Value)
						oTATransTraveler.ClientName = Convert.ToString(oDbDataReader["ClientName"]);

					if(oDbDataReader["ClientSurName"] != DBNull.Value)
						oTATransTraveler.ClientSurName = Convert.ToString(oDbDataReader["ClientSurName"]);

					if(oDbDataReader["Birthday"] != DBNull.Value)
						oTATransTraveler.Birthday = Convert.ToString(oDbDataReader["Birthday"]);

					if(oDbDataReader["PassportID"] != DBNull.Value)
						oTATransTraveler.PassportID = Convert.ToString(oDbDataReader["PassportID"]);

					if(oDbDataReader["Tel"] != DBNull.Value)
						oTATransTraveler.Tel = Convert.ToString(oDbDataReader["Tel"]);

					if(oDbDataReader["isStudent"] != DBNull.Value)
						oTATransTraveler.isStudent = Convert.ToSByte(oDbDataReader["isStudent"]);

					if(oDbDataReader["isSingle"] != DBNull.Value)
						oTATransTraveler.isSingle = Convert.ToSByte(oDbDataReader["isSingle"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oTATransTraveler.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);
				}
				oDbDataReader.Close();
				return oTATransTraveler;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public int AddTATransTraveler(string JobNo,int TravelerId,string ClientTitle,string ClientName,string ClientSurName,string Birthday,string PassportID,string Tel,Nullable<SByte> isStudent,Nullable<SByte> isSingle,Nullable<DateTime> CreateDate)
		{
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
		}
		public int UpdateTATransTraveler(string JobNo,int TravelerId,string ClientTitle,string ClientName,string ClientSurName,string Birthday,string PassportID,string Tel,Nullable<SByte> isStudent,Nullable<SByte> isSingle,Nullable<DateTime> CreateDate)
		{
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
		}
		public int RemoveTATransTraveler(string JobNo,int TravelerId)
		{
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
		}

        /// <summary>
        /// INSERT/UPDATE
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="TravelerId"></param>
        /// <param name="ClientTitle"></param>
        /// <param name="ClientName"></param>
        /// <param name="ClientSurName"></param>
        /// <param name="Birthday"></param>
        /// <param name="PassportID"></param>
        /// <param name="Tel"></param>
        /// <param name="isStudent"></param>
        /// <param name="isSingle"></param>
        /// <param name="CreateDate"></param>
        /// <returns></returns>
        public int SetTATransTraveler(string JobNo, int TravelerId, string ClientTitle, string ClientName, string ClientSurName, string Birthday, string PassportID, string Tel, Nullable<SByte> isStudent, Nullable<SByte> isSingle, Nullable<DateTime> CreateDate)
        {
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spTA_SetTransTraveler", CommandType.StoredProcedure);
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TravelerId", DbType.Int32, TravelerId));

                if (ClientTitle != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientTitle", DbType.String, ClientTitle));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientTitle", DbType.String, DBNull.Value));
                if (ClientName != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientName", DbType.String, ClientName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientName", DbType.String, DBNull.Value));
                if (ClientSurName != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSurName", DbType.String, ClientSurName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSurName", DbType.String, DBNull.Value));
                if (Birthday != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Birthday", DbType.String, Birthday));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Birthday", DbType.String, DBNull.Value));
                if (PassportID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PassportID", DbType.String, PassportID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PassportID", DbType.String, DBNull.Value));
                if (isStudent.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isStudent", DbType.Int16, isStudent));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isStudent", DbType.Int16, DBNull.Value));
                if (isSingle.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isSingle", DbType.Int16, isSingle));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isSingle", DbType.Int16, DBNull.Value));
                if (Tel != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tel", DbType.String, Tel));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tel", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        /// <summary>
        /// //INSERT/UPDATE WIHT DBTRANSACTION
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="TravelerId"></param>
        /// <param name="ClientTitle"></param>
        /// <param name="ClientName"></param>
        /// <param name="ClientSurName"></param>
        /// <param name="Birthday"></param>
        /// <param name="PassportID"></param>
        /// <param name="Tel"></param>
        /// <param name="isStudent"></param>
        /// <param name="isSingle"></param>
        /// <param name="CreateDate"></param>
        /// <param name="dbTransaction"></param>
        /// <returns></returns>
        public int SetTATransTraveler(string JobNo, int TravelerId, string ClientTitle, string ClientName, string ClientSurName, string Birthday, string PassportID, string Tel, Nullable<SByte> isStudent, Nullable<SByte> isSingle, Nullable<DateTime> CreateDate, DbTransaction dbTransaction)
        {
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spTA_SetTransTraveler", CommandType.StoredProcedure, dbTransaction);
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TravelerId", DbType.Int32, TravelerId));
                
                if (ClientTitle != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientTitle", DbType.String, ClientTitle));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientTitle", DbType.String, DBNull.Value));
                if (ClientName != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientName", DbType.String, ClientName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientName", DbType.String, DBNull.Value));
                if (ClientSurName != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSurName", DbType.String, ClientSurName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSurName", DbType.String, DBNull.Value));
                if (Birthday != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Birthday", DbType.String, Birthday));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Birthday", DbType.String, DBNull.Value));
                if (PassportID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PassportID", DbType.String, PassportID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PassportID", DbType.String, DBNull.Value));        
                if (isStudent.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isStudent", DbType.Int16, isStudent));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isStudent", DbType.Int16, DBNull.Value));
                if (isSingle.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isSingle", DbType.Int16, isSingle));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isSingle", DbType.Int16, DBNull.Value));
                if (Tel != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tel", DbType.String, Tel));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tel", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand,true);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        /// <summary>
        /// //INSERT/UPDATE WIHT DBTRANSACTION
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="TravelerId"></param>
        /// <param name="ClientCode"></param>
        /// <param name="ClientTitle"></param>
        /// <param name="ClientName"></param>
        /// <param name="ClientSurName"></param>
        /// <param name="Birthday"></param>
        /// <param name="PassportID"></param>
        /// <param name="Tel"></param>
        /// <param name="isStudent"></param>
        /// <param name="isSingle"></param>
        /// <param name="SumInsuredPA"></param>
        /// <param name="NetPremium"></param>
        /// <param name="Stamp"></param>
        /// <param name="SBT"></param>
        /// <param name="TotalPremium"></param>
        /// <param name="CreateDate"></param>
        /// <param name="dbTransaction"></param>
        /// <returns></returns>
        public int SetTATransTraveler(string JobNo, int TravelerId, string ClientTitle, string ClientName, string ClientSurName, string Birthday, string PassportID, string Tel, Nullable<SByte> isStudent, Nullable<SByte> isSingle, Nullable<Decimal> SumInsurePA, Nullable<Decimal> NetPremium, Nullable<int> Stamp, Nullable<int> SBT, Nullable<Decimal> TotalPremium, Nullable<DateTime> CreateDate, DbTransaction dbTransaction)
        {
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spTA_SetTransTraveler", CommandType.StoredProcedure, dbTransaction);
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TravelerId", DbType.Int32, TravelerId));

                if (ClientTitle != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientTitle", DbType.String, ClientTitle));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientTitle", DbType.String, DBNull.Value));
                if (ClientName != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientName", DbType.String, ClientName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientName", DbType.String, DBNull.Value));
                if (ClientSurName != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSurName", DbType.String, ClientSurName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSurName", DbType.String, DBNull.Value));
                if (Birthday != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Birthday", DbType.String, Birthday));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Birthday", DbType.String, DBNull.Value));
                if (PassportID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PassportID", DbType.String, PassportID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PassportID", DbType.String, DBNull.Value));
                if (isStudent.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isStudent", DbType.Int16, isStudent));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isStudent", DbType.Int16, DBNull.Value));
                if (isSingle.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isSingle", DbType.Int16, isSingle));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isSingle", DbType.Int16, DBNull.Value));
                if (Tel != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tel", DbType.String, Tel));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tel", DbType.String, DBNull.Value));
                if (SumInsurePA.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@SumInsurePA", DbType.Decimal, SumInsurePA));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@SumInsurePA", DbType.Decimal, DBNull.Value));
                if (NetPremium.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NetPremium", DbType.Decimal, NetPremium));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NetPremium", DbType.Decimal, DBNull.Value));
                if (Stamp.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Stamp", DbType.Int32, Stamp));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Stamp", DbType.Int32, DBNull.Value));
                if (SBT.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@SBT", DbType.Int32, SBT));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@SBT", DbType.Int32, DBNull.Value));
                if (TotalPremium.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TotalPremium", DbType.Decimal, TotalPremium));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TotalPremium", DbType.Decimal, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand, true);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        public int SetTATransTraveler(string JobNo, int TravelerId, string ClientTitle, string ClientName, string ClientSurName, string Birthday, string PassportID, string Tel, Nullable<SByte> isStudent, Nullable<SByte> isSingle, Nullable<Decimal> SumInsurePA, Nullable<Decimal> NetPremium, Nullable<int> Stamp, Nullable<int> SBT, Nullable<Decimal> TotalPremium, Nullable<DateTime> CreateDate)
        {
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spTA_SetTransTraveler", CommandType.StoredProcedure);
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TravelerId", DbType.Int32, TravelerId));

                if (ClientTitle != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientTitle", DbType.String, ClientTitle));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientTitle", DbType.String, DBNull.Value));
                if (ClientName != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientName", DbType.String, ClientName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientName", DbType.String, DBNull.Value));
                if (ClientSurName != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSurName", DbType.String, ClientSurName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@ClientSurName", DbType.String, DBNull.Value));
                if (Birthday != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Birthday", DbType.String, Birthday));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Birthday", DbType.String, DBNull.Value));
                if (PassportID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PassportID", DbType.String, PassportID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PassportID", DbType.String, DBNull.Value));
                if (isStudent.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isStudent", DbType.Int16, isStudent));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isStudent", DbType.Int16, DBNull.Value));
                if (isSingle.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isSingle", DbType.Int16, isSingle));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isSingle", DbType.Int16, DBNull.Value));
                if (Tel != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tel", DbType.String, Tel));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Tel", DbType.String, DBNull.Value));
                if (SumInsurePA.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@SumInsurePA", DbType.Decimal, SumInsurePA));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@SumInsurePA", DbType.Decimal, DBNull.Value));
                if (NetPremium.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NetPremium", DbType.Decimal, NetPremium));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NetPremium", DbType.Decimal, DBNull.Value));
                if (Stamp.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Stamp", DbType.Int32, Stamp));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Stamp", DbType.Int32, DBNull.Value));
                if (SBT.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@SBT", DbType.Int32, SBT));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@SBT", DbType.Int32, DBNull.Value));
                if (TotalPremium.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TotalPremium", DbType.Decimal, TotalPremium));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TotalPremium", DbType.Decimal, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand, true);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        /// <summary>
        /// GET
        /// </summary>
        /// <param name="JobNo"></param>
        /// <returns></returns>
        public DataTable GetDtTATransTraveler(string JobNo)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = DbProviderHelper.CreateCommand("spTA_GetBindTraveler", CommandType.StoredProcedure);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return DbProviderHelper.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

    
    }
}
