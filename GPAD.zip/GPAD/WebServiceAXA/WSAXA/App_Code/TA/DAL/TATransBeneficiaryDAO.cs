using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;

namespace TA.DAL
{
	public class TATransBeneficiaryDAO
	{
		public TATransBeneficiaryDAO()
		{
			DbProviderHelper.GetConnection();
		}
		public List<TATransBeneficiary> GetTATransBeneficiarys()
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<TATransBeneficiary> lstTATransBeneficiarys = new List<TATransBeneficiary>();
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("",CommandType.StoredProcedure);
				oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					TATransBeneficiary oTATransBeneficiary = new TATransBeneficiary();
					oTATransBeneficiary.JobNo = Convert.ToString(oDbDataReader["JobNo"]);
					oTATransBeneficiary.TravelerID = Convert.ToInt32(oDbDataReader["TravelerID"]);
					oTATransBeneficiary.Seq = Convert.ToInt32(oDbDataReader["Seq"]);

					if(oDbDataReader["BeneficiaryTitle"] != DBNull.Value)
						oTATransBeneficiary.BeneficiaryTitle = Convert.ToString(oDbDataReader["BeneficiaryTitle"]);

					if(oDbDataReader["BeneficiaryName"] != DBNull.Value)
						oTATransBeneficiary.BeneficiaryName = Convert.ToString(oDbDataReader["BeneficiaryName"]);

					if(oDbDataReader["BeneficiarySurName"] != DBNull.Value)
						oTATransBeneficiary.BeneficiarySurName = Convert.ToString(oDbDataReader["BeneficiarySurName"]);

					if(oDbDataReader["BeneficiaryRelation"] != DBNull.Value)
						oTATransBeneficiary.BeneficiaryRelation = Convert.ToString(oDbDataReader["BeneficiaryRelation"]);

					if(oDbDataReader["BeneficiaryRatio"] != DBNull.Value)
						oTATransBeneficiary.BeneficiaryRatio = Convert.ToString(oDbDataReader["BeneficiaryRatio"]);

					if(oDbDataReader["BeneficiaryTel"] != DBNull.Value)
						oTATransBeneficiary.BeneficiaryTel = Convert.ToString(oDbDataReader["BeneficiaryTel"]);
					lstTATransBeneficiarys.Add(oTATransBeneficiary);
				}
				oDbDataReader.Close();
				return lstTATransBeneficiarys;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public TATransBeneficiary GetTATransBeneficiary(string JobNo,int TravelerID,int Seq)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				TATransBeneficiary oTATransBeneficiary = new TATransBeneficiary();
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("",CommandType.StoredProcedure);
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo",DbType.String,JobNo));
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TravelerID",DbType.Int32,TravelerID));
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Seq",DbType.Int32,Seq));
				oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oTATransBeneficiary.JobNo = Convert.ToString(oDbDataReader["JobNo"]);
					oTATransBeneficiary.TravelerID = Convert.ToInt32(oDbDataReader["TravelerID"]);
					oTATransBeneficiary.Seq = Convert.ToInt32(oDbDataReader["Seq"]);

					if(oDbDataReader["BeneficiaryTitle"] != DBNull.Value)
						oTATransBeneficiary.BeneficiaryTitle = Convert.ToString(oDbDataReader["BeneficiaryTitle"]);

					if(oDbDataReader["BeneficiaryName"] != DBNull.Value)
						oTATransBeneficiary.BeneficiaryName = Convert.ToString(oDbDataReader["BeneficiaryName"]);

					if(oDbDataReader["BeneficiarySurName"] != DBNull.Value)
						oTATransBeneficiary.BeneficiarySurName = Convert.ToString(oDbDataReader["BeneficiarySurName"]);

					if(oDbDataReader["BeneficiaryRelation"] != DBNull.Value)
						oTATransBeneficiary.BeneficiaryRelation = Convert.ToString(oDbDataReader["BeneficiaryRelation"]);

					if(oDbDataReader["BeneficiaryRatio"] != DBNull.Value)
						oTATransBeneficiary.BeneficiaryRatio = Convert.ToString(oDbDataReader["BeneficiaryRatio"]);

					if(oDbDataReader["BeneficiaryTel"] != DBNull.Value)
						oTATransBeneficiary.BeneficiaryTel = Convert.ToString(oDbDataReader["BeneficiaryTel"]);
				}
				oDbDataReader.Close();
				return oTATransBeneficiary;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public int AddTATransBeneficiary(string JobNo,int TravelerID,int Seq,string BeneficiaryTitle,string BeneficiaryName,string BeneficiarySurName,string BeneficiaryRelation,string BeneficiaryRatio,string BeneficiaryTel)
		{
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
		}
		public int UpdateTATransBeneficiary(string JobNo,int TravelerID,int Seq,string BeneficiaryTitle,string BeneficiaryName,string BeneficiarySurName,string BeneficiaryRelation,string BeneficiaryRatio,string BeneficiaryTel)
		{
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
		}
		public int RemoveTATransBeneficiary(string JobNo,int TravelerID,int Seq)
		{
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
		}

        /// <summary>
        /// INSERT/UPDATE
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="TravelerID"></param>
        /// <param name="Seq"></param>
        /// <param name="BeneficiaryTitle"></param>
        /// <param name="BeneficiaryName"></param>
        /// <param name="BeneficiarySurName"></param>
        /// <param name="BeneficiaryRelation"></param>
        /// <param name="BeneficiaryRatio"></param>
        /// <param name="BeneficiaryTel"></param>
        /// <returns></returns>
        public int SetTATransBeneficiary(string JobNo, int TravelerID, int Seq, string BeneficiaryTitle, string BeneficiaryName, string BeneficiarySurName, string BeneficiaryRelation, string BeneficiaryRatio, string BeneficiaryTel)
        {
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spTA_SetBeneficiary", CommandType.StoredProcedure);
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TravelerID", DbType.Int32, TravelerID));
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Seq", DbType.Int32, Seq));

                if (BeneficiaryTitle != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficiaryTitle", DbType.String, BeneficiaryTitle));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficiaryTitle", DbType.String, DBNull.Value));
                if (BeneficiaryName != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficiaryName", DbType.String, BeneficiaryName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficiaryName", DbType.String, DBNull.Value));
                if (BeneficiarySurName != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficiarySurName", DbType.String, BeneficiarySurName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficiarySurName", DbType.String, DBNull.Value));
                if (BeneficiaryRelation != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficiaryRelation", DbType.String, BeneficiaryRelation));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficiaryRelation", DbType.String, DBNull.Value));
                if (BeneficiaryRatio != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficiaryRatio", DbType.String, BeneficiaryRatio));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficiaryRatio", DbType.String, DBNull.Value));
                if (BeneficiaryTel != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficiaryTel", DbType.String, BeneficiaryTel));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficiaryTel", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        /// <summary>
        /// INSERT/UPDATE WITH TRANSACTION
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="TravelerID"></param>
        /// <param name="Seq"></param>
        /// <param name="BeneficiaryTitle"></param>
        /// <param name="BeneficiaryName"></param>
        /// <param name="BeneficiarySurName"></param>
        /// <param name="BeneficiaryRelation"></param>
        /// <param name="BeneficiaryRatio"></param>
        /// <param name="BeneficiaryTel"></param>
        /// <param name="dbTransaction"></param>
        /// <returns></returns>
        public int SetTATransBeneficiary(string JobNo, int TravelerID, int Seq, string BeneficiaryTitle, string BeneficiaryName, string BeneficiarySurName, string BeneficiaryRelation, string BeneficiaryRatio, string BeneficiaryTel, DbTransaction dbTransaction)
        {
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spTA_SetBeneficiary", CommandType.StoredProcedure,dbTransaction);
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TravelerID", DbType.Int32, TravelerID));
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Seq", DbType.Int32, Seq));
                
                if (BeneficiaryTitle != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficiaryTitle", DbType.String, BeneficiaryTitle));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficiaryTitle", DbType.String, DBNull.Value));
                if (BeneficiaryName != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficiaryName", DbType.String, BeneficiaryName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficiaryName", DbType.String, DBNull.Value));
                if (BeneficiarySurName != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficiarySurName", DbType.String, BeneficiarySurName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficiarySurName", DbType.String, DBNull.Value));
                if (BeneficiaryRelation != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficiaryRelation", DbType.String, BeneficiaryRelation));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficiaryRelation", DbType.String, DBNull.Value));
                if (BeneficiaryRatio != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficiaryRatio", DbType.String, BeneficiaryRatio));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficiaryRatio", DbType.String, DBNull.Value));
                if (BeneficiaryTel != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficiaryTel", DbType.String, BeneficiaryTel));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@BeneficiaryTel", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand,true);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        /// <summary>
        /// GET
        /// </summary>
        /// <param name="JobNo"></param>
        /// <returns></returns>
        public DataTable GetDtTATransBeneficiary(string JobNo)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = DbProviderHelper.CreateCommand("spTA_GetBindBeneficiary", CommandType.StoredProcedure);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return DbProviderHelper.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        /// <summary>
        /// GET
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="TravelerID"></param>
        /// <returns></returns>
        public DataTable GetDtTATransBeneficiary(string JobNo,int TravelerID)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = DbProviderHelper.CreateCommand("spTA_GetBindBeneficiaryByJobNoAndTravelerID", CommandType.StoredProcedure);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@TravelerID", DbType.Int32, TravelerID));
                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return DbProviderHelper.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        
	}
}
