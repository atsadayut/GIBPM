using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;

namespace TA.DAL
{
	public class TATransPolicyDAO
	{
		public TATransPolicyDAO()
		{
			DbProviderHelper.GetConnection();
		}
		public List<TATransPolicy> GetTATransPolicys()
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<TATransPolicy> lstTATransPolicys = new List<TATransPolicy>();
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("",CommandType.StoredProcedure);
				oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					TATransPolicy oTATransPolicy = new TATransPolicy();
					oTATransPolicy.JobNo = Convert.ToString(oDbDataReader["JobNo"]);

					if(oDbDataReader["PolicyNo"] != DBNull.Value)
						oTATransPolicy.PolicyNo = Convert.ToString(oDbDataReader["PolicyNo"]);

					if(oDbDataReader["TravelPlan"] != DBNull.Value)
						oTATransPolicy.TravelPlan = Convert.ToString(oDbDataReader["TravelPlan"]);

					if(oDbDataReader["PolicyType"] != DBNull.Value)
						oTATransPolicy.PolicyType = Convert.ToString(oDbDataReader["PolicyType"]);

					if(oDbDataReader["NumbersOfChildren"] != DBNull.Value)
						oTATransPolicy.NumbersOfChildren = Convert.ToInt32(oDbDataReader["NumbersOfChildren"]);

					if(oDbDataReader["InsurancePlan"] != DBNull.Value)
						oTATransPolicy.InsurancePlan = Convert.ToString(oDbDataReader["InsurancePlan"]);

					if(oDbDataReader["EffectiveDateFrom"] != DBNull.Value)
						oTATransPolicy.EffectiveDateFrom = Convert.ToString(oDbDataReader["EffectiveDateFrom"]);

					if(oDbDataReader["EffectiveDateTo"] != DBNull.Value)
						oTATransPolicy.EffectiveDateTo = Convert.ToString(oDbDataReader["EffectiveDateTo"]);

					if(oDbDataReader["CountryOfDestination"] != DBNull.Value)
						oTATransPolicy.CountryOfDestination = Convert.ToString(oDbDataReader["CountryOfDestination"]);

					if(oDbDataReader["PlanCode"] != DBNull.Value)
						oTATransPolicy.PlanCode = Convert.ToString(oDbDataReader["PlanCode"]);

					if(oDbDataReader["ContractType"] != DBNull.Value)
						oTATransPolicy.ContractType = Convert.ToString(oDbDataReader["ContractType"]);

					if(oDbDataReader["AgentCode"] != DBNull.Value)
						oTATransPolicy.AgentCode = Convert.ToString(oDbDataReader["AgentCode"]);

					if(oDbDataReader["StaffCode"] != DBNull.Value)
						oTATransPolicy.StaffCode = Convert.ToString(oDbDataReader["StaffCode"]);

					if(oDbDataReader["BranchCode"] != DBNull.Value)
						oTATransPolicy.BranchCode = Convert.ToString(oDbDataReader["BranchCode"]);

					if(oDbDataReader["TemplateCode"] != DBNull.Value)
						oTATransPolicy.TemplateCode = Convert.ToString(oDbDataReader["TemplateCode"]);

					if(oDbDataReader["OccupatnCode"] != DBNull.Value)
						oTATransPolicy.OccupatnCode = Convert.ToString(oDbDataReader["OccupatnCode"]);

					if(oDbDataReader["NetPremium"] != DBNull.Value)
						oTATransPolicy.NetPremium = Convert.ToDecimal(oDbDataReader["NetPremium"]);

					if(oDbDataReader["Stamp"] != DBNull.Value)
						oTATransPolicy.Stamp = Convert.ToInt32(oDbDataReader["Stamp"]);

					if(oDbDataReader["SBT"] != DBNull.Value)
						oTATransPolicy.SBT = Convert.ToDecimal(oDbDataReader["SBT"]);

					if(oDbDataReader["TotalPremium"] != DBNull.Value)
						oTATransPolicy.TotalPremium = Convert.ToDecimal(oDbDataReader["TotalPremium"]);

					if(oDbDataReader["isLongName"] != DBNull.Value)
						oTATransPolicy.isLongName = Convert.ToSByte(oDbDataReader["isLongName"]);

					if(oDbDataReader["isBeneficiary"] != DBNull.Value)
						oTATransPolicy.isBeneficiary = Convert.ToSByte(oDbDataReader["isBeneficiary"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oTATransPolicy.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);

					if(oDbDataReader["CreateUser"] != DBNull.Value)
						oTATransPolicy.CreateUser = Convert.ToString(oDbDataReader["CreateUser"]);

					if(oDbDataReader["GroupBrokerId"] != DBNull.Value)
						oTATransPolicy.GroupBrokerId = Convert.ToString(oDbDataReader["GroupBrokerId"]);
					lstTATransPolicys.Add(oTATransPolicy);
				}
				oDbDataReader.Close();
				return lstTATransPolicys;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public TATransPolicy GetTATransPolicy(string JobNo)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				TATransPolicy oTATransPolicy = new TATransPolicy();
				DbCommand oDbCommand = DbProviderHelper.CreateCommand("",CommandType.StoredProcedure);
				oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo",DbType.String,JobNo));
				oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oTATransPolicy.JobNo = Convert.ToString(oDbDataReader["JobNo"]);

					if(oDbDataReader["PolicyNo"] != DBNull.Value)
						oTATransPolicy.PolicyNo = Convert.ToString(oDbDataReader["PolicyNo"]);

					if(oDbDataReader["TravelPlan"] != DBNull.Value)
						oTATransPolicy.TravelPlan = Convert.ToString(oDbDataReader["TravelPlan"]);

					if(oDbDataReader["PolicyType"] != DBNull.Value)
						oTATransPolicy.PolicyType = Convert.ToString(oDbDataReader["PolicyType"]);

					if(oDbDataReader["NumbersOfChildren"] != DBNull.Value)
						oTATransPolicy.NumbersOfChildren = Convert.ToInt32(oDbDataReader["NumbersOfChildren"]);

					if(oDbDataReader["InsurancePlan"] != DBNull.Value)
						oTATransPolicy.InsurancePlan = Convert.ToString(oDbDataReader["InsurancePlan"]);

					if(oDbDataReader["EffectiveDateFrom"] != DBNull.Value)
						oTATransPolicy.EffectiveDateFrom = Convert.ToString(oDbDataReader["EffectiveDateFrom"]);

					if(oDbDataReader["EffectiveDateTo"] != DBNull.Value)
						oTATransPolicy.EffectiveDateTo = Convert.ToString(oDbDataReader["EffectiveDateTo"]);

					if(oDbDataReader["CountryOfDestination"] != DBNull.Value)
						oTATransPolicy.CountryOfDestination = Convert.ToString(oDbDataReader["CountryOfDestination"]);

					if(oDbDataReader["PlanCode"] != DBNull.Value)
						oTATransPolicy.PlanCode = Convert.ToString(oDbDataReader["PlanCode"]);

					if(oDbDataReader["ContractType"] != DBNull.Value)
						oTATransPolicy.ContractType = Convert.ToString(oDbDataReader["ContractType"]);

					if(oDbDataReader["AgentCode"] != DBNull.Value)
						oTATransPolicy.AgentCode = Convert.ToString(oDbDataReader["AgentCode"]);

					if(oDbDataReader["StaffCode"] != DBNull.Value)
						oTATransPolicy.StaffCode = Convert.ToString(oDbDataReader["StaffCode"]);

					if(oDbDataReader["BranchCode"] != DBNull.Value)
						oTATransPolicy.BranchCode = Convert.ToString(oDbDataReader["BranchCode"]);

					if(oDbDataReader["TemplateCode"] != DBNull.Value)
						oTATransPolicy.TemplateCode = Convert.ToString(oDbDataReader["TemplateCode"]);

					if(oDbDataReader["OccupatnCode"] != DBNull.Value)
						oTATransPolicy.OccupatnCode = Convert.ToString(oDbDataReader["OccupatnCode"]);

					if(oDbDataReader["NetPremium"] != DBNull.Value)
						oTATransPolicy.NetPremium = Convert.ToDecimal(oDbDataReader["NetPremium"]);

					if(oDbDataReader["Stamp"] != DBNull.Value)
						oTATransPolicy.Stamp = Convert.ToInt32(oDbDataReader["Stamp"]);

					if(oDbDataReader["SBT"] != DBNull.Value)
						oTATransPolicy.SBT = Convert.ToDecimal(oDbDataReader["SBT"]);

					if(oDbDataReader["TotalPremium"] != DBNull.Value)
						oTATransPolicy.TotalPremium = Convert.ToDecimal(oDbDataReader["TotalPremium"]);

					if(oDbDataReader["isLongName"] != DBNull.Value)
						oTATransPolicy.isLongName = Convert.ToSByte(oDbDataReader["isLongName"]);

					if(oDbDataReader["isBeneficiary"] != DBNull.Value)
						oTATransPolicy.isBeneficiary = Convert.ToSByte(oDbDataReader["isBeneficiary"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oTATransPolicy.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);

					if(oDbDataReader["CreateUser"] != DBNull.Value)
						oTATransPolicy.CreateUser = Convert.ToString(oDbDataReader["CreateUser"]);

					if(oDbDataReader["GroupBrokerId"] != DBNull.Value)
						oTATransPolicy.GroupBrokerId = Convert.ToString(oDbDataReader["GroupBrokerId"]);
				}
				oDbDataReader.Close();
				return oTATransPolicy;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public int AddTATransPolicy(string JobNo,string PolicyNo,string TravelPlan,string PolicyType,Nullable<int> NumbersOfChildren,string InsurancePlan,string EffectiveDateFrom,string EffectiveDateTo,string CountryOfDestination,string PlanCode,string ContractType,string AgentCode,string StaffCode,string BranchCode,string TemplateCode,string OccupatnCode,Nullable<Decimal> NetPremium,Nullable<int> Stamp,Nullable<Decimal> SBT,Nullable<Decimal> TotalPremium,Nullable<SByte> isLongName,Nullable<SByte> isBeneficiary,Nullable<DateTime> CreateDate,string CreateUser,string GroupBrokerId)
		{
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
		}
		public int UpdateTATransPolicy(string JobNo,string PolicyNo,string TravelPlan,string PolicyType,Nullable<int> NumbersOfChildren,string InsurancePlan,string EffectiveDateFrom,string EffectiveDateTo,string CountryOfDestination,string PlanCode,string ContractType,string AgentCode,string StaffCode,string BranchCode,string TemplateCode,string OccupatnCode,Nullable<Decimal> NetPremium,Nullable<int> Stamp,Nullable<Decimal> SBT,Nullable<Decimal> TotalPremium,Nullable<SByte> isLongName,Nullable<SByte> isBeneficiary,Nullable<DateTime> CreateDate,string CreateUser,string GroupBrokerId)
		{
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
		}
		public int RemoveTATransPolicy(string JobNo)
		{

            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
		}

        /// <summary>
        /// GET
        /// </summary>
        /// <param name="JobNo"></param>
        /// <returns></returns>
        public TAGetBindPackagePolicy GetTATransPolicy(string JobNo, string GroupBrokerId)
        {
            DbDataReader oDbDataReader = null;
            try
            {
                TAGetBindPackagePolicy oTATransPolicy = new TAGetBindPackagePolicy();
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spTA_GetBindPackagePolicy", CommandType.StoredProcedure);
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId", DbType.String, GroupBrokerId));
                oDbDataReader = DbProviderHelper.ExecuteReader(oDbCommand);
                while (oDbDataReader.Read())
                {
                    oTATransPolicy.JobNo = Convert.ToString(oDbDataReader["JobNo"]);

                    if (oDbDataReader["PolicyNo"] != DBNull.Value)
                        oTATransPolicy.PolicyNo = Convert.ToString(oDbDataReader["PolicyNo"]);

                    if (oDbDataReader["TravelPlan"] != DBNull.Value)
                        oTATransPolicy.TravelPlan = Convert.ToString(oDbDataReader["TravelPlan"]);

                    if (oDbDataReader["PolicyType"] != DBNull.Value)
                        oTATransPolicy.PolicyType = Convert.ToString(oDbDataReader["PolicyType"]);

                    if (oDbDataReader["NumbersOfChildren"] != DBNull.Value)
                        oTATransPolicy.NumbersOfChildren = Convert.ToString(oDbDataReader["NumbersOfChildren"]);

                    if (oDbDataReader["InsurancePlan"] != DBNull.Value)
                        oTATransPolicy.InsurancePlan = Convert.ToString(oDbDataReader["InsurancePlan"]);

                    if (oDbDataReader["EffectiveDateFrom"] != DBNull.Value)
                        oTATransPolicy.EffectiveDateFrom = Convert.ToString(oDbDataReader["EffectiveDateFrom"]);

                    if (oDbDataReader["EffectiveDateTo"] != DBNull.Value)
                        oTATransPolicy.EffectiveDateTo = Convert.ToString(oDbDataReader["EffectiveDateTo"]);

                    if (oDbDataReader["CountryOfDestination"] != DBNull.Value)
                        oTATransPolicy.CountryOfDestination = Convert.ToString(oDbDataReader["CountryOfDestination"]);

                    if (oDbDataReader["CountryOther"] != DBNull.Value)
                        oTATransPolicy.CounterOther = Convert.ToString(oDbDataReader["CountryOther"]);

                    if (oDbDataReader["PlanCode"] != DBNull.Value)
                        oTATransPolicy.PlanCode = Convert.ToString(oDbDataReader["PlanCode"]);

                    if (oDbDataReader["ContractType"] != DBNull.Value)
                        oTATransPolicy.ContractType = Convert.ToString(oDbDataReader["ContractType"]);

                    if (oDbDataReader["AgentCode"] != DBNull.Value)
                        oTATransPolicy.AgentCode = Convert.ToString(oDbDataReader["AgentCode"]);

                    if (oDbDataReader["NetPremium"] != DBNull.Value)
                        oTATransPolicy.NetPremium = Convert.ToString(oDbDataReader["NetPremium"]);

                    if (oDbDataReader["Stamp"] != DBNull.Value)
                        oTATransPolicy.Stamp = Convert.ToString(oDbDataReader["Stamp"]);

                    if (oDbDataReader["SBT"] != DBNull.Value)
                        oTATransPolicy.SBT = Convert.ToString(oDbDataReader["SBT"]);

                    if (oDbDataReader["TotalPremium"] != DBNull.Value)
                        oTATransPolicy.TotalPremium = Convert.ToString(oDbDataReader["TotalPremium"]);

                    if (oDbDataReader["isLongName"] != DBNull.Value)
                        oTATransPolicy.IsLongName = Convert.ToString(oDbDataReader["isLongName"]);

                    if (oDbDataReader["isBeneficiary"] != DBNull.Value)
                        oTATransPolicy.IsBeneficiary = Convert.ToString(oDbDataReader["isBeneficiary"]);                  
   
                    if (oDbDataReader["GroupBrokerId"] != DBNull.Value)
                        oTATransPolicy.GroupBrokerId = Convert.ToString(oDbDataReader["GroupBrokerId"]);
                    oTATransPolicy.LongName1 = "";
                    if (oDbDataReader["LongName1"] != DBNull.Value)
                        oTATransPolicy.LongName1 = Convert.ToString(oDbDataReader["LongName1"]);
                    oTATransPolicy.LongName2 = "";
                    if (oDbDataReader["LongName2"] != DBNull.Value)
                        oTATransPolicy.LongName2 = Convert.ToString(oDbDataReader["LongName2"]);
                    oTATransPolicy.LongName3 = "";
                    if (oDbDataReader["LongName3"] != DBNull.Value)
                        oTATransPolicy.LongName3 = Convert.ToString(oDbDataReader["LongName3"]);
                    oTATransPolicy.LongName4 = "";
                    if (oDbDataReader["LongName4"] != DBNull.Value)
                        oTATransPolicy.LongName4 = Convert.ToString(oDbDataReader["LongName4"]);


                }
                oDbDataReader.Close();
                return oTATransPolicy;
            }
            catch (Exception ex)
            {
                oDbDataReader.Close();
                Utilities.LogError(ex);
                throw ex;
            }
        }
        /// <summary>
        /// INSERT/UPDATE
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="PolicyNo"></param>
        /// <param name="TravelPlan"></param>
        /// <param name="PolicyType"></param>
        /// <param name="NumbersOfChildren"></param>
        /// <param name="InsurancePlan"></param>
        /// <param name="EffectiveDateFrom"></param>
        /// <param name="EffectiveDateTo"></param>
        /// <param name="CountryOfDestination"></param>
        /// <param name="PlanCode"></param>
        /// <param name="ContractType"></param>
        /// <param name="AgentCode"></param>
        /// <param name="StaffCode"></param>
        /// <param name="BranchCode"></param>
        /// <param name="TemplateCode"></param>
        /// <param name="OccupatnCode"></param>
        /// <param name="NetPremium"></param>
        /// <param name="Stamp"></param>
        /// <param name="SBT"></param>
        /// <param name="TotalPremium"></param>
        /// <param name="isLongName"></param>
        /// <param name="isBeneficiary"></param>
        /// <param name="CreateDate"></param>
        /// <param name="CreateUser"></param>
        /// <param name="GroupBrokerId"></param>
        /// <returns></returns>
        public int SetTATransPolicy(string JobNo, string PolicyNo, string TravelPlan, string PolicyType, Nullable<int> NumbersOfChildren, string InsurancePlan, string EffectiveDateFrom, string EffectiveDateTo, string CountryOfDestination, string CountryOther, string AgentCode, string OccupatnCode, Nullable<Decimal> NetPremium, Nullable<int> Stamp, Nullable<Decimal> SBT, Nullable<Decimal> TotalPremium, Nullable<SByte> isLongName, Nullable<SByte> isBeneficiary, string CreateUser, string GroupBrokerId)
        {
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spTA_setTransPolicy", CommandType.StoredProcedure);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (PolicyNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, PolicyNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, DBNull.Value));
                if (TravelPlan != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TravelPlan", DbType.String, TravelPlan));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TravelPlan", DbType.String, DBNull.Value));
                if (PolicyType != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyType", DbType.String, PolicyType));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyType", DbType.String, DBNull.Value));
                if (NumbersOfChildren.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NumbersOfChildren", DbType.Int32, NumbersOfChildren));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NumbersOfChildren", DbType.Int32, DBNull.Value));
                if (InsurancePlan != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PlanID", DbType.String, InsurancePlan));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PlanID", DbType.String, DBNull.Value));
                if (EffectiveDateFrom != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EffectiveDateFrom", DbType.String, EffectiveDateFrom));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EffectiveDateFrom", DbType.String, DBNull.Value));
                if (EffectiveDateTo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EffectiveDateTo", DbType.String, EffectiveDateTo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EffectiveDateTo", DbType.String, DBNull.Value));
                if (CountryOfDestination != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CountryOfDestination", DbType.String, CountryOfDestination));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CountryOfDestination", DbType.String, DBNull.Value));
                if (CountryOther != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CountryOther", DbType.String, CountryOther));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CountryOther", DbType.String, DBNull.Value));
                if (AgentCode != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AgentCode", DbType.String, AgentCode));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AgentCode", DbType.String, DBNull.Value));
                if (OccupatnCode != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@OccupatnCode", DbType.String, OccupatnCode));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@OccupatnCode", DbType.String, DBNull.Value));
                if (NetPremium.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NetPremium", DbType.Decimal, NetPremium));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NetPremium", DbType.Decimal, DBNull.Value));
                if (Stamp.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Stamp", DbType.Int32, Stamp));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Stamp", DbType.Int32, DBNull.Value));
                if (SBT.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@SBT", DbType.Decimal, SBT));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@SBT", DbType.Decimal, DBNull.Value));
                if (TotalPremium.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TotalPremium", DbType.Decimal, TotalPremium));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TotalPremium", DbType.Decimal, DBNull.Value));
                if (isLongName.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isLongName", DbType.Int16, isLongName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isLongName", DbType.Int16, DBNull.Value));
                if (isBeneficiary.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isBeneficiary", DbType.Int16, isBeneficiary));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isBeneficiary", DbType.Int16, DBNull.Value));
                if (CreateUser != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreateUser", DbType.String, CreateUser));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreateUser", DbType.String, DBNull.Value));
                if (GroupBrokerId != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId", DbType.String, GroupBrokerId));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        /// <summary>
        /// INSERT/UPDATE WIHT DBTRANSACTION
        /// </summary>
        /// <param name="dbtransaction"></param>
        /// <param name="JobNo"></param>
        /// <param name="PolicyNo"></param>
        /// <param name="TravelPlan"></param>
        /// <param name="PolicyType"></param>
        /// <param name="NumbersOfChildren"></param>
        /// <param name="InsurancePlan"></param>
        /// <param name="EffectiveDateFrom"></param>
        /// <param name="EffectiveDateTo"></param>
        /// <param name="CountryOfDestination"></param>
        /// <param name="PlanCode"></param>
        /// <param name="ContractType"></param>
        /// <param name="AgentCode"></param>
        /// <param name="StaffCode"></param>
        /// <param name="BranchCode"></param>
        /// <param name="TemplateCode"></param>
        /// <param name="OccupatnCode"></param>
        /// <param name="NetPremium"></param>
        /// <param name="Stamp"></param>
        /// <param name="SBT"></param>
        /// <param name="TotalPremium"></param>
        /// <param name="isLongName"></param>
        /// <param name="isBeneficiary"></param>
        /// <param name="CreateDate"></param>
        /// <param name="CreateUser"></param>
        /// <param name="GroupBrokerId"></param>
        /// <returns></returns>
        public int SetTATransPolicy(string JobNo, string PolicyNo, string TravelPlan, string PolicyType, Nullable<int> NumbersOfChildren, string InsurancePlan, string EffectiveDateFrom, string EffectiveDateTo, string CountryOfDestination, string CountryOther, string AgentCode,string OccupatnCode, Nullable<Decimal> NetPremium, Nullable<int> Stamp, Nullable<Decimal> SBT, Nullable<Decimal> TotalPremium, Nullable<SByte> isLongName, Nullable<SByte> isBeneficiary, string CreateUser, string GroupBrokerId, DbTransaction dbTransaction)
        {
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spTA_setTransPolicy", CommandType.StoredProcedure, dbTransaction);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (PolicyNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, PolicyNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, DBNull.Value));
                if (TravelPlan != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TravelPlan", DbType.String, TravelPlan));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TravelPlan", DbType.String, DBNull.Value));
                if (PolicyType != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyType", DbType.String, PolicyType));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyType", DbType.String, DBNull.Value));
                if (NumbersOfChildren.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NumbersOfChildren", DbType.Int32, NumbersOfChildren));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NumbersOfChildren", DbType.Int32, DBNull.Value));
                if (InsurancePlan != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PlanID", DbType.String, InsurancePlan));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PlanID", DbType.String, DBNull.Value));
                if (EffectiveDateFrom != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EffectiveDateFrom", DbType.String, EffectiveDateFrom));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EffectiveDateFrom", DbType.String, DBNull.Value));
                if (EffectiveDateTo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EffectiveDateTo", DbType.String, EffectiveDateTo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EffectiveDateTo", DbType.String, DBNull.Value));
                if (CountryOfDestination != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CountryOfDestination", DbType.String, CountryOfDestination));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CountryOfDestination", DbType.String, DBNull.Value));
                if (CountryOther != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CountryOther", DbType.String, CountryOther));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CountryOther", DbType.String, DBNull.Value));
                if (AgentCode != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AgentCode", DbType.String, AgentCode));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AgentCode", DbType.String, DBNull.Value));
                if (OccupatnCode != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@OccupatnCode", DbType.String, OccupatnCode));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@OccupatnCode", DbType.String, DBNull.Value));
                if (NetPremium.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NetPremium", DbType.Decimal, NetPremium));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@NetPremium", DbType.Decimal, DBNull.Value));
                if (Stamp.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Stamp", DbType.Int32, Stamp));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@Stamp", DbType.Int32, DBNull.Value));
                if (SBT.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@SBT", DbType.Decimal, SBT));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@SBT", DbType.Decimal, DBNull.Value));
                if (TotalPremium.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TotalPremium", DbType.Decimal, TotalPremium));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@TotalPremium", DbType.Decimal, DBNull.Value));
                if (isLongName.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isLongName", DbType.Int16, isLongName));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isLongName", DbType.Int16, DBNull.Value));
                if (isBeneficiary.HasValue)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isBeneficiary", DbType.Int16, isBeneficiary));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@isBeneficiary", DbType.Int16, DBNull.Value));
                if (CreateUser != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreateUser", DbType.String, CreateUser));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreateUser", DbType.String, DBNull.Value));
                if (GroupBrokerId != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId", DbType.String, GroupBrokerId));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand,true);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        /// <summary>
        /// SET Trans cancel policy
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="PolicyNo"></param>
        /// <param name="UserID"></param>
        /// <param name="GroupBrokerID"></param>
        /// <returns></returns>
        public int SetTATransCancelPolicy(string JobNo, string PolicyNo, string UserID, string GroupBrokerID)
        {
            try
            {
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spTA_SetTransCancelPolicy", CommandType.StoredProcedure);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JOBNO", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JOBNO", DbType.String, DBNull.Value));
                if (PolicyNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@POLICYNO", DbType.String, PolicyNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@POLICYNO", DbType.String, DBNull.Value));
                if (UserID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@USERID", DbType.String, UserID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@USERID", DbType.String, DBNull.Value));
                if (GroupBrokerID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerID", DbType.String, GroupBrokerID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerID", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        
        /// <summary>
        /// GET TA POLICY FOR COPY
        /// </summary>
        /// <param name="PolicyNo"></param>
        /// <param name="JobNo"></param>
        /// <param name="InsureName"></param>
        /// <param name="TravelerName"></param>
        /// <param name="PassportID"></param>
        /// <param name="TransDateFrom"></param>
        /// <param name="TransDateTo"></param>
        /// <param name="GroupBrokerId"></param>
        /// <returns></returns>
        public DataTable GetDtTAGetListTAPolicy(string PolicyNo, string JobNo, string InsureName, string TravelerName, string PassportID, string TransDateFrom, string TransDateTo, string GroupBrokerId)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = DbProviderHelper.CreateCommand("spTA_GetListTAPolicy", CommandType.StoredProcedure);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, PolicyNo));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@InsureName", DbType.String, InsureName));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@TravelerName", DbType.String, TravelerName));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@PassportID", DbType.String, PassportID));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@TransDateFrom", DbType.String, TransDateFrom));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@TransDateTo", DbType.String, TransDateTo));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId", DbType.String, GroupBrokerId));
                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return DbProviderHelper.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        } 
        /// <summary>
        /// GET TA POLICY FOR CANCEL
        /// </summary>
        /// <param name="PolicyNo"></param>
        /// <param name="JobNo"></param>
        /// <param name="InsureName"></param>
        /// <param name="TravelerName"></param>
        /// <param name="PassportID"></param>
        /// <param name="TransDateFrom"></param>
        /// <param name="TransDateTo"></param>
        /// <param name="GroupBrokerId"></param>
        /// <returns></returns>
        public DataTable GetDtTAGetListTAPolicyForCancel(string PolicyNo, string JobNo, string InsureName, string TravelerName, string PassportID, string TransDateFrom, string TransDateTo, string GroupBrokerId)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = DbProviderHelper.CreateCommand("spTA_GetListTACancelPolicy", CommandType.StoredProcedure);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, PolicyNo));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@InsureName", DbType.String, InsureName));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@TravelerName", DbType.String, TravelerName));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@PassportID", DbType.String, PassportID));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@TransDateFrom", DbType.String, TransDateFrom));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@TransDateTo", DbType.String, TransDateTo));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId", DbType.String, GroupBrokerId));
                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return DbProviderHelper.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        ///<summary>
        /// SET TRANS TAXINVOINCE
        /// <param name="JobNo"></param>
        /// <param name="PolicyNo"></param>
        /// <param name="UserID"></param>
        /// <param name="FlagID"></param>
        /// <return></return>
        public int SetTATransTaxInvoince(string PolicyNo, string JobNo, string UserID, string FlagID)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spTA_SetTransTaxInvoince", CommandType.StoredProcedure);
                if (PolicyNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@POLICYNO", DbType.String, PolicyNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@POLICYNO", DbType.String, DBNull.Value));
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JOBNO", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JOBNO", DbType.String, DBNull.Value));
                if (UserID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@USERID", DbType.String, UserID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@USERID", DbType.String, DBNull.Value));
                if (FlagID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@FlagID", DbType.String, FlagID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@FlagID", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand,false);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        ///<summary>
        /// SET TRANS TAXINVOINCE
        /// <param name="JobNo"></param>
        /// <param name="PolicyNo"></param>
        /// <param name="UserID"></param>
        /// <param name="FlagID"></param>
        /// <return></return>
        public int SetTATransTaxInvoince(string PolicyNo, string JobNo, string UserID, string FlagID, DbTransaction dbTransaction)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spTA_SetTransTaxInvoince", CommandType.StoredProcedure, dbTransaction);
                if (PolicyNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@POLICYNO", DbType.String, PolicyNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@POLICYNO", DbType.String, DBNull.Value));
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JOBNO", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JOBNO", DbType.String, DBNull.Value));
                if (UserID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@USERID", DbType.String, UserID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@USERID", DbType.String, DBNull.Value));
                if (FlagID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@FlagID", DbType.String, FlagID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@FlagID", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand,true);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        ///<summary>
        /// SET TRANS PRINTS
        /// <param name="JobNo"></param>
        /// <param name="PolicyNo"></param>
        /// <param name="UserID"></param>
        /// <param name="EndtNo"></param>
        /// <param name="AgentCode"></param>
        /// <param name="GroupBrokerId"></param>
        /// <param name="CreatedUser"></param>
        /// <return></return>
        public int SetTATransPrint(string PolicyNo, string JobNo, string EndtNo, string AgentCode,string GroupBrokerId,string CreatedUser)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spTA_SetTransPrint", CommandType.StoredProcedure);
                if (PolicyNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, PolicyNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, DBNull.Value));
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (EndtNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EndtNo", DbType.String, EndtNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EndtNo", DbType.String, DBNull.Value));
                if (AgentCode != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AgentCode", DbType.String, AgentCode));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AgentCode", DbType.String, DBNull.Value));
                if (GroupBrokerId != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId", DbType.String, GroupBrokerId));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId", DbType.String, DBNull.Value));
                if (CreatedUser != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreatedUser", DbType.String, CreatedUser));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreatedUser", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand,false);

                
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        ///<summary>
        /// SET TRANS PRINTS
        /// <param name="JobNo"></param>
        /// <param name="PolicyNo"></param>
        /// <param name="UserID"></param>
        /// <param name="EndtNo"></param>
        /// <param name="AgentCode"></param>
        /// <param name="GroupBrokerId"></param>
        /// <param name="CreatedUser"></param>
        /// <return></return>
        public int SetTATransPrint(string PolicyNo, string JobNo, string EndtNo, string AgentCode, string GroupBrokerId, string CreatedUser, DbTransaction dbTransaction)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spTA_SetTransPrint", CommandType.StoredProcedure,dbTransaction);
                if (PolicyNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, PolicyNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, DBNull.Value));
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (EndtNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EndtNo", DbType.String, EndtNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EndtNo", DbType.String, DBNull.Value));
                if (AgentCode != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AgentCode", DbType.String, AgentCode));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AgentCode", DbType.String, DBNull.Value));
                if (GroupBrokerId != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId", DbType.String, GroupBrokerId));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerId", DbType.String, DBNull.Value));
                if (CreatedUser != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreatedUser", DbType.String, CreatedUser));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CreatedUser", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand,true);


            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        ///<summary>
        /// GET LIST PRINT POLICY
        /// <param name="PolicyFrom"></param>
        /// <param name="PolicyTo"></param>
        /// <param name="IssuedDateFrom"></param>
        /// <param name="IssuedDateTo"></param>
        /// <return></return>
        public DataTable GetTAListPrintPolicy(string PolicyFrom, string PolicyTo, string IssuedDateFrom, string IssuedDateTo,string EndtNo, string GroupBrokerID)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = DbProviderHelper.CreateCommand("spTA_GetListPrintPolicy", CommandType.StoredProcedure);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyFrom", DbType.String, PolicyFrom));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyTo", DbType.String, PolicyTo));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@IssuedDateFrom", DbType.String, IssuedDateFrom));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@IssuedDateTo", DbType.String, IssuedDateTo));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@EndtNo", DbType.String, EndtNo));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerID", DbType.String, GroupBrokerID));

                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return DbProviderHelper.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        ///<summary>
        /// GET LIST PRINT POLICY
        /// <param name="PolicyNo"></param>
        /// <param name="EndtNo"></param>
        /// <return></return>
        public DataTable GetTAPrintListReportName(string PolicyNo, string EndtNo)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = DbProviderHelper.CreateCommand("spTA_GetPrintListReportName", CommandType.StoredProcedure);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, PolicyNo));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@EndtNo", DbType.String, EndtNo));

                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return DbProviderHelper.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        ///<summary>
        /// GET LIST PRINT POLICY
        /// <param name="PolicyNo"></param>
        /// <param name="EndtNo"></param>
        /// <param name="FlagOriginal"></param>
        /// <return></return>
        public int SetTAPrintFlagOriginal(string PolicyNo, string EndtNo,int FlagOriginal)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spTA_SetPrintFlagOriginal", CommandType.StoredProcedure);
                if (PolicyNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, PolicyNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, DBNull.Value));
                if (EndtNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EndtNo", DbType.String, EndtNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EndtNo", DbType.String, DBNull.Value));
                
                if (FlagOriginal != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@FlagOriginal", DbType.Int16, FlagOriginal));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@FlagOriginal", DbType.Int16, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand);

            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        ///<summary>
        /// GET LIST PRINT POLICY
        /// <param name="PolicyNo"></param>
        /// <param name="EndtNo"></param>
        /// <param name="FlagCopy"></param>
        /// <return></return>
        public int SetTAPrintFlagCopy(string PolicyNo, string EndtNo,int FlagCopy)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spTA_SetPrintFlagCopy", CommandType.StoredProcedure);
                if (PolicyNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, PolicyNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, DBNull.Value));
                if (EndtNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EndtNo", DbType.String, EndtNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EndtNo", DbType.String, DBNull.Value));
                if (FlagCopy != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@FlagCopy", DbType.Int16, FlagCopy));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@FlagCopy", DbType.Int16, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        ///<summary>
        /// GET GetReport
        /// <param name="PolicyNo"></param>
        /// <param name="EndtNo"></param>
        /// <return></return>
        public DataTable GetTAGetReport(string TransDateFrom, string TransDateTo, string EffectiveDateFrom, string EffectiveDateTo, string AgentCode, string GroupBrokerID)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = DbProviderHelper.CreateCommand("spTA_GetReport", CommandType.StoredProcedure);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@TransDateFrom", DbType.String, TransDateFrom));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@TransDateTo", DbType.String, TransDateTo));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@EffectiveDateFrom", DbType.String, EffectiveDateFrom));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@EffectiveDateTo", DbType.String, EffectiveDateTo));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@AgentCode", DbType.String, AgentCode));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@GroupBrokerID", DbType.String, GroupBrokerID));


                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return DbProviderHelper.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        //----------------------------------------------------------------------------
        public DataTable GetTAGetReport(string PolicyNo)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = DbProviderHelper.CreateCommand("select [TAReportJPackage].*,[TAReport].[DefaultFlagOriginal],[TAReport].[DefaultFlagCopy] from [TAReportJPackage] left join [TAReport] on [TAReportJPackage].[Name] = [TAReport].[Name] where [PolicyNo]=@PolicyNo", CommandType.Text);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, PolicyNo));


                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return DbProviderHelper.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        public int SetTAPrintAllFlag(string PolicyNo, string EndtNo, int FlagOriginal, int FlagCopy)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("update [TAReportJPackage] set [FlagOriginal] = @FlagOriginal,[FlagCopy] = @FlagCopy,[CreateDate] = GETDATE() where [PolicyNo] =@PolicyNo and [EndtNo] = @EndtNo ", CommandType.Text);
                if (PolicyNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, PolicyNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@PolicyNo", DbType.String, DBNull.Value));
                if (EndtNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EndtNo", DbType.String, EndtNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@EndtNo", DbType.String, DBNull.Value));
                if (FlagCopy != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@FlagOriginal", DbType.Int16, FlagOriginal));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@FlagOriginal", DbType.Int16, DBNull.Value));
                if (FlagCopy != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@FlagCopy", DbType.Int16, FlagCopy));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@FlagCopy", DbType.Int16, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        public int spTAB2C_SetTransTaxInvoince(string PolicyNo, string JobNo, string UserID)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spTAB2C_SetTransTaxInvoince", CommandType.StoredProcedure);
                if (PolicyNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@POLICYNO", DbType.String, PolicyNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@POLICYNO", DbType.String, DBNull.Value));
                if (JobNo != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JOBNO", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@JOBNO", DbType.String, DBNull.Value));
                if (UserID != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@USERID", DbType.String, UserID));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@USERID", DbType.String, DBNull.Value));                

                return DbProviderHelper.ExecuteNonQuery(oDbCommand, false);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        public int spTAB2C_SetTransPayment(string HOSTRESP, string RESERVED1, string AUTHCODE, string RETURNINV, string SERVED2, string CARDNUMBER, string AMOUNT, string THBAMOUNT ,string CURISO, string FXRATE, string FILLSPACE)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand oDbCommand = DbProviderHelper.CreateCommand("spTAB2C_SetTransPayment", CommandType.StoredProcedure);
                if (HOSTRESP != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@HOSTRESP", DbType.String, HOSTRESP));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@HOSTRESP", DbType.String, DBNull.Value));
                if (RESERVED1 != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@RESERVED1", DbType.String, RESERVED1));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@RESERVED1", DbType.String, DBNull.Value));
                if (AUTHCODE != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AUTHCODE", DbType.String, AUTHCODE));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AUTHCODE", DbType.String, DBNull.Value));
                if (RETURNINV != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@RETURNINV", DbType.String, RETURNINV));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@RETURNINV", DbType.String, DBNull.Value));
                if (SERVED2 != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@SERVED2", DbType.String, SERVED2));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@SERVED2", DbType.String, DBNull.Value));
                if (CARDNUMBER != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CARDNUMBER", DbType.String, CARDNUMBER));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CARDNUMBER", DbType.String, DBNull.Value));
                if (AMOUNT != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AMOUNT", DbType.String, AMOUNT));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@AMOUNT", DbType.String, DBNull.Value));
                if (THBAMOUNT != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@THBAMOUNT", DbType.String, THBAMOUNT));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@THBAMOUNT", DbType.String, DBNull.Value));
                if (CURISO != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CURISO", DbType.String, CURISO));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@CURISO", DbType.String, DBNull.Value));
                if (FXRATE != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@FXRATE", DbType.String, FXRATE));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@FXRATE", DbType.String, DBNull.Value));
                if (FILLSPACE != null)
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@FILLSPACE", DbType.String, FILLSPACE));
                else
                    oDbCommand.Parameters.Add(DbProviderHelper.CreateParameter("@FILLSPACE", DbType.String, DBNull.Value));

                return DbProviderHelper.ExecuteNonQuery(oDbCommand, false);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        ///<summary>
        /// GET Policy By PassportID And Return(RefCode)
        /// <param name="PassportID"></param>
        /// <param name="RefCode"></param>
        /// <return></return>
        /// Add By Makkawat 2015-07-02
        public DataTable GetTATransPolicyByPassportIDAndReturn(string PassportID, string RefCode)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = DbProviderHelper.CreateCommand("spTA_GetPolicyByPassportIDAndReturn", CommandType.StoredProcedure);
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@i_PassportID", DbType.String, PassportID));
                comm.Parameters.Add(DbProviderHelper.CreateParameter("@i_RefCode", DbType.String, RefCode));

                // create DataAdapter object
                DbDataAdapter adap = DbProviderHelper.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return DbProviderHelper.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
	}
}
