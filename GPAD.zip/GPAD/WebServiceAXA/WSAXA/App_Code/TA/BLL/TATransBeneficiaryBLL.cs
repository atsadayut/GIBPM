using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;
using TA.DAL;

namespace TA.BLL
{
	public class TATransBeneficiaryBLL
	{
		private TATransBeneficiaryDAO _TATransBeneficiaryDAO;

		public TATransBeneficiaryDAO TATransBeneficiaryDAO
		{
			get { return _TATransBeneficiaryDAO; }
			set { _TATransBeneficiaryDAO = value; }
		}

		public TATransBeneficiaryBLL()
		{
			TATransBeneficiaryDAO = new TATransBeneficiaryDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<TATransBeneficiary> GetTATransBeneficiarys()
		{
			try
			{
				return TATransBeneficiaryDAO.GetTATransBeneficiarys();
			}
			catch(Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public TATransBeneficiary GetTATransBeneficiary(string JobNo,int TravelerID,int Seq)
		{
			try
			{
				return TATransBeneficiaryDAO.GetTATransBeneficiary(JobNo,TravelerID,Seq);
			}
			catch(Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int AddTATransBeneficiary(string JobNo,int TravelerID,int Seq,string BeneficiaryTitle,string BeneficiaryName,string BeneficiarySurName,string BeneficiaryRelation,string BeneficiaryRatio,string BeneficiaryTel)
		{
			try
			{
				return TATransBeneficiaryDAO.AddTATransBeneficiary(JobNo,TravelerID,Seq,BeneficiaryTitle,BeneficiaryName,BeneficiarySurName,BeneficiaryRelation,BeneficiaryRatio,BeneficiaryTel);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
		public int UpdateTATransBeneficiary(string JobNo,int TravelerID,int Seq,string BeneficiaryTitle,string BeneficiaryName,string BeneficiarySurName,string BeneficiaryRelation,string BeneficiaryRatio,string BeneficiaryTel)
		{
			try
			{
				return TATransBeneficiaryDAO.UpdateTATransBeneficiary(JobNo,TravelerID,Seq,BeneficiaryTitle,BeneficiaryName,BeneficiarySurName,BeneficiaryRelation,BeneficiaryRatio,BeneficiaryTel);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Delete, true)]
		public int RemoveTATransBeneficiary(string JobNo,int TravelerID,int Seq)
		{
			try
			{
				return TATransBeneficiaryDAO.RemoveTATransBeneficiary(JobNo,TravelerID,Seq);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public List<TATransBeneficiary> DeserializeTATransBeneficiarys(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<TATransBeneficiary>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public void SerializeTATransBeneficiarys(string Path, List<TATransBeneficiary> TATransBeneficiarys)
		{
			try
			{
				GenericXmlSerializer<List<TATransBeneficiary>>.Serialize(TATransBeneficiarys, Path);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}

  
        public int SetTATransBeneficiary(string JobNo, int TravelerID, int Seq, string BeneficiaryTitle, string BeneficiaryName, string BeneficiarySurName, string BeneficiaryRelation, string BeneficiaryRatio, string BeneficiaryTel)
        {
            try
            {
                return TATransBeneficiaryDAO.SetTATransBeneficiary(JobNo, TravelerID, Seq, BeneficiaryTitle, BeneficiaryName, BeneficiarySurName, BeneficiaryRelation, BeneficiaryRatio, BeneficiaryTel);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public int SetTATransBeneficiary(string JobNo, int TravelerID, int Seq, string BeneficiaryTitle, string BeneficiaryName, string BeneficiarySurName, string BeneficiaryRelation, string BeneficiaryRatio, string BeneficiaryTel, DbTransaction dbTransaction)
        {
            try
            {
                return TATransBeneficiaryDAO.SetTATransBeneficiary(JobNo, TravelerID, Seq, BeneficiaryTitle, BeneficiaryName, BeneficiarySurName, BeneficiaryRelation, BeneficiaryRatio, BeneficiaryTel, dbTransaction);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public DataTable GetDtTATransBeneficiary(string JobNo)
        {
            try
            {
                return TATransBeneficiaryDAO.GetDtTATransBeneficiary(JobNo);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public DataTable GetDtTATransBeneficiary(string JobNo, int TravelerID)
        {
            try
            {
                return TATransBeneficiaryDAO.GetDtTATransBeneficiary(JobNo, TravelerID);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }


        
	}
}
