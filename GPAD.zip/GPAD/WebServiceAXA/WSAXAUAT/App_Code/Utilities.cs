using System;
using System.Net;
using System.Net.Mail;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using System.Globalization;
using System.Data;

/// <summary>
/// Class contains miscellaneous functionality 
/// </summary>
public static class Utilities
{
    static Utilities()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    // Generic method for sending emails

    public static void SendMail(string from, string to, string subject, string body)
    {
        try
        {
            SmtpClient mailClient = new SmtpClient(QuickLinkConfiguration.MailServer);
            NetworkCredential nc = new NetworkCredential("qlhelpdesk", "password");
            mailClient.Credentials = nc;
            MailMessage mailMessage = new MailMessage(from, to, subject, body);
            mailClient.Send(mailMessage);
        }
        catch
        {

        }
    }
    public static void SendMail(string from, string to, string subject, string body, string cc)
    {
        try
        {
            SmtpClient mailClient = new SmtpClient(QuickLinkConfiguration.MailServer);
            NetworkCredential nc = new NetworkCredential("qlhelpdesk", "password");
            mailClient.Credentials = nc;
            MailMessage mailMessage = new MailMessage(from, to, subject, body);
            MailAddress mcc = new MailAddress(cc);
            mailMessage.CC.Add(mcc);
            mailClient.Send(mailMessage);
        }
        catch
        {

        }
    }

    public static void ReplySendMail(string from, string to, string subject, string body)
    {
        try
        {
            SmtpClient ReplymailClient = new SmtpClient(QuickLinkConfiguration.MailServer);
            NetworkCredential Replync = new NetworkCredential("qlhelpdesk", "password");
            ReplymailClient.Credentials = Replync;
            MailMessage ReplymailMessage = new MailMessage(from, to, subject, body);
            ReplymailClient.Send(ReplymailMessage);
        }
        catch
        {

        }
    }
    public static void SendMail(string from, string to, string subject, string body, bool isBodyHtml)
    {
        try
        {
            MailMessage mail = new MailMessage(from, to);
            mail.Subject = subject;
            mail.Body = body;
            mail.IsBodyHtml = isBodyHtml; //true,false
            SmtpClient smtp = new SmtpClient();
            smtp.Send(mail); 
        }
        catch
        { 
        
        }
    }
    public static void SendMail(string from, string to, string subject, string body, bool isBodyHtml, string filepath)
    {
        try
        {
            string cc = "TAB2C@axa.co.th";
            MailMessage mail = new MailMessage(from, to);
           
            mail.Subject = subject;
            mail.Body = body;
            mail.IsBodyHtml = isBodyHtml; //true,false

            System.Net.Mail.Attachment attachment;
            attachment = new Attachment(filepath);
            mail.Attachments.Add(attachment);

            SmtpClient smtp = new SmtpClient();

            MailAddress mcc = new MailAddress(cc);
            mail.CC.Add(mcc);

            smtp.Send(mail);            
        }
        catch
        {

        }
    }
    // Send error log mail
    public static void LogError(Exception ex)
    {
        try
        {
            // get the current date and time
            string dateTime = DateTime.Now.ToLongDateString() + ", at "
                            + DateTime.Now.ToShortTimeString();
            // stores the error message
            string errorMessage = "Exception generated on " + dateTime;
            // obtain the page that generated the error
            System.Web.HttpContext context = System.Web.HttpContext.Current;
            errorMessage += "\n\n Page location: " + context.Request.RawUrl;
            // build the error message
            errorMessage += "\n\n Message: " + ex.Message;
            errorMessage += "\n\n Source: " + ex.Source;
            errorMessage += "\n\n Method: " + ex.TargetSite;
            errorMessage += "\n\n Stack Trace: \n\n" + ex.StackTrace;
            // send error email in case the option is activated in Web.Config
            if (QuickLinkConfiguration.EnableErrorLogEmail)
            {
                string from = "QuickLinkHelpdesk@axa-insurance.co.th";//
                string to = QuickLinkConfiguration.ErrorLogEmail;
                string subject = QuickLinkConfiguration.SiteName + " error report";
                string body = errorMessage;
                SendMail(from, to, subject, body);
            }
        }
        catch
        {

        }
    }
    //
    public static string ConvertNullToEmptyString(string input)
    {
        return (input == null ? "" : input);
    }
    //
    public static string BrokerCode()
    {
        
        //string userName = "";
        //if (System.Web.HttpContext.Current.User.Identity.IsAuthenticated)
        //{ 
        //    userName = System.Web.HttpContext.Current.User.Identity.Name;
        //    return (Broker.GetBrokerNameByUsername(userName).Trim()); 
        //}
        //return "";
        try
        {
            string brokercode = "";
            brokercode = System.Web.HttpContext.Current.Session["BrokerCode"].ToString().Trim();
            if (brokercode.Equals("")|string.IsNullOrEmpty(brokercode))
            {
                return "";
            }
            else
            {
                return brokercode;
            }
        }
        catch (Exception ex)
        {
            return ""; 
        }
    }

    public static string GetGroupBrokerID()
    {
        //string userName = "";
        //if (System.Web.HttpContext.Current.User.Identity.IsAuthenticated)
        //{ 
        //    userName = System.Web.HttpContext.Current.User.Identity.Name;
        //    return (Broker.GetBrokerNameByUsername(userName).Trim()); 
        //}
        //return "";

        try
        {
            string groupBrokerID = "";
            groupBrokerID = System.Web.HttpContext.Current.Session["GroupBrokerID"].ToString().Trim();
            if (groupBrokerID.Equals("")|string.IsNullOrEmpty(groupBrokerID))
            {
                return "";
            }
            else
            {
                return groupBrokerID;
            }
        }
        catch (Exception ex)
        {
            return ""; 
        }
    }

    /// <summary>
    /// For Default BrokerID
    /// </summary>
    /// 
    public static void SetBrokerCodeDefault()
    {
        try
        {
            string temp = System.Web.HttpContext.Current.Session["BrokerCode"].ToString();
            string brokercode = "";
            string tempGroupBrokerID = "";
            if (temp.Trim().Equals("") | string.IsNullOrEmpty(temp))
            {
                DataTable dt = new DataTable();
                dt = Utilities.GetAllBrokerCodeInGroup();
                if (!dt.Equals(null))
                {
                    if (dt.Rows.Count > 0)
                    {
                        brokercode = dt.Rows[0]["BROKERCODE"].ToString().Trim();
                        tempGroupBrokerID = dt.Rows[0]["GROUPBROKERID"].ToString().Trim();
                        System.Web.HttpContext.Current.Session["BrokerCode"] = brokercode;
                        System.Web.HttpContext.Current.Session["GroupBrokerID"] = tempGroupBrokerID;

                    }
                }
            }
        }
        catch (Exception ex)
        {

        }

    }
 

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    /// 
    public static void SetGroupBrokerDefault()
    {
        try
        {
            string temp = System.Web.HttpContext.Current.Session["BrokerCode"].ToString();
            string temp2 = System.Web.HttpContext.Current.Session["GroupBrokerID"].ToString();
            string brokercode = "";
            string tempGroupBrokerID = "";
            if (temp2.Equals("") | string.IsNullOrEmpty(temp2))
            {
                DataTable dt = new DataTable();
                dt = Utilities.GetAllBrokerCodeInGroup();
                if (!dt.Equals(null))
                {
                    if (dt.Rows.Count > 0)
                    {
                        brokercode = dt.Rows[0]["BROKERCODE"].ToString().Trim();
                        tempGroupBrokerID = dt.Rows[0]["GROUPBROKERID"].ToString().Trim();
                        System.Web.HttpContext.Current.Session["BrokerCode"] = brokercode;
                        System.Web.HttpContext.Current.Session["GroupBrokerID"] = tempGroupBrokerID;

                    }
                }
            }
        }
        catch (Exception ex)
        {

        }

    }
    public static DataTable GetAllBrokerCodeInGroup()
    {
        string userName = "";
        if (System.Web.HttpContext.Current.User.Identity.IsAuthenticated)
        {
            userName = System.Web.HttpContext.Current.User.Identity.Name;
            if (userName.Trim().Equals("")) { return null; }
            return (Broker.GetAllBrokerInGroupByUsername(userName.Trim()));
        }
        return null;
    }
 
    public static string GetUsername()
    {
        string userName ="";
        if (System.Web.HttpContext.Current.User.Identity.IsAuthenticated)
           userName = System.Web.HttpContext.Current.User.Identity.Name;
                        if (userName.Trim().Equals("")) { return null; }
        return userName;
    }

    public static string CurrentUserIP
    {
        get { return System.Web.HttpContext.Current.Request.UserHostAddress; }
    }

    public static bool CheckEmpty(string str)
    {
        str = str.Trim();
        if ((str.Length) == 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public static string StringFormatWithCommaEng(string str)
    {
        
        CultureInfo culture = new CultureInfo("en-US");
        float tempFloat = Single.Parse(str.ToString());
        str = tempFloat.ToString("C", culture).Substring(1, tempFloat.ToString("C", culture).ToString().Length - 1);
        return str;
    }
    // Tile Button
    public static void TieButton(Page page, Control TextBoxToTie, Control ButtonToTie)
    {
        // Init jscript
        string jsString = "";

        // Check button type and get required jscript
        if (ButtonToTie is LinkButton)
        {
            jsString = "if ((event.which && event.which == 13) || (event.keyCode && event.keyCode == 13)) {"
                + page.ClientScript.GetPostBackEventReference(ButtonToTie, "").Replace(":", "$") + ";return false;} else return true;";
        }
        else if (ButtonToTie is ImageButton)
        {
            jsString = "if ((event.which && event.which == 13) || (event.keyCode && event.keyCode == 13)) {"
                + page.ClientScript.GetPostBackEventReference(ButtonToTie, "").Replace(":", "$") + ";return false;} else return true;";
        }
        else
        {
            jsString = "if ((event.which && event.which == 13) || (event.keyCode && event.keyCode == 13)) {document."
                + "forms[0].elements['" + ButtonToTie.UniqueID.Replace(":", "_") + "'].click();return false;} else return true; ";
        }

        // Attach jscript to the onkeydown attribute - we have to cater for HtmlControl or WebControl
        if (TextBoxToTie is HtmlControl)
        {
            ((HtmlControl)TextBoxToTie).Attributes.Add("onkeydown", jsString);
        }
        else if (TextBoxToTie is WebControl)
        {
            ((WebControl)TextBoxToTie).Attributes.Add("onkeydown", jsString);
        }
    }

    public static int getDay(string Date)
    {
        string tmp = Date[0].ToString();
        tmp += Date[1].ToString();
        return System.Convert.ToInt32(tmp);
    }
    public static int getMonth(string Date)
    {
        string tmp = Date[3].ToString();
        tmp += Date[4].ToString();
        return System.Convert.ToInt32(tmp);
    }
    public static int getYear(string Date)
    {
        string tmp = Date[6].ToString();
        tmp += Date[7].ToString();
        tmp += Date[8].ToString();
        tmp += Date[9].ToString();
        return System.Convert.ToInt32(tmp);
    }

    public static string getDayString(string Date)
    {
        string tmp = Date[0].ToString();
        tmp += Date[1].ToString();
        return tmp.Trim();
    }
    public static string getMonthString(string Date)
    {
        string tmp = Date[3].ToString();
        tmp += Date[4].ToString();
        return tmp.Trim();
    }
    public static string getYearString (string Date)
    {
        string tmp = Date[6].ToString();
        tmp += Date[7].ToString();
        tmp += Date[8].ToString();
        tmp += Date[9].ToString();
        return tmp.Trim();
    }

    //For ID Card UPDATE 2009-08-03
    //
    public static bool isCharDigit(char text)
    {
        switch (text)
        {
            case '1':
                return true;
            case '2':
                return true;
            case '3':
                return true;
            case '4':
                return true;
            case '5':
                return true;
            case '6':
                return true;
            case '7':
                return true;
            case '8':
                return true;
            case '9':
                return true;
            case '0':
                return true;
            default:
                return false;
        }
    }
    //For ID Card UPDATE 2009-08-03
    //
    public static bool isTextDidit(string text)
    {
        for (int i = 0; i < text.Length; i++)
        {
            if (!isCharDigit(text[i]))
            {
                return false;
            }
        }
        return true;
    }
    //For ID Card UPDATE 2009-08-03
    //
    public static bool isID(string text)
    {
        int sum = 0;
        if (isTextDidit(text))
        {
            if (text[0] < '1' || text[0] > '8')
            {
                return false;
            }
            else
            {
                for (int i = 0; i < 12; i++)
                {
                    sum = sum + int.Parse(text[i].ToString()) * (13 - i);
                }
                sum = (11 - (sum % 11)) % 10;
                if (sum == int.Parse(text[12].ToString()))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

        }
        else
        {
            return false;
        }
    }
    public static bool IsPolicyTypeCompulsary(string text)
    {
        //VBY,VCF,VCY,VMD,VMY,VPF,VPG,VPY,VSY
        switch (text)
        {
            case "VBY": return true;
            case "VCF": return true;
            case "VCY": return true;
            case "VMD": return true;
            case "VMY": return true;
            case "VPF": return true;
            case "VPG": return true;
            case "VPY": return true;
            case "VSY": return true;
            default: return false;
        }
    }

    public static double ExactNumber(string strnumber)
    {
        if (string.IsNullOrEmpty(strnumber))
        {
            return 0.00;
        }
        else
        {
            string temp1 = strnumber.Replace(",", "");
            return double.Parse(temp1);
        }
    }
}
