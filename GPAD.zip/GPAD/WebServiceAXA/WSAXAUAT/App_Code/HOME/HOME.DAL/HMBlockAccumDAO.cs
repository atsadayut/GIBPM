using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;

namespace HOME.DAL
{
	public class HMBlockAccumDAO
	{
        DbProviderHelper db;

		public HMBlockAccumDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}

        public DataTable GetHMBlock(string tumbol,string amphur, string province)
        {
            try
            {

                DbCommand comm = db.CreateCommand("spHM_getBlockAccum", CommandType.StoredProcedure);
                comm.Parameters.Add(db.CreateParameter("@Tumbol", DbType.String, tumbol));
                comm.Parameters.Add(db.CreateParameter("@Amphur", DbType.String, amphur));
                comm.Parameters.Add(db.CreateParameter("@Province", DbType.String, province));

                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                
                return db.FillDataTable(adap); ;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
		
	}
}
