using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;

namespace HOME.DAL
{
	public class HMStructurePackageDAO
	{
        DbProviderHelper db;

        public HMStructurePackageDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}

        public DataTable GetHMStructurePackages(string Language, string AOBCode)
		{
			try
			{
                DataTable data = new DataTable();

                DbCommand comm = db.CreateCommand("spHM_getStructurePackage", CommandType.StoredProcedure);
                comm.Parameters.Add(db.CreateParameter("@Language", DbType.String, Language));
                comm.Parameters.Add(db.CreateParameter("@AOBCode", DbType.String, AOBCode));

                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                db.FillDataTable(adap);
                adap.Fill(data);
                // get data and return with DataTable object
                db.CloseDb();
                return data;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		
	}
}
