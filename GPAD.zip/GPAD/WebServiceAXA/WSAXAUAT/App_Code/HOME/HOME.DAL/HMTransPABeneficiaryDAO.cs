using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;

namespace HOME.DAL
{
	public class HMTransPABeneficiaryDAO
	{
        DbProviderHelper db;

		public HMTransPABeneficiaryDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}

        public int AddHMTransPABeneficiary(string JobNo, int LocationNo, int PASeq, string PATitle, string PAName, string PASurName, string PAID, string PADOB, string PABeneficiary, string PARelation)
		{
			try
			{
                
                DbCommand oDbCommand = db.CreateCommand("spHM_setTransPABeneficiary", CommandType.StoredProcedure);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, PATitle));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (LocationNo != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LocationNo", DbType.Int16, LocationNo));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LocationNo", DbType.Int16, DBNull.Value));
                if (PASeq != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PASeq", DbType.Int16, PASeq));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PASeq", DbType.Int16, DBNull.Value));
				if (PATitle!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@PATitle",DbType.String,PATitle));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@PATitle",DbType.String,DBNull.Value));
				if (PAName!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@PAName",DbType.String,PAName));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@PAName",DbType.String,DBNull.Value));
				if (PASurName!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@PASurName",DbType.String,PASurName));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@PASurName",DbType.String,DBNull.Value));
				if (PAID!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@PAID",DbType.String,PAID));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@PAID",DbType.String,DBNull.Value));
				if (PADOB != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PADOB", DbType.String, PADOB));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PADOB", DbType.String, DBNull.Value));
				if (PABeneficiary!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@PABeneficiary",DbType.String,PABeneficiary));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@PABeneficiary",DbType.String,DBNull.Value));
				if (PARelation!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@PARelation",DbType.String,PARelation));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@PARelation",DbType.String,DBNull.Value));

				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

        public int AddHMTransPABeneficiary(DbProviderHelper db,string JobNo, int LocationNo, int PASeq, string PATitle, string PAName, string PASurName, string PAID, string PADOB, string PABeneficiary, string PARelation, DbTransaction dbTransaction)
        {
            try
            {

                DbCommand oDbCommand = db.CreateCommand("spHM_setTransPABeneficiary", CommandType.StoredProcedure, dbTransaction);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (LocationNo != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LocationNo", DbType.Int16, LocationNo));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LocationNo", DbType.Int16, DBNull.Value));
                if (PASeq != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PASeq", DbType.Int16, PASeq));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PASeq", DbType.Int16, DBNull.Value));
                if (PATitle != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PATitle", DbType.String, PATitle));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PATitle", DbType.String, DBNull.Value));
                if (PAName != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PAName", DbType.String, PAName));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PAName", DbType.String, DBNull.Value));
                if (PASurName != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PASurName", DbType.String, PASurName));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PASurName", DbType.String, DBNull.Value));
                if (PAID != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PAID", DbType.String, PAID));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PAID", DbType.String, DBNull.Value));
                if (PADOB != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PADOB", DbType.String, PADOB));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PADOB", DbType.String, DBNull.Value));
                if (PABeneficiary != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PABeneficiary", DbType.String, PABeneficiary));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PABeneficiary", DbType.String, DBNull.Value));
                if (PARelation != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PARelation", DbType.String, PARelation));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PARelation", DbType.String, DBNull.Value));

                return db.ExecuteNonQuery(oDbCommand, true);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
		
	}
}
