using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;

namespace HOME.DAL
{
	public class HMPlanPackageDAO
	{
        DbProviderHelper db;

		public HMPlanPackageDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}

        public DataTable GetHMPlanPackages(string groupBrokerId,string Language, string AOBCode, string StructurePackageCode, Int64 BuildingSumInsured, Int64 ContentSumInsured)
		{
			try
			{
                DataTable data = new DataTable();

                DbCommand comm = db.CreateCommand("spHM_getPlanPackage", CommandType.StoredProcedure);
                comm.Parameters.Add(db.CreateParameter("@groupBrokerId", DbType.String, groupBrokerId));
                comm.Parameters.Add(db.CreateParameter("@Language", DbType.String, Language));
                comm.Parameters.Add(db.CreateParameter("@AOBCode", DbType.String, AOBCode));
                comm.Parameters.Add(db.CreateParameter("@StructurePackageCode", DbType.String, StructurePackageCode));
                comm.Parameters.Add(db.CreateParameter("@BuildingSumInsured", DbType.Int64, BuildingSumInsured));
                comm.Parameters.Add(db.CreateParameter("@ContentSumInsured", DbType.Int64, ContentSumInsured));

                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                db.FillDataTable(adap);
                adap.Fill(data);
                // get data and return with DataTable object
                db.CloseDb();
                return data;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		
	}
}
