using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;

namespace HOME.DAL
{
	public class HMTransPropertyLocationDAO
	{
        DbProviderHelper db;

		public HMTransPropertyLocationDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}

        public int AddHMTransPropertyLocation(DbProviderHelper db,string JobNo, string Language, int LocationNo, string AOBCode, string StructurePackageCode, string PackageID, Int64 BuildingSumInsured, Int64 ContentSumInsured, Nullable<bool> IsVillage, string HouseCode, string Address1, string Address2, string Road, string Province, string Amphur, string Tumbol, string PostCode, string Latitude, string Longtitude, Nullable<bool> IsTenant, Nullable<int> StoreyCount, Nullable<int> BuildingCount, Nullable<int> RoomNo, Nullable<int> FloorNo, string TotalInternalArea, Nullable<Decimal> NetPremium, Nullable<int> Stamp, Nullable<Decimal> VAT, Nullable<Decimal> TotalPremium, DbTransaction dbTransaction)
		{
			try
			{

                DbCommand oDbCommand = db.CreateCommand("spHM_setTransPropertyLocation", CommandType.StoredProcedure, dbTransaction);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, JobNo));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (Language != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Language", DbType.String, Language));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Language", DbType.String, DBNull.Value));
                if (LocationNo != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LocationNo", DbType.Int16, LocationNo));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LocationNo", DbType.Int16, DBNull.Value));
                if (AOBCode != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@AOBCode", DbType.String, AOBCode));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@AOBCode", DbType.String, DBNull.Value));
                if (StructurePackageCode != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@StructurePackageCode", DbType.String, StructurePackageCode));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@StructurePackageCode", DbType.String, DBNull.Value));
                if (PackageID != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PackageID", DbType.String, PackageID));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PackageID", DbType.String, DBNull.Value));
                if (BuildingSumInsured != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@BuildingSumInsured", DbType.Int64, BuildingSumInsured));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@BuildingSumInsured", DbType.Int64, DBNull.Value));
                if (ContentSumInsured != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ContentSumInsured", DbType.Int64, ContentSumInsured));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ContentSumInsured", DbType.Int64, DBNull.Value));


                if (IsVillage != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@IsVillage", DbType.Boolean, IsVillage));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@IsVillage", DbType.Boolean, DBNull.Value));
				if (HouseCode!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@HouseCode",DbType.String,HouseCode));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@HouseCode",DbType.String,DBNull.Value));
				if (Address1!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Address1",DbType.String,Address1));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Address1",DbType.String,DBNull.Value));
				if (Address2!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Address2",DbType.String,Address2));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Address2",DbType.String,DBNull.Value));
                if (Road != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Road", DbType.String, Road));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Road", DbType.String, DBNull.Value));

				if (Province!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Province",DbType.String,Province));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Province",DbType.String,DBNull.Value));
				if (Amphur!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Amphur",DbType.String,Amphur));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Amphur",DbType.String,DBNull.Value));
				if (Tumbol!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Tumbol",DbType.String,Tumbol));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Tumbol",DbType.String,DBNull.Value));
				if (PostCode!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@PostCode",DbType.String,PostCode));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@PostCode",DbType.String,DBNull.Value));

                if (IsTenant.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@IsTenant", DbType.Boolean, IsTenant));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@IsTenant", DbType.Boolean, DBNull.Value));
				
				if (Latitude!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Latitude",DbType.String,Latitude));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Latitude",DbType.String,DBNull.Value));
				if (Longtitude!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Longtitude",DbType.String,Longtitude));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Longtitude",DbType.String,DBNull.Value));

                if (StoreyCount != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@StoreyCount", DbType.Int32, StoreyCount));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@StoreyCount", DbType.Int32, DBNull.Value));
                if (BuildingCount != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@BuildingCount", DbType.Int32, BuildingCount));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@BuildingCount", DbType.Int32, DBNull.Value));


				if (RoomNo.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@RoomNo",DbType.Int32,RoomNo));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@RoomNo",DbType.Int32,DBNull.Value));
				if (FloorNo.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@FloorNo",DbType.Int32,FloorNo));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@FloorNo",DbType.Int32,DBNull.Value));
                if (TotalInternalArea != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@TotalInternalArea", DbType.String, TotalInternalArea));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@TotalInternalArea", DbType.String, DBNull.Value));

                
				if (NetPremium.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@NetPremium",DbType.Decimal,NetPremium));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@NetPremium",DbType.Decimal,DBNull.Value));
				if (Stamp.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@Stamp",DbType.Int32,Stamp));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Stamp",DbType.Int32,DBNull.Value));
				if (VAT.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@VAT",DbType.Decimal,VAT));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@VAT",DbType.Decimal,DBNull.Value));
				
				if (TotalPremium.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@TotalPremium",DbType.Decimal,TotalPremium));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@TotalPremium",DbType.Decimal,DBNull.Value));

                return db.ExecuteNonQuery(oDbCommand, true);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		
	}
}
