using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;

namespace HOME.DAL
{
	public class HMInsuredSubGroupDAO
	{
        DbProviderHelper db;

		public HMInsuredSubGroupDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}

        public DataTable GetHMInsuredSubGroups(string Language)
		{
			try
			{
                DataTable data = new DataTable();

                DbCommand comm = db.CreateCommand("spHM_getDDLAppearanceOfBuilding", CommandType.StoredProcedure);
                comm.Parameters.Add(db.CreateParameter("@Language", DbType.String, Language));

                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                // get data and return with DataTable object
                adap.Fill(data);
                // get data and return with DataTable object
                db.CloseDb();
                return data;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		
	}
}
