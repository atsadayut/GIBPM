using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;

namespace HOME.DAL
{
	public class HMRestrictedAreaDAO
	{
        DbProviderHelper db;

		public HMRestrictedAreaDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}
        public bool CheckHMRestrictedAreas(string Address1, string Address2, string Road, string Tumbol, string Amphur, string Province)
		{
			try
			{
                DbCommand comm = db.CreateCommand("spHM_chkRestrictedArea", CommandType.StoredProcedure);
                comm.Parameters.Add(db.CreateParameter("@Address1", DbType.String, Address1));
                comm.Parameters.Add(db.CreateParameter("@Address2", DbType.String, Address2));
                comm.Parameters.Add(db.CreateParameter("@Road", DbType.String, Road));
                comm.Parameters.Add(db.CreateParameter("@Tumbol", DbType.String, Tumbol));
                comm.Parameters.Add(db.CreateParameter("@Amphur", DbType.String, Amphur));
                comm.Parameters.Add(db.CreateParameter("@Province", DbType.String, Province));

                DbDataReader oDbDataReader = db.ExecuteReader(comm);

                bool result = false;
				while (oDbDataReader.Read())
				{

                    if (oDbDataReader["IsRestrictedArea"] != DBNull.Value)
                        result = Convert.ToBoolean(oDbDataReader["IsRestrictedArea"]);

				}
				oDbDataReader.Close();
                return result;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		
	}
}
