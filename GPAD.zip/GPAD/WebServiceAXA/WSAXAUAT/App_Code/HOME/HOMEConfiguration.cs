﻿using System;
using System.Configuration;

/// <summary>
/// Summary description for HOMEConfiguration is 
/// Get data from web.config of this project to using at the module travel.
/// </summary>

namespace HOME
{
    public static class HOMEConfiguration
    {
        private readonly static string siteName;
        private readonly static string dbConnectionString;
        private readonly static string dbProviderName;

        // class constuctor
        static HOMEConfiguration()
        {
            //
            // TODO: Add constructor logic here
            //
            siteName = ConfigurationManager.AppSettings["SiteName"];
            dbConnectionString = ConfigurationManager.ConnectionStrings["HOMEDBConnectionString"].ConnectionString;
            dbProviderName = ConfigurationManager.ConnectionStrings["HOMEDBConnectionString"].ProviderName;
        }

        // Return site string name
        public static string SiteName
        {
            get
            {
                return siteName;
            }
        }

        // Return connection string name
        public static string DbConnectionString
        {
            get
            {
                return dbConnectionString;
            }
        }

        // Returns the data provider name
        public static string DbProviderName
        {
            get
            {
                return dbProviderName;
            }
        }
    }
}