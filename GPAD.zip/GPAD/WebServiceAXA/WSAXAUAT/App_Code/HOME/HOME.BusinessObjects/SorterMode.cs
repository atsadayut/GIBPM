using System;
using System.Text;

namespace HOME.BusinessObjects
{
	public enum SorterMode
	{
		Ascending,
		Descending
	}
}
