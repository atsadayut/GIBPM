using System;
using System.Text;

namespace HOME.BusinessObjects
{
	[Serializable()]
	public class HMStructurePackage
	{
		private string _PackageCode;

		public string PackageCode
		{
			get { return _PackageCode; }
			set { _PackageCode = value; }
		}

		private string _InsuredSubGroupCode;

		public string InsuredSubGroupCode
		{
			get { return _InsuredSubGroupCode; }
			set { _InsuredSubGroupCode = value; }
		}

		private string _EXTWALCode;

		public string EXTWALCode
		{
			get { return _EXTWALCode; }
			set { _EXTWALCode = value; }
		}

		private string _UPFLRCode;

		public string UPFLRCode
		{
			get { return _UPFLRCode; }
			set { _UPFLRCode = value; }
		}

		private string _ROOFBMCode;

		public string ROOFBMCode
		{
			get { return _ROOFBMCode; }
			set { _ROOFBMCode = value; }
		}

		private string _ROOFCode;

		public string ROOFCode
		{
			get { return _ROOFCode; }
			set { _ROOFCode = value; }
		}

		private string _WallCode;

		public string WallCode
		{
			get { return _WallCode; }
			set { _WallCode = value; }
		}

		private string _BRWallCode;

		public string BRWallCode
		{
			get { return _BRWallCode; }
			set { _BRWallCode = value; }
		}

		private string _BeamCode;

		public string BeamCode
		{
			get { return _BeamCode; }
			set { _BeamCode = value; }
		}

		private string _SFLOORCode;

		public string SFLOORCode
		{
			get { return _SFLOORCode; }
			set { _SFLOORCode = value; }
		}

		private string _StructureCode;

		public string StructureCode
		{
			get { return _StructureCode; }
			set { _StructureCode = value; }
		}

		private string _Class;

		public string Class
		{
			get { return _Class; }
			set { _Class = value; }
		}

		private string _CreatedBy;

		public string CreatedBy
		{
			get { return _CreatedBy; }
			set { _CreatedBy = value; }
		}

		private Nullable<DateTime> _CreatedDate;

		public Nullable<DateTime> CreatedDate
		{
			get { return _CreatedDate; }
			set { _CreatedDate = value; }
		}

		private string _UpdatedBy;

		public string UpdatedBy
		{
			get { return _UpdatedBy; }
			set { _UpdatedBy = value; }
		}

		private Nullable<DateTime> _UpdatedDate;

		public Nullable<DateTime> UpdatedDate
		{
			get { return _UpdatedDate; }
			set { _UpdatedDate = value; }
		}

		public HMStructurePackage()
		{ }

		public HMStructurePackage(string PackageCode,string InsuredSubGroupCode,string EXTWALCode,string UPFLRCode,string ROOFBMCode,string ROOFCode,string WallCode,string BRWallCode,string BeamCode,string SFLOORCode,string StructureCode,string Class,string CreatedBy,Nullable<DateTime> CreatedDate,string UpdatedBy,Nullable<DateTime> UpdatedDate)
		{
			this.PackageCode = PackageCode;
			this.InsuredSubGroupCode = InsuredSubGroupCode;
			this.EXTWALCode = EXTWALCode;
			this.UPFLRCode = UPFLRCode;
			this.ROOFBMCode = ROOFBMCode;
			this.ROOFCode = ROOFCode;
			this.WallCode = WallCode;
			this.BRWallCode = BRWallCode;
			this.BeamCode = BeamCode;
			this.SFLOORCode = SFLOORCode;
			this.StructureCode = StructureCode;
			this.Class = Class;
			this.CreatedBy = CreatedBy;
			this.CreatedDate = CreatedDate;
			this.UpdatedBy = UpdatedBy;
			this.UpdatedDate = UpdatedDate;
		}

		public override string ToString()
		{
			return "PackageCode = " + PackageCode + ",InsuredSubGroupCode = " + InsuredSubGroupCode + ",EXTWALCode = " + EXTWALCode + ",UPFLRCode = " + UPFLRCode + ",ROOFBMCode = " + ROOFBMCode + ",ROOFCode = " + ROOFCode + ",WallCode = " + WallCode + ",BRWallCode = " + BRWallCode + ",BeamCode = " + BeamCode + ",SFLOORCode = " + SFLOORCode + ",StructureCode = " + StructureCode + ",Class = " + Class + ",CreatedBy = " + CreatedBy + ",CreatedDate = " + CreatedDate.ToString() + ",UpdatedBy = " + UpdatedBy + ",UpdatedDate = " + UpdatedDate.ToString();
		}

		public class PackageCodeComparer : System.Collections.Generic.IComparer<HMStructurePackage>
		{
			public SorterMode SorterMode;
			public PackageCodeComparer()
			{ }
			public PackageCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMStructurePackage> Membres
			int System.Collections.Generic.IComparer<HMStructurePackage>.Compare(HMStructurePackage x, HMStructurePackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PackageCode.CompareTo(x.PackageCode);
				}
				else
				{
					return x.PackageCode.CompareTo(y.PackageCode);
				}
			}
			#endregion
		}
		public class InsuredSubGroupCodeComparer : System.Collections.Generic.IComparer<HMStructurePackage>
		{
			public SorterMode SorterMode;
			public InsuredSubGroupCodeComparer()
			{ }
			public InsuredSubGroupCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMStructurePackage> Membres
			int System.Collections.Generic.IComparer<HMStructurePackage>.Compare(HMStructurePackage x, HMStructurePackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.InsuredSubGroupCode.CompareTo(x.InsuredSubGroupCode);
				}
				else
				{
					return x.InsuredSubGroupCode.CompareTo(y.InsuredSubGroupCode);
				}
			}
			#endregion
		}
		public class EXTWALCodeComparer : System.Collections.Generic.IComparer<HMStructurePackage>
		{
			public SorterMode SorterMode;
			public EXTWALCodeComparer()
			{ }
			public EXTWALCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMStructurePackage> Membres
			int System.Collections.Generic.IComparer<HMStructurePackage>.Compare(HMStructurePackage x, HMStructurePackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.EXTWALCode.CompareTo(x.EXTWALCode);
				}
				else
				{
					return x.EXTWALCode.CompareTo(y.EXTWALCode);
				}
			}
			#endregion
		}
		public class UPFLRCodeComparer : System.Collections.Generic.IComparer<HMStructurePackage>
		{
			public SorterMode SorterMode;
			public UPFLRCodeComparer()
			{ }
			public UPFLRCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMStructurePackage> Membres
			int System.Collections.Generic.IComparer<HMStructurePackage>.Compare(HMStructurePackage x, HMStructurePackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.UPFLRCode.CompareTo(x.UPFLRCode);
				}
				else
				{
					return x.UPFLRCode.CompareTo(y.UPFLRCode);
				}
			}
			#endregion
		}
		public class ROOFBMCodeComparer : System.Collections.Generic.IComparer<HMStructurePackage>
		{
			public SorterMode SorterMode;
			public ROOFBMCodeComparer()
			{ }
			public ROOFBMCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMStructurePackage> Membres
			int System.Collections.Generic.IComparer<HMStructurePackage>.Compare(HMStructurePackage x, HMStructurePackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ROOFBMCode.CompareTo(x.ROOFBMCode);
				}
				else
				{
					return x.ROOFBMCode.CompareTo(y.ROOFBMCode);
				}
			}
			#endregion
		}
		public class ROOFCodeComparer : System.Collections.Generic.IComparer<HMStructurePackage>
		{
			public SorterMode SorterMode;
			public ROOFCodeComparer()
			{ }
			public ROOFCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMStructurePackage> Membres
			int System.Collections.Generic.IComparer<HMStructurePackage>.Compare(HMStructurePackage x, HMStructurePackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ROOFCode.CompareTo(x.ROOFCode);
				}
				else
				{
					return x.ROOFCode.CompareTo(y.ROOFCode);
				}
			}
			#endregion
		}
		public class WallCodeComparer : System.Collections.Generic.IComparer<HMStructurePackage>
		{
			public SorterMode SorterMode;
			public WallCodeComparer()
			{ }
			public WallCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMStructurePackage> Membres
			int System.Collections.Generic.IComparer<HMStructurePackage>.Compare(HMStructurePackage x, HMStructurePackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.WallCode.CompareTo(x.WallCode);
				}
				else
				{
					return x.WallCode.CompareTo(y.WallCode);
				}
			}
			#endregion
		}
		public class BRWallCodeComparer : System.Collections.Generic.IComparer<HMStructurePackage>
		{
			public SorterMode SorterMode;
			public BRWallCodeComparer()
			{ }
			public BRWallCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMStructurePackage> Membres
			int System.Collections.Generic.IComparer<HMStructurePackage>.Compare(HMStructurePackage x, HMStructurePackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.BRWallCode.CompareTo(x.BRWallCode);
				}
				else
				{
					return x.BRWallCode.CompareTo(y.BRWallCode);
				}
			}
			#endregion
		}
		public class BeamCodeComparer : System.Collections.Generic.IComparer<HMStructurePackage>
		{
			public SorterMode SorterMode;
			public BeamCodeComparer()
			{ }
			public BeamCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMStructurePackage> Membres
			int System.Collections.Generic.IComparer<HMStructurePackage>.Compare(HMStructurePackage x, HMStructurePackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.BeamCode.CompareTo(x.BeamCode);
				}
				else
				{
					return x.BeamCode.CompareTo(y.BeamCode);
				}
			}
			#endregion
		}
		public class SFLOORCodeComparer : System.Collections.Generic.IComparer<HMStructurePackage>
		{
			public SorterMode SorterMode;
			public SFLOORCodeComparer()
			{ }
			public SFLOORCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMStructurePackage> Membres
			int System.Collections.Generic.IComparer<HMStructurePackage>.Compare(HMStructurePackage x, HMStructurePackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.SFLOORCode.CompareTo(x.SFLOORCode);
				}
				else
				{
					return x.SFLOORCode.CompareTo(y.SFLOORCode);
				}
			}
			#endregion
		}
		public class StructureCodeComparer : System.Collections.Generic.IComparer<HMStructurePackage>
		{
			public SorterMode SorterMode;
			public StructureCodeComparer()
			{ }
			public StructureCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMStructurePackage> Membres
			int System.Collections.Generic.IComparer<HMStructurePackage>.Compare(HMStructurePackage x, HMStructurePackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.StructureCode.CompareTo(x.StructureCode);
				}
				else
				{
					return x.StructureCode.CompareTo(y.StructureCode);
				}
			}
			#endregion
		}
		public class ClassComparer : System.Collections.Generic.IComparer<HMStructurePackage>
		{
			public SorterMode SorterMode;
			public ClassComparer()
			{ }
			public ClassComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMStructurePackage> Membres
			int System.Collections.Generic.IComparer<HMStructurePackage>.Compare(HMStructurePackage x, HMStructurePackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.Class.CompareTo(x.Class);
				}
				else
				{
					return x.Class.CompareTo(y.Class);
				}
			}
			#endregion
		}
		public class CreatedByComparer : System.Collections.Generic.IComparer<HMStructurePackage>
		{
			public SorterMode SorterMode;
			public CreatedByComparer()
			{ }
			public CreatedByComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMStructurePackage> Membres
			int System.Collections.Generic.IComparer<HMStructurePackage>.Compare(HMStructurePackage x, HMStructurePackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CreatedBy.CompareTo(x.CreatedBy);
				}
				else
				{
					return x.CreatedBy.CompareTo(y.CreatedBy);
				}
			}
			#endregion
		}
		public class UpdatedByComparer : System.Collections.Generic.IComparer<HMStructurePackage>
		{
			public SorterMode SorterMode;
			public UpdatedByComparer()
			{ }
			public UpdatedByComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMStructurePackage> Membres
			int System.Collections.Generic.IComparer<HMStructurePackage>.Compare(HMStructurePackage x, HMStructurePackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.UpdatedBy.CompareTo(x.UpdatedBy);
				}
				else
				{
					return x.UpdatedBy.CompareTo(y.UpdatedBy);
				}
			}
			#endregion
		}
	}
}
