using System;
using System.Text;

namespace HOME.BusinessObjects
{
	[Serializable()]
	public class HMRestrictedArea
	{
		private int _ID;

		public int ID
		{
			get { return _ID; }
			set { _ID = value; }
		}

		private string _RestrictedType;

		public string RestrictedType
		{
			get { return _RestrictedType; }
			set { _RestrictedType = value; }
		}

		private string _SubDistrictID;

		public string SubDistrictID
		{
			get { return _SubDistrictID; }
			set { _SubDistrictID = value; }
		}

		private string _DistrictID;

		public string DistrictID
		{
			get { return _DistrictID; }
			set { _DistrictID = value; }
		}

		private string _ProvinceID;

		public string ProvinceID
		{
			get { return _ProvinceID; }
			set { _ProvinceID = value; }
		}

		private string _RoadTH;

		public string RoadTH
		{
			get { return _RoadTH; }
			set { _RoadTH = value; }
		}

		private string _RoadEN;

		public string RoadEN
		{
			get { return _RoadEN; }
			set { _RoadEN = value; }
		}

		private string _SubDistrictTH;

		public string SubDistrictTH
		{
			get { return _SubDistrictTH; }
			set { _SubDistrictTH = value; }
		}

		private string _SubDistrictEN;

		public string SubDistrictEN
		{
			get { return _SubDistrictEN; }
			set { _SubDistrictEN = value; }
		}

		private string _DistrictTH;

		public string DistrictTH
		{
			get { return _DistrictTH; }
			set { _DistrictTH = value; }
		}

		private string _DistrictEN;

		public string DistrictEN
		{
			get { return _DistrictEN; }
			set { _DistrictEN = value; }
		}

		private string _ProvinceTH;

		public string ProvinceTH
		{
			get { return _ProvinceTH; }
			set { _ProvinceTH = value; }
		}

		private string _ProvinceEn;

		public string ProvinceEn
		{
			get { return _ProvinceEn; }
			set { _ProvinceEn = value; }
		}

		private string _PostCode;

		public string PostCode
		{
			get { return _PostCode; }
			set { _PostCode = value; }
		}

		private Nullable<bool> _Status;

		public Nullable<bool> Status
		{
			get { return _Status; }
			set { _Status = value; }
		}

		public HMRestrictedArea()
		{ }

		public HMRestrictedArea(int ID,string RestrictedType,string SubDistrictID,string DistrictID,string ProvinceID,string RoadTH,string RoadEN,string SubDistrictTH,string SubDistrictEN,string DistrictTH,string DistrictEN,string ProvinceTH,string ProvinceEn,string PostCode,Nullable<bool> Status)
		{
			this.ID = ID;
			this.RestrictedType = RestrictedType;
			this.SubDistrictID = SubDistrictID;
			this.DistrictID = DistrictID;
			this.ProvinceID = ProvinceID;
			this.RoadTH = RoadTH;
			this.RoadEN = RoadEN;
			this.SubDistrictTH = SubDistrictTH;
			this.SubDistrictEN = SubDistrictEN;
			this.DistrictTH = DistrictTH;
			this.DistrictEN = DistrictEN;
			this.ProvinceTH = ProvinceTH;
			this.ProvinceEn = ProvinceEn;
			this.PostCode = PostCode;
			this.Status = Status;
		}

		public override string ToString()
		{
			return "ID = " + ID.ToString() + ",RestrictedType = " + RestrictedType + ",SubDistrictID = " + SubDistrictID + ",DistrictID = " + DistrictID + ",ProvinceID = " + ProvinceID + ",RoadTH = " + RoadTH + ",RoadEN = " + RoadEN + ",SubDistrictTH = " + SubDistrictTH + ",SubDistrictEN = " + SubDistrictEN + ",DistrictTH = " + DistrictTH + ",DistrictEN = " + DistrictEN + ",ProvinceTH = " + ProvinceTH + ",ProvinceEn = " + ProvinceEn + ",PostCode = " + PostCode + ",Status = " + Status.ToString();
		}

		public class IDComparer : System.Collections.Generic.IComparer<HMRestrictedArea>
		{
			public SorterMode SorterMode;
			public IDComparer()
			{ }
			public IDComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMRestrictedArea> Membres
			int System.Collections.Generic.IComparer<HMRestrictedArea>.Compare(HMRestrictedArea x, HMRestrictedArea y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ID.CompareTo(x.ID);
				}
				else
				{
					return x.ID.CompareTo(y.ID);
				}
			}
			#endregion
		}
		public class RestrictedTypeComparer : System.Collections.Generic.IComparer<HMRestrictedArea>
		{
			public SorterMode SorterMode;
			public RestrictedTypeComparer()
			{ }
			public RestrictedTypeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMRestrictedArea> Membres
			int System.Collections.Generic.IComparer<HMRestrictedArea>.Compare(HMRestrictedArea x, HMRestrictedArea y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.RestrictedType.CompareTo(x.RestrictedType);
				}
				else
				{
					return x.RestrictedType.CompareTo(y.RestrictedType);
				}
			}
			#endregion
		}
		public class SubDistrictIDComparer : System.Collections.Generic.IComparer<HMRestrictedArea>
		{
			public SorterMode SorterMode;
			public SubDistrictIDComparer()
			{ }
			public SubDistrictIDComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMRestrictedArea> Membres
			int System.Collections.Generic.IComparer<HMRestrictedArea>.Compare(HMRestrictedArea x, HMRestrictedArea y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.SubDistrictID.CompareTo(x.SubDistrictID);
				}
				else
				{
					return x.SubDistrictID.CompareTo(y.SubDistrictID);
				}
			}
			#endregion
		}
		public class DistrictIDComparer : System.Collections.Generic.IComparer<HMRestrictedArea>
		{
			public SorterMode SorterMode;
			public DistrictIDComparer()
			{ }
			public DistrictIDComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMRestrictedArea> Membres
			int System.Collections.Generic.IComparer<HMRestrictedArea>.Compare(HMRestrictedArea x, HMRestrictedArea y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.DistrictID.CompareTo(x.DistrictID);
				}
				else
				{
					return x.DistrictID.CompareTo(y.DistrictID);
				}
			}
			#endregion
		}
		public class ProvinceIDComparer : System.Collections.Generic.IComparer<HMRestrictedArea>
		{
			public SorterMode SorterMode;
			public ProvinceIDComparer()
			{ }
			public ProvinceIDComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMRestrictedArea> Membres
			int System.Collections.Generic.IComparer<HMRestrictedArea>.Compare(HMRestrictedArea x, HMRestrictedArea y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ProvinceID.CompareTo(x.ProvinceID);
				}
				else
				{
					return x.ProvinceID.CompareTo(y.ProvinceID);
				}
			}
			#endregion
		}
		public class RoadTHComparer : System.Collections.Generic.IComparer<HMRestrictedArea>
		{
			public SorterMode SorterMode;
			public RoadTHComparer()
			{ }
			public RoadTHComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMRestrictedArea> Membres
			int System.Collections.Generic.IComparer<HMRestrictedArea>.Compare(HMRestrictedArea x, HMRestrictedArea y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.RoadTH.CompareTo(x.RoadTH);
				}
				else
				{
					return x.RoadTH.CompareTo(y.RoadTH);
				}
			}
			#endregion
		}
		public class RoadENComparer : System.Collections.Generic.IComparer<HMRestrictedArea>
		{
			public SorterMode SorterMode;
			public RoadENComparer()
			{ }
			public RoadENComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMRestrictedArea> Membres
			int System.Collections.Generic.IComparer<HMRestrictedArea>.Compare(HMRestrictedArea x, HMRestrictedArea y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.RoadEN.CompareTo(x.RoadEN);
				}
				else
				{
					return x.RoadEN.CompareTo(y.RoadEN);
				}
			}
			#endregion
		}
		public class SubDistrictTHComparer : System.Collections.Generic.IComparer<HMRestrictedArea>
		{
			public SorterMode SorterMode;
			public SubDistrictTHComparer()
			{ }
			public SubDistrictTHComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMRestrictedArea> Membres
			int System.Collections.Generic.IComparer<HMRestrictedArea>.Compare(HMRestrictedArea x, HMRestrictedArea y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.SubDistrictTH.CompareTo(x.SubDistrictTH);
				}
				else
				{
					return x.SubDistrictTH.CompareTo(y.SubDistrictTH);
				}
			}
			#endregion
		}
		public class SubDistrictENComparer : System.Collections.Generic.IComparer<HMRestrictedArea>
		{
			public SorterMode SorterMode;
			public SubDistrictENComparer()
			{ }
			public SubDistrictENComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMRestrictedArea> Membres
			int System.Collections.Generic.IComparer<HMRestrictedArea>.Compare(HMRestrictedArea x, HMRestrictedArea y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.SubDistrictEN.CompareTo(x.SubDistrictEN);
				}
				else
				{
					return x.SubDistrictEN.CompareTo(y.SubDistrictEN);
				}
			}
			#endregion
		}
		public class DistrictTHComparer : System.Collections.Generic.IComparer<HMRestrictedArea>
		{
			public SorterMode SorterMode;
			public DistrictTHComparer()
			{ }
			public DistrictTHComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMRestrictedArea> Membres
			int System.Collections.Generic.IComparer<HMRestrictedArea>.Compare(HMRestrictedArea x, HMRestrictedArea y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.DistrictTH.CompareTo(x.DistrictTH);
				}
				else
				{
					return x.DistrictTH.CompareTo(y.DistrictTH);
				}
			}
			#endregion
		}
		public class DistrictENComparer : System.Collections.Generic.IComparer<HMRestrictedArea>
		{
			public SorterMode SorterMode;
			public DistrictENComparer()
			{ }
			public DistrictENComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMRestrictedArea> Membres
			int System.Collections.Generic.IComparer<HMRestrictedArea>.Compare(HMRestrictedArea x, HMRestrictedArea y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.DistrictEN.CompareTo(x.DistrictEN);
				}
				else
				{
					return x.DistrictEN.CompareTo(y.DistrictEN);
				}
			}
			#endregion
		}
		public class ProvinceTHComparer : System.Collections.Generic.IComparer<HMRestrictedArea>
		{
			public SorterMode SorterMode;
			public ProvinceTHComparer()
			{ }
			public ProvinceTHComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMRestrictedArea> Membres
			int System.Collections.Generic.IComparer<HMRestrictedArea>.Compare(HMRestrictedArea x, HMRestrictedArea y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ProvinceTH.CompareTo(x.ProvinceTH);
				}
				else
				{
					return x.ProvinceTH.CompareTo(y.ProvinceTH);
				}
			}
			#endregion
		}
		public class ProvinceEnComparer : System.Collections.Generic.IComparer<HMRestrictedArea>
		{
			public SorterMode SorterMode;
			public ProvinceEnComparer()
			{ }
			public ProvinceEnComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMRestrictedArea> Membres
			int System.Collections.Generic.IComparer<HMRestrictedArea>.Compare(HMRestrictedArea x, HMRestrictedArea y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ProvinceEn.CompareTo(x.ProvinceEn);
				}
				else
				{
					return x.ProvinceEn.CompareTo(y.ProvinceEn);
				}
			}
			#endregion
		}
		public class PostCodeComparer : System.Collections.Generic.IComparer<HMRestrictedArea>
		{
			public SorterMode SorterMode;
			public PostCodeComparer()
			{ }
			public PostCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMRestrictedArea> Membres
			int System.Collections.Generic.IComparer<HMRestrictedArea>.Compare(HMRestrictedArea x, HMRestrictedArea y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PostCode.CompareTo(x.PostCode);
				}
				else
				{
					return x.PostCode.CompareTo(y.PostCode);
				}
			}
			#endregion
		}
	}
}
