using System;
using System.Text;

namespace HOME.BusinessObjects
{
	[Serializable()]
	public class HMPlanPackage
	{
		private string _PackageID;

		public string PackageID
		{
			get { return _PackageID; }
			set { _PackageID = value; }
		}

		private string _PackageCode;

		public string PackageCode
		{
			get { return _PackageCode; }
			set { _PackageCode = value; }
		}

		private string _InsuredSubGroupCode;

		public string InsuredSubGroupCode
		{
			get { return _InsuredSubGroupCode; }
			set { _InsuredSubGroupCode = value; }
		}

		private string _PackageNameTH;

		public string PackageNameTH
		{
			get { return _PackageNameTH; }
			set { _PackageNameTH = value; }
		}

		private string _PackageNameEN;

		public string PackageNameEN
		{
			get { return _PackageNameEN; }
			set { _PackageNameEN = value; }
		}

		private Nullable<Decimal> _PercentRetention;

		public Nullable<Decimal> PercentRetention
		{
			get { return _PercentRetention; }
			set { _PercentRetention = value; }
		}

		private Nullable<Decimal> _AmountLimit;

		public Nullable<Decimal> AmountLimit
		{
			get { return _AmountLimit; }
			set { _AmountLimit = value; }
		}

		private Nullable<int> _AdditionalRate;

		public Nullable<int> AdditionalRate
		{
			get { return _AdditionalRate; }
			set { _AdditionalRate = value; }
		}

		private Nullable<int> _Factor;

		public Nullable<int> Factor
		{
			get { return _Factor; }
			set { _Factor = value; }
		}

		private string _ContractType;

		public string ContractType
		{
			get { return _ContractType; }
			set { _ContractType = value; }
		}

		private string _RiskType;

		public string RiskType
		{
			get { return _RiskType; }
			set { _RiskType = value; }
		}

		private string _PremiumClass;

		public string PremiumClass
		{
			get { return _PremiumClass; }
			set { _PremiumClass = value; }
		}

		private Nullable<int> _MinSumInsured;

		public Nullable<int> MinSumInsured
		{
			get { return _MinSumInsured; }
			set { _MinSumInsured = value; }
		}

		private Nullable<int> _MaxSumInsured;

		public Nullable<int> MaxSumInsured
		{
			get { return _MaxSumInsured; }
			set { _MaxSumInsured = value; }
		}

		private Nullable<SByte> _isEnable;

		public Nullable<SByte> isEnable
		{
			get { return _isEnable; }
			set { _isEnable = value; }
		}

		private string _CreatedBy;

		public string CreatedBy
		{
			get { return _CreatedBy; }
			set { _CreatedBy = value; }
		}

		private Nullable<DateTime> _CreatedDate;

		public Nullable<DateTime> CreatedDate
		{
			get { return _CreatedDate; }
			set { _CreatedDate = value; }
		}

		private string _UpdatedBy;

		public string UpdatedBy
		{
			get { return _UpdatedBy; }
			set { _UpdatedBy = value; }
		}

		private Nullable<DateTime> _UpdatedDate;

		public Nullable<DateTime> UpdatedDate
		{
			get { return _UpdatedDate; }
			set { _UpdatedDate = value; }
		}

		public HMPlanPackage()
		{ }

		public HMPlanPackage(string PackageID,string PackageCode,string InsuredSubGroupCode,string PackageNameTH,string PackageNameEN,Nullable<Decimal> PercentRetention,Nullable<Decimal> AmountLimit,Nullable<int> AdditionalRate,Nullable<int> Factor,string ContractType,string RiskType,string PremiumClass,Nullable<int> MinSumInsured,Nullable<int> MaxSumInsured,Nullable<SByte> isEnable,string CreatedBy,Nullable<DateTime> CreatedDate,string UpdatedBy,Nullable<DateTime> UpdatedDate)
		{
			this.PackageID = PackageID;
			this.PackageCode = PackageCode;
			this.InsuredSubGroupCode = InsuredSubGroupCode;
			this.PackageNameTH = PackageNameTH;
			this.PackageNameEN = PackageNameEN;
			this.PercentRetention = PercentRetention;
			this.AmountLimit = AmountLimit;
			this.AdditionalRate = AdditionalRate;
			this.Factor = Factor;
			this.ContractType = ContractType;
			this.RiskType = RiskType;
			this.PremiumClass = PremiumClass;
			this.MinSumInsured = MinSumInsured;
			this.MaxSumInsured = MaxSumInsured;
			this.isEnable = isEnable;
			this.CreatedBy = CreatedBy;
			this.CreatedDate = CreatedDate;
			this.UpdatedBy = UpdatedBy;
			this.UpdatedDate = UpdatedDate;
		}

		public override string ToString()
		{
			return "PackageID = " + PackageID + ",PackageCode = " + PackageCode + ",InsuredSubGroupCode = " + InsuredSubGroupCode + ",PackageNameTH = " + PackageNameTH + ",PackageNameEN = " + PackageNameEN + ",PercentRetention = " + PercentRetention.ToString() + ",AmountLimit = " + AmountLimit.ToString() + ",AdditionalRate = " + AdditionalRate.ToString() + ",Factor = " + Factor.ToString() + ",ContractType = " + ContractType + ",RiskType = " + RiskType + ",PremiumClass = " + PremiumClass + ",MinSumInsured = " + MinSumInsured.ToString() + ",MaxSumInsured = " + MaxSumInsured.ToString() + ",isEnable = " + isEnable.ToString() + ",CreatedBy = " + CreatedBy + ",CreatedDate = " + CreatedDate.ToString() + ",UpdatedBy = " + UpdatedBy + ",UpdatedDate = " + UpdatedDate.ToString();
		}

		public class PackageIDComparer : System.Collections.Generic.IComparer<HMPlanPackage>
		{
			public SorterMode SorterMode;
			public PackageIDComparer()
			{ }
			public PackageIDComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMPlanPackage> Membres
			int System.Collections.Generic.IComparer<HMPlanPackage>.Compare(HMPlanPackage x, HMPlanPackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PackageID.CompareTo(x.PackageID);
				}
				else
				{
					return x.PackageID.CompareTo(y.PackageID);
				}
			}
			#endregion
		}
		public class PackageCodeComparer : System.Collections.Generic.IComparer<HMPlanPackage>
		{
			public SorterMode SorterMode;
			public PackageCodeComparer()
			{ }
			public PackageCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMPlanPackage> Membres
			int System.Collections.Generic.IComparer<HMPlanPackage>.Compare(HMPlanPackage x, HMPlanPackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PackageCode.CompareTo(x.PackageCode);
				}
				else
				{
					return x.PackageCode.CompareTo(y.PackageCode);
				}
			}
			#endregion
		}
		public class InsuredSubGroupCodeComparer : System.Collections.Generic.IComparer<HMPlanPackage>
		{
			public SorterMode SorterMode;
			public InsuredSubGroupCodeComparer()
			{ }
			public InsuredSubGroupCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMPlanPackage> Membres
			int System.Collections.Generic.IComparer<HMPlanPackage>.Compare(HMPlanPackage x, HMPlanPackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.InsuredSubGroupCode.CompareTo(x.InsuredSubGroupCode);
				}
				else
				{
					return x.InsuredSubGroupCode.CompareTo(y.InsuredSubGroupCode);
				}
			}
			#endregion
		}
		public class PackageNameTHComparer : System.Collections.Generic.IComparer<HMPlanPackage>
		{
			public SorterMode SorterMode;
			public PackageNameTHComparer()
			{ }
			public PackageNameTHComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMPlanPackage> Membres
			int System.Collections.Generic.IComparer<HMPlanPackage>.Compare(HMPlanPackage x, HMPlanPackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PackageNameTH.CompareTo(x.PackageNameTH);
				}
				else
				{
					return x.PackageNameTH.CompareTo(y.PackageNameTH);
				}
			}
			#endregion
		}
		public class PackageNameENComparer : System.Collections.Generic.IComparer<HMPlanPackage>
		{
			public SorterMode SorterMode;
			public PackageNameENComparer()
			{ }
			public PackageNameENComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMPlanPackage> Membres
			int System.Collections.Generic.IComparer<HMPlanPackage>.Compare(HMPlanPackage x, HMPlanPackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PackageNameEN.CompareTo(x.PackageNameEN);
				}
				else
				{
					return x.PackageNameEN.CompareTo(y.PackageNameEN);
				}
			}
			#endregion
		}
		public class ContractTypeComparer : System.Collections.Generic.IComparer<HMPlanPackage>
		{
			public SorterMode SorterMode;
			public ContractTypeComparer()
			{ }
			public ContractTypeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMPlanPackage> Membres
			int System.Collections.Generic.IComparer<HMPlanPackage>.Compare(HMPlanPackage x, HMPlanPackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ContractType.CompareTo(x.ContractType);
				}
				else
				{
					return x.ContractType.CompareTo(y.ContractType);
				}
			}
			#endregion
		}
		public class RiskTypeComparer : System.Collections.Generic.IComparer<HMPlanPackage>
		{
			public SorterMode SorterMode;
			public RiskTypeComparer()
			{ }
			public RiskTypeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMPlanPackage> Membres
			int System.Collections.Generic.IComparer<HMPlanPackage>.Compare(HMPlanPackage x, HMPlanPackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.RiskType.CompareTo(x.RiskType);
				}
				else
				{
					return x.RiskType.CompareTo(y.RiskType);
				}
			}
			#endregion
		}
		public class PremiumClassComparer : System.Collections.Generic.IComparer<HMPlanPackage>
		{
			public SorterMode SorterMode;
			public PremiumClassComparer()
			{ }
			public PremiumClassComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMPlanPackage> Membres
			int System.Collections.Generic.IComparer<HMPlanPackage>.Compare(HMPlanPackage x, HMPlanPackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PremiumClass.CompareTo(x.PremiumClass);
				}
				else
				{
					return x.PremiumClass.CompareTo(y.PremiumClass);
				}
			}
			#endregion
		}
		public class CreatedByComparer : System.Collections.Generic.IComparer<HMPlanPackage>
		{
			public SorterMode SorterMode;
			public CreatedByComparer()
			{ }
			public CreatedByComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMPlanPackage> Membres
			int System.Collections.Generic.IComparer<HMPlanPackage>.Compare(HMPlanPackage x, HMPlanPackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CreatedBy.CompareTo(x.CreatedBy);
				}
				else
				{
					return x.CreatedBy.CompareTo(y.CreatedBy);
				}
			}
			#endregion
		}
		public class UpdatedByComparer : System.Collections.Generic.IComparer<HMPlanPackage>
		{
			public SorterMode SorterMode;
			public UpdatedByComparer()
			{ }
			public UpdatedByComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMPlanPackage> Membres
			int System.Collections.Generic.IComparer<HMPlanPackage>.Compare(HMPlanPackage x, HMPlanPackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.UpdatedBy.CompareTo(x.UpdatedBy);
				}
				else
				{
					return x.UpdatedBy.CompareTo(y.UpdatedBy);
				}
			}
			#endregion
		}
	}
}
