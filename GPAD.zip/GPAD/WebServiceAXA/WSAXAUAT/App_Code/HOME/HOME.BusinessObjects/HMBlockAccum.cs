using System;
using System.Text;

namespace HOME.BusinessObjects
{
	[Serializable()]
	public class HMBlockAccum
	{
		private string _RegisterCode;

		public string RegisterCode
		{
			get { return _RegisterCode; }
			set { _RegisterCode = value; }
		}

		private string _DistrictID;

		public string DistrictID
		{
			get { return _DistrictID; }
			set { _DistrictID = value; }
		}

		private string _ProvinceID;

		public string ProvinceID
		{
			get { return _ProvinceID; }
			set { _ProvinceID = value; }
		}

		private string _DistrictTH;

		public string DistrictTH
		{
			get { return _DistrictTH; }
			set { _DistrictTH = value; }
		}

		private string _DistrictEN;

		public string DistrictEN
		{
			get { return _DistrictEN; }
			set { _DistrictEN = value; }
		}

		private string _ProvinceTH;

		public string ProvinceTH
		{
			get { return _ProvinceTH; }
			set { _ProvinceTH = value; }
		}

		private string _ProvinceEn;

		public string ProvinceEn
		{
			get { return _ProvinceEn; }
			set { _ProvinceEn = value; }
		}

		private string _Block;

		public string Block
		{
			get { return _Block; }
			set { _Block = value; }
		}

		private string _BuildingEN;

		public string BuildingEN
		{
			get { return _BuildingEN; }
			set { _BuildingEN = value; }
		}

		private string _BuildindTH;

		public string BuildindTH
		{
			get { return _BuildindTH; }
			set { _BuildindTH = value; }
		}

		private string _Address;

		public string Address
		{
			get { return _Address; }
			set { _Address = value; }
		}

		private Nullable<Decimal> _Limit;

		public Nullable<Decimal> Limit
		{
			get { return _Limit; }
			set { _Limit = value; }
		}

		private Nullable<Decimal> _UsedTo;

		public Nullable<Decimal> UsedTo
		{
			get { return _UsedTo; }
			set { _UsedTo = value; }
		}

		private Nullable<Decimal> _Bookings;

		public Nullable<Decimal> Bookings
		{
			get { return _Bookings; }
			set { _Bookings = value; }
		}

		private Nullable<Decimal> _Balance;

		public Nullable<Decimal> Balance
		{
			get { return _Balance; }
			set { _Balance = value; }
		}

		private Nullable<bool> _Status;

		public Nullable<bool> Status
		{
			get { return _Status; }
			set { _Status = value; }
		}

		public HMBlockAccum()
		{ }

		public HMBlockAccum(string RegisterCode,string DistrictID,string ProvinceID,string DistrictTH,string DistrictEN,string ProvinceTH,string ProvinceEn,string Block,string BuildingEN,string BuildindTH,string Address,Nullable<Decimal> Limit,Nullable<Decimal> UsedTo,Nullable<Decimal> Bookings,Nullable<Decimal> Balance,Nullable<bool> Status)
		{
			this.RegisterCode = RegisterCode;
			this.DistrictID = DistrictID;
			this.ProvinceID = ProvinceID;
			this.DistrictTH = DistrictTH;
			this.DistrictEN = DistrictEN;
			this.ProvinceTH = ProvinceTH;
			this.ProvinceEn = ProvinceEn;
			this.Block = Block;
			this.BuildingEN = BuildingEN;
			this.BuildindTH = BuildindTH;
			this.Address = Address;
			this.Limit = Limit;
			this.UsedTo = UsedTo;
			this.Bookings = Bookings;
			this.Balance = Balance;
			this.Status = Status;
		}

		public override string ToString()
		{
			return "RegisterCode = " + RegisterCode + ",DistrictID = " + DistrictID + ",ProvinceID = " + ProvinceID + ",DistrictTH = " + DistrictTH + ",DistrictEN = " + DistrictEN + ",ProvinceTH = " + ProvinceTH + ",ProvinceEn = " + ProvinceEn + ",Block = " + Block + ",BuildingEN = " + BuildingEN + ",BuildindTH = " + BuildindTH + ",Address = " + Address + ",Limit = " + Limit.ToString() + ",UsedTo = " + UsedTo.ToString() + ",Bookings = " + Bookings.ToString() + ",Balance = " + Balance.ToString() + ",Status = " + Status.ToString();
		}

		public class RegisterCodeComparer : System.Collections.Generic.IComparer<HMBlockAccum>
		{
			public SorterMode SorterMode;
			public RegisterCodeComparer()
			{ }
			public RegisterCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMBlockAccum> Membres
			int System.Collections.Generic.IComparer<HMBlockAccum>.Compare(HMBlockAccum x, HMBlockAccum y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.RegisterCode.CompareTo(x.RegisterCode);
				}
				else
				{
					return x.RegisterCode.CompareTo(y.RegisterCode);
				}
			}
			#endregion
		}
		public class DistrictIDComparer : System.Collections.Generic.IComparer<HMBlockAccum>
		{
			public SorterMode SorterMode;
			public DistrictIDComparer()
			{ }
			public DistrictIDComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMBlockAccum> Membres
			int System.Collections.Generic.IComparer<HMBlockAccum>.Compare(HMBlockAccum x, HMBlockAccum y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.DistrictID.CompareTo(x.DistrictID);
				}
				else
				{
					return x.DistrictID.CompareTo(y.DistrictID);
				}
			}
			#endregion
		}
        public class ProvinceIDComparer : System.Collections.Generic.IComparer<HMBlockAccum>
		{
			public SorterMode SorterMode;
			public ProvinceIDComparer()
			{ }
			public ProvinceIDComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMBlockAccum> Membres
			int System.Collections.Generic.IComparer<HMBlockAccum>.Compare(HMBlockAccum x, HMBlockAccum y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ProvinceID.CompareTo(x.ProvinceID);
				}
				else
				{
					return x.ProvinceID.CompareTo(y.ProvinceID);
				}
			}
			#endregion
		}
        public class DistrictTHComparer : System.Collections.Generic.IComparer<HMBlockAccum>
		{
			public SorterMode SorterMode;
			public DistrictTHComparer()
			{ }
			public DistrictTHComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMBlockAccum> Membres
			int System.Collections.Generic.IComparer<HMBlockAccum>.Compare(HMBlockAccum x, HMBlockAccum y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.DistrictTH.CompareTo(x.DistrictTH);
				}
				else
				{
					return x.DistrictTH.CompareTo(y.DistrictTH);
				}
			}
			#endregion
		}
        public class DistrictENComparer : System.Collections.Generic.IComparer<HMBlockAccum>
		{
			public SorterMode SorterMode;
			public DistrictENComparer()
			{ }
			public DistrictENComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMBlockAccum> Membres
			int System.Collections.Generic.IComparer<HMBlockAccum>.Compare(HMBlockAccum x, HMBlockAccum y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.DistrictEN.CompareTo(x.DistrictEN);
				}
				else
				{
					return x.DistrictEN.CompareTo(y.DistrictEN);
				}
			}
			#endregion
		}
        public class ProvinceTHComparer : System.Collections.Generic.IComparer<HMBlockAccum>
		{
			public SorterMode SorterMode;
			public ProvinceTHComparer()
			{ }
			public ProvinceTHComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMBlockAccum> Membres
			int System.Collections.Generic.IComparer<HMBlockAccum>.Compare(HMBlockAccum x, HMBlockAccum y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ProvinceTH.CompareTo(x.ProvinceTH);
				}
				else
				{
					return x.ProvinceTH.CompareTo(y.ProvinceTH);
				}
			}
			#endregion
		}
        public class ProvinceEnComparer : System.Collections.Generic.IComparer<HMBlockAccum>
		{
			public SorterMode SorterMode;
			public ProvinceEnComparer()
			{ }
			public ProvinceEnComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMBlockAccum> Membres
			int System.Collections.Generic.IComparer<HMBlockAccum>.Compare(HMBlockAccum x, HMBlockAccum y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ProvinceEn.CompareTo(x.ProvinceEn);
				}
				else
				{
					return x.ProvinceEn.CompareTo(y.ProvinceEn);
				}
			}
			#endregion
		}
        public class BlockComparer : System.Collections.Generic.IComparer<HMBlockAccum>
		{
			public SorterMode SorterMode;
			public BlockComparer()
			{ }
			public BlockComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMBlockAccum> Membres
			int System.Collections.Generic.IComparer<HMBlockAccum>.Compare(HMBlockAccum x, HMBlockAccum y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.Block.CompareTo(x.Block);
				}
				else
				{
					return x.Block.CompareTo(y.Block);
				}
			}
			#endregion
		}
        public class BuildingENComparer : System.Collections.Generic.IComparer<HMBlockAccum>
		{
			public SorterMode SorterMode;
			public BuildingENComparer()
			{ }
			public BuildingENComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMBlockAccum> Membres
			int System.Collections.Generic.IComparer<HMBlockAccum>.Compare(HMBlockAccum x, HMBlockAccum y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.BuildingEN.CompareTo(x.BuildingEN);
				}
				else
				{
					return x.BuildingEN.CompareTo(y.BuildingEN);
				}
			}
			#endregion
		}
        public class BuildindTHComparer : System.Collections.Generic.IComparer<HMBlockAccum>
		{
			public SorterMode SorterMode;
			public BuildindTHComparer()
			{ }
			public BuildindTHComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMBlockAccum> Membres
			int System.Collections.Generic.IComparer<HMBlockAccum>.Compare(HMBlockAccum x, HMBlockAccum y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.BuildindTH.CompareTo(x.BuildindTH);
				}
				else
				{
					return x.BuildindTH.CompareTo(y.BuildindTH);
				}
			}
			#endregion
		}
        public class AddressComparer : System.Collections.Generic.IComparer<HMBlockAccum>
		{
			public SorterMode SorterMode;
			public AddressComparer()
			{ }
			public AddressComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMBlockAccum> Membres
			int System.Collections.Generic.IComparer<HMBlockAccum>.Compare(HMBlockAccum x, HMBlockAccum y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.Address.CompareTo(x.Address);
				}
				else
				{
					return x.Address.CompareTo(y.Address);
				}
			}
			#endregion
		}
	}
}
