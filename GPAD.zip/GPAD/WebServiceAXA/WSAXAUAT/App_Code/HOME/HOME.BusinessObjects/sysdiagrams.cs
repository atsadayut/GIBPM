using System;
using System.Text;

namespace HOME.BusinessObjects
{
	[Serializable()]
	public class sysdiagrams
	{
		private string _name;

		public string name
		{
			get { return _name; }
			set { _name = value; }
		}

		private int _principal_id;

		public int principal_id
		{
			get { return _principal_id; }
			set { _principal_id = value; }
		}

		private int _diagram_id;

		public int diagram_id
		{
			get { return _diagram_id; }
			set { _diagram_id = value; }
		}

		private Nullable<int> _version;

		public Nullable<int> version
		{
			get { return _version; }
			set { _version = value; }
		}

		private Byte[] _definition;

		public Byte[] definition
		{
			get { return _definition; }
			set { _definition = value; }
		}

		public sysdiagrams()
		{ }

		public sysdiagrams(string name,int principal_id,int diagram_id,Nullable<int> version,Byte[] definition)
		{
			this.name = name;
			this.principal_id = principal_id;
			this.diagram_id = diagram_id;
			this.version = version;
			this.definition = definition;
		}

		public override string ToString()
		{
			return "name = " + name + ",principal_id = " + principal_id.ToString() + ",diagram_id = " + diagram_id.ToString() + ",version = " + version.ToString() + ",definition = " + definition.ToString();
		}

		public class nameComparer : System.Collections.Generic.IComparer<sysdiagrams>
		{
			public SorterMode SorterMode;
			public nameComparer()
			{ }
			public nameComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<sysdiagrams> Membres
			int System.Collections.Generic.IComparer<sysdiagrams>.Compare(sysdiagrams x, sysdiagrams y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.name.CompareTo(x.name);
				}
				else
				{
					return x.name.CompareTo(y.name);
				}
			}
			#endregion
		}
		public class principal_idComparer : System.Collections.Generic.IComparer<sysdiagrams>
		{
			public SorterMode SorterMode;
			public principal_idComparer()
			{ }
			public principal_idComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<sysdiagrams> Membres
			int System.Collections.Generic.IComparer<sysdiagrams>.Compare(sysdiagrams x, sysdiagrams y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.principal_id.CompareTo(x.principal_id);
				}
				else
				{
					return x.principal_id.CompareTo(y.principal_id);
				}
			}
			#endregion
		}
		public class diagram_idComparer : System.Collections.Generic.IComparer<sysdiagrams>
		{
			public SorterMode SorterMode;
			public diagram_idComparer()
			{ }
			public diagram_idComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<sysdiagrams> Membres
			int System.Collections.Generic.IComparer<sysdiagrams>.Compare(sysdiagrams x, sysdiagrams y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.diagram_id.CompareTo(x.diagram_id);
				}
				else
				{
					return x.diagram_id.CompareTo(y.diagram_id);
				}
			}
			#endregion
		}
	}
}
