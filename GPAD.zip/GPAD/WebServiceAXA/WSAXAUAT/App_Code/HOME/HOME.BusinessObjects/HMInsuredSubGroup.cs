using System;
using System.Text;

namespace HOME.BusinessObjects
{
	[Serializable()]
	public class HMInsuredSubGroup
	{
		private string _InsuredSubGroupCode;

		public string InsuredSubGroupCode
		{
			get { return _InsuredSubGroupCode; }
			set { _InsuredSubGroupCode = value; }
		}

		private string _InsuredGroupCode;

		public string InsuredGroupCode
		{
			get { return _InsuredGroupCode; }
			set { _InsuredGroupCode = value; }
		}

		private string _InsuredSubGroupNameTH;

		public string InsuredSubGroupNameTH
		{
			get { return _InsuredSubGroupNameTH; }
			set { _InsuredSubGroupNameTH = value; }
		}

		private string _InsuredSubGroupNameEN;

		public string InsuredSubGroupNameEN
		{
			get { return _InsuredSubGroupNameEN; }
			set { _InsuredSubGroupNameEN = value; }
		}

		private Nullable<bool> _IsHighBuilding;

		public Nullable<bool> IsHighBuilding
		{
			get { return _IsHighBuilding; }
			set { _IsHighBuilding = value; }
		}

		private Nullable<bool> _IsNonIsolate;

		public Nullable<bool> IsNonIsolate
		{
			get { return _IsNonIsolate; }
			set { _IsNonIsolate = value; }
		}

		private Nullable<bool> _IsIsolate;

		public Nullable<bool> IsIsolate
		{
			get { return _IsIsolate; }
			set { _IsIsolate = value; }
		}

		private Nullable<bool> _Status;

		public Nullable<bool> Status
		{
			get { return _Status; }
			set { _Status = value; }
		}

		public HMInsuredSubGroup()
		{ }

		public HMInsuredSubGroup(string InsuredSubGroupCode,string InsuredGroupCode,string InsuredSubGroupNameTH,string InsuredSubGroupNameEN,Nullable<bool> IsHighBuilding,Nullable<bool> IsNonIsolate,Nullable<bool> IsIsolate,Nullable<bool> Status)
		{
			this.InsuredSubGroupCode = InsuredSubGroupCode;
			this.InsuredGroupCode = InsuredGroupCode;
			this.InsuredSubGroupNameTH = InsuredSubGroupNameTH;
			this.InsuredSubGroupNameEN = InsuredSubGroupNameEN;
			this.IsHighBuilding = IsHighBuilding;
			this.IsNonIsolate = IsNonIsolate;
			this.IsIsolate = IsIsolate;
			this.Status = Status;
		}

		public override string ToString()
		{
			return "InsuredSubGroupCode = " + InsuredSubGroupCode + ",InsuredGroupCode = " + InsuredGroupCode + ",InsuredSubGroupNameTH = " + InsuredSubGroupNameTH + ",InsuredSubGroupNameEN = " + InsuredSubGroupNameEN + ",IsHighBuilding = " + IsHighBuilding.ToString() + ",IsNonIsolate = " + IsNonIsolate.ToString() + ",IsIsolate = " + IsIsolate.ToString() + ",Status = " + Status.ToString();
		}

		public class InsuredSubGroupCodeComparer : System.Collections.Generic.IComparer<HMInsuredSubGroup>
		{
			public SorterMode SorterMode;
			public InsuredSubGroupCodeComparer()
			{ }
			public InsuredSubGroupCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMInsuredSubGroup> Membres
			int System.Collections.Generic.IComparer<HMInsuredSubGroup>.Compare(HMInsuredSubGroup x, HMInsuredSubGroup y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.InsuredSubGroupCode.CompareTo(x.InsuredSubGroupCode);
				}
				else
				{
					return x.InsuredSubGroupCode.CompareTo(y.InsuredSubGroupCode);
				}
			}
			#endregion
		}
		public class InsuredGroupCodeComparer : System.Collections.Generic.IComparer<HMInsuredSubGroup>
		{
			public SorterMode SorterMode;
			public InsuredGroupCodeComparer()
			{ }
			public InsuredGroupCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMInsuredSubGroup> Membres
			int System.Collections.Generic.IComparer<HMInsuredSubGroup>.Compare(HMInsuredSubGroup x, HMInsuredSubGroup y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.InsuredGroupCode.CompareTo(x.InsuredGroupCode);
				}
				else
				{
					return x.InsuredGroupCode.CompareTo(y.InsuredGroupCode);
				}
			}
			#endregion
		}
		public class InsuredSubGroupNameTHComparer : System.Collections.Generic.IComparer<HMInsuredSubGroup>
		{
			public SorterMode SorterMode;
			public InsuredSubGroupNameTHComparer()
			{ }
			public InsuredSubGroupNameTHComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMInsuredSubGroup> Membres
			int System.Collections.Generic.IComparer<HMInsuredSubGroup>.Compare(HMInsuredSubGroup x, HMInsuredSubGroup y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.InsuredSubGroupNameTH.CompareTo(x.InsuredSubGroupNameTH);
				}
				else
				{
					return x.InsuredSubGroupNameTH.CompareTo(y.InsuredSubGroupNameTH);
				}
			}
			#endregion
		}
		public class InsuredSubGroupNameENComparer : System.Collections.Generic.IComparer<HMInsuredSubGroup>
		{
			public SorterMode SorterMode;
			public InsuredSubGroupNameENComparer()
			{ }
			public InsuredSubGroupNameENComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<HMInsuredSubGroup> Membres
			int System.Collections.Generic.IComparer<HMInsuredSubGroup>.Compare(HMInsuredSubGroup x, HMInsuredSubGroup y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.InsuredSubGroupNameEN.CompareTo(x.InsuredSubGroupNameEN);
				}
				else
				{
					return x.InsuredSubGroupNameEN.CompareTo(y.InsuredSubGroupNameEN);
				}
			}
			#endregion
		}
	}
}
