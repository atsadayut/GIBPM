using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;
using HOME.DAL;

namespace HOME.BLL
{
	public class HMInsuredSubGroupBLL
	{
		private HMInsuredSubGroupDAO _HMInsuredSubGroupDAO;

		public HMInsuredSubGroupDAO HMInsuredSubGroupDAO
		{
			get { return _HMInsuredSubGroupDAO; }
			set { _HMInsuredSubGroupDAO = value; }
		}

		public HMInsuredSubGroupBLL()
		{
			HMInsuredSubGroupDAO = new HMInsuredSubGroupDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
        public DataTable GetHMInsuredSubGroups(string Language)
		{
			try
			{
                return HMInsuredSubGroupDAO.GetHMInsuredSubGroups(Language);
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		
		public List<HMInsuredSubGroup> DeserializeHMInsuredSubGroups(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<HMInsuredSubGroup>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public void SerializeHMInsuredSubGroups(string Path, List<HMInsuredSubGroup> HMInsuredSubGroups)
		{
			try
			{
				GenericXmlSerializer<List<HMInsuredSubGroup>>.Serialize(HMInsuredSubGroups, Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}
