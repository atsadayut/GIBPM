using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;
using HOME.DAL;

namespace HOME.BLL
{
	public class HMBlockAccumBLL
	{
		private HMBlockAccumDAO _HMBlockAccumDAO;

		public HMBlockAccumDAO HMBlockAccumDAO
		{
			get { return _HMBlockAccumDAO; }
			set { _HMBlockAccumDAO = value; }
		}

        public HMBlockAccumBLL()
		{
            HMBlockAccumDAO = new HMBlockAccumDAO();
		}

        [System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
        public DataTable GetHMBlock(string tumbol,string amphur, string province)
        {
            try
            {
                return HMBlockAccumDAO.GetHMBlock(tumbol,amphur, province);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

		public List<HMBlockAccum> DeserializeQTBlockAccums(string Path)
		{
			try
			{
                return GenericXmlSerializer<List<HMBlockAccum>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
        public void SerializeQTBlockAccums(string Path, List<HMBlockAccum> HMBlockAccums)
		{
			try
			{
                GenericXmlSerializer<List<HMBlockAccum>>.Serialize(HMBlockAccums, Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}
