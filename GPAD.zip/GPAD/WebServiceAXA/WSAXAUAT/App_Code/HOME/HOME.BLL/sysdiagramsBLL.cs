using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;
using HOME.DAL;

namespace HOME.BLL
{
	public class sysdiagramsBLL
	{
		private sysdiagramsDAO _sysdiagramsDAO;

		public sysdiagramsDAO sysdiagramsDAO
		{
			get { return _sysdiagramsDAO; }
			set { _sysdiagramsDAO = value; }
		}

		public sysdiagramsBLL()
		{
			sysdiagramsDAO = new sysdiagramsDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<sysdiagrams> Getsysdiagramss()
		{
			try
			{
				return sysdiagramsDAO.Getsysdiagramss();
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public sysdiagrams Getsysdiagrams(int diagram_id)
		{
			try
			{
				return sysdiagramsDAO.Getsysdiagrams(diagram_id);
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int Addsysdiagrams(string name,int principal_id,Nullable<int> version,Byte[] definition)
		{
			try
			{
				return sysdiagramsDAO.Addsysdiagrams(name,principal_id,version,definition);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
		public int Updatesysdiagrams(string name,int principal_id,int diagram_id,Nullable<int> version,Byte[] definition)
		{
			try
			{
				return sysdiagramsDAO.Updatesysdiagrams(name,principal_id,diagram_id,version,definition);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Delete, true)]
		public int Removesysdiagrams(int diagram_id)
		{
			try
			{
				return sysdiagramsDAO.Removesysdiagrams(diagram_id);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public List<sysdiagrams> Deserializesysdiagramss(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<sysdiagrams>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public void Serializesysdiagramss(string Path, List<sysdiagrams> sysdiagramss)
		{
			try
			{
				GenericXmlSerializer<List<sysdiagrams>>.Serialize(sysdiagramss, Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}
