using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;
using HOME.DAL;

namespace HOME.BLL
{
	public class HMLongTermRateBLL
	{
		private HMLongTermRateDAO _HMLongTermRateDAO;

		public HMLongTermRateDAO HMLongTermRateDAO
		{
			get { return _HMLongTermRateDAO; }
			set { _HMLongTermRateDAO = value; }
		}

		public HMLongTermRateBLL()
		{
			HMLongTermRateDAO = new HMLongTermRateDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
        public DataTable GetHMCoveredYears()
		{
			try
			{
                return HMLongTermRateDAO.GetHMCoveredYears();
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		
	}
}
