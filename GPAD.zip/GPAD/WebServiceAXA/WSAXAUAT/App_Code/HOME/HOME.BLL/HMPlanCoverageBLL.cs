using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;
using HOME.DAL;

namespace HOME.BLL
{
	public class HMPlanCoverageBLL
	{
		private HMPlanCoverageDAO _HMPlanCoverageDAO;

		public HMPlanCoverageDAO HMPlanCoverageDAO
		{
			get { return _HMPlanCoverageDAO; }
			set { _HMPlanCoverageDAO = value; }
		}

		public HMPlanCoverageBLL()
		{
			HMPlanCoverageDAO = new HMPlanCoverageDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
        public DataTable GetHMPlanCoverages(string AOBCode, string StructurePackageCode, string PackageID, Int64 BuildingSumInsured, Int64 ContentSumInsured)
		{
			try
			{
				return HMPlanCoverageDAO.GetHMPlanCoverages( AOBCode,  StructurePackageCode,  PackageID,  BuildingSumInsured,  ContentSumInsured);
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		
	}
}
