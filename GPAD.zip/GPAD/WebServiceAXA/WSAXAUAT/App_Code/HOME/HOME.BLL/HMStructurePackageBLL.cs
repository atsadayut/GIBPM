using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;
using HOME.DAL;

namespace HOME.BLL
{
	public class HMStructurePackageBLL
	{
		private HMStructurePackageDAO _HMStructurePackageDAO;

		public HMStructurePackageDAO HMStructurePackageDAO
		{
			get { return _HMStructurePackageDAO; }
			set { _HMStructurePackageDAO = value; }
		}

		public HMStructurePackageBLL()
		{
			HMStructurePackageDAO = new HMStructurePackageDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
        public DataTable GetHMStructurePackages(string Language, string AOBCode)
		{
			try
			{
                return HMStructurePackageDAO.GetHMStructurePackages(Language, AOBCode);
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		
		public List<HMStructurePackage> DeserializeHMStructurePackages(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<HMStructurePackage>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public void SerializeHMStructurePackages(string Path, List<HMStructurePackage> HMStructurePackages)
		{
			try
			{
				GenericXmlSerializer<List<HMStructurePackage>>.Serialize(HMStructurePackages, Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}
