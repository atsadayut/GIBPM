using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;
using HOME.DAL;

namespace HOME.BLL
{
	public class HMJobRunningBLL
	{
		private HMJobRunningDAO _HMJobRunningDAO;

		public HMJobRunningDAO HMJobRunningDAO
		{
			get { return _HMJobRunningDAO; }
			set { _HMJobRunningDAO = value; }
		}

		public HMJobRunningBLL()
		{
			HMJobRunningDAO = new HMJobRunningDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public string GetHMJobRunnings()
		{
			try
			{
                return HMJobRunningDAO.GetHMJobRunnings();
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		
		public List<HMJobRunning> DeserializeHMJobRunnings(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<HMJobRunning>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public void SerializeHMJobRunnings(string Path, List<HMJobRunning> HMJobRunnings)
		{
			try
			{
				GenericXmlSerializer<List<HMJobRunning>>.Serialize(HMJobRunnings, Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}
