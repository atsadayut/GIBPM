using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;
using HOME.DAL;

namespace HOME.BLL
{
	public class HMRestrictedAreaBLL
	{
		private HMRestrictedAreaDAO _HMRestrictedAreaDAO;

		public HMRestrictedAreaDAO HMRestrictedAreaDAO
		{
			get { return _HMRestrictedAreaDAO; }
			set { _HMRestrictedAreaDAO = value; }
		}

		public HMRestrictedAreaBLL()
		{
			HMRestrictedAreaDAO = new HMRestrictedAreaDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
        public bool CheckHMRestrictedAreas(string Address1, string Address2, string Road, string Tumbol, string Amphur, string Province)
		{
			try
			{
                return HMRestrictedAreaDAO.CheckHMRestrictedAreas( Address1,  Address2, Road,  Tumbol,  Amphur,  Province);
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		
		public List<HMRestrictedArea> DeserializeHMRestrictedAreas(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<HMRestrictedArea>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public void SerializeHMRestrictedAreas(string Path, List<HMRestrictedArea> HMRestrictedAreas)
		{
			try
			{
				GenericXmlSerializer<List<HMRestrictedArea>>.Serialize(HMRestrictedAreas, Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}
