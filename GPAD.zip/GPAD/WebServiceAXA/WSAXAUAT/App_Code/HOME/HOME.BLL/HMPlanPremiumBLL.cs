using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;
using HOME.DAL;

namespace HOME.BLL
{
	public class HMPlanPremiumBLL
	{
		private HMPlanPremiumDAO _HMPlanPremiumDAO;

		public HMPlanPremiumDAO HMPlanPremiumDAO
		{
			get { return _HMPlanPremiumDAO; }
			set { _HMPlanPremiumDAO = value; }
		}

		public HMPlanPremiumBLL()
		{
			HMPlanPremiumDAO = new HMPlanPremiumDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
        public DataTable GetHMPlanPremiums(string AOBCode, string StructurePackageCode, string PackageID, Int64 BuildingSumInsured, Int64 ContentSumInsured)
		{
			try
			{
                return HMPlanPremiumDAO.GetHMPlanPremium( AOBCode,  StructurePackageCode,  PackageID,  BuildingSumInsured,  ContentSumInsured);
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		
	}
}
