using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;
using HOME.DAL;

namespace HOME.BLL
{
	public class HMPlanPackageBLL
	{
		private HMPlanPackageDAO _HMPlanPackageDAO;

		public HMPlanPackageDAO HMPlanPackageDAO
		{
			get { return _HMPlanPackageDAO; }
			set { _HMPlanPackageDAO = value; }
		}

		public HMPlanPackageBLL()
		{
			HMPlanPackageDAO = new HMPlanPackageDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
        public DataTable GetHMPlanPackages(string groupBrokerId, string Language, string AOBCode, string StructurePackageCode, Int64 BuildingSumInsured, Int64 ContentSumInsured)
		{
			try
			{
                return HMPlanPackageDAO.GetHMPlanPackages(groupBrokerId, Language,  AOBCode,  StructurePackageCode,  BuildingSumInsured,  ContentSumInsured);
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		
	}
}
