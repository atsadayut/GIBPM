using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using HOME.BusinessObjects;
using HOME.DAL;

namespace HOME.BLL
{
	public class HMTransPropertyLocationBLL
	{
		private HMTransPropertyLocationDAO _HMTransPropertyLocationDAO;

		public HMTransPropertyLocationDAO HMTransPropertyLocationDAO
		{
			get { return _HMTransPropertyLocationDAO; }
			set { _HMTransPropertyLocationDAO = value; }
		}

		public HMTransPropertyLocationBLL()
		{
			HMTransPropertyLocationDAO = new HMTransPropertyLocationDAO();
		}
		
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
        public int AddHMTransPropertyLocation(DbProviderHelper db,string JobNo, string Language, int LocationNo, string AOBCode, string StructurePackageCode, string PackageID, Int64 BuildingSumInsured, Int64 ContentSumInsured, Nullable<bool> IsVillage, string HouseCode, string Address1, string Address2, string Road, string Province, string Amphur, string Tumbol, string PostCode, string Latitude, string Longtitude, Nullable<bool> IsTenant, Nullable<int> StoreyCount, Nullable<int> BuildingCount, Nullable<int> RoomNo, Nullable<int> FloorNo, string TotalInternalArea, Nullable<Decimal> NetPremium, Nullable<int> Stamp, Nullable<Decimal> VAT, Nullable<Decimal> TotalPremium, DbTransaction dbTransaction)
		{
			try
			{
                return HMTransPropertyLocationDAO.AddHMTransPropertyLocation(db,JobNo, Language, LocationNo, AOBCode, StructurePackageCode, PackageID, BuildingSumInsured, ContentSumInsured, IsVillage, HouseCode, Address1, Address2, Road, Province, Amphur, Tumbol, PostCode, Latitude, Longtitude, IsTenant, StoreyCount, BuildingCount, RoomNo, FloorNo, TotalInternalArea, NetPremium, Stamp, VAT, TotalPremium, dbTransaction);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		
	}
}
