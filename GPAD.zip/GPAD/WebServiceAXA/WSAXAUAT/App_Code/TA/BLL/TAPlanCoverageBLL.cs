using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;
using TA.DAL;

namespace TA.BLL
{
	public class TAPlanCoverageBLL
	{
		private TAPlanCoverageDAO _TAPlanCoverageDAO;

		public TAPlanCoverageDAO TAPlanCoverageDAO
		{
			get { return _TAPlanCoverageDAO; }
			set { _TAPlanCoverageDAO = value; }
		}

		public TAPlanCoverageBLL()
		{
			TAPlanCoverageDAO = new TAPlanCoverageDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<TAPlanCoverage> GetTAPlanCoverages()
		{
			try
			{
				return TAPlanCoverageDAO.GetTAPlanCoverages();
			}
			catch(Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public TAPlanCoverage GetTAPlanCoverage(int ID)
		{
			try
			{
				return TAPlanCoverageDAO.GetTAPlanCoverage(ID);
			}
			catch(Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int AddTAPlanCoverage(string PlanType,string CoverageType,string CoverageLine,string CoverageDetailEN,string CoverageDetailTH,string CoveragePlan1,string CoveragePlan2,string CoveragePlan3,string CoveragePlan4,string CoveragePlan5,Nullable<DateTime> CreateDate,string CreateUser,string FieldName)
		{
			try
			{
				return TAPlanCoverageDAO.AddTAPlanCoverage(PlanType,CoverageType,CoverageLine,CoverageDetailEN,CoverageDetailTH,CoveragePlan1,CoveragePlan2,CoveragePlan3,CoveragePlan4,CoveragePlan5,CreateDate,CreateUser,FieldName);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
		public int UpdateTAPlanCoverage(int ID,string PlanType,string CoverageType,string CoverageLine,string CoverageDetailEN,string CoverageDetailTH,string CoveragePlan1,string CoveragePlan2,string CoveragePlan3,string CoveragePlan4,string CoveragePlan5,Nullable<DateTime> CreateDate,string CreateUser,string FieldName)
		{
			try
			{
				return TAPlanCoverageDAO.UpdateTAPlanCoverage(ID,PlanType,CoverageType,CoverageLine,CoverageDetailEN,CoverageDetailTH,CoveragePlan1,CoveragePlan2,CoveragePlan3,CoveragePlan4,CoveragePlan5,CreateDate,CreateUser,FieldName);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Delete, true)]
		public int RemoveTAPlanCoverage(int ID)
		{
			try
			{
				return TAPlanCoverageDAO.RemoveTAPlanCoverage(ID);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public List<TAPlanCoverage> DeserializeTAPlanCoverages(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<TAPlanCoverage>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public void SerializeTAPlanCoverages(string Path, List<TAPlanCoverage> TAPlanCoverages)
		{
			try
			{
				GenericXmlSerializer<List<TAPlanCoverage>>.Serialize(TAPlanCoverages, Path);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}


        public int SetTAPlanCoverage(string PlanType, string CoverageType, string CoverageLine, string CoverageDetailEN, string CoverageDetailTH, string CoveragePlan1, string CoveragePlan2, string CoveragePlan3, string CoveragePlan4, string CoveragePlan5, Nullable<DateTime> CreateDate, string CreateUser, string FieldName)
        {
            try
            {
                return TAPlanCoverageDAO.SetTAPlanCoverage(PlanType, CoverageType, CoverageLine, CoverageDetailEN, CoverageDetailTH, CoveragePlan1, CoveragePlan2, CoveragePlan3, CoveragePlan4, CoveragePlan5, CreateDate, CreateUser, FieldName);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public DataTable GetDtTAPlanCoverages(string PlanID)
        {
            try
            {
                return TAPlanCoverageDAO.GetDtTAPlanCoverages(PlanID);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        public DataTable GetDtAllTAPlanCoverages()
        {
            try
            {
                return TAPlanCoverageDAO.GetDtAllTAPlanCoverages();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public int SetTAPlanCoverage(int ID, string CoveragePlan1, string CoveragePlan2, string CoveragePlan3, string CoveragePlan4, string CoveragePlan5, string CreateUser)
        {
            try
            {
                return TAPlanCoverageDAO.SetTAPlanCoverage(ID, CoveragePlan1, CoveragePlan2, CoveragePlan3, CoveragePlan4, CoveragePlan5, CreateUser);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
      
	}
}
