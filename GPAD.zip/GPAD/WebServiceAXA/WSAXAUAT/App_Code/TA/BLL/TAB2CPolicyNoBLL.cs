using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;
using TA.DAL;

namespace TA.BLL
{
	public class TAB2CPolicyNoBLL
	{
		private TAB2CPolicyNoDAO _TAB2CPolicyNoDAO;

		public TAB2CPolicyNoDAO TAB2CPolicyNoDAO
		{
			get { return _TAB2CPolicyNoDAO; }
			set { _TAB2CPolicyNoDAO = value; }
		}

		public TAB2CPolicyNoBLL()
		{
			TAB2CPolicyNoDAO = new TAB2CPolicyNoDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<TAB2CPolicyNo> GetTAB2CPolicyNos()
		{
			try
			{
				return TAB2CPolicyNoDAO.GetTAB2CPolicyNos();
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public TAB2CPolicyNo GetTAB2CPolicyNo(string PREFIX,int RUNNING)
		{
			try
			{
				return TAB2CPolicyNoDAO.GetTAB2CPolicyNo(PREFIX,RUNNING);
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int AddTAB2CPolicyNo(string PREFIX,int RUNNING)
		{
			try
			{
				return TAB2CPolicyNoDAO.AddTAB2CPolicyNo(PREFIX,RUNNING);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
        public string spTAB2C_SetPolicyNo()
        {
            try
            {
                return TAB2CPolicyNoDAO.spTAB2C_SetPolicyNo();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string spTAB2C_SetPolicyNo(string JobNo)
        {
            try
            {
                return TAB2CPolicyNoDAO.spTAB2C_SetPolicyNo(JobNo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Delete, true)]
		public int RemoveTAB2CPolicyNo(string PREFIX,int RUNNING)
		{
			try
			{
				return TAB2CPolicyNoDAO.RemoveTAB2CPolicyNo(PREFIX,RUNNING);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
        [System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
        public int spTAB2C_UpdatePolicyNoToJobNo(string JobNo, string PolicyNo, string RETURNINV)
        {
            try
            {
                return TAB2CPolicyNoDAO.spTAB2C_UpdatePolicyNoToJobNo(JobNo, PolicyNo, RETURNINV);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
		public List<TAB2CPolicyNo> DeserializeTAB2CPolicyNos(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<TAB2CPolicyNo>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public void SerializeTAB2CPolicyNos(string Path, List<TAB2CPolicyNo> TAB2CPolicyNos)
		{
			try
			{
				GenericXmlSerializer<List<TAB2CPolicyNo>>.Serialize(TAB2CPolicyNos, Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

        //Krit Update 20150317
        public DataTable spTAB2C_FindPolicyNoByRef(string RETURNINV)
        {
            try
            {
                return TAB2CPolicyNoDAO.spTAB2C_FindPolicyNoByRef(RETURNINV);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
	}
}
