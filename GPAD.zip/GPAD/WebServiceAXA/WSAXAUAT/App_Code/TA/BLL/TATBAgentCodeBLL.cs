using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;
using TA.DAL;

namespace TA.BLL
{
	public class TATBAgentCodeBLL
	{
		private TATBAgentCodeDAO _TATBAgentCodeDAO;

		public TATBAgentCodeDAO TATBAgentCodeDAO
		{
			get { return _TATBAgentCodeDAO; }
			set { _TATBAgentCodeDAO = value; }
		}

		public TATBAgentCodeBLL()
		{
			TATBAgentCodeDAO = new TATBAgentCodeDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<TATBAgentCode> GetTATBAgentCodes()
		{
			try
			{
				return TATBAgentCodeDAO.GetTATBAgentCodes();
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int AddTATBAgentCode(string GroupID,string AgentCode,string Password,string Branch,string AgentName,string AccountType,string AccountTypeName,string AgentLicenseNo,Nullable<int> AgentStartDate,Nullable<int> AgentEndDate,string ModifiedDateTime,string LSurname,string LGivname)
		{
			try
			{
				return TATBAgentCodeDAO.AddTATBAgentCode(GroupID,AgentCode,Password,Branch,AgentName,AccountType,AccountTypeName,AgentLicenseNo,AgentStartDate,AgentEndDate,ModifiedDateTime,LSurname,LGivname);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}


        [System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
        public TATBAgentCode spTAB2C_GetAgentCode(string GroupID, string AgentCode)
        {
            try
            {
                return TATBAgentCodeDAO.spTAB2C_GetAgentCode(GroupID, AgentCode);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
        public int spTAB2C_SetAgentCode(string GroupID, string AgentCode, string Password, string Branch, string AgentName, string AccountType, string AccountTypeName, string AgentLicenseNo, Nullable<int> AgentStartDate, Nullable<int> AgentEndDate, string LSurname, string LGivname)
        {
            try
            {
                return TATBAgentCodeDAO.spTAB2C_SetAgentCode(GroupID, AgentCode, Password, Branch, AgentName, AccountType, AccountTypeName, AgentLicenseNo, AgentStartDate, AgentEndDate, LSurname, LGivname);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
		

        public List<TATBAgentCode> DeserializeTATBAgentCodes(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<TATBAgentCode>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public void SerializeTATBAgentCodes(string Path, List<TATBAgentCode> TATBAgentCodes)
		{
			try
			{
				GenericXmlSerializer<List<TATBAgentCode>>.Serialize(TATBAgentCodes, Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}
