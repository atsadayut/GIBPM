using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;
using TA.DAL;

namespace TA.BLL
{
	public class TAPlanCampaignBLL
	{
		private TAPlanCampaignDAO _TAPlanCampaignDAO;

		public TAPlanCampaignDAO TAPlanCampaignDAO
		{
			get { return _TAPlanCampaignDAO; }
			set { _TAPlanCampaignDAO = value; }
		}

		public TAPlanCampaignBLL()
		{
			TAPlanCampaignDAO = new TAPlanCampaignDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<TAPlanCampaign> GetTAPlanCampaigns()
		{
			try
			{
				return TAPlanCampaignDAO.GetTAPlanCampaigns();
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public TAPlanCampaign GetTAPlanCampaign(string CampaignCode)
		{
			try
			{
				return TAPlanCampaignDAO.GetTAPlanCampaign(CampaignCode);
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int AddTAPlanCampaign(string CampaignCode,string CampaignName,Nullable<int> PercentDiscount,Nullable<DateTime> StartDate,Nullable<DateTime> EndDate,Nullable<int> CampaignType,Nullable<SByte> isEnabel,string CreatedUser,Nullable<DateTime> CreatedDate)
		{
			try
			{
				return TAPlanCampaignDAO.AddTAPlanCampaign(CampaignCode,CampaignName,PercentDiscount,StartDate,EndDate,CampaignType,isEnabel,CreatedUser,CreatedDate);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
		public int UpdateTAPlanCampaign(string CampaignCode,string CampaignName,Nullable<int> PercentDiscount,Nullable<DateTime> StartDate,Nullable<DateTime> EndDate,Nullable<int> CampaignType,Nullable<SByte> isEnabel,string CreatedUser,Nullable<DateTime> CreatedDate)
		{
			try
			{
				return TAPlanCampaignDAO.UpdateTAPlanCampaign(CampaignCode,CampaignName,PercentDiscount,StartDate,EndDate,CampaignType,isEnabel,CreatedUser,CreatedDate);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Delete, true)]
		public int RemoveTAPlanCampaign(string CampaignCode)
		{
			try
			{
				return TAPlanCampaignDAO.RemoveTAPlanCampaign(CampaignCode);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
        [System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
        public int spTA_GetCampaignDiscount(int type, string Country)
        {
            try
            {
                return TAPlanCampaignDAO.spTA_GetCampaignDiscount(type, Country);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
		public List<TAPlanCampaign> DeserializeTAPlanCampaigns(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<TAPlanCampaign>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public void SerializeTAPlanCampaigns(string Path, List<TAPlanCampaign> TAPlanCampaigns)
		{
			try
			{
				GenericXmlSerializer<List<TAPlanCampaign>>.Serialize(TAPlanCampaigns, Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}
