using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;
using TA.DAL;

namespace TA.BLL
{
	public class TATBPlanIDBLL
	{
		private TATBPlanIDDAO _TATBPlanIDDAO;

		public TATBPlanIDDAO TATBPlanIDDAO
		{
			get { return _TATBPlanIDDAO; }
			set { _TATBPlanIDDAO = value; }
		}

		public TATBPlanIDBLL()
		{
			TATBPlanIDDAO = new TATBPlanIDDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<TATBPlanID> GetTATBPlanIDs()
		{
			try
			{
				return TATBPlanIDDAO.GetTATBPlanIDs();
			}
			catch(Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public TATBPlanID GetTATBPlanID(string PlanID)
		{
			try
			{
				return TATBPlanIDDAO.GetTATBPlanID(PlanID);
			}
			catch(Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int AddTATBPlanID(string PlanID,string PlanName,Nullable<SByte> isEnable,Nullable<DateTime> CreateDate)
		{
			try
			{
				return TATBPlanIDDAO.AddTATBPlanID(PlanID,PlanName,isEnable,CreateDate);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
		public int UpdateTATBPlanID(string PlanID,string PlanName,Nullable<SByte> isEnable,Nullable<DateTime> CreateDate)
		{
			try
			{
				return TATBPlanIDDAO.UpdateTATBPlanID(PlanID,PlanName,isEnable,CreateDate);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Delete, true)]
		public int RemoveTATBPlanID(string PlanID)
		{
			try
			{
				return TATBPlanIDDAO.RemoveTATBPlanID(PlanID);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public List<TATBPlanID> DeserializeTATBPlanIDs(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<TATBPlanID>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public void SerializeTATBPlanIDs(string Path, List<TATBPlanID> TATBPlanIDs)
		{
			try
			{
				GenericXmlSerializer<List<TATBPlanID>>.Serialize(TATBPlanIDs, Path);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}

        
        public int SetTATBPlanID(string PlanID, string PlanName, Nullable<SByte> isEnable, Nullable<DateTime> CreateDate)
        {
            try
            {
                return TATBPlanIDDAO.AddTATBPlanID(PlanID, PlanName, isEnable, CreateDate);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public DataTable GetDtTATBPlanIDs()
        {
            try
            {
                return TATBPlanIDDAO.GetDtTATBPlanIDs();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

	}
}
