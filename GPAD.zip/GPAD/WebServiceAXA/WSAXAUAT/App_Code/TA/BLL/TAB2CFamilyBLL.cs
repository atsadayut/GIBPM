using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;
using TA.DAL;

namespace TA.BLL
{
	public class TAB2CFamilyBLL
	{
		private TAB2CFamilyDAO _TAB2CFamilyDAO;

		public TAB2CFamilyDAO TAB2CFamilyDAO
		{
			get { return _TAB2CFamilyDAO; }
			set { _TAB2CFamilyDAO = value; }
		}

		public TAB2CFamilyBLL()
		{
			TAB2CFamilyDAO = new TAB2CFamilyDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<TAB2CFamily> GetTAB2CFamilys()
		{
			try
			{
				return TAB2CFamilyDAO.GetTAB2CFamilys();
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
        public List<TAB2CFamily> GetTAB2CFamily(string GroupBrokerId)
        {
            try
            {
                return TAB2CFamilyDAO.GetTAB2CFamily(GroupBrokerId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public TAB2CFamily GetTAB2CFamily(string GroupBrokerId,int SEQ)
		{
			try
			{
				return TAB2CFamilyDAO.GetTAB2CFamily(GroupBrokerId,SEQ);
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
        public int AddTAB2CFamily(string GroupBrokerId, int SEQ, string ClientCode, string ClientType, string ClientTitle, string ClientName, string ClientSurName, string ClientAddress1, string ClientAddress2, string Province, string Amphur, string Tumbol, string PostCode, string CountryCode, string Birthday, string ClientSEX, string ClientStatus, string PassportID, string IDCard, string TaxID, string Tel, string Email, string Language, Nullable<DateTime> CreateDate, string Message)
		{
			try
			{
				return TAB2CFamilyDAO.AddTAB2CFamily(GroupBrokerId,SEQ,ClientCode,ClientType,ClientTitle,ClientName,ClientSurName,ClientAddress1,ClientAddress2,Province,Amphur,Tumbol,PostCode,CountryCode,Birthday,ClientSEX,ClientStatus,PassportID,IDCard,TaxID,Tel,Email,Language,CreateDate,Message);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
        public int UpdateTAB2CFamily(string GroupBrokerId, int SEQ, string ClientCode, string ClientType, string ClientTitle, string ClientName, string ClientSurName, string ClientAddress1, string ClientAddress2, string Province, string Amphur, string Tumbol, string PostCode, string CountryCode, string Birthday, string ClientSEX, string ClientStatus, string PassportID, string IDCard, string TaxID, string Tel, string Email, string Language, Nullable<DateTime> CreateDate, string Message)
		{
			try
			{
				return TAB2CFamilyDAO.UpdateTAB2CFamily(GroupBrokerId,SEQ,ClientCode,ClientType,ClientTitle,ClientName,ClientSurName,ClientAddress1,ClientAddress2,Province,Amphur,Tumbol,PostCode,CountryCode,Birthday,ClientSEX,ClientStatus,PassportID,IDCard,TaxID,Tel,Email,Language,CreateDate,Message);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Delete, true)]
		public int RemoveTAB2CFamily(string GroupBrokerId,int SEQ)
		{
			try
			{
				return TAB2CFamilyDAO.RemoveTAB2CFamily(GroupBrokerId,SEQ);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public List<TAB2CFamily> DeserializeTAB2CFamilys(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<TAB2CFamily>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public void SerializeTAB2CFamilys(string Path, List<TAB2CFamily> TAB2CFamilys)
		{
			try
			{
				GenericXmlSerializer<List<TAB2CFamily>>.Serialize(TAB2CFamilys, Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}
