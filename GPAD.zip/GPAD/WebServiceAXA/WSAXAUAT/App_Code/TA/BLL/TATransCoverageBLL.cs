using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;
using TA.DAL;

namespace TA.BLL
{
	public class TATransCoverageBLL
	{
		private TATransCoverageDAO _TATransCoverageDAO;

		public TATransCoverageDAO TATransCoverageDAO
		{
			get { return _TATransCoverageDAO; }
			set { _TATransCoverageDAO = value; }
		}

		public TATransCoverageBLL()
		{
			TATransCoverageDAO = new TATransCoverageDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<TATransCoverage> GetTATransCoverages()
		{
			try
			{
				return TATransCoverageDAO.GetTATransCoverages();
			}
			catch(Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public TATransCoverage GetTATransCoverage(string JobNo)
		{
			try
			{
				return TATransCoverageDAO.GetTATransCoverage(JobNo);
			}
			catch(Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int AddTATransCoverage(string JobNo,string PersonalAccident,string MedicalExpense,string EmergencyMedical,string Repatriation,string PersonalLiability,string TripCancellation,string TravelDelay,string FlightMisconnection,string TripCurtailment,string BaggageDelay,string LossBaggage,string LossPersonalMoney,string LossTravelDocument,string CompassionateVisitation,string ReturnChildren,string AutomaticExtension,string HospitalIncome)
		{
			try
			{
				return TATransCoverageDAO.AddTATransCoverage(JobNo,PersonalAccident,MedicalExpense,EmergencyMedical,Repatriation,PersonalLiability,TripCancellation,TravelDelay,FlightMisconnection,TripCurtailment,BaggageDelay,LossBaggage,LossPersonalMoney,LossTravelDocument,CompassionateVisitation,ReturnChildren,AutomaticExtension,HospitalIncome);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
		public int UpdateTATransCoverage(string JobNo,string PersonalAccident,string MedicalExpense,string EmergencyMedical,string Repatriation,string PersonalLiability,string TripCancellation,string TravelDelay,string FlightMisconnection,string TripCurtailment,string BaggageDelay,string LossBaggage,string LossPersonalMoney,string LossTravelDocument,string CompassionateVisitation,string ReturnChildren,string AutomaticExtension,string HospitalIncome)
		{
			try
			{
				return TATransCoverageDAO.UpdateTATransCoverage(JobNo,PersonalAccident,MedicalExpense,EmergencyMedical,Repatriation,PersonalLiability,TripCancellation,TravelDelay,FlightMisconnection,TripCurtailment,BaggageDelay,LossBaggage,LossPersonalMoney,LossTravelDocument,CompassionateVisitation,ReturnChildren,AutomaticExtension,HospitalIncome);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Delete, true)]
		public int RemoveTATransCoverage(string JobNo)
		{
			try
			{
				return TATransCoverageDAO.RemoveTATransCoverage(JobNo);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public List<TATransCoverage> DeserializeTATransCoverages(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<TATransCoverage>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public void SerializeTATransCoverages(string Path, List<TATransCoverage> TATransCoverages)
		{
			try
			{
				GenericXmlSerializer<List<TATransCoverage>>.Serialize(TATransCoverages, Path);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}



        public int SetTATransCoverage(string JobNo, string PersonalAccident, string MedicalExpense, string EmergencyMedical, string Repatriation, string PersonalLiability, string TripCancellation, string TravelDelay, string FlightMisconnection, string TripCurtailment, string BaggageDelay, string LossBaggage, string LossPersonalMoney, string LossTravelDocument, string CompassionateVisitation, string ReturnChildren, string AutomaticExtension, string HospitalIncome)
        {
            try
            {
                return TATransCoverageDAO.SetTATransCoverage(JobNo, PersonalAccident, MedicalExpense, EmergencyMedical, Repatriation, PersonalLiability, TripCancellation, TravelDelay, FlightMisconnection, TripCurtailment, BaggageDelay, LossBaggage, LossPersonalMoney, LossTravelDocument, CompassionateVisitation, ReturnChildren, AutomaticExtension, HospitalIncome);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public int SetTATransCoverage(string JobNo, string PersonalAccident, string MedicalExpense, string EmergencyMedical, string Repatriation, string PersonalLiability, string TripCancellation, string TravelDelay, string FlightMisconnection, string TripCurtailment, string BaggageDelay, string LossBaggage, string LossPersonalMoney, string LossTravelDocument, string CompassionateVisitation, string ReturnChildren, string AutomaticExtension, string HospitalIncome, DbTransaction dbTransaction)
        {
            try
            {
                return TATransCoverageDAO.SetTATransCoverage(JobNo, PersonalAccident, MedicalExpense, EmergencyMedical, Repatriation, PersonalLiability, TripCancellation, TravelDelay, FlightMisconnection, TripCurtailment, BaggageDelay, LossBaggage, LossPersonalMoney, LossTravelDocument, CompassionateVisitation, ReturnChildren, AutomaticExtension, HospitalIncome, dbTransaction);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public int SetTATransCoverage(string JobNo, float PersonalAccident, string PlanId)
        {
            try
            {
                return TATransCoverageDAO.SetTATransCoverage(JobNo, PersonalAccident, PlanId);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public int SetTATransCoverage(DbProviderHelper db,string JobNo, float PersonalAccident, string PlanId, DbTransaction dbTransaction)
        {
            try
            {
                return TATransCoverageDAO.SetTATransCoverage(db,JobNo, PersonalAccident, PlanId,  dbTransaction);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }


	}
}
