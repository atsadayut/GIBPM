using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;
using TA.DAL;

namespace TA.BLL
{
	public class TATBCountryBLL
	{
		private TATBCountryDAO _TATBCountryDAO;

		public TATBCountryDAO TATBCountryDAO
		{
			get { return _TATBCountryDAO; }
			set { _TATBCountryDAO = value; }
		}

		public TATBCountryBLL()
		{
			TATBCountryDAO = new TATBCountryDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<TATBCountry> GetTATBCountrys()
		{
			try
			{
				return TATBCountryDAO.GetTATBCountrys();
			}
			catch(Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public TATBCountry GetTATBCountry(string CountryCode)
		{
			try
			{
				return TATBCountryDAO.GetTATBCountry(CountryCode);
			}
			catch(Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int AddTATBCountry(string CountryCode,string CountryName,Nullable<SByte> isEnable,Nullable<DateTime> CreateDate)
		{
			try
			{
				return TATBCountryDAO.AddTATBCountry(CountryCode,CountryName,isEnable,CreateDate);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
		public int UpdateTATBCountry(string CountryCode,string CountryName,Nullable<SByte> isEnable,Nullable<DateTime> CreateDate)
		{
			try
			{
				return TATBCountryDAO.UpdateTATBCountry(CountryCode,CountryName,isEnable,CreateDate);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Delete, true)]
		public int RemoveTATBCountry(string CountryCode)
		{
			try
			{
				return TATBCountryDAO.RemoveTATBCountry(CountryCode);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public List<TATBCountry> DeserializeTATBCountrys(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<TATBCountry>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public void SerializeTATBCountrys(string Path, List<TATBCountry> TATBCountrys)
		{
			try
			{
				GenericXmlSerializer<List<TATBCountry>>.Serialize(TATBCountrys, Path);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}


        public int SetTATBCountry(string CountryCode, string CountryName, Nullable<SByte> isEnable, Nullable<DateTime> CreateDate)
        {
            try
            {
                return TATBCountryDAO.SetTATBCountry(CountryCode, CountryName, isEnable, CreateDate);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

       
        public DataTable GetDtTATBCountrys()
        {
            try
            {
                return TATBCountryDAO.GetDtTATBCountrys();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        //--------------------------------------SET -------------------------------------
        public int SetTATBCountry(string CountryCode, int isEnable)
        {
            try
            {
                return TATBCountryDAO.SetTATBCountry(CountryCode, isEnable);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        //---------------------------------GET --------------------------------
        public DataTable GetAllColumnTATBCountrys()
        {
            try
            {
                return TATBCountryDAO.GetAllColumnTATBCountrys();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
	}
}
