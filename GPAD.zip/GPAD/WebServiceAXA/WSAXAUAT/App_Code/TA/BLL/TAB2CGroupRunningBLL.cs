using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;
using TA.DAL;

namespace TA.BLL
{
	public class TAB2CGroupRunningBLL
	{
		private TAB2CGroupRunningDAO _TAB2CGroupRunningDAO;

		public TAB2CGroupRunningDAO TAB2CGroupRunningDAO
		{
			get { return _TAB2CGroupRunningDAO; }
			set { _TAB2CGroupRunningDAO = value; }
		}

		public TAB2CGroupRunningBLL()
		{
			TAB2CGroupRunningDAO = new TAB2CGroupRunningDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<TAB2CGroupRunning> GetTAB2CGroupRunnings()
		{
			try
			{
				return TAB2CGroupRunningDAO.GetTAB2CGroupRunnings();
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public TAB2CGroupRunning GetTAB2CGroupRunning(string PREFIX,int YEAR,int MONTH,int GROUPID)
		{
			try
			{
				return TAB2CGroupRunningDAO.GetTAB2CGroupRunning(PREFIX,YEAR,MONTH,GROUPID);
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int AddTAB2CGroupRunning(string PREFIX,int YEAR,int MONTH,int GROUPID,Nullable<DateTime> CreatedDate)
		{
			try
			{
				return TAB2CGroupRunningDAO.AddTAB2CGroupRunning(PREFIX,YEAR,MONTH,GROUPID,CreatedDate);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
		public int UpdateTAB2CGroupRunning(string PREFIX,int YEAR,int MONTH,int GROUPID,Nullable<DateTime> CreatedDate)
		{
			try
			{
				return TAB2CGroupRunningDAO.UpdateTAB2CGroupRunning(PREFIX,YEAR,MONTH,GROUPID,CreatedDate);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Delete, true)]
		public int RemoveTAB2CGroupRunning(string PREFIX,int YEAR,int MONTH,int GROUPID)
		{
			try
			{
				return TAB2CGroupRunningDAO.RemoveTAB2CGroupRunning(PREFIX,YEAR,MONTH,GROUPID);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public List<TAB2CGroupRunning> DeserializeTAB2CGroupRunnings(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<TAB2CGroupRunning>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public void SerializeTAB2CGroupRunnings(string Path, List<TAB2CGroupRunning> TAB2CGroupRunnings)
		{
			try
			{
				GenericXmlSerializer<List<TAB2CGroupRunning>>.Serialize(TAB2CGroupRunnings, Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}
