using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;
using TA.DAL;

namespace TA.BLL
{
	public class TAPlanPackageBLL
	{
		private TAPlanPackageDAO _TAPlanPackageDAO;

		public TAPlanPackageDAO TAPlanPackageDAO
		{
			get { return _TAPlanPackageDAO; }
			set { _TAPlanPackageDAO = value; }
		}

		public TAPlanPackageBLL()
		{
			TAPlanPackageDAO = new TAPlanPackageDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<TAPlanPackage> GetTAPlanPackages()
		{
			try
			{
				return TAPlanPackageDAO.GetTAPlanPackages();
			}
			catch(Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public TAPlanPackage GetTAPlanPackage(string PlanID,string PolicyType,string TravelPlan)
		{
			try
			{
				return TAPlanPackageDAO.GetTAPlanPackage(PlanID,PolicyType,TravelPlan);
			}
			catch(Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int AddTAPlanPackage(string PlanID,string PolicyType,string TravelPlan,string ContractType,string RiskType,string PremiumClass,string PlanCode,string TemplateCode,Nullable<SByte> isEnable,Nullable<DateTime> CreatDate,string CreateUser)
		{
			try
			{
				return TAPlanPackageDAO.AddTAPlanPackage(PlanID,PolicyType,TravelPlan,ContractType,RiskType,PremiumClass,PlanCode,TemplateCode,isEnable,CreatDate,CreateUser);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
		public int UpdateTAPlanPackage(string PlanID,string PolicyType,string TravelPlan,string ContractType,string RiskType,string PremiumClass,string PlanCode,string TemplateCode,Nullable<SByte> isEnable,Nullable<DateTime> CreatDate,string CreateUser)
		{
			try
			{
				return TAPlanPackageDAO.UpdateTAPlanPackage(PlanID,PolicyType,TravelPlan,ContractType,RiskType,PremiumClass,PlanCode,TemplateCode,isEnable,CreatDate,CreateUser);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Delete, true)]
		public int RemoveTAPlanPackage(string PlanID,string PolicyType,string TravelPlan)
		{
			try
			{
				return TAPlanPackageDAO.RemoveTAPlanPackage(PlanID,PolicyType,TravelPlan);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public List<TAPlanPackage> DeserializeTAPlanPackages(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<TAPlanPackage>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public void SerializeTAPlanPackages(string Path, List<TAPlanPackage> TAPlanPackages)
		{
			try
			{
				GenericXmlSerializer<List<TAPlanPackage>>.Serialize(TAPlanPackages, Path);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}

        /// <summary>
        /// Get TA Age
        /// </summary>
        /// <param name="PolicyType"></param>
        /// <param name="TravelPlan"></param>
        /// <param name="PlanID"></param>
        /// <returns></returns>
        public TAGetAge GetTAGetAge(string PolicyType, string TravelPlan, string PlanID)
		{
			try
			{
                return TAPlanPackageDAO.GetTAGetAge(PolicyType, TravelPlan, PlanID);
			}
			catch(Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
        

	}
}
