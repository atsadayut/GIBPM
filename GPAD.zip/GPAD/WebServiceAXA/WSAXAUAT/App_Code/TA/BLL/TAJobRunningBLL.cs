using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;
using TA.DAL;

namespace TA.BLL
{
	public class TAJobRunningBLL
	{
		private TAJobRunningDAO _TAJobRunningDAO;

		public TAJobRunningDAO TAJobRunningDAO
		{
			get { return _TAJobRunningDAO; }
			set { _TAJobRunningDAO = value; }
		}

		public TAJobRunningBLL()
		{
			TAJobRunningDAO = new TAJobRunningDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<TAJobRunning> GetTAJobRunnings()
		{
			try
			{
				return TAJobRunningDAO.GetTAJobRunnings();
			}
			catch(Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public TAJobRunning GetTAJobRunning(string PREFIX,int YEAR,int MONTH)
		{
			try
			{
				return TAJobRunningDAO.GetTAJobRunning(PREFIX,YEAR,MONTH);
			}
			catch(Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int AddTAJobRunning(string PREFIX,int YEAR,int MONTH,string RUNNING)
		{
			try
			{
				return TAJobRunningDAO.AddTAJobRunning(PREFIX,YEAR,MONTH,RUNNING);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
		public int UpdateTAJobRunning(string PREFIX,int YEAR,int MONTH,string RUNNING)
		{
			try
			{
				return TAJobRunningDAO.UpdateTAJobRunning(PREFIX,YEAR,MONTH,RUNNING);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Delete, true)]
		public int RemoveTAJobRunning(string PREFIX,int YEAR,int MONTH)
		{
			try
			{
				return TAJobRunningDAO.RemoveTAJobRunning(PREFIX,YEAR,MONTH);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public List<TAJobRunning> DeserializeTAJobRunnings(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<TAJobRunning>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public void SerializeTAJobRunnings(string Path, List<TAJobRunning> TAJobRunnings)
		{
			try
			{
				GenericXmlSerializer<List<TAJobRunning>>.Serialize(TAJobRunnings, Path);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}

        /// <summary>
        /// GET/SET JOB NUMBER
        /// </summary>
        /// <returns></returns>
        public string GetTAJobRunningNumber()
        {
            try
            {
                return TAJobRunningDAO.GetTAJobRunningNumber();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        public string GetTAJobRunningNumber(DbTransaction dbTransaction)
        {
            try
            {
                return TAJobRunningDAO.GetTAJobRunningNumber(dbTransaction);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

	}
}
