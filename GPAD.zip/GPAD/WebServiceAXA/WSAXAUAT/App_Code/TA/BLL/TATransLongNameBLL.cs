using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;
using TA.DAL;

namespace TA.BLL
{
	public class TATransLongNameBLL
	{
		private TATransLongNameDAO _TATransLongNameDAO;

		public TATransLongNameDAO TATransLongNameDAO
		{
			get { return _TATransLongNameDAO; }
			set { _TATransLongNameDAO = value; }
		}

		public TATransLongNameBLL()
		{
			TATransLongNameDAO = new TATransLongNameDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<TATransLongName> GetTATransLongNames()
		{
			try
			{
				return TATransLongNameDAO.GetTATransLongNames();
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public TATransLongName GetTATransLongName(string JobNo)
		{
			try
			{
				return TATransLongNameDAO.GetTATransLongName(JobNo);
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int AddTATransLongName(string JobNo,string LongName1,string LongName2,string LongName3,string LongName4)
		{
			try
			{
				return TATransLongNameDAO.AddTATransLongName(JobNo,LongName1,LongName2,LongName3,LongName4);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
		public int UpdateTATransLongName(string JobNo,string LongName1,string LongName2,string LongName3,string LongName4)
		{
			try
			{
				return TATransLongNameDAO.UpdateTATransLongName(JobNo,LongName1,LongName2,LongName3,LongName4);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Delete, true)]
		public int RemoveTATransLongName(string JobNo)
		{
			try
			{
				return TATransLongNameDAO.RemoveTATransLongName(JobNo);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public List<TATransLongName> DeserializeTATransLongNames(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<TATransLongName>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public void SerializeTATransLongNames(string Path, List<TATransLongName> TATransLongNames)
		{
			try
			{
				GenericXmlSerializer<List<TATransLongName>>.Serialize(TATransLongNames, Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}


        public int SetTATransLongName(string JobNo, string LongName1, string LongName2, string LongName3, string LongName4)
        {
            try
            {
                return TATransLongNameDAO.SetTATransLongName(JobNo, LongName1, LongName2, LongName3, LongName4);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int SetTATransLongName(string JobNo, string LongName1, string LongName2, string LongName3, string LongName4, DbTransaction dbTransaction)
        {
            try
            {
                return TATransLongNameDAO.SetTATransLongName(JobNo, LongName1, LongName2, LongName3, LongName4, dbTransaction);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public int SetTATransLongName(string JobNo, string LongName1, string LongName2, DbTransaction dbTransaction)
        {
            try
            {
                return TATransLongNameDAO.SetTATransLongName(JobNo, LongName1, LongName2, dbTransaction);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public DataTable GetDtTATransLongNames()
        {
            try
            {
                return TATransLongNameDAO.GetDtTATransLongNames();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
	}
}
