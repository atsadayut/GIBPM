using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;
using TA.DAL;

namespace TA.BLL
{
	public class TATransTravelerBLL
	{
		private TATransTravelerDAO _TATransTravelerDAO;

		public TATransTravelerDAO TATransTravelerDAO
		{
			get { return _TATransTravelerDAO; }
			set { _TATransTravelerDAO = value; }
		}

		public TATransTravelerBLL()
		{
			TATransTravelerDAO = new TATransTravelerDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<TATransTraveler> GetTATransTravelers()
		{
			try
			{
				return TATransTravelerDAO.GetTATransTravelers();
			}
			catch(Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public TATransTraveler GetTATransTraveler(string JobNo,int TravelerId)
		{
			try
			{
				return TATransTravelerDAO.GetTATransTraveler(JobNo,TravelerId);
			}
			catch(Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int AddTATransTraveler(string JobNo,int TravelerId,string ClientTitle,string ClientName,string ClientSurName,string Birthday,string PassportID,string Tel,Nullable<SByte> isStudent,Nullable<SByte> isSingle,Nullable<DateTime> CreateDate)
		{
			try
			{
				return TATransTravelerDAO.AddTATransTraveler(JobNo,TravelerId,ClientTitle,ClientName,ClientSurName,Birthday,PassportID,Tel,isStudent,isSingle,CreateDate);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
		public int UpdateTATransTraveler(string JobNo,int TravelerId,string ClientTitle,string ClientName,string ClientSurName,string Birthday,string PassportID,string Tel,Nullable<SByte> isStudent,Nullable<SByte> isSingle,Nullable<DateTime> CreateDate)
		{
			try
			{
				return TATransTravelerDAO.UpdateTATransTraveler(JobNo,TravelerId,ClientTitle,ClientName,ClientSurName,Birthday,PassportID,Tel,isStudent,isSingle,CreateDate);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Delete, true)]
		public int RemoveTATransTraveler(string JobNo,int TravelerId)
		{
			try
			{
				return TATransTravelerDAO.RemoveTATransTraveler(JobNo,TravelerId);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public List<TATransTraveler> DeserializeTATransTravelers(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<TATransTraveler>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public void SerializeTATransTravelers(string Path, List<TATransTraveler> TATransTravelers)
		{
			try
			{
				GenericXmlSerializer<List<TATransTraveler>>.Serialize(TATransTravelers, Path);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}



        public int SetTATransTraveler(string JobNo, int TravelerId, string ClientTitle, string ClientName, string ClientSurName, string Birthday, string PassportID, string Tel, Nullable<SByte> isStudent, Nullable<SByte> isSingle, Nullable<DateTime> CreateDate)
        {
            try
            {
                return TATransTravelerDAO.SetTATransTraveler(JobNo, TravelerId, ClientTitle, ClientName, ClientSurName, Birthday, PassportID, Tel, isStudent, isSingle, CreateDate);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public int SetTATransTraveler(string JobNo, int TravelerId, string ClientTitle, string ClientName, string ClientSurName, string Birthday, string PassportID, string Tel, Nullable<SByte> isStudent, Nullable<SByte> isSingle, Nullable<DateTime> CreateDate, DbTransaction dbTransaction)
        {
            try
            {
                return TATransTravelerDAO.SetTATransTraveler(JobNo, TravelerId, ClientTitle, ClientName, ClientSurName, Birthday, PassportID, Tel, isStudent, isSingle, CreateDate, dbTransaction);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public int SetTATransTraveler(DbProviderHelper db, string JobNo, int TravelerId, string ClientTitle, string ClientName, string ClientSurName, string Birthday, string PassportID, string Tel, Nullable<SByte> isStudent, Nullable<SByte> isSingle, Nullable<Decimal> SumInsurePA, Nullable<Decimal> NetPremium, Nullable<int> Stamp, Nullable<int> SBT, Nullable<Decimal> TotalPremium, Nullable<DateTime> CreateDate, DbTransaction dbTransaction)
        {
            try
            {
                return TATransTravelerDAO.SetTATransTraveler(db,JobNo, TravelerId, ClientTitle, ClientName, ClientSurName, Birthday, PassportID, Tel, isStudent, isSingle, SumInsurePA, NetPremium, Stamp, SBT, TotalPremium, CreateDate, dbTransaction);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public int SetTATransTraveler(string JobNo, int TravelerId, string ClientTitle, string ClientName, string ClientSurName, string Birthday, string PassportID, string Tel, Nullable<SByte> isStudent, Nullable<SByte> isSingle, Nullable<Decimal> SumInsurePA, Nullable<Decimal> NetPremium, Nullable<int> Stamp, Nullable<int> SBT, Nullable<Decimal> TotalPremium, Nullable<DateTime> CreateDate)
        {
            try
            {
                return TATransTravelerDAO.SetTATransTraveler(JobNo, TravelerId, ClientTitle, ClientName, ClientSurName, Birthday, PassportID, Tel, isStudent, isSingle, SumInsurePA, NetPremium, Stamp, SBT, TotalPremium, CreateDate);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
	    public DataTable GetDtTATransTraveler(string JobNo)
        {
            try
            {
                return TATransTravelerDAO.GetDtTATransTraveler(JobNo);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
    
    }
}
