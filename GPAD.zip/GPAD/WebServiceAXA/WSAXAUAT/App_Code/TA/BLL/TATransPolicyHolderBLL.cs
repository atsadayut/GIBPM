using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;
using TA.DAL;

namespace TA.BLL
{
	public class TATransPolicyHolderBLL
	{
		private TATransPolicyHolderDAO _TATransPolicyHolderDAO;

		public TATransPolicyHolderDAO TATransPolicyHolderDAO
		{
			get { return _TATransPolicyHolderDAO; }
			set { _TATransPolicyHolderDAO = value; }
		}

		public TATransPolicyHolderBLL()
		{
			TATransPolicyHolderDAO = new TATransPolicyHolderDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<TATransPolicyHolder> GetTATransPolicyHolders()
		{
			try
			{
				return TATransPolicyHolderDAO.GetTATransPolicyHolders();
			}
			catch(Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public TATransPolicyHolder GetTATransPolicyHolder(string JobNo)
		{
			try
			{
				return TATransPolicyHolderDAO.GetTATransPolicyHolder(JobNo);
			}
			catch(Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int AddTATransPolicyHolder(string JobNo,string ClientCode,string ClientType,string ClientTitle,string ClientName,string ClientSurName,string ClientAddress1,string ClientAddress2,string Province,string Amphur,string Tumbol,string PostCode,string CountryCode,string Birthday,string ClientSEX,string ClientStatus,string PassportID,string IDCard,string TaxID,string Tel,string Email,Nullable<DateTime> CreateDate)
		{
			try
			{
				return TATransPolicyHolderDAO.AddTATransPolicyHolder(JobNo,ClientCode,ClientType,ClientTitle,ClientName,ClientSurName,ClientAddress1,ClientAddress2,Province,Amphur,Tumbol,PostCode,CountryCode,Birthday,ClientSEX,ClientStatus,PassportID,IDCard,TaxID,Tel,Email,CreateDate);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
		public int UpdateTATransPolicyHolder(string JobNo,string ClientCode,string ClientType,string ClientTitle,string ClientName,string ClientSurName,string ClientAddress1,string ClientAddress2,string Province,string Amphur,string Tumbol,string PostCode,string CountryCode,string Birthday,string ClientSEX,string ClientStatus,string PassportID,string IDCard,string TaxID,string Tel,string Email,Nullable<DateTime> CreateDate)
		{
			try
			{
				return TATransPolicyHolderDAO.UpdateTATransPolicyHolder(JobNo,ClientCode,ClientType,ClientTitle,ClientName,ClientSurName,ClientAddress1,ClientAddress2,Province,Amphur,Tumbol,PostCode,CountryCode,Birthday,ClientSEX,ClientStatus,PassportID,IDCard,TaxID,Tel,Email,CreateDate);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Delete, true)]
		public int RemoveTATransPolicyHolder(string JobNo)
		{
			try
			{
				return TATransPolicyHolderDAO.RemoveTATransPolicyHolder(JobNo);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public List<TATransPolicyHolder> DeserializeTATransPolicyHolders(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<TATransPolicyHolder>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public void SerializeTATransPolicyHolders(string Path, List<TATransPolicyHolder> TATransPolicyHolders)
		{
			try
			{
				GenericXmlSerializer<List<TATransPolicyHolder>>.Serialize(TATransPolicyHolders, Path);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}


        public int SetTATransPolicyHolder(string JobNo, string ClientType, string ClientTitle, string ClientName, string ClientSurName, string ClientAddress1, string ClientAddress2, string Province, string Amphur, string Tumbol, string PostCode, string Birthday, string IDCard, string Tel, string Email, string Language)
        {
            try
            {
                return TATransPolicyHolderDAO.SetTATransPolicyHolder(JobNo, ClientType, ClientTitle, ClientName, ClientSurName, ClientAddress1, ClientAddress2, Province, Amphur, Tumbol, PostCode, Birthday, IDCard, Tel, Email, Language);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public int SetTATransPolicyHolder(string JobNo, string ClientType, string ClientTitle, string ClientName, string ClientSurName, string ClientAddress1, string ClientAddress2, string Province, string Amphur, string Tumbol, string PostCode, string Birthday, string IDCard, string Tel, string Email, string Language, DbTransaction dbTransaction)
        {
            try
            {
                return TATransPolicyHolderDAO.SetTATransPolicyHolder(JobNo, ClientType, ClientTitle, ClientName, ClientSurName, ClientAddress1, ClientAddress2, Province, Amphur, Tumbol, PostCode, Birthday, IDCard, Tel, Email,Language, dbTransaction);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        public int SetTATransPolicyHolder(DbProviderHelper db,string JobNo, string ClientType, string ClientTitle, string ClientName, string ClientSurName, string ClientAddress1, string ClientAddress2, string Province, string Amphur, string Tumbol, string PostCode, string Birthday, string IDCard, string Tel, string Email, string Language, string branchNo, DbTransaction dbTransaction)
        {
            try
            {
                return TATransPolicyHolderDAO.SetTATransPolicyHolder(db,JobNo, ClientType, ClientTitle, ClientName, ClientSurName, ClientAddress1, ClientAddress2, Province, Amphur, Tumbol, PostCode, Birthday, IDCard, Tel, Email, Language, branchNo, dbTransaction);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
	}
}
