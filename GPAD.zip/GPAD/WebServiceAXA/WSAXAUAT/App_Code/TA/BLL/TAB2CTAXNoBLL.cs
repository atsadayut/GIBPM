using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;
using TA.DAL;

namespace TA.BLL
{
	public class TAB2CTAXNoBLL
	{
		private TAB2CTAXNoDAO _TAB2CTAXNoDAO;

		public TAB2CTAXNoDAO TAB2CTAXNoDAO
		{
			get { return _TAB2CTAXNoDAO; }
			set { _TAB2CTAXNoDAO = value; }
		}

		public TAB2CTAXNoBLL()
		{
			TAB2CTAXNoDAO = new TAB2CTAXNoDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<TAB2CTAXNo> GetTAB2CTAXNos()
		{
			try
			{
				return TAB2CTAXNoDAO.GetTAB2CTAXNos();
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int AddTAB2CTAXNo(string PREFIX,int RUNNING)
		{
			try
			{
				return TAB2CTAXNoDAO.AddTAB2CTAXNo(PREFIX,RUNNING);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public List<TAB2CTAXNo> DeserializeTAB2CTAXNos(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<TAB2CTAXNo>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public void SerializeTAB2CTAXNos(string Path, List<TAB2CTAXNo> TAB2CTAXNos)
		{
			try
			{
				GenericXmlSerializer<List<TAB2CTAXNo>>.Serialize(TAB2CTAXNos, Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}
