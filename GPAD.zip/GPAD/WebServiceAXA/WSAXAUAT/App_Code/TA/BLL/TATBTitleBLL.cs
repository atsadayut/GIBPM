using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;
using TA.DAL;

namespace TA.BLL
{
	public class TATBTitleBLL
	{
		private TATBTitleDAO _TATBTitleDAO;

		public TATBTitleDAO TATBTitleDAO
		{
			get { return _TATBTitleDAO; }
			set { _TATBTitleDAO = value; }
		}

		public TATBTitleBLL()
		{
			TATBTitleDAO = new TATBTitleDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<TATBTitle> GetTATBTitles()
		{
			try
			{
				return TATBTitleDAO.GetTATBTitles();
			}
			catch(Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int AddTATBTitle(string TitleName,string SEX,Nullable<SByte> isEnable,Nullable<DateTime> CreateDate)
		{
			try
			{
				return TATBTitleDAO.AddTATBTitle(TitleName,SEX,isEnable,CreateDate);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public List<TATBTitle> DeserializeTATBTitles(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<TATBTitle>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public void SerializeTATBTitles(string Path, List<TATBTitle> TATBTitles)
		{
			try
			{
				GenericXmlSerializer<List<TATBTitle>>.Serialize(TATBTitles, Path);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}

        public int SetTATBTitle(string TitleName, string SEX, Nullable<SByte> isEnable, Nullable<DateTime> CreateDate)
        {
            try
            {
                return TATBTitleDAO.SetTATBTitle(TitleName, SEX, isEnable, CreateDate);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public DataTable GetDtTATBCountrys()
        {
            try
            {
                return TATBTitleDAO.GetDtTATBTitles();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        public DataTable GetDtTATBCountrysThai()
        {
            try
            {
                return TATBTitleDAO.GetDtTATBTitlesThai();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
	}
}
