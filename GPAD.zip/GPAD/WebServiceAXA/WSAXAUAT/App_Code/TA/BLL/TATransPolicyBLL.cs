using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;
using TA.DAL;

namespace TA.BLL
{
	public class TATransPolicyBLL
	{
		private TATransPolicyDAO _TATransPolicyDAO;

		public TATransPolicyDAO TATransPolicyDAO
		{
			get { return _TATransPolicyDAO; }
			set { _TATransPolicyDAO = value; }
		}

		public TATransPolicyBLL()
		{
			TATransPolicyDAO = new TATransPolicyDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<TATransPolicy> GetTATransPolicys()
		{
			try
			{
				return TATransPolicyDAO.GetTATransPolicys();
			}
			catch(Exception ex)
			{
               
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public TATransPolicy GetTATransPolicy(string JobNo)
		{
			try
			{
				return TATransPolicyDAO.GetTATransPolicy(JobNo);
			}
			catch(Exception ex)
			{
               
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int AddTATransPolicy(string JobNo,string PolicyNo,string TravelPlan,string PolicyType,Nullable<int> NumbersOfChildren,string InsurancePlan,string EffectiveDateFrom,string EffectiveDateTo,string CountryOfDestination,string PlanCode,string ContractType,string AgentCode,string StaffCode,string BranchCode,string TemplateCode,string OccupatnCode,Nullable<Decimal> NetPremium,Nullable<int> Stamp,Nullable<Decimal> SBT,Nullable<Decimal> TotalPremium,Nullable<SByte> isLongName,Nullable<SByte> isBeneficiary,Nullable<DateTime> CreateDate,string CreateUser,string GroupBrokerId)
		{
			try
			{
				return TATransPolicyDAO.AddTATransPolicy(JobNo,PolicyNo,TravelPlan,PolicyType,NumbersOfChildren,InsurancePlan,EffectiveDateFrom,EffectiveDateTo,CountryOfDestination,PlanCode,ContractType,AgentCode,StaffCode,BranchCode,TemplateCode,OccupatnCode,NetPremium,Stamp,SBT,TotalPremium,isLongName,isBeneficiary,CreateDate,CreateUser,GroupBrokerId);
			}
			catch (Exception ex)
			{
               
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
		public int UpdateTATransPolicy(string JobNo,string PolicyNo,string TravelPlan,string PolicyType,Nullable<int> NumbersOfChildren,string InsurancePlan,string EffectiveDateFrom,string EffectiveDateTo,string CountryOfDestination,string PlanCode,string ContractType,string AgentCode,string StaffCode,string BranchCode,string TemplateCode,string OccupatnCode,Nullable<Decimal> NetPremium,Nullable<int> Stamp,Nullable<Decimal> SBT,Nullable<Decimal> TotalPremium,Nullable<SByte> isLongName,Nullable<SByte> isBeneficiary,Nullable<DateTime> CreateDate,string CreateUser,string GroupBrokerId)
		{
			try
			{
				return TATransPolicyDAO.UpdateTATransPolicy(JobNo,PolicyNo,TravelPlan,PolicyType,NumbersOfChildren,InsurancePlan,EffectiveDateFrom,EffectiveDateTo,CountryOfDestination,PlanCode,ContractType,AgentCode,StaffCode,BranchCode,TemplateCode,OccupatnCode,NetPremium,Stamp,SBT,TotalPremium,isLongName,isBeneficiary,CreateDate,CreateUser,GroupBrokerId);
			}
			catch (Exception ex)
			{
               
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Delete, true)]
		public int RemoveTATransPolicy(string JobNo)
		{
			try
			{
				return TATransPolicyDAO.RemoveTATransPolicy(JobNo);
			}
			catch (Exception ex)
			{
               
				throw ex;
			}
		}
		public List<TATransPolicy> DeserializeTATransPolicys(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<TATransPolicy>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
               
				throw ex;
			}
		}
		public void SerializeTATransPolicys(string Path, List<TATransPolicy> TATransPolicys)
		{
			try
			{
				GenericXmlSerializer<List<TATransPolicy>>.Serialize(TATransPolicys, Path);
			}
			catch (Exception ex)
			{
               
				throw ex;
			}
		}



        public TAGetBindPackagePolicy GetTATransPolicy(string JobNo, string GroupBrokerId)
		{
			try
			{
                return TATransPolicyDAO.GetTATransPolicy(JobNo, GroupBrokerId);
			}
			catch(Exception ex)
			{
               
				throw ex;
			}
		}
        public int SetTATransPolicy(string JobNo, string PolicyNo, string TravelPlan, string PolicyType, Nullable<int> NumbersOfChildren, string InsurancePlan, string EffectiveDateFrom, string EffectiveDateTo, string CountryOfDestination, string CountryOther, string AgentCode, string OccupatnCode, Nullable<Decimal> NetPremium, Nullable<int> Stamp, Nullable<Decimal> SBT, Nullable<Decimal> TotalPremium, Nullable<SByte> isLongName, Nullable<SByte> isBeneficiary, string CreateUser, string GroupBrokerId)
        {
            try
            {
                return TATransPolicyDAO.SetTATransPolicy(JobNo, PolicyNo, TravelPlan, PolicyType, NumbersOfChildren, InsurancePlan, EffectiveDateFrom, EffectiveDateTo, CountryOfDestination, CountryOther, AgentCode, OccupatnCode, NetPremium, Stamp, SBT, TotalPremium, isLongName, isBeneficiary, CreateUser, GroupBrokerId);
            }
            catch (Exception ex)
            {
               
                throw ex;
            }
        }
        public int SetTATransPolicy(DbProviderHelper db,string JobNo, string PolicyNo, string TravelPlan, string PolicyType, Nullable<int> NumbersOfChildren, string InsurancePlan, string EffectiveDateFrom, string EffectiveDateTo, string CountryOfDestination, string CountryOther, string AgentCode, string OccupatnCode, Nullable<Decimal> NetPremium, Nullable<int> Stamp, Nullable<Decimal> SBT, Nullable<Decimal> TotalPremium, Nullable<SByte> isLongName, Nullable<SByte> isBeneficiary, string CreateUser, string GroupBrokerId, DbTransaction dbTransaction)
        {
            try
            {
                return TATransPolicyDAO.SetTATransPolicy(db,JobNo, PolicyNo, TravelPlan, PolicyType, NumbersOfChildren, InsurancePlan, EffectiveDateFrom, EffectiveDateTo, CountryOfDestination, CountryOther, AgentCode, OccupatnCode, NetPremium, Stamp, SBT, TotalPremium, isLongName, isBeneficiary, CreateUser, GroupBrokerId, dbTransaction);
            }
            catch (Exception ex)
            {
               
                throw ex;
            }
        }
        public int SetTATransCancelPolicy(string JobNo, string PolicyNo, string UserID, string GroupBrokerID)
        {
            try
            {
                return TATransPolicyDAO.SetTATransCancelPolicy(JobNo, PolicyNo, UserID, GroupBrokerID);
            }
            catch (Exception ex)
            {
               
                throw ex;
            }
        }    
        public DataTable GetDtTAGetListTAPolicy(string PolicyNo, string JobNo, string InsureName, string TravelerName, string PassportID, string TransDateFrom, string TransDateTo, string GroupBrokerId)
        {
            try
            {
                return TATransPolicyDAO.GetDtTAGetListTAPolicy(PolicyNo, JobNo, InsureName, TravelerName, PassportID, TransDateFrom, TransDateTo, GroupBrokerId);
            }
            catch (Exception ex)
            {
               
                throw ex;
            }
        }
        public DataTable GetDtTAGetListTAPolicyForCancel(string PolicyNo, string JobNo, string InsureName, string TravelerName, string PassportID, string TransDateFrom, string TransDateTo, string GroupBrokerId)
        {
            try
            {
                return TATransPolicyDAO.GetDtTAGetListTAPolicyForCancel(PolicyNo, JobNo, InsureName, TravelerName, PassportID, TransDateFrom, TransDateTo, GroupBrokerId);
            }
            catch (Exception ex)
            {
               
                throw ex;
            }
        }

        public int SetTATransTaxInvoince(string PolicyNo, string JobNo, string UserID, string FlagID)
        {
            try
            {
                return TATransPolicyDAO.SetTATransTaxInvoince(PolicyNo, JobNo, UserID, FlagID);
            }
            catch (Exception ex)
            {
               
                throw ex;
            }
        }
        public int SetTATransTaxInvoince(string PolicyNo, string JobNo, string UserID, string FlagID, DbTransaction dbTransaction)
        {
            try
            {
                return TATransPolicyDAO.SetTATransTaxInvoince(PolicyNo, JobNo, UserID, FlagID, dbTransaction);
            }
            catch (Exception ex)
            {
               
                throw ex;
            }
        }
        
        public int SetTATransPrint(string PolicyNo, string JobNo, string EndtNo, string AgentCode, string GroupBrokerId, string CreatedUser)
        {
            try
            {
                return TATransPolicyDAO.SetTATransPrint( PolicyNo,  JobNo,  EndtNo,  AgentCode, GroupBrokerId, CreatedUser);
            }
            catch (Exception ex)
            {
               
                throw ex;
            }
        }
        public int SetTATransPrint(string PolicyNo, string JobNo, string EndtNo, string AgentCode, string GroupBrokerId, string CreatedUser, DbTransaction dbTransaction)
        {
            try
            {
                return TATransPolicyDAO.SetTATransPrint(PolicyNo, JobNo, EndtNo, AgentCode, GroupBrokerId, CreatedUser, dbTransaction);
            }
            catch (Exception ex)
            {
               
                throw ex;
            }
        }

        public DataTable GetTAListPrintPolicy(string PolicyFrom, string PolicyTo, string IssuedDateFrom, string IssuedDateTo,string EndtNo, string GroupBrokerID)
        {
            try
            {
                return TATransPolicyDAO.GetTAListPrintPolicy(PolicyFrom, PolicyTo, IssuedDateFrom, IssuedDateTo, EndtNo, GroupBrokerID);
            }
            catch (Exception ex)
            {
               
                throw ex;
            }
        }
        public DataTable GetTAPrintListReportName(string PolicyNo, string EndtNo)
        {
            try
            {
                return TATransPolicyDAO.GetTAPrintListReportName( PolicyNo,  EndtNo);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public int SetTAPrintFlagOriginal(string PolicyNo, string EndtNo, int FlagOriginal)
        {
            try
            {
                return TATransPolicyDAO.SetTAPrintFlagOriginal( PolicyNo,  EndtNo, FlagOriginal);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int SetTAPrintFlagCopy(string PolicyNo, string EndtNo, int FlagCopy)
        {
            try
            {
                return TATransPolicyDAO.SetTAPrintFlagCopy( PolicyNo,  EndtNo, FlagCopy);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetTAGetReport(string TransDateFrom, string TransDateTo, string EffectiveDateFrom, string EffectiveDateTo, string AgentCode, string GroupBrokerID)
        {
            try
            {
                return TATransPolicyDAO.GetTAGetReport( TransDateFrom,  TransDateTo,  EffectiveDateFrom,  EffectiveDateTo,  AgentCode,  GroupBrokerID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetTAGetReport(string PolicyNo)
        {
            try
            {
                return TATransPolicyDAO.GetTAGetReport(PolicyNo);
            }
            catch (Exception ex)
            {
                 throw ex;
            }
        }

        public int SetTAPrintAllFlag(string PolicyNo, string EndtNo, int FlagOriginal, int FlagCopy)
        {
            try
            {
                return TATransPolicyDAO.SetTAPrintAllFlag(PolicyNo, EndtNo, FlagOriginal, FlagCopy);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int spTAB2C_SetTransTaxInvoince(string PolicyNo, string JobNo, string UserID)
        {
            try
            {
                return TATransPolicyDAO.spTAB2C_SetTransTaxInvoince( PolicyNo,  JobNo,  UserID);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public int spTAB2C_SetTransPayment(string HOSTRESP, string RESERVED1, string AUTHCODE, string RETURNINV, string SERVED2, string CARDNUMBER, string AMOUNT, string THBAMOUNT, string CURISO, string FXRATE, string FILLSPACE)
        {
            try
            {
                return TATransPolicyDAO.spTAB2C_SetTransPayment( HOSTRESP,  RESERVED1,  AUTHCODE,  RETURNINV,  SERVED2,  CARDNUMBER,  AMOUNT,  THBAMOUNT,  CURISO,  FXRATE,  FILLSPACE);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public DataTable GetTATransPolicyByPassportIDAndReturn(string PassportID, string RefCode)
        {
            try
            {
                return TATransPolicyDAO.GetTATransPolicyByPassportIDAndReturn(PassportID, RefCode);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
