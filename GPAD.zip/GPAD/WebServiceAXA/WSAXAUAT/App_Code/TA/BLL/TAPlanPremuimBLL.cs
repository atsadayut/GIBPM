using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;
using TA.DAL;

namespace TA.BLL
{
	public class TAPlanPremuimBLL
	{
		private TAPlanPremuimDAO _TAPlanPremuimDAO;

		public TAPlanPremuimDAO TAPlanPremuimDAO
		{
			get { return _TAPlanPremuimDAO; }
			set { _TAPlanPremuimDAO = value; }
		}

		public TAPlanPremuimBLL()
		{
			TAPlanPremuimDAO = new TAPlanPremuimDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<TAPlanPremuim> GetTAPlanPremuims()
		{
			try
			{
				return TAPlanPremuimDAO.GetTAPlanPremuims();
			}
			catch(Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public TAPlanPremuim GetTAPlanPremuim(string PlanID,string PolicyType,string TravelPlan,int DurationFrom,int DurationTo)
		{
			try
			{
				return TAPlanPremuimDAO.GetTAPlanPremuim(PlanID,PolicyType,TravelPlan,DurationFrom,DurationTo);
			}
			catch(Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int AddTAPlanPremuim(string PlanID,string PolicyType,string TravelPlan,int DurationFrom,int DurationTo,Nullable<Double> NetPremium,Nullable<SByte> isEnabel,Nullable<DateTime> CreatedDate,string CreatedUser)
		{
			try
			{
				return TAPlanPremuimDAO.AddTAPlanPremuim(PlanID,PolicyType,TravelPlan,DurationFrom,DurationTo,NetPremium,isEnabel,CreatedDate,CreatedUser);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
		public int UpdateTAPlanPremuim(string PlanID,string PolicyType,string TravelPlan,int DurationFrom,int DurationTo,Nullable<Double> NetPremium,Nullable<SByte> isEnabel,Nullable<DateTime> CreatedDate,string CreatedUser)
		{
			try
			{
				return TAPlanPremuimDAO.UpdateTAPlanPremuim(PlanID,PolicyType,TravelPlan,DurationFrom,DurationTo,NetPremium,isEnabel,CreatedDate,CreatedUser);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Delete, true)]
		public int RemoveTAPlanPremuim(string PlanID,string PolicyType,string TravelPlan,int DurationFrom,int DurationTo)
		{
			try
			{
				return TAPlanPremuimDAO.RemoveTAPlanPremuim(PlanID,PolicyType,TravelPlan,DurationFrom,DurationTo);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public List<TAPlanPremuim> DeserializeTAPlanPremuims(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<TAPlanPremuim>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public void SerializeTAPlanPremuims(string Path, List<TAPlanPremuim> TAPlanPremuims)
		{
			try
			{
				GenericXmlSerializer<List<TAPlanPremuim>>.Serialize(TAPlanPremuims, Path);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}


        public int SetTAPlanPremuim(string PlanID, string PolicyType, string TravelPlan, int DurationFrom, int DurationTo, Nullable<Double> NetPremium, Nullable<SByte> isEnabel, Nullable<DateTime> CreatedDate, string CreatedUser)
        {
            try
            {
                return TAPlanPremuimDAO.SetTAPlanPremuim(PlanID, PolicyType, TravelPlan, DurationFrom, DurationTo, NetPremium, isEnabel, CreatedDate, CreatedUser);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public DataTable GetDtTATBPlanIDs(string PlanID, int Duration, string TravelPlan)
        {
            try
            {
                return TAPlanPremuimDAO.GetDtTAPlanPremuims(PlanID, Duration, TravelPlan);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public TAPremuim GetTAPremuim(string PlanID, int Duration, string TravelPlan)
        {
            try
            {
                return TAPlanPremuimDAO.GetTAPremuim(PlanID, Duration, TravelPlan);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        
        //------------------------------------------------------------------------------------------
        public DataTable GetAllTAPlanPremuim(string PlanID, string TravelPlan)
        {
            try
            {
                return TAPlanPremuimDAO.GetAllTAPlanPremuim(PlanID, TravelPlan);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public int SetTAPlanPremuim(string PlanID, string PolicyType, string TravelPlan, int DurationFrom, int DurationTo, Nullable<Double> NetPremium, Nullable<SByte> isEnabel, string CreatedUser)
        {
            try
            {
                return TAPlanPremuimDAO.SetTAPlanPremuim(PlanID, PolicyType, TravelPlan, DurationFrom, DurationTo, NetPremium, isEnabel, CreatedUser);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        
	}
}
