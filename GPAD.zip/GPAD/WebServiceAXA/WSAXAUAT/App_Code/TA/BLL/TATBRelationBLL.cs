using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;
using TA.DAL;

namespace TA.BLL
{
	public class TATBRelationBLL
	{
		private TATBRelationDAO _TATBRelationDAO;

		public TATBRelationDAO TATBRelationDAO
		{
			get { return _TATBRelationDAO; }
			set { _TATBRelationDAO = value; }
		}

		public TATBRelationBLL()
		{
			TATBRelationDAO = new TATBRelationDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<TATBRelation> GetTATBRelations()
		{
			try
			{
				return TATBRelationDAO.GetTATBRelations();
			}
			catch(Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public TATBRelation GetTATBRelation(int ID)
		{
			try
			{
				return TATBRelationDAO.GetTATBRelation(ID);
			}
			catch(Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int AddTATBRelation(int ID,string Relation,Nullable<SByte> isEnable,Nullable<DateTime> CreateDate)
		{
			try
			{
				return TATBRelationDAO.AddTATBRelation(ID,Relation,isEnable,CreateDate);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
		public int UpdateTATBRelation(int ID,string Relation,Nullable<SByte> isEnable,Nullable<DateTime> CreateDate)
		{
			try
			{
				return TATBRelationDAO.UpdateTATBRelation(ID,Relation,isEnable,CreateDate);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Delete, true)]
		public int RemoveTATBRelation(int ID)
		{
			try
			{
				return TATBRelationDAO.RemoveTATBRelation(ID);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public List<TATBRelation> DeserializeTATBRelations(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<TATBRelation>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public void SerializeTATBRelations(string Path, List<TATBRelation> TATBRelations)
		{
			try
			{
				GenericXmlSerializer<List<TATBRelation>>.Serialize(TATBRelations, Path);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}


        public int SetTATBRelation(int ID, string Relation, Nullable<SByte> isEnable, Nullable<DateTime> CreateDate)
        {
            try
            {
                return TATBRelationDAO.SetTATBRelation(ID, Relation, isEnable, CreateDate);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public DataTable GetDtTATBRelations(string lang)
        {
            try
            {
                return TATBRelationDAO.GetDtTATBRelations(lang);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
	}
}
