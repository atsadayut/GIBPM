using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;
using TA.DAL;

namespace TA.BLL
{
	public class TAB2CRegistrationBLL
	{
		private TAB2CRegistrationDAO _TAB2CRegistrationDAO;

		public TAB2CRegistrationDAO TAB2CRegistrationDAO
		{
			get { return _TAB2CRegistrationDAO; }
			set { _TAB2CRegistrationDAO = value; }
		}

		public TAB2CRegistrationBLL()
		{
			TAB2CRegistrationDAO = new TAB2CRegistrationDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<TAB2CRegistration> GetTAB2CRegistrations()
		{
			try
			{
				return TAB2CRegistrationDAO.GetTAB2CRegistrations();
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public TAB2CRegistration GetTAB2CRegistration(string Login)
		{
			try
			{
				return TAB2CRegistrationDAO.GetTAB2CRegistration(Login);
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int AddTAB2CRegistration(string Login,string Password,string ClientCode,string ClientType,string ClientTitle,string ClientName,string ClientSurName,string ClientAddress1,string ClientAddress2,string Province,string Amphur,string Tumbol,string PostCode,string CountryCode,Nullable<DateTime> Birthday,string ClientSEX,string ClientStatus,string PassportID,string IDCard,string TaxID,string Tel,string Email,string Language,Nullable<DateTime> CreateDate,string AgentCode,string StaffCode,string GroupBrokerId,string Message,Nullable<DateTime> ModifiedDate)
		{
			try
			{
				return TAB2CRegistrationDAO.AddTAB2CRegistration(Login,Password,ClientCode,ClientType,ClientTitle,ClientName,ClientSurName,ClientAddress1,ClientAddress2,Province,Amphur,Tumbol,PostCode,CountryCode,Birthday,ClientSEX,ClientStatus,PassportID,IDCard,TaxID,Tel,Email,Language,CreateDate,AgentCode,StaffCode,GroupBrokerId,Message,ModifiedDate);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
        public int SetTAB2CRegistration(string Login, string Password, string ClientType, string ClientTitle, string ClientName, string ClientSurName, string ClientAddress1, string ClientAddress2, string Province, string Amphur, string Tumbol, string PostCode, string CountryCode, string Birthday, string ClientSEX, string ClientStatus, string PassportID, string IDCard, string TaxID, string Tel, string Email, string Language)
        {
            try
            {
                return TAB2CRegistrationDAO.SetTAB2CRegistration(Login, Password, ClientType, ClientTitle, ClientName, ClientSurName, ClientAddress1, ClientAddress2, Province, Amphur, Tumbol, PostCode, CountryCode, Birthday, ClientSEX, ClientStatus, PassportID, IDCard, TaxID, Tel, Email, Language);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
		public int UpdateTAB2CRegistration(string Login,string Password,string ClientCode,string ClientType,string ClientTitle,string ClientName,string ClientSurName,string ClientAddress1,string ClientAddress2,string Province,string Amphur,string Tumbol,string PostCode,string CountryCode,Nullable<DateTime> Birthday,string ClientSEX,string ClientStatus,string PassportID,string IDCard,string TaxID,string Tel,string Email,string Language,Nullable<DateTime> CreateDate,string AgentCode,string StaffCode,string GroupBrokerId,string Message,Nullable<DateTime> ModifiedDate)
		{
			try
			{
				return TAB2CRegistrationDAO.UpdateTAB2CRegistration(Login,Password,ClientCode,ClientType,ClientTitle,ClientName,ClientSurName,ClientAddress1,ClientAddress2,Province,Amphur,Tumbol,PostCode,CountryCode,Birthday,ClientSEX,ClientStatus,PassportID,IDCard,TaxID,Tel,Email,Language,CreateDate,AgentCode,StaffCode,GroupBrokerId,Message,ModifiedDate);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
        public int SetTAB2CRegistration(string Login, string Password)
        {
            try
            {
                return TAB2CRegistrationDAO.SetTAB2CRegistration(Login, Password);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Delete, true)]
		public int RemoveTAB2CRegistration(string Login)
		{
			try
			{
				return TAB2CRegistrationDAO.RemoveTAB2CRegistration(Login);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public List<TAB2CRegistration> DeserializeTAB2CRegistrations(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<TAB2CRegistration>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public void SerializeTAB2CRegistrations(string Path, List<TAB2CRegistration> TAB2CRegistrations)
		{
			try
			{
				GenericXmlSerializer<List<TAB2CRegistration>>.Serialize(TAB2CRegistrations, Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}
