using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;
using TA.DAL;

namespace TA.BLL
{
	public class TAB2CDiscountBLL
	{
		private TAB2CDiscountDAO _TAB2CDiscountDAO;

		public TAB2CDiscountDAO TAB2CDiscountDAO
		{
			get { return _TAB2CDiscountDAO; }
			set { _TAB2CDiscountDAO = value; }
		}

		public TAB2CDiscountBLL()
		{
			TAB2CDiscountDAO = new TAB2CDiscountDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<TAB2CDiscount> GetTAB2CDiscounts()
		{
			try
			{
				return TAB2CDiscountDAO.GetTAB2CDiscounts();
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public TAB2CDiscount GetTAB2CDiscount(int ID)
		{
			try
			{
				return TAB2CDiscountDAO.GetTAB2CDiscount(ID);
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
        public TAB2CDiscount GetTAB2CDiscount(string CodeDiscount, string UserID)
        {
            try
            {
                return TAB2CDiscountDAO.GetTAB2CDiscount(CodeDiscount, UserID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int AddTAB2CDiscount(string CodeDiscount,Nullable<int> Checksum,Nullable<int> DiscountPresent,Nullable<int> DiscountAmount,string ForUserWebID,string BrokerCode,string GroupBrokerId,string GeneratedUse,Nullable<DateTime> GeneratedDate,string JobNo,string UsedUserID,Nullable<DateTime> UsedDate,Nullable<SByte> UsedFlag)
		{
			try
			{
				return TAB2CDiscountDAO.AddTAB2CDiscount(CodeDiscount,Checksum,DiscountPresent,DiscountAmount,ForUserWebID,BrokerCode,GroupBrokerId,GeneratedUse,GeneratedDate,JobNo,UsedUserID,UsedDate,UsedFlag);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
		public int UpdateTAB2CDiscount(int ID,string CodeDiscount,Nullable<int> Checksum,Nullable<int> DiscountPresent,Nullable<int> DiscountAmount,string ForUserWebID,string BrokerCode,string GroupBrokerId,string GeneratedUse,Nullable<DateTime> GeneratedDate,string JobNo,string UsedUserID,Nullable<DateTime> UsedDate,Nullable<SByte> UsedFlag)
		{
			try
			{
				return TAB2CDiscountDAO.UpdateTAB2CDiscount(ID,CodeDiscount,Checksum,DiscountPresent,DiscountAmount,ForUserWebID,BrokerCode,GroupBrokerId,GeneratedUse,GeneratedDate,JobNo,UsedUserID,UsedDate,UsedFlag);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
        public int spTAB2C_SetUseDiscount(string JobNo, string CodeDiscount, string UserID)
        {
            try
            {
                return TAB2CDiscountDAO.spTAB2C_SetUseDiscount(JobNo, CodeDiscount, UserID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int spTAB2C_SetUseDiscount(string JobNo, string CodeDiscount, string UserID, DbTransaction dbTransaction)
        {
            try
            {
                return TAB2CDiscountDAO.spTAB2C_SetUseDiscount(JobNo, CodeDiscount, UserID, dbTransaction);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Delete, true)]
		public int RemoveTAB2CDiscount(int ID)
		{
			try
			{
				return TAB2CDiscountDAO.RemoveTAB2CDiscount(ID);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public List<TAB2CDiscount> DeserializeTAB2CDiscounts(string Path)
		{
			try
			{
				return GenericXmlSerializer<List<TAB2CDiscount>>.Deserialize(Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public void SerializeTAB2CDiscounts(string Path, List<TAB2CDiscount> TAB2CDiscounts)
		{
			try
			{
				GenericXmlSerializer<List<TAB2CDiscount>>.Serialize(TAB2CDiscounts, Path);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}
