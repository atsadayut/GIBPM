﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Globalization;
using System.Configuration;

using System.Diagnostics;
using System.Globalization;
using System.Web.UI;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for TAUtilities
/// </summary>

namespace TA
{
    public class TAUtilities
    {
        public enum DateInterval
        {
            Day,
            DayOfYear,
            Hour,
            Minute,
            Month,
            Quarter,
            Second,
            Weekday,
            WeekOfYear,
            Year
        }

        public enum PolicyType
        {
            Individual,
            Family,
        } 

        public enum TravelPlan
        {
            Single,
            Annaul,
        }
                 
        public TAUtilities()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        //Convert format date to DB (fix format datevalue = dd/MM/yyyy to yyyy-MM-dd)
        public static string ConvertDateFieldToDB(string datevalue)
        {
            try
            {
                string culture = CultureInfo.CurrentCulture.Name.ToString();
                string[] arrDate = datevalue.Split('/');
                string dateFormatToDB = "";
                if (Int32.Parse(arrDate[2].Substring(0, 4)) > 2500)
                {
                    dateFormatToDB = (Int32.Parse(arrDate[2].Substring(0, 4)) - 543).ToString() + "-" + arrDate[1] + "-" + arrDate[0];
                }
                else
                {
                    dateFormatToDB = arrDate[2].Substring(0, 4) + "-" + arrDate[1] + "-" + arrDate[0];
                }
                return dateFormatToDB;
            }
            catch (Exception e)
            {
                Utilities.LogError(e);
                throw (new Exception("Unable to convert datetime value to db: " + e.Message));
            }
        }

        //Convert format date to DB (fix format datevalue = dd/MM/yyyy HH:mm:ss to yyyy-MM-dd HH:mm:ss )
        public static string ConvertDateTimeFieldToDB(string datevalue)
        {
            try
            {
                string culture = CultureInfo.CurrentCulture.Name.ToString();

                string[] arrDate = datevalue.Split('/');
                string dateFormatToDB = "";
                string time = arrDate[2].Replace(arrDate[2].Substring(0, 4), string.Empty);
                if (Int32.Parse(arrDate[2].Substring(0, 4)) > 2500)
                {
                    if (culture == "th-TH")
                    {
                        dateFormatToDB = (Int32.Parse(arrDate[2].Substring(0, 4)) - 543).ToString() + "-" + arrDate[1] + "-" + arrDate[0] + " " + time;
                    }

                    if (culture == "en-US")
                    {
                        dateFormatToDB = (Int32.Parse(arrDate[2].Substring(0, 4)) - 543).ToString() + "-" + arrDate[0] + "-" + arrDate[1] + " " + time;
                    }
                }
                else
                {
                    if (culture == "th-TH")
                    {
                        dateFormatToDB = arrDate[2].Substring(0, 4) + "-" + arrDate[1] + "-" + arrDate[0] + " " + time;
                    }

                    if (culture == "en-US")
                    {
                        dateFormatToDB = arrDate[2].Substring(0, 4) + "-" + arrDate[0] + "-" + arrDate[1] + " " + time;
                    }
                }
                return dateFormatToDB;

            }
            catch (Exception e)
            {
                Utilities.LogError(e);
                throw (new Exception("Unable to convert datetime value to db: " + e.Message));
            }
        }

        //Convert DateTime 31/03/2554 00:59:59 to string 31/03/2011
        public static string ConvertDateTimeToEnShowDateString(DateTime date)
        {
            try
            {
                string datevalue = date.ToString("dd/MM/yyyy HH:mm:ss").Trim();
                string[] arrDate = datevalue.Split('/');
                string dateFormatToDB = "";
                string time = arrDate[2].Replace(arrDate[2].Substring(0, 4), string.Empty);
                if (Int32.Parse(arrDate[2].Substring(0, 4)) > 2500)
                {
                    //dateFormatToDB = (Int32.Parse(arrDate[2].Substring(0, 4)) - 543).ToString() + "-" + arrDate[1] + "-" + arrDate[0];
                    dateFormatToDB = arrDate[0] + "/" + arrDate[1] + "/" + (Int32.Parse(arrDate[2].Substring(0, 4)) - 543).ToString();
                    return dateFormatToDB;
                }
                else
                {
                    //dateFormatToDB = arrDate[2].Substring(0, 4) + "-" + arrDate[1] + "-" + arrDate[0];
                    dateFormatToDB = arrDate[0] + "/" + arrDate[1] + "/" + arrDate[2].Substring(0, 4);
                    return dateFormatToDB;
                }

            }
            catch (Exception e)
            {
                Utilities.LogError(e);
                throw (new Exception("Unable to convert datetime value to date string: " + e.Message));
            }
        }

        //Convert DateTime 31/03/2554 00:59:59 to string 00:59
        public static string ConvertDateTimeToShowTimeString(DateTime date)
        {
            try
            {
                string datevalue = date.ToString("dd/MM/yyyy HH:mm:ss").Trim();
                string timeString = Right(datevalue, 8).Substring(0, 5);

                return timeString;
            }
            catch (Exception e)
            {
                Utilities.LogError(e);
                throw (new Exception("Unable to convert datetime value to time string: " + e.Message));
            }
        }

        public static DateTime CheckCultureAndConvertToDateTime(string dateValue)
        {
            string culture = CultureInfo.CurrentCulture.Name.ToString();
            string[] arrDate = dateValue.Split('/');
            string dateFormat = "";

            if (culture == "th-TH")
            {
                dateFormat = arrDate[0] + "/" + arrDate[1] + "/" + arrDate[2].Substring(0, 4);
            }
            else
            {
                if (culture == "en-US")
                {
                    dateFormat = arrDate[1] + "/" + arrDate[0] + "/" + arrDate[2].Substring(0, 4);
                }
            }

            return Convert.ToDateTime(dateFormat);
        }

        public static long DateDiff(DateInterval interval, DateTime dt1, DateTime dt2)
        {
            if (interval == DateInterval.Year)
                return dt2.Year - dt1.Year;

            if (interval == DateInterval.Month)
                return (dt2.Month - dt1.Month) + (12 * (dt2.Year - dt1.Year));

            TimeSpan ts = dt2 - dt1;

            if (interval == DateInterval.Day || interval == DateInterval.DayOfYear)
                return Round(ts.TotalDays);

            if (interval == DateInterval.Hour)
                return Round(ts.TotalHours);

            if (interval == DateInterval.Minute)
                return Round(ts.TotalMinutes);

            if (interval == DateInterval.Second)
                return Round(ts.TotalSeconds);

            return 0;
        }

        private static long Round(double dVal)
        {
            if (dVal >= 0)
                return (long)Math.Floor(dVal);
            return (long)Math.Ceiling(dVal);
        }

        public static long DateDiff(DateTime effdatefrom, DateTime effdateto)
        {
            long divTodayWithLassChangePassword = Microsoft.VisualBasic.DateAndTime.DateDiff("d",
                                        effdatefrom.Date,
                                        effdateto.Date,
                                        Microsoft.VisualBasic.FirstDayOfWeek.System,
                                        Microsoft.VisualBasic.FirstWeekOfYear.System);
            return divTodayWithLassChangePassword;
        }
        
        public static DateTime GetEnDateTimeNow()
        {
            //DateTime dateReturn;

            try
            {
                string vDateNow = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                if (Int32.Parse(vDateNow.Substring(0, 4)) > 2500)
                {
                    //dateReturn = Convert.ToDateTime(DateTime.Now.AddYears(-543).ToString("dd/MM/yyyy HH:mm:ss"));
                    //return dateReturn;
                    return Convert.ToDateTime(DateTime.Now.AddYears(-543).ToString("yyyy-MM-dd HH:mm:ss"));
                }
                else
                {
                    //dateReturn = Convert.ToDateTime(DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                    //return dateReturn;
                    return Convert.ToDateTime(vDateNow);
                }
            }
            catch (Exception e)
            {
                Utilities.LogError(e);
                throw (new Exception("Unable to convert DateTime.Now format: " + e.Message));
            }
        }        

        public static bool CheckIsBackDate(string dateValue)
        {
            bool returnStatus = false;
            try
            {
                if (!string.IsNullOrEmpty(dateValue)) //24/09/2011
                {
                    //DateTime d_start_temp = Convert.ToDateTime(dateValue.ToString().Trim());                
                    //DateTime d_start = DateTime.Parse(d_start_temp.ToString());
                    DateTime d_start = CheckCultureAndConvertToDateTime(dateValue + " 23:59:00");
                    //DateTime d_stop = GetEnDateTimeNow();
                    //DateTime d_stop = CheckCultureAndConvertToDateTime(DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                    DateTime d_stop = CheckCultureAndConvertToDateTime(GetEnDateTimeNow().ToString("dd/MM/yyyy HH:mm:ss"));

                    long diffday = Microsoft.VisualBasic.DateAndTime.DateDiff("d", d_start, d_stop);
                    if (diffday > 0)
                    {
                        returnStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                returnStatus = false;
                //throw ex;
            }

            return returnStatus;
        }

        public static bool CheckIsBackDate(string dateValue, string compareValue)
        {
            bool returnStatus = false;

            try
            {
                if (!string.IsNullOrEmpty(dateValue) && !string.IsNullOrEmpty(compareValue))
                {
                    string dateTimeValue = dateValue;
                    string compareDateTimeValue = compareValue;
                    //DateTime dt1 = Convert.ToDateTime(dateTimeValue);
                    //DateTime dt2 = Convert.ToDateTime(compareDateTimeValue);
                    DateTime dt1 = CheckCultureAndConvertToDateTime(dateTimeValue);
                    DateTime dt2 = CheckCultureAndConvertToDateTime(compareDateTimeValue);
                    //TimeSpan ts = dt2 - dt1;
                    //int diffDays = ts.Days;

                    long diffday = Microsoft.VisualBasic.DateAndTime.DateDiff("d", dt1, dt2);
                    if (diffday > 0)
                    {
                        returnStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                returnStatus = false;
                //throw ex;
            }

            return returnStatus;
        }

        public static bool CheckIsBackDate(string dateValue, int canBackDay)
        {
            bool returnStatus = false;
            try
            {
                if (!string.IsNullOrEmpty(dateValue)) //24/09/2011
                {
                    //DateTime d_start_temp = Convert.ToDateTime(dateValue.ToString().Trim());                
                    //DateTime d_start = DateTime.Parse(d_start_temp.ToString());
                    DateTime d_start = CheckCultureAndConvertToDateTime(dateValue + " 23:59:00");
                    //DateTime d_stop = GetEnDateTimeNow();
                    //DateTime d_stop = CheckCultureAndConvertToDateTime(DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                    DateTime d_stop = CheckCultureAndConvertToDateTime(GetEnDateTimeNow().ToString("dd/MM/yyyy HH:mm:ss"));
                    d_stop = d_stop.AddDays(canBackDay);

                    long diffday = Microsoft.VisualBasic.DateAndTime.DateDiff("d", d_start, d_stop);
                    if (diffday > 0)
                    {
                        returnStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                returnStatus = false;
                //throw ex;
            }

            return returnStatus;
        }

        public static bool ChkIDNO(string idno)
        {
            bool functionReturnValue = false;
            // ไม่มีการป้อนข้อมูล ก็ให้ออกจากโปรแกรม
            if (string.IsNullOrEmpty(idno) || idno.Length == 0)
                return functionReturnValue;
            // ความยาวต้องเท่ากับ 13 หลัก
            if (idno.Length != 13)
            {
                return functionReturnValue;
            }
            // หาผลรวมตั้งแต่หลักที่ 1 ไปจนถึงหลักที่ 12
            int Sum = 0;
            //for (int Count = 1; Count <= 12; Count++)
            //{
            //    Sum += (Convert.ToInt32(idno.Substring(Count, 1)) * (14 - Count));            
            //}

            for (int i = 0; i < 12; i++)
            {
                Sum += (Convert.ToInt32(idno.Substring(i, 1)) * (13 - i));
            }

            // เปรียบเทียบค่าที่ได้กับหลักที่ 13
            int modIDNo = Sum % 11;
            int checkDigit = (11 - modIDNo) % 10;
            //if (Utilities.Right(idno, 1) == Utilities.Right((11 - (Sum % 11)).ToString(), 1))
            if (Right(idno, 1) == Right(checkDigit.ToString(), 1))
            {
                //return true;
                functionReturnValue = true;
            }
            else
            {
                //return false;
                functionReturnValue = false;
            }

            return functionReturnValue;
        }

        public static string Right(string value, int length)
        {
            string result = value.Substring(value.Length - length, length);
            return result;
        }

        public static string Left(string value, int length)
        {
            string result = value.Substring(0, length);
            return result;
        }

        public static void msgBOX(System.Web.UI.Page xPage, string xMessage)
        {
            ScriptManager.RegisterStartupScript(xPage, typeof(string), "Msg", "<script> alert('" + xMessage + "') </script>", false);
        }
        
    }
}