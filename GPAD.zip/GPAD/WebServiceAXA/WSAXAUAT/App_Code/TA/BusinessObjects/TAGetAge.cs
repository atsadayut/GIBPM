using System;
using System.Text;

namespace TA.BusinessObjects
{
	public class TAGetAge
	{

        private string _PlanID;

        public string PlanID
        {
            get { return _PlanID; }
            set { _PlanID = value; }
        }

        private string _PolicyType;

        public string PolicyType
        {
            get { return _PolicyType; }
            set { _PolicyType = value; }
        }

        private string _TravelPlan;

        public string TravelPlan
        {
            get { return _TravelPlan; }
            set { _TravelPlan = value; }
        }

        private string _AgeOfTravelerFrom;

        public string AgeOfTravelerFrom
        {
            get { return _AgeOfTravelerFrom; }
            set { _AgeOfTravelerFrom = value; }
        }


        private string _AgeOfTravelerTo;

        public string AgeOfTravelerTo
        {
            get { return _AgeOfTravelerTo; }
            set { _AgeOfTravelerTo = value; }
        }

        public TAGetAge()
        { 
        
        }
		
	}
}
