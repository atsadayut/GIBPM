using System;
using System.Text;

namespace TA.BusinessObjects
{
	
	public class TAPremuim
	{
        private string _NetPremium;
        public string NetPremium
        {
            get { return _NetPremium; }
            set { _NetPremium = value; }
        }

        private string _Stamp;
        public string Stamp
        {
            get { return _Stamp; }
            set { _Stamp = value; }
        }

        private string _TAX;
        public string TAX
        {
            get { return _TAX; }
            set { _TAX = value; }
        }

        private string _Total;
        public string Total
        {
            get { return _Total; }
            set { _Total = value; }
        }

        private string _PersonalAccident;
        public string PersonalAccident
        {
            get { return _PersonalAccident; }
            set { _PersonalAccident = value; }
        }

	
		public TAPremuim()
		{ }

        public TAPremuim(string NetPremium,string Stamp, string TAX, string Total, string PersonalAccident)
		{
            this.NetPremium = NetPremium;
            this.Stamp = Stamp;
            this.TAX = TAX;
            this.Total = Total;
            this.PersonalAccident = PersonalAccident;
		}

		public override string ToString()
		{
            return "NetPremium = " + NetPremium + "Stamp = " + Stamp + ",TAX = " + TAX + ",Total = " + Total + ",PersonalAccident = " + PersonalAccident;
		}
	}
}
