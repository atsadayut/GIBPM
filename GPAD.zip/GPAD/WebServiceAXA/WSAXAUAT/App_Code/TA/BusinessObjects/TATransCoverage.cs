using System;
using System.Text;

namespace TA.BusinessObjects
{
	[Serializable()]
	public class TATransCoverage
	{
		private string _JobNo;

		public string JobNo
		{
			get { return _JobNo; }
			set { _JobNo = value; }
		}

		private string _PersonalAccident;

		public string PersonalAccident
		{
			get { return _PersonalAccident; }
			set { _PersonalAccident = value; }
		}

		private string _MedicalExpense;

		public string MedicalExpense
		{
			get { return _MedicalExpense; }
			set { _MedicalExpense = value; }
		}

		private string _EmergencyMedical;

		public string EmergencyMedical
		{
			get { return _EmergencyMedical; }
			set { _EmergencyMedical = value; }
		}

		private string _Repatriation;

		public string Repatriation
		{
			get { return _Repatriation; }
			set { _Repatriation = value; }
		}

		private string _PersonalLiability;

		public string PersonalLiability
		{
			get { return _PersonalLiability; }
			set { _PersonalLiability = value; }
		}

		private string _TripCancellation;

		public string TripCancellation
		{
			get { return _TripCancellation; }
			set { _TripCancellation = value; }
		}

		private string _TravelDelay;

		public string TravelDelay
		{
			get { return _TravelDelay; }
			set { _TravelDelay = value; }
		}

		private string _FlightMisconnection;

		public string FlightMisconnection
		{
			get { return _FlightMisconnection; }
			set { _FlightMisconnection = value; }
		}

		private string _TripCurtailment;

		public string TripCurtailment
		{
			get { return _TripCurtailment; }
			set { _TripCurtailment = value; }
		}

		private string _BaggageDelay;

		public string BaggageDelay
		{
			get { return _BaggageDelay; }
			set { _BaggageDelay = value; }
		}

		private string _LossBaggage;

		public string LossBaggage
		{
			get { return _LossBaggage; }
			set { _LossBaggage = value; }
		}

		private string _LossPersonalMoney;

		public string LossPersonalMoney
		{
			get { return _LossPersonalMoney; }
			set { _LossPersonalMoney = value; }
		}

		private string _LossTravelDocument;

		public string LossTravelDocument
		{
			get { return _LossTravelDocument; }
			set { _LossTravelDocument = value; }
		}

		private string _CompassionateVisitation;

		public string CompassionateVisitation
		{
			get { return _CompassionateVisitation; }
			set { _CompassionateVisitation = value; }
		}

		private string _ReturnChildren;

		public string ReturnChildren
		{
			get { return _ReturnChildren; }
			set { _ReturnChildren = value; }
		}

		private string _AutomaticExtension;

		public string AutomaticExtension
		{
			get { return _AutomaticExtension; }
			set { _AutomaticExtension = value; }
		}

		private string _HospitalIncome;

		public string HospitalIncome
		{
			get { return _HospitalIncome; }
			set { _HospitalIncome = value; }
		}

		public TATransCoverage()
		{ }

		public TATransCoverage(string JobNo,string PersonalAccident,string MedicalExpense,string EmergencyMedical,string Repatriation,string PersonalLiability,string TripCancellation,string TravelDelay,string FlightMisconnection,string TripCurtailment,string BaggageDelay,string LossBaggage,string LossPersonalMoney,string LossTravelDocument,string CompassionateVisitation,string ReturnChildren,string AutomaticExtension,string HospitalIncome)
		{
			this.JobNo = JobNo;
			this.PersonalAccident = PersonalAccident;
			this.MedicalExpense = MedicalExpense;
			this.EmergencyMedical = EmergencyMedical;
			this.Repatriation = Repatriation;
			this.PersonalLiability = PersonalLiability;
			this.TripCancellation = TripCancellation;
			this.TravelDelay = TravelDelay;
			this.FlightMisconnection = FlightMisconnection;
			this.TripCurtailment = TripCurtailment;
			this.BaggageDelay = BaggageDelay;
			this.LossBaggage = LossBaggage;
			this.LossPersonalMoney = LossPersonalMoney;
			this.LossTravelDocument = LossTravelDocument;
			this.CompassionateVisitation = CompassionateVisitation;
			this.ReturnChildren = ReturnChildren;
			this.AutomaticExtension = AutomaticExtension;
			this.HospitalIncome = HospitalIncome;
		}

		public override string ToString()
		{
			return "JobNo = " + JobNo + ",PersonalAccident = " + PersonalAccident + ",MedicalExpense = " + MedicalExpense + ",EmergencyMedical = " + EmergencyMedical + ",Repatriation = " + Repatriation + ",PersonalLiability = " + PersonalLiability + ",TripCancellation = " + TripCancellation + ",TravelDelay = " + TravelDelay + ",FlightMisconnection = " + FlightMisconnection + ",TripCurtailment = " + TripCurtailment + ",BaggageDelay = " + BaggageDelay + ",LossBaggage = " + LossBaggage + ",LossPersonalMoney = " + LossPersonalMoney + ",LossTravelDocument = " + LossTravelDocument + ",CompassionateVisitation = " + CompassionateVisitation + ",ReturnChildren = " + ReturnChildren + ",AutomaticExtension = " + AutomaticExtension + ",HospitalIncome = " + HospitalIncome;
		}

		public class JobNoComparer : System.Collections.Generic.IComparer<TATransCoverage>
		{
			public SorterMode SorterMode;
			public JobNoComparer()
			{ }
			public JobNoComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransCoverage> Membres
			int System.Collections.Generic.IComparer<TATransCoverage>.Compare(TATransCoverage x, TATransCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.JobNo.CompareTo(x.JobNo);
				}
				else
				{
					return x.JobNo.CompareTo(y.JobNo);
				}
			}
			#endregion
		}
		public class PersonalAccidentComparer : System.Collections.Generic.IComparer<TATransCoverage>
		{
			public SorterMode SorterMode;
			public PersonalAccidentComparer()
			{ }
			public PersonalAccidentComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransCoverage> Membres
			int System.Collections.Generic.IComparer<TATransCoverage>.Compare(TATransCoverage x, TATransCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PersonalAccident.CompareTo(x.PersonalAccident);
				}
				else
				{
					return x.PersonalAccident.CompareTo(y.PersonalAccident);
				}
			}
			#endregion
		}
		public class MedicalExpenseComparer : System.Collections.Generic.IComparer<TATransCoverage>
		{
			public SorterMode SorterMode;
			public MedicalExpenseComparer()
			{ }
			public MedicalExpenseComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransCoverage> Membres
			int System.Collections.Generic.IComparer<TATransCoverage>.Compare(TATransCoverage x, TATransCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.MedicalExpense.CompareTo(x.MedicalExpense);
				}
				else
				{
					return x.MedicalExpense.CompareTo(y.MedicalExpense);
				}
			}
			#endregion
		}
		public class EmergencyMedicalComparer : System.Collections.Generic.IComparer<TATransCoverage>
		{
			public SorterMode SorterMode;
			public EmergencyMedicalComparer()
			{ }
			public EmergencyMedicalComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransCoverage> Membres
			int System.Collections.Generic.IComparer<TATransCoverage>.Compare(TATransCoverage x, TATransCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.EmergencyMedical.CompareTo(x.EmergencyMedical);
				}
				else
				{
					return x.EmergencyMedical.CompareTo(y.EmergencyMedical);
				}
			}
			#endregion
		}
		public class RepatriationComparer : System.Collections.Generic.IComparer<TATransCoverage>
		{
			public SorterMode SorterMode;
			public RepatriationComparer()
			{ }
			public RepatriationComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransCoverage> Membres
			int System.Collections.Generic.IComparer<TATransCoverage>.Compare(TATransCoverage x, TATransCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.Repatriation.CompareTo(x.Repatriation);
				}
				else
				{
					return x.Repatriation.CompareTo(y.Repatriation);
				}
			}
			#endregion
		}
		public class PersonalLiabilityComparer : System.Collections.Generic.IComparer<TATransCoverage>
		{
			public SorterMode SorterMode;
			public PersonalLiabilityComparer()
			{ }
			public PersonalLiabilityComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransCoverage> Membres
			int System.Collections.Generic.IComparer<TATransCoverage>.Compare(TATransCoverage x, TATransCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PersonalLiability.CompareTo(x.PersonalLiability);
				}
				else
				{
					return x.PersonalLiability.CompareTo(y.PersonalLiability);
				}
			}
			#endregion
		}
		public class TripCancellationComparer : System.Collections.Generic.IComparer<TATransCoverage>
		{
			public SorterMode SorterMode;
			public TripCancellationComparer()
			{ }
			public TripCancellationComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransCoverage> Membres
			int System.Collections.Generic.IComparer<TATransCoverage>.Compare(TATransCoverage x, TATransCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.TripCancellation.CompareTo(x.TripCancellation);
				}
				else
				{
					return x.TripCancellation.CompareTo(y.TripCancellation);
				}
			}
			#endregion
		}
		public class TravelDelayComparer : System.Collections.Generic.IComparer<TATransCoverage>
		{
			public SorterMode SorterMode;
			public TravelDelayComparer()
			{ }
			public TravelDelayComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransCoverage> Membres
			int System.Collections.Generic.IComparer<TATransCoverage>.Compare(TATransCoverage x, TATransCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.TravelDelay.CompareTo(x.TravelDelay);
				}
				else
				{
					return x.TravelDelay.CompareTo(y.TravelDelay);
				}
			}
			#endregion
		}
		public class FlightMisconnectionComparer : System.Collections.Generic.IComparer<TATransCoverage>
		{
			public SorterMode SorterMode;
			public FlightMisconnectionComparer()
			{ }
			public FlightMisconnectionComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransCoverage> Membres
			int System.Collections.Generic.IComparer<TATransCoverage>.Compare(TATransCoverage x, TATransCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.FlightMisconnection.CompareTo(x.FlightMisconnection);
				}
				else
				{
					return x.FlightMisconnection.CompareTo(y.FlightMisconnection);
				}
			}
			#endregion
		}
		public class TripCurtailmentComparer : System.Collections.Generic.IComparer<TATransCoverage>
		{
			public SorterMode SorterMode;
			public TripCurtailmentComparer()
			{ }
			public TripCurtailmentComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransCoverage> Membres
			int System.Collections.Generic.IComparer<TATransCoverage>.Compare(TATransCoverage x, TATransCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.TripCurtailment.CompareTo(x.TripCurtailment);
				}
				else
				{
					return x.TripCurtailment.CompareTo(y.TripCurtailment);
				}
			}
			#endregion
		}
		public class BaggageDelayComparer : System.Collections.Generic.IComparer<TATransCoverage>
		{
			public SorterMode SorterMode;
			public BaggageDelayComparer()
			{ }
			public BaggageDelayComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransCoverage> Membres
			int System.Collections.Generic.IComparer<TATransCoverage>.Compare(TATransCoverage x, TATransCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.BaggageDelay.CompareTo(x.BaggageDelay);
				}
				else
				{
					return x.BaggageDelay.CompareTo(y.BaggageDelay);
				}
			}
			#endregion
		}
		public class LossBaggageComparer : System.Collections.Generic.IComparer<TATransCoverage>
		{
			public SorterMode SorterMode;
			public LossBaggageComparer()
			{ }
			public LossBaggageComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransCoverage> Membres
			int System.Collections.Generic.IComparer<TATransCoverage>.Compare(TATransCoverage x, TATransCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.LossBaggage.CompareTo(x.LossBaggage);
				}
				else
				{
					return x.LossBaggage.CompareTo(y.LossBaggage);
				}
			}
			#endregion
		}
		public class LossPersonalMoneyComparer : System.Collections.Generic.IComparer<TATransCoverage>
		{
			public SorterMode SorterMode;
			public LossPersonalMoneyComparer()
			{ }
			public LossPersonalMoneyComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransCoverage> Membres
			int System.Collections.Generic.IComparer<TATransCoverage>.Compare(TATransCoverage x, TATransCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.LossPersonalMoney.CompareTo(x.LossPersonalMoney);
				}
				else
				{
					return x.LossPersonalMoney.CompareTo(y.LossPersonalMoney);
				}
			}
			#endregion
		}
		public class LossTravelDocumentComparer : System.Collections.Generic.IComparer<TATransCoverage>
		{
			public SorterMode SorterMode;
			public LossTravelDocumentComparer()
			{ }
			public LossTravelDocumentComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransCoverage> Membres
			int System.Collections.Generic.IComparer<TATransCoverage>.Compare(TATransCoverage x, TATransCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.LossTravelDocument.CompareTo(x.LossTravelDocument);
				}
				else
				{
					return x.LossTravelDocument.CompareTo(y.LossTravelDocument);
				}
			}
			#endregion
		}
		public class CompassionateVisitationComparer : System.Collections.Generic.IComparer<TATransCoverage>
		{
			public SorterMode SorterMode;
			public CompassionateVisitationComparer()
			{ }
			public CompassionateVisitationComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransCoverage> Membres
			int System.Collections.Generic.IComparer<TATransCoverage>.Compare(TATransCoverage x, TATransCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CompassionateVisitation.CompareTo(x.CompassionateVisitation);
				}
				else
				{
					return x.CompassionateVisitation.CompareTo(y.CompassionateVisitation);
				}
			}
			#endregion
		}
		public class ReturnChildrenComparer : System.Collections.Generic.IComparer<TATransCoverage>
		{
			public SorterMode SorterMode;
			public ReturnChildrenComparer()
			{ }
			public ReturnChildrenComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransCoverage> Membres
			int System.Collections.Generic.IComparer<TATransCoverage>.Compare(TATransCoverage x, TATransCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ReturnChildren.CompareTo(x.ReturnChildren);
				}
				else
				{
					return x.ReturnChildren.CompareTo(y.ReturnChildren);
				}
			}
			#endregion
		}
		public class AutomaticExtensionComparer : System.Collections.Generic.IComparer<TATransCoverage>
		{
			public SorterMode SorterMode;
			public AutomaticExtensionComparer()
			{ }
			public AutomaticExtensionComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransCoverage> Membres
			int System.Collections.Generic.IComparer<TATransCoverage>.Compare(TATransCoverage x, TATransCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.AutomaticExtension.CompareTo(x.AutomaticExtension);
				}
				else
				{
					return x.AutomaticExtension.CompareTo(y.AutomaticExtension);
				}
			}
			#endregion
		}
		public class HospitalIncomeComparer : System.Collections.Generic.IComparer<TATransCoverage>
		{
			public SorterMode SorterMode;
			public HospitalIncomeComparer()
			{ }
			public HospitalIncomeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransCoverage> Membres
			int System.Collections.Generic.IComparer<TATransCoverage>.Compare(TATransCoverage x, TATransCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.HospitalIncome.CompareTo(x.HospitalIncome);
				}
				else
				{
					return x.HospitalIncome.CompareTo(y.HospitalIncome);
				}
			}
			#endregion
		}
	}
}
