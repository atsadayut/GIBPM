using System;
using System.Text;

namespace TA.BusinessObjects
{
	[Serializable()]
	public class TAPlanPackage
	{
		private string _PlanID;

		public string PlanID
		{
			get { return _PlanID; }
			set { _PlanID = value; }
		}

		private string _PolicyType;

		public string PolicyType
		{
			get { return _PolicyType; }
			set { _PolicyType = value; }
		}

		private string _TravelPlan;

		public string TravelPlan
		{
			get { return _TravelPlan; }
			set { _TravelPlan = value; }
		}

		private string _ContractType;

		public string ContractType
		{
			get { return _ContractType; }
			set { _ContractType = value; }
		}

		private string _RiskType;

		public string RiskType
		{
			get { return _RiskType; }
			set { _RiskType = value; }
		}

		private string _PremiumClass;

		public string PremiumClass
		{
			get { return _PremiumClass; }
			set { _PremiumClass = value; }
		}

		private string _PlanCode;

		public string PlanCode
		{
			get { return _PlanCode; }
			set { _PlanCode = value; }
		}

		private string _TemplateCode;

		public string TemplateCode
		{
			get { return _TemplateCode; }
			set { _TemplateCode = value; }
		}

		private Nullable<SByte> _isEnable;

		public Nullable<SByte> isEnable
		{
			get { return _isEnable; }
			set { _isEnable = value; }
		}

		private Nullable<DateTime> _CreatDate;

		public Nullable<DateTime> CreatDate
		{
			get { return _CreatDate; }
			set { _CreatDate = value; }
		}

		private string _CreateUser;

		public string CreateUser
		{
			get { return _CreateUser; }
			set { _CreateUser = value; }
		}

		public TAPlanPackage()
		{ }

		public TAPlanPackage(string PlanID,string PolicyType,string TravelPlan,string ContractType,string RiskType,string PremiumClass,string PlanCode,string TemplateCode,Nullable<SByte> isEnable,Nullable<DateTime> CreatDate,string CreateUser)
		{
			this.PlanID = PlanID;
			this.PolicyType = PolicyType;
			this.TravelPlan = TravelPlan;
			this.ContractType = ContractType;
			this.RiskType = RiskType;
			this.PremiumClass = PremiumClass;
			this.PlanCode = PlanCode;
			this.TemplateCode = TemplateCode;
			this.isEnable = isEnable;
			this.CreatDate = CreatDate;
			this.CreateUser = CreateUser;
		}

		public override string ToString()
		{
			return "PlanID = " + PlanID + ",PolicyType = " + PolicyType + ",TravelPlan = " + TravelPlan + ",ContractType = " + ContractType + ",RiskType = " + RiskType + ",PremiumClass = " + PremiumClass + ",PlanCode = " + PlanCode + ",TemplateCode = " + TemplateCode + ",isEnable = " + isEnable.ToString() + ",CreatDate = " + CreatDate.ToString() + ",CreateUser = " + CreateUser;
		}

		public class PlanIDComparer : System.Collections.Generic.IComparer<TAPlanPackage>
		{
			public SorterMode SorterMode;
			public PlanIDComparer()
			{ }
			public PlanIDComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanPackage> Membres
			int System.Collections.Generic.IComparer<TAPlanPackage>.Compare(TAPlanPackage x, TAPlanPackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PlanID.CompareTo(x.PlanID);
				}
				else
				{
					return x.PlanID.CompareTo(y.PlanID);
				}
			}
			#endregion
		}
		public class PolicyTypeComparer : System.Collections.Generic.IComparer<TAPlanPackage>
		{
			public SorterMode SorterMode;
			public PolicyTypeComparer()
			{ }
			public PolicyTypeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanPackage> Membres
			int System.Collections.Generic.IComparer<TAPlanPackage>.Compare(TAPlanPackage x, TAPlanPackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PolicyType.CompareTo(x.PolicyType);
				}
				else
				{
					return x.PolicyType.CompareTo(y.PolicyType);
				}
			}
			#endregion
		}
		public class TravelPlanComparer : System.Collections.Generic.IComparer<TAPlanPackage>
		{
			public SorterMode SorterMode;
			public TravelPlanComparer()
			{ }
			public TravelPlanComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanPackage> Membres
			int System.Collections.Generic.IComparer<TAPlanPackage>.Compare(TAPlanPackage x, TAPlanPackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.TravelPlan.CompareTo(x.TravelPlan);
				}
				else
				{
					return x.TravelPlan.CompareTo(y.TravelPlan);
				}
			}
			#endregion
		}
		public class ContractTypeComparer : System.Collections.Generic.IComparer<TAPlanPackage>
		{
			public SorterMode SorterMode;
			public ContractTypeComparer()
			{ }
			public ContractTypeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanPackage> Membres
			int System.Collections.Generic.IComparer<TAPlanPackage>.Compare(TAPlanPackage x, TAPlanPackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ContractType.CompareTo(x.ContractType);
				}
				else
				{
					return x.ContractType.CompareTo(y.ContractType);
				}
			}
			#endregion
		}
		public class RiskTypeComparer : System.Collections.Generic.IComparer<TAPlanPackage>
		{
			public SorterMode SorterMode;
			public RiskTypeComparer()
			{ }
			public RiskTypeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanPackage> Membres
			int System.Collections.Generic.IComparer<TAPlanPackage>.Compare(TAPlanPackage x, TAPlanPackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.RiskType.CompareTo(x.RiskType);
				}
				else
				{
					return x.RiskType.CompareTo(y.RiskType);
				}
			}
			#endregion
		}
		public class PremiumClassComparer : System.Collections.Generic.IComparer<TAPlanPackage>
		{
			public SorterMode SorterMode;
			public PremiumClassComparer()
			{ }
			public PremiumClassComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanPackage> Membres
			int System.Collections.Generic.IComparer<TAPlanPackage>.Compare(TAPlanPackage x, TAPlanPackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PremiumClass.CompareTo(x.PremiumClass);
				}
				else
				{
					return x.PremiumClass.CompareTo(y.PremiumClass);
				}
			}
			#endregion
		}
		public class PlanCodeComparer : System.Collections.Generic.IComparer<TAPlanPackage>
		{
			public SorterMode SorterMode;
			public PlanCodeComparer()
			{ }
			public PlanCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanPackage> Membres
			int System.Collections.Generic.IComparer<TAPlanPackage>.Compare(TAPlanPackage x, TAPlanPackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PlanCode.CompareTo(x.PlanCode);
				}
				else
				{
					return x.PlanCode.CompareTo(y.PlanCode);
				}
			}
			#endregion
		}
		public class TemplateCodeComparer : System.Collections.Generic.IComparer<TAPlanPackage>
		{
			public SorterMode SorterMode;
			public TemplateCodeComparer()
			{ }
			public TemplateCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanPackage> Membres
			int System.Collections.Generic.IComparer<TAPlanPackage>.Compare(TAPlanPackage x, TAPlanPackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.TemplateCode.CompareTo(x.TemplateCode);
				}
				else
				{
					return x.TemplateCode.CompareTo(y.TemplateCode);
				}
			}
			#endregion
		}
		public class CreateUserComparer : System.Collections.Generic.IComparer<TAPlanPackage>
		{
			public SorterMode SorterMode;
			public CreateUserComparer()
			{ }
			public CreateUserComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanPackage> Membres
			int System.Collections.Generic.IComparer<TAPlanPackage>.Compare(TAPlanPackage x, TAPlanPackage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CreateUser.CompareTo(x.CreateUser);
				}
				else
				{
					return x.CreateUser.CompareTo(y.CreateUser);
				}
			}
			#endregion
		}
	}
}
