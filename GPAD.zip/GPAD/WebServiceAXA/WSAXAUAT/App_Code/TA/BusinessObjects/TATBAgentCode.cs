using System;
using System.Text;

namespace TA.BusinessObjects
{
	[Serializable()]
	public class TATBAgentCode
	{
		private string _GroupID;

		public string GroupID
		{
			get { return _GroupID; }
			set { _GroupID = value; }
		}

		private string _AgentCode;

		public string AgentCode
		{
			get { return _AgentCode; }
			set { _AgentCode = value; }
		}

		private string _Password;

		public string Password
		{
			get { return _Password; }
			set { _Password = value; }
		}

		private string _Branch;

		public string Branch
		{
			get { return _Branch; }
			set { _Branch = value; }
		}

		private string _AgentName;

		public string AgentName
		{
			get { return _AgentName; }
			set { _AgentName = value; }
		}

		private string _AccountType;

		public string AccountType
		{
			get { return _AccountType; }
			set { _AccountType = value; }
		}

		private string _AccountTypeName;

		public string AccountTypeName
		{
			get { return _AccountTypeName; }
			set { _AccountTypeName = value; }
		}

		private string _AgentLicenseNo;

		public string AgentLicenseNo
		{
			get { return _AgentLicenseNo; }
			set { _AgentLicenseNo = value; }
		}

		private Nullable<int> _AgentStartDate;

		public Nullable<int> AgentStartDate
		{
			get { return _AgentStartDate; }
			set { _AgentStartDate = value; }
		}

		private Nullable<int> _AgentEndDate;

		public Nullable<int> AgentEndDate
		{
			get { return _AgentEndDate; }
			set { _AgentEndDate = value; }
		}

		private string _ModifiedDateTime;

		public string ModifiedDateTime
		{
			get { return _ModifiedDateTime; }
			set { _ModifiedDateTime = value; }
		}

		private string _LSurname;

		public string LSurname
		{
			get { return _LSurname; }
			set { _LSurname = value; }
		}

		private string _LGivname;

		public string LGivname
		{
			get { return _LGivname; }
			set { _LGivname = value; }
		}

		public TATBAgentCode()
		{ }

		public TATBAgentCode(string GroupID,string AgentCode,string Password,string Branch,string AgentName,string AccountType,string AccountTypeName,string AgentLicenseNo,Nullable<int> AgentStartDate,Nullable<int> AgentEndDate,string ModifiedDateTime,string LSurname,string LGivname)
		{
			this.GroupID = GroupID;
			this.AgentCode = AgentCode;
			this.Password = Password;
			this.Branch = Branch;
			this.AgentName = AgentName;
			this.AccountType = AccountType;
			this.AccountTypeName = AccountTypeName;
			this.AgentLicenseNo = AgentLicenseNo;
			this.AgentStartDate = AgentStartDate;
			this.AgentEndDate = AgentEndDate;
			this.ModifiedDateTime = ModifiedDateTime;
			this.LSurname = LSurname;
			this.LGivname = LGivname;
		}

		public override string ToString()
		{
			return "GroupID = " + GroupID + ",AgentCode = " + AgentCode + ",Password = " + Password + ",Branch = " + Branch + ",AgentName = " + AgentName + ",AccountType = " + AccountType + ",AccountTypeName = " + AccountTypeName + ",AgentLicenseNo = " + AgentLicenseNo + ",AgentStartDate = " + AgentStartDate.ToString() + ",AgentEndDate = " + AgentEndDate.ToString() + ",ModifiedDateTime = " + ModifiedDateTime + ",LSurname = " + LSurname + ",LGivname = " + LGivname;
		}

		public class GroupIDComparer : System.Collections.Generic.IComparer<TATBAgentCode>
		{
			public SorterMode SorterMode;
			public GroupIDComparer()
			{ }
			public GroupIDComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATBAgentCode> Membres
			int System.Collections.Generic.IComparer<TATBAgentCode>.Compare(TATBAgentCode x, TATBAgentCode y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.GroupID.CompareTo(x.GroupID);
				}
				else
				{
					return x.GroupID.CompareTo(y.GroupID);
				}
			}
			#endregion
		}
		public class AgentCodeComparer : System.Collections.Generic.IComparer<TATBAgentCode>
		{
			public SorterMode SorterMode;
			public AgentCodeComparer()
			{ }
			public AgentCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATBAgentCode> Membres
			int System.Collections.Generic.IComparer<TATBAgentCode>.Compare(TATBAgentCode x, TATBAgentCode y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.AgentCode.CompareTo(x.AgentCode);
				}
				else
				{
					return x.AgentCode.CompareTo(y.AgentCode);
				}
			}
			#endregion
		}
		public class PasswordComparer : System.Collections.Generic.IComparer<TATBAgentCode>
		{
			public SorterMode SorterMode;
			public PasswordComparer()
			{ }
			public PasswordComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATBAgentCode> Membres
			int System.Collections.Generic.IComparer<TATBAgentCode>.Compare(TATBAgentCode x, TATBAgentCode y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.Password.CompareTo(x.Password);
				}
				else
				{
					return x.Password.CompareTo(y.Password);
				}
			}
			#endregion
		}
		public class BranchComparer : System.Collections.Generic.IComparer<TATBAgentCode>
		{
			public SorterMode SorterMode;
			public BranchComparer()
			{ }
			public BranchComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATBAgentCode> Membres
			int System.Collections.Generic.IComparer<TATBAgentCode>.Compare(TATBAgentCode x, TATBAgentCode y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.Branch.CompareTo(x.Branch);
				}
				else
				{
					return x.Branch.CompareTo(y.Branch);
				}
			}
			#endregion
		}
		public class AgentNameComparer : System.Collections.Generic.IComparer<TATBAgentCode>
		{
			public SorterMode SorterMode;
			public AgentNameComparer()
			{ }
			public AgentNameComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATBAgentCode> Membres
			int System.Collections.Generic.IComparer<TATBAgentCode>.Compare(TATBAgentCode x, TATBAgentCode y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.AgentName.CompareTo(x.AgentName);
				}
				else
				{
					return x.AgentName.CompareTo(y.AgentName);
				}
			}
			#endregion
		}
		public class AccountTypeComparer : System.Collections.Generic.IComparer<TATBAgentCode>
		{
			public SorterMode SorterMode;
			public AccountTypeComparer()
			{ }
			public AccountTypeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATBAgentCode> Membres
			int System.Collections.Generic.IComparer<TATBAgentCode>.Compare(TATBAgentCode x, TATBAgentCode y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.AccountType.CompareTo(x.AccountType);
				}
				else
				{
					return x.AccountType.CompareTo(y.AccountType);
				}
			}
			#endregion
		}
		public class AccountTypeNameComparer : System.Collections.Generic.IComparer<TATBAgentCode>
		{
			public SorterMode SorterMode;
			public AccountTypeNameComparer()
			{ }
			public AccountTypeNameComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATBAgentCode> Membres
			int System.Collections.Generic.IComparer<TATBAgentCode>.Compare(TATBAgentCode x, TATBAgentCode y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.AccountTypeName.CompareTo(x.AccountTypeName);
				}
				else
				{
					return x.AccountTypeName.CompareTo(y.AccountTypeName);
				}
			}
			#endregion
		}
		public class AgentLicenseNoComparer : System.Collections.Generic.IComparer<TATBAgentCode>
		{
			public SorterMode SorterMode;
			public AgentLicenseNoComparer()
			{ }
			public AgentLicenseNoComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATBAgentCode> Membres
			int System.Collections.Generic.IComparer<TATBAgentCode>.Compare(TATBAgentCode x, TATBAgentCode y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.AgentLicenseNo.CompareTo(x.AgentLicenseNo);
				}
				else
				{
					return x.AgentLicenseNo.CompareTo(y.AgentLicenseNo);
				}
			}
			#endregion
		}
		public class ModifiedDateTimeComparer : System.Collections.Generic.IComparer<TATBAgentCode>
		{
			public SorterMode SorterMode;
			public ModifiedDateTimeComparer()
			{ }
			public ModifiedDateTimeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATBAgentCode> Membres
			int System.Collections.Generic.IComparer<TATBAgentCode>.Compare(TATBAgentCode x, TATBAgentCode y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ModifiedDateTime.CompareTo(x.ModifiedDateTime);
				}
				else
				{
					return x.ModifiedDateTime.CompareTo(y.ModifiedDateTime);
				}
			}
			#endregion
		}
		public class LSurnameComparer : System.Collections.Generic.IComparer<TATBAgentCode>
		{
			public SorterMode SorterMode;
			public LSurnameComparer()
			{ }
			public LSurnameComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATBAgentCode> Membres
			int System.Collections.Generic.IComparer<TATBAgentCode>.Compare(TATBAgentCode x, TATBAgentCode y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.LSurname.CompareTo(x.LSurname);
				}
				else
				{
					return x.LSurname.CompareTo(y.LSurname);
				}
			}
			#endregion
		}
		public class LGivnameComparer : System.Collections.Generic.IComparer<TATBAgentCode>
		{
			public SorterMode SorterMode;
			public LGivnameComparer()
			{ }
			public LGivnameComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATBAgentCode> Membres
			int System.Collections.Generic.IComparer<TATBAgentCode>.Compare(TATBAgentCode x, TATBAgentCode y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.LGivname.CompareTo(x.LGivname);
				}
				else
				{
					return x.LGivname.CompareTo(y.LGivname);
				}
			}
			#endregion
		}
	}
}
