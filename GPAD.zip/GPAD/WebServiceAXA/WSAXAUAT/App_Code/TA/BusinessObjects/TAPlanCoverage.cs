using System;
using System.Text;

namespace TA.BusinessObjects
{
	[Serializable()]
	public class TAPlanCoverage
	{
		private int _ID;

		public int ID
		{
			get { return _ID; }
			set { _ID = value; }
		}

		private string _PlanType;

		public string PlanType
		{
			get { return _PlanType; }
			set { _PlanType = value; }
		}

		private string _CoverageType;

		public string CoverageType
		{
			get { return _CoverageType; }
			set { _CoverageType = value; }
		}

		private string _CoverageLine;

		public string CoverageLine
		{
			get { return _CoverageLine; }
			set { _CoverageLine = value; }
		}

		private string _CoverageDetailEN;

		public string CoverageDetailEN
		{
			get { return _CoverageDetailEN; }
			set { _CoverageDetailEN = value; }
		}

		private string _CoverageDetailTH;

		public string CoverageDetailTH
		{
			get { return _CoverageDetailTH; }
			set { _CoverageDetailTH = value; }
		}

		private string _CoveragePlan1;

		public string CoveragePlan1
		{
			get { return _CoveragePlan1; }
			set { _CoveragePlan1 = value; }
		}

		private string _CoveragePlan2;

		public string CoveragePlan2
		{
			get { return _CoveragePlan2; }
			set { _CoveragePlan2 = value; }
		}

		private string _CoveragePlan3;

		public string CoveragePlan3
		{
			get { return _CoveragePlan3; }
			set { _CoveragePlan3 = value; }
		}

		private string _CoveragePlan4;

		public string CoveragePlan4
		{
			get { return _CoveragePlan4; }
			set { _CoveragePlan4 = value; }
		}

		private string _CoveragePlan5;

		public string CoveragePlan5
		{
			get { return _CoveragePlan5; }
			set { _CoveragePlan5 = value; }
		}

		private Nullable<DateTime> _CreateDate;

		public Nullable<DateTime> CreateDate
		{
			get { return _CreateDate; }
			set { _CreateDate = value; }
		}

		private string _CreateUser;

		public string CreateUser
		{
			get { return _CreateUser; }
			set { _CreateUser = value; }
		}

		private string _FieldName;

		public string FieldName
		{
			get { return _FieldName; }
			set { _FieldName = value; }
		}

		public TAPlanCoverage()
		{ }

		public TAPlanCoverage(int ID,string PlanType,string CoverageType,string CoverageLine,string CoverageDetailEN,string CoverageDetailTH,string CoveragePlan1,string CoveragePlan2,string CoveragePlan3,string CoveragePlan4,string CoveragePlan5,Nullable<DateTime> CreateDate,string CreateUser,string FieldName)
		{
			this.ID = ID;
			this.PlanType = PlanType;
			this.CoverageType = CoverageType;
			this.CoverageLine = CoverageLine;
			this.CoverageDetailEN = CoverageDetailEN;
			this.CoverageDetailTH = CoverageDetailTH;
			this.CoveragePlan1 = CoveragePlan1;
			this.CoveragePlan2 = CoveragePlan2;
			this.CoveragePlan3 = CoveragePlan3;
			this.CoveragePlan4 = CoveragePlan4;
			this.CoveragePlan5 = CoveragePlan5;
			this.CreateDate = CreateDate;
			this.CreateUser = CreateUser;
			this.FieldName = FieldName;
		}

		public override string ToString()
		{
			return "ID = " + ID.ToString() + ",PlanType = " + PlanType + ",CoverageType = " + CoverageType + ",CoverageLine = " + CoverageLine + ",CoverageDetailEN = " + CoverageDetailEN + ",CoverageDetailTH = " + CoverageDetailTH + ",CoveragePlan1 = " + CoveragePlan1 + ",CoveragePlan2 = " + CoveragePlan2 + ",CoveragePlan3 = " + CoveragePlan3 + ",CoveragePlan4 = " + CoveragePlan4 + ",CoveragePlan5 = " + CoveragePlan5 + ",CreateDate = " + CreateDate.ToString() + ",CreateUser = " + CreateUser + ",FieldName = " + FieldName;
		}

		public class IDComparer : System.Collections.Generic.IComparer<TAPlanCoverage>
		{
			public SorterMode SorterMode;
			public IDComparer()
			{ }
			public IDComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanCoverage> Membres
			int System.Collections.Generic.IComparer<TAPlanCoverage>.Compare(TAPlanCoverage x, TAPlanCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ID.CompareTo(x.ID);
				}
				else
				{
					return x.ID.CompareTo(y.ID);
				}
			}
			#endregion
		}
		public class PlanTypeComparer : System.Collections.Generic.IComparer<TAPlanCoverage>
		{
			public SorterMode SorterMode;
			public PlanTypeComparer()
			{ }
			public PlanTypeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanCoverage> Membres
			int System.Collections.Generic.IComparer<TAPlanCoverage>.Compare(TAPlanCoverage x, TAPlanCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PlanType.CompareTo(x.PlanType);
				}
				else
				{
					return x.PlanType.CompareTo(y.PlanType);
				}
			}
			#endregion
		}
		public class CoverageTypeComparer : System.Collections.Generic.IComparer<TAPlanCoverage>
		{
			public SorterMode SorterMode;
			public CoverageTypeComparer()
			{ }
			public CoverageTypeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanCoverage> Membres
			int System.Collections.Generic.IComparer<TAPlanCoverage>.Compare(TAPlanCoverage x, TAPlanCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CoverageType.CompareTo(x.CoverageType);
				}
				else
				{
					return x.CoverageType.CompareTo(y.CoverageType);
				}
			}
			#endregion
		}
		public class CoverageLineComparer : System.Collections.Generic.IComparer<TAPlanCoverage>
		{
			public SorterMode SorterMode;
			public CoverageLineComparer()
			{ }
			public CoverageLineComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanCoverage> Membres
			int System.Collections.Generic.IComparer<TAPlanCoverage>.Compare(TAPlanCoverage x, TAPlanCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CoverageLine.CompareTo(x.CoverageLine);
				}
				else
				{
					return x.CoverageLine.CompareTo(y.CoverageLine);
				}
			}
			#endregion
		}
		public class CoverageDetailENComparer : System.Collections.Generic.IComparer<TAPlanCoverage>
		{
			public SorterMode SorterMode;
			public CoverageDetailENComparer()
			{ }
			public CoverageDetailENComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanCoverage> Membres
			int System.Collections.Generic.IComparer<TAPlanCoverage>.Compare(TAPlanCoverage x, TAPlanCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CoverageDetailEN.CompareTo(x.CoverageDetailEN);
				}
				else
				{
					return x.CoverageDetailEN.CompareTo(y.CoverageDetailEN);
				}
			}
			#endregion
		}
		public class CoverageDetailTHComparer : System.Collections.Generic.IComparer<TAPlanCoverage>
		{
			public SorterMode SorterMode;
			public CoverageDetailTHComparer()
			{ }
			public CoverageDetailTHComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanCoverage> Membres
			int System.Collections.Generic.IComparer<TAPlanCoverage>.Compare(TAPlanCoverage x, TAPlanCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CoverageDetailTH.CompareTo(x.CoverageDetailTH);
				}
				else
				{
					return x.CoverageDetailTH.CompareTo(y.CoverageDetailTH);
				}
			}
			#endregion
		}
		public class CoveragePlan1Comparer : System.Collections.Generic.IComparer<TAPlanCoverage>
		{
			public SorterMode SorterMode;
			public CoveragePlan1Comparer()
			{ }
			public CoveragePlan1Comparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanCoverage> Membres
			int System.Collections.Generic.IComparer<TAPlanCoverage>.Compare(TAPlanCoverage x, TAPlanCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CoveragePlan1.CompareTo(x.CoveragePlan1);
				}
				else
				{
					return x.CoveragePlan1.CompareTo(y.CoveragePlan1);
				}
			}
			#endregion
		}
		public class CoveragePlan2Comparer : System.Collections.Generic.IComparer<TAPlanCoverage>
		{
			public SorterMode SorterMode;
			public CoveragePlan2Comparer()
			{ }
			public CoveragePlan2Comparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanCoverage> Membres
			int System.Collections.Generic.IComparer<TAPlanCoverage>.Compare(TAPlanCoverage x, TAPlanCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CoveragePlan2.CompareTo(x.CoveragePlan2);
				}
				else
				{
					return x.CoveragePlan2.CompareTo(y.CoveragePlan2);
				}
			}
			#endregion
		}
		public class CoveragePlan3Comparer : System.Collections.Generic.IComparer<TAPlanCoverage>
		{
			public SorterMode SorterMode;
			public CoveragePlan3Comparer()
			{ }
			public CoveragePlan3Comparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanCoverage> Membres
			int System.Collections.Generic.IComparer<TAPlanCoverage>.Compare(TAPlanCoverage x, TAPlanCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CoveragePlan3.CompareTo(x.CoveragePlan3);
				}
				else
				{
					return x.CoveragePlan3.CompareTo(y.CoveragePlan3);
				}
			}
			#endregion
		}
		public class CoveragePlan4Comparer : System.Collections.Generic.IComparer<TAPlanCoverage>
		{
			public SorterMode SorterMode;
			public CoveragePlan4Comparer()
			{ }
			public CoveragePlan4Comparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanCoverage> Membres
			int System.Collections.Generic.IComparer<TAPlanCoverage>.Compare(TAPlanCoverage x, TAPlanCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CoveragePlan4.CompareTo(x.CoveragePlan4);
				}
				else
				{
					return x.CoveragePlan4.CompareTo(y.CoveragePlan4);
				}
			}
			#endregion
		}
		public class CoveragePlan5Comparer : System.Collections.Generic.IComparer<TAPlanCoverage>
		{
			public SorterMode SorterMode;
			public CoveragePlan5Comparer()
			{ }
			public CoveragePlan5Comparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanCoverage> Membres
			int System.Collections.Generic.IComparer<TAPlanCoverage>.Compare(TAPlanCoverage x, TAPlanCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CoveragePlan5.CompareTo(x.CoveragePlan5);
				}
				else
				{
					return x.CoveragePlan5.CompareTo(y.CoveragePlan5);
				}
			}
			#endregion
		}
		public class CreateUserComparer : System.Collections.Generic.IComparer<TAPlanCoverage>
		{
			public SorterMode SorterMode;
			public CreateUserComparer()
			{ }
			public CreateUserComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanCoverage> Membres
			int System.Collections.Generic.IComparer<TAPlanCoverage>.Compare(TAPlanCoverage x, TAPlanCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CreateUser.CompareTo(x.CreateUser);
				}
				else
				{
					return x.CreateUser.CompareTo(y.CreateUser);
				}
			}
			#endregion
		}
		public class FieldNameComparer : System.Collections.Generic.IComparer<TAPlanCoverage>
		{
			public SorterMode SorterMode;
			public FieldNameComparer()
			{ }
			public FieldNameComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanCoverage> Membres
			int System.Collections.Generic.IComparer<TAPlanCoverage>.Compare(TAPlanCoverage x, TAPlanCoverage y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.FieldName.CompareTo(x.FieldName);
				}
				else
				{
					return x.FieldName.CompareTo(y.FieldName);
				}
			}
			#endregion
		}
	}
}
