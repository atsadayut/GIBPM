using System;
using System.Text;

namespace TA.BusinessObjects
{
	[Serializable()]
	public class TAPlanPremuim
	{
		private string _PlanID;

		public string PlanID
		{
			get { return _PlanID; }
			set { _PlanID = value; }
		}

		private string _PolicyType;

		public string PolicyType
		{
			get { return _PolicyType; }
			set { _PolicyType = value; }
		}

		private string _TravelPlan;

		public string TravelPlan
		{
			get { return _TravelPlan; }
			set { _TravelPlan = value; }
		}

		private int _DurationFrom;

		public int DurationFrom
		{
			get { return _DurationFrom; }
			set { _DurationFrom = value; }
		}

		private int _DurationTo;

		public int DurationTo
		{
			get { return _DurationTo; }
			set { _DurationTo = value; }
		}

		private Nullable<Double> _NetPremium;

		public Nullable<Double> NetPremium
		{
			get { return _NetPremium; }
			set { _NetPremium = value; }
		}

		private Nullable<SByte> _isEnabel;

		public Nullable<SByte> isEnabel
		{
			get { return _isEnabel; }
			set { _isEnabel = value; }
		}

		private Nullable<DateTime> _CreatedDate;

		public Nullable<DateTime> CreatedDate
		{
			get { return _CreatedDate; }
			set { _CreatedDate = value; }
		}

		private string _CreatedUser;

		public string CreatedUser
		{
			get { return _CreatedUser; }
			set { _CreatedUser = value; }
		}

		public TAPlanPremuim()
		{ }

		public TAPlanPremuim(string PlanID,string PolicyType,string TravelPlan,int DurationFrom,int DurationTo,Nullable<Double> NetPremium,Nullable<SByte> isEnabel,Nullable<DateTime> CreatedDate,string CreatedUser)
		{
			this.PlanID = PlanID;
			this.PolicyType = PolicyType;
			this.TravelPlan = TravelPlan;
			this.DurationFrom = DurationFrom;
			this.DurationTo = DurationTo;
			this.NetPremium = NetPremium;
			this.isEnabel = isEnabel;
			this.CreatedDate = CreatedDate;
			this.CreatedUser = CreatedUser;
		}

		public override string ToString()
		{
			return "PlanID = " + PlanID + ",PolicyType = " + PolicyType + ",TravelPlan = " + TravelPlan + ",DurationFrom = " + DurationFrom.ToString() + ",DurationTo = " + DurationTo.ToString() + ",NetPremium = " + NetPremium.ToString() + ",isEnabel = " + isEnabel.ToString() + ",CreatedDate = " + CreatedDate.ToString() + ",CreatedUser = " + CreatedUser;
		}

		public class PlanIDComparer : System.Collections.Generic.IComparer<TAPlanPremuim>
		{
			public SorterMode SorterMode;
			public PlanIDComparer()
			{ }
			public PlanIDComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanPremuim> Membres
			int System.Collections.Generic.IComparer<TAPlanPremuim>.Compare(TAPlanPremuim x, TAPlanPremuim y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PlanID.CompareTo(x.PlanID);
				}
				else
				{
					return x.PlanID.CompareTo(y.PlanID);
				}
			}
			#endregion
		}
		public class PolicyTypeComparer : System.Collections.Generic.IComparer<TAPlanPremuim>
		{
			public SorterMode SorterMode;
			public PolicyTypeComparer()
			{ }
			public PolicyTypeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanPremuim> Membres
			int System.Collections.Generic.IComparer<TAPlanPremuim>.Compare(TAPlanPremuim x, TAPlanPremuim y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PolicyType.CompareTo(x.PolicyType);
				}
				else
				{
					return x.PolicyType.CompareTo(y.PolicyType);
				}
			}
			#endregion
		}
		public class TravelPlanComparer : System.Collections.Generic.IComparer<TAPlanPremuim>
		{
			public SorterMode SorterMode;
			public TravelPlanComparer()
			{ }
			public TravelPlanComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanPremuim> Membres
			int System.Collections.Generic.IComparer<TAPlanPremuim>.Compare(TAPlanPremuim x, TAPlanPremuim y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.TravelPlan.CompareTo(x.TravelPlan);
				}
				else
				{
					return x.TravelPlan.CompareTo(y.TravelPlan);
				}
			}
			#endregion
		}
		public class DurationFromComparer : System.Collections.Generic.IComparer<TAPlanPremuim>
		{
			public SorterMode SorterMode;
			public DurationFromComparer()
			{ }
			public DurationFromComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanPremuim> Membres
			int System.Collections.Generic.IComparer<TAPlanPremuim>.Compare(TAPlanPremuim x, TAPlanPremuim y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.DurationFrom.CompareTo(x.DurationFrom);
				}
				else
				{
					return x.DurationFrom.CompareTo(y.DurationFrom);
				}
			}
			#endregion
		}
		public class DurationToComparer : System.Collections.Generic.IComparer<TAPlanPremuim>
		{
			public SorterMode SorterMode;
			public DurationToComparer()
			{ }
			public DurationToComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanPremuim> Membres
			int System.Collections.Generic.IComparer<TAPlanPremuim>.Compare(TAPlanPremuim x, TAPlanPremuim y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.DurationTo.CompareTo(x.DurationTo);
				}
				else
				{
					return x.DurationTo.CompareTo(y.DurationTo);
				}
			}
			#endregion
		}
		public class CreatedUserComparer : System.Collections.Generic.IComparer<TAPlanPremuim>
		{
			public SorterMode SorterMode;
			public CreatedUserComparer()
			{ }
			public CreatedUserComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanPremuim> Membres
			int System.Collections.Generic.IComparer<TAPlanPremuim>.Compare(TAPlanPremuim x, TAPlanPremuim y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CreatedUser.CompareTo(x.CreatedUser);
				}
				else
				{
					return x.CreatedUser.CompareTo(y.CreatedUser);
				}
			}
			#endregion
		}
	}
}
