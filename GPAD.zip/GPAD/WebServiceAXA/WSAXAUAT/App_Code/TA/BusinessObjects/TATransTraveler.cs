using System;
using System.Text;

namespace TA.BusinessObjects
{
	[Serializable()]
	public class TATransTraveler
	{
		private string _JobNo;

		public string JobNo
		{
			get { return _JobNo; }
			set { _JobNo = value; }
		}

		private int _TravelerId;

		public int TravelerId
		{
			get { return _TravelerId; }
			set { _TravelerId = value; }
		}

		private string _ClientTitle;

		public string ClientTitle
		{
			get { return _ClientTitle; }
			set { _ClientTitle = value; }
		}

		private string _ClientName;

		public string ClientName
		{
			get { return _ClientName; }
			set { _ClientName = value; }
		}

		private string _ClientSurName;

		public string ClientSurName
		{
			get { return _ClientSurName; }
			set { _ClientSurName = value; }
		}

		private string _Birthday;

		public string Birthday
		{
			get { return _Birthday; }
			set { _Birthday = value; }
		}

		private string _PassportID;

		public string PassportID
		{
			get { return _PassportID; }
			set { _PassportID = value; }
		}

		private string _Tel;

		public string Tel
		{
			get { return _Tel; }
			set { _Tel = value; }
		}

		private Nullable<SByte> _isStudent;

		public Nullable<SByte> isStudent
		{
			get { return _isStudent; }
			set { _isStudent = value; }
		}

		private Nullable<SByte> _isSingle;

		public Nullable<SByte> isSingle
		{
			get { return _isSingle; }
			set { _isSingle = value; }
		}

		private Nullable<DateTime> _CreateDate;

		public Nullable<DateTime> CreateDate
		{
			get { return _CreateDate; }
			set { _CreateDate = value; }
		}

		public TATransTraveler()
		{ }

		public TATransTraveler(string JobNo,int TravelerId,string ClientTitle,string ClientName,string ClientSurName,string Birthday,string PassportID,string Tel,Nullable<SByte> isStudent,Nullable<SByte> isSingle,Nullable<DateTime> CreateDate)
		{
			this.JobNo = JobNo;
			this.TravelerId = TravelerId;
			this.ClientTitle = ClientTitle;
			this.ClientName = ClientName;
			this.ClientSurName = ClientSurName;
			this.Birthday = Birthday;
			this.PassportID = PassportID;
			this.Tel = Tel;
			this.isStudent = isStudent;
			this.isSingle = isSingle;
			this.CreateDate = CreateDate;
		}

		public override string ToString()
		{
			return "JobNo = " + JobNo + ",TravelerId = " + TravelerId.ToString() + ",ClientTitle = " + ClientTitle + ",ClientName = " + ClientName + ",ClientSurName = " + ClientSurName + ",Birthday = " + Birthday + ",PassportID = " + PassportID + ",Tel = " + Tel + ",isStudent = " + isStudent.ToString() + ",isSingle = " + isSingle.ToString() + ",CreateDate = " + CreateDate.ToString();
		}

		public class JobNoComparer : System.Collections.Generic.IComparer<TATransTraveler>
		{
			public SorterMode SorterMode;
			public JobNoComparer()
			{ }
			public JobNoComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransTraveler> Membres
			int System.Collections.Generic.IComparer<TATransTraveler>.Compare(TATransTraveler x, TATransTraveler y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.JobNo.CompareTo(x.JobNo);
				}
				else
				{
					return x.JobNo.CompareTo(y.JobNo);
				}
			}
			#endregion
		}
		public class TravelerIdComparer : System.Collections.Generic.IComparer<TATransTraveler>
		{
			public SorterMode SorterMode;
			public TravelerIdComparer()
			{ }
			public TravelerIdComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransTraveler> Membres
			int System.Collections.Generic.IComparer<TATransTraveler>.Compare(TATransTraveler x, TATransTraveler y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.TravelerId.CompareTo(x.TravelerId);
				}
				else
				{
					return x.TravelerId.CompareTo(y.TravelerId);
				}
			}
			#endregion
		}
		public class ClientTitleComparer : System.Collections.Generic.IComparer<TATransTraveler>
		{
			public SorterMode SorterMode;
			public ClientTitleComparer()
			{ }
			public ClientTitleComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransTraveler> Membres
			int System.Collections.Generic.IComparer<TATransTraveler>.Compare(TATransTraveler x, TATransTraveler y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ClientTitle.CompareTo(x.ClientTitle);
				}
				else
				{
					return x.ClientTitle.CompareTo(y.ClientTitle);
				}
			}
			#endregion
		}
		public class ClientNameComparer : System.Collections.Generic.IComparer<TATransTraveler>
		{
			public SorterMode SorterMode;
			public ClientNameComparer()
			{ }
			public ClientNameComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransTraveler> Membres
			int System.Collections.Generic.IComparer<TATransTraveler>.Compare(TATransTraveler x, TATransTraveler y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ClientName.CompareTo(x.ClientName);
				}
				else
				{
					return x.ClientName.CompareTo(y.ClientName);
				}
			}
			#endregion
		}
		public class ClientSurNameComparer : System.Collections.Generic.IComparer<TATransTraveler>
		{
			public SorterMode SorterMode;
			public ClientSurNameComparer()
			{ }
			public ClientSurNameComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransTraveler> Membres
			int System.Collections.Generic.IComparer<TATransTraveler>.Compare(TATransTraveler x, TATransTraveler y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ClientSurName.CompareTo(x.ClientSurName);
				}
				else
				{
					return x.ClientSurName.CompareTo(y.ClientSurName);
				}
			}
			#endregion
		}
		public class BirthdayComparer : System.Collections.Generic.IComparer<TATransTraveler>
		{
			public SorterMode SorterMode;
			public BirthdayComparer()
			{ }
			public BirthdayComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransTraveler> Membres
			int System.Collections.Generic.IComparer<TATransTraveler>.Compare(TATransTraveler x, TATransTraveler y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.Birthday.CompareTo(x.Birthday);
				}
				else
				{
					return x.Birthday.CompareTo(y.Birthday);
				}
			}
			#endregion
		}
		public class PassportIDComparer : System.Collections.Generic.IComparer<TATransTraveler>
		{
			public SorterMode SorterMode;
			public PassportIDComparer()
			{ }
			public PassportIDComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransTraveler> Membres
			int System.Collections.Generic.IComparer<TATransTraveler>.Compare(TATransTraveler x, TATransTraveler y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PassportID.CompareTo(x.PassportID);
				}
				else
				{
					return x.PassportID.CompareTo(y.PassportID);
				}
			}
			#endregion
		}
		public class TelComparer : System.Collections.Generic.IComparer<TATransTraveler>
		{
			public SorterMode SorterMode;
			public TelComparer()
			{ }
			public TelComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransTraveler> Membres
			int System.Collections.Generic.IComparer<TATransTraveler>.Compare(TATransTraveler x, TATransTraveler y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.Tel.CompareTo(x.Tel);
				}
				else
				{
					return x.Tel.CompareTo(y.Tel);
				}
			}
			#endregion
		}
	}
}
