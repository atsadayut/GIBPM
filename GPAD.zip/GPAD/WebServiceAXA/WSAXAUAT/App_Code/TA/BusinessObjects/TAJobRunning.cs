using System;
using System.Text;

namespace TA.BusinessObjects
{
	[Serializable()]
	public class TAJobRunning
	{
		private string _PREFIX;

		public string PREFIX
		{
			get { return _PREFIX; }
			set { _PREFIX = value; }
		}

		private int _YEAR;

		public int YEAR
		{
			get { return _YEAR; }
			set { _YEAR = value; }
		}

		private int _MONTH;

		public int MONTH
		{
			get { return _MONTH; }
			set { _MONTH = value; }
		}

		private string _RUNNING;

		public string RUNNING
		{
			get { return _RUNNING; }
			set { _RUNNING = value; }
		}

		public TAJobRunning()
		{ }

		public TAJobRunning(string PREFIX,int YEAR,int MONTH,string RUNNING)
		{
			this.PREFIX = PREFIX;
			this.YEAR = YEAR;
			this.MONTH = MONTH;
			this.RUNNING = RUNNING;
		}

		public override string ToString()
		{
			return "PREFIX = " + PREFIX + ",YEAR = " + YEAR.ToString() + ",MONTH = " + MONTH.ToString() + ",RUNNING = " + RUNNING;
		}

		public class PREFIXComparer : System.Collections.Generic.IComparer<TAJobRunning>
		{
			public SorterMode SorterMode;
			public PREFIXComparer()
			{ }
			public PREFIXComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAJobRunning> Membres
			int System.Collections.Generic.IComparer<TAJobRunning>.Compare(TAJobRunning x, TAJobRunning y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PREFIX.CompareTo(x.PREFIX);
				}
				else
				{
					return x.PREFIX.CompareTo(y.PREFIX);
				}
			}
			#endregion
		}
		public class YEARComparer : System.Collections.Generic.IComparer<TAJobRunning>
		{
			public SorterMode SorterMode;
			public YEARComparer()
			{ }
			public YEARComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAJobRunning> Membres
			int System.Collections.Generic.IComparer<TAJobRunning>.Compare(TAJobRunning x, TAJobRunning y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.YEAR.CompareTo(x.YEAR);
				}
				else
				{
					return x.YEAR.CompareTo(y.YEAR);
				}
			}
			#endregion
		}
		public class MONTHComparer : System.Collections.Generic.IComparer<TAJobRunning>
		{
			public SorterMode SorterMode;
			public MONTHComparer()
			{ }
			public MONTHComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAJobRunning> Membres
			int System.Collections.Generic.IComparer<TAJobRunning>.Compare(TAJobRunning x, TAJobRunning y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.MONTH.CompareTo(x.MONTH);
				}
				else
				{
					return x.MONTH.CompareTo(y.MONTH);
				}
			}
			#endregion
		}
		public class RUNNINGComparer : System.Collections.Generic.IComparer<TAJobRunning>
		{
			public SorterMode SorterMode;
			public RUNNINGComparer()
			{ }
			public RUNNINGComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAJobRunning> Membres
			int System.Collections.Generic.IComparer<TAJobRunning>.Compare(TAJobRunning x, TAJobRunning y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.RUNNING.CompareTo(x.RUNNING);
				}
				else
				{
					return x.RUNNING.CompareTo(y.RUNNING);
				}
			}
			#endregion
		}
	}
}
