using System;
using System.Text;

namespace TA.BusinessObjects
{
	[Serializable()]
	public class TATransBeneficiary
	{
		private string _JobNo;

		public string JobNo
		{
			get { return _JobNo; }
			set { _JobNo = value; }
		}

		private int _TravelerID;

		public int TravelerID
		{
			get { return _TravelerID; }
			set { _TravelerID = value; }
		}

		private int _Seq;

		public int Seq
		{
			get { return _Seq; }
			set { _Seq = value; }
		}

		private string _BeneficiaryTitle;

		public string BeneficiaryTitle
		{
			get { return _BeneficiaryTitle; }
			set { _BeneficiaryTitle = value; }
		}

		private string _BeneficiaryName;

		public string BeneficiaryName
		{
			get { return _BeneficiaryName; }
			set { _BeneficiaryName = value; }
		}

		private string _BeneficiarySurName;

		public string BeneficiarySurName
		{
			get { return _BeneficiarySurName; }
			set { _BeneficiarySurName = value; }
		}

		private string _BeneficiaryRelation;

		public string BeneficiaryRelation
		{
			get { return _BeneficiaryRelation; }
			set { _BeneficiaryRelation = value; }
		}

		private string _BeneficiaryRatio;

		public string BeneficiaryRatio
		{
			get { return _BeneficiaryRatio; }
			set { _BeneficiaryRatio = value; }
		}

		private string _BeneficiaryTel;

		public string BeneficiaryTel
		{
			get { return _BeneficiaryTel; }
			set { _BeneficiaryTel = value; }
		}

		public TATransBeneficiary()
		{ }

		public TATransBeneficiary(string JobNo,int TravelerID,int Seq,string BeneficiaryTitle,string BeneficiaryName,string BeneficiarySurName,string BeneficiaryRelation,string BeneficiaryRatio,string BeneficiaryTel)
		{
			this.JobNo = JobNo;
			this.TravelerID = TravelerID;
			this.Seq = Seq;
			this.BeneficiaryTitle = BeneficiaryTitle;
			this.BeneficiaryName = BeneficiaryName;
			this.BeneficiarySurName = BeneficiarySurName;
			this.BeneficiaryRelation = BeneficiaryRelation;
			this.BeneficiaryRatio = BeneficiaryRatio;
			this.BeneficiaryTel = BeneficiaryTel;
		}

		public override string ToString()
		{
			return "JobNo = " + JobNo + ",TravelerID = " + TravelerID.ToString() + ",Seq = " + Seq.ToString() + ",BeneficiaryTitle = " + BeneficiaryTitle + ",BeneficiaryName = " + BeneficiaryName + ",BeneficiarySurName = " + BeneficiarySurName + ",BeneficiaryRelation = " + BeneficiaryRelation + ",BeneficiaryRatio = " + BeneficiaryRatio + ",BeneficiaryTel = " + BeneficiaryTel;
		}

		public class JobNoComparer : System.Collections.Generic.IComparer<TATransBeneficiary>
		{
			public SorterMode SorterMode;
			public JobNoComparer()
			{ }
			public JobNoComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransBeneficiary> Membres
			int System.Collections.Generic.IComparer<TATransBeneficiary>.Compare(TATransBeneficiary x, TATransBeneficiary y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.JobNo.CompareTo(x.JobNo);
				}
				else
				{
					return x.JobNo.CompareTo(y.JobNo);
				}
			}
			#endregion
		}
		public class TravelerIDComparer : System.Collections.Generic.IComparer<TATransBeneficiary>
		{
			public SorterMode SorterMode;
			public TravelerIDComparer()
			{ }
			public TravelerIDComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransBeneficiary> Membres
			int System.Collections.Generic.IComparer<TATransBeneficiary>.Compare(TATransBeneficiary x, TATransBeneficiary y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.TravelerID.CompareTo(x.TravelerID);
				}
				else
				{
					return x.TravelerID.CompareTo(y.TravelerID);
				}
			}
			#endregion
		}
		public class SeqComparer : System.Collections.Generic.IComparer<TATransBeneficiary>
		{
			public SorterMode SorterMode;
			public SeqComparer()
			{ }
			public SeqComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransBeneficiary> Membres
			int System.Collections.Generic.IComparer<TATransBeneficiary>.Compare(TATransBeneficiary x, TATransBeneficiary y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.Seq.CompareTo(x.Seq);
				}
				else
				{
					return x.Seq.CompareTo(y.Seq);
				}
			}
			#endregion
		}
		public class BeneficiaryTitleComparer : System.Collections.Generic.IComparer<TATransBeneficiary>
		{
			public SorterMode SorterMode;
			public BeneficiaryTitleComparer()
			{ }
			public BeneficiaryTitleComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransBeneficiary> Membres
			int System.Collections.Generic.IComparer<TATransBeneficiary>.Compare(TATransBeneficiary x, TATransBeneficiary y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.BeneficiaryTitle.CompareTo(x.BeneficiaryTitle);
				}
				else
				{
					return x.BeneficiaryTitle.CompareTo(y.BeneficiaryTitle);
				}
			}
			#endregion
		}
		public class BeneficiaryNameComparer : System.Collections.Generic.IComparer<TATransBeneficiary>
		{
			public SorterMode SorterMode;
			public BeneficiaryNameComparer()
			{ }
			public BeneficiaryNameComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransBeneficiary> Membres
			int System.Collections.Generic.IComparer<TATransBeneficiary>.Compare(TATransBeneficiary x, TATransBeneficiary y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.BeneficiaryName.CompareTo(x.BeneficiaryName);
				}
				else
				{
					return x.BeneficiaryName.CompareTo(y.BeneficiaryName);
				}
			}
			#endregion
		}
		public class BeneficiarySurNameComparer : System.Collections.Generic.IComparer<TATransBeneficiary>
		{
			public SorterMode SorterMode;
			public BeneficiarySurNameComparer()
			{ }
			public BeneficiarySurNameComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransBeneficiary> Membres
			int System.Collections.Generic.IComparer<TATransBeneficiary>.Compare(TATransBeneficiary x, TATransBeneficiary y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.BeneficiarySurName.CompareTo(x.BeneficiarySurName);
				}
				else
				{
					return x.BeneficiarySurName.CompareTo(y.BeneficiarySurName);
				}
			}
			#endregion
		}
		public class BeneficiaryRelationComparer : System.Collections.Generic.IComparer<TATransBeneficiary>
		{
			public SorterMode SorterMode;
			public BeneficiaryRelationComparer()
			{ }
			public BeneficiaryRelationComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransBeneficiary> Membres
			int System.Collections.Generic.IComparer<TATransBeneficiary>.Compare(TATransBeneficiary x, TATransBeneficiary y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.BeneficiaryRelation.CompareTo(x.BeneficiaryRelation);
				}
				else
				{
					return x.BeneficiaryRelation.CompareTo(y.BeneficiaryRelation);
				}
			}
			#endregion
		}
		public class BeneficiaryRatioComparer : System.Collections.Generic.IComparer<TATransBeneficiary>
		{
			public SorterMode SorterMode;
			public BeneficiaryRatioComparer()
			{ }
			public BeneficiaryRatioComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransBeneficiary> Membres
			int System.Collections.Generic.IComparer<TATransBeneficiary>.Compare(TATransBeneficiary x, TATransBeneficiary y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.BeneficiaryRatio.CompareTo(x.BeneficiaryRatio);
				}
				else
				{
					return x.BeneficiaryRatio.CompareTo(y.BeneficiaryRatio);
				}
			}
			#endregion
		}
		public class BeneficiaryTelComparer : System.Collections.Generic.IComparer<TATransBeneficiary>
		{
			public SorterMode SorterMode;
			public BeneficiaryTelComparer()
			{ }
			public BeneficiaryTelComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransBeneficiary> Membres
			int System.Collections.Generic.IComparer<TATransBeneficiary>.Compare(TATransBeneficiary x, TATransBeneficiary y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.BeneficiaryTel.CompareTo(x.BeneficiaryTel);
				}
				else
				{
					return x.BeneficiaryTel.CompareTo(y.BeneficiaryTel);
				}
			}
			#endregion
		}
	}
}
