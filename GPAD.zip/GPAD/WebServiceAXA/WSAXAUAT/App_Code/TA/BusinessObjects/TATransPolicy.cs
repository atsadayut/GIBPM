using System;
using System.Text;

namespace TA.BusinessObjects
{
	[Serializable()]
	public class TATransPolicy
	{
		private string _JobNo;

		public string JobNo
		{
			get { return _JobNo; }
			set { _JobNo = value; }
		}

		private string _PolicyNo;

		public string PolicyNo
		{
			get { return _PolicyNo; }
			set { _PolicyNo = value; }
		}

		private string _TravelPlan;

		public string TravelPlan
		{
			get { return _TravelPlan; }
			set { _TravelPlan = value; }
		}

		private string _PolicyType;

		public string PolicyType
		{
			get { return _PolicyType; }
			set { _PolicyType = value; }
		}

		private Nullable<int> _NumbersOfChildren;

		public Nullable<int> NumbersOfChildren
		{
			get { return _NumbersOfChildren; }
			set { _NumbersOfChildren = value; }
		}

		private string _InsurancePlan;

		public string InsurancePlan
		{
			get { return _InsurancePlan; }
			set { _InsurancePlan = value; }
		}

		private string _EffectiveDateFrom;

		public string EffectiveDateFrom
		{
			get { return _EffectiveDateFrom; }
			set { _EffectiveDateFrom = value; }
		}

		private string _EffectiveDateTo;

		public string EffectiveDateTo
		{
			get { return _EffectiveDateTo; }
			set { _EffectiveDateTo = value; }
		}

		private string _CountryOfDestination;

		public string CountryOfDestination
		{
			get { return _CountryOfDestination; }
			set { _CountryOfDestination = value; }
		}

		private string _PlanCode;

		public string PlanCode
		{
			get { return _PlanCode; }
			set { _PlanCode = value; }
		}

		private string _ContractType;

		public string ContractType
		{
			get { return _ContractType; }
			set { _ContractType = value; }
		}

		private string _AgentCode;

		public string AgentCode
		{
			get { return _AgentCode; }
			set { _AgentCode = value; }
		}

		private string _StaffCode;

		public string StaffCode
		{
			get { return _StaffCode; }
			set { _StaffCode = value; }
		}

		private string _BranchCode;

		public string BranchCode
		{
			get { return _BranchCode; }
			set { _BranchCode = value; }
		}

		private string _TemplateCode;

		public string TemplateCode
		{
			get { return _TemplateCode; }
			set { _TemplateCode = value; }
		}

		private string _OccupatnCode;

		public string OccupatnCode
		{
			get { return _OccupatnCode; }
			set { _OccupatnCode = value; }
		}

		private Nullable<Decimal> _NetPremium;

		public Nullable<Decimal> NetPremium
		{
			get { return _NetPremium; }
			set { _NetPremium = value; }
		}

		private Nullable<int> _Stamp;

		public Nullable<int> Stamp
		{
			get { return _Stamp; }
			set { _Stamp = value; }
		}

		private Nullable<Decimal> _SBT;

		public Nullable<Decimal> SBT
		{
			get { return _SBT; }
			set { _SBT = value; }
		}

		private Nullable<Decimal> _TotalPremium;

		public Nullable<Decimal> TotalPremium
		{
			get { return _TotalPremium; }
			set { _TotalPremium = value; }
		}

		private Nullable<SByte> _isLongName;

		public Nullable<SByte> isLongName
		{
			get { return _isLongName; }
			set { _isLongName = value; }
		}

		private Nullable<SByte> _isBeneficiary;

		public Nullable<SByte> isBeneficiary
		{
			get { return _isBeneficiary; }
			set { _isBeneficiary = value; }
		}

		private Nullable<DateTime> _CreateDate;

		public Nullable<DateTime> CreateDate
		{
			get { return _CreateDate; }
			set { _CreateDate = value; }
		}

		private string _CreateUser;

		public string CreateUser
		{
			get { return _CreateUser; }
			set { _CreateUser = value; }
		}

		private string _GroupBrokerId;

		public string GroupBrokerId
		{
			get { return _GroupBrokerId; }
			set { _GroupBrokerId = value; }
		}

		public TATransPolicy()
		{ }

		public TATransPolicy(string JobNo,string PolicyNo,string TravelPlan,string PolicyType,Nullable<int> NumbersOfChildren,string InsurancePlan,string EffectiveDateFrom,string EffectiveDateTo,string CountryOfDestination,string PlanCode,string ContractType,string AgentCode,string StaffCode,string BranchCode,string TemplateCode,string OccupatnCode,Nullable<Decimal> NetPremium,Nullable<int> Stamp,Nullable<Decimal> SBT,Nullable<Decimal> TotalPremium,Nullable<SByte> isLongName,Nullable<SByte> isBeneficiary,Nullable<DateTime> CreateDate,string CreateUser,string GroupBrokerId)
		{
			this.JobNo = JobNo;
			this.PolicyNo = PolicyNo;
			this.TravelPlan = TravelPlan;
			this.PolicyType = PolicyType;
			this.NumbersOfChildren = NumbersOfChildren;
			this.InsurancePlan = InsurancePlan;
			this.EffectiveDateFrom = EffectiveDateFrom;
			this.EffectiveDateTo = EffectiveDateTo;
			this.CountryOfDestination = CountryOfDestination;
			this.PlanCode = PlanCode;
			this.ContractType = ContractType;
			this.AgentCode = AgentCode;
			this.StaffCode = StaffCode;
			this.BranchCode = BranchCode;
			this.TemplateCode = TemplateCode;
			this.OccupatnCode = OccupatnCode;
			this.NetPremium = NetPremium;
			this.Stamp = Stamp;
			this.SBT = SBT;
			this.TotalPremium = TotalPremium;
			this.isLongName = isLongName;
			this.isBeneficiary = isBeneficiary;
			this.CreateDate = CreateDate;
			this.CreateUser = CreateUser;
			this.GroupBrokerId = GroupBrokerId;
		}

		public override string ToString()
		{
			return "JobNo = " + JobNo + ",PolicyNo = " + PolicyNo + ",TravelPlan = " + TravelPlan + ",PolicyType = " + PolicyType + ",NumbersOfChildren = " + NumbersOfChildren.ToString() + ",InsurancePlan = " + InsurancePlan + ",EffectiveDateFrom = " + EffectiveDateFrom + ",EffectiveDateTo = " + EffectiveDateTo + ",CountryOfDestination = " + CountryOfDestination + ",PlanCode = " + PlanCode + ",ContractType = " + ContractType + ",AgentCode = " + AgentCode + ",StaffCode = " + StaffCode + ",BranchCode = " + BranchCode + ",TemplateCode = " + TemplateCode + ",OccupatnCode = " + OccupatnCode + ",NetPremium = " + NetPremium.ToString() + ",Stamp = " + Stamp.ToString() + ",SBT = " + SBT.ToString() + ",TotalPremium = " + TotalPremium.ToString() + ",isLongName = " + isLongName.ToString() + ",isBeneficiary = " + isBeneficiary.ToString() + ",CreateDate = " + CreateDate.ToString() + ",CreateUser = " + CreateUser + ",GroupBrokerId = " + GroupBrokerId;
		}

		public class JobNoComparer : System.Collections.Generic.IComparer<TATransPolicy>
		{
			public SorterMode SorterMode;
			public JobNoComparer()
			{ }
			public JobNoComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransPolicy> Membres
			int System.Collections.Generic.IComparer<TATransPolicy>.Compare(TATransPolicy x, TATransPolicy y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.JobNo.CompareTo(x.JobNo);
				}
				else
				{
					return x.JobNo.CompareTo(y.JobNo);
				}
			}
			#endregion
		}
		public class PolicyNoComparer : System.Collections.Generic.IComparer<TATransPolicy>
		{
			public SorterMode SorterMode;
			public PolicyNoComparer()
			{ }
			public PolicyNoComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransPolicy> Membres
			int System.Collections.Generic.IComparer<TATransPolicy>.Compare(TATransPolicy x, TATransPolicy y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PolicyNo.CompareTo(x.PolicyNo);
				}
				else
				{
					return x.PolicyNo.CompareTo(y.PolicyNo);
				}
			}
			#endregion
		}
		public class TravelPlanComparer : System.Collections.Generic.IComparer<TATransPolicy>
		{
			public SorterMode SorterMode;
			public TravelPlanComparer()
			{ }
			public TravelPlanComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransPolicy> Membres
			int System.Collections.Generic.IComparer<TATransPolicy>.Compare(TATransPolicy x, TATransPolicy y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.TravelPlan.CompareTo(x.TravelPlan);
				}
				else
				{
					return x.TravelPlan.CompareTo(y.TravelPlan);
				}
			}
			#endregion
		}
		public class PolicyTypeComparer : System.Collections.Generic.IComparer<TATransPolicy>
		{
			public SorterMode SorterMode;
			public PolicyTypeComparer()
			{ }
			public PolicyTypeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransPolicy> Membres
			int System.Collections.Generic.IComparer<TATransPolicy>.Compare(TATransPolicy x, TATransPolicy y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PolicyType.CompareTo(x.PolicyType);
				}
				else
				{
					return x.PolicyType.CompareTo(y.PolicyType);
				}
			}
			#endregion
		}
		public class InsurancePlanComparer : System.Collections.Generic.IComparer<TATransPolicy>
		{
			public SorterMode SorterMode;
			public InsurancePlanComparer()
			{ }
			public InsurancePlanComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransPolicy> Membres
			int System.Collections.Generic.IComparer<TATransPolicy>.Compare(TATransPolicy x, TATransPolicy y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.InsurancePlan.CompareTo(x.InsurancePlan);
				}
				else
				{
					return x.InsurancePlan.CompareTo(y.InsurancePlan);
				}
			}
			#endregion
		}
		public class EffectiveDateFromComparer : System.Collections.Generic.IComparer<TATransPolicy>
		{
			public SorterMode SorterMode;
			public EffectiveDateFromComparer()
			{ }
			public EffectiveDateFromComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransPolicy> Membres
			int System.Collections.Generic.IComparer<TATransPolicy>.Compare(TATransPolicy x, TATransPolicy y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.EffectiveDateFrom.CompareTo(x.EffectiveDateFrom);
				}
				else
				{
					return x.EffectiveDateFrom.CompareTo(y.EffectiveDateFrom);
				}
			}
			#endregion
		}
		public class EffectiveDateToComparer : System.Collections.Generic.IComparer<TATransPolicy>
		{
			public SorterMode SorterMode;
			public EffectiveDateToComparer()
			{ }
			public EffectiveDateToComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransPolicy> Membres
			int System.Collections.Generic.IComparer<TATransPolicy>.Compare(TATransPolicy x, TATransPolicy y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.EffectiveDateTo.CompareTo(x.EffectiveDateTo);
				}
				else
				{
					return x.EffectiveDateTo.CompareTo(y.EffectiveDateTo);
				}
			}
			#endregion
		}
		public class CountryOfDestinationComparer : System.Collections.Generic.IComparer<TATransPolicy>
		{
			public SorterMode SorterMode;
			public CountryOfDestinationComparer()
			{ }
			public CountryOfDestinationComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransPolicy> Membres
			int System.Collections.Generic.IComparer<TATransPolicy>.Compare(TATransPolicy x, TATransPolicy y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CountryOfDestination.CompareTo(x.CountryOfDestination);
				}
				else
				{
					return x.CountryOfDestination.CompareTo(y.CountryOfDestination);
				}
			}
			#endregion
		}
		public class PlanCodeComparer : System.Collections.Generic.IComparer<TATransPolicy>
		{
			public SorterMode SorterMode;
			public PlanCodeComparer()
			{ }
			public PlanCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransPolicy> Membres
			int System.Collections.Generic.IComparer<TATransPolicy>.Compare(TATransPolicy x, TATransPolicy y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PlanCode.CompareTo(x.PlanCode);
				}
				else
				{
					return x.PlanCode.CompareTo(y.PlanCode);
				}
			}
			#endregion
		}
		public class ContractTypeComparer : System.Collections.Generic.IComparer<TATransPolicy>
		{
			public SorterMode SorterMode;
			public ContractTypeComparer()
			{ }
			public ContractTypeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransPolicy> Membres
			int System.Collections.Generic.IComparer<TATransPolicy>.Compare(TATransPolicy x, TATransPolicy y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ContractType.CompareTo(x.ContractType);
				}
				else
				{
					return x.ContractType.CompareTo(y.ContractType);
				}
			}
			#endregion
		}
		public class AgentCodeComparer : System.Collections.Generic.IComparer<TATransPolicy>
		{
			public SorterMode SorterMode;
			public AgentCodeComparer()
			{ }
			public AgentCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransPolicy> Membres
			int System.Collections.Generic.IComparer<TATransPolicy>.Compare(TATransPolicy x, TATransPolicy y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.AgentCode.CompareTo(x.AgentCode);
				}
				else
				{
					return x.AgentCode.CompareTo(y.AgentCode);
				}
			}
			#endregion
		}
		public class StaffCodeComparer : System.Collections.Generic.IComparer<TATransPolicy>
		{
			public SorterMode SorterMode;
			public StaffCodeComparer()
			{ }
			public StaffCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransPolicy> Membres
			int System.Collections.Generic.IComparer<TATransPolicy>.Compare(TATransPolicy x, TATransPolicy y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.StaffCode.CompareTo(x.StaffCode);
				}
				else
				{
					return x.StaffCode.CompareTo(y.StaffCode);
				}
			}
			#endregion
		}
		public class BranchCodeComparer : System.Collections.Generic.IComparer<TATransPolicy>
		{
			public SorterMode SorterMode;
			public BranchCodeComparer()
			{ }
			public BranchCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransPolicy> Membres
			int System.Collections.Generic.IComparer<TATransPolicy>.Compare(TATransPolicy x, TATransPolicy y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.BranchCode.CompareTo(x.BranchCode);
				}
				else
				{
					return x.BranchCode.CompareTo(y.BranchCode);
				}
			}
			#endregion
		}
		public class TemplateCodeComparer : System.Collections.Generic.IComparer<TATransPolicy>
		{
			public SorterMode SorterMode;
			public TemplateCodeComparer()
			{ }
			public TemplateCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransPolicy> Membres
			int System.Collections.Generic.IComparer<TATransPolicy>.Compare(TATransPolicy x, TATransPolicy y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.TemplateCode.CompareTo(x.TemplateCode);
				}
				else
				{
					return x.TemplateCode.CompareTo(y.TemplateCode);
				}
			}
			#endregion
		}
		public class OccupatnCodeComparer : System.Collections.Generic.IComparer<TATransPolicy>
		{
			public SorterMode SorterMode;
			public OccupatnCodeComparer()
			{ }
			public OccupatnCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransPolicy> Membres
			int System.Collections.Generic.IComparer<TATransPolicy>.Compare(TATransPolicy x, TATransPolicy y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.OccupatnCode.CompareTo(x.OccupatnCode);
				}
				else
				{
					return x.OccupatnCode.CompareTo(y.OccupatnCode);
				}
			}
			#endregion
		}
		public class CreateUserComparer : System.Collections.Generic.IComparer<TATransPolicy>
		{
			public SorterMode SorterMode;
			public CreateUserComparer()
			{ }
			public CreateUserComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransPolicy> Membres
			int System.Collections.Generic.IComparer<TATransPolicy>.Compare(TATransPolicy x, TATransPolicy y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CreateUser.CompareTo(x.CreateUser);
				}
				else
				{
					return x.CreateUser.CompareTo(y.CreateUser);
				}
			}
			#endregion
		}
		public class GroupBrokerIdComparer : System.Collections.Generic.IComparer<TATransPolicy>
		{
			public SorterMode SorterMode;
			public GroupBrokerIdComparer()
			{ }
			public GroupBrokerIdComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATransPolicy> Membres
			int System.Collections.Generic.IComparer<TATransPolicy>.Compare(TATransPolicy x, TATransPolicy y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.GroupBrokerId.CompareTo(x.GroupBrokerId);
				}
				else
				{
					return x.GroupBrokerId.CompareTo(y.GroupBrokerId);
				}
			}
			#endregion
		}
	}
}
