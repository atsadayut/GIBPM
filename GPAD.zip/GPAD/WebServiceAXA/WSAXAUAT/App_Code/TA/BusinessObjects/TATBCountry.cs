using System;
using System.Text;

namespace TA.BusinessObjects
{
	[Serializable()]
	public class TATBCountry
	{
		private string _CountryCode;

		public string CountryCode
		{
			get { return _CountryCode; }
			set { _CountryCode = value; }
		}

		private string _CountryName;

		public string CountryName
		{
			get { return _CountryName; }
			set { _CountryName = value; }
		}

		private Nullable<SByte> _isEnable;

		public Nullable<SByte> isEnable
		{
			get { return _isEnable; }
			set { _isEnable = value; }
		}

		private Nullable<DateTime> _CreateDate;

		public Nullable<DateTime> CreateDate
		{
			get { return _CreateDate; }
			set { _CreateDate = value; }
		}

		public TATBCountry()
		{ }

		public TATBCountry(string CountryCode,string CountryName,Nullable<SByte> isEnable,Nullable<DateTime> CreateDate)
		{
			this.CountryCode = CountryCode;
			this.CountryName = CountryName;
			this.isEnable = isEnable;
			this.CreateDate = CreateDate;
		}

		public override string ToString()
		{
			return "CountryCode = " + CountryCode + ",CountryName = " + CountryName + ",isEnable = " + isEnable.ToString() + ",CreateDate = " + CreateDate.ToString();
		}

		public class CountryCodeComparer : System.Collections.Generic.IComparer<TATBCountry>
		{
			public SorterMode SorterMode;
			public CountryCodeComparer()
			{ }
			public CountryCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATBCountry> Membres
			int System.Collections.Generic.IComparer<TATBCountry>.Compare(TATBCountry x, TATBCountry y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CountryCode.CompareTo(x.CountryCode);
				}
				else
				{
					return x.CountryCode.CompareTo(y.CountryCode);
				}
			}
			#endregion
		}
		public class CountryNameComparer : System.Collections.Generic.IComparer<TATBCountry>
		{
			public SorterMode SorterMode;
			public CountryNameComparer()
			{ }
			public CountryNameComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATBCountry> Membres
			int System.Collections.Generic.IComparer<TATBCountry>.Compare(TATBCountry x, TATBCountry y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CountryName.CompareTo(x.CountryName);
				}
				else
				{
					return x.CountryName.CompareTo(y.CountryName);
				}
			}
			#endregion
		}
	}
}
