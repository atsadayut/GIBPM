using System;
using System.Text;

namespace TA.BusinessObjects
{
	[Serializable()]
	public class TAB2CGroupRunning
	{
		private string _PREFIX;

		public string PREFIX
		{
			get { return _PREFIX; }
			set { _PREFIX = value; }
		}

		private int _YEAR;

		public int YEAR
		{
			get { return _YEAR; }
			set { _YEAR = value; }
		}

		private int _MONTH;

		public int MONTH
		{
			get { return _MONTH; }
			set { _MONTH = value; }
		}

		private int _GROUPID;

		public int GROUPID
		{
			get { return _GROUPID; }
			set { _GROUPID = value; }
		}

		private Nullable<DateTime> _CreatedDate;

		public Nullable<DateTime> CreatedDate
		{
			get { return _CreatedDate; }
			set { _CreatedDate = value; }
		}

		public TAB2CGroupRunning()
		{ }

		public TAB2CGroupRunning(string PREFIX,int YEAR,int MONTH,int GROUPID,Nullable<DateTime> CreatedDate)
		{
			this.PREFIX = PREFIX;
			this.YEAR = YEAR;
			this.MONTH = MONTH;
			this.GROUPID = GROUPID;
			this.CreatedDate = CreatedDate;
		}

		public override string ToString()
		{
			return "PREFIX = " + PREFIX + ",YEAR = " + YEAR.ToString() + ",MONTH = " + MONTH.ToString() + ",GROUPID = " + GROUPID.ToString() + ",CreatedDate = " + CreatedDate.ToString();
		}

		public class PREFIXComparer : System.Collections.Generic.IComparer<TAB2CGroupRunning>
		{
			public SorterMode SorterMode;
			public PREFIXComparer()
			{ }
			public PREFIXComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CGroupRunning> Membres
			int System.Collections.Generic.IComparer<TAB2CGroupRunning>.Compare(TAB2CGroupRunning x, TAB2CGroupRunning y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PREFIX.CompareTo(x.PREFIX);
				}
				else
				{
					return x.PREFIX.CompareTo(y.PREFIX);
				}
			}
			#endregion
		}
		public class YEARComparer : System.Collections.Generic.IComparer<TAB2CGroupRunning>
		{
			public SorterMode SorterMode;
			public YEARComparer()
			{ }
			public YEARComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CGroupRunning> Membres
			int System.Collections.Generic.IComparer<TAB2CGroupRunning>.Compare(TAB2CGroupRunning x, TAB2CGroupRunning y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.YEAR.CompareTo(x.YEAR);
				}
				else
				{
					return x.YEAR.CompareTo(y.YEAR);
				}
			}
			#endregion
		}
		public class MONTHComparer : System.Collections.Generic.IComparer<TAB2CGroupRunning>
		{
			public SorterMode SorterMode;
			public MONTHComparer()
			{ }
			public MONTHComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CGroupRunning> Membres
			int System.Collections.Generic.IComparer<TAB2CGroupRunning>.Compare(TAB2CGroupRunning x, TAB2CGroupRunning y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.MONTH.CompareTo(x.MONTH);
				}
				else
				{
					return x.MONTH.CompareTo(y.MONTH);
				}
			}
			#endregion
		}
		public class GROUPIDComparer : System.Collections.Generic.IComparer<TAB2CGroupRunning>
		{
			public SorterMode SorterMode;
			public GROUPIDComparer()
			{ }
			public GROUPIDComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CGroupRunning> Membres
			int System.Collections.Generic.IComparer<TAB2CGroupRunning>.Compare(TAB2CGroupRunning x, TAB2CGroupRunning y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.GROUPID.CompareTo(x.GROUPID);
				}
				else
				{
					return x.GROUPID.CompareTo(y.GROUPID);
				}
			}
			#endregion
		}
	}
}
