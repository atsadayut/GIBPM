using System;
using System.Text;

namespace TA.BusinessObjects
{
	[Serializable()]
	public class TATBTitle
	{
		private string _TitleName;

		public string TitleName
		{
			get { return _TitleName; }
			set { _TitleName = value; }
		}

		private string _SEX;

		public string SEX
		{
			get { return _SEX; }
			set { _SEX = value; }
		}

		private Nullable<SByte> _isEnable;

		public Nullable<SByte> isEnable
		{
			get { return _isEnable; }
			set { _isEnable = value; }
		}

		private Nullable<DateTime> _CreateDate;

		public Nullable<DateTime> CreateDate
		{
			get { return _CreateDate; }
			set { _CreateDate = value; }
		}

		public TATBTitle()
		{ }

		public TATBTitle(string TitleName,string SEX,Nullable<SByte> isEnable,Nullable<DateTime> CreateDate)
		{
			this.TitleName = TitleName;
			this.SEX = SEX;
			this.isEnable = isEnable;
			this.CreateDate = CreateDate;
		}

		public override string ToString()
		{
			return "TitleName = " + TitleName + ",SEX = " + SEX + ",isEnable = " + isEnable.ToString() + ",CreateDate = " + CreateDate.ToString();
		}

		public class TitleNameComparer : System.Collections.Generic.IComparer<TATBTitle>
		{
			public SorterMode SorterMode;
			public TitleNameComparer()
			{ }
			public TitleNameComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATBTitle> Membres
			int System.Collections.Generic.IComparer<TATBTitle>.Compare(TATBTitle x, TATBTitle y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.TitleName.CompareTo(x.TitleName);
				}
				else
				{
					return x.TitleName.CompareTo(y.TitleName);
				}
			}
			#endregion
		}
		public class SEXComparer : System.Collections.Generic.IComparer<TATBTitle>
		{
			public SorterMode SorterMode;
			public SEXComparer()
			{ }
			public SEXComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATBTitle> Membres
			int System.Collections.Generic.IComparer<TATBTitle>.Compare(TATBTitle x, TATBTitle y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.SEX.CompareTo(x.SEX);
				}
				else
				{
					return x.SEX.CompareTo(y.SEX);
				}
			}
			#endregion
		}
	}
}
