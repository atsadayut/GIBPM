using System;
using System.Text;

namespace TA.BusinessObjects
{
	[Serializable()]
	public class TAB2CDiscount
	{
		private int _ID;

		public int ID
		{
			get { return _ID; }
			set { _ID = value; }
		}

		private string _CodeDiscount;

		public string CodeDiscount
		{
			get { return _CodeDiscount; }
			set { _CodeDiscount = value; }
		}

		private Nullable<int> _Checksum;

		public Nullable<int> Checksum
		{
			get { return _Checksum; }
			set { _Checksum = value; }
		}

		private Nullable<int> _DiscountPresent;

		public Nullable<int> DiscountPresent
		{
			get { return _DiscountPresent; }
			set { _DiscountPresent = value; }
		}

		private Nullable<int> _DiscountAmount;

		public Nullable<int> DiscountAmount
		{
			get { return _DiscountAmount; }
			set { _DiscountAmount = value; }
		}

		private string _ForUserWebID;

		public string ForUserWebID
		{
			get { return _ForUserWebID; }
			set { _ForUserWebID = value; }
		}

		private string _BrokerCode;

		public string BrokerCode
		{
			get { return _BrokerCode; }
			set { _BrokerCode = value; }
		}

		private string _GroupBrokerId;

		public string GroupBrokerId
		{
			get { return _GroupBrokerId; }
			set { _GroupBrokerId = value; }
		}

		private string _GeneratedUse;

		public string GeneratedUse
		{
			get { return _GeneratedUse; }
			set { _GeneratedUse = value; }
		}

		private Nullable<DateTime> _GeneratedDate;

		public Nullable<DateTime> GeneratedDate
		{
			get { return _GeneratedDate; }
			set { _GeneratedDate = value; }
		}

		private string _JobNo;

		public string JobNo
		{
			get { return _JobNo; }
			set { _JobNo = value; }
		}

		private string _UsedUserID;

		public string UsedUserID
		{
			get { return _UsedUserID; }
			set { _UsedUserID = value; }
		}

		private Nullable<DateTime> _UsedDate;

		public Nullable<DateTime> UsedDate
		{
			get { return _UsedDate; }
			set { _UsedDate = value; }
		}

		private Nullable<SByte> _UsedFlag;

		public Nullable<SByte> UsedFlag
		{
			get { return _UsedFlag; }
			set { _UsedFlag = value; }
		}

		public TAB2CDiscount()
		{ }

		public TAB2CDiscount(int ID,string CodeDiscount,Nullable<int> Checksum,Nullable<int> DiscountPresent,Nullable<int> DiscountAmount,string ForUserWebID,string BrokerCode,string GroupBrokerId,string GeneratedUse,Nullable<DateTime> GeneratedDate,string JobNo,string UsedUserID,Nullable<DateTime> UsedDate,Nullable<SByte> UsedFlag)
		{
			this.ID = ID;
			this.CodeDiscount = CodeDiscount;
			this.Checksum = Checksum;
			this.DiscountPresent = DiscountPresent;
			this.DiscountAmount = DiscountAmount;
			this.ForUserWebID = ForUserWebID;
			this.BrokerCode = BrokerCode;
			this.GroupBrokerId = GroupBrokerId;
			this.GeneratedUse = GeneratedUse;
			this.GeneratedDate = GeneratedDate;
			this.JobNo = JobNo;
			this.UsedUserID = UsedUserID;
			this.UsedDate = UsedDate;
			this.UsedFlag = UsedFlag;
		}

		public override string ToString()
		{
			return "ID = " + ID.ToString() + ",CodeDiscount = " + CodeDiscount + ",Checksum = " + Checksum.ToString() + ",DiscountPresent = " + DiscountPresent.ToString() + ",DiscountAmount = " + DiscountAmount.ToString() + ",ForUserWebID = " + ForUserWebID + ",BrokerCode = " + BrokerCode + ",GroupBrokerId = " + GroupBrokerId + ",GeneratedUse = " + GeneratedUse + ",GeneratedDate = " + GeneratedDate.ToString() + ",JobNo = " + JobNo + ",UsedUserID = " + UsedUserID + ",UsedDate = " + UsedDate.ToString() + ",UsedFlag = " + UsedFlag.ToString();
		}

		public class IDComparer : System.Collections.Generic.IComparer<TAB2CDiscount>
		{
			public SorterMode SorterMode;
			public IDComparer()
			{ }
			public IDComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CDiscount> Membres
			int System.Collections.Generic.IComparer<TAB2CDiscount>.Compare(TAB2CDiscount x, TAB2CDiscount y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ID.CompareTo(x.ID);
				}
				else
				{
					return x.ID.CompareTo(y.ID);
				}
			}
			#endregion
		}
		public class CodeDiscountComparer : System.Collections.Generic.IComparer<TAB2CDiscount>
		{
			public SorterMode SorterMode;
			public CodeDiscountComparer()
			{ }
			public CodeDiscountComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CDiscount> Membres
			int System.Collections.Generic.IComparer<TAB2CDiscount>.Compare(TAB2CDiscount x, TAB2CDiscount y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CodeDiscount.CompareTo(x.CodeDiscount);
				}
				else
				{
					return x.CodeDiscount.CompareTo(y.CodeDiscount);
				}
			}
			#endregion
		}
		public class ForUserWebIDComparer : System.Collections.Generic.IComparer<TAB2CDiscount>
		{
			public SorterMode SorterMode;
			public ForUserWebIDComparer()
			{ }
			public ForUserWebIDComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CDiscount> Membres
			int System.Collections.Generic.IComparer<TAB2CDiscount>.Compare(TAB2CDiscount x, TAB2CDiscount y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ForUserWebID.CompareTo(x.ForUserWebID);
				}
				else
				{
					return x.ForUserWebID.CompareTo(y.ForUserWebID);
				}
			}
			#endregion
		}
		public class BrokerCodeComparer : System.Collections.Generic.IComparer<TAB2CDiscount>
		{
			public SorterMode SorterMode;
			public BrokerCodeComparer()
			{ }
			public BrokerCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CDiscount> Membres
			int System.Collections.Generic.IComparer<TAB2CDiscount>.Compare(TAB2CDiscount x, TAB2CDiscount y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.BrokerCode.CompareTo(x.BrokerCode);
				}
				else
				{
					return x.BrokerCode.CompareTo(y.BrokerCode);
				}
			}
			#endregion
		}
		public class GroupBrokerIdComparer : System.Collections.Generic.IComparer<TAB2CDiscount>
		{
			public SorterMode SorterMode;
			public GroupBrokerIdComparer()
			{ }
			public GroupBrokerIdComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CDiscount> Membres
			int System.Collections.Generic.IComparer<TAB2CDiscount>.Compare(TAB2CDiscount x, TAB2CDiscount y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.GroupBrokerId.CompareTo(x.GroupBrokerId);
				}
				else
				{
					return x.GroupBrokerId.CompareTo(y.GroupBrokerId);
				}
			}
			#endregion
		}
		public class GeneratedUseComparer : System.Collections.Generic.IComparer<TAB2CDiscount>
		{
			public SorterMode SorterMode;
			public GeneratedUseComparer()
			{ }
			public GeneratedUseComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CDiscount> Membres
			int System.Collections.Generic.IComparer<TAB2CDiscount>.Compare(TAB2CDiscount x, TAB2CDiscount y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.GeneratedUse.CompareTo(x.GeneratedUse);
				}
				else
				{
					return x.GeneratedUse.CompareTo(y.GeneratedUse);
				}
			}
			#endregion
		}
		public class JobNoComparer : System.Collections.Generic.IComparer<TAB2CDiscount>
		{
			public SorterMode SorterMode;
			public JobNoComparer()
			{ }
			public JobNoComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CDiscount> Membres
			int System.Collections.Generic.IComparer<TAB2CDiscount>.Compare(TAB2CDiscount x, TAB2CDiscount y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.JobNo.CompareTo(x.JobNo);
				}
				else
				{
					return x.JobNo.CompareTo(y.JobNo);
				}
			}
			#endregion
		}
		public class UsedUserIDComparer : System.Collections.Generic.IComparer<TAB2CDiscount>
		{
			public SorterMode SorterMode;
			public UsedUserIDComparer()
			{ }
			public UsedUserIDComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CDiscount> Membres
			int System.Collections.Generic.IComparer<TAB2CDiscount>.Compare(TAB2CDiscount x, TAB2CDiscount y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.UsedUserID.CompareTo(x.UsedUserID);
				}
				else
				{
					return x.UsedUserID.CompareTo(y.UsedUserID);
				}
			}
			#endregion
		}
	}
}
