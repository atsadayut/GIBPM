using System;
using System.Text;

namespace TA.BusinessObjects
{
	[Serializable()]
	public class TAPlanCampaign
	{
		private string _CampaignCode;

		public string CampaignCode
		{
			get { return _CampaignCode; }
			set { _CampaignCode = value; }
		}

		private string _CampaignName;

		public string CampaignName
		{
			get { return _CampaignName; }
			set { _CampaignName = value; }
		}

		private Nullable<int> _PercentDiscount;

		public Nullable<int> PercentDiscount
		{
			get { return _PercentDiscount; }
			set { _PercentDiscount = value; }
		}

		private Nullable<DateTime> _StartDate;

		public Nullable<DateTime> StartDate
		{
			get { return _StartDate; }
			set { _StartDate = value; }
		}

		private Nullable<DateTime> _EndDate;

		public Nullable<DateTime> EndDate
		{
			get { return _EndDate; }
			set { _EndDate = value; }
		}

		private Nullable<int> _CampaignType;

		public Nullable<int> CampaignType
		{
			get { return _CampaignType; }
			set { _CampaignType = value; }
		}

		private Nullable<SByte> _isEnabel;

		public Nullable<SByte> isEnabel
		{
			get { return _isEnabel; }
			set { _isEnabel = value; }
		}

		private string _CreatedUser;

		public string CreatedUser
		{
			get { return _CreatedUser; }
			set { _CreatedUser = value; }
		}

		private Nullable<DateTime> _CreatedDate;

		public Nullable<DateTime> CreatedDate
		{
			get { return _CreatedDate; }
			set { _CreatedDate = value; }
		}

		public TAPlanCampaign()
		{ }

		public TAPlanCampaign(string CampaignCode,string CampaignName,Nullable<int> PercentDiscount,Nullable<DateTime> StartDate,Nullable<DateTime> EndDate,Nullable<int> CampaignType,Nullable<SByte> isEnabel,string CreatedUser,Nullable<DateTime> CreatedDate)
		{
			this.CampaignCode = CampaignCode;
			this.CampaignName = CampaignName;
			this.PercentDiscount = PercentDiscount;
			this.StartDate = StartDate;
			this.EndDate = EndDate;
			this.CampaignType = CampaignType;
			this.isEnabel = isEnabel;
			this.CreatedUser = CreatedUser;
			this.CreatedDate = CreatedDate;
		}

		public override string ToString()
		{
			return "CampaignCode = " + CampaignCode + ",CampaignName = " + CampaignName + ",PercentDiscount = " + PercentDiscount.ToString() + ",StartDate = " + StartDate.ToString() + ",EndDate = " + EndDate.ToString() + ",CampaignType = " + CampaignType.ToString() + ",isEnabel = " + isEnabel.ToString() + ",CreatedUser = " + CreatedUser + ",CreatedDate = " + CreatedDate.ToString();
		}

		public class CampaignCodeComparer : System.Collections.Generic.IComparer<TAPlanCampaign>
		{
			public SorterMode SorterMode;
			public CampaignCodeComparer()
			{ }
			public CampaignCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanCampaign> Membres
			int System.Collections.Generic.IComparer<TAPlanCampaign>.Compare(TAPlanCampaign x, TAPlanCampaign y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CampaignCode.CompareTo(x.CampaignCode);
				}
				else
				{
					return x.CampaignCode.CompareTo(y.CampaignCode);
				}
			}
			#endregion
		}
		public class CampaignNameComparer : System.Collections.Generic.IComparer<TAPlanCampaign>
		{
			public SorterMode SorterMode;
			public CampaignNameComparer()
			{ }
			public CampaignNameComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanCampaign> Membres
			int System.Collections.Generic.IComparer<TAPlanCampaign>.Compare(TAPlanCampaign x, TAPlanCampaign y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CampaignName.CompareTo(x.CampaignName);
				}
				else
				{
					return x.CampaignName.CompareTo(y.CampaignName);
				}
			}
			#endregion
		}
		public class CreatedUserComparer : System.Collections.Generic.IComparer<TAPlanCampaign>
		{
			public SorterMode SorterMode;
			public CreatedUserComparer()
			{ }
			public CreatedUserComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAPlanCampaign> Membres
			int System.Collections.Generic.IComparer<TAPlanCampaign>.Compare(TAPlanCampaign x, TAPlanCampaign y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CreatedUser.CompareTo(x.CreatedUser);
				}
				else
				{
					return x.CreatedUser.CompareTo(y.CreatedUser);
				}
			}
			#endregion
		}
	}
}
