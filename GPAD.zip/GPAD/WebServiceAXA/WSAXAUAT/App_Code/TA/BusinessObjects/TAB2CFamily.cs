using System;
using System.Text;

namespace TA.BusinessObjects
{
	[Serializable()]
	public class TAB2CFamily
	{
		private string _GroupBrokerId;

		public string GroupBrokerId
		{
			get { return _GroupBrokerId; }
			set { _GroupBrokerId = value; }
		}

		private int _SEQ;

		public int SEQ
		{
			get { return _SEQ; }
			set { _SEQ = value; }
		}

		private string _ClientCode;

		public string ClientCode
		{
			get { return _ClientCode; }
			set { _ClientCode = value; }
		}

		private string _ClientType;

		public string ClientType
		{
			get { return _ClientType; }
			set { _ClientType = value; }
		}

		private string _ClientTitle;

		public string ClientTitle
		{
			get { return _ClientTitle; }
			set { _ClientTitle = value; }
		}

		private string _ClientName;

		public string ClientName
		{
			get { return _ClientName; }
			set { _ClientName = value; }
		}

		private string _ClientSurName;

		public string ClientSurName
		{
			get { return _ClientSurName; }
			set { _ClientSurName = value; }
		}

		private string _ClientAddress1;

		public string ClientAddress1
		{
			get { return _ClientAddress1; }
			set { _ClientAddress1 = value; }
		}

		private string _ClientAddress2;

		public string ClientAddress2
		{
			get { return _ClientAddress2; }
			set { _ClientAddress2 = value; }
		}

		private string _Province;

		public string Province
		{
			get { return _Province; }
			set { _Province = value; }
		}

		private string _Amphur;

		public string Amphur
		{
			get { return _Amphur; }
			set { _Amphur = value; }
		}

		private string _Tumbol;

		public string Tumbol
		{
			get { return _Tumbol; }
			set { _Tumbol = value; }
		}

		private string _PostCode;

		public string PostCode
		{
			get { return _PostCode; }
			set { _PostCode = value; }
		}

		private string _CountryCode;

		public string CountryCode
		{
			get { return _CountryCode; }
			set { _CountryCode = value; }
		}

		private Nullable<DateTime> _Birthday;

		public Nullable<DateTime> Birthday
		{
			get { return _Birthday; }
			set { _Birthday = value; }
		}

		private string _ClientSEX;

		public string ClientSEX
		{
			get { return _ClientSEX; }
			set { _ClientSEX = value; }
		}

		private string _ClientStatus;

		public string ClientStatus
		{
			get { return _ClientStatus; }
			set { _ClientStatus = value; }
		}

		private string _PassportID;

		public string PassportID
		{
			get { return _PassportID; }
			set { _PassportID = value; }
		}

		private string _IDCard;

		public string IDCard
		{
			get { return _IDCard; }
			set { _IDCard = value; }
		}

		private string _TaxID;

		public string TaxID
		{
			get { return _TaxID; }
			set { _TaxID = value; }
		}

		private string _Tel;

		public string Tel
		{
			get { return _Tel; }
			set { _Tel = value; }
		}

		private string _Email;

		public string Email
		{
			get { return _Email; }
			set { _Email = value; }
		}

		private string _Language;

		public string Language
		{
			get { return _Language; }
			set { _Language = value; }
		}

		private Nullable<DateTime> _CreateDate;

		public Nullable<DateTime> CreateDate
		{
			get { return _CreateDate; }
			set { _CreateDate = value; }
		}

		private string _Message;

		public string Message
		{
			get { return _Message; }
			set { _Message = value; }
		}

		public TAB2CFamily()
		{ }

		public TAB2CFamily(string GroupBrokerId,int SEQ,string ClientCode,string ClientType,string ClientTitle,string ClientName,string ClientSurName,string ClientAddress1,string ClientAddress2,string Province,string Amphur,string Tumbol,string PostCode,string CountryCode,Nullable<DateTime> Birthday,string ClientSEX,string ClientStatus,string PassportID,string IDCard,string TaxID,string Tel,string Email,string Language,Nullable<DateTime> CreateDate,string Message)
		{
			this.GroupBrokerId = GroupBrokerId;
			this.SEQ = SEQ;
			this.ClientCode = ClientCode;
			this.ClientType = ClientType;
			this.ClientTitle = ClientTitle;
			this.ClientName = ClientName;
			this.ClientSurName = ClientSurName;
			this.ClientAddress1 = ClientAddress1;
			this.ClientAddress2 = ClientAddress2;
			this.Province = Province;
			this.Amphur = Amphur;
			this.Tumbol = Tumbol;
			this.PostCode = PostCode;
			this.CountryCode = CountryCode;
			this.Birthday = Birthday;
			this.ClientSEX = ClientSEX;
			this.ClientStatus = ClientStatus;
			this.PassportID = PassportID;
			this.IDCard = IDCard;
			this.TaxID = TaxID;
			this.Tel = Tel;
			this.Email = Email;
			this.Language = Language;
			this.CreateDate = CreateDate;
			this.Message = Message;
		}

		public override string ToString()
		{
			return "GroupBrokerId = " + GroupBrokerId + ",SEQ = " + SEQ.ToString() + ",ClientCode = " + ClientCode + ",ClientType = " + ClientType + ",ClientTitle = " + ClientTitle + ",ClientName = " + ClientName + ",ClientSurName = " + ClientSurName + ",ClientAddress1 = " + ClientAddress1 + ",ClientAddress2 = " + ClientAddress2 + ",Province = " + Province + ",Amphur = " + Amphur + ",Tumbol = " + Tumbol + ",PostCode = " + PostCode + ",CountryCode = " + CountryCode + ",Birthday = " + Birthday.ToString() + ",ClientSEX = " + ClientSEX + ",ClientStatus = " + ClientStatus + ",PassportID = " + PassportID + ",IDCard = " + IDCard + ",TaxID = " + TaxID + ",Tel = " + Tel + ",Email = " + Email + ",Language = " + Language + ",CreateDate = " + CreateDate.ToString() + ",Message = " + Message;
		}

		public class GroupBrokerIdComparer : System.Collections.Generic.IComparer<TAB2CFamily>
		{
			public SorterMode SorterMode;
			public GroupBrokerIdComparer()
			{ }
			public GroupBrokerIdComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CFamily> Membres
			int System.Collections.Generic.IComparer<TAB2CFamily>.Compare(TAB2CFamily x, TAB2CFamily y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.GroupBrokerId.CompareTo(x.GroupBrokerId);
				}
				else
				{
					return x.GroupBrokerId.CompareTo(y.GroupBrokerId);
				}
			}
			#endregion
		}
		public class SEQComparer : System.Collections.Generic.IComparer<TAB2CFamily>
		{
			public SorterMode SorterMode;
			public SEQComparer()
			{ }
			public SEQComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CFamily> Membres
			int System.Collections.Generic.IComparer<TAB2CFamily>.Compare(TAB2CFamily x, TAB2CFamily y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.SEQ.CompareTo(x.SEQ);
				}
				else
				{
					return x.SEQ.CompareTo(y.SEQ);
				}
			}
			#endregion
		}
		public class ClientCodeComparer : System.Collections.Generic.IComparer<TAB2CFamily>
		{
			public SorterMode SorterMode;
			public ClientCodeComparer()
			{ }
			public ClientCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CFamily> Membres
			int System.Collections.Generic.IComparer<TAB2CFamily>.Compare(TAB2CFamily x, TAB2CFamily y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ClientCode.CompareTo(x.ClientCode);
				}
				else
				{
					return x.ClientCode.CompareTo(y.ClientCode);
				}
			}
			#endregion
		}
		public class ClientTypeComparer : System.Collections.Generic.IComparer<TAB2CFamily>
		{
			public SorterMode SorterMode;
			public ClientTypeComparer()
			{ }
			public ClientTypeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CFamily> Membres
			int System.Collections.Generic.IComparer<TAB2CFamily>.Compare(TAB2CFamily x, TAB2CFamily y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ClientType.CompareTo(x.ClientType);
				}
				else
				{
					return x.ClientType.CompareTo(y.ClientType);
				}
			}
			#endregion
		}
		public class ClientTitleComparer : System.Collections.Generic.IComparer<TAB2CFamily>
		{
			public SorterMode SorterMode;
			public ClientTitleComparer()
			{ }
			public ClientTitleComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CFamily> Membres
			int System.Collections.Generic.IComparer<TAB2CFamily>.Compare(TAB2CFamily x, TAB2CFamily y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ClientTitle.CompareTo(x.ClientTitle);
				}
				else
				{
					return x.ClientTitle.CompareTo(y.ClientTitle);
				}
			}
			#endregion
		}
		public class ClientNameComparer : System.Collections.Generic.IComparer<TAB2CFamily>
		{
			public SorterMode SorterMode;
			public ClientNameComparer()
			{ }
			public ClientNameComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CFamily> Membres
			int System.Collections.Generic.IComparer<TAB2CFamily>.Compare(TAB2CFamily x, TAB2CFamily y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ClientName.CompareTo(x.ClientName);
				}
				else
				{
					return x.ClientName.CompareTo(y.ClientName);
				}
			}
			#endregion
		}
		public class ClientSurNameComparer : System.Collections.Generic.IComparer<TAB2CFamily>
		{
			public SorterMode SorterMode;
			public ClientSurNameComparer()
			{ }
			public ClientSurNameComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CFamily> Membres
			int System.Collections.Generic.IComparer<TAB2CFamily>.Compare(TAB2CFamily x, TAB2CFamily y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ClientSurName.CompareTo(x.ClientSurName);
				}
				else
				{
					return x.ClientSurName.CompareTo(y.ClientSurName);
				}
			}
			#endregion
		}
		public class ClientAddress1Comparer : System.Collections.Generic.IComparer<TAB2CFamily>
		{
			public SorterMode SorterMode;
			public ClientAddress1Comparer()
			{ }
			public ClientAddress1Comparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CFamily> Membres
			int System.Collections.Generic.IComparer<TAB2CFamily>.Compare(TAB2CFamily x, TAB2CFamily y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ClientAddress1.CompareTo(x.ClientAddress1);
				}
				else
				{
					return x.ClientAddress1.CompareTo(y.ClientAddress1);
				}
			}
			#endregion
		}
		public class ClientAddress2Comparer : System.Collections.Generic.IComparer<TAB2CFamily>
		{
			public SorterMode SorterMode;
			public ClientAddress2Comparer()
			{ }
			public ClientAddress2Comparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CFamily> Membres
			int System.Collections.Generic.IComparer<TAB2CFamily>.Compare(TAB2CFamily x, TAB2CFamily y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ClientAddress2.CompareTo(x.ClientAddress2);
				}
				else
				{
					return x.ClientAddress2.CompareTo(y.ClientAddress2);
				}
			}
			#endregion
		}
		public class ProvinceComparer : System.Collections.Generic.IComparer<TAB2CFamily>
		{
			public SorterMode SorterMode;
			public ProvinceComparer()
			{ }
			public ProvinceComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CFamily> Membres
			int System.Collections.Generic.IComparer<TAB2CFamily>.Compare(TAB2CFamily x, TAB2CFamily y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.Province.CompareTo(x.Province);
				}
				else
				{
					return x.Province.CompareTo(y.Province);
				}
			}
			#endregion
		}
		public class AmphurComparer : System.Collections.Generic.IComparer<TAB2CFamily>
		{
			public SorterMode SorterMode;
			public AmphurComparer()
			{ }
			public AmphurComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CFamily> Membres
			int System.Collections.Generic.IComparer<TAB2CFamily>.Compare(TAB2CFamily x, TAB2CFamily y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.Amphur.CompareTo(x.Amphur);
				}
				else
				{
					return x.Amphur.CompareTo(y.Amphur);
				}
			}
			#endregion
		}
		public class TumbolComparer : System.Collections.Generic.IComparer<TAB2CFamily>
		{
			public SorterMode SorterMode;
			public TumbolComparer()
			{ }
			public TumbolComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CFamily> Membres
			int System.Collections.Generic.IComparer<TAB2CFamily>.Compare(TAB2CFamily x, TAB2CFamily y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.Tumbol.CompareTo(x.Tumbol);
				}
				else
				{
					return x.Tumbol.CompareTo(y.Tumbol);
				}
			}
			#endregion
		}
		public class PostCodeComparer : System.Collections.Generic.IComparer<TAB2CFamily>
		{
			public SorterMode SorterMode;
			public PostCodeComparer()
			{ }
			public PostCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CFamily> Membres
			int System.Collections.Generic.IComparer<TAB2CFamily>.Compare(TAB2CFamily x, TAB2CFamily y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PostCode.CompareTo(x.PostCode);
				}
				else
				{
					return x.PostCode.CompareTo(y.PostCode);
				}
			}
			#endregion
		}
		public class CountryCodeComparer : System.Collections.Generic.IComparer<TAB2CFamily>
		{
			public SorterMode SorterMode;
			public CountryCodeComparer()
			{ }
			public CountryCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CFamily> Membres
			int System.Collections.Generic.IComparer<TAB2CFamily>.Compare(TAB2CFamily x, TAB2CFamily y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CountryCode.CompareTo(x.CountryCode);
				}
				else
				{
					return x.CountryCode.CompareTo(y.CountryCode);
				}
			}
			#endregion
		}
		public class ClientSEXComparer : System.Collections.Generic.IComparer<TAB2CFamily>
		{
			public SorterMode SorterMode;
			public ClientSEXComparer()
			{ }
			public ClientSEXComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CFamily> Membres
			int System.Collections.Generic.IComparer<TAB2CFamily>.Compare(TAB2CFamily x, TAB2CFamily y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ClientSEX.CompareTo(x.ClientSEX);
				}
				else
				{
					return x.ClientSEX.CompareTo(y.ClientSEX);
				}
			}
			#endregion
		}
		public class ClientStatusComparer : System.Collections.Generic.IComparer<TAB2CFamily>
		{
			public SorterMode SorterMode;
			public ClientStatusComparer()
			{ }
			public ClientStatusComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CFamily> Membres
			int System.Collections.Generic.IComparer<TAB2CFamily>.Compare(TAB2CFamily x, TAB2CFamily y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ClientStatus.CompareTo(x.ClientStatus);
				}
				else
				{
					return x.ClientStatus.CompareTo(y.ClientStatus);
				}
			}
			#endregion
		}
		public class PassportIDComparer : System.Collections.Generic.IComparer<TAB2CFamily>
		{
			public SorterMode SorterMode;
			public PassportIDComparer()
			{ }
			public PassportIDComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CFamily> Membres
			int System.Collections.Generic.IComparer<TAB2CFamily>.Compare(TAB2CFamily x, TAB2CFamily y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PassportID.CompareTo(x.PassportID);
				}
				else
				{
					return x.PassportID.CompareTo(y.PassportID);
				}
			}
			#endregion
		}
		public class IDCardComparer : System.Collections.Generic.IComparer<TAB2CFamily>
		{
			public SorterMode SorterMode;
			public IDCardComparer()
			{ }
			public IDCardComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CFamily> Membres
			int System.Collections.Generic.IComparer<TAB2CFamily>.Compare(TAB2CFamily x, TAB2CFamily y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.IDCard.CompareTo(x.IDCard);
				}
				else
				{
					return x.IDCard.CompareTo(y.IDCard);
				}
			}
			#endregion
		}
		public class TaxIDComparer : System.Collections.Generic.IComparer<TAB2CFamily>
		{
			public SorterMode SorterMode;
			public TaxIDComparer()
			{ }
			public TaxIDComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CFamily> Membres
			int System.Collections.Generic.IComparer<TAB2CFamily>.Compare(TAB2CFamily x, TAB2CFamily y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.TaxID.CompareTo(x.TaxID);
				}
				else
				{
					return x.TaxID.CompareTo(y.TaxID);
				}
			}
			#endregion
		}
		public class TelComparer : System.Collections.Generic.IComparer<TAB2CFamily>
		{
			public SorterMode SorterMode;
			public TelComparer()
			{ }
			public TelComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CFamily> Membres
			int System.Collections.Generic.IComparer<TAB2CFamily>.Compare(TAB2CFamily x, TAB2CFamily y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.Tel.CompareTo(x.Tel);
				}
				else
				{
					return x.Tel.CompareTo(y.Tel);
				}
			}
			#endregion
		}
		public class EmailComparer : System.Collections.Generic.IComparer<TAB2CFamily>
		{
			public SorterMode SorterMode;
			public EmailComparer()
			{ }
			public EmailComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CFamily> Membres
			int System.Collections.Generic.IComparer<TAB2CFamily>.Compare(TAB2CFamily x, TAB2CFamily y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.Email.CompareTo(x.Email);
				}
				else
				{
					return x.Email.CompareTo(y.Email);
				}
			}
			#endregion
		}
		public class LanguageComparer : System.Collections.Generic.IComparer<TAB2CFamily>
		{
			public SorterMode SorterMode;
			public LanguageComparer()
			{ }
			public LanguageComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CFamily> Membres
			int System.Collections.Generic.IComparer<TAB2CFamily>.Compare(TAB2CFamily x, TAB2CFamily y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.Language.CompareTo(x.Language);
				}
				else
				{
					return x.Language.CompareTo(y.Language);
				}
			}
			#endregion
		}
		public class MessageComparer : System.Collections.Generic.IComparer<TAB2CFamily>
		{
			public SorterMode SorterMode;
			public MessageComparer()
			{ }
			public MessageComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TAB2CFamily> Membres
			int System.Collections.Generic.IComparer<TAB2CFamily>.Compare(TAB2CFamily x, TAB2CFamily y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.Message.CompareTo(x.Message);
				}
				else
				{
					return x.Message.CompareTo(y.Message);
				}
			}
			#endregion
		}
	}
}
