using System;
using System.Text;

namespace TA.BusinessObjects
{
	public class TAGetBindPackagePolicy
	{
		private string _JobNo;

		public string JobNo
		{
			get { return _JobNo; }
			set { _JobNo = value; }
		}

		private string _PolicyNo;

		public string PolicyNo
		{
			get { return _PolicyNo; }
			set { _PolicyNo = value; }
		}

		private string _TravelPlan;

		public string TravelPlan
		{
			get { return _TravelPlan; }
			set { _TravelPlan = value; }
		}

		private string _PolicyType;

		public string PolicyType
		{
			get { return _PolicyType; }
			set { _PolicyType = value; }
		}

        private string _NumbersOfChildren;

        public string NumbersOfChildren
        {
            get { return _NumbersOfChildren; }
            set { _NumbersOfChildren = value; }
        }

		private string _InsurancePlan;

		public string InsurancePlan
		{
			get { return _InsurancePlan; }
			set { _InsurancePlan = value; }
		}

		private string _EffectiveDateFrom;

		public string EffectiveDateFrom
		{
			get { return _EffectiveDateFrom; }
			set { _EffectiveDateFrom = value; }
		}

		private string _EffectiveDateTo;

		public string EffectiveDateTo
		{
			get { return _EffectiveDateTo; }
			set { _EffectiveDateTo = value; }
		}

		private string _CountryOfDestination;

		public string CountryOfDestination
		{
			get { return _CountryOfDestination; }
			set { _CountryOfDestination = value; }
		}

        private string _CounterOther;

        public string CounterOther
        {
            get { return _CounterOther; }
            set { _CounterOther = value; }
        }

		private string _PlanCode;

		public string PlanCode
		{
			get { return _PlanCode; }
			set { _PlanCode = value; }
		}

		private string _ContractType;

		public string ContractType
		{
			get { return _ContractType; }
			set { _ContractType = value; }
		}

		private string _AgentCode;

		public string AgentCode
		{
			get { return _AgentCode; }
			set { _AgentCode = value; }
		}

        private string _NetPremium;

        public string NetPremium
        {
            get { return _NetPremium; }
            set { _NetPremium = value; }
        }

        private string _Stamp;

        public string Stamp
        {
            get { return _Stamp; }
            set { _Stamp = value; }
        }

        private string _SBT;

        public string SBT
        {
            get { return _SBT; }
            set { _SBT = value; }
        }

        private string _TotalPremium;

        public string TotalPremium
        {
            get { return _TotalPremium; }
            set { _TotalPremium = value; }
        }

        private string _isLongName;

        public string IsLongName
        {
            get { return _isLongName; }
            set { _isLongName = value; }
        }

        private string _isBeneficiary;

        public string IsBeneficiary
        {
            get { return _isBeneficiary; }
            set { _isBeneficiary = value; }
        }

		private string _GroupBrokerId;

		public string GroupBrokerId
		{
			get { return _GroupBrokerId; }
			set { _GroupBrokerId = value; }
		}

        private string _LongName1;

        public string LongName1
        {
            get { return _LongName1; }
            set { _LongName1 = value; }
        }

        private string _LongName2;

        public string LongName2
        {
            get { return _LongName2; }
            set { _LongName2 = value; }
        }

        private string _LongName3;

        public string LongName3
        {
            get { return _LongName3; }
            set { _LongName3 = value; }
        }

        private string _LongName4;

        public string LongName4
        {
            get { return _LongName4; }
            set { _LongName4 = value; }
        }
        

		
	}
}
