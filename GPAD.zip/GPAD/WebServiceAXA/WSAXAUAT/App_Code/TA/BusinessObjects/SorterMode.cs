using System;
using System.Text;

namespace TA.BusinessObjects
{
	public enum SorterMode
	{
		Ascending,
		Descending
	}
}
