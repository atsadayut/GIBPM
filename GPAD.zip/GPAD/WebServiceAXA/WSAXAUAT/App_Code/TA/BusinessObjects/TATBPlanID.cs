using System;
using System.Text;

namespace TA.BusinessObjects
{
	[Serializable()]
	public class TATBPlanID
	{
		private string _PlanID;

		public string PlanID
		{
			get { return _PlanID; }
			set { _PlanID = value; }
		}

		private string _PlanName;

		public string PlanName
		{
			get { return _PlanName; }
			set { _PlanName = value; }
		}

		private Nullable<SByte> _isEnable;

		public Nullable<SByte> isEnable
		{
			get { return _isEnable; }
			set { _isEnable = value; }
		}

		private Nullable<DateTime> _CreateDate;

		public Nullable<DateTime> CreateDate
		{
			get { return _CreateDate; }
			set { _CreateDate = value; }
		}

		public TATBPlanID()
		{ }

		public TATBPlanID(string PlanID,string PlanName,Nullable<SByte> isEnable,Nullable<DateTime> CreateDate)
		{
			this.PlanID = PlanID;
			this.PlanName = PlanName;
			this.isEnable = isEnable;
			this.CreateDate = CreateDate;
		}

		public override string ToString()
		{
			return "PlanID = " + PlanID + ",PlanName = " + PlanName + ",isEnable = " + isEnable.ToString() + ",CreateDate = " + CreateDate.ToString();
		}

		public class PlanIDComparer : System.Collections.Generic.IComparer<TATBPlanID>
		{
			public SorterMode SorterMode;
			public PlanIDComparer()
			{ }
			public PlanIDComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATBPlanID> Membres
			int System.Collections.Generic.IComparer<TATBPlanID>.Compare(TATBPlanID x, TATBPlanID y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PlanID.CompareTo(x.PlanID);
				}
				else
				{
					return x.PlanID.CompareTo(y.PlanID);
				}
			}
			#endregion
		}
		public class PlanNameComparer : System.Collections.Generic.IComparer<TATBPlanID>
		{
			public SorterMode SorterMode;
			public PlanNameComparer()
			{ }
			public PlanNameComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATBPlanID> Membres
			int System.Collections.Generic.IComparer<TATBPlanID>.Compare(TATBPlanID x, TATBPlanID y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PlanName.CompareTo(x.PlanName);
				}
				else
				{
					return x.PlanName.CompareTo(y.PlanName);
				}
			}
			#endregion
		}
	}
}
