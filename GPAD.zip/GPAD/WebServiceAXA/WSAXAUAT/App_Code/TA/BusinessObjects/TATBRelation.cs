using System;
using System.Text;

namespace TA.BusinessObjects
{
	[Serializable()]
	public class TATBRelation
	{
		private int _ID;

		public int ID
		{
			get { return _ID; }
			set { _ID = value; }
		}

		private string _Relation;

		public string Relation
		{
			get { return _Relation; }
			set { _Relation = value; }
		}

		private Nullable<SByte> _isEnable;

		public Nullable<SByte> isEnable
		{
			get { return _isEnable; }
			set { _isEnable = value; }
		}

		private Nullable<DateTime> _CreateDate;

		public Nullable<DateTime> CreateDate
		{
			get { return _CreateDate; }
			set { _CreateDate = value; }
		}

		public TATBRelation()
		{ }

		public TATBRelation(int ID,string Relation,Nullable<SByte> isEnable,Nullable<DateTime> CreateDate)
		{
			this.ID = ID;
			this.Relation = Relation;
			this.isEnable = isEnable;
			this.CreateDate = CreateDate;
		}

		public override string ToString()
		{
			return "ID = " + ID.ToString() + ",Relation = " + Relation + ",isEnable = " + isEnable.ToString() + ",CreateDate = " + CreateDate.ToString();
		}

		public class IDComparer : System.Collections.Generic.IComparer<TATBRelation>
		{
			public SorterMode SorterMode;
			public IDComparer()
			{ }
			public IDComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATBRelation> Membres
			int System.Collections.Generic.IComparer<TATBRelation>.Compare(TATBRelation x, TATBRelation y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ID.CompareTo(x.ID);
				}
				else
				{
					return x.ID.CompareTo(y.ID);
				}
			}
			#endregion
		}
		public class RelationComparer : System.Collections.Generic.IComparer<TATBRelation>
		{
			public SorterMode SorterMode;
			public RelationComparer()
			{ }
			public RelationComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATBRelation> Membres
			int System.Collections.Generic.IComparer<TATBRelation>.Compare(TATBRelation x, TATBRelation y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.Relation.CompareTo(x.Relation);
				}
				else
				{
					return x.Relation.CompareTo(y.Relation);
				}
			}
			#endregion
		}
	}
}
