using System;
using System.Text;

namespace TA.BusinessObjects
{
	[Serializable()]
	public class TATBTAXRate
	{
		private string _Product;

		public string Product
		{
			get { return _Product; }
			set { _Product = value; }
		}

		private string _SBTRate;

		public string SBTRate
		{
			get { return _SBTRate; }
			set { _SBTRate = value; }
		}

		private string _VATRate;

		public string VATRate
		{
			get { return _VATRate; }
			set { _VATRate = value; }
		}

		private string _StampRate;

		public string StampRate
		{
			get { return _StampRate; }
			set { _StampRate = value; }
		}

		private Nullable<SByte> _isEnable;

		public Nullable<SByte> isEnable
		{
			get { return _isEnable; }
			set { _isEnable = value; }
		}

		private Nullable<DateTime> _CreateDate;

		public Nullable<DateTime> CreateDate
		{
			get { return _CreateDate; }
			set { _CreateDate = value; }
		}

		public TATBTAXRate()
		{ }

		public TATBTAXRate(string Product,string SBTRate,string VATRate,string StampRate,Nullable<SByte> isEnable,Nullable<DateTime> CreateDate)
		{
			this.Product = Product;
			this.SBTRate = SBTRate;
			this.VATRate = VATRate;
			this.StampRate = StampRate;
			this.isEnable = isEnable;
			this.CreateDate = CreateDate;
		}

		public override string ToString()
		{
			return "Product = " + Product + ",SBTRate = " + SBTRate + ",VATRate = " + VATRate + ",StampRate = " + StampRate + ",isEnable = " + isEnable.ToString() + ",CreateDate = " + CreateDate.ToString();
		}

		public class ProductComparer : System.Collections.Generic.IComparer<TATBTAXRate>
		{
			public SorterMode SorterMode;
			public ProductComparer()
			{ }
			public ProductComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATBTAXRate> Membres
			int System.Collections.Generic.IComparer<TATBTAXRate>.Compare(TATBTAXRate x, TATBTAXRate y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.Product.CompareTo(x.Product);
				}
				else
				{
					return x.Product.CompareTo(y.Product);
				}
			}
			#endregion
		}
		public class SBTRateComparer : System.Collections.Generic.IComparer<TATBTAXRate>
		{
			public SorterMode SorterMode;
			public SBTRateComparer()
			{ }
			public SBTRateComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATBTAXRate> Membres
			int System.Collections.Generic.IComparer<TATBTAXRate>.Compare(TATBTAXRate x, TATBTAXRate y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.SBTRate.CompareTo(x.SBTRate);
				}
				else
				{
					return x.SBTRate.CompareTo(y.SBTRate);
				}
			}
			#endregion
		}
		public class VATRateComparer : System.Collections.Generic.IComparer<TATBTAXRate>
		{
			public SorterMode SorterMode;
			public VATRateComparer()
			{ }
			public VATRateComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATBTAXRate> Membres
			int System.Collections.Generic.IComparer<TATBTAXRate>.Compare(TATBTAXRate x, TATBTAXRate y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.VATRate.CompareTo(x.VATRate);
				}
				else
				{
					return x.VATRate.CompareTo(y.VATRate);
				}
			}
			#endregion
		}
		public class StampRateComparer : System.Collections.Generic.IComparer<TATBTAXRate>
		{
			public SorterMode SorterMode;
			public StampRateComparer()
			{ }
			public StampRateComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<TATBTAXRate> Membres
			int System.Collections.Generic.IComparer<TATBTAXRate>.Compare(TATBTAXRate x, TATBTAXRate y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.StampRate.CompareTo(x.StampRate);
				}
				else
				{
					return x.StampRate.CompareTo(y.StampRate);
				}
			}
			#endregion
		}
	}
}
