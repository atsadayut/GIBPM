using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;

namespace TA.DAL
{
	public class TAPlanCoverageDAO
	{
        DbProviderHelper db;

		public TAPlanCoverageDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}
		public List<TAPlanCoverage> GetTAPlanCoverages()
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<TAPlanCoverage> lstTAPlanCoverages = new List<TAPlanCoverage>();
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					TAPlanCoverage oTAPlanCoverage = new TAPlanCoverage();
					oTAPlanCoverage.ID = Convert.ToInt32(oDbDataReader["ID"]);

					if(oDbDataReader["PlanType"] != DBNull.Value)
						oTAPlanCoverage.PlanType = Convert.ToString(oDbDataReader["PlanType"]);

					if(oDbDataReader["CoverageType"] != DBNull.Value)
						oTAPlanCoverage.CoverageType = Convert.ToString(oDbDataReader["CoverageType"]);

					if(oDbDataReader["CoverageLine"] != DBNull.Value)
						oTAPlanCoverage.CoverageLine = Convert.ToString(oDbDataReader["CoverageLine"]);

					if(oDbDataReader["CoverageDetailEN"] != DBNull.Value)
						oTAPlanCoverage.CoverageDetailEN = Convert.ToString(oDbDataReader["CoverageDetailEN"]);

					if(oDbDataReader["CoverageDetailTH"] != DBNull.Value)
						oTAPlanCoverage.CoverageDetailTH = Convert.ToString(oDbDataReader["CoverageDetailTH"]);

					if(oDbDataReader["CoveragePlan1"] != DBNull.Value)
						oTAPlanCoverage.CoveragePlan1 = Convert.ToString(oDbDataReader["CoveragePlan1"]);

					if(oDbDataReader["CoveragePlan2"] != DBNull.Value)
						oTAPlanCoverage.CoveragePlan2 = Convert.ToString(oDbDataReader["CoveragePlan2"]);

					if(oDbDataReader["CoveragePlan3"] != DBNull.Value)
						oTAPlanCoverage.CoveragePlan3 = Convert.ToString(oDbDataReader["CoveragePlan3"]);

					if(oDbDataReader["CoveragePlan4"] != DBNull.Value)
						oTAPlanCoverage.CoveragePlan4 = Convert.ToString(oDbDataReader["CoveragePlan4"]);

					if(oDbDataReader["CoveragePlan5"] != DBNull.Value)
						oTAPlanCoverage.CoveragePlan5 = Convert.ToString(oDbDataReader["CoveragePlan5"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oTAPlanCoverage.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);

					if(oDbDataReader["CreateUser"] != DBNull.Value)
						oTAPlanCoverage.CreateUser = Convert.ToString(oDbDataReader["CreateUser"]);

					if(oDbDataReader["FieldName"] != DBNull.Value)
						oTAPlanCoverage.FieldName = Convert.ToString(oDbDataReader["FieldName"]);
					lstTAPlanCoverages.Add(oTAPlanCoverage);
				}
				oDbDataReader.Close();
				return lstTAPlanCoverages;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
				throw ex;
			}
		}
		public TAPlanCoverage GetTAPlanCoverage(int ID)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				TAPlanCoverage oTAPlanCoverage = new TAPlanCoverage();
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
				oDbCommand.Parameters.Add(db.CreateParameter("@ID",DbType.Int32,ID));
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oTAPlanCoverage.ID = Convert.ToInt32(oDbDataReader["ID"]);

					if(oDbDataReader["PlanType"] != DBNull.Value)
						oTAPlanCoverage.PlanType = Convert.ToString(oDbDataReader["PlanType"]);

					if(oDbDataReader["CoverageType"] != DBNull.Value)
						oTAPlanCoverage.CoverageType = Convert.ToString(oDbDataReader["CoverageType"]);

					if(oDbDataReader["CoverageLine"] != DBNull.Value)
						oTAPlanCoverage.CoverageLine = Convert.ToString(oDbDataReader["CoverageLine"]);

					if(oDbDataReader["CoverageDetailEN"] != DBNull.Value)
						oTAPlanCoverage.CoverageDetailEN = Convert.ToString(oDbDataReader["CoverageDetailEN"]);

					if(oDbDataReader["CoverageDetailTH"] != DBNull.Value)
						oTAPlanCoverage.CoverageDetailTH = Convert.ToString(oDbDataReader["CoverageDetailTH"]);

					if(oDbDataReader["CoveragePlan1"] != DBNull.Value)
						oTAPlanCoverage.CoveragePlan1 = Convert.ToString(oDbDataReader["CoveragePlan1"]);

					if(oDbDataReader["CoveragePlan2"] != DBNull.Value)
						oTAPlanCoverage.CoveragePlan2 = Convert.ToString(oDbDataReader["CoveragePlan2"]);

					if(oDbDataReader["CoveragePlan3"] != DBNull.Value)
						oTAPlanCoverage.CoveragePlan3 = Convert.ToString(oDbDataReader["CoveragePlan3"]);

					if(oDbDataReader["CoveragePlan4"] != DBNull.Value)
						oTAPlanCoverage.CoveragePlan4 = Convert.ToString(oDbDataReader["CoveragePlan4"]);

					if(oDbDataReader["CoveragePlan5"] != DBNull.Value)
						oTAPlanCoverage.CoveragePlan5 = Convert.ToString(oDbDataReader["CoveragePlan5"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oTAPlanCoverage.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);

					if(oDbDataReader["CreateUser"] != DBNull.Value)
						oTAPlanCoverage.CreateUser = Convert.ToString(oDbDataReader["CreateUser"]);

					if(oDbDataReader["FieldName"] != DBNull.Value)
						oTAPlanCoverage.FieldName = Convert.ToString(oDbDataReader["FieldName"]);
				}
				oDbDataReader.Close();
				return oTAPlanCoverage;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
 
				throw ex;
			}
		}
		public int AddTAPlanCoverage(string PlanType,string CoverageType,string CoverageLine,string CoverageDetailEN,string CoverageDetailTH,string CoveragePlan1,string CoveragePlan2,string CoveragePlan3,string CoveragePlan4,string CoveragePlan5,Nullable<DateTime> CreateDate,string CreateUser,string FieldName)
		{
			try
			{
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
                //Add Parameters
				return Convert.ToInt32(db.ExecuteScalar(oDbCommand));
			}
			catch (Exception ex)
			{
  
				throw ex;
			}
		}
		public int UpdateTAPlanCoverage(int ID,string PlanType,string CoverageType,string CoverageLine,string CoverageDetailEN,string CoverageDetailTH,string CoveragePlan1,string CoveragePlan2,string CoveragePlan3,string CoveragePlan4,string CoveragePlan5,Nullable<DateTime> CreateDate,string CreateUser,string FieldName)
		{

			try
			{
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
                //Add Parameters
				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
               
				throw ex;
			}
		}
		public int RemoveTAPlanCoverage(int ID)
		{

			try
			{
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
                //Add Parameters
				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
               
				throw ex;
			}
		}


        /// <summary>
        /// INSERT/UPDATE
        /// </summary>
        /// <param name="PlanType"></param>
        /// <param name="CoverageType"></param>
        /// <param name="CoverageLine"></param>
        /// <param name="CoverageDetailEN"></param>
        /// <param name="CoverageDetailTH"></param>
        /// <param name="CoveragePlan1"></param>
        /// <param name="CoveragePlan2"></param>
        /// <param name="CoveragePlan3"></param>
        /// <param name="CoveragePlan4"></param>
        /// <param name="CoveragePlan5"></param>
        /// <param name="CreateDate"></param>
        /// <param name="CreateUser"></param>
        /// <param name="FieldName"></param>
        /// <returns></returns>
        public int SetTAPlanCoverage(string PlanType, string CoverageType, string CoverageLine, string CoverageDetailEN, string CoverageDetailTH, string CoveragePlan1, string CoveragePlan2, string CoveragePlan3, string CoveragePlan4, string CoveragePlan5, Nullable<DateTime> CreateDate, string CreateUser, string FieldName)
        {
            try
            {
                DbCommand oDbCommand = db.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters
                return Convert.ToInt32(db.ExecuteScalar(oDbCommand));
            }
            catch (Exception ex)
            {
               
                throw ex;
            }
        }
        /// <summary>
        /// GET
        /// </summary>
        /// <param name="PlanID">0001-0005</param>
        /// <returns></returns>
        public DataTable GetDtTAPlanCoverages(string PlanID)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = db.CreateCommand("spTA_GetCoverage", CommandType.StoredProcedure);
                comm.Parameters.Add(db.CreateParameter("@PlanID", DbType.String, PlanID));
                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return db.FillDataTable(adap);
            }
            catch (Exception ex)
            {
               
                throw ex;
            }
        }

        //-----------------------------------------------------------------------------------
        public DataTable GetDtAllTAPlanCoverages()
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = db.CreateCommand("select * from [TAPlanCoverage] where [CoverageType] != 'REMARK'", CommandType.Text);
                //comm.Parameters.Add(db.CreateParameter("@PlanID", DbType.String, PlanID));
                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return db.FillDataTable(adap);
            }
            catch (Exception ex)
            {
               
                throw ex;
            }
        }

        public int SetTAPlanCoverage(int ID, string CoveragePlan1, string CoveragePlan2, string CoveragePlan3, string CoveragePlan4, string CoveragePlan5,  string CreateUser)
        {

            try
            {
                DbCommand oDbCommand = db.CreateCommand("update [TAPlanCoverage] set [CoveragePlan1] = @CoveragePlan1,[CoveragePlan2] = @CoveragePlan2,[CoveragePlan3] = @CoveragePlan3,[CoveragePlan4] = @CoveragePlan4, [CoveragePlan5] = @CoveragePlan5,[CreateDate] = GETDATE(), [CreateUser] = @CreateUser  where  [ID] = @ID", CommandType.Text);
                //Add Parameters
                if (ID != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ID", DbType.Int16, ID));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ID", DbType.Int16, DBNull.Value));
                if (CoveragePlan1 != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@CoveragePlan1", DbType.String, CoveragePlan1));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@CoveragePlan1", DbType.String, DBNull.Value));
                if (CoveragePlan2 != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@CoveragePlan2", DbType.String, CoveragePlan2));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@CoveragePlan2", DbType.String, DBNull.Value));
                if (CoveragePlan3 != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@CoveragePlan3", DbType.String, CoveragePlan3));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@CoveragePlan3", DbType.String, DBNull.Value));
                if (CoveragePlan4 != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@CoveragePlan4", DbType.String, CoveragePlan4));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@CoveragePlan4", DbType.String, DBNull.Value));
                if (CoveragePlan5 != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@CoveragePlan5", DbType.String, CoveragePlan5));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@CoveragePlan5", DbType.String, DBNull.Value));
                if (CreateUser != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@CreateUser", DbType.String, CreateUser));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@CreateUser", DbType.String, DBNull.Value));
               
                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
               
                throw ex;
            }
        }
		
	}
}
