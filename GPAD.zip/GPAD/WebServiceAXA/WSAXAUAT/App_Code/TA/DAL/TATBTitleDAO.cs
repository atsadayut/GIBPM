using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;

namespace TA.DAL
{
	public class TATBTitleDAO
	{
        DbProviderHelper db;

		public TATBTitleDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}
		public List<TATBTitle> GetTATBTitles()
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<TATBTitle> lstTATBTitles = new List<TATBTitle>();
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					TATBTitle oTATBTitle = new TATBTitle();

					if(oDbDataReader["TitleName"] != DBNull.Value)
						oTATBTitle.TitleName = Convert.ToString(oDbDataReader["TitleName"]);

					if(oDbDataReader["SEX"] != DBNull.Value)
						oTATBTitle.SEX = Convert.ToString(oDbDataReader["SEX"]);

					if(oDbDataReader["isEnable"] != DBNull.Value)
						oTATBTitle.isEnable = Convert.ToSByte(oDbDataReader["isEnable"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oTATBTitle.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);
					lstTATBTitles.Add(oTATBTitle);
				}
				oDbDataReader.Close();
				return lstTATBTitles;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public int AddTATBTitle(string TitleName,string SEX,Nullable<SByte> isEnable,Nullable<DateTime> CreateDate)
		{
			try
			{
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
                //Add Parameters 
				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}

        /// <summary>
        /// INSERT/UPDATE
        /// </summary>
        /// <param name="TitleName"></param>
        /// <param name="SEX"></param>
        /// <param name="isEnable"></param>
        /// <param name="CreateDate"></param>
        /// <returns></returns>
        public int SetTATBTitle(string TitleName, string SEX, Nullable<SByte> isEnable, Nullable<DateTime> CreateDate)
        {
            try
            {
                DbCommand oDbCommand = db.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        /// <summary>
        /// INSERT/UPDATE WITH TRANSACTION
        /// </summary>
        /// <param name="TitleName"></param>
        /// <param name="SEX"></param>
        /// <param name="isEnable"></param>
        /// <param name="CreateDate"></param>
        /// <param name="dbTransaction"></param>
        /// <returns></returns>
        public int SetTATBTitle(string TitleName, string SEX, Nullable<SByte> isEnable, Nullable<DateTime> CreateDate,DbTransaction dbTransaction)
        {
            try
            {
                DbCommand oDbCommand = db.CreateCommand("", CommandType.StoredProcedure, dbTransaction);
                //Add Parameters 
                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        /// <summary>
        /// GET
        /// </summary>
        /// <returns></returns>
        public DataTable GetDtTATBTitles()
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = db.CreateCommand("spTA_GetTitle", CommandType.StoredProcedure);
                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return db.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public DataTable GetDtTATBTitlesThai()
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = db.CreateCommand("spTA_GetTitleTH", CommandType.StoredProcedure);
                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return db.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
	}
}
