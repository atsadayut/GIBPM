using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;

namespace TA.DAL
{
	public class TAPlanPackageDAO
	{
        DbProviderHelper db;

		public TAPlanPackageDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}
		public List<TAPlanPackage> GetTAPlanPackages()
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<TAPlanPackage> lstTAPlanPackages = new List<TAPlanPackage>();
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					TAPlanPackage oTAPlanPackage = new TAPlanPackage();
					oTAPlanPackage.PlanID = Convert.ToString(oDbDataReader["PlanID"]);
					oTAPlanPackage.PolicyType = Convert.ToString(oDbDataReader["PolicyType"]);
					oTAPlanPackage.TravelPlan = Convert.ToString(oDbDataReader["TravelPlan"]);

					if(oDbDataReader["ContractType"] != DBNull.Value)
						oTAPlanPackage.ContractType = Convert.ToString(oDbDataReader["ContractType"]);

					if(oDbDataReader["RiskType"] != DBNull.Value)
						oTAPlanPackage.RiskType = Convert.ToString(oDbDataReader["RiskType"]);

					if(oDbDataReader["PremiumClass"] != DBNull.Value)
						oTAPlanPackage.PremiumClass = Convert.ToString(oDbDataReader["PremiumClass"]);

					if(oDbDataReader["PlanCode"] != DBNull.Value)
						oTAPlanPackage.PlanCode = Convert.ToString(oDbDataReader["PlanCode"]);

					if(oDbDataReader["TemplateCode"] != DBNull.Value)
						oTAPlanPackage.TemplateCode = Convert.ToString(oDbDataReader["TemplateCode"]);

					if(oDbDataReader["isEnable"] != DBNull.Value)
						oTAPlanPackage.isEnable = Convert.ToSByte(oDbDataReader["isEnable"]);

					if(oDbDataReader["CreatDate"] != DBNull.Value)
						oTAPlanPackage.CreatDate = Convert.ToDateTime(oDbDataReader["CreatDate"]);

					if(oDbDataReader["CreateUser"] != DBNull.Value)
						oTAPlanPackage.CreateUser = Convert.ToString(oDbDataReader["CreateUser"]);
					lstTAPlanPackages.Add(oTAPlanPackage);
				}
				oDbDataReader.Close();
				return lstTAPlanPackages;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public TAPlanPackage GetTAPlanPackage(string PlanID,string PolicyType,string TravelPlan)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				TAPlanPackage oTAPlanPackage = new TAPlanPackage();
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
				oDbCommand.Parameters.Add(db.CreateParameter("@PlanID",DbType.String,PlanID));
				oDbCommand.Parameters.Add(db.CreateParameter("@PolicyType",DbType.String,PolicyType));
				oDbCommand.Parameters.Add(db.CreateParameter("@TravelPlan",DbType.String,TravelPlan));
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oTAPlanPackage.PlanID = Convert.ToString(oDbDataReader["PlanID"]);
					oTAPlanPackage.PolicyType = Convert.ToString(oDbDataReader["PolicyType"]);
					oTAPlanPackage.TravelPlan = Convert.ToString(oDbDataReader["TravelPlan"]);

					if(oDbDataReader["ContractType"] != DBNull.Value)
						oTAPlanPackage.ContractType = Convert.ToString(oDbDataReader["ContractType"]);

					if(oDbDataReader["RiskType"] != DBNull.Value)
						oTAPlanPackage.RiskType = Convert.ToString(oDbDataReader["RiskType"]);

					if(oDbDataReader["PremiumClass"] != DBNull.Value)
						oTAPlanPackage.PremiumClass = Convert.ToString(oDbDataReader["PremiumClass"]);

					if(oDbDataReader["PlanCode"] != DBNull.Value)
						oTAPlanPackage.PlanCode = Convert.ToString(oDbDataReader["PlanCode"]);

					if(oDbDataReader["TemplateCode"] != DBNull.Value)
						oTAPlanPackage.TemplateCode = Convert.ToString(oDbDataReader["TemplateCode"]);

					if(oDbDataReader["isEnable"] != DBNull.Value)
						oTAPlanPackage.isEnable = Convert.ToSByte(oDbDataReader["isEnable"]);

					if(oDbDataReader["CreatDate"] != DBNull.Value)
						oTAPlanPackage.CreatDate = Convert.ToDateTime(oDbDataReader["CreatDate"]);

					if(oDbDataReader["CreateUser"] != DBNull.Value)
						oTAPlanPackage.CreateUser = Convert.ToString(oDbDataReader["CreateUser"]);
				}
				oDbDataReader.Close();
				return oTAPlanPackage;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public int AddTAPlanPackage(string PlanID,string PolicyType,string TravelPlan,string ContractType,string RiskType,string PremiumClass,string PlanCode,string TemplateCode,Nullable<SByte> isEnable,Nullable<DateTime> CreatDate,string CreateUser)
		{
            try
            {
                DbCommand oDbCommand = db.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
		}
		public int UpdateTAPlanPackage(string PlanID,string PolicyType,string TravelPlan,string ContractType,string RiskType,string PremiumClass,string PlanCode,string TemplateCode,Nullable<SByte> isEnable,Nullable<DateTime> CreatDate,string CreateUser)
		{
            try
            {
                DbCommand oDbCommand = db.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
		}
		public int RemoveTAPlanPackage(string PlanID,string PolicyType,string TravelPlan)
		{
            try
            {
                DbCommand oDbCommand = db.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
		}

        /// <summary>
        /// GET TA Get Age
        /// </summary>
        /// <param name="PolicyType"></param>
        /// <param name="TravelPlan"></param>
        /// <param name="PlanID"></param>
        /// <returns></returns>
        public TAGetAge GetTAGetAge(string PolicyType, string TravelPlan,string PlanID)
        {
            DbDataReader oDbDataReader = null;
            try
            {
                TAGetAge oTAGetAge = new TAGetAge();
                DbCommand oDbCommand = db.CreateCommand("spTA_GetAge", CommandType.StoredProcedure);      
                oDbCommand.Parameters.Add(db.CreateParameter("@PolicyType", DbType.String, PolicyType));
                oDbCommand.Parameters.Add(db.CreateParameter("@TravelPlan", DbType.String, TravelPlan));
                oDbCommand.Parameters.Add(db.CreateParameter("@PlanID", DbType.String, PlanID));
                oDbDataReader = db.ExecuteReader(oDbCommand);
                while (oDbDataReader.Read())
                {
                    if (oDbDataReader["AgeOfTravelerFrom"] != DBNull.Value)
                        oTAGetAge.AgeOfTravelerFrom = Convert.ToString(oDbDataReader["AgeOfTravelerFrom"]);

                    if (oDbDataReader["AgeOfTravelerTo"] != DBNull.Value)
                        oTAGetAge.AgeOfTravelerTo = Convert.ToString(oDbDataReader["AgeOfTravelerTo"]);            
                }
                oDbDataReader.Close();
                return oTAGetAge;
            }
            catch (Exception ex)
            {
                oDbDataReader.Close();
                Utilities.LogError(ex);
                throw ex;
            }
        }

	}
}
