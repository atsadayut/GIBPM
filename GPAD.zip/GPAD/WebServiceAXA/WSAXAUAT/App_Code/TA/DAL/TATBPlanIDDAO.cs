using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;

namespace TA.DAL
{
	public class TATBPlanIDDAO
	{
        DbProviderHelper db;

		public TATBPlanIDDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}
		public List<TATBPlanID> GetTATBPlanIDs()
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<TATBPlanID> lstTATBPlanIDs = new List<TATBPlanID>();
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					TATBPlanID oTATBPlanID = new TATBPlanID();
					oTATBPlanID.PlanID = Convert.ToString(oDbDataReader["PlanID"]);

					if(oDbDataReader["PlanName"] != DBNull.Value)
						oTATBPlanID.PlanName = Convert.ToString(oDbDataReader["PlanName"]);

					if(oDbDataReader["isEnable"] != DBNull.Value)
						oTATBPlanID.isEnable = Convert.ToSByte(oDbDataReader["isEnable"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oTATBPlanID.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);
					lstTATBPlanIDs.Add(oTATBPlanID);
				}
				oDbDataReader.Close();
				return lstTATBPlanIDs;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public TATBPlanID GetTATBPlanID(string PlanID)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				TATBPlanID oTATBPlanID = new TATBPlanID();
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
				oDbCommand.Parameters.Add(db.CreateParameter("@PlanID",DbType.String,PlanID));
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oTATBPlanID.PlanID = Convert.ToString(oDbDataReader["PlanID"]);

					if(oDbDataReader["PlanName"] != DBNull.Value)
						oTATBPlanID.PlanName = Convert.ToString(oDbDataReader["PlanName"]);

					if(oDbDataReader["isEnable"] != DBNull.Value)
						oTATBPlanID.isEnable = Convert.ToSByte(oDbDataReader["isEnable"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oTATBPlanID.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);
				}
				oDbDataReader.Close();
				return oTATBPlanID;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public int AddTATBPlanID(string PlanID,string PlanName,Nullable<SByte> isEnable,Nullable<DateTime> CreateDate)
		{
			try
			{
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
                //Add Parameters 
				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public int UpdateTATBPlanID(string PlanID,string PlanName,Nullable<SByte> isEnable,Nullable<DateTime> CreateDate)
		{

			try
			{
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
                //Add Parameters 
				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public int RemoveTATBPlanID(string PlanID)
		{

			try
			{
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
                //Add Parameters 
				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}

        /// <summary>
        /// INSERT/UPDATE
        /// </summary>
        /// <param name="PlanID"></param>
        /// <param name="PlanName"></param>
        /// <param name="isEnable"></param>
        /// <param name="CreateDate"></param>
        /// <returns></returns>
        public int SetTATBPlanID(string PlanID, string PlanName, Nullable<SByte> isEnable, Nullable<DateTime> CreateDate)
        {
            try
            {
                DbCommand oDbCommand = db.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        /// <summary>
        /// GET
        /// </summary>
        /// <returns></returns>
        public DataTable GetDtTATBPlanIDs()
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = db.CreateCommand("spTA_GetPlanID", CommandType.StoredProcedure);
                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return db.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
	}
}
