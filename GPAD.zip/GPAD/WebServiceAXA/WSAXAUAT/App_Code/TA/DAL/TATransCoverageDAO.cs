using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;

namespace TA.DAL
{
	public class TATransCoverageDAO
	{
        DbProviderHelper db;

		public TATransCoverageDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}
		public List<TATransCoverage> GetTATransCoverages()
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<TATransCoverage> lstTATransCoverages = new List<TATransCoverage>();
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					TATransCoverage oTATransCoverage = new TATransCoverage();
					oTATransCoverage.JobNo = Convert.ToString(oDbDataReader["JobNo"]);

					if(oDbDataReader["PersonalAccident"] != DBNull.Value)
						oTATransCoverage.PersonalAccident = Convert.ToString(oDbDataReader["PersonalAccident"]);

					if(oDbDataReader["MedicalExpense"] != DBNull.Value)
						oTATransCoverage.MedicalExpense = Convert.ToString(oDbDataReader["MedicalExpense"]);

					if(oDbDataReader["EmergencyMedical"] != DBNull.Value)
						oTATransCoverage.EmergencyMedical = Convert.ToString(oDbDataReader["EmergencyMedical"]);

					if(oDbDataReader["Repatriation"] != DBNull.Value)
						oTATransCoverage.Repatriation = Convert.ToString(oDbDataReader["Repatriation"]);

					if(oDbDataReader["PersonalLiability"] != DBNull.Value)
						oTATransCoverage.PersonalLiability = Convert.ToString(oDbDataReader["PersonalLiability"]);

					if(oDbDataReader["TripCancellation"] != DBNull.Value)
						oTATransCoverage.TripCancellation = Convert.ToString(oDbDataReader["TripCancellation"]);

					if(oDbDataReader["TravelDelay"] != DBNull.Value)
						oTATransCoverage.TravelDelay = Convert.ToString(oDbDataReader["TravelDelay"]);
					oTATransCoverage.FlightMisconnection = Convert.ToString(oDbDataReader["FlightMisconnection"]);

					if(oDbDataReader["TripCurtailment"] != DBNull.Value)
						oTATransCoverage.TripCurtailment = Convert.ToString(oDbDataReader["TripCurtailment"]);

					if(oDbDataReader["BaggageDelay"] != DBNull.Value)
						oTATransCoverage.BaggageDelay = Convert.ToString(oDbDataReader["BaggageDelay"]);

					if(oDbDataReader["LossBaggage"] != DBNull.Value)
						oTATransCoverage.LossBaggage = Convert.ToString(oDbDataReader["LossBaggage"]);

					if(oDbDataReader["LossPersonalMoney"] != DBNull.Value)
						oTATransCoverage.LossPersonalMoney = Convert.ToString(oDbDataReader["LossPersonalMoney"]);

					if(oDbDataReader["LossTravelDocument"] != DBNull.Value)
						oTATransCoverage.LossTravelDocument = Convert.ToString(oDbDataReader["LossTravelDocument"]);

					if(oDbDataReader["CompassionateVisitation"] != DBNull.Value)
						oTATransCoverage.CompassionateVisitation = Convert.ToString(oDbDataReader["CompassionateVisitation"]);

					if(oDbDataReader["ReturnChildren"] != DBNull.Value)
						oTATransCoverage.ReturnChildren = Convert.ToString(oDbDataReader["ReturnChildren"]);

					if(oDbDataReader["AutomaticExtension"] != DBNull.Value)
						oTATransCoverage.AutomaticExtension = Convert.ToString(oDbDataReader["AutomaticExtension"]);

					if(oDbDataReader["HospitalIncome"] != DBNull.Value)
						oTATransCoverage.HospitalIncome = Convert.ToString(oDbDataReader["HospitalIncome"]);
					lstTATransCoverages.Add(oTATransCoverage);
				}
				oDbDataReader.Close();
				return lstTATransCoverages;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public TATransCoverage GetTATransCoverage(string JobNo)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				TATransCoverage oTATransCoverage = new TATransCoverage();
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
				oDbCommand.Parameters.Add(db.CreateParameter("@JobNo",DbType.String,JobNo));
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oTATransCoverage.JobNo = Convert.ToString(oDbDataReader["JobNo"]);

					if(oDbDataReader["PersonalAccident"] != DBNull.Value)
						oTATransCoverage.PersonalAccident = Convert.ToString(oDbDataReader["PersonalAccident"]);

					if(oDbDataReader["MedicalExpense"] != DBNull.Value)
						oTATransCoverage.MedicalExpense = Convert.ToString(oDbDataReader["MedicalExpense"]);

					if(oDbDataReader["EmergencyMedical"] != DBNull.Value)
						oTATransCoverage.EmergencyMedical = Convert.ToString(oDbDataReader["EmergencyMedical"]);

					if(oDbDataReader["Repatriation"] != DBNull.Value)
						oTATransCoverage.Repatriation = Convert.ToString(oDbDataReader["Repatriation"]);

					if(oDbDataReader["PersonalLiability"] != DBNull.Value)
						oTATransCoverage.PersonalLiability = Convert.ToString(oDbDataReader["PersonalLiability"]);

					if(oDbDataReader["TripCancellation"] != DBNull.Value)
						oTATransCoverage.TripCancellation = Convert.ToString(oDbDataReader["TripCancellation"]);

					if(oDbDataReader["TravelDelay"] != DBNull.Value)
						oTATransCoverage.TravelDelay = Convert.ToString(oDbDataReader["TravelDelay"]);
					oTATransCoverage.FlightMisconnection = Convert.ToString(oDbDataReader["FlightMisconnection"]);

					if(oDbDataReader["TripCurtailment"] != DBNull.Value)
						oTATransCoverage.TripCurtailment = Convert.ToString(oDbDataReader["TripCurtailment"]);

					if(oDbDataReader["BaggageDelay"] != DBNull.Value)
						oTATransCoverage.BaggageDelay = Convert.ToString(oDbDataReader["BaggageDelay"]);

					if(oDbDataReader["LossBaggage"] != DBNull.Value)
						oTATransCoverage.LossBaggage = Convert.ToString(oDbDataReader["LossBaggage"]);

					if(oDbDataReader["LossPersonalMoney"] != DBNull.Value)
						oTATransCoverage.LossPersonalMoney = Convert.ToString(oDbDataReader["LossPersonalMoney"]);

					if(oDbDataReader["LossTravelDocument"] != DBNull.Value)
						oTATransCoverage.LossTravelDocument = Convert.ToString(oDbDataReader["LossTravelDocument"]);

					if(oDbDataReader["CompassionateVisitation"] != DBNull.Value)
						oTATransCoverage.CompassionateVisitation = Convert.ToString(oDbDataReader["CompassionateVisitation"]);

					if(oDbDataReader["ReturnChildren"] != DBNull.Value)
						oTATransCoverage.ReturnChildren = Convert.ToString(oDbDataReader["ReturnChildren"]);

					if(oDbDataReader["AutomaticExtension"] != DBNull.Value)
						oTATransCoverage.AutomaticExtension = Convert.ToString(oDbDataReader["AutomaticExtension"]);

					if(oDbDataReader["HospitalIncome"] != DBNull.Value)
						oTATransCoverage.HospitalIncome = Convert.ToString(oDbDataReader["HospitalIncome"]);
				}
				oDbDataReader.Close();
				return oTATransCoverage;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public int AddTATransCoverage(string JobNo,string PersonalAccident,string MedicalExpense,string EmergencyMedical,string Repatriation,string PersonalLiability,string TripCancellation,string TravelDelay,string FlightMisconnection,string TripCurtailment,string BaggageDelay,string LossBaggage,string LossPersonalMoney,string LossTravelDocument,string CompassionateVisitation,string ReturnChildren,string AutomaticExtension,string HospitalIncome)
		{
            try
            {
                DbCommand oDbCommand = db.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
				
		}
		public int UpdateTATransCoverage(string JobNo,string PersonalAccident,string MedicalExpense,string EmergencyMedical,string Repatriation,string PersonalLiability,string TripCancellation,string TravelDelay,string FlightMisconnection,string TripCurtailment,string BaggageDelay,string LossBaggage,string LossPersonalMoney,string LossTravelDocument,string CompassionateVisitation,string ReturnChildren,string AutomaticExtension,string HospitalIncome)
		{
            try
            {
                DbCommand oDbCommand = db.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
		}
		public int RemoveTATransCoverage(string JobNo)
		{
            try
            {
                DbCommand oDbCommand = db.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
		}

       

        /// <summary>
        /// INSERT/UPDATE
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="PersonalAccident"></param>
        /// <param name="MedicalExpense"></param>
        /// <param name="EmergencyMedical"></param>
        /// <param name="Repatriation"></param>
        /// <param name="PersonalLiability"></param>
        /// <param name="TripCancellation"></param>
        /// <param name="TravelDelay"></param>
        /// <param name="FlightMisconnection"></param>
        /// <param name="TripCurtailment"></param>
        /// <param name="BaggageDelay"></param>
        /// <param name="LossBaggage"></param>
        /// <param name="LossPersonalMoney"></param>
        /// <param name="LossTravelDocument"></param>
        /// <param name="CompassionateVisitation"></param>
        /// <param name="ReturnChildren"></param>
        /// <param name="AutomaticExtension"></param>
        /// <param name="HospitalIncome"></param>
        /// <returns></returns>
        public int SetTATransCoverage(string JobNo, string PersonalAccident, string MedicalExpense, string EmergencyMedical, string Repatriation, string PersonalLiability, string TripCancellation, string TravelDelay, string FlightMisconnection, string TripCurtailment, string BaggageDelay, string LossBaggage, string LossPersonalMoney, string LossTravelDocument, string CompassionateVisitation, string ReturnChildren, string AutomaticExtension, string HospitalIncome)
        {
            try
            {
                DbCommand oDbCommand = db.CreateCommand("", CommandType.StoredProcedure);
                if (PersonalAccident != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PersonalAccident", DbType.String, PersonalAccident));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PersonalAccident", DbType.String, DBNull.Value));
                if (MedicalExpense != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@MedicalExpense", DbType.String, MedicalExpense));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@MedicalExpense", DbType.String, DBNull.Value));
                if (EmergencyMedical != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@EmergencyMedical", DbType.String, EmergencyMedical));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@EmergencyMedical", DbType.String, DBNull.Value));
                if (Repatriation != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Repatriation", DbType.String, Repatriation));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Repatriation", DbType.String, DBNull.Value));
                if (PersonalLiability != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PersonalLiability", DbType.String, PersonalLiability));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PersonalLiability", DbType.String, DBNull.Value));
                if (TripCancellation != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@TripCancellation", DbType.String, TripCancellation));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@TripCancellation", DbType.String, DBNull.Value));
                if (TravelDelay != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@TravelDelay", DbType.String, TravelDelay));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@TravelDelay", DbType.String, DBNull.Value));
                oDbCommand.Parameters.Add(db.CreateParameter("@FlightMisconnection", DbType.String, FlightMisconnection));
                if (TripCurtailment != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@TripCurtailment", DbType.String, TripCurtailment));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@TripCurtailment", DbType.String, DBNull.Value));
                if (BaggageDelay != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@BaggageDelay", DbType.String, BaggageDelay));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@BaggageDelay", DbType.String, DBNull.Value));
                if (LossBaggage != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LossBaggage", DbType.String, LossBaggage));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LossBaggage", DbType.String, DBNull.Value));
                if (LossPersonalMoney != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LossPersonalMoney", DbType.String, LossPersonalMoney));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LossPersonalMoney", DbType.String, DBNull.Value));
                if (LossTravelDocument != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LossTravelDocument", DbType.String, LossTravelDocument));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LossTravelDocument", DbType.String, DBNull.Value));
                if (CompassionateVisitation != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@CompassionateVisitation", DbType.String, CompassionateVisitation));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@CompassionateVisitation", DbType.String, DBNull.Value));
                if (ReturnChildren != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ReturnChildren", DbType.String, ReturnChildren));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ReturnChildren", DbType.String, DBNull.Value));
                if (AutomaticExtension != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@AutomaticExtension", DbType.String, AutomaticExtension));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@AutomaticExtension", DbType.String, DBNull.Value));
                if (HospitalIncome != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@HospitalIncome", DbType.String, HospitalIncome));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@HospitalIncome", DbType.String, DBNull.Value));

                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        /// <summary>
        /// INSERT/UPDATE WITH TRANSACTION
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="PersonalAccident"></param>
        /// <param name="MedicalExpense"></param>
        /// <param name="EmergencyMedical"></param>
        /// <param name="Repatriation"></param>
        /// <param name="PersonalLiability"></param>
        /// <param name="TripCancellation"></param>
        /// <param name="TravelDelay"></param>
        /// <param name="FlightMisconnection"></param>
        /// <param name="TripCurtailment"></param>
        /// <param name="BaggageDelay"></param>
        /// <param name="LossBaggage"></param>
        /// <param name="LossPersonalMoney"></param>
        /// <param name="LossTravelDocument"></param>
        /// <param name="CompassionateVisitation"></param>
        /// <param name="ReturnChildren"></param>
        /// <param name="AutomaticExtension"></param>
        /// <param name="HospitalIncome"></param>
        /// <param name="dbTransaction"></param>
        /// <returns></returns>
        public int SetTATransCoverage(string JobNo, string PersonalAccident, string MedicalExpense, string EmergencyMedical, string Repatriation, string PersonalLiability, string TripCancellation, string TravelDelay, string FlightMisconnection, string TripCurtailment, string BaggageDelay, string LossBaggage, string LossPersonalMoney, string LossTravelDocument, string CompassionateVisitation, string ReturnChildren, string AutomaticExtension, string HospitalIncome, DbTransaction dbTransaction)
        {
            try
            {
                DbCommand oDbCommand = db.CreateCommand("", CommandType.StoredProcedure, dbTransaction);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (PersonalAccident != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PersonalAccident", DbType.String, PersonalAccident));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PersonalAccident", DbType.String, DBNull.Value));
                if (MedicalExpense != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@MedicalExpense", DbType.String, MedicalExpense));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@MedicalExpense", DbType.String, DBNull.Value));
                if (EmergencyMedical != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@EmergencyMedical", DbType.String, EmergencyMedical));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@EmergencyMedical", DbType.String, DBNull.Value));
                if (Repatriation != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Repatriation", DbType.String, Repatriation));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Repatriation", DbType.String, DBNull.Value));
                if (PersonalLiability != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PersonalLiability", DbType.String, PersonalLiability));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PersonalLiability", DbType.String, DBNull.Value));
                if (TripCancellation != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@TripCancellation", DbType.String, TripCancellation));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@TripCancellation", DbType.String, DBNull.Value));
                if (TravelDelay != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@TravelDelay", DbType.String, TravelDelay));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@TravelDelay", DbType.String, DBNull.Value));
                oDbCommand.Parameters.Add(db.CreateParameter("@FlightMisconnection", DbType.String, FlightMisconnection));
                if (TripCurtailment != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@TripCurtailment", DbType.String, TripCurtailment));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@TripCurtailment", DbType.String, DBNull.Value));
                if (BaggageDelay != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@BaggageDelay", DbType.String, BaggageDelay));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@BaggageDelay", DbType.String, DBNull.Value));
                if (LossBaggage != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LossBaggage", DbType.String, LossBaggage));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LossBaggage", DbType.String, DBNull.Value));
                if (LossPersonalMoney != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LossPersonalMoney", DbType.String, LossPersonalMoney));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LossPersonalMoney", DbType.String, DBNull.Value));
                if (LossTravelDocument != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LossTravelDocument", DbType.String, LossTravelDocument));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LossTravelDocument", DbType.String, DBNull.Value));
                if (CompassionateVisitation != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@CompassionateVisitation", DbType.String, CompassionateVisitation));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@CompassionateVisitation", DbType.String, DBNull.Value));
                if (ReturnChildren != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ReturnChildren", DbType.String, ReturnChildren));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ReturnChildren", DbType.String, DBNull.Value));
                if (AutomaticExtension != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@AutomaticExtension", DbType.String, AutomaticExtension));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@AutomaticExtension", DbType.String, DBNull.Value));
                if (HospitalIncome != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@HospitalIncome", DbType.String, HospitalIncome));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@HospitalIncome", DbType.String, DBNull.Value));

                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        /// <summary>
        /// INSERT/UPDATE
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="PersonalAccident"></param>
        /// <param name="PlanId"></param>
        /// <returns></returns>
        public int SetTATransCoverage(string JobNo, float PersonalAccident, string PlanId)
        {
            try
            {
                DbCommand oDbCommand = db.CreateCommand("spTA_SetTATransCoverage", CommandType.StoredProcedure);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (PersonalAccident != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PersonalAccident", DbType.Single, PersonalAccident));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PersonalAccident", DbType.Single, DBNull.Value));
                if (PlanId != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PlanId", DbType.String, PlanId));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PlanId", DbType.String, DBNull.Value));


                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        /// <summary>
        /// INSERT/UPDATE WITH TRANSACTION
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="PersonalAccident"></param>
        /// <param name="PlanId"></param>
        /// <param name="dbTransaction"></param>
        /// <returns></returns>
        public int SetTATransCoverage(DbProviderHelper db,string JobNo, float PersonalAccident, string PlanId, DbTransaction dbTransaction)
        {
            try
            {
                DbCommand oDbCommand = db.CreateCommand("spTA_SetTATransCoverage", CommandType.StoredProcedure, dbTransaction);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (PersonalAccident != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PersonalAccident ", DbType.Single, PersonalAccident));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PersonalAccident", DbType.Single, DBNull.Value));
                if (PlanId != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PlanId", DbType.String, PlanId));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PlanId", DbType.String, DBNull.Value));
                

                return db.ExecuteNonQuery(oDbCommand,true);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
	
    }
}
