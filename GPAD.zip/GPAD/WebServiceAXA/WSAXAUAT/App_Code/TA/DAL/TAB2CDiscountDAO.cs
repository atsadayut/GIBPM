using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;

namespace TA.DAL
{
	public class TAB2CDiscountDAO
	{
        DbProviderHelper db;

		public TAB2CDiscountDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}
		public List<TAB2CDiscount> GetTAB2CDiscounts()
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<TAB2CDiscount> lstTAB2CDiscounts = new List<TAB2CDiscount>();
				DbCommand oDbCommand = db.CreateCommand("SELECT [ID],[CodeDiscount],[Checksum],[DiscountPresent],[DiscountAmount],[ForUserWebID],[BrokerCode],[GroupBrokerId],[GeneratedUse],[GeneratedDate],[JobNo],[UsedUserID],[UsedDate],[UsedFlag] FROM [TAB2CDiscount]",CommandType.Text);
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					TAB2CDiscount oTAB2CDiscount = new TAB2CDiscount();
					oTAB2CDiscount.ID = Convert.ToInt32(oDbDataReader["ID"]);

					if(oDbDataReader["CodeDiscount"] != DBNull.Value)
						oTAB2CDiscount.CodeDiscount = Convert.ToString(oDbDataReader["CodeDiscount"]);

					if(oDbDataReader["Checksum"] != DBNull.Value)
						oTAB2CDiscount.Checksum = Convert.ToInt32(oDbDataReader["Checksum"]);

					if(oDbDataReader["DiscountPresent"] != DBNull.Value)
						oTAB2CDiscount.DiscountPresent = Convert.ToInt32(oDbDataReader["DiscountPresent"]);

					if(oDbDataReader["DiscountAmount"] != DBNull.Value)
						oTAB2CDiscount.DiscountAmount = Convert.ToInt32(oDbDataReader["DiscountAmount"]);

					if(oDbDataReader["ForUserWebID"] != DBNull.Value)
						oTAB2CDiscount.ForUserWebID = Convert.ToString(oDbDataReader["ForUserWebID"]);

					if(oDbDataReader["BrokerCode"] != DBNull.Value)
						oTAB2CDiscount.BrokerCode = Convert.ToString(oDbDataReader["BrokerCode"]);

					if(oDbDataReader["GroupBrokerId"] != DBNull.Value)
						oTAB2CDiscount.GroupBrokerId = Convert.ToString(oDbDataReader["GroupBrokerId"]);

					if(oDbDataReader["GeneratedUse"] != DBNull.Value)
						oTAB2CDiscount.GeneratedUse = Convert.ToString(oDbDataReader["GeneratedUse"]);

					if(oDbDataReader["GeneratedDate"] != DBNull.Value)
						oTAB2CDiscount.GeneratedDate = Convert.ToDateTime(oDbDataReader["GeneratedDate"]);

					if(oDbDataReader["JobNo"] != DBNull.Value)
						oTAB2CDiscount.JobNo = Convert.ToString(oDbDataReader["JobNo"]);

					if(oDbDataReader["UsedUserID"] != DBNull.Value)
						oTAB2CDiscount.UsedUserID = Convert.ToString(oDbDataReader["UsedUserID"]);

					if(oDbDataReader["UsedDate"] != DBNull.Value)
						oTAB2CDiscount.UsedDate = Convert.ToDateTime(oDbDataReader["UsedDate"]);

					if(oDbDataReader["UsedFlag"] != DBNull.Value)
						oTAB2CDiscount.UsedFlag = Convert.ToSByte(oDbDataReader["UsedFlag"]);
					lstTAB2CDiscounts.Add(oTAB2CDiscount);
				}
				oDbDataReader.Close();
				return lstTAB2CDiscounts;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}
		public TAB2CDiscount GetTAB2CDiscount(int ID)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				TAB2CDiscount oTAB2CDiscount = new TAB2CDiscount();
				DbCommand oDbCommand = db.CreateCommand("SELECT [ID],[CodeDiscount],[Checksum],[DiscountPresent],[DiscountAmount],[ForUserWebID],[BrokerCode],[GroupBrokerId],[GeneratedUse],[GeneratedDate],[JobNo],[UsedUserID],[UsedDate],[UsedFlag] FROM [TAB2CDiscount] WHERE [ID]=@ID",CommandType.Text);
				oDbCommand.Parameters.Add(db.CreateParameter("@ID",DbType.Int32,ID));
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oTAB2CDiscount.ID = Convert.ToInt32(oDbDataReader["ID"]);

					if(oDbDataReader["CodeDiscount"] != DBNull.Value)
						oTAB2CDiscount.CodeDiscount = Convert.ToString(oDbDataReader["CodeDiscount"]);

					if(oDbDataReader["Checksum"] != DBNull.Value)
						oTAB2CDiscount.Checksum = Convert.ToInt32(oDbDataReader["Checksum"]);

					if(oDbDataReader["DiscountPresent"] != DBNull.Value)
						oTAB2CDiscount.DiscountPresent = Convert.ToInt32(oDbDataReader["DiscountPresent"]);

					if(oDbDataReader["DiscountAmount"] != DBNull.Value)
						oTAB2CDiscount.DiscountAmount = Convert.ToInt32(oDbDataReader["DiscountAmount"]);

					if(oDbDataReader["ForUserWebID"] != DBNull.Value)
						oTAB2CDiscount.ForUserWebID = Convert.ToString(oDbDataReader["ForUserWebID"]);

					if(oDbDataReader["BrokerCode"] != DBNull.Value)
						oTAB2CDiscount.BrokerCode = Convert.ToString(oDbDataReader["BrokerCode"]);

					if(oDbDataReader["GroupBrokerId"] != DBNull.Value)
						oTAB2CDiscount.GroupBrokerId = Convert.ToString(oDbDataReader["GroupBrokerId"]);

					if(oDbDataReader["GeneratedUse"] != DBNull.Value)
						oTAB2CDiscount.GeneratedUse = Convert.ToString(oDbDataReader["GeneratedUse"]);

					if(oDbDataReader["GeneratedDate"] != DBNull.Value)
						oTAB2CDiscount.GeneratedDate = Convert.ToDateTime(oDbDataReader["GeneratedDate"]);

					if(oDbDataReader["JobNo"] != DBNull.Value)
						oTAB2CDiscount.JobNo = Convert.ToString(oDbDataReader["JobNo"]);

					if(oDbDataReader["UsedUserID"] != DBNull.Value)
						oTAB2CDiscount.UsedUserID = Convert.ToString(oDbDataReader["UsedUserID"]);

					if(oDbDataReader["UsedDate"] != DBNull.Value)
						oTAB2CDiscount.UsedDate = Convert.ToDateTime(oDbDataReader["UsedDate"]);

					if(oDbDataReader["UsedFlag"] != DBNull.Value)
						oTAB2CDiscount.UsedFlag = Convert.ToSByte(oDbDataReader["UsedFlag"]);
				}
				oDbDataReader.Close();
				return oTAB2CDiscount;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}
        public TAB2CDiscount GetTAB2CDiscount(string CodeDiscount, string UserID)
        {
            DbDataReader oDbDataReader = null;
            try
            {
                TAB2CDiscount oTAB2CDiscount = new TAB2CDiscount();
                DbCommand oDbCommand = db.CreateCommand("SELECT [ID],[CodeDiscount],[Checksum],[DiscountPresent],[DiscountAmount],[ForUserWebID],[BrokerCode],[GroupBrokerId],[GeneratedUse],[GeneratedDate],[JobNo],[UsedUserID],[UsedDate],[UsedFlag] FROM [TAB2CDiscount] WHERE [CodeDiscount]=@CodeDiscount AND [ForUserWebID] = @ForUserWebID AND [UsedFlag] = 0", CommandType.Text);
                oDbCommand.Parameters.Add(db.CreateParameter("@CodeDiscount", DbType.String, CodeDiscount));
                oDbCommand.Parameters.Add(db.CreateParameter("@ForUserWebID", DbType.String, UserID));
                oDbDataReader = db.ExecuteReader(oDbCommand);
                while (oDbDataReader.Read())
                {
                    oTAB2CDiscount.ID = Convert.ToInt32(oDbDataReader["ID"]);

                    if (oDbDataReader["CodeDiscount"] != DBNull.Value)
                        oTAB2CDiscount.CodeDiscount = Convert.ToString(oDbDataReader["CodeDiscount"]);

                    if (oDbDataReader["Checksum"] != DBNull.Value)
                        oTAB2CDiscount.Checksum = Convert.ToInt32(oDbDataReader["Checksum"]);

                    if (oDbDataReader["DiscountPresent"] != DBNull.Value)
                        oTAB2CDiscount.DiscountPresent = Convert.ToInt32(oDbDataReader["DiscountPresent"]);

                    if (oDbDataReader["DiscountAmount"] != DBNull.Value)
                        oTAB2CDiscount.DiscountAmount = Convert.ToInt32(oDbDataReader["DiscountAmount"]);

                    if (oDbDataReader["ForUserWebID"] != DBNull.Value)
                        oTAB2CDiscount.ForUserWebID = Convert.ToString(oDbDataReader["ForUserWebID"]);

                    if (oDbDataReader["BrokerCode"] != DBNull.Value)
                        oTAB2CDiscount.BrokerCode = Convert.ToString(oDbDataReader["BrokerCode"]);

                    if (oDbDataReader["GroupBrokerId"] != DBNull.Value)
                        oTAB2CDiscount.GroupBrokerId = Convert.ToString(oDbDataReader["GroupBrokerId"]);

                    if (oDbDataReader["GeneratedUse"] != DBNull.Value)
                        oTAB2CDiscount.GeneratedUse = Convert.ToString(oDbDataReader["GeneratedUse"]);

                    if (oDbDataReader["GeneratedDate"] != DBNull.Value)
                        oTAB2CDiscount.GeneratedDate = Convert.ToDateTime(oDbDataReader["GeneratedDate"]);

                    if (oDbDataReader["JobNo"] != DBNull.Value)
                        oTAB2CDiscount.JobNo = Convert.ToString(oDbDataReader["JobNo"]);

                    if (oDbDataReader["UsedUserID"] != DBNull.Value)
                        oTAB2CDiscount.UsedUserID = Convert.ToString(oDbDataReader["UsedUserID"]);

                    if (oDbDataReader["UsedDate"] != DBNull.Value)
                        oTAB2CDiscount.UsedDate = Convert.ToDateTime(oDbDataReader["UsedDate"]);

                    if (oDbDataReader["UsedFlag"] != DBNull.Value)
                        oTAB2CDiscount.UsedFlag = Convert.ToSByte(oDbDataReader["UsedFlag"]);
                }
                oDbDataReader.Close();
                return oTAB2CDiscount;
            }
            catch (Exception ex)
            {
                oDbDataReader.Close();
                throw ex;
            }
        }
		public int AddTAB2CDiscount(string CodeDiscount,Nullable<int> Checksum,Nullable<int> DiscountPresent,Nullable<int> DiscountAmount,string ForUserWebID,string BrokerCode,string GroupBrokerId,string GeneratedUse,Nullable<DateTime> GeneratedDate,string JobNo,string UsedUserID,Nullable<DateTime> UsedDate,Nullable<SByte> UsedFlag)
		{
			try
			{
				DbCommand oDbCommand = db.CreateCommand("INSERT INTO [TAB2CDiscount]([CodeDiscount],[Checksum],[DiscountPresent],[DiscountAmount],[ForUserWebID],[BrokerCode],[GroupBrokerId],[GeneratedUse],[GeneratedDate],[JobNo],[UsedUserID],[UsedDate],[UsedFlag])VALUES(@CodeDiscount,@Checksum,@DiscountPresent,@DiscountAmount,@ForUserWebID,@BrokerCode,@GroupBrokerId,@GeneratedUse,@GeneratedDate,@JobNo,@UsedUserID,@UsedDate,@UsedFlag);SELECT SCOPE_IDENTITY();",CommandType.Text);
				if (CodeDiscount!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@CodeDiscount",DbType.String,CodeDiscount));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@CodeDiscount",DbType.String,DBNull.Value));
				if (Checksum.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@Checksum",DbType.Int32,Checksum));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Checksum",DbType.Int32,DBNull.Value));
				if (DiscountPresent.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@DiscountPresent",DbType.Int32,DiscountPresent));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@DiscountPresent",DbType.Int32,DBNull.Value));
				if (DiscountAmount.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@DiscountAmount",DbType.Int32,DiscountAmount));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@DiscountAmount",DbType.Int32,DBNull.Value));
				if (ForUserWebID!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ForUserWebID",DbType.String,ForUserWebID));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ForUserWebID",DbType.String,DBNull.Value));
				if (BrokerCode!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@BrokerCode",DbType.String,BrokerCode));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@BrokerCode",DbType.String,DBNull.Value));
				if (GroupBrokerId!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@GroupBrokerId",DbType.String,GroupBrokerId));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@GroupBrokerId",DbType.String,DBNull.Value));
				if (GeneratedUse!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@GeneratedUse",DbType.String,GeneratedUse));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@GeneratedUse",DbType.String,DBNull.Value));
				if (GeneratedDate.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@GeneratedDate",DbType.DateTime,GeneratedDate));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@GeneratedDate",DbType.DateTime,DBNull.Value));
				if (JobNo!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@JobNo",DbType.String,JobNo));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@JobNo",DbType.String,DBNull.Value));
				if (UsedUserID!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@UsedUserID",DbType.String,UsedUserID));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@UsedUserID",DbType.String,DBNull.Value));
				if (UsedDate.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@UsedDate",DbType.DateTime,UsedDate));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@UsedDate",DbType.DateTime,DBNull.Value));
				if (UsedFlag.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@UsedFlag",DbType.SByte,UsedFlag));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@UsedFlag",DbType.SByte,DBNull.Value));

				return Convert.ToInt32(db.ExecuteScalar(oDbCommand));
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public int UpdateTAB2CDiscount(int ID,string CodeDiscount,Nullable<int> Checksum,Nullable<int> DiscountPresent,Nullable<int> DiscountAmount,string ForUserWebID,string BrokerCode,string GroupBrokerId,string GeneratedUse,Nullable<DateTime> GeneratedDate,string JobNo,string UsedUserID,Nullable<DateTime> UsedDate,Nullable<SByte> UsedFlag)
		{

			try
			{
				DbCommand oDbCommand = db.CreateCommand("UPDATE [TAB2CDiscount] SET [CodeDiscount]=@CodeDiscount,[Checksum]=@Checksum,[DiscountPresent]=@DiscountPresent,[DiscountAmount]=@DiscountAmount,[ForUserWebID]=@ForUserWebID,[BrokerCode]=@BrokerCode,[GroupBrokerId]=@GroupBrokerId,[GeneratedUse]=@GeneratedUse,[GeneratedDate]=@GeneratedDate,[JobNo]=@JobNo,[UsedUserID]=@UsedUserID,[UsedDate]=@UsedDate,[UsedFlag]=@UsedFlag WHERE [ID]=@ID",CommandType.Text);
				if (CodeDiscount!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@CodeDiscount",DbType.String,CodeDiscount));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@CodeDiscount",DbType.String,DBNull.Value));
				if (Checksum.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@Checksum",DbType.Int32,Checksum));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Checksum",DbType.Int32,DBNull.Value));
				if (DiscountPresent.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@DiscountPresent",DbType.Int32,DiscountPresent));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@DiscountPresent",DbType.Int32,DBNull.Value));
				if (DiscountAmount.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@DiscountAmount",DbType.Int32,DiscountAmount));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@DiscountAmount",DbType.Int32,DBNull.Value));
				if (ForUserWebID!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ForUserWebID",DbType.String,ForUserWebID));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ForUserWebID",DbType.String,DBNull.Value));
				if (BrokerCode!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@BrokerCode",DbType.String,BrokerCode));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@BrokerCode",DbType.String,DBNull.Value));
				if (GroupBrokerId!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@GroupBrokerId",DbType.String,GroupBrokerId));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@GroupBrokerId",DbType.String,DBNull.Value));
				if (GeneratedUse!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@GeneratedUse",DbType.String,GeneratedUse));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@GeneratedUse",DbType.String,DBNull.Value));
				if (GeneratedDate.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@GeneratedDate",DbType.DateTime,GeneratedDate));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@GeneratedDate",DbType.DateTime,DBNull.Value));
				if (JobNo!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@JobNo",DbType.String,JobNo));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@JobNo",DbType.String,DBNull.Value));
				if (UsedUserID!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@UsedUserID",DbType.String,UsedUserID));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@UsedUserID",DbType.String,DBNull.Value));
				if (UsedDate.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@UsedDate",DbType.DateTime,UsedDate));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@UsedDate",DbType.DateTime,DBNull.Value));
				if (UsedFlag.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@UsedFlag",DbType.SByte,UsedFlag));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@UsedFlag",DbType.SByte,DBNull.Value));
				oDbCommand.Parameters.Add(db.CreateParameter("@ID",DbType.Int32,ID));
				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public int RemoveTAB2CDiscount(int ID)
		{

			try
			{
				DbCommand oDbCommand = db.CreateCommand("DELETE FROM [TAB2CDiscount] WHERE [ID]=@ID",CommandType.Text);
				oDbCommand.Parameters.Add(db.CreateParameter("@ID",DbType.Int32,ID));
				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

        public int spTAB2C_SetDiscount(string CodeDiscount, int Checksum, int DiscountPresent, int DiscountAmount, string ForUserWebID, string BrokerCode, string GroupBrokerId, string GeneratedUse)
        {
            try
            {
                DbCommand oDbCommand = db.CreateCommand("spTAB2C_SetDiscount", CommandType.StoredProcedure);
                oDbCommand.Parameters.Add(db.CreateParameter("@CodeDiscount", DbType.String, CodeDiscount));
                oDbCommand.Parameters.Add(db.CreateParameter("@Checksum", DbType.Int32, Checksum));
                oDbCommand.Parameters.Add(db.CreateParameter("@DiscountPresent", DbType.Int32, DiscountPresent));
                oDbCommand.Parameters.Add(db.CreateParameter("@DiscountAmount", DbType.Int32, DiscountAmount));

                if (ForUserWebID != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ForUserWebID", DbType.String, ForUserWebID));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ForUserWebID", DbType.String, DBNull.Value));
                if (BrokerCode != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@BrokerCode", DbType.String, BrokerCode));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@BrokerCode", DbType.String, DBNull.Value));
                if (GroupBrokerId != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@GroupBrokerId", DbType.String, GroupBrokerId));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@GroupBrokerId", DbType.String, DBNull.Value));                

                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        public int spTAB2C_SetUseDiscount(string JobNo, string CodeDiscount, string UserID)
        {
            try
            {
                DbCommand oDbCommand = db.CreateCommand("spTAB2C_SetUseDiscount", CommandType.StoredProcedure);
                oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, JobNo));
                oDbCommand.Parameters.Add(db.CreateParameter("@CodeDiscount", DbType.String, CodeDiscount));
                oDbCommand.Parameters.Add(db.CreateParameter("@UserID", DbType.String, UserID));
                                
                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public int spTAB2C_SetUseDiscount(string JobNo, string CodeDiscount, string UserID, DbTransaction dbTransaction)
        {
            try
            {
                DbCommand oDbCommand = db.CreateCommand("spTAB2C_SetUseDiscount", CommandType.StoredProcedure, dbTransaction);
                oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, JobNo));
                oDbCommand.Parameters.Add(db.CreateParameter("@CodeDiscount", DbType.String, CodeDiscount));
                oDbCommand.Parameters.Add(db.CreateParameter("@UserID", DbType.String, UserID));

                return db.ExecuteNonQuery(oDbCommand, true);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
	}
}
