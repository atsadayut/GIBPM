using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;

namespace TA.DAL
{
	public class TAB2CPolicyNoDAO
	{
        DbProviderHelper db;

		public TAB2CPolicyNoDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}
		public List<TAB2CPolicyNo> GetTAB2CPolicyNos()
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<TAB2CPolicyNo> lstTAB2CPolicyNos = new List<TAB2CPolicyNo>();
				DbCommand oDbCommand = db.CreateCommand("SELECT [PREFIX],[RUNNING] FROM [TAB2CPolicyNo]",CommandType.Text);
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					TAB2CPolicyNo oTAB2CPolicyNo = new TAB2CPolicyNo();
					oTAB2CPolicyNo.PREFIX = Convert.ToString(oDbDataReader["PREFIX"]);
					oTAB2CPolicyNo.RUNNING = Convert.ToInt32(oDbDataReader["RUNNING"]);
					lstTAB2CPolicyNos.Add(oTAB2CPolicyNo);
				}
				oDbDataReader.Close();
				return lstTAB2CPolicyNos;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}
		public TAB2CPolicyNo GetTAB2CPolicyNo(string PREFIX,int RUNNING)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				TAB2CPolicyNo oTAB2CPolicyNo = new TAB2CPolicyNo();
				DbCommand oDbCommand = db.CreateCommand("SELECT [PREFIX],[RUNNING] FROM [TAB2CPolicyNo] WHERE [PREFIX]=@PREFIX AND [RUNNING]=@RUNNING",CommandType.Text);
				oDbCommand.Parameters.Add(db.CreateParameter("@PREFIX",DbType.String,PREFIX));
				oDbCommand.Parameters.Add(db.CreateParameter("@RUNNING",DbType.Int32,RUNNING));
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oTAB2CPolicyNo.PREFIX = Convert.ToString(oDbDataReader["PREFIX"]);
					oTAB2CPolicyNo.RUNNING = Convert.ToInt32(oDbDataReader["RUNNING"]);
				}
				oDbDataReader.Close();
				return oTAB2CPolicyNo;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}
		public int AddTAB2CPolicyNo(string PREFIX,int RUNNING)
		{
			try
			{
				DbCommand oDbCommand = db.CreateCommand("INSERT INTO [TAB2CPolicyNo]()VALUES()",CommandType.Text);

				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public int RemoveTAB2CPolicyNo(string PREFIX,int RUNNING)
		{

			try
			{
				DbCommand oDbCommand = db.CreateCommand("DELETE FROM [TAB2CPolicyNo] WHERE [PREFIX]=@PREFIX AND [RUNNING]=@RUNNING",CommandType.Text);
				oDbCommand.Parameters.Add(db.CreateParameter("@PREFIX",DbType.String,PREFIX));
				oDbCommand.Parameters.Add(db.CreateParameter("@RUNNING",DbType.Int32,RUNNING));
				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

        public string spTAB2C_SetPolicyNo()
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = db.CreateCommand("spTAB2C_SetPolicyNo", CommandType.StoredProcedure);

                // create parameter and direction
                DbParameter param = comm.CreateParameter();
                param.ParameterName = "@PolicyNo";
                param.DbType = DbType.String;
                param.Size = 20;
                param.Direction = ParameterDirection.Output;
                comm.Parameters.Add(param);

                //execute command
                int ret = db.ExecuteNonQuery(comm);

                //return jobno
                return param.Value.ToString();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public string spTAB2C_SetPolicyNo(string JobNo)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = db.CreateCommand("spTAB2C_SetPolicyNoByJobNo", CommandType.StoredProcedure);

                // create parameter and direction
                DbParameter param = comm.CreateParameter();
                param.ParameterName = "@PolicyNo";
                param.DbType = DbType.String;
                param.Size = 20;
                param.Direction = ParameterDirection.Output;
                comm.Parameters.Add(param);

                DbParameter param2 = comm.CreateParameter();
                param2.ParameterName = "@JobNo";
                param2.DbType = DbType.String;
                param2.Size = 200;
                param2.Value = JobNo;
                param2.Direction = ParameterDirection.Input;
                comm.Parameters.Add(param2);

                //execute command
                int ret = db.ExecuteNonQuery(comm);

                //return jobno
                return param.Value.ToString();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public int spTAB2C_UpdatePolicyNoToJobNo(string JobNo, string PolicyNo, string RETURNINV)
        {
            try
            {
                DbCommand oDbCommand = db.CreateCommand("UPDATE [TATransPolicy] SET [PolicyNo]=@PolicyNo, [RETURNINV] = @RETURNINV WHERE [JobNo] = @JobNo", CommandType.Text);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (PolicyNo != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PolicyNo", DbType.String, PolicyNo));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PolicyNo", DbType.String, DBNull.Value));

                if (RETURNINV != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@RETURNINV", DbType.String, RETURNINV));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@RETURNINV", DbType.String, DBNull.Value));

                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //Krit Update 20150317
        public DataTable spTAB2C_FindPolicyNoByRef(string RETURNINV)
        {
            DbDataReader oDbDataReader = null;
            try
            {
                DataTable result = new DataTable();
                DbCommand oDbCommand = db.CreateCommand("SELECT [PolicyNo],[PolicyType],[InsurancePlan] FROM [TATransPolicy] where RETURNINV = @RETURNINV", CommandType.Text);
                oDbCommand.Parameters.Add(db.CreateParameter("@RETURNINV", DbType.String, RETURNINV));
                oDbDataReader = db.ExecuteReader(oDbCommand);

                result.Load(oDbDataReader);
                
                oDbDataReader.Close();

                return result;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

	}
}
