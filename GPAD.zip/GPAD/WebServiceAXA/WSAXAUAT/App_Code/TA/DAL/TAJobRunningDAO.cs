using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;

namespace TA.DAL
{
	public class TAJobRunningDAO
	{
        DbProviderHelper db;

		public TAJobRunningDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}
		public List<TAJobRunning> GetTAJobRunnings()
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<TAJobRunning> lstTAJobRunnings = new List<TAJobRunning>();
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					TAJobRunning oTAJobRunning = new TAJobRunning();
					oTAJobRunning.PREFIX = Convert.ToString(oDbDataReader["PREFIX"]);
					oTAJobRunning.YEAR = Convert.ToInt32(oDbDataReader["YEAR"]);
					oTAJobRunning.MONTH = Convert.ToInt32(oDbDataReader["MONTH"]);

					if(oDbDataReader["RUNNING"] != DBNull.Value)
						oTAJobRunning.RUNNING = Convert.ToString(oDbDataReader["RUNNING"]);
					lstTAJobRunnings.Add(oTAJobRunning);
				}
				oDbDataReader.Close();
				return lstTAJobRunnings;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public TAJobRunning GetTAJobRunning(string PREFIX,int YEAR,int MONTH)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				TAJobRunning oTAJobRunning = new TAJobRunning();
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
				oDbCommand.Parameters.Add(db.CreateParameter("@PREFIX",DbType.String,PREFIX));
				oDbCommand.Parameters.Add(db.CreateParameter("@YEAR",DbType.Int32,YEAR));
				oDbCommand.Parameters.Add(db.CreateParameter("@MONTH",DbType.Int32,MONTH));
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oTAJobRunning.PREFIX = Convert.ToString(oDbDataReader["PREFIX"]);
					oTAJobRunning.YEAR = Convert.ToInt32(oDbDataReader["YEAR"]);
					oTAJobRunning.MONTH = Convert.ToInt32(oDbDataReader["MONTH"]);

					if(oDbDataReader["RUNNING"] != DBNull.Value)
						oTAJobRunning.RUNNING = Convert.ToString(oDbDataReader["RUNNING"]);
				}
				oDbDataReader.Close();
				return oTAJobRunning;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public int AddTAJobRunning(string PREFIX,int YEAR,int MONTH,string RUNNING)
		{
            try
            {
                DbCommand oDbCommand = db.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
		}
		public int UpdateTAJobRunning(string PREFIX,int YEAR,int MONTH,string RUNNING)
		{
            try
            {
                DbCommand oDbCommand = db.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
		}
		public int RemoveTAJobRunning(string PREFIX,int YEAR,int MONTH)
		{
            try
            {
                DbCommand oDbCommand = db.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
		}


        /// <summary>
        /// GET/SET JOBNO
        /// </summary>
        /// <returns></returns>
        public string GetTAJobRunningNumber()
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = db.CreateCommand("spTA_SetJobNo", CommandType.StoredProcedure);

                // create parameter and direction
                DbParameter param = comm.CreateParameter();
                param.ParameterName = "@GetJobNo";
                param.DbType = DbType.String;
                param.Size = 20;
                param.Direction = ParameterDirection.Output;
                comm.Parameters.Add(param);

                //execute command
                int ret = db.ExecuteNonQuery(comm);

                //return jobno
                return param.Value.ToString();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public string GetTAJobRunningNumber(DbTransaction dbTransaction)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = db.CreateCommand("spTA_SetJobNo", CommandType.StoredProcedure, dbTransaction);

                // create parameter and direction
                DbParameter param = comm.CreateParameter();
                param.ParameterName = "@GetJobNo";
                param.DbType = DbType.String;
                param.Size = 20;
                param.Direction = ParameterDirection.Output;
                comm.Parameters.Add(param);

                //execute command
                int ret = db.ExecuteNonQuery(comm);

                //return jobno
                return param.Value.ToString();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
	}
}
