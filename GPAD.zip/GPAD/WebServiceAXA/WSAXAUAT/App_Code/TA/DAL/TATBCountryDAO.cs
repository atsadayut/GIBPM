using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;

namespace TA.DAL
{
	public class TATBCountryDAO
	{
        DbProviderHelper db;

		public TATBCountryDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}
		public List<TATBCountry> GetTATBCountrys()
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<TATBCountry> lstTATBCountrys = new List<TATBCountry>();
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					TATBCountry oTATBCountry = new TATBCountry();
					oTATBCountry.CountryCode = Convert.ToString(oDbDataReader["CountryCode"]);

					if(oDbDataReader["CountryName"] != DBNull.Value)
						oTATBCountry.CountryName = Convert.ToString(oDbDataReader["CountryName"]);

					if(oDbDataReader["isEnable"] != DBNull.Value)
						oTATBCountry.isEnable = Convert.ToSByte(oDbDataReader["isEnable"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oTATBCountry.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);
					lstTATBCountrys.Add(oTATBCountry);
				}
				oDbDataReader.Close();
				return lstTATBCountrys;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public TATBCountry GetTATBCountry(string CountryCode)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				TATBCountry oTATBCountry = new TATBCountry();
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
				oDbCommand.Parameters.Add(db.CreateParameter("@CountryCode",DbType.String,CountryCode));
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oTATBCountry.CountryCode = Convert.ToString(oDbDataReader["CountryCode"]);

					if(oDbDataReader["CountryName"] != DBNull.Value)
						oTATBCountry.CountryName = Convert.ToString(oDbDataReader["CountryName"]);

					if(oDbDataReader["isEnable"] != DBNull.Value)
						oTATBCountry.isEnable = Convert.ToSByte(oDbDataReader["isEnable"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oTATBCountry.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);
				}
				oDbDataReader.Close();
				return oTATBCountry;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public int AddTATBCountry(string CountryCode,string CountryName,Nullable<SByte> isEnable,Nullable<DateTime> CreateDate)
		{
			try
			{
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
                //Add Parameters 
				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public int UpdateTATBCountry(string CountryCode,string CountryName,Nullable<SByte> isEnable,Nullable<DateTime> CreateDate)
		{
			try
			{
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
                //Add Parameters 
				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public int RemoveTATBCountry(string CountryCode)
		{
			try
			{
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
                //Add Parameters 
				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}

        /// <summary>
        /// INSERT/UPDATE
        /// </summary>
        /// <param name="CountryCode"></param>
        /// <param name="CountryName"></param>
        /// <param name="isEnable"></param>
        /// <param name="CreateDate"></param>
        /// <returns></returns>
        public int SetTATBCountry(string CountryCode, string CountryName, Nullable<SByte> isEnable, Nullable<DateTime> CreateDate)
        {

            try
            {
                DbCommand oDbCommand = db.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        ////------------------------------SET ------------------------------------------
        public int SetTATBCountry(string CountryCode, int isEnable )
        {

            try
            {
                DbCommand oDbCommand = db.CreateCommand("update [TATBCountry] SET [isEnable] = @isEnable,[CreateDate] = GETDATE()  where [CountryCode] = @CountryCode", CommandType.Text);
                //Add Parameters 
                if (CountryCode != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@CountryCode", DbType.String, CountryCode));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@CountryCode", DbType.String, DBNull.Value));
                if (isEnable != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@isEnable", DbType.Int16, isEnable));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@isEnable", DbType.Int16, DBNull.Value));
                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        /// <summary>
        /// GET
        /// </summary>
        /// <returns></returns>
        public DataTable GetDtTATBCountrys()
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = db.CreateCommand("spTA_GetCountry", CommandType.StoredProcedure);
                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return db.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        //-------------------------------------------
        public DataTable GetAllColumnTATBCountrys()
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = db.CreateCommand("select * from [TATBCountry] order by [CountryName]", CommandType.Text);
                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return db.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
	}
}
