using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;

namespace TA.DAL
{
	public class TATBAgentCodeDAO
	{
        DbProviderHelper db;

		public TATBAgentCodeDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}
		public List<TATBAgentCode> GetTATBAgentCodes()
		{
			try
			{                
                List<TATBAgentCode> lstTATBAgentCodes = new List<TATBAgentCode>();
                DbCommand oDbCommand = db.CreateCommand("SELECT [GroupID],[AgentCode],[Password],[Branch],[AgentName],[AccountType],[AccountTypeName],[AgentLicenseNo],[AgentStartDate],[AgentEndDate],[ModifiedDateTime],[LSurname],[LGivname] FROM [TATBAgentCode]", CommandType.Text);
                DbDataReader oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					TATBAgentCode oTATBAgentCode = new TATBAgentCode();

					if(oDbDataReader["GroupID"] != DBNull.Value)
						oTATBAgentCode.GroupID = Convert.ToString(oDbDataReader["GroupID"]);

					if(oDbDataReader["AgentCode"] != DBNull.Value)
						oTATBAgentCode.AgentCode = Convert.ToString(oDbDataReader["AgentCode"]);

					if(oDbDataReader["Password"] != DBNull.Value)
						oTATBAgentCode.Password = Convert.ToString(oDbDataReader["Password"]);

					if(oDbDataReader["Branch"] != DBNull.Value)
						oTATBAgentCode.Branch = Convert.ToString(oDbDataReader["Branch"]);

					if(oDbDataReader["AgentName"] != DBNull.Value)
						oTATBAgentCode.AgentName = Convert.ToString(oDbDataReader["AgentName"]);

					if(oDbDataReader["AccountType"] != DBNull.Value)
						oTATBAgentCode.AccountType = Convert.ToString(oDbDataReader["AccountType"]);

					if(oDbDataReader["AccountTypeName"] != DBNull.Value)
						oTATBAgentCode.AccountTypeName = Convert.ToString(oDbDataReader["AccountTypeName"]);

					if(oDbDataReader["AgentLicenseNo"] != DBNull.Value)
						oTATBAgentCode.AgentLicenseNo = Convert.ToString(oDbDataReader["AgentLicenseNo"]);

					if(oDbDataReader["AgentStartDate"] != DBNull.Value)
						oTATBAgentCode.AgentStartDate = Convert.ToInt32(oDbDataReader["AgentStartDate"]);

					if(oDbDataReader["AgentEndDate"] != DBNull.Value)
						oTATBAgentCode.AgentEndDate = Convert.ToInt32(oDbDataReader["AgentEndDate"]);

					if(oDbDataReader["ModifiedDateTime"] != DBNull.Value)
						oTATBAgentCode.ModifiedDateTime = Convert.ToString(oDbDataReader["ModifiedDateTime"]);

					if(oDbDataReader["LSurname"] != DBNull.Value)
						oTATBAgentCode.LSurname = Convert.ToString(oDbDataReader["LSurname"]);

					if(oDbDataReader["LGivname"] != DBNull.Value)
						oTATBAgentCode.LGivname = Convert.ToString(oDbDataReader["LGivname"]);
					lstTATBAgentCodes.Add(oTATBAgentCode);
				}
				oDbDataReader.Close();
				return lstTATBAgentCodes;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public int AddTATBAgentCode(string GroupID,string AgentCode,string Password,string Branch,string AgentName,string AccountType,string AccountTypeName,string AgentLicenseNo,Nullable<int> AgentStartDate,Nullable<int> AgentEndDate,string ModifiedDateTime,string LSurname,string LGivname)
		{
			try
			{                
                DbCommand oDbCommand = db.CreateCommand("INSERT INTO [TATBAgentCode]([GroupID],[AgentCode],[Password],[Branch],[AgentName],[AccountType],[AccountTypeName],[AgentLicenseNo],[AgentStartDate],[AgentEndDate],[ModifiedDateTime],[LSurname],[LGivname])VALUES(@GroupID,@AgentCode,@Password,@Branch,@AgentName,@AccountType,@AccountTypeName,@AgentLicenseNo,@AgentStartDate,@AgentEndDate,@ModifiedDateTime,@LSurname,@LGivname)", CommandType.Text);
				if (GroupID!=null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@GroupID", DbType.String, GroupID));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@GroupID", DbType.String, DBNull.Value));
				if (AgentCode!=null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@AgentCode", DbType.String, AgentCode));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@AgentCode", DbType.String, DBNull.Value));
				if (Password!=null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Password", DbType.String, Password));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Password", DbType.String, DBNull.Value));
				if (Branch!=null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Branch", DbType.String, Branch));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Branch", DbType.String, DBNull.Value));
				if (AgentName!=null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@AgentName", DbType.String, AgentName));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@AgentName", DbType.String, DBNull.Value));
				if (AccountType!=null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@AccountType", DbType.String, AccountType));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@AccountType", DbType.String, DBNull.Value));
				if (AccountTypeName!=null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@AccountTypeName", DbType.String, AccountTypeName));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@AccountTypeName", DbType.String, DBNull.Value));
				if (AgentLicenseNo!=null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@AgentLicenseNo", DbType.String, AgentLicenseNo));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@AgentLicenseNo", DbType.String, DBNull.Value));
				if (AgentStartDate.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@AgentStartDate", DbType.Int32, AgentStartDate));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@AgentStartDate", DbType.Int32, DBNull.Value));
				if (AgentEndDate.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@AgentEndDate", DbType.Int32, AgentEndDate));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@AgentEndDate", DbType.Int32, DBNull.Value));
				if (ModifiedDateTime!=null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ModifiedDateTime", DbType.String, ModifiedDateTime));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ModifiedDateTime", DbType.String, DBNull.Value));
				if (LSurname!=null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LSurname", DbType.String, LSurname));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LSurname", DbType.String, DBNull.Value));
				if (LGivname!=null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LGivname", DbType.String, LGivname));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LGivname", DbType.String, DBNull.Value));

                return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

        public TATBAgentCode spTAB2C_GetAgentCode(string GroupID, string AgentCode)
        {
            try
            {
                TATBAgentCode oTATBAgentCode = new TATBAgentCode();

                DbCommand oDbCommand = db.CreateCommand("spTAB2C_GetAgentCode", CommandType.StoredProcedure);
                oDbCommand.Parameters.Add(db.CreateParameter("@GroupID", DbType.String, GroupID));
                oDbCommand.Parameters.Add(db.CreateParameter("@AgentCode", DbType.String, AgentCode));

                DbDataReader oDbDataReader = db.ExecuteReader(oDbCommand);
                while (oDbDataReader.Read())
                {
                    //TATBAgentCode oTATBAgentCode = new TATBAgentCode();

                    if (oDbDataReader["GroupID"] != DBNull.Value)
                        oTATBAgentCode.GroupID = Convert.ToString(oDbDataReader["GroupID"]);

                    if (oDbDataReader["AgentCode"] != DBNull.Value)
                        oTATBAgentCode.AgentCode = Convert.ToString(oDbDataReader["AgentCode"]);

                    if (oDbDataReader["Password"] != DBNull.Value)
                        oTATBAgentCode.Password = Convert.ToString(oDbDataReader["Password"]);

                    if (oDbDataReader["Branch"] != DBNull.Value)
                        oTATBAgentCode.Branch = Convert.ToString(oDbDataReader["Branch"]);

                    if (oDbDataReader["AgentName"] != DBNull.Value)
                        oTATBAgentCode.AgentName = Convert.ToString(oDbDataReader["AgentName"]);

                    if (oDbDataReader["AccountType"] != DBNull.Value)
                        oTATBAgentCode.AccountType = Convert.ToString(oDbDataReader["AccountType"]);

                    if (oDbDataReader["AccountTypeName"] != DBNull.Value)
                        oTATBAgentCode.AccountTypeName = Convert.ToString(oDbDataReader["AccountTypeName"]);

                    if (oDbDataReader["AgentLicenseNo"] != DBNull.Value)
                        oTATBAgentCode.AgentLicenseNo = Convert.ToString(oDbDataReader["AgentLicenseNo"]);

                    if (oDbDataReader["AgentStartDate"] != DBNull.Value)
                        oTATBAgentCode.AgentStartDate = Convert.ToInt32(oDbDataReader["AgentStartDate"]);

                    if (oDbDataReader["AgentEndDate"] != DBNull.Value)
                        oTATBAgentCode.AgentEndDate = Convert.ToInt32(oDbDataReader["AgentEndDate"]);

                    if (oDbDataReader["ModifiedDateTime"] != DBNull.Value)
                        oTATBAgentCode.ModifiedDateTime = Convert.ToString(oDbDataReader["ModifiedDateTime"]);

                    if (oDbDataReader["LSurname"] != DBNull.Value)
                        oTATBAgentCode.LSurname = Convert.ToString(oDbDataReader["LSurname"]);

                    if (oDbDataReader["LGivname"] != DBNull.Value)
                        oTATBAgentCode.LGivname = Convert.ToString(oDbDataReader["LGivname"]);
                    //lstTATBAgentCodes.Add(oTATBAgentCode);
                }
                oDbDataReader.Close();

                return oTATBAgentCode;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int spTAB2C_SetAgentCode(string GroupID, string AgentCode, string Password, string Branch, string AgentName, string AccountType, string AccountTypeName, string AgentLicenseNo, Nullable<int> AgentStartDate, Nullable<int> AgentEndDate, string LSurname, string LGivname)
        {
            try
            {
                DbCommand oDbCommand = db.CreateCommand("spTAB2C_SetAgentCode", CommandType.StoredProcedure);
                if (GroupID != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@GroupID", DbType.String, GroupID));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@GroupID", DbType.String, DBNull.Value));
                if (AgentCode != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@AgentCode", DbType.String, AgentCode));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@AgentCode", DbType.String, DBNull.Value));
                if (Password != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Password", DbType.String, Password));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Password", DbType.String, DBNull.Value));
                if (Branch != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Branch", DbType.String, Branch));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Branch", DbType.String, DBNull.Value));
                if (AgentName != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@AgentName", DbType.String, AgentName));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@AgentName", DbType.String, DBNull.Value));
                if (AccountType != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@AccountType", DbType.String, AccountType));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@AccountType", DbType.String, DBNull.Value));
                if (AccountTypeName != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@AccountTypeName", DbType.String, AccountTypeName));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@AccountTypeName", DbType.String, DBNull.Value));
                if (AgentLicenseNo != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@AgentLicenseNo", DbType.String, AgentLicenseNo));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@AgentLicenseNo", DbType.String, DBNull.Value));
                if (AgentStartDate.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@AgentStartDate", DbType.Int32, AgentStartDate));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@AgentStartDate", DbType.Int32, DBNull.Value));
                if (AgentEndDate.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@AgentEndDate", DbType.Int32, AgentEndDate));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@AgentEndDate", DbType.Int32, DBNull.Value));
                if (LSurname != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LSurname", DbType.String, LSurname));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LSurname", DbType.String, DBNull.Value));
                if (LGivname != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LGivname", DbType.String, LGivname));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LGivname", DbType.String, DBNull.Value));

                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
	}
}
