using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;

namespace TA.DAL
{
	public class TATransPolicyHolderDAO
	{
        DbProviderHelper db;

		public TATransPolicyHolderDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}
		public List<TATransPolicyHolder> GetTATransPolicyHolders()
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<TATransPolicyHolder> lstTATransPolicyHolders = new List<TATransPolicyHolder>();
				DbCommand oDbCommand = db.CreateCommand("SELECTTATransPolicyHolders",CommandType.StoredProcedure);
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					TATransPolicyHolder oTATransPolicyHolder = new TATransPolicyHolder();
					oTATransPolicyHolder.JobNo = Convert.ToString(oDbDataReader["JobNo"]);

					if(oDbDataReader["ClientCode"] != DBNull.Value)
						oTATransPolicyHolder.ClientCode = Convert.ToString(oDbDataReader["ClientCode"]);

					if(oDbDataReader["ClientType"] != DBNull.Value)
						oTATransPolicyHolder.ClientType = Convert.ToString(oDbDataReader["ClientType"]);

					if(oDbDataReader["ClientTitle"] != DBNull.Value)
						oTATransPolicyHolder.ClientTitle = Convert.ToString(oDbDataReader["ClientTitle"]);

					if(oDbDataReader["ClientName"] != DBNull.Value)
						oTATransPolicyHolder.ClientName = Convert.ToString(oDbDataReader["ClientName"]);

					if(oDbDataReader["ClientSurName"] != DBNull.Value)
						oTATransPolicyHolder.ClientSurName = Convert.ToString(oDbDataReader["ClientSurName"]);

					if(oDbDataReader["ClientAddress1"] != DBNull.Value)
						oTATransPolicyHolder.ClientAddress1 = Convert.ToString(oDbDataReader["ClientAddress1"]);

					if(oDbDataReader["ClientAddress2"] != DBNull.Value)
						oTATransPolicyHolder.ClientAddress2 = Convert.ToString(oDbDataReader["ClientAddress2"]);

					if(oDbDataReader["Province"] != DBNull.Value)
						oTATransPolicyHolder.Province = Convert.ToString(oDbDataReader["Province"]);

					if(oDbDataReader["Amphur"] != DBNull.Value)
						oTATransPolicyHolder.Amphur = Convert.ToString(oDbDataReader["Amphur"]);

					if(oDbDataReader["Tumbol"] != DBNull.Value)
						oTATransPolicyHolder.Tumbol = Convert.ToString(oDbDataReader["Tumbol"]);

					if(oDbDataReader["PostCode"] != DBNull.Value)
						oTATransPolicyHolder.PostCode = Convert.ToString(oDbDataReader["PostCode"]);

					if(oDbDataReader["CountryCode"] != DBNull.Value)
						oTATransPolicyHolder.CountryCode = Convert.ToString(oDbDataReader["CountryCode"]);

					if(oDbDataReader["Birthday"] != DBNull.Value)
						oTATransPolicyHolder.Birthday = Convert.ToString(oDbDataReader["Birthday"]);

					if(oDbDataReader["ClientSEX"] != DBNull.Value)
						oTATransPolicyHolder.ClientSEX = Convert.ToString(oDbDataReader["ClientSEX"]);

					if(oDbDataReader["ClientStatus"] != DBNull.Value)
						oTATransPolicyHolder.ClientStatus = Convert.ToString(oDbDataReader["ClientStatus"]);

					if(oDbDataReader["PassportID"] != DBNull.Value)
						oTATransPolicyHolder.PassportID = Convert.ToString(oDbDataReader["PassportID"]);

					if(oDbDataReader["IDCard"] != DBNull.Value)
						oTATransPolicyHolder.IDCard = Convert.ToString(oDbDataReader["IDCard"]);

					if(oDbDataReader["TaxID"] != DBNull.Value)
						oTATransPolicyHolder.TaxID = Convert.ToString(oDbDataReader["TaxID"]);

					if(oDbDataReader["Tel"] != DBNull.Value)
						oTATransPolicyHolder.Tel = Convert.ToString(oDbDataReader["Tel"]);

					if(oDbDataReader["Email"] != DBNull.Value)
						oTATransPolicyHolder.Email = Convert.ToString(oDbDataReader["Email"]);
                    
                    if (oDbDataReader["Language"] != DBNull.Value)
                        oTATransPolicyHolder.Language = Convert.ToString(oDbDataReader["Language"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oTATransPolicyHolder.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);
					lstTATransPolicyHolders.Add(oTATransPolicyHolder);
				}
				oDbDataReader.Close();
				return lstTATransPolicyHolders;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public TATransPolicyHolder GetTATransPolicyHolder(string JobNo)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				TATransPolicyHolder oTATransPolicyHolder = new TATransPolicyHolder();
                DbCommand oDbCommand = db.CreateCommand("spTA_GetBindPolicyHolder", CommandType.StoredProcedure);
				oDbCommand.Parameters.Add(db.CreateParameter("@JobNo",DbType.String,JobNo));
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oTATransPolicyHolder.JobNo = Convert.ToString(oDbDataReader["JobNo"]);

					if(oDbDataReader["ClientCode"] != DBNull.Value)
						oTATransPolicyHolder.ClientCode = Convert.ToString(oDbDataReader["ClientCode"]);

					if(oDbDataReader["ClientType"] != DBNull.Value)
						oTATransPolicyHolder.ClientType = Convert.ToString(oDbDataReader["ClientType"]);

					if(oDbDataReader["ClientTitle"] != DBNull.Value)
						oTATransPolicyHolder.ClientTitle = Convert.ToString(oDbDataReader["ClientTitle"]);

					if(oDbDataReader["ClientName"] != DBNull.Value)
						oTATransPolicyHolder.ClientName = Convert.ToString(oDbDataReader["ClientName"]);

					if(oDbDataReader["ClientSurName"] != DBNull.Value)
						oTATransPolicyHolder.ClientSurName = Convert.ToString(oDbDataReader["ClientSurName"]);

					if(oDbDataReader["ClientAddress1"] != DBNull.Value)
						oTATransPolicyHolder.ClientAddress1 = Convert.ToString(oDbDataReader["ClientAddress1"]);

					if(oDbDataReader["ClientAddress2"] != DBNull.Value)
						oTATransPolicyHolder.ClientAddress2 = Convert.ToString(oDbDataReader["ClientAddress2"]);

					if(oDbDataReader["Province"] != DBNull.Value)
						oTATransPolicyHolder.Province = Convert.ToString(oDbDataReader["Province"]);

					if(oDbDataReader["Amphur"] != DBNull.Value)
						oTATransPolicyHolder.Amphur = Convert.ToString(oDbDataReader["Amphur"]);

					if(oDbDataReader["Tumbol"] != DBNull.Value)
						oTATransPolicyHolder.Tumbol = Convert.ToString(oDbDataReader["Tumbol"]);

					if(oDbDataReader["PostCode"] != DBNull.Value)
						oTATransPolicyHolder.PostCode = Convert.ToString(oDbDataReader["PostCode"]);

					if(oDbDataReader["Birthday"] != DBNull.Value)
						oTATransPolicyHolder.Birthday = Convert.ToString(oDbDataReader["Birthday"]);

					if(oDbDataReader["PassportID"] != DBNull.Value)
						oTATransPolicyHolder.PassportID = Convert.ToString(oDbDataReader["PassportID"]);

					if(oDbDataReader["IDCard"] != DBNull.Value)
						oTATransPolicyHolder.IDCard = Convert.ToString(oDbDataReader["IDCard"]);

					if(oDbDataReader["TaxID"] != DBNull.Value)
						oTATransPolicyHolder.TaxID = Convert.ToString(oDbDataReader["TaxID"]);

					if(oDbDataReader["Tel"] != DBNull.Value)
						oTATransPolicyHolder.Tel = Convert.ToString(oDbDataReader["Tel"]);

					if(oDbDataReader["Email"] != DBNull.Value)
						oTATransPolicyHolder.Email = Convert.ToString(oDbDataReader["Email"]);

                    if (oDbDataReader["Language"] != DBNull.Value)
                        oTATransPolicyHolder.Language = Convert.ToString(oDbDataReader["Language"]);
				}
				oDbDataReader.Close();
				return oTATransPolicyHolder;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public int AddTATransPolicyHolder(string JobNo,string ClientCode,string ClientType,string ClientTitle,string ClientName,string ClientSurName,string ClientAddress1,string ClientAddress2,string Province,string Amphur,string Tumbol,string PostCode,string CountryCode,string Birthday,string ClientSEX,string ClientStatus,string PassportID,string IDCard,string TaxID,string Tel,string Email,Nullable<DateTime> CreateDate)
		{
			try
			{
				DbCommand oDbCommand = db.CreateCommand("INSERTTATransPolicyHolder",CommandType.StoredProcedure);
				if (ClientCode!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientCode",DbType.String,ClientCode));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientCode",DbType.String,DBNull.Value));
				if (ClientType!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientType",DbType.String,ClientType));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientType",DbType.String,DBNull.Value));
				if (ClientTitle!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle",DbType.String,ClientTitle));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle",DbType.String,DBNull.Value));
				if (ClientName!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientName",DbType.String,ClientName));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientName",DbType.String,DBNull.Value));
				if (ClientSurName!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName",DbType.String,ClientSurName));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName",DbType.String,DBNull.Value));
				if (ClientAddress1!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress1",DbType.String,ClientAddress1));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress1",DbType.String,DBNull.Value));
				if (ClientAddress2!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress2",DbType.String,ClientAddress2));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress2",DbType.String,DBNull.Value));
				if (Province!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Province",DbType.String,Province));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Province",DbType.String,DBNull.Value));
				if (Amphur!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Amphur",DbType.String,Amphur));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Amphur",DbType.String,DBNull.Value));
				if (Tumbol!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Tumbol",DbType.String,Tumbol));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Tumbol",DbType.String,DBNull.Value));
				if (PostCode!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@PostCode",DbType.String,PostCode));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@PostCode",DbType.String,DBNull.Value));
				if (CountryCode!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@CountryCode",DbType.String,CountryCode));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@CountryCode",DbType.String,DBNull.Value));
				if (Birthday!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Birthday",DbType.String,Birthday));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Birthday",DbType.String,DBNull.Value));
				if (ClientSEX!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientSEX",DbType.String,ClientSEX));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientSEX",DbType.String,DBNull.Value));
				if (ClientStatus!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientStatus",DbType.String,ClientStatus));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientStatus",DbType.String,DBNull.Value));
				if (PassportID!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@PassportID",DbType.String,PassportID));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@PassportID",DbType.String,DBNull.Value));
				if (IDCard!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@IDCard",DbType.String,IDCard));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@IDCard",DbType.String,DBNull.Value));
				if (TaxID!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@TaxID",DbType.String,TaxID));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@TaxID",DbType.String,DBNull.Value));
				if (Tel!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Tel",DbType.String,Tel));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Tel",DbType.String,DBNull.Value));
				if (Email!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Email",DbType.String,Email));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Email",DbType.String,DBNull.Value));
				if (CreateDate.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@CreateDate",DbType.DateTime,CreateDate));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@CreateDate",DbType.DateTime,DBNull.Value));

				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public int UpdateTATransPolicyHolder(string JobNo,string ClientCode,string ClientType,string ClientTitle,string ClientName,string ClientSurName,string ClientAddress1,string ClientAddress2,string Province,string Amphur,string Tumbol,string PostCode,string CountryCode,string Birthday,string ClientSEX,string ClientStatus,string PassportID,string IDCard,string TaxID,string Tel,string Email,Nullable<DateTime> CreateDate)
		{

			try
			{
				DbCommand oDbCommand = db.CreateCommand("UPDATETATransPolicyHolder",CommandType.StoredProcedure);
				if (ClientCode!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientCode",DbType.String,ClientCode));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientCode",DbType.String,DBNull.Value));
				if (ClientType!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientType",DbType.String,ClientType));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientType",DbType.String,DBNull.Value));
				if (ClientTitle!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle",DbType.String,ClientTitle));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle",DbType.String,DBNull.Value));
				if (ClientName!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientName",DbType.String,ClientName));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientName",DbType.String,DBNull.Value));
				if (ClientSurName!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName",DbType.String,ClientSurName));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName",DbType.String,DBNull.Value));
				if (ClientAddress1!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress1",DbType.String,ClientAddress1));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress1",DbType.String,DBNull.Value));
				if (ClientAddress2!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress2",DbType.String,ClientAddress2));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress2",DbType.String,DBNull.Value));
				if (Province!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Province",DbType.String,Province));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Province",DbType.String,DBNull.Value));
				if (Amphur!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Amphur",DbType.String,Amphur));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Amphur",DbType.String,DBNull.Value));
				if (Tumbol!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Tumbol",DbType.String,Tumbol));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Tumbol",DbType.String,DBNull.Value));
				if (PostCode!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@PostCode",DbType.String,PostCode));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@PostCode",DbType.String,DBNull.Value));
				if (CountryCode!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@CountryCode",DbType.String,CountryCode));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@CountryCode",DbType.String,DBNull.Value));
				if (Birthday!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Birthday",DbType.String,Birthday));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Birthday",DbType.String,DBNull.Value));
				if (ClientSEX!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientSEX",DbType.String,ClientSEX));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientSEX",DbType.String,DBNull.Value));
				if (ClientStatus!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientStatus",DbType.String,ClientStatus));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientStatus",DbType.String,DBNull.Value));
				if (PassportID!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@PassportID",DbType.String,PassportID));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@PassportID",DbType.String,DBNull.Value));
				if (IDCard!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@IDCard",DbType.String,IDCard));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@IDCard",DbType.String,DBNull.Value));
				if (TaxID!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@TaxID",DbType.String,TaxID));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@TaxID",DbType.String,DBNull.Value));
				if (Tel!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Tel",DbType.String,Tel));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Tel",DbType.String,DBNull.Value));
				if (Email!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Email",DbType.String,Email));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Email",DbType.String,DBNull.Value));
				if (CreateDate.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@CreateDate",DbType.DateTime,CreateDate));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@CreateDate",DbType.DateTime,DBNull.Value));
				oDbCommand.Parameters.Add(db.CreateParameter("@JobNo",DbType.String,JobNo));
				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public int RemoveTATransPolicyHolder(string JobNo)
		{

			try
			{
				DbCommand oDbCommand = db.CreateCommand("DELETETATransPolicyHolder",CommandType.StoredProcedure);
				oDbCommand.Parameters.Add(db.CreateParameter("@JobNo",DbType.String,JobNo));
				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}

        /// <summary>
        /// INSERT/UPDATE
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="ClientCode"></param>
        /// <param name="ClientType"></param>
        /// <param name="ClientTitle"></param>
        /// <param name="ClientName"></param>
        /// <param name="ClientSurName"></param>
        /// <param name="ClientAddress1"></param>
        /// <param name="ClientAddress2"></param>
        /// <param name="Province"></param>
        /// <param name="Amphur"></param>
        /// <param name="Tumbol"></param>
        /// <param name="PostCode"></param>
        /// <param name="CountryCode"></param>
        /// <param name="Birthday"></param>
        /// <param name="ClientSEX"></param>
        /// <param name="ClientStatus"></param>
        /// <param name="PassportID"></param>
        /// <param name="IDCard"></param>
        /// <param name="TaxID"></param>
        /// <param name="Tel"></param>
        /// <param name="Email"></param>
        /// <param name="CreateDate"></param>
        /// <returns></returns>
        public int SetTATransPolicyHolder(string JobNo, string ClientType, string ClientTitle, string ClientName, string ClientSurName, string ClientAddress1, string ClientAddress2, string Province, string Amphur, string Tumbol, string PostCode, string Birthday, string IDCard, string Tel, string Email, string Language)
        {
            try
            {
                DbCommand oDbCommand = db.CreateCommand("spTA_SetTransPolicyHolder", CommandType.StoredProcedure);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                //if (ClientCode != null)
                //    oDbCommand.Parameters.Add(db.CreateParameter("@ClientCode", DbType.String, ClientCode));
                //else
                //    oDbCommand.Parameters.Add(db.CreateParameter("@ClientCode", DbType.String, DBNull.Value));
                if (ClientType != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientType", DbType.String, ClientType));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientType", DbType.String, DBNull.Value));
                if (ClientTitle != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle", DbType.String, ClientTitle));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle", DbType.String, DBNull.Value));
                if (ClientName != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientName", DbType.String, ClientName));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientName", DbType.String, DBNull.Value));
                if (ClientSurName != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName", DbType.String, ClientSurName));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName", DbType.String, DBNull.Value));
                if (ClientAddress1 != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress1", DbType.String, ClientAddress1));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress1", DbType.String, DBNull.Value));
                if (ClientAddress2 != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress2", DbType.String, ClientAddress2));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress2", DbType.String, DBNull.Value));
                if (Province != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Province", DbType.String, Province));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Province", DbType.String, DBNull.Value));
                if (Amphur != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Amphur", DbType.String, Amphur));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Amphur", DbType.String, DBNull.Value));
                if (Tumbol != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tumbol", DbType.String, Tumbol));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tumbol", DbType.String, DBNull.Value));
                if (PostCode != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PostCode", DbType.String, PostCode));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PostCode", DbType.String, DBNull.Value));
                //if (CountryCode != null)
                //    oDbCommand.Parameters.Add(db.CreateParameter("@CountryCode", DbType.String, CountryCode));
                //else
                //    oDbCommand.Parameters.Add(db.CreateParameter("@CountryCode", DbType.String, DBNull.Value));
                if (Birthday != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Birthday", DbType.String, Birthday));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Birthday", DbType.String, DBNull.Value));
                //if (ClientSEX != null)
                //    oDbCommand.Parameters.Add(db.CreateParameter("@ClientSEX", DbType.String, ClientSEX));
                //else
                //    oDbCommand.Parameters.Add(db.CreateParameter("@ClientSEX", DbType.String, DBNull.Value));
                //if (ClientStatus != null)
                //    oDbCommand.Parameters.Add(db.CreateParameter("@ClientStatus", DbType.String, ClientStatus));
                //else
                //    oDbCommand.Parameters.Add(db.CreateParameter("@ClientStatus", DbType.String, DBNull.Value));
                //if (PassportID != null)
                //    oDbCommand.Parameters.Add(db.CreateParameter("@PassportID", DbType.String, PassportID));
                //else
                //    oDbCommand.Parameters.Add(db.CreateParameter("@PassportID", DbType.String, DBNull.Value));
                if (IDCard != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@IDCard", DbType.String, IDCard));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@IDCard", DbType.String, DBNull.Value));
                //if (TaxID != null)
                //    oDbCommand.Parameters.Add(db.CreateParameter("@TaxID", DbType.String, TaxID));
                //else
                //    oDbCommand.Parameters.Add(db.CreateParameter("@TaxID", DbType.String, DBNull.Value));
                if (Tel != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tel", DbType.String, Tel));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tel", DbType.String, DBNull.Value));
                if (Email != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Email", DbType.String, Email));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Email", DbType.String, DBNull.Value));
                if (Language != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Language", DbType.String, Language));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Language", DbType.String, DBNull.Value));


                //if (CreateDate.HasValue)
                //    oDbCommand.Parameters.Add(db.CreateParameter("@CreateDate", DbType.DateTime, CreateDate));
                //else
                //    oDbCommand.Parameters.Add(db.CreateParameter("@CreateDate", DbType.DateTime, DBNull.Value));

                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        /// <summary>
        /// INSERT/UPDATE WIHT DBTRANSACTION
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="ClientCode"></param>
        /// <param name="ClientType"></param>
        /// <param name="ClientTitle"></param>
        /// <param name="ClientName"></param>
        /// <param name="ClientSurName"></param>
        /// <param name="ClientAddress1"></param>
        /// <param name="ClientAddress2"></param>
        /// <param name="Province"></param>
        /// <param name="Amphur"></param>
        /// <param name="Tumbol"></param>
        /// <param name="PostCode"></param>
        /// <param name="CountryCode"></param>
        /// <param name="Birthday"></param>
        /// <param name="ClientSEX"></param>
        /// <param name="ClientStatus"></param>
        /// <param name="PassportID"></param>
        /// <param name="IDCard"></param>
        /// <param name="TaxID"></param>
        /// <param name="Tel"></param>
        /// <param name="Email"></param>
        /// <param name="CreateDate"></param>
        /// <param name="dbTransaction"></param>
        /// <returns></returns>
        public int SetTATransPolicyHolder(string JobNo, string ClientType, string ClientTitle, string ClientName, string ClientSurName, string ClientAddress1, string ClientAddress2, string Province, string Amphur, string Tumbol, string PostCode, string Birthday, string IDCard, string Tel, string Email,string Lanuage,DbTransaction dbTransaction)
        {
            try
            {
                DbCommand oDbCommand = db.CreateCommand("spTA_SetTransPolicyHolder", CommandType.StoredProcedure,dbTransaction);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (ClientType != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientType", DbType.String, ClientType));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientType", DbType.String, DBNull.Value));
                if (ClientTitle != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle", DbType.String, ClientTitle));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle", DbType.String, DBNull.Value));
                if (ClientName != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientName", DbType.String, ClientName));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientName", DbType.String, DBNull.Value));
                if (ClientSurName != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName", DbType.String, ClientSurName));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName", DbType.String, DBNull.Value));
                if (ClientAddress1 != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress1", DbType.String, ClientAddress1));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress1", DbType.String, DBNull.Value));
                if (ClientAddress2 != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress2", DbType.String, ClientAddress2));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress2", DbType.String, DBNull.Value));
                if (Province != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Province", DbType.String, Province));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Province", DbType.String, DBNull.Value));
                if (Amphur != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Amphur", DbType.String, Amphur));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Amphur", DbType.String, DBNull.Value));
                if (Tumbol != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tumbol", DbType.String, Tumbol));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tumbol", DbType.String, DBNull.Value));
                if (PostCode != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PostCode", DbType.String, PostCode));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PostCode", DbType.String, DBNull.Value));
                if (Birthday != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Birthday", DbType.String, Birthday));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Birthday", DbType.String, DBNull.Value));
                if (IDCard != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@IDCard", DbType.String, IDCard));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@IDCard", DbType.String, DBNull.Value));
                if (Tel != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tel", DbType.String, Tel));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tel", DbType.String, DBNull.Value));
                if (Email != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Email", DbType.String, Email));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Email", DbType.String, DBNull.Value));

                if (Lanuage != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Language", DbType.String, Lanuage));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Language", DbType.String, DBNull.Value));
                
                return db.ExecuteNonQuery(oDbCommand,true);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        /// <summary>
        /// INSERT/UPDATE WIHT DBTRANSACTION
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="ClientCode"></param>
        /// <param name="ClientType"></param>
        /// <param name="ClientTitle"></param>
        /// <param name="ClientName"></param>
        /// <param name="ClientSurName"></param>
        /// <param name="ClientAddress1"></param>
        /// <param name="ClientAddress2"></param>
        /// <param name="Province"></param>
        /// <param name="Amphur"></param>
        /// <param name="Tumbol"></param>
        /// <param name="PostCode"></param>
        /// <param name="CountryCode"></param>
        /// <param name="Birthday"></param>
        /// <param name="ClientSEX"></param>
        /// <param name="ClientStatus"></param>
        /// <param name="PassportID"></param>
        /// <param name="IDCard"></param>
        /// <param name="TaxID"></param>
        /// <param name="Tel"></param>
        /// <param name="Email"></param>
        /// <param name="CreateDate"></param>
        /// <param name="dbTransaction"></param>
        /// <returns></returns>
        public int SetTATransPolicyHolder(DbProviderHelper db,string JobNo, string ClientType, string ClientTitle, string ClientName, string ClientSurName, string ClientAddress1, string ClientAddress2, string Province, string Amphur, string Tumbol, string PostCode, string Birthday, string IDCard, string Tel, string Email, string Lanuage, string branchNo, DbTransaction dbTransaction)
        {
            try
            {
                DbCommand oDbCommand = db.CreateCommand("spTA_SetTransPolicyHolder_V2", CommandType.StoredProcedure, dbTransaction);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (ClientType != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientType", DbType.String, ClientType));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientType", DbType.String, DBNull.Value));
                if (ClientTitle != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle", DbType.String, ClientTitle));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle", DbType.String, DBNull.Value));
                if (ClientName != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientName", DbType.String, ClientName));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientName", DbType.String, DBNull.Value));
                if (ClientSurName != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName", DbType.String, ClientSurName));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName", DbType.String, DBNull.Value));
                if (ClientAddress1 != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress1", DbType.String, ClientAddress1));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress1", DbType.String, DBNull.Value));
                if (ClientAddress2 != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress2", DbType.String, ClientAddress2));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress2", DbType.String, DBNull.Value));
                if (Province != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Province", DbType.String, Province));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Province", DbType.String, DBNull.Value));
                if (Amphur != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Amphur", DbType.String, Amphur));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Amphur", DbType.String, DBNull.Value));
                if (Tumbol != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tumbol", DbType.String, Tumbol));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tumbol", DbType.String, DBNull.Value));
                if (PostCode != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PostCode", DbType.String, PostCode));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PostCode", DbType.String, DBNull.Value));
                if (Birthday != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Birthday", DbType.String, Birthday));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Birthday", DbType.String, DBNull.Value));
                if (IDCard != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@IDCard", DbType.String, IDCard));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@IDCard", DbType.String, DBNull.Value));
                if (Tel != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tel", DbType.String, Tel));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tel", DbType.String, DBNull.Value));
                if (Email != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Email", DbType.String, Email));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Email", DbType.String, DBNull.Value));

                if (Lanuage != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Language", DbType.String, Lanuage));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Language", DbType.String, DBNull.Value));
                if (branchNo != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@BranchNo", DbType.String, branchNo));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@BranchNo", DbType.String, DBNull.Value));


                return db.ExecuteNonQuery(oDbCommand, true);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

	}
}
