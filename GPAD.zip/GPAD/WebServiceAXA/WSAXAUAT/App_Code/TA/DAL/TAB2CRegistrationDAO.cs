using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;

namespace TA.DAL
{
	public class TAB2CRegistrationDAO
	{
        DbProviderHelper db;

		public TAB2CRegistrationDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}
		public List<TAB2CRegistration> GetTAB2CRegistrations()
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<TAB2CRegistration> lstTAB2CRegistrations = new List<TAB2CRegistration>();
				DbCommand oDbCommand = db.CreateCommand("SELECT [Login],[Password],[ClientCode],[ClientType],[ClientTitle],[ClientName],[ClientSurName],[ClientAddress1],[ClientAddress2],[Province],[Amphur],[Tumbol],[PostCode],[CountryCode],[Birthday],[ClientSEX],[ClientStatus],[PassportID],[IDCard],[TaxID],[Tel],[Email],[Language],[CreateDate],[AgentCode],[StaffCode],[GroupBrokerId],[Message],[ModifiedDate] FROM [TAB2CRegistration]",CommandType.Text);
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					TAB2CRegistration oTAB2CRegistration = new TAB2CRegistration();
					oTAB2CRegistration.Login = Convert.ToString(oDbDataReader["Login"]);

					if(oDbDataReader["Password"] != DBNull.Value)
						oTAB2CRegistration.Password = Convert.ToString(oDbDataReader["Password"]);

					if(oDbDataReader["ClientCode"] != DBNull.Value)
						oTAB2CRegistration.ClientCode = Convert.ToString(oDbDataReader["ClientCode"]);

					if(oDbDataReader["ClientType"] != DBNull.Value)
						oTAB2CRegistration.ClientType = Convert.ToString(oDbDataReader["ClientType"]);

					if(oDbDataReader["ClientTitle"] != DBNull.Value)
						oTAB2CRegistration.ClientTitle = Convert.ToString(oDbDataReader["ClientTitle"]);

					if(oDbDataReader["ClientName"] != DBNull.Value)
						oTAB2CRegistration.ClientName = Convert.ToString(oDbDataReader["ClientName"]);

					if(oDbDataReader["ClientSurName"] != DBNull.Value)
						oTAB2CRegistration.ClientSurName = Convert.ToString(oDbDataReader["ClientSurName"]);

					if(oDbDataReader["ClientAddress1"] != DBNull.Value)
						oTAB2CRegistration.ClientAddress1 = Convert.ToString(oDbDataReader["ClientAddress1"]);

					if(oDbDataReader["ClientAddress2"] != DBNull.Value)
						oTAB2CRegistration.ClientAddress2 = Convert.ToString(oDbDataReader["ClientAddress2"]);

					if(oDbDataReader["Province"] != DBNull.Value)
						oTAB2CRegistration.Province = Convert.ToString(oDbDataReader["Province"]);

					if(oDbDataReader["Amphur"] != DBNull.Value)
						oTAB2CRegistration.Amphur = Convert.ToString(oDbDataReader["Amphur"]);

					if(oDbDataReader["Tumbol"] != DBNull.Value)
						oTAB2CRegistration.Tumbol = Convert.ToString(oDbDataReader["Tumbol"]);

					if(oDbDataReader["PostCode"] != DBNull.Value)
						oTAB2CRegistration.PostCode = Convert.ToString(oDbDataReader["PostCode"]);

					if(oDbDataReader["CountryCode"] != DBNull.Value)
						oTAB2CRegistration.CountryCode = Convert.ToString(oDbDataReader["CountryCode"]);

					if(oDbDataReader["Birthday"] != DBNull.Value)
						oTAB2CRegistration.Birthday = Convert.ToDateTime(oDbDataReader["Birthday"]);

					if(oDbDataReader["ClientSEX"] != DBNull.Value)
						oTAB2CRegistration.ClientSEX = Convert.ToString(oDbDataReader["ClientSEX"]);

					if(oDbDataReader["ClientStatus"] != DBNull.Value)
						oTAB2CRegistration.ClientStatus = Convert.ToString(oDbDataReader["ClientStatus"]);

					if(oDbDataReader["PassportID"] != DBNull.Value)
						oTAB2CRegistration.PassportID = Convert.ToString(oDbDataReader["PassportID"]);

					if(oDbDataReader["IDCard"] != DBNull.Value)
						oTAB2CRegistration.IDCard = Convert.ToString(oDbDataReader["IDCard"]);

					if(oDbDataReader["TaxID"] != DBNull.Value)
						oTAB2CRegistration.TaxID = Convert.ToString(oDbDataReader["TaxID"]);

					if(oDbDataReader["Tel"] != DBNull.Value)
						oTAB2CRegistration.Tel = Convert.ToString(oDbDataReader["Tel"]);

					if(oDbDataReader["Email"] != DBNull.Value)
						oTAB2CRegistration.Email = Convert.ToString(oDbDataReader["Email"]);

					if(oDbDataReader["Language"] != DBNull.Value)
						oTAB2CRegistration.Language = Convert.ToString(oDbDataReader["Language"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oTAB2CRegistration.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);

					if(oDbDataReader["AgentCode"] != DBNull.Value)
						oTAB2CRegistration.AgentCode = Convert.ToString(oDbDataReader["AgentCode"]);

					if(oDbDataReader["StaffCode"] != DBNull.Value)
						oTAB2CRegistration.StaffCode = Convert.ToString(oDbDataReader["StaffCode"]);
					oTAB2CRegistration.GroupBrokerId = Convert.ToString(oDbDataReader["GroupBrokerId"]);

					if(oDbDataReader["Message"] != DBNull.Value)
						oTAB2CRegistration.Message = Convert.ToString(oDbDataReader["Message"]);

					if(oDbDataReader["ModifiedDate"] != DBNull.Value)
						oTAB2CRegistration.ModifiedDate = Convert.ToDateTime(oDbDataReader["ModifiedDate"]);
					lstTAB2CRegistrations.Add(oTAB2CRegistration);
				}
				oDbDataReader.Close();
				return lstTAB2CRegistrations;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}
		public TAB2CRegistration GetTAB2CRegistration(string Login)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				TAB2CRegistration oTAB2CRegistration = new TAB2CRegistration();
				DbCommand oDbCommand = db.CreateCommand("SELECT [Login],[Password],[ClientCode],[ClientType],[ClientTitle],[ClientName],[ClientSurName],[ClientAddress1],[ClientAddress2],[Province],[Amphur],[Tumbol],[PostCode],[CountryCode],[Birthday],[ClientSEX],[ClientStatus],[PassportID],[IDCard],[TaxID],[Tel],[Email],[Language],[CreateDate],[AgentCode],[StaffCode],[GroupBrokerId],[Message],[ModifiedDate] FROM [TAB2CRegistration] WHERE [Login]=@Login",CommandType.Text);
				oDbCommand.Parameters.Add(db.CreateParameter("@Login",DbType.String,Login));
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oTAB2CRegistration.Login = Convert.ToString(oDbDataReader["Login"]);

					if(oDbDataReader["Password"] != DBNull.Value)
						oTAB2CRegistration.Password = Convert.ToString(oDbDataReader["Password"]);

					if(oDbDataReader["ClientCode"] != DBNull.Value)
						oTAB2CRegistration.ClientCode = Convert.ToString(oDbDataReader["ClientCode"]);

					if(oDbDataReader["ClientType"] != DBNull.Value)
						oTAB2CRegistration.ClientType = Convert.ToString(oDbDataReader["ClientType"]);

					if(oDbDataReader["ClientTitle"] != DBNull.Value)
						oTAB2CRegistration.ClientTitle = Convert.ToString(oDbDataReader["ClientTitle"]);

					if(oDbDataReader["ClientName"] != DBNull.Value)
						oTAB2CRegistration.ClientName = Convert.ToString(oDbDataReader["ClientName"]);

					if(oDbDataReader["ClientSurName"] != DBNull.Value)
						oTAB2CRegistration.ClientSurName = Convert.ToString(oDbDataReader["ClientSurName"]);

					if(oDbDataReader["ClientAddress1"] != DBNull.Value)
						oTAB2CRegistration.ClientAddress1 = Convert.ToString(oDbDataReader["ClientAddress1"]);

					if(oDbDataReader["ClientAddress2"] != DBNull.Value)
						oTAB2CRegistration.ClientAddress2 = Convert.ToString(oDbDataReader["ClientAddress2"]);

					if(oDbDataReader["Province"] != DBNull.Value)
						oTAB2CRegistration.Province = Convert.ToString(oDbDataReader["Province"]);

					if(oDbDataReader["Amphur"] != DBNull.Value)
						oTAB2CRegistration.Amphur = Convert.ToString(oDbDataReader["Amphur"]);

					if(oDbDataReader["Tumbol"] != DBNull.Value)
						oTAB2CRegistration.Tumbol = Convert.ToString(oDbDataReader["Tumbol"]);

					if(oDbDataReader["PostCode"] != DBNull.Value)
						oTAB2CRegistration.PostCode = Convert.ToString(oDbDataReader["PostCode"]);

					if(oDbDataReader["CountryCode"] != DBNull.Value)
						oTAB2CRegistration.CountryCode = Convert.ToString(oDbDataReader["CountryCode"]);

					if(oDbDataReader["Birthday"] != DBNull.Value)
						oTAB2CRegistration.Birthday = Convert.ToDateTime(oDbDataReader["Birthday"]);

					if(oDbDataReader["ClientSEX"] != DBNull.Value)
						oTAB2CRegistration.ClientSEX = Convert.ToString(oDbDataReader["ClientSEX"]);

					if(oDbDataReader["ClientStatus"] != DBNull.Value)
						oTAB2CRegistration.ClientStatus = Convert.ToString(oDbDataReader["ClientStatus"]);

					if(oDbDataReader["PassportID"] != DBNull.Value)
						oTAB2CRegistration.PassportID = Convert.ToString(oDbDataReader["PassportID"]);

					if(oDbDataReader["IDCard"] != DBNull.Value)
						oTAB2CRegistration.IDCard = Convert.ToString(oDbDataReader["IDCard"]);

					if(oDbDataReader["TaxID"] != DBNull.Value)
						oTAB2CRegistration.TaxID = Convert.ToString(oDbDataReader["TaxID"]);

					if(oDbDataReader["Tel"] != DBNull.Value)
						oTAB2CRegistration.Tel = Convert.ToString(oDbDataReader["Tel"]);

					if(oDbDataReader["Email"] != DBNull.Value)
						oTAB2CRegistration.Email = Convert.ToString(oDbDataReader["Email"]);

					if(oDbDataReader["Language"] != DBNull.Value)
						oTAB2CRegistration.Language = Convert.ToString(oDbDataReader["Language"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oTAB2CRegistration.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);

					if(oDbDataReader["AgentCode"] != DBNull.Value)
						oTAB2CRegistration.AgentCode = Convert.ToString(oDbDataReader["AgentCode"]);

					if(oDbDataReader["StaffCode"] != DBNull.Value)
						oTAB2CRegistration.StaffCode = Convert.ToString(oDbDataReader["StaffCode"]);
					oTAB2CRegistration.GroupBrokerId = Convert.ToString(oDbDataReader["GroupBrokerId"]);

					if(oDbDataReader["Message"] != DBNull.Value)
						oTAB2CRegistration.Message = Convert.ToString(oDbDataReader["Message"]);

					if(oDbDataReader["ModifiedDate"] != DBNull.Value)
						oTAB2CRegistration.ModifiedDate = Convert.ToDateTime(oDbDataReader["ModifiedDate"]);
				}
				oDbDataReader.Close();
				return oTAB2CRegistration;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}
		public int AddTAB2CRegistration(string Login,string Password,string ClientCode,string ClientType,string ClientTitle,string ClientName,string ClientSurName,string ClientAddress1,string ClientAddress2,string Province,string Amphur,string Tumbol,string PostCode,string CountryCode,Nullable<DateTime> Birthday,string ClientSEX,string ClientStatus,string PassportID,string IDCard,string TaxID,string Tel,string Email,string Language,Nullable<DateTime> CreateDate,string AgentCode,string StaffCode,string GroupBrokerId,string Message,Nullable<DateTime> ModifiedDate)
		{
			try
			{
				DbCommand oDbCommand = db.CreateCommand("INSERT INTO [TAB2CRegistration]([Password],[ClientCode],[ClientType],[ClientTitle],[ClientName],[ClientSurName],[ClientAddress1],[ClientAddress2],[Province],[Amphur],[Tumbol],[PostCode],[CountryCode],[Birthday],[ClientSEX],[ClientStatus],[PassportID],[IDCard],[TaxID],[Tel],[Email],[Language],[CreateDate],[AgentCode],[StaffCode],[GroupBrokerId],[Message],[ModifiedDate])VALUES(@Password,@ClientCode,@ClientType,@ClientTitle,@ClientName,@ClientSurName,@ClientAddress1,@ClientAddress2,@Province,@Amphur,@Tumbol,@PostCode,@CountryCode,@Birthday,@ClientSEX,@ClientStatus,@PassportID,@IDCard,@TaxID,@Tel,@Email,@Language,@CreateDate,@AgentCode,@StaffCode,@GroupBrokerId,@Message,@ModifiedDate)",CommandType.Text);
				if (Password!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Password",DbType.String,Password));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Password",DbType.String,DBNull.Value));
				if (ClientCode!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientCode",DbType.String,ClientCode));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientCode",DbType.String,DBNull.Value));
				if (ClientType!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientType",DbType.String,ClientType));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientType",DbType.String,DBNull.Value));
				if (ClientTitle!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle",DbType.String,ClientTitle));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle",DbType.String,DBNull.Value));
				if (ClientName!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientName",DbType.String,ClientName));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientName",DbType.String,DBNull.Value));
				if (ClientSurName!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName",DbType.String,ClientSurName));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName",DbType.String,DBNull.Value));
				if (ClientAddress1!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress1",DbType.String,ClientAddress1));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress1",DbType.String,DBNull.Value));
				if (ClientAddress2!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress2",DbType.String,ClientAddress2));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress2",DbType.String,DBNull.Value));
				if (Province!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Province",DbType.String,Province));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Province",DbType.String,DBNull.Value));
				if (Amphur!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Amphur",DbType.String,Amphur));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Amphur",DbType.String,DBNull.Value));
				if (Tumbol!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Tumbol",DbType.String,Tumbol));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Tumbol",DbType.String,DBNull.Value));
				if (PostCode!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@PostCode",DbType.String,PostCode));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@PostCode",DbType.String,DBNull.Value));
				if (CountryCode!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@CountryCode",DbType.String,CountryCode));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@CountryCode",DbType.String,DBNull.Value));
				if (Birthday.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@Birthday",DbType.DateTime,Birthday));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Birthday",DbType.DateTime,DBNull.Value));
				if (ClientSEX!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientSEX",DbType.String,ClientSEX));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientSEX",DbType.String,DBNull.Value));
				if (ClientStatus!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientStatus",DbType.String,ClientStatus));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientStatus",DbType.String,DBNull.Value));
				if (PassportID!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@PassportID",DbType.String,PassportID));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@PassportID",DbType.String,DBNull.Value));
				if (IDCard!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@IDCard",DbType.String,IDCard));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@IDCard",DbType.String,DBNull.Value));
				if (TaxID!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@TaxID",DbType.String,TaxID));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@TaxID",DbType.String,DBNull.Value));
				if (Tel!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Tel",DbType.String,Tel));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Tel",DbType.String,DBNull.Value));
				if (Email!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Email",DbType.String,Email));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Email",DbType.String,DBNull.Value));
				if (Language!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Language",DbType.String,Language));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Language",DbType.String,DBNull.Value));
				if (CreateDate.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@CreateDate",DbType.DateTime,CreateDate));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@CreateDate",DbType.DateTime,DBNull.Value));
				if (AgentCode!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@AgentCode",DbType.String,AgentCode));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@AgentCode",DbType.String,DBNull.Value));
				if (StaffCode!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@StaffCode",DbType.String,StaffCode));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@StaffCode",DbType.String,DBNull.Value));
				oDbCommand.Parameters.Add(db.CreateParameter("@GroupBrokerId",DbType.String,GroupBrokerId));
				if (Message!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Message",DbType.String,Message));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Message",DbType.String,DBNull.Value));
				if (ModifiedDate.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@ModifiedDate",DbType.DateTime,ModifiedDate));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ModifiedDate",DbType.DateTime,DBNull.Value));

				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
        public int SetTAB2CRegistration(string Login, string Password, string ClientType, string ClientTitle, string ClientName, string ClientSurName, string ClientAddress1, string ClientAddress2, string Province, string Amphur, string Tumbol, string PostCode, string CountryCode, string Birthday, string ClientSEX, string ClientStatus, string PassportID, string IDCard, string TaxID, string Tel, string Email, string Language)
        {
            try
            {
                DbCommand oDbCommand = db.CreateCommand("spTAB2C_SetRegistration", CommandType.StoredProcedure);
                if (Login != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Login", DbType.String, Login));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Login", DbType.String, DBNull.Value));
                if (Password != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Password", DbType.String, Password));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Password", DbType.String, DBNull.Value));
                if (ClientType != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientType", DbType.String, ClientType));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientType", DbType.String, DBNull.Value));
                if (ClientTitle != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle", DbType.String, ClientTitle));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle", DbType.String, DBNull.Value));
                if (ClientName != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientName", DbType.String, ClientName));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientName", DbType.String, DBNull.Value));
                if (ClientSurName != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName", DbType.String, ClientSurName));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName", DbType.String, DBNull.Value));
                if (ClientAddress1 != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress1", DbType.String, ClientAddress1));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress1", DbType.String, DBNull.Value));
                if (ClientAddress2 != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress2", DbType.String, ClientAddress2));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress2", DbType.String, DBNull.Value));
                if (Province != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Province", DbType.String, Province));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Province", DbType.String, DBNull.Value));
                if (Amphur != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Amphur", DbType.String, Amphur));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Amphur", DbType.String, DBNull.Value));
                if (Tumbol != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tumbol", DbType.String, Tumbol));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tumbol", DbType.String, DBNull.Value));
                if (PostCode != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PostCode", DbType.String, PostCode));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PostCode", DbType.String, DBNull.Value));
                if (CountryCode != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@CountryCode", DbType.String, CountryCode));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@CountryCode", DbType.String, DBNull.Value));
                if (Birthday != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Birthday", DbType.String, Birthday));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Birthday", DbType.String, DBNull.Value));
                if (ClientSEX != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientSEX", DbType.String, ClientSEX));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientSEX", DbType.String, DBNull.Value));
                if (ClientStatus != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientStatus", DbType.String, ClientStatus));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientStatus", DbType.String, DBNull.Value));
                if (PassportID != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PassportID", DbType.String, PassportID));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PassportID", DbType.String, DBNull.Value));
                if (IDCard != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@IDCard", DbType.String, IDCard));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@IDCard", DbType.String, DBNull.Value));
                if (TaxID != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@TaxID", DbType.String, TaxID));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@TaxID", DbType.String, DBNull.Value));
                if (Tel != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tel", DbType.String, Tel));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tel", DbType.String, DBNull.Value));
                if (Email != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Email", DbType.String, Email));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Email", DbType.String, DBNull.Value));
                if (Language != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Language", DbType.String, Language));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Language", DbType.String, DBNull.Value));

                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
		public int UpdateTAB2CRegistration(string Login,string Password,string ClientCode,string ClientType,string ClientTitle,string ClientName,string ClientSurName,string ClientAddress1,string ClientAddress2,string Province,string Amphur,string Tumbol,string PostCode,string CountryCode,Nullable<DateTime> Birthday,string ClientSEX,string ClientStatus,string PassportID,string IDCard,string TaxID,string Tel,string Email,string Language,Nullable<DateTime> CreateDate,string AgentCode,string StaffCode,string GroupBrokerId,string Message,Nullable<DateTime> ModifiedDate)
		{

			try
			{
				DbCommand oDbCommand = db.CreateCommand("UPDATE [TAB2CRegistration] SET [Password]=@Password,[ClientCode]=@ClientCode,[ClientType]=@ClientType,[ClientTitle]=@ClientTitle,[ClientName]=@ClientName,[ClientSurName]=@ClientSurName,[ClientAddress1]=@ClientAddress1,[ClientAddress2]=@ClientAddress2,[Province]=@Province,[Amphur]=@Amphur,[Tumbol]=@Tumbol,[PostCode]=@PostCode,[CountryCode]=@CountryCode,[Birthday]=@Birthday,[ClientSEX]=@ClientSEX,[ClientStatus]=@ClientStatus,[PassportID]=@PassportID,[IDCard]=@IDCard,[TaxID]=@TaxID,[Tel]=@Tel,[Email]=@Email,[Language]=@Language,[CreateDate]=@CreateDate,[AgentCode]=@AgentCode,[StaffCode]=@StaffCode,[GroupBrokerId]=@GroupBrokerId,[Message]=@Message,[ModifiedDate]=@ModifiedDate WHERE [Login]=@Login",CommandType.Text);
				if (Password!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Password",DbType.String,Password));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Password",DbType.String,DBNull.Value));
				if (ClientCode!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientCode",DbType.String,ClientCode));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientCode",DbType.String,DBNull.Value));
				if (ClientType!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientType",DbType.String,ClientType));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientType",DbType.String,DBNull.Value));
				if (ClientTitle!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle",DbType.String,ClientTitle));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle",DbType.String,DBNull.Value));
				if (ClientName!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientName",DbType.String,ClientName));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientName",DbType.String,DBNull.Value));
				if (ClientSurName!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName",DbType.String,ClientSurName));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName",DbType.String,DBNull.Value));
				if (ClientAddress1!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress1",DbType.String,ClientAddress1));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress1",DbType.String,DBNull.Value));
				if (ClientAddress2!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress2",DbType.String,ClientAddress2));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress2",DbType.String,DBNull.Value));
				if (Province!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Province",DbType.String,Province));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Province",DbType.String,DBNull.Value));
				if (Amphur!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Amphur",DbType.String,Amphur));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Amphur",DbType.String,DBNull.Value));
				if (Tumbol!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Tumbol",DbType.String,Tumbol));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Tumbol",DbType.String,DBNull.Value));
				if (PostCode!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@PostCode",DbType.String,PostCode));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@PostCode",DbType.String,DBNull.Value));
				if (CountryCode!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@CountryCode",DbType.String,CountryCode));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@CountryCode",DbType.String,DBNull.Value));
				if (Birthday.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@Birthday",DbType.DateTime,Birthday));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Birthday",DbType.DateTime,DBNull.Value));
				if (ClientSEX!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientSEX",DbType.String,ClientSEX));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientSEX",DbType.String,DBNull.Value));
				if (ClientStatus!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientStatus",DbType.String,ClientStatus));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientStatus",DbType.String,DBNull.Value));
				if (PassportID!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@PassportID",DbType.String,PassportID));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@PassportID",DbType.String,DBNull.Value));
				if (IDCard!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@IDCard",DbType.String,IDCard));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@IDCard",DbType.String,DBNull.Value));
				if (TaxID!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@TaxID",DbType.String,TaxID));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@TaxID",DbType.String,DBNull.Value));
				if (Tel!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Tel",DbType.String,Tel));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Tel",DbType.String,DBNull.Value));
				if (Email!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Email",DbType.String,Email));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Email",DbType.String,DBNull.Value));
				if (Language!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Language",DbType.String,Language));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Language",DbType.String,DBNull.Value));
				if (CreateDate.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@CreateDate",DbType.DateTime,CreateDate));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@CreateDate",DbType.DateTime,DBNull.Value));
				if (AgentCode!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@AgentCode",DbType.String,AgentCode));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@AgentCode",DbType.String,DBNull.Value));
				if (StaffCode!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@StaffCode",DbType.String,StaffCode));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@StaffCode",DbType.String,DBNull.Value));
				oDbCommand.Parameters.Add(db.CreateParameter("@GroupBrokerId",DbType.String,GroupBrokerId));
				if (Message!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Message",DbType.String,Message));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Message",DbType.String,DBNull.Value));
				if (ModifiedDate.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@ModifiedDate",DbType.DateTime,ModifiedDate));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ModifiedDate",DbType.DateTime,DBNull.Value));
				oDbCommand.Parameters.Add(db.CreateParameter("@Login",DbType.String,Login));
				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public int RemoveTAB2CRegistration(string Login)
		{

			try
			{
				DbCommand oDbCommand = db.CreateCommand("DELETE FROM [TAB2CRegistration] WHERE [Login]=@Login",CommandType.Text);
				oDbCommand.Parameters.Add(db.CreateParameter("@Login",DbType.String,Login));
				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

        public DataTable spTAB2C_GetGroupBrokerId(string login)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = db.CreateCommand("spTAB2C_GetGroupBrokerId", CommandType.StoredProcedure);
                comm.Parameters.Add(db.CreateParameter("@Login", DbType.String, login));
                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return db.FillDataTable(adap);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public int spTAB2C_SetRegistration(string Login, string Password, string ClientCode, string ClientType, string ClientTitle, string ClientName, string ClientSurName, string ClientAddress1, string ClientAddress2, string Province, string Amphur, string Tumbol, string PostCode, string CountryCode, Nullable<DateTime> Birthday, string ClientSEX, string ClientStatus, string PassportID, string IDCard, string TaxID, string Tel, string Email, string Language, string AgentCode, string StaffCode, string GroupBrokerId, string Message)
        {
            try
            {
                DbCommand oDbCommand = db.CreateCommand("spTAB2C_SetRegistration", CommandType.StoredProcedure);

                oDbCommand.Parameters.Add(db.CreateParameter("@Login", DbType.String, Login));
                if (Password != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Password", DbType.String, Password));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Password", DbType.String, DBNull.Value));
                if (ClientCode != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientCode", DbType.String, ClientCode));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientCode", DbType.String, DBNull.Value));
                if (ClientType != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientType", DbType.String, ClientType));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientType", DbType.String, DBNull.Value));
                if (ClientTitle != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle", DbType.String, ClientTitle));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle", DbType.String, DBNull.Value));
                if (ClientName != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientName", DbType.String, ClientName));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientName", DbType.String, DBNull.Value));
                if (ClientSurName != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName", DbType.String, ClientSurName));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName", DbType.String, DBNull.Value));
                if (ClientAddress1 != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress1", DbType.String, ClientAddress1));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress1", DbType.String, DBNull.Value));
                if (ClientAddress2 != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress2", DbType.String, ClientAddress2));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientAddress2", DbType.String, DBNull.Value));
                if (Province != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Province", DbType.String, Province));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Province", DbType.String, DBNull.Value));
                if (Amphur != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Amphur", DbType.String, Amphur));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Amphur", DbType.String, DBNull.Value));
                if (Tumbol != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tumbol", DbType.String, Tumbol));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tumbol", DbType.String, DBNull.Value));
                if (PostCode != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PostCode", DbType.String, PostCode));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PostCode", DbType.String, DBNull.Value));
                if (CountryCode != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@CountryCode", DbType.String, CountryCode));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@CountryCode", DbType.String, DBNull.Value));
                if (Birthday.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Birthday", DbType.DateTime, Birthday));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Birthday", DbType.DateTime, DBNull.Value));
                if (ClientSEX != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientSEX", DbType.String, ClientSEX));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientSEX", DbType.String, DBNull.Value));
                if (ClientStatus != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientStatus", DbType.String, ClientStatus));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientStatus", DbType.String, DBNull.Value));
                if (PassportID != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PassportID", DbType.String, PassportID));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PassportID", DbType.String, DBNull.Value));
                if (IDCard != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@IDCard", DbType.String, IDCard));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@IDCard", DbType.String, DBNull.Value));
                if (TaxID != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@TaxID", DbType.String, TaxID));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@TaxID", DbType.String, DBNull.Value));
                if (Tel != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tel", DbType.String, Tel));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tel", DbType.String, DBNull.Value));
                if (Email != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Email", DbType.String, Email));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Email", DbType.String, DBNull.Value));
                if (Language != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Language", DbType.String, Language));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Language", DbType.String, DBNull.Value));                
                if (AgentCode != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@AgentCode", DbType.String, AgentCode));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@AgentCode", DbType.String, DBNull.Value));
                if (StaffCode != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@StaffCode", DbType.String, StaffCode));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@StaffCode", DbType.String, DBNull.Value));
                oDbCommand.Parameters.Add(db.CreateParameter("@GroupBrokerId", DbType.String, GroupBrokerId));
                if (Message != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Message", DbType.String, Message));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Message", DbType.String, DBNull.Value));                           

                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        public int SetTAB2CRegistration(string Login, string Password)
        {
            try{
                DbCommand oDbCommand = db.CreateCommand("UPDATE [TAB2CRegistration] SET [Password] = @Password ,[ModifiedDate] = GETDATE() WHERE [Login]=@Login", CommandType.Text);
                if (Password != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Password", DbType.String, Password));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Password", DbType.String, DBNull.Value));
                
                oDbCommand.Parameters.Add(db.CreateParameter("@Login",DbType.String,Login));
				
                return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
        }
	}
}
