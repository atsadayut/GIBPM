using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;

namespace TA.DAL
{
	public class TATBRelationDAO
	{
        DbProviderHelper db;

		public TATBRelationDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}
		public List<TATBRelation> GetTATBRelations()
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<TATBRelation> lstTATBRelations = new List<TATBRelation>();
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					TATBRelation oTATBRelation = new TATBRelation();
					oTATBRelation.ID = Convert.ToInt32(oDbDataReader["ID"]);

					if(oDbDataReader["Relation"] != DBNull.Value)
						oTATBRelation.Relation = Convert.ToString(oDbDataReader["Relation"]);

					if(oDbDataReader["isEnable"] != DBNull.Value)
						oTATBRelation.isEnable = Convert.ToSByte(oDbDataReader["isEnable"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oTATBRelation.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);
					lstTATBRelations.Add(oTATBRelation);
				}
				oDbDataReader.Close();
				return lstTATBRelations;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public TATBRelation GetTATBRelation(int ID)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				TATBRelation oTATBRelation = new TATBRelation();
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
				oDbCommand.Parameters.Add(db.CreateParameter("@ID",DbType.Int32,ID));
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oTATBRelation.ID = Convert.ToInt32(oDbDataReader["ID"]);

					if(oDbDataReader["Relation"] != DBNull.Value)
						oTATBRelation.Relation = Convert.ToString(oDbDataReader["Relation"]);

					if(oDbDataReader["isEnable"] != DBNull.Value)
						oTATBRelation.isEnable = Convert.ToSByte(oDbDataReader["isEnable"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oTATBRelation.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);
				}
				oDbDataReader.Close();
				return oTATBRelation;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public int AddTATBRelation(int ID,string Relation,Nullable<SByte> isEnable,Nullable<DateTime> CreateDate)
		{
			try
			{
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
                //Add Parameters 
				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public int UpdateTATBRelation(int ID,string Relation,Nullable<SByte> isEnable,Nullable<DateTime> CreateDate)
		{

			try
			{
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
                //Add Parameters 
				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}
		public int RemoveTATBRelation(int ID)
		{

			try
			{
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
                //Add Parameters 
				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
                Utilities.LogError(ex);
				throw ex;
			}
		}

        /// <summary>
        /// INSERT/UPDATE
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="Relation"></param>
        /// <param name="isEnable"></param>
        /// <param name="CreateDate"></param>
        /// <returns></returns>
        public int SetTATBRelation(int ID, string Relation, Nullable<SByte> isEnable, Nullable<DateTime> CreateDate)
        {
            try
            {
                DbCommand oDbCommand = db.CreateCommand("", CommandType.StoredProcedure);
                //Add Parameters 
                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        /// <summary>
        /// GET
        /// </summary>
        /// <returns></returns>
        public DataTable GetDtTATBRelations(string lang)
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm;
                if (lang == "E")
                {
                    comm = db.CreateCommand("spTA_GetRelation", CommandType.StoredProcedure);
                }
                else
                {
                    comm = db.CreateCommand("spTA_GetRelationTH", CommandType.StoredProcedure);
                }
                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return db.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

	}
}
