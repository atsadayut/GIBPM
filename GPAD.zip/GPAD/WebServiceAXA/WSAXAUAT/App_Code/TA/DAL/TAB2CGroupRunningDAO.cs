using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TA.BusinessObjects;

namespace TA.DAL
{
	public class TAB2CGroupRunningDAO
	{
        DbProviderHelper db;

		public TAB2CGroupRunningDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}
		public List<TAB2CGroupRunning> GetTAB2CGroupRunnings()
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<TAB2CGroupRunning> lstTAB2CGroupRunnings = new List<TAB2CGroupRunning>();
				DbCommand oDbCommand = db.CreateCommand("SELECT [PREFIX],[YEAR],[MONTH],[GROUPID],[CreatedDate] FROM [TAB2CGroupRunning]",CommandType.Text);
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					TAB2CGroupRunning oTAB2CGroupRunning = new TAB2CGroupRunning();
					oTAB2CGroupRunning.PREFIX = Convert.ToString(oDbDataReader["PREFIX"]);
					oTAB2CGroupRunning.YEAR = Convert.ToInt32(oDbDataReader["YEAR"]);
					oTAB2CGroupRunning.MONTH = Convert.ToInt32(oDbDataReader["MONTH"]);
					oTAB2CGroupRunning.GROUPID = Convert.ToInt32(oDbDataReader["GROUPID"]);

					if(oDbDataReader["CreatedDate"] != DBNull.Value)
						oTAB2CGroupRunning.CreatedDate = Convert.ToDateTime(oDbDataReader["CreatedDate"]);
					lstTAB2CGroupRunnings.Add(oTAB2CGroupRunning);
				}
				oDbDataReader.Close();
				return lstTAB2CGroupRunnings;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}
		public TAB2CGroupRunning GetTAB2CGroupRunning(string PREFIX,int YEAR,int MONTH,int GROUPID)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				TAB2CGroupRunning oTAB2CGroupRunning = new TAB2CGroupRunning();
				DbCommand oDbCommand = db.CreateCommand("SELECT [PREFIX],[YEAR],[MONTH],[GROUPID],[CreatedDate] FROM [TAB2CGroupRunning] WHERE [PREFIX]=@PREFIX AND [YEAR]=@YEAR AND [MONTH]=@MONTH AND [GROUPID]=@GROUPID",CommandType.Text);
				oDbCommand.Parameters.Add(db.CreateParameter("@PREFIX",DbType.String,PREFIX));
				oDbCommand.Parameters.Add(db.CreateParameter("@YEAR",DbType.Int32,YEAR));
				oDbCommand.Parameters.Add(db.CreateParameter("@MONTH",DbType.Int32,MONTH));
				oDbCommand.Parameters.Add(db.CreateParameter("@GROUPID",DbType.Int32,GROUPID));
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oTAB2CGroupRunning.PREFIX = Convert.ToString(oDbDataReader["PREFIX"]);
					oTAB2CGroupRunning.YEAR = Convert.ToInt32(oDbDataReader["YEAR"]);
					oTAB2CGroupRunning.MONTH = Convert.ToInt32(oDbDataReader["MONTH"]);
					oTAB2CGroupRunning.GROUPID = Convert.ToInt32(oDbDataReader["GROUPID"]);

					if(oDbDataReader["CreatedDate"] != DBNull.Value)
						oTAB2CGroupRunning.CreatedDate = Convert.ToDateTime(oDbDataReader["CreatedDate"]);
				}
				oDbDataReader.Close();
				return oTAB2CGroupRunning;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}
		public int AddTAB2CGroupRunning(string PREFIX,int YEAR,int MONTH,int GROUPID,Nullable<DateTime> CreatedDate)
		{
			try
			{
				DbCommand oDbCommand = db.CreateCommand("INSERT INTO [TAB2CGroupRunning]([CreatedDate])VALUES(@CreatedDate)",CommandType.Text);
				if (CreatedDate.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@CreatedDate",DbType.DateTime,CreatedDate));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@CreatedDate",DbType.DateTime,DBNull.Value));

				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public int UpdateTAB2CGroupRunning(string PREFIX,int YEAR,int MONTH,int GROUPID,Nullable<DateTime> CreatedDate)
		{

			try
			{
				DbCommand oDbCommand = db.CreateCommand("UPDATE [TAB2CGroupRunning] SET [CreatedDate]=@CreatedDate WHERE [PREFIX]=@PREFIX AND [YEAR]=@YEAR AND [MONTH]=@MONTH AND [GROUPID]=@GROUPID",CommandType.Text);
				if (CreatedDate.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@CreatedDate",DbType.DateTime,CreatedDate));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@CreatedDate",DbType.DateTime,DBNull.Value));
				oDbCommand.Parameters.Add(db.CreateParameter("@PREFIX",DbType.String,PREFIX));
				oDbCommand.Parameters.Add(db.CreateParameter("@YEAR",DbType.Int32,YEAR));
				oDbCommand.Parameters.Add(db.CreateParameter("@MONTH",DbType.Int32,MONTH));
				oDbCommand.Parameters.Add(db.CreateParameter("@GROUPID",DbType.Int32,GROUPID));
				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public int RemoveTAB2CGroupRunning(string PREFIX,int YEAR,int MONTH,int GROUPID)
		{

			try
			{
				DbCommand oDbCommand = db.CreateCommand("DELETE FROM [TAB2CGroupRunning] WHERE [PREFIX]=@PREFIX AND [YEAR]=@YEAR AND [MONTH]=@MONTH AND [GROUPID]=@GROUPID",CommandType.Text);
				oDbCommand.Parameters.Add(db.CreateParameter("@PREFIX",DbType.String,PREFIX));
				oDbCommand.Parameters.Add(db.CreateParameter("@YEAR",DbType.Int32,YEAR));
				oDbCommand.Parameters.Add(db.CreateParameter("@MONTH",DbType.Int32,MONTH));
				oDbCommand.Parameters.Add(db.CreateParameter("@GROUPID",DbType.Int32,GROUPID));
				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

        public string spTAB2C_SetGroupId()
        {
            try
            {
                // get a configured & create DbCommand object
                DbCommand comm = db.CreateCommand("spTAB2C_SetGroupId", CommandType.StoredProcedure);

                // create parameter and direction
                DbParameter param = comm.CreateParameter();
                param.ParameterName = "@GetGROUPID";
                param.DbType = DbType.String;
                param.Size = 20;
                param.Direction = ParameterDirection.Output;
                comm.Parameters.Add(param);

                //execute command
                int ret = db.ExecuteNonQuery(comm);

                //return jobno
                return param.Value.ToString();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
	}
}
