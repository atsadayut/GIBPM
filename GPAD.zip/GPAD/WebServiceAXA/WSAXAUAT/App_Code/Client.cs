using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Data.Common;
using System.Data.SqlClient;
/// <summary>
/// Summary description for UserMember
/// </summary>
///
public struct ClientDetails
{
    public string ClientNo;       //[CLNTNUM]         
    public string ClientType;     //[CLTTYPE]
    public string Salutation;     //[SALUTL]
    public string Name;           //[LGIVNAME]
    public string Surname;        //[LSURNAME]
    public string Address1;       //[CLTADDR01]       '13/21-22 ���� 3 �������§���ͧ
    public string Address2;       //[CLTADDR02]       '�.�Ҵ�˭�
    public string Address3;       //[CLTADDR03]       '�.�Ҵ�˭�
    public string Address4;        //[CLTADDR04]       '�.ʧ���
    public string Address5;        //[CLTADDR05]       'BANGKOK.
    public string PostCode;       //[CLTPCODE]
    public string Country;         //[CTRYCODE]
    public string SEX;            //[CLTSEX]          'M,F
    public string Married;        //[MARRYD]          'Z,M
    public string Status;         //[CLTSTAT]         'AC
    public string BusRes;         //[ADDRTYPE]        'R   
    public string ID;              //[SECUITYNO] 
    public string Phone;           //[RMBLPHONE]
    public string PhoneOffice;     //[CLTPHONE01]
    public string PhoneMoblie;     //[CLTPHONE02]
    public string Emails;          //[RINTERNET]
    public string Nationality;     //[NATLTY]
    public string DOB;            //[CLTDOB] 'float
    public string FAXNO;           //[FAXNO]
    public string FAXNO01;         //[FAXNO01]
    public string Language;        //[LANGUAGE]
    public string TaxID  ;          //[TaxID]     UPDATE PENDING 2009-07-31
    public string Datetime;        //[DATIME]
    public string LicenseDriver;    //[DLICENSE] //Table DriverLicense
    public string GroupBrokerId;    //[GROUPBROKERID] //Table ClientBroker
} 

public struct ClientBrokerDetails
{
    public string ClientCode ;             
    public string BrokerCode ;
    public string GroupBrokerId; 
}

public  class Client
{
    public Client()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public static DataTable GetClientPersonalByClientNo(string clientNo, string ClientType, string GROUPBROKERID)
    {
        string str = "SELECT [tbl_ClientBroker].[CLNTNUM]";
        str += ",[tbl_ClientBroker].[BROKERCODE]";
        str += ",[tbl_Client].[CLNTNUM] ";
        str += ",[tbl_Client].[CLTTYPE]";
        str += ",[tbl_Client].[SALUTL]";
        str += ",[tbl_Client].[LGIVNAME]";
        str += ",[tbl_Client].[LSURNAME]";
        str += ",[tbl_Client].[CLTADDR01]";
        str += ",[tbl_Client].[CLTADDR02]";
        str += ",[tbl_Client].[CLTADDR03]";
        str += ",[tbl_Client].[CLTADDR04]";
        str += ",[tbl_Client].[CLTADDR05]";
        str += ",[tbl_Client].[CLTPCODE]";
        str += ",[tbl_Client].[CTRYCODE]";
        str += ",[tbl_Client].[CLTSEX]";
        str += ",[tbl_Client].[MARRYD]";
        str += ",[tbl_Client].[CLTSTAT]";
        str += ",[tbl_Client].[ADDRTYPE]";
        str += ",[tbl_Client].[SECUITYNO]";
        str += ",[tbl_Client].[RMBLPHONE]";
        str += ",[tbl_Client].[CLTPHONE01]";
        str += ",[tbl_Client].[CLTPHONE02]";
        str += ",[tbl_Client].[RINTERNET]";
        str += ",[tbl_Client].[NATLTY]";
        str += ",[tbl_Client].[CLTDOB]";
        str += ",[tbl_Client].[FAXNO]";
        str += ",[tbl_Client].[FAXNO01]";
        str += ",[tbl_Client].[LANGUAGE]";
        str += ",[tbl_Client].[DATIME]";
        str += ",[tbl_Language].[LANGUAGE_FULL]";
        str += ",[tbl_Sex].[CLTSEX_LONGDESC]";
        str += ",[tbl_Married].[MARRYD_LONGDESC]";
        str += ",[tbl_Country].[CTRY_LONGDESC]";
        str += ",[tbl_LicenseDriver].[DLICENSE]";
        str += " FROM [tbl_ClientBroker] ";
        str += " INNER JOIN [tbl_Client] ON [tbl_ClientBroker].[CLNTNUM]=[tbl_Client].[CLNTNUM] ";
        str += " LEFT JOIN [tbl_Language] ON [tbl_Client].[LANGUAGE]=[tbl_Language].[LANGUAGE] ";
        str += " LEFT JOIN [tbl_Sex] ON [tbl_Client].[CLTSEX]=[tbl_Sex].[CLTSEX] ";
        str += " LEFT JOIN [tbl_Married] ON [tbl_Client].[MARRYD]=[tbl_Married].[MARRYD] ";
        str += " LEFT JOIN [tbl_Country] ON [tbl_Client].[CTRYCODE]=[tbl_Country].[CTRYCODE] ";
        str += " LEFT JOIN [tbl_LicenseDriver] ON [tbl_Client].[CLNTNUM]=[tbl_LicenseDriver].[CLNTNUM] ";
        str += " WHERE [tbl_ClientBroker].[GROUPBROKERID]='" + GROUPBROKERID + "' and ([tbl_Client].[CLTTYPE]='" + ClientType + "'and [tbl_ClientBroker].[CLNTNUM]='" + clientNo + "' and [tbl_Client].[LANGUAGE]=[tbl_Sex].[LANG] and [tbl_Client].[LANGUAGE]=[tbl_Married].[LANG]);";

        //str += " WHERE [tbl_ClientBroker].[BROKERCODE]='" + Utilities.BrokerCode() + "' and [tbl_Client].[CLTTYPE]='" + ClientType + "'and [tbl_Client].[CLNTNUM]='" + clientNo + "' and [tbl_Client].[LANGUAGE]=[tbl_Sex].[LANG] and [tbl_Client].[LANGUAGE]=[tbl_Married].[LANG];";

        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    //UPDATE 2009-07-31
    //ADD FIELD TAXID  str += ",[tbl_Client].[TAXID]";
    public static DataTable GetClientCorporateByClientNo(string clientNo, string ClientType, string GROUPBROKERID)
    {
        string str = "SELECT [tbl_ClientBroker].[CLNTNUM]";
        str += ",[tbl_ClientBroker].[BROKERCODE]";
        str += ",[tbl_Client].[CLNTNUM] ";
        str += ",[tbl_Client].[CLTTYPE]";
        str += ",[tbl_Client].[SALUTL]";
        str += ",[tbl_Client].[LGIVNAME]";
        str += ",[tbl_Client].[LSURNAME]";
        str += ",[tbl_Client].[CLTADDR01]";
        str += ",[tbl_Client].[CLTADDR02]";
        str += ",[tbl_Client].[CLTADDR03]";
        str += ",[tbl_Client].[CLTADDR04]";
        str += ",[tbl_Client].[CLTADDR05]";
        str += ",[tbl_Client].[CLTPCODE]";
        str += ",[tbl_Client].[CTRYCODE]";
        str += ",[tbl_Client].[CLTSEX]";
        str += ",[tbl_Client].[MARRYD]";
        str += ",[tbl_Client].[CLTSTAT]";
        str += ",[tbl_Client].[ADDRTYPE]";
        str += ",[tbl_Client].[SECUITYNO]";
        str += ",[tbl_Client].[RMBLPHONE]";
        str += ",[tbl_Client].[CLTPHONE01]";
        str += ",[tbl_Client].[CLTPHONE02]";
        str += ",[tbl_Client].[RINTERNET]";
        str += ",[tbl_Client].[NATLTY]";
        str += ",[tbl_Client].[CLTDOB]";
        str += ",[tbl_Client].[FAXNO]";
        str += ",[tbl_Client].[FAXNO01]";
        str += ",[tbl_Client].[LANGUAGE]";
        str += ",[tbl_Client].[TAXID]";
        str += ",[tbl_Client].[DATIME]";
        str += ",[tbl_Language].[LANGUAGE_FULL]";
        str += ",[tbl_Country].[CTRY_LONGDESC]";
        str += " FROM [tbl_ClientBroker] ";
        str += " LEFT JOIN [tbl_Client] ON [tbl_ClientBroker].[CLNTNUM]=[tbl_Client].[CLNTNUM] ";
        str += " LEFT JOIN [tbl_Language] ON [tbl_Client].[LANGUAGE]=[tbl_Language].[LANGUAGE] ";
        str += " LEFT JOIN [tbl_Country] ON [tbl_Client].[CTRYCODE]=[tbl_Country].[CTRYCODE] ";
        str += " WHERE [tbl_ClientBroker].[GROUPBROKERID]='" + GROUPBROKERID + "' and [tbl_Client].[CLTTYPE]='" + ClientType + "'and [tbl_Client].[CLNTNUM]='" + clientNo + "';";

        //str += " WHERE [tbl_ClientBroker].[BROKERCODE]='" + Utilities.BrokerCode() + "' and [tbl_Client].[CLTTYPE]='" + ClientType + "'and [tbl_Client].[CLNTNUM]='" + clientNo + "';";

        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    //UPDATE 2009-07-31
    //ADD FIELD TAXID  str += ",[tbl_Client].[TAXID]";
    public static DataTable GetClientById(string Id, string ClientType)
    {
        string str = "SELECT [tbl_ClientBroker].[CLNTNUM]";
        str += ",[tbl_ClientBroker].[BROKERCODE]";
        str += ",[tbl_Client].[CLNTNUM] ";
        str += ",[tbl_Client].[CLTTYPE]";
        str += ",[tbl_Client].[SALUTL]";
        str += ",[tbl_Client].[LGIVNAME]";
        str += ",[tbl_Client].[LSURNAME]";
        str += ",[tbl_Client].[CLTADDR01]";
        str += ",[tbl_Client].[CLTADDR02]";
        str += ",[tbl_Client].[CLTADDR03]";
        str += ",[tbl_Client].[CLTADDR04]";
        str += ",[tbl_Client].[CLTADDR05]";
        str += ",[tbl_Client].[CLTPCODE]";
        str += ",[tbl_Client].[CTRYCODE]";
        str += ",[tbl_Client].[CLTSEX]";
        str += ",[tbl_Client].[MARRYD]";
        str += ",[tbl_Client].[CLTSTAT]";
        str += ",[tbl_Client].[ADDRTYPE]";
        str += ",[tbl_Client].[SECUITYNO]";
        str += ",[tbl_Client].[RMBLPHONE]";
        str += ",[tbl_Client].[CLTPHONE01]";
        str += ",[tbl_Client].[CLTPHONE02]";
        str += ",[tbl_Client].[RINTERNET]";
        str += ",[tbl_Client].[NATLTY]";
        str += ",[tbl_Client].[CLTDOB]";
        str += ",[tbl_Client].[FAXNO]";
        str += ",[tbl_Client].[FAXNO01]";
        str += ",[tbl_Client].[LANGUAGE]";
        str += ",[tbl_Client].[TAXID]";
        str += ",[tbl_Client].[DATIME]";
        str += ",[tbl_Language].[LANGUAGE_FULL]";
        str += ",[tbl_Sex].[CLTSEX_LONGDESC]";
        str += ",[tbl_Married].[MARRYD_LONGDESC]";
        str += ",[tbl_Country].[CTRY_LONGDESC]";
        str += ",[tbl_LicenseDriver].[DLICENSE]";
        str += " FROM [tbl_ClientBroker]  ";
        str += " LEFT JOIN	[tbl_Client] ON [tbl_ClientBroker].[CLNTNUM]=[tbl_Client].[CLNTNUM] ";
        str += " LEFT JOIN   [tbl_Language] ON [tbl_Client].[LANGUAGE]=[tbl_Language].[LANGUAGE] ";
        str += " LEFT JOIN   [tbl_Sex] ON [tbl_Client].[CLTSEX]=[tbl_Sex].[CLTSEX] ";
        str += " LEFT JOIN   [tbl_Married] ON [tbl_Client].[MARRYD]=[tbl_Married].[MARRYD] ";
        str += " LEFT JOIN   [tbl_Country] ON [tbl_Client].[CTRYCODE]=[tbl_Country].[CTRYCODE] ";
        str += " LEFT JOIN   [tbl_LicenseDriver] ON [tbl_Client].[CLNTNUM]=[tbl_LicenseDriver].[CLNTNUM] ";
        str += " WHERE [tbl_ClientBroker].[GROUPBROKERID]='" + Utilities.GetGroupBrokerID() + "' and [tbl_Client].[CLTTYPE]='" + ClientType + "'and [tbl_Client].[SECUITYNO]='" + Id + "';";

        
        
        //str += " WHERE [tbl_ClientBroker].[BROKERCODE]='" + Utilities.BrokerCode() + "' and [tbl_Client].[CLTTYPE]='" + ClientType + "'and [tbl_Client].[SECUITYNO]='" + Id + "';";

        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    //UPDATE 2010-09-2010
    public static DataTable GetClientType(string ClientCode)
    {
        string str = "SELECT [CLNTNUM],[CLTTYPE],[SALUTL],[LGIVNAME],[LSURNAME] ";
        str +=" FROM [tbl_Client]";
        str +=" WHERE [CLNTNUM]= '"+ClientCode+"';";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
     
        return GenericDataAccess.ExecuteSelectCommand(comm);
        
    }

    //UPDATE 2009-07-31
    //ADD FIELD TAXID  str += ",[tbl_Client].[TAXID]";
    public static DataTable GetAllClient()
    {
        string str = "SELECT [tbl_ClientBroker].[CLNTNUM]";
        str += ",[tbl_ClientBroker].[BROKERCODE]";
        str += ",[tbl_Client].[CLNTNUM] ";
        str += ",[tbl_Client].[CLTTYPE]";
        str += ",[tbl_Client].[SALUTL]";
        str += ",[tbl_Client].[LGIVNAME]";
        str += ",[tbl_Client].[LSURNAME]";
        str += ",[tbl_Client].[CLTADDR01]";
        str += ",[tbl_Client].[CLTADDR02]";
        str += ",[tbl_Client].[CLTADDR03]";
        str += ",[tbl_Client].[CLTADDR04]";
        str += ",[tbl_Client].[CLTADDR05]";
        str += ",[tbl_Client].[CLTPCODE]";
        str += ",[tbl_Client].[CTRYCODE]";
        str += ",[tbl_Client].[CLTSEX]";
        str += ",[tbl_Client].[MARRYD]";
        str += ",[tbl_Client].[CLTSTAT]";
        str += ",[tbl_Client].[ADDRTYPE]";
        str += ",[tbl_Client].[SECUITYNO]";
        str += ",[tbl_Client].[RMBLPHONE]";
        str += ",[tbl_Client].[CLTPHONE01]";
        str += ",[tbl_Client].[CLTPHONE02]";
        str += ",[tbl_Client].[RINTERNET]";
        str += ",[tbl_Client].[NATLTY]";
        str += ",[tbl_Client].[CLTDOB]";
        str += ",[tbl_Client].[FAXNO]";
        str += ",[tbl_Client].[FAXNO01]";
        str += ",[tbl_Client].[LANGUAGE]";
        str += ",[tbl_Client].[TAXID]";
        str += ",[tbl_Client].[DATIME]";
        str += ",[tbl_Language].[LANGUAGE_FULL]";
        str += ",[tbl_Sex].[CLTSEX_LONGDESC]";
        str += ",[tbl_Married].[MARRYD_LONGDESC]";
        str += ",[tbl_Country].[CTRY_LONGDESC]";
        str += ",[tbl_LicenseDriver].[DLICENSE]";
        str += " FROM [tbl_ClientBroker]  ";
        str += " LEFT JOIN	[tbl_Client] ON [tbl_ClientBroker].[CLNTNUM]=[tbl_Client].[CLNTNUM] ";
        str += " LEFT JOIN   [tbl_Language] ON [tbl_Client].[LANGUAGE]=[tbl_Language].[LANGUAGE] ";
        str += " LEFT JOIN   [tbl_Sex] ON [tbl_Client].[CLTSEX]=[tbl_Sex].[CLTSEX] ";
        str += " LEFT JOIN   [tbl_Married] ON [tbl_Client].[MARRYD]=[tbl_Married].[MARRYD] ";
        str += " LEFT JOIN   [tbl_Country] ON [tbl_Client].[CTRYCODE]=[tbl_Country].[CTRYCODE] ";
        str += " LEFT JOIN   [tbl_LicenseDriver] ON [tbl_Client].[CLNTNUM]=[tbl_LicenseDriver].[CLNTNUM] ";
        str += " WHERE [tbl_ClientBroker].[GROUPBROKERID]='" + Utilities.GetGroupBrokerID() + "';";


        
        //str += " WHERE [tbl_ClientBroker].[BROKERCODE]='" + Utilities.BrokerCode() + "';";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static DataTable GetAllClientByNameandSureName(String name, String surename)
    {
        string str = " SELECT ";
        str += " [tbl_Client].[CLNTNUM] ";
        str += ",[tbl_Client].[CLTTYPE]";
        str += ",[tbl_Client].[SALUTL]";
        str += ",[tbl_Client].[LGIVNAME]";
        str += ",[tbl_Client].[LSURNAME]";
        str += ",[tbl_Client].[CLTADDR01]";
        str += ",[tbl_Client].[CLTADDR02]";
        str += ",[tbl_Client].[CLTADDR03]";
        str += ",[tbl_Client].[CLTADDR04]";
        str += ",[tbl_Client].[CLTADDR05]";
        str += ",[tbl_Client].[LANGUAGE]";
        str += ",[tbl_Client].[CLTDOB]";
        str += " FROM [tbl_ClientBroker]  ";
        str += " LEFT JOIN	[tbl_Client] ON [tbl_ClientBroker].[CLNTNUM]=[tbl_Client].[CLNTNUM] ";
        str += " WHERE [tbl_ClientBroker].[GROUPBROKERID]='" + Utilities.GetGroupBrokerID() + "' and  (([tbl_Client].[LGIVNAME] like '%" + name + "%' or [tbl_Client].[LGIVNAME] is null) and [tbl_Client].[LSURNAME] like '%" + surename + "%') ";
        str += " group by [tbl_Client].[CLNTNUM], [tbl_Client].[CLTTYPE],[tbl_Client].[SALUTL],[tbl_Client].[LGIVNAME],[tbl_Client].[LSURNAME],[tbl_Client].[CLTADDR01],[tbl_Client].[CLTADDR02],[tbl_Client].[CLTADDR03],[tbl_Client].[CLTADDR04],[tbl_Client].[CLTADDR05],[tbl_Client].[LANGUAGE],[tbl_Client].[CLTDOB]";
       
        
        //str += " WHERE [tbl_ClientBroker].[BROKERCODE]='" + Utilities.BrokerCode() + "' and  (([tbl_Client].[LGIVNAME] like '%" + name + "%' or [tbl_Client].[LGIVNAME] is null) and [tbl_Client].[LSURNAME] like '%" + surename + "%') ";
        // get a configured DbCommand object " + Utilities.BrokerCode() + "
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetAllClientPersonal()
    {
        string str = " SELECT ";
        str += " [tbl_Client].[CLNTNUM] ";
        str += ",[tbl_Client].[CLTTYPE]";
        str += ",[tbl_Client].[SALUTL]";
        str += ",[tbl_Client].[LGIVNAME]";
        str += ",[tbl_Client].[LSURNAME]";
        str += ",[tbl_Client].[CLTADDR01]";
        str += ",[tbl_Client].[CLTADDR02]";
        str += ",[tbl_Client].[CLTADDR03]";
        str += ",[tbl_Client].[CLTADDR04]";
        str += ",[tbl_Client].[CLTADDR05]";
        str += " FROM [tbl_ClientBroker]  ";
        str += " LEFT JOIN	[tbl_Client] ON [tbl_ClientBroker].[CLNTNUM]=[tbl_Client].[CLNTNUM] ";
        str += " WHERE [tbl_ClientBroker].[GROUPBROKERID]='" + Utilities.GetGroupBrokerID() + "' and [tbl_Client].[CLTTYPE]='P' ";
        str += " group by [tbl_Client].[CLNTNUM], [tbl_Client].[CLTTYPE],[tbl_Client].[SALUTL],[tbl_Client].[LGIVNAME],[tbl_Client].[LSURNAME],[tbl_Client].[CLTADDR01],[tbl_Client].[CLTADDR02],[tbl_Client].[CLTADDR03],[tbl_Client].[CLTADDR04],[tbl_Client].[CLTADDR05]";
       
        
        //str += " WHERE [tbl_ClientBroker].[BROKERCODE]='" + Utilities.BrokerCode() + "' and [tbl_Client].[CLTTYPE]='P' ;";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetAllClientCorporate()
    {
        string str = " SELECT ";
        str += " [tbl_Client].[CLNTNUM] ";
        str += ",[tbl_Client].[CLTTYPE]";
        str += ",[tbl_Client].[LGIVNAME]";
        str += ",[tbl_Client].[LSURNAME]";
        str += ",[tbl_Client].[CLTADDR01]";
        str += ",[tbl_Client].[CLTADDR02]";
        str += ",[tbl_Client].[CLTADDR03]";
        str += ",[tbl_Client].[CLTADDR04]";
        str += ",[tbl_Client].[CLTADDR05]";
        str += " FROM [tbl_ClientBroker]  ";
        str += " LEFT JOIN	[tbl_Client] ON [tbl_ClientBroker].[CLNTNUM]=[tbl_Client].[CLNTNUM] ";
        str += " WHERE [tbl_ClientBroker].[GROUPBROKERID]='" + Utilities.GetGroupBrokerID() + "' and [tbl_Client].[CLTTYPE]='C' ";
        str += " group by [tbl_Client].[CLNTNUM], [tbl_Client].[CLTTYPE],[tbl_Client].[LGIVNAME],[tbl_Client].[LSURNAME],[tbl_Client].[CLTADDR01],[tbl_Client].[CLTADDR02],[tbl_Client].[CLTADDR03],[tbl_Client].[CLTADDR04],[tbl_Client].[CLTADDR05]";
       
        //str += " WHERE [tbl_ClientBroker].[BROKERCODE]='" + Utilities.BrokerCode() + "' and [tbl_Client].[CLTTYPE]='C' ;";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetPersonalClientByName(String name)
    {
        string str = " SELECT ";
        str += " [tbl_Client].[CLNTNUM] ";
        str += ",[tbl_Client].[CLTTYPE]";
        str += ",[tbl_Client].[SALUTL]";
        str += ",[tbl_Client].[LGIVNAME]";
        str += ",[tbl_Client].[LSURNAME]";
        str += ",[tbl_Client].[CLTADDR01]";
        str += ",[tbl_Client].[CLTADDR02]";
        str += ",[tbl_Client].[CLTADDR03]";
        str += ",[tbl_Client].[CLTADDR04]";
        str += ",[tbl_Client].[CLTADDR05]";
        str += " FROM [tbl_ClientBroker]  ";
        str += " LEFT JOIN	[tbl_Client] ON [tbl_ClientBroker].[CLNTNUM]=[tbl_Client].[CLNTNUM] ";
        str += " WHERE [tbl_ClientBroker].[GROUPBROKERID]='" + Utilities.GetGroupBrokerID() + "' and [tbl_Client].[CLTTYPE]='P' and [tbl_Client].[LGIVNAME] like '" + name + "%'";
        str += " group by [tbl_Client].[CLNTNUM], [tbl_Client].[CLTTYPE],[tbl_Client].[SALUTL],[tbl_Client].[LGIVNAME],[tbl_Client].[LSURNAME],[tbl_Client].[CLTADDR01],[tbl_Client].[CLTADDR02],[tbl_Client].[CLTADDR03],[tbl_Client].[CLTADDR04],[tbl_Client].[CLTADDR05]";
       
        //str += " WHERE [tbl_ClientBroker].[BROKERCODE]='" + Utilities.BrokerCode() + "' and [tbl_Client].[CLTTYPE]='P' and [tbl_Client].[LGIVNAME] like '" + name + "%';";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetPersonalClientBySureName(String surename)
    {
        string str = " SELECT ";
        str += " [tbl_Client].[CLNTNUM] ";
        str += ",[tbl_Client].[CLTTYPE]";
        str += ",[tbl_Client].[SALUTL]";
        str += ",[tbl_Client].[LGIVNAME]";
        str += ",[tbl_Client].[LSURNAME]";
        str += ",[tbl_Client].[CLTADDR01]";
        str += ",[tbl_Client].[CLTADDR02]";
        str += ",[tbl_Client].[CLTADDR03]";
        str += ",[tbl_Client].[CLTADDR04]";
        str += ",[tbl_Client].[CLTADDR05]";
        str += " FROM [tbl_ClientBroker]  ";
        str += " LEFT JOIN	[tbl_Client] ON [tbl_ClientBroker].[CLNTNUM]=[tbl_Client].[CLNTNUM] ";
        str += " WHERE [tbl_ClientBroker].[GROUPBROKERID]='" + Utilities.GetGroupBrokerID() + "' and [tbl_Client].[CLTTYPE]='P' and [tbl_Client].[LSURNAME] like '" + surename + "%'";
        str += " group by [tbl_Client].[CLNTNUM], [tbl_Client].[CLTTYPE],[tbl_Client].[SALUTL],[tbl_Client].[LGIVNAME],[tbl_Client].[LSURNAME],[tbl_Client].[CLTADDR01],[tbl_Client].[CLTADDR02],[tbl_Client].[CLTADDR03],[tbl_Client].[CLTADDR04],[tbl_Client].[CLTADDR05]";
       
        //str += " WHERE [tbl_ClientBroker].[BROKERCODE]='" + Utilities.BrokerCode() + "' and [tbl_Client].[CLTTYPE]='P' and [tbl_Client].[LSURNAME] like '" + surename + "%';";

        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetPersonalClientByNameandSureName(String name,String surename)
    {
        string str = " SELECT ";
        str += " [tbl_Client].[CLNTNUM] ";
        str += ",[tbl_Client].[CLTTYPE]";
        str += ",[tbl_Client].[SALUTL]";
        str += ",[tbl_Client].[LGIVNAME]";
        str += ",[tbl_Client].[LSURNAME]";
        str += ",[tbl_Client].[CLTADDR01]";
        str += ",[tbl_Client].[CLTADDR02]";
        str += ",[tbl_Client].[CLTADDR03]";
        str += ",[tbl_Client].[CLTADDR04]";
        str += ",[tbl_Client].[CLTADDR05]";
        str += " FROM [tbl_ClientBroker]  ";
        str += " LEFT JOIN	[tbl_Client] ON [tbl_ClientBroker].[CLNTNUM]=[tbl_Client].[CLNTNUM] ";
        str += " WHERE [tbl_ClientBroker].[GROUPBROKERID]='" + Utilities.GetGroupBrokerID() + "' and [tbl_Client].[CLTTYPE]='P' and [tbl_Client].[LGIVNAME] like '" + name + "%' and [tbl_Client].[LSURNAME] like '" + surename + "%'";
        str += " group by [tbl_Client].[CLNTNUM], [tbl_Client].[CLTTYPE],[tbl_Client].[SALUTL],[tbl_Client].[LGIVNAME],[tbl_Client].[LSURNAME],[tbl_Client].[CLTADDR01],[tbl_Client].[CLTADDR02],[tbl_Client].[CLTADDR03],[tbl_Client].[CLTADDR04],[tbl_Client].[CLTADDR05]";
       
        
        //str += " WHERE [tbl_ClientBroker].[BROKERCODE]='" + Utilities.BrokerCode() + "' and [tbl_Client].[CLTTYPE]='P' and [tbl_Client].[LGIVNAME] like '" + name + "%' and [tbl_Client].[LSURNAME] like '" + surename + "%';";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetPersonalClientByNameandSureNameCheckNameDriver(String name, String surename)
    {
        string str = " SELECT ";
        str += " [tbl_Client].[CLNTNUM] ";
        str += ",[tbl_Client].[CLTTYPE]";
        str += ",[tbl_Client].[SALUTL]";
        str += ",[tbl_Client].[LGIVNAME]";
        str += ",[tbl_Client].[LSURNAME]";
        str += ",[tbl_Client].[CLTADDR01]";
        str += ",[tbl_Client].[CLTADDR02]";
        str += ",[tbl_Client].[CLTADDR03]";
        str += ",[tbl_Client].[CLTADDR04]";
        str += ",[tbl_Client].[CLTADDR05]";
        str += ",[tbl_Client].[LANGUAGE]";
        str += ",[tbl_Client].[CLTDOB]";
        str += ",[tbl_LicenseDriver].[DLICENSE]";
        str += " FROM [tbl_ClientBroker]  ";
        str += " LEFT JOIN	[tbl_Client] ON [tbl_ClientBroker].[CLNTNUM]=[tbl_Client].[CLNTNUM] ";
        str += " LEFT JOIN   [tbl_LicenseDriver] ON [tbl_Client].[CLNTNUM]=[tbl_LicenseDriver].[CLNTNUM] ";
        str += " WHERE [tbl_ClientBroker].[GROUPBROKERID]='" + Utilities.GetGroupBrokerID() + "' and [tbl_Client].[CLTTYPE]='P' and [tbl_Client].[LGIVNAME] like '" + name + "%' and [tbl_Client].[LSURNAME] like '" + surename + "%'";
        str += " group by [tbl_Client].[CLNTNUM], [tbl_Client].[CLTTYPE],[tbl_Client].[SALUTL],[tbl_Client].[LGIVNAME],[tbl_Client].[LSURNAME],[tbl_Client].[CLTADDR01],[tbl_Client].[CLTADDR02],[tbl_Client].[CLTADDR03],[tbl_Client].[CLTADDR04],[tbl_Client].[CLTADDR05],[tbl_Client].[LANGUAGE],[tbl_Client].[CLTDOB],[tbl_LicenseDriver].[DLICENSE]";
       
        
        //str += " WHERE [tbl_ClientBroker].[BROKERCODE]='" + Utilities.BrokerCode() + "' and [tbl_Client].[CLTTYPE]='P' and [tbl_Client].[LGIVNAME] like '" + name + "%' and [tbl_Client].[LSURNAME] like '" + surename + "%';";
        // get a configured DbCommand object " + Utilities.BrokerCode() + "
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetPersonalClientByNameandSureNameFullText(String name, String surename)
    {
        string str = "SELECT ";
        str += "[tbl_Client].[CLNTNUM] ";
        str += ",[tbl_Client].[SALUTL]";
        str += ",[tbl_Client].[LGIVNAME]";
        str += ",[tbl_Client].[LSURNAME]";
        str += ",[tbl_Client].[CLTSEX]";
        str += ",[tbl_Client].[MARRYD]";
        str += ",[tbl_Client].[SECUITYNO]";
        str += ",[tbl_Client].[CLTDOB]";
        str += ",[tbl_Client].[LANGUAGE]";
        str += ",[tbl_LicenseDriver].[DLICENSE]";
        str += " FROM [tbl_ClientBroker]  ";
        str += " LEFT JOIN [tbl_Client] ON [tbl_ClientBroker].[CLNTNUM]=[tbl_Client].[CLNTNUM] ";
        str += " LEFT JOIN [tbl_LicenseDriver] ON [tbl_Client].[CLNTNUM]=[tbl_LicenseDriver].[CLNTNUM] ";
        str += " WHERE [tbl_ClientBroker].[GROUPBROKERID]='" + Utilities.GetGroupBrokerID() + "' and [tbl_Client].[CLTTYPE]='P' and [tbl_Client].[LGIVNAME] = '" + name + "' and [tbl_Client].[LSURNAME] = '" + surename + "';";

        
        //str += " WHERE [tbl_ClientBroker].[BROKERCODE]='" + Utilities.BrokerCode() + "' and [tbl_Client].[CLTTYPE]='P' and [tbl_Client].[LGIVNAME] = '" + name + "' and [tbl_Client].[LSURNAME] = '" + surename + "';";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetPersonalClientByNameandSureNameFullTextAll(String name, String surename)
    {
        string str = "SELECT ";
        str += "[tbl_Client].[CLNTNUM] ";
        str += ",[tbl_Client].[SALUTL]";
        str += ",[tbl_Client].[LGIVNAME]";
        str += ",[tbl_Client].[LSURNAME]";
        str += ",[tbl_Client].[CLTSEX]";
        str += ",[tbl_Client].[MARRYD]";
        str += ",[tbl_Client].[SECUITYNO]";
        str += ",[tbl_Client].[CLTDOB]";
        str += ",[tbl_Client].[LANGUAGE]";
        str += ",[tbl_LicenseDriver].[DLICENSE]";
        str += " FROM [tbl_Client]  ";
        str += " LEFT JOIN   [tbl_LicenseDriver] ON [tbl_Client].[CLNTNUM]=[tbl_LicenseDriver].[CLNTNUM] ";
        str += " WHERE  [tbl_Client].[CLTTYPE]='P' and [tbl_Client].[LGIVNAME] = '" + name + "' and [tbl_Client].[LSURNAME] = '" + surename + "';";

        
        //str += " WHERE  [tbl_Client].[CLTTYPE]='P' and [tbl_Client].[LGIVNAME] = '" + name + "' and [tbl_Client].[LSURNAME] = '" + surename + "';";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetPersonalClientByNameandHomeAddress(String name,String homeAddress)
    {
        string str = " SELECT ";
        str += " [tbl_Client].[CLNTNUM] ";
        str += ",[tbl_Client].[CLTTYPE]";
        str += ",[tbl_Client].[SALUTL]";
        str += ",[tbl_Client].[LGIVNAME]";
        str += ",[tbl_Client].[LSURNAME]";
        str += ",[tbl_Client].[CLTADDR01]";
        str += ",[tbl_Client].[CLTADDR02]";
        str += ",[tbl_Client].[CLTADDR03]";
        str += ",[tbl_Client].[CLTADDR04]";
        str += ",[tbl_Client].[CLTADDR05]";
        str += " FROM [tbl_ClientBroker]  ";
        str += " LEFT JOIN	[tbl_Client] ON [tbl_ClientBroker].[CLNTNUM]=[tbl_Client].[CLNTNUM] ";
        str += " WHERE [tbl_ClientBroker].[GROUPBROKERID]='" + Utilities.GetGroupBrokerID() + "' and [tbl_Client].[CLTTYPE]='P' and [tbl_Client].[LGIVNAME] like '" + name + "%' and [tbl_Client].[CLTADDR01] like '%" + homeAddress + "%'";
        str += " group by [tbl_Client].[CLNTNUM], [tbl_Client].[CLTTYPE],[tbl_Client].[SALUTL],[tbl_Client].[LGIVNAME],[tbl_Client].[LSURNAME],[tbl_Client].[CLTADDR01],[tbl_Client].[CLTADDR02],[tbl_Client].[CLTADDR03],[tbl_Client].[CLTADDR04],[tbl_Client].[CLTADDR05]";
       
        
        //str += " WHERE [tbl_ClientBroker].[BROKERCODE]='" + Utilities.BrokerCode() + "' and [tbl_Client].[CLTTYPE]='P' and [tbl_Client].[LGIVNAME] like '" + name + "%' and [tbl_Client].[CLTADDR01] like '%" + homeAddress + "%';";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetPersonalClientBySureNameandHomeAddress(String surename, String homeAddress)
    {
        string str = " SELECT ";
        str += " [tbl_Client].[CLNTNUM] ";
        str += ",[tbl_Client].[CLTTYPE]";
        str += ",[tbl_Client].[SALUTL]";
        str += ",[tbl_Client].[LGIVNAME]";
        str += ",[tbl_Client].[LSURNAME]";
        str += ",[tbl_Client].[CLTADDR01]";
        str += ",[tbl_Client].[CLTADDR02]";
        str += ",[tbl_Client].[CLTADDR03]";
        str += ",[tbl_Client].[CLTADDR04]";
        str += ",[tbl_Client].[CLTADDR05]";
        str += " FROM [tbl_ClientBroker]  ";
        str += " LEFT JOIN	[tbl_Client] ON [tbl_ClientBroker].[CLNTNUM]=[tbl_Client].[CLNTNUM] ";
        str += " WHERE [tbl_ClientBroker].[GROUPBROKERID]='" + Utilities.GetGroupBrokerID() + "' and [tbl_Client].[CLTTYPE]='P' and [tbl_Client].[LSURNAME] like '" + surename + "%' and [tbl_Client].[CLTADDR01] like '%" + homeAddress + "%'";
        str += " group by [tbl_Client].[CLNTNUM], [tbl_Client].[CLTTYPE],[tbl_Client].[SALUTL],[tbl_Client].[LGIVNAME],[tbl_Client].[LSURNAME],[tbl_Client].[CLTADDR01],[tbl_Client].[CLTADDR02],[tbl_Client].[CLTADDR03],[tbl_Client].[CLTADDR04],[tbl_Client].[CLTADDR05]";
       
        
        //str += " WHERE [tbl_ClientBroker].[BROKERCODE]='" + Utilities.BrokerCode() + "' and [tbl_Client].[CLTTYPE]='P' and [tbl_Client].[LSURNAME] like '" + surename + "%' and [tbl_Client].[CLTADDR01] like '%" + homeAddress + "%';";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetPersonalClientByNameandSureNameandHomeAddress(String name, String surename ,String homeAddress)
    {
        string str = " SELECT ";
        str += " [tbl_Client].[CLNTNUM] ";
        str += ",[tbl_Client].[CLTTYPE]";
        str += ",[tbl_Client].[SALUTL]";
        str += ",[tbl_Client].[LGIVNAME]";
        str += ",[tbl_Client].[LSURNAME]";
        str += ",[tbl_Client].[CLTADDR01]";
        str += ",[tbl_Client].[CLTADDR02]";
        str += ",[tbl_Client].[CLTADDR03]";
        str += ",[tbl_Client].[CLTADDR04]";
        str += ",[tbl_Client].[CLTADDR05]";
        str += " FROM [tbl_ClientBroker]  ";
        str += " LEFT JOIN	[tbl_Client] ON [tbl_ClientBroker].[CLNTNUM]=[tbl_Client].[CLNTNUM] ";
        str += " WHERE [tbl_ClientBroker].[GROUPBROKERID]='" + Utilities.GetGroupBrokerID() + "' and [tbl_Client].[CLTTYPE]='P' and [tbl_Client].[LGIVNAME] like '" + name + "%' and [tbl_Client].[LSURNAME] like '" + surename + "%' and [tbl_Client].[CLTADDR01] like '%" + homeAddress + "%'";
        str += " group by [tbl_Client].[CLNTNUM], [tbl_Client].[CLTTYPE],[tbl_Client].[SALUTL],[tbl_Client].[LGIVNAME],[tbl_Client].[LSURNAME],[tbl_Client].[CLTADDR01],[tbl_Client].[CLTADDR02],[tbl_Client].[CLTADDR03],[tbl_Client].[CLTADDR04],[tbl_Client].[CLTADDR05]";
        
        //str += " WHERE [tbl_ClientBroker].[BROKERCODE]='" + Utilities.BrokerCode() + "' and [tbl_Client].[CLTTYPE]='P' and [tbl_Client].[LGIVNAME] like '" + name + "%' and [tbl_Client].[LSURNAME] like '" + surename + "%' and [tbl_Client].[CLTADDR01] like '%" + homeAddress + "%';";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static DataTable GetCorporateClientByCompanyName(String name)
    {
        string str = " SELECT ";
        str += " [tbl_Client].[CLNTNUM] ";
        str += ",[tbl_Client].[CLTTYPE]";
        str += ",[tbl_Client].[LGIVNAME]";
        str += ",[tbl_Client].[LSURNAME]";
        str += ",[tbl_Client].[CLTADDR01]";
        str += ",[tbl_Client].[CLTADDR02]";
        str += ",[tbl_Client].[CLTADDR03]";
        str += ",[tbl_Client].[CLTADDR04]";
        str += ",[tbl_Client].[CLTADDR05]";
        str += " FROM [tbl_ClientBroker]  ";
        str += " LEFT JOIN	[tbl_Client] ON [tbl_ClientBroker].[CLNTNUM]=[tbl_Client].[CLNTNUM] ";
        str += " WHERE [tbl_ClientBroker].[GROUPBROKERID]='" + Utilities.GetGroupBrokerID() + "' and [tbl_Client].[CLTTYPE]='C' and [tbl_Client].[LSURNAME] like '%" + name + "%'";
        str += " group by [tbl_Client].[CLNTNUM], [tbl_Client].[CLTTYPE],[tbl_Client].[SALUTL],[tbl_Client].[LGIVNAME],[tbl_Client].[LSURNAME],[tbl_Client].[CLTADDR01],[tbl_Client].[CLTADDR02],[tbl_Client].[CLTADDR03],[tbl_Client].[CLTADDR04],[tbl_Client].[CLTADDR05]";
 
        
        //str += " WHERE [tbl_ClientBroker].[BROKERCODE]='" + Utilities.BrokerCode() + "' and [tbl_Client].[CLTTYPE]='C' and [tbl_Client].[LSURNAME] like '%" + name + "%';";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetCorporateClientByCompanyNameFullText(String name)
    {
        string str = " SELECT ";
        str += " [tbl_Client].[CLNTNUM] ";
        //str += ",[tbl_Client].[CLTTYPE]";
        //str += ",[tbl_Client].[LGIVNAME]";
        //str += ",[tbl_Client].[LSURNAME]";
        //str += ",[tbl_Client].[CLTADDR01]";
        //str += ",[tbl_Client].[CLTADDR02]";
        //str += ",[tbl_Client].[CLTADDR03]";
        //str += ",[tbl_Client].[CLTADDR04]";
        //str += ",[tbl_Client].[CLTADDR05]";
        str += " FROM [tbl_ClientBroker]  ";
        str += " LEFT JOIN	[tbl_Client] ON [tbl_ClientBroker].[CLNTNUM]=[tbl_Client].[CLNTNUM] ";
        str += " WHERE [tbl_ClientBroker].[GROUPBROKERID]='" + Utilities.GetGroupBrokerID() + "' and [tbl_Client].[CLTTYPE]='C' and [tbl_Client].[LSURNAME] = '" + name + "'";
        str += " group by [tbl_Client].[CLNTNUM]";
 
        
        //str += " WHERE [tbl_ClientBroker].[BROKERCODE]='" + Utilities.BrokerCode() + "' and [tbl_Client].[CLTTYPE]='C' and [tbl_Client].[LSURNAME] = '" + name + "';";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetCorporateClientByCompanyNameFullTextAll(String name)
    {
        string str = " SELECT ";
        str += " [tbl_Client].[CLNTNUM] ";
        //str += ",[tbl_Client].[CLTTYPE]";
        //str += ",[tbl_Client].[LGIVNAME]";
        //str += ",[tbl_Client].[LSURNAME]";
        //str += ",[tbl_Client].[CLTADDR01]";
        //str += ",[tbl_Client].[CLTADDR02]";
        //str += ",[tbl_Client].[CLTADDR03]";
        //str += ",[tbl_Client].[CLTADDR04]";
        //str += ",[tbl_Client].[CLTADDR05]";
        str += " FROM [tbl_Client]  ";
        str += " WHERE [tbl_Client].[CLTTYPE]='C' and [tbl_Client].[LSURNAME] = '" + name + "'";
        str += " group by [tbl_Client].[CLNTNUM]";

        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }


    public static DataTable GetCorporateClientByCompanyNameandHomeAddress(String name,String homeAddress)
    {
        string str = " SELECT ";
        str += " [tbl_Client].[CLNTNUM] ";
        str += ",[tbl_Client].[CLTTYPE]";
        str += ",[tbl_Client].[LGIVNAME]";
        str += ",[tbl_Client].[LSURNAME]";
        str += ",[tbl_Client].[CLTADDR01]";
        str += ",[tbl_Client].[CLTADDR02]";
        str += ",[tbl_Client].[CLTADDR03]";
        str += ",[tbl_Client].[CLTADDR04]";
        str += ",[tbl_Client].[CLTADDR05]";
        str += " FROM [tbl_ClientBroker]  ";
        str += " LEFT JOIN	[tbl_Client] ON [tbl_ClientBroker].[CLNTNUM]=[tbl_Client].[CLNTNUM] ";
        str += " WHERE [tbl_ClientBroker].[GROUPBROKERID]='" + Utilities.GetGroupBrokerID() + "' and [tbl_Client].[CLTTYPE]='C' and [tbl_Client].[LSURNAME] like '%" + name + "%' or [tbl_Client].[LGIVNAME] like '%" + name + "%' and [tbl_Client].[CLTADDR01] like '%" + homeAddress + "%'";
        str += " group by [tbl_Client].[CLNTNUM], [tbl_Client].[CLTTYPE],[tbl_Client].[LGIVNAME],[tbl_Client].[LSURNAME],[tbl_Client].[CLTADDR01],[tbl_Client].[CLTADDR02],[tbl_Client].[CLTADDR03],[tbl_Client].[CLTADDR04],[tbl_Client].[CLTADDR05]";

        
        //str += " WHERE [tbl_ClientBroker].[BROKERCODE]='" + Utilities.BrokerCode() + "' and [tbl_Client].[CLTTYPE]='C' and [tbl_Client].[LSURNAME] like '%" + name + "%' or [tbl_Client].[LGIVNAME] like '%" + name + "%' and [tbl_Client].[CLTADDR01] like '%" + homeAddress + "%';";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }


    public static DataTable GetAllProvince()
    {
        string str = " SELECT ";
        str +=" [ProvinceID],[Description] ";
        str +=" FROM [tbl_Province] ORDER  BY [Description] ASC ";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the sql and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    //UPDATE 2009-07-21
    //TEXT:
    //VALUE:
    public static DataTable GetProvinceThaiLanguage()
    {
        string str = " SELECT ";
        str += " [ProvinceID],[Description] ";
        str += " FROM [tbl_Province] ORDER  BY [Description] ASC ";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the sql and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    //UPDATE 2009-07-21
    //TEXT:
    //VALUE:
    public static DataTable GetProvinceEngLanguage()
    {
        string str = " SELECT ";
        str += " [ProvinceID],[Description_EN] ";
        str += " FROM [tbl_Province] ORDER  BY [Description_EN] ASC ";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the sql and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetAllNationality()
    {
        string str = " SELECT ";
        str +=" [CTRYCODE],[CTRY_LONGDESC] "; 
        str +=" FROM [tbl_Country] ";
        str +=" WHERE [CTRYCODE] not in ('THA') ORDER  BY [CTRY_LONGDESC] ASC ";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the sql and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetAllBenificialy()
    {
        string str = " SELECT ";
        str += " [CLNTNUM],[LSURNAME] ";
        str += " FROM [tbl_Benefit] ";
        str += " ORDER BY [LSURNAME] ASC ";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the sql and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetAllBenificialyByLanguage(string lang)
    {
        string str = " SELECT ";
        str += " [CLNTNUM],[LSURNAME] ";
        str += " FROM [tbl_Benefit] ";
        str += " WHERE [LANG]='"+lang+"' ORDER BY [LSURNAME] ASC ";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the sql and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetAllCampaignByBroker()
    {
        string str = " SELECT ";
        str += " [CAMPAIGNCODE],[CAMPAIGNNAME] ";
        str += " FROM [tbl_Campaign] ";
        str += " WHERE [AGENTCODE]='" + Utilities.BrokerCode().Trim() + "' ORDER BY [CAMPAIGNNAME] ASC ";

        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the sql and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetSexByLanguage(string lang)
    {
        string str = " SELECT ";
        str +=" [CLTSEX],[CLTSEX_LONGDESC] ";
        str +=" FROM [tbl_Sex] ";
        str +=" WHERE [LANG]='" + lang + "' ORDER  BY [ID] ASC ";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the sql and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetSexByLanguageAndTitle(string lang,string title )
    {
        if (title.Equals("�ҧ���"))
        {
            title = "�.�.";
        }
        string str = " SELECT ";
        str += " [tbl_Title].[DESCITEM],";
        str += " [tbl_Title].[LONGDESC],";
        str += " [tbl_Title].[SEX],";
        str += " [tbl_Title].[LANG],";
        str += " [tbl_Sex].[CLTSEX],";
        str += " [tbl_Sex].[CLTSEX_LONGDESC] ";
        str += " FROM [tbl_Title] ";
        str += " LEFT JOIN [tbl_Sex] ON [tbl_Title].[SEX] = [tbl_Sex].[CLTSEX] ";
        str += " WHERE [tbl_Title].[DESCITEM] like '" + title + "' and [tbl_Sex].[LANG]='" + lang + "';";

        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the sql and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    
    public static DataTable GetNationalityThaiLanguage()
    {
        string str = " SELECT ";
        str +=" [DESCITEM],[ENG_LANG_NATIONALITY],[THAI_LANG_NATIONALITY] ";
        str +=" FROM [tbl_Nationality] ";
        str += " WHERE [THAI_LANG_NATIONALITY] is not null  ORDER  BY [THAI_LANG_NATIONALITY] ASC ";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the sql and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetNationalityEngLanguage()
    {
        string str = " SELECT ";
        str += " [DESCITEM],[ENG_LANG_NATIONALITY],[THAI_LANG_NATIONALITY] ";
        str += " FROM [tbl_Nationality] ";
        str += " WHERE [ENG_LANG_NATIONALITY] is not null  ORDER  BY [ENG_LANG_NATIONALITY] ASC ";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the sql and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetMarriedByLanguage(string lang)
    {
        string str = " SELECT ";
        str +=" [MARRYD],[MARRYD_LONGDESC] ";
        str +=" FROM [tbl_Married] ";
        str +=" WHERE [LANG]='" + lang + "' ORDER  BY [ID] ASC ";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the sql and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetTitleByLanguage(string lang)
    {
        string str = " SELECT ";
        str +=" [DESCITEM],[LONGDESC],[SEX] ";
        str +=" FROM [tbl_Title] ";
        str +=" WHERE [LONGDESC] not in ('���','�ҧ���','�ҧ') and [LANG]='" + lang + "'";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the sql and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static DataTable GetTitleLanguage(string lang)
    {
        string str = " SELECT ";
        str += " [DESCITEM],[LONGDESC],[SEX] ";
        str += " FROM [tbl_Title]  ";
        str += " WHERE [LANG]='" + lang + "'";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the sql and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static DataTable GetDocument(string clienttype)
    {
        string str = " SELECT KYCDocumentID,KYCDocumentType,KYCDocumentName   from dbo.KYCDocument  ";
        str += "  where KYCClientType ='" + clienttype + "'";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommandKYC();
        // set the sql statement
        comm.CommandText = str;
        // execute the sql and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetAmphurByProvince(string provincecode)
    {
        string str = " SELECT ";
        str += " [AmphurID],[Amphur] ";
        str += " FROM [tbl_Amphur] ";
        str += " WHERE [ProvinceID]='" + provincecode + "' ORDER  BY [Amphur] ASC;";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the sql and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    //Update 2009-07-21
    //Text:
    //Value:
    public static DataTable GetAmphurByProvinceThai(string provincecode)
    {
        string str = " SELECT ";
        str += " [AmphurID],[Amphur] ";
        str += " FROM [tbl_Amphur] ";
        str += " WHERE [ProvinceID]='" + provincecode + "' ORDER  BY [Amphur] ASC;";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the sql and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    //Update 2009-07-21
    //Text:
    //Value:

    public static DataTable GetAmphurByProvinceEng(string provincecode)
    {
        string str = " SELECT ";
        str += " [AmphurID],[Amphur_EN] ";
        str += " FROM [tbl_Amphur] ";
        str += " WHERE [ProvinceID]='" + provincecode + "' ORDER  BY [Amphur_EN] ASC;";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the sql and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetTumbolByProvinceAndAmphur(string province, string amphur)
    {
        string str = " SELECT ";
        str += " [TumbolID],[Tumbol] ";
        str += " FROM [tbl_Tumbol] ";
        str += " WHERE [ProvinceID]='" + province + "'and [AmphurID]='" + amphur + "' ORDER  BY [Tumbol] ASC;";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the sql and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    //Update 2009-07-21
    //Text:
    //Value:
    public static DataTable GetTumbolByProvinceAndAmphurThai(string province, string amphur)
    {
        string str = " SELECT ";
        str += " [TumbolID],[Tumbol] ";
        str += " FROM [tbl_Tumbol] ";
        str += " WHERE [ProvinceID]='" + province + "'and [AmphurID]='" + amphur + "' ORDER  BY [Tumbol] ASC;";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the sql and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    //Update 2009-07-21
    //Text:
    //Value:
    public static DataTable GetTumbolByProvinceAndAmphurEng(string province, string amphur)
    {
        string str = " SELECT ";
        str += " [TumbolID],[Tumbol_EN] ";
        str += " FROM [tbl_Tumbol] ";
        str += " WHERE [ProvinceID]='" + province + "'and [AmphurID]='" + amphur + "' ORDER  BY [Tumbol_EN] ASC;";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the sql and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static void CreateClientBroker(ClientBrokerDetails clientbroker)
    {
        string str ="";
        str += " INSERT INTO [tbl_ClientBroker]([CLNTNUM],[BROKERCODE],[GROUPBROKERID]) ";
        str +=" VALUES (@ClientNo,@BrokerCode,@GroupBrokerId) ";
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = str;

        //CREATE NEW PARAMETER 
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ClientNo";
        param.Value = clientbroker.ClientCode;
        param.DbType  = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@BrokerCode";
        param.Value = clientbroker.BrokerCode;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@GroupBrokerId";
        param.Value = clientbroker.GroupBrokerId;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        GenericDataAccess.ExecuteNonQuery(comm);
    }

    //UPDATE 2009-07-31
    //ADD FIELD TAXID  str += ",[tbl_Client].[TAXID]";
    public static void CreateClient(ClientDetails client)
    {
        //string str = "";
        //str += " INSERT INTO [tbl_ClientBroker]([CLNTNUM],[BROKERCODE]) ";
        //str += " VALUES (@ClientNo,@BrokerCode) ";

        string str = "";
        str +=" INSERT INTO [tbl_Client] ";
           str +="([CLNTNUM] "; //1
           str +=",[CLTTYPE] "; //2
           str +=",[SALUTL] "; //3
           str +=",[LGIVNAME] "; //4
           str +=",[LSURNAME] ";//5
           str +=",[CLTADDR01] ";//6
           str +=",[CLTADDR02] ";//7
           str +=",[CLTADDR03] ";//8
           str +=",[CLTADDR04] ";//9
           str +=",[CLTADDR05] ";//10
           str +=",[CLTPCODE] ";//11
           str +=",[CTRYCODE] ";//12
           str +=",[CLTSEX] ";//13
           str +=",[MARRYD] ";//14
           str +=",[CLTSTAT] ";//15
           str +=",[ADDRTYPE] ";//16
           str +=",[SECUITYNO] ";//17
           str +=",[RMBLPHONE] ";//18
           str +=",[CLTPHONE01] ";//19
           str +=",[CLTPHONE02] ";//20
           str +=",[RINTERNET] ";//21
           str +=",[NATLTY] ";//22
           str +=",[CLTDOB] ";//23
           str +=",[FAXNO] ";//24
           str +=",[FAXNO01] ";//25
           str +=",[LANGUAGE] ";//26 
           str +=",[TAXID] ";//29
           str +=",[DATIME] "; //27
           str +=",[SOURCE]) ";//28
           str +=" VALUES ";
           str +="(@CLNTNUM ";//1
           str +=",@CLTTYPE ";//2
           str +=",@SALUTL ";//3
           str +=",@LGIVNAME ";//4
           str +=",@LSURNAME ";//5
           str +=",@CLTADDR01 ";//6
           str +=",@CLTADDR02 ";//7
           str +=",@CLTADDR03 ";//8
           str +=",@CLTADDR04 ";//9
           str +=",@CLTADDR05 ";//10
           str +=",@CLTPCODE ";//11
           str +=",@CTRYCODE ";//12
           str +=",@CLTSEX ";//13
           str +=",@MARRYD ";//14
           str +=",@CLTSTAT ";//15
           str +=",@ADDRTYPE ";//16
           str +=",@SECUITYNO ";//17
           str +=",@RMBLPHONE ";//18
           str +=",@CLTPHONE01 ";//19
           str +=",@CLTPHONE02 ";//20
           str +=",@RINTERNET ";//21
           str +=",@NATLTY ";//22
           str +=",@CLTDOB ";//23
           str +=",@FAXNO ";//24
           str +=",@FAXNO01 ";//25
           str +=",@LANGUAGES ";//26
           str +=",@TAXID ";//29
           str +=",@DATIMES ";//27
           str +=",@SOURCES) ";//28
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = str;

        //CREATE NEW PARAMETER 
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@CLNTNUM"; //1
        param.Value = client.ClientNo;
        param.DbType = DbType.String ;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLTTYPE"; //2
        param.Value = client.ClientType ;
        param.DbType = DbType.StringFixedLength;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@SALUTL";  //3
        param.Value = client.Salutation ;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@LGIVNAME"; //4
        param.Value = client.Name ;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@LSURNAME";//5
        param.Value = client.Surname ;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLTADDR01";//6
        param.Value = client.Address1 ;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLTADDR02";//7
        param.Value = client.Address2;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLTADDR03";//8
        param.Value = client.Address3 ;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLTADDR04";//9
        param.Value = client.Address4 ;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLTADDR05";//10
        param.Value = client.Address5 ;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLTPCODE";//11
        param.Value = client.PostCode ;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CTRYCODE";//12
        param.Value = client.Country ;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLTSEX";//13
        param.Value = client.SEX ;
        param.DbType = DbType.StringFixedLength;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@MARRYD";//14
        param.Value = client.Married ;
        param.DbType = DbType.StringFixedLength;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLTSTAT";//15
        param.Value = client.Status ;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@ADDRTYPE";//16
        param.Value = client.BusRes;
        param.DbType = DbType.StringFixedLength;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@SECUITYNO";//17
        param.Value = client.ID;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@RMBLPHONE";//18
        param.Value = client.Phone;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLTPHONE01";//19
        param.Value = client.PhoneOffice;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLTPHONE02";//20
        param.Value = client.PhoneMoblie ;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@RINTERNET";//21
        param.Value = client.Emails ;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@NATLTY";//22
        param.Value = client.Nationality ;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLTDOB";//23
        param.Value = client.DOB ;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@FAXNO";//24
        param.Value = client.FAXNO ;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@FAXNO01";//25
        param.Value = client.FAXNO01;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@LANGUAGES";//26
        param.Value = client.Language ;
        param.DbType = DbType.StringFixedLength;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@TAXID";//29
        param.Value = client.TaxID;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@DATIMES";//27
        param.Value = client.Datetime;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@SOURCES";//28
        param.Value = "WEB";
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        
        
        //GenericDataAccess.ExecuteNonQuery(comm);
        comm.Connection.Open();
        DbTransaction tran = comm.Connection.BeginTransaction();
        comm.Transaction = tran;

        int roweffect = -1;
        roweffect = comm.ExecuteNonQuery();
        if (roweffect == -1)
        {
            comm.Transaction.Rollback();
            return;
        }
        if (!client.LicenseDriver.Equals(""))
        {
            str = "";
            str += "INSERT INTO [tbl_LicenseDriver]([CLNTNUM],[DLICENSE]) ";
            str += "VALUES (@CCode,@LicensDriver) ";

            comm.CommandText = str;
            param = null;
            DbParameter param1 = comm.CreateParameter();
            //CREATE NEW PARAMETER 
            param1 = comm.CreateParameter();
            param1.ParameterName = "@CCode"; //1
            param1.Value = client.ClientNo;
            param1.DbType = DbType.String;
            comm.Parameters.Add(param1);

            //CREATE NEW PARAMETER 
            param1 = comm.CreateParameter();
            param1.ParameterName = "@LicensDriver"; //2
            param1.Value = client.LicenseDriver;
            param1.DbType = DbType.String;
            comm.Parameters.Add(param1);


            roweffect = -1;
            roweffect = comm.ExecuteNonQuery();
            if (roweffect == -1)
            {
                comm.Transaction.Rollback();
                return;
            }
        }

        str = "";
        str += " INSERT INTO [tbl_ClientBroker]([CLNTNUM],[BROKERCODE],[GROUPBROKERID]) ";
        str += " VALUES (@ClientNo,@BrokerCode,@GroupBrokerId) ";

        comm.CommandText = str;
        //CREATE NEW PARAMETER 
        param = null;
        DbParameter param2 = comm.CreateParameter();
        param2.ParameterName = "@ClientNo";
        param2.Value = client.ClientNo;
        param2.DbType = DbType.String;
        comm.Parameters.Add(param2);

        //CREATE NEW PARAMETER 
        param2 = comm.CreateParameter();
        param2.ParameterName = "@BrokerCode";
        param2.Value = Utilities.BrokerCode();
        param2.DbType = DbType.String;
        comm.Parameters.Add(param2);

        //CREATE NEW PARAMETER 
        param2 = comm.CreateParameter();
        param2.ParameterName = "@GroupBrokerId";
        param2.Value = client.GroupBrokerId;
        param2.DbType = DbType.String;
        comm.Parameters.Add(param2);

        roweffect = -1;
        roweffect = comm.ExecuteNonQuery();
        if (roweffect == -1)
        {
            comm.Transaction.Rollback();
            return;
        }
        else
        {
            comm.Transaction.Commit();
        }
        comm.Connection.Close();
    }

    //UPDATE 2010-09-30
    public static void UpdateClient(ClientDetails client)
    { 
        string str = "sp_setUpdateClient";

        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateStorePCommand();
        // set the sql statement        
        comm.CommandText = str;

        DbParameter param = comm.CreateParameter();
        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLNTNUM";
        param.Value = client.ClientNo;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);
        //SET OUTPUT

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLTADDR01";
        param.Value = client.Address1;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLTADDR02";
        param.Value = client.Address2;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLTADDR03";
        param.Value = client.Address3;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLTADDR04";
        param.Value = client.Address4 ;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLTADDR05";
        param.Value = client.Address5;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLTPCODE";
        param.Value = client.PostCode;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CTRYCODE";
        param.Value = client.Country;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLTSEX";
        param.Value = client.SEX ;
        param.DbType = DbType.StringFixedLength;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@MARRYD";
        param.Value = client.Married;
        param.DbType = DbType.StringFixedLength;
        comm.Parameters.Add(param);

		 //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLTSTAT";
        param.Value = client.Status;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);
		
        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@ADDRTYPE";
        param.Value = client.BusRes;
        param.DbType = DbType.StringFixedLength;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@SECUITYNO";
        param.Value = client.ID;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

         //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@RMBLPHONE";
        param.Value = client.Phone;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLTPHONE01";
        param.Value = client.PhoneOffice;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLTPHONE02";
        param.Value = client.PhoneMoblie;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@RINTERNET";
        param.Value = client.Emails;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@NATLTY";
        param.Value = client.Nationality;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLTDOB";
        param.Value = client.DOB;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@FAXNO";
        param.Value = client.FAXNO;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@FAXNO01";
        param.Value = client.FAXNO01;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@LANGUAGE";
        param.Value = client.Language;
        param.DbType = DbType.StringFixedLength;
        comm.Parameters.Add(param);

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@TAXID";
        param.Value = client.TaxID;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

	    //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@DATIME";
        param.Value = client.Datetime;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

		//CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@DLICENSE";
        param.Value = client.LicenseDriver;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);


        GenericDataAccess.ExecuteNonQuery(comm);
    }
    public static int DeleteClient()
    {
        return 0;
    }
    public static DataTable GetClientData(string Id)
    {
        string str = "SELECT [tbl_ClientBroker].[CLNTNUM]";
        str += ",[tbl_ClientBroker].[BROKERCODE]";
        str += ",[tbl_Client].[CLNTNUM] ";
        str += ",[tbl_Client].[CLTTYPE]";
        str += ",[tbl_Client].[SALUTL]";
        str += ",[tbl_Client].[LGIVNAME]";
        str += ",[tbl_Client].[LSURNAME]";
        str += ",[tbl_Client].[CLTADDR01]";
        str += ",[tbl_Client].[CLTADDR02]";
        str += ",[tbl_Client].[CLTADDR03]";
        str += ",[tbl_Client].[CLTADDR04]";
        str += ",[tbl_Client].[CLTADDR05]";
        str += ",[tbl_Client].[CLTPCODE]";
        str += ",[tbl_Client].[CTRYCODE]";
        str += ",[tbl_Client].[CLTSEX]";
        str += ",[tbl_Client].[MARRYD]";
        str += ",[tbl_Client].[CLTSTAT]";
        str += ",[tbl_Client].[ADDRTYPE]";
        str += ",[tbl_Client].[SECUITYNO]";
        str += ",[tbl_Client].[RMBLPHONE]";
        str += ",[tbl_Client].[CLTPHONE01]";
        str += ",[tbl_Client].[CLTPHONE02]";
        str += ",[tbl_Client].[RINTERNET]";
        str += ",[tbl_Client].[NATLTY]";
        str += ",[tbl_Client].[CLTDOB]";
        str += ",[tbl_Client].[FAXNO]";
        str += ",[tbl_Client].[FAXNO01]";
        str += ",[tbl_Client].[LANGUAGE]";
        str += ",[tbl_Client].[DATIME]";
        str += " FROM [tbl_ClientBroker]  ";
        str += " LEFT JOIN	[tbl_Client] ON [tbl_ClientBroker].[CLNTNUM]=[tbl_Client].[CLNTNUM] ";
        str += " WHERE [tbl_ClientBroker].[GROUPBROKERID]='" + Utilities.GetGroupBrokerID() + "'";
        str += " AND [tbl_Client].[CLNTNUM]='" + Id + "'";

        
        //str += " WHERE [tbl_ClientBroker].[BROKERCODE]='" + Utilities.BrokerCode() + "'";        
        //str += " WHERE [tbl_Client].[CLNTNUM]='" + Id + "'";

        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static DataTable GetBenificialyName(string Id)
    {
        string str = " SELECT ";
        str += " [LSURNAME] ";
        str += " FROM [tbl_Benefit] ";
        str += " WHERE [CLNTNUM]='" + Id + "'";
        str += " AND [LANG]='T'";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the sql and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }
    public static string GetCampaignName(string campaignCode)
    {
        string str = " SELECT ";
        str += " [CAMPAIGNNAME] ";
        str += " FROM [tbl_Campaign] ";
        str += " WHERE [CAMPAIGNCODE]='" + campaignCode + "'" ;


	//+ "AND [GROUPBROKERID]='" + Utilities.GetGroupBrokerID() + "'";
        
        //str += " WHERE [CAMPAIGNCODE]='" + campaignCode + "'" + "AND [AGENTCODE]='" + Utilities.BrokerCode() + "'";

        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        DataTable dt = GenericDataAccess.ExecuteSelectCommand(comm);
        if (dt.Rows.Count > 0)
        {
            string campaignName = dt.Rows[0]["CAMPAIGNNAME"].ToString();
            return campaignName;
        }
        return "";
    }

    //-------Add 2010-10-04-------
    public static void UpdateClientLog(string clientCode, string userId)
    {

        string str = "SP_setClientLog";

        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateStorePCommand();
        // set the sql statement        
        comm.CommandText = str;

        DbParameter param = comm.CreateParameter();
        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@CLIENTCODE";
        param.Value = clientCode;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);
        //SET OUTPUT

        //CREATE NEW PARAMETER 
        param = comm.CreateParameter();
        param.ParameterName = "@USERID";
        param.Value = userId;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);
        
        GenericDataAccess.ExecuteNonQuery(comm);

    }

}