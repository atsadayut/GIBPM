using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Data.Common;
using System.Data.SqlClient;


/// <summary>
/// Summary description for UserMember
/// </summary>
/// 

public static class Broker
{
    static Broker()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public static string GetBrokerNameByUsername(string name)
    {
        string str = "SELECT [BROKERCODE]";
        str += " FROM [tbl_UserHost]";
        str += " WHERE [USERNAME]='"+name+"' ";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        DataTable dt= GenericDataAccess.ExecuteSelectCommand(comm);
        if (dt.Rows.Count > 0)
        {
            return (dt.Rows[0][0].ToString());
        }
        return "";
    }
    public static DataTable GetAllBrokerInGroupByUsername(string name)
    {
        string str = "SELECT [tbl_Brokers].[BROKERCODE],[tbl_Brokers].[BROKERNAME],[tbl_UserHost].[GROUPBROKERID] ";
        str += " FROM [tbl_UserHost]";
        str += " INNER JOIN  [tbl_MainBrokerIndex] ON [tbl_UserHost].[GROUPBROKERID]=[tbl_MainBrokerIndex].[GROUPBROKERID] ";
        str += " INNER JOIN  [tbl_Brokers] ON [tbl_MainBrokerIndex].[BROKERCODE]=[tbl_Brokers].[BROKERCODE] ";
        str += " WHERE [tbl_UserHost].[USERNAME]='" + name + "' ORDER BY [tbl_Brokers].[BROKERNAME] ASC";


	//str += " WHERE [tbl_UserHost].[USERNAME]='" + name + "' ORDER BY [tbl_Brokers].[BROKERNAME]";
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        DataTable dt= GenericDataAccess.ExecuteSelectCommand(comm);
        if (dt.Rows.Count > 0)
        {
            return dt;
        }
        return null;
    }
    public static DataTable GetBrokerInGroupId(string groupId)
    {
        string str = "SELECT [tbl_Brokers].[BROKERCODE] ";
        str +=" ,[tbl_Brokers].[BROKERNAME] ";
        str +=" ,[tbl_Brokers].[BROKDESC] ";
        str +=" FROM [tbl_MainBrokerIndex] ";
        str +=" INNER JOIN  [tbl_Brokers] ON [tbl_MainBrokerIndex].[BROKERCODE]= [tbl_Brokers].[BROKERCODE] ";
	str += " WHERE [tbl_MainBrokerIndex].[GROUPBROKERID]='" + groupId + "' ORDER BY BROKERNAME ASC";

        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static DataTable GetBrokerName(string BrokerCode)
    {
        string str = "SELECT [tbl_Brokers].[BROKERCODE] ";
        str += " ,[tbl_Brokers].[BROKERNAME] ";
        str += " ,[tbl_Brokers].[BROKDESC] ";
        str += " FROM [tbl_Brokers] ";
        str += " WHERE [tbl_Brokers].[BROKERCODE]='" + BrokerCode + "'";

        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static DataTable GetEmailReplyApproved(string JobNo)
    {
        string str = "select d1.UserName,d2.Email from dbo.tbl_UserHost d1 ";
            str += " inner join dbo.aspnet_Membership d2 on ";
            str += " d1.UserId = d2.UserId ";
            str += " where UserName in ( ";
            str += " select USERWEBCREATE from dbo.Tran_Policy  ";
            str += " where JOBNO = '" + JobNo + "'" ;
            str += " group by USERWEBCREATE)"; 

        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static string GetBrokerName2(string BrokerCode)
    {
        string str = "SELECT [tbl_Brokers].[BROKERCODE] ";
        str += " ,[tbl_Brokers].[BROKERNAME] ";
        str += " ,[tbl_Brokers].[BROKDESC] ";
        str += " FROM [tbl_Brokers] ";
        str += " WHERE [tbl_Brokers].[BROKERCODE]='" + BrokerCode + "'";

        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // set the sql statement
        comm.CommandText = str;
        // execute the stored procedure and return the results
        DataTable dt = GenericDataAccess.ExecuteSelectCommand(comm);
        return dt.Rows[0]["BROKERNAME"].ToString().Trim(); 
    }
}