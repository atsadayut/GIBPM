﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Persnal
/// </summary>
public class Persnal
{
    public string ClientAddress1 { get; set; }
    public string ClientAddress2 { get; set; }
    public string Province { get; set; }
    public string Amphur { get; set; }
    public string Tumbol { get; set; }
    public string ProvinceCode { get; set; }
    public string AmphurCode { get; set; }
    public string TumbolCode { get; set; }
    public string PostCode { get; set; }
    public string Email { get; set; }
    public string Tel { get; set; }
    public string DiscountCode { get; set; }
	public Persnal()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public string toText()
    {
        string temp = "";

        temp += "<table> <tr><td width='90'>Address:</td><td><span style='color:red'> " + ClientAddress1
            + " " + ClientAddress2
            + " " + Tumbol
            + ", " + Amphur
            + ", " + Province
            + " " + PostCode;
        temp += "</span></td></tr><tr>";
        temp += "<td>Tel:</td><td><span style='color:red'>" + Tel;
        temp += "</span></td></tr><tr>";
        temp += "<td>E-mail:</td><td><span style='color:red'>" + Email + "</span></td></tr></table>";
        return temp;
    }


    public int DiscountAmount { get; set; }
}