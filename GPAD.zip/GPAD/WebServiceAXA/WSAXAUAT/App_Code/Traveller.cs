﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Traveller
/// </summary>
public class Traveller
{
    public string ClientTitleValue { get; set; }
    public string ClientTitle { get; set; }
    public string ClientName { get; set; }
    public string ClientSurName { get; set; }
    public string Birthday { get; set; }
    public string PassportID { get; set; }
    public string Beneficiary { get; set; }

	public Traveller()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public string ToText(){
        string temp = "";
        temp += ClientTitle + " " + ClientName + " " + ClientSurName;
        temp += ", Birthday : " + Birthday + ", NRIC/Pass No : " + PassportID + ", Beneficiary :" + Beneficiary;

        return temp;
    }
}