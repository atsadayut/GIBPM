﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

using TA.BLL;
using TA.BusinessObjects;
using TA.DAL;
using System.Data;
using System.Data.Common;
using System.IO;
using System.Globalization;
using System.Collections;
using System.Net;
using System.Web.Services.Protocols;
using PA.BLL;
using PA.BusinessObjects;

/// <summary>
/// Summary description for INF_AXACOMMONWS
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class INF_AXACOMMONWS : System.Web.Services.WebService {

    public INF_AXACOMMONWS () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    public class ObjAXATitle
    {
        public string titleName { get; set; }
        //public string sex { get; set; }
        //public string language { get; set; }
        //public int isEnable { get; set; }
    }

    public class ObjAXAListTitle
    {
        public string _msg { get; set; }
        public List<ObjAXATitle> _listTitle { get; set; }
    }

    public class ObjAXAProvince
    {
        public string provinceID { get; set; }
        public string province { get; set; }
    }

    public class ObjAXAListProvince
    {
        public string _msg { get; set; }
        public List<ObjAXAProvince> _listProvince { get; set; }
    }

    public class ObjAXAAmphur
    {
        public string amphurID { get; set; }
        public string amphur { get; set; }
    }

    public class ObjAXAListAmphur
    {
        public string _msg { get; set; }
        public List<ObjAXAAmphur> _listAmphur { get; set; }
    }

    public class ObjAXATumbol
    {
        public string tumbolID { get; set; }
        public string tumbol { get; set; }
    }

    public class ObjAXAListTumbol
    {
        public string _msg { get; set; }
        public List<ObjAXATumbol> _listTumbol { get; set; }
    }

    public class ObjAXALanguage
    {                
        public string language { get; set; }
        public string languageFull { get; set; }
    }

    public class ObjAXAListLanguage
    {
        public string _msg { get; set; }
        public List<ObjAXALanguage> _listLanguage { get; set; }
    }

    public class ObjAXAClientType
    {
        public string clientType_code { get; set; }
        public string clientType_name { get; set; }
    }

    public class ObjAXAListClientType
    {
        public string _msg { get; set; }
        public List<ObjAXAClientType> _listClientType { get; set; }
    }

    public class ObjAXAGender
    {
        public string _genderCode { get; set; }
        public string _genderName { get; set; }
    }

    public class ObjAXAListGender
    {
        public string _msg { get; set; }
        public List<ObjAXAGender> _listGender { get; set; }
    }

    public class ObjAXAMarital
    {
        public string _marriedCode { get; set; }
        public string _marriedName { get; set; }
    }

    public class ObjAXAListMarital
    {
        public string _msg { get; set; }
        public List<ObjAXAMarital> _listMarital { get; set; }
    }

    public class ObjAXANationality
    {
        public string _nationalityCode { get; set; }
        public string _nationalityName { get; set; }
    }

    public class ObjAXAListNationality
    {
        public string _msg { get; set; }
        public List<ObjAXANationality> _listNationality { get; set; }
    }

    public class ObjAXARelation
    {
        //public int _ID { get; set; }
        public string _relation { get; set; }
    }

    public class ObjAXAListRelation
    {
        public string _msg { get; set; }
        public List<ObjAXARelation> _listRelation { get; set; }
    }

    public class ObjAXAPATitle
    {
        public string _title { get; set; }
        public string _titlelong { get; set; }
        public string _sex { get; set; }
    }

    public class ObjAXAPAListTitle
    {
        public string _msg { get; set; }
        public List<ObjAXAPATitle> _listTitle { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="language"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAListTitle GetAXATitle(string agentCode, string groupBrokerId, string password, string language)
    {
        string retMsg = string.Empty;
        string langFilter = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();
        DataTable dt;

        ObjAXAListTitle objRetTitle = new ObjAXAListTitle();
        List<ObjAXATitle> lstAXATATitle = new List<ObjAXATitle>();
        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            #endregion

            if (isValidateOK == true)
            {
                TATBTitleBLL clstitle = new TATBTitleBLL();

                if (string.Compare(langFilter, "T") == 0)
                {
                    dt = clstitle.GetDtTATBCountrysThai();
                }
                else
                {
                    dt = clstitle.GetDtTATBCountrys();
                }

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ObjAXATitle item = new ObjAXATitle();
                    item.titleName = dt.Rows[i]["TitleName"].ToString();

                    lstAXATATitle.Add(item);
                }

                retMsg = "SUCCESS";
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        //msg = retMsg;
        //return lstAXATATitle.Cast<ObjAXATitle>().ToList();
        objRetTitle._msg = retMsg;
        objRetTitle._listTitle = lstAXATATitle.Cast<ObjAXATitle>().ToList(); 

        return objRetTitle;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="language"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAListProvince GetAXAProvince(string agentCode, string groupBrokerId, string password, string language)
    {
        string retMsg = string.Empty;
        string langFilter = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();
        DataTable dt;

        ObjAXAListProvince objListProvince = new ObjAXAListProvince();
        List<ObjAXAProvince> lstAXATAProvince = new List<ObjAXAProvince>();
        try
        {
            if (string.Compare(langFilter, "T") == 0)
            {
                dt = Client.GetProvinceThaiLanguage();
            }
            else
            {
                dt = Client.GetProvinceEngLanguage();
            }

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                ObjAXAProvince item = new ObjAXAProvince();
                item.provinceID = dt.Rows[i]["ProvinceID"].ToString();

                if (string.Compare(langFilter, "T") == 0)
                {
                    item.province = dt.Rows[i]["Description"].ToString();
                }
                else
                {
                    item.province = dt.Rows[i]["Description_EN"].ToString();
                }

                lstAXATAProvince.Add(item);
            }

            retMsg = "SUCCESS";
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        //msg = retMsg;
        //return lstAXATAProvince.Cast<ObjAXAProvince>().ToList();
        objListProvince._msg = retMsg;
        objListProvince._listProvince = lstAXATAProvince.Cast<ObjAXAProvince>().ToList();

        return objListProvince;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="provinceID"></param>
    /// <param name="language"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAListAmphur GetAXAAmphur(string agentCode, string groupBrokerId, string password, string provinceID, string language)
    {
        string retMsg = string.Empty;
        string langFilter = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();
        DataTable dt;

        ObjAXAListAmphur objListAmphur = new ObjAXAListAmphur();
        List<ObjAXAAmphur> lstAXATAAmphur = new List<ObjAXAAmphur>();
        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            #endregion

            if (isValidateOK == true)
            {
                if (string.Compare(langFilter, "T") == 0)
                {
                    dt = Client.GetAmphurByProvinceThai(provinceID);
                }
                else
                {
                    dt = Client.GetAmphurByProvinceEng(provinceID);
                }

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ObjAXAAmphur item = new ObjAXAAmphur();
                    item.amphurID = dt.Rows[i]["AmphurID"].ToString();

                    if (string.Compare(langFilter, "T") == 0)
                    {
                        item.amphur = dt.Rows[i]["Amphur"].ToString();
                    }
                    else
                    {
                        item.amphur = dt.Rows[i]["Amphur_EN"].ToString();
                    }

                    lstAXATAAmphur.Add(item);
                }

                retMsg = "SUCCESS";
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        //msg = retMsg;
        //return lstAXATAAmphur.Cast<ObjAXAAmphur>().ToList();
        objListAmphur._msg = retMsg;
        objListAmphur._listAmphur = lstAXATAAmphur.Cast<ObjAXAAmphur>().ToList();

        return objListAmphur;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="provinceID"></param>
    /// <param name="amphurID"></param>
    /// <param name="language"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAListTumbol GetAXATumbol(string agentCode, string groupBrokerId, string password, string provinceID, string amphurID, string language)
    {
        string retMsg = string.Empty;
        string langFilter = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();
        DataTable dt;

        ObjAXAListTumbol objListTumbol = new ObjAXAListTumbol();
        List<ObjAXATumbol> lstAXATATumbol = new List<ObjAXATumbol>();
        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            #endregion

            if (isValidateOK == true)
            {
                if (string.Compare(langFilter, "T") == 0)
                {
                    dt = Client.GetTumbolByProvinceAndAmphurThai(provinceID, amphurID);
                }
                else
                {
                    dt = Client.GetTumbolByProvinceAndAmphurEng(provinceID, amphurID);
                }

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ObjAXATumbol item = new ObjAXATumbol();
                    item.tumbolID = dt.Rows[i]["TumbolID"].ToString();

                    if (string.Compare(langFilter, "T") == 0)
                    {
                        item.tumbol = dt.Rows[i]["Tumbol"].ToString();
                    }
                    else
                    {
                        item.tumbol = dt.Rows[i]["Tumbol_EN"].ToString();
                    }

                    lstAXATATumbol.Add(item);
                }

                retMsg = "SUCCESS";
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        //msg = retMsg;
        //return lstAXATATumbol.Cast<ObjAXATumbol>().ToList();
        objListTumbol._msg = retMsg;
        objListTumbol._listTumbol = lstAXATATumbol.Cast<ObjAXATumbol>().ToList();

        return objListTumbol;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAListLanguage GetAXALanguage(string agentCode, string groupBrokerId, string password)
    {
        string retMsg = string.Empty;
        ObjAXAListLanguage objListLanguage = new ObjAXAListLanguage();
        List<ObjAXALanguage> lstAXALanguage = new List<ObjAXALanguage>();
        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            #endregion

            if (isValidateOK == true)
            {
                ObjAXALanguage itemThai = new ObjAXALanguage();
                itemThai.language = "T";
                itemThai.languageFull = "Thai";
                lstAXALanguage.Add(itemThai);

                ObjAXALanguage itemEng = new ObjAXALanguage();
                itemEng.language = "E";
                itemEng.languageFull = "English";
                lstAXALanguage.Add(itemEng);

                retMsg = "SUCCESS";
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        //msg = retMsg;
        //return lstAXALanguage.Cast<ObjAXALanguage>().ToList();
        objListLanguage._msg = retMsg;
        objListLanguage._listLanguage = lstAXALanguage.Cast<ObjAXALanguage>().ToList();

        return objListLanguage;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAListClientType GetAXAClientType(string agentCode, string groupBrokerId, string password)
    {
        string retMsg = string.Empty;
        ObjAXAListClientType objListClientType = new ObjAXAListClientType();
        List<ObjAXAClientType> lstAXAClientType = new List<ObjAXAClientType>();
        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            #endregion

            if (isValidateOK == true)
            {
                ObjAXAClientType itemP = new ObjAXAClientType();
                itemP.clientType_code = "P";
                itemP.clientType_name = "Personal";
                lstAXAClientType.Add(itemP);

                ObjAXAClientType itemC = new ObjAXAClientType();
                itemC.clientType_code = "C";
                itemC.clientType_name = "Corporate";
                lstAXAClientType.Add(itemC);

                retMsg = "SUCCESS";
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        //msg = retMsg;
        //return lstAXAClientType.Cast<ObjAXAClientType>().ToList();
        objListClientType._msg = retMsg;
        objListClientType._listClientType = lstAXAClientType.Cast<ObjAXAClientType>().ToList();

        return objListClientType;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="language"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAListGender GetAXAGender(string agentCode, string groupBrokerId, string password, string language)
    {
        string retMsg = string.Empty;
        language = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();

        ObjAXAListGender objListGender = new ObjAXAListGender();
        List<ObjAXAGender> lstAXAGender = new List<ObjAXAGender>();

        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            #endregion

            if (isValidateOK == true)
            {
                PAGetDDLTableBLL clsPAGetDDLTableBLL = new PAGetDDLTableBLL();
                DataTable dt = clsPAGetDDLTableBLL.GetDDLGender(language);

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ObjAXAGender item = new ObjAXAGender();
                    string genderCode = dt.Rows[i]["gendercode"].ToString();
                    string genderName = dt.Rows[i]["gender"].ToString();

                    item._genderCode = genderCode;
                    item._genderName = genderName;

                    lstAXAGender.Add(item);
                }

                retMsg = "SUCCESS";
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        //msg = retMsg;
        //return lstAXAGender.Cast<ObjAXAGender>().ToList();
        objListGender._msg = retMsg;
        objListGender._listGender = lstAXAGender.Cast<ObjAXAGender>().ToList();

        return objListGender;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="language"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAListMarital GetAXAMarital(string agentCode, string groupBrokerId, string password, string language)
    {
        string retMsg = string.Empty;
        language = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();

        ObjAXAListMarital objListMarital = new ObjAXAListMarital();
        List<ObjAXAMarital> lstAXAMarital = new List<ObjAXAMarital>();

        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            #endregion

            if (isValidateOK == true)
            {
                PAGetDDLTableBLL clsPAGetDDLTableBLL = new PAGetDDLTableBLL();
                DataTable dt = clsPAGetDDLTableBLL.GetDDLMarried(language);

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ObjAXAMarital item = new ObjAXAMarital();
                    string marriedCode = dt.Rows[i]["MarriedCode"].ToString();
                    string marriedName = dt.Rows[i]["Married"].ToString();

                    item._marriedCode = marriedCode;
                    item._marriedName = marriedName;

                    lstAXAMarital.Add(item);
                }

                retMsg = "SUCCESS";
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        //msg = retMsg;
        //return lstAXAMarital.Cast<ObjAXAMarital>().ToList();
        objListMarital._msg = retMsg;
        objListMarital._listMarital = lstAXAMarital.Cast<ObjAXAMarital>().ToList();

        return objListMarital;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="language"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAListNationality GetAXANationality(string agentCode, string groupBrokerId, string password, string language)
    {
        string retMsg = string.Empty;
        language = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();

        ObjAXAListNationality objListNationality = new ObjAXAListNationality();
        List<ObjAXANationality> lstAXANationality = new List<ObjAXANationality>();

        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            #endregion

            if (isValidateOK == true)
            {
                PAGetDDLTableBLL clsPAGetDDLTableBLL = new PAGetDDLTableBLL();
                DataTable dt = clsPAGetDDLTableBLL.GetDDLNationality(language);

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ObjAXANationality item = new ObjAXANationality();
                    string nationalityCode = dt.Rows[i]["NationalityCode"].ToString();
                    string nationalityName = dt.Rows[i]["Nationality"].ToString();

                    item._nationalityCode = nationalityCode;
                    item._nationalityName = nationalityName;

                    lstAXANationality.Add(item);
                }

                retMsg = "SUCCESS";
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        //msg = retMsg;
        //return lstAXANationality.Cast<ObjAXANationality>().ToList();
        objListNationality._msg = retMsg;
        objListNationality._listNationality = lstAXANationality.Cast<ObjAXANationality>().ToList();

        return objListNationality;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="language"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAListRelation GetAXARelation(string agentCode, string groupBrokerId, string password, string language)
    {
        string retMsg = string.Empty;
        language = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();

        ObjAXAListRelation objListRelation = new ObjAXAListRelation();
        List<ObjAXARelation> lstAXARelation = new List<ObjAXARelation>();
        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            #endregion

            if (isValidateOK == true)
            {
                TATBRelationBLL clsTATBRelationBLL = new TATBRelationBLL();
                DataTable dt = clsTATBRelationBLL.GetDtTATBRelations(language);

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ObjAXARelation item = new ObjAXARelation();
                    int id = Convert.ToInt32(dt.Rows[i]["ID"].ToString());
                    string relation = dt.Rows[i]["Relation"].ToString();

                    //item._ID = id;
                    item._relation = relation;

                    lstAXARelation.Add(item);
                }

                retMsg = "SUCCESS";
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        //msg = retMsg;
        //return lstAXARelation.Cast<ObjAXARelation>().ToList();
        objListRelation._msg = retMsg;
        objListRelation._listRelation = lstAXARelation.Cast<ObjAXARelation>().ToList();

        return objListRelation;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="language"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAPAListTitle GetAXAPATitle(string agentCode, string groupBrokerId, string password, string language)
    {
        string retMsg = string.Empty;
        language = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();

        ObjAXAPAListTitle objListPATitle = new ObjAXAPAListTitle();
        List<ObjAXAPATitle> lstAXAPATitle = new List<ObjAXAPATitle>();

        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            #endregion

            if (isValidateOK == true)
            {
                PAGetDDLTableBLL clsPAGetDDLTableBLL = new PAGetDDLTableBLL();
                DataTable dt = clsPAGetDDLTableBLL.GetDDLTitle(language);

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ObjAXAPATitle item = new ObjAXAPATitle();
                    string title = dt.Rows[i]["TITLE"].ToString();
                    string titlelong = dt.Rows[i]["TITLELONG"].ToString();
                    string sex = dt.Rows[i]["SEX"].ToString();

                    item._title = title;
                    item._titlelong = titlelong;
                    item._sex = sex;

                    lstAXAPATitle.Add(item);
                }

                retMsg = "SUCCESS";
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        //msg = retMsg;
        //return lstAXAPATitle.Cast<ObjAXAPATitle>().ToList();
        objListPATitle._msg = retMsg;
        objListPATitle._listTitle = lstAXAPATitle.Cast<ObjAXAPATitle>().ToList();

        return objListPATitle;
    }

    [WebMethod]//Add Update 20150721
    public void SendEmailResetPassword(string agentCode, string groupBrokerId, string password, string email, string newpassword)
    {
        try
        {
            bool isValidateOK = true;

            string retMsg = String.Empty;
            string msgSendMail = String.Empty;

            #region ###Validate security & authorization into Web Service

            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out retMsg);

            if (isValidateOK == false)
            {
                throw new Exception(retMsg);
            }
            #endregion

            if (isValidateOK)
            {
                string emailFrom = "axatraveller@axa.co.th";
                string emailTo = email;
                string subject = "Reset You Password for AXA Thailand";

                string body = "เรียน ผู้ใช้บริการ<br/><br/>";
                body += "<p>บริษัท แอกซ่าประกันภัย จำกัด (มหาชน) ขอขอบคุณที่ท่านไว้วางใจให้บริษัทเป็นผู้ให้ความคุ้มครองแก่ลูกค้าของท่าน</p><br/><br/>";
                body += "<p>ดำเนินการเปลี่ยนรหัสผ่านให้ลูกค้าเรียบร้อยแล้ว</p><br/>";
                body += String.Format("<p>รหัสผ่านใหม่คือ {0}</p>", newpassword);

                body += "<p>ทั้งนี้ หากท่านมีข้อสงสัยประการใด สามารถติดต่อสอบถามกับเจ้าหน้าที่รับประกันภัยที่ดูแลท่านตลอดเวลาทำการ  </p><br/>";
                body += "<p>ขอแสดงความนับถือบริษัท<br/>แอกซ่าประกันภัย จำกัด (มหาชน)<br/>โทร. 02-118-8000</p>";
                body += "<p>บริการช่วยเหลือฉุกเฉิน 24 ชั่วโมง<br/>แอกซ่า ฮอตไลน์<br/>โทร. 02-642-6688, 02-206-5488<br/>เว็บไซด์ : <a href='http://www.axa.co.th' target='_blank'>www.axa.co.th</a></p>";

                Utilities.SendMail(emailFrom, emailTo, subject, body, true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}
