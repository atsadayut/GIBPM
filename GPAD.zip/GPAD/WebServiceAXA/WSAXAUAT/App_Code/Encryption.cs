﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Security.Cryptography;
using System.Globalization; 

public static class Encryption
{
    private static Byte[] _iv = { 15, 0, 53, 255, 78, 25, 72, 84 };
    private static string keysecret = "12345";
    /// <summary>
    /// FOR ENCODING
    /// </summary>
    /// <param name="text"></param>
    /// <returns></returns>
    public static string RsaSymenEncrypt(string text)
    {
        MemoryStream mem = new MemoryStream();
        RC2CryptoServiceProvider rc2 = new RC2CryptoServiceProvider();
        rc2.IV = _iv;
        //rc2.Key = System.Text.Encoding.ASCII.GetBytes(keysecret);
        rc2.Key = System.Text.Encoding.Unicode.GetBytes(keysecret);

        //Byte[] datatobyte = System.Text.Encoding.ASCII.GetBytes(text);
        Byte[] datatobyte = System.Text.Encoding.Unicode.GetBytes(text);

        CryptoStream myCryptoStream = new CryptoStream(mem, rc2.CreateEncryptor(), CryptoStreamMode.Write);
        myCryptoStream.Write(datatobyte, 0, datatobyte.Length);
        myCryptoStream.Close();

        return (Convert.ToBase64String(mem.ToArray()));
    }
    /// <summary>
    /// FOR DECODING
    /// </summary>
    /// <param name="text"></param>
    /// <returns></returns>
    public static string RsaSymenDecrypt(string text)
    {
        MemoryStream mem = new MemoryStream();
        RC2CryptoServiceProvider rc2 = new RC2CryptoServiceProvider();
        rc2.IV = _iv;
        //rc2.Key = System.Text.Encoding.ASCII.GetBytes(keysecret);
        rc2.Key = System.Text.Encoding.Unicode.GetBytes(keysecret);

        Byte[] DeCryptData = Convert.FromBase64String(text);

        CryptoStream myCryptoStream = new CryptoStream(mem, rc2.CreateDecryptor(), CryptoStreamMode.Write);
        myCryptoStream.Write(DeCryptData, 0, DeCryptData.Length);
        myCryptoStream.Close();
        text = Convert.ToBase64String(mem.ToArray());
        myCryptoStream.Close();

        //return (System.Text.Encoding.ASCII.GetString(mem.ToArray()));
        return (System.Text.Encoding.Unicode.GetString(mem.ToArray()));
    }
}

