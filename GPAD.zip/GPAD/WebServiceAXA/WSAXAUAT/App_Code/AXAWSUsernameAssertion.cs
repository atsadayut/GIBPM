﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Security.Cryptography;
using System.Globalization;
using TA.BLL;
using TA.BusinessObjects;
using TA.DAL;
using System.Data;
using System.Data.Common;

/// <summary>
/// Summary description for AXAWSUsernameAssertion
/// </summary>
public class AXAWSUsernameAssertion
{
	public AXAWSUsernameAssertion()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public static bool CheckAXAWSUsernameAssertion(string agentCode, string groupBrokerId, string password, out string msg)
    {
        string retMsg = string.Empty;
        bool retValue = false;
        try
        {
            TATBAgentCodeBLL clsTATBAgentCode = new TATBAgentCodeBLL();
            TATBAgentCode getdata = new TATBAgentCode();
            getdata = clsTATBAgentCode.spTAB2C_GetAgentCode(groupBrokerId, agentCode);

            if (!string.IsNullOrEmpty(groupBrokerId) && !string.IsNullOrEmpty(agentCode))
            {                
                string dbPassword = getdata.Password.Trim();

                if (string.Compare(password.Trim(), dbPassword) == 0)
                {
                    retValue = true;
                    retMsg = "SUCCESS";
                }
                else
                {
                    retValue = false;
                    retMsg = "Error password mismatch!!!";
                }
            }
            else
            {
                retValue = false;
                retMsg = "Error get agent data or agent data is empty!!!";
            }                                    
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        msg = retMsg;
        return retValue;
    }

    public static bool CheckAXAWSUsernameAssertion(string agentCode, string groupBrokerId, string password)
    {
        //string retMsg = string.Empty;
        bool retValue = false;
        try
        {
            TATBAgentCodeBLL clsTATBAgentCode = new TATBAgentCodeBLL();
            TATBAgentCode getdata = new TATBAgentCode();
            getdata = clsTATBAgentCode.spTAB2C_GetAgentCode(groupBrokerId, agentCode);

            if (!string.IsNullOrEmpty(groupBrokerId) && !string.IsNullOrEmpty(agentCode))
            {
                string dbPassword = getdata.Password.Trim();

                if (string.Compare(password.Trim(), dbPassword) == 0)
                {
                    retValue = true;
                    //retMsg = "SUCCESS";
                }
                else
                {
                    retValue = false;
                    //retMsg = "Error password mismatch!!!";
                }
            }
            else
            {
                retValue = false;
                //retMsg = "Error get agent data or agent data is empty!!!";
            }
        }
        catch (Exception ex)
        {
            //retMsg = ex.Message.ToString();
            retValue = false;
        }

        //msg = retMsg;
        return retValue;
    }
}