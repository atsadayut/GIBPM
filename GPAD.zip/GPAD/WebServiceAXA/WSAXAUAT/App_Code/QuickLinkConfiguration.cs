using System;
using System.Configuration;

/// <summary>
/// Repository for QuickLinkC configuration settings
/// </summary>
public static class QuickLinkConfiguration
{
    private readonly static string siteName;
    private readonly static string dbConnectionString;
    private readonly static string dbProviderName;

    private readonly static string dbKYCConnectionString;
    private readonly static string dbKYCProviderName;

    private readonly static string mailServer;
    private readonly static bool enableErrorLogEmail;
    private readonly static string errorLogEmail;
    private readonly static string credentialUser;
    private readonly static string credentialPassword;
    private readonly static string brokerTisco;

    //�������������
    private readonly static string dbReportConnectionString;
    private readonly static string dbReportProviderName;

    private readonly static int backDatePolicy;  //Back date Inception
    private readonly static int limitDateForRenew; //Limit Num Day for Renew
    private readonly static int limitChassisExpiry;//Limit Num Day for Enquiry

    private readonly static string urlReportingService;//Limit Num Day for Report address
    private readonly static string urlReportingServiceNew;//Limit Num Day for Report address
    private readonly static string urlReportingServiceTQM;//Limit Num Day for Report address

    private readonly static int limitPrintTimeOut;//Limit Num Day for Timeout print num

    private readonly static int limitBeforeUserPasswordExpiry;//Limit Before User Password Expire date

    private readonly static int limitUserPasswordExpiry;//Limit User Password Expire date

    private readonly static int limitClass5DefaultOD_Deduct;//Limit User Password Expire date
    
    private readonly static string urlFileUpload;

    private readonly static string urlFileDownload;

    private readonly static string openSystem;

    private readonly static string qttClientCodeC;
    private readonly static string qttClientCodeP;
    private readonly static string qttDriver18;
    private readonly static string qttDriver25;
    private readonly static string qttDriver36;
    private readonly static string qttDriver51;
    private readonly static int defaultStandardSumInsured;
    private readonly static string approvalEmail;

    // Initialize various properties in the constructor
    static QuickLinkConfiguration()
    {
        siteName = ConfigurationManager.AppSettings["SiteName"];
        dbConnectionString = ConfigurationManager.ConnectionStrings["LocalSqlServerAXA"].ConnectionString;
        dbProviderName = ConfigurationManager.ConnectionStrings["LocalSqlServerAXA"].ProviderName;
        mailServer = ConfigurationManager.AppSettings["mailServer"];
        enableErrorLogEmail = bool.Parse(ConfigurationManager.AppSettings["enableErrorLogEmail"]);
        errorLogEmail = ConfigurationManager.AppSettings["errorLogEmail"];
        credentialUser = ConfigurationManager.AppSettings["credentialUser"];
        credentialPassword = ConfigurationManager.AppSettings["credentialPassword"];
        brokerTisco = ConfigurationManager.AppSettings["BrokerTisco"];
        //productDescriptionLength = Int32.Parse(ConfigurationManager.AppSettings["ProductDescriptionLength"]);
        //dbKYCConnectionString = ConfigurationManager.ConnectionStrings["KYCDBConnectionString"].ConnectionString;
        //dbKYCProviderName = ConfigurationManager.ConnectionStrings["KYCDBConnectionString"].ProviderName;


        //��ǹ���������
        dbReportConnectionString = ConfigurationManager.ConnectionStrings["QuickLinkReportConnectionString"].ConnectionString;
        dbReportProviderName = ConfigurationManager.ConnectionStrings["QuickLinkReportConnectionString"].ProviderName;

        //Back date for policy create
        backDatePolicy = Int32.Parse(ConfigurationManager.AppSettings["BackDatePolicy"]);

        //LimitDateForRenew
        limitDateForRenew = Int32.Parse(ConfigurationManager.AppSettings["LimitDateForRenew"]);

        //LimitChassisExpiry
        limitChassisExpiry = Int32.Parse(ConfigurationManager.AppSettings["LimitChassisExpiry"]);

        //UrlReportingService
        urlReportingService = ConfigurationManager.AppSettings["UrlReportingService"];
        urlReportingServiceNew = ConfigurationManager.AppSettings["UrlReportingServiceNew"];
        urlReportingServiceTQM = ConfigurationManager.AppSettings["UrlReportingServiceTQM"];

        //LimitPrintTimeOut
        limitPrintTimeOut = Int32.Parse(ConfigurationManager.AppSettings["LimitPrintTimeOut"]);

        //LimitBeforeUserPasswordExpiry
        limitBeforeUserPasswordExpiry = Int32.Parse(ConfigurationManager.AppSettings["LimitBeforeUserPasswordExpiry"]);

        //LimitUserPasswordExpiry
        limitUserPasswordExpiry = Int32.Parse(ConfigurationManager.AppSettings["LimitUserPasswordExpiry"]);

        //LimitClass5DefaultOD_Deduct
        limitClass5DefaultOD_Deduct = Int32.Parse(ConfigurationManager.AppSettings["LimitClass5DefaultOD_Deduct"]);

	 //UrlFileUpload
        urlFileUpload = ConfigurationManager.AppSettings["UrlFileUpload"];

        //UrlFileDownload
        urlFileDownload = ConfigurationManager.AppSettings["UrlFileDownload"];
	
	//OpenSystem
        openSystem = ConfigurationManager.AppSettings["OpenSystem"];

        //Quotation 
        qttClientCodeC = ConfigurationManager.AppSettings["QttClientCodeC"];
        qttClientCodeP = ConfigurationManager.AppSettings["QttClientCodeP"];
        qttDriver18 = ConfigurationManager.AppSettings["QttDriver18"];
        qttDriver25 = ConfigurationManager.AppSettings["QttDriver25"];
        qttDriver36 = ConfigurationManager.AppSettings["QttDriver36"];
        qttDriver51 = ConfigurationManager.AppSettings["QttDriver51"];

        //QuickLinkStandFlag
        defaultStandardSumInsured = Int32.Parse(ConfigurationManager.AppSettings["DefaultStandardSumInsured"]);

        //ApprovalEmail
       approvalEmail = ConfigurationManager.AppSettings["ApprovalEmail"];

    }

    public static string SiteName
    {
        get
        {
            return siteName;
        }
    }

    // Returns the email address for customers to contact the site


    // Return connection string name
    public static string DbConnectionString
    {
        get
        {
            return dbConnectionString;
        }
    }
    public static string DbKYCConnectionString
    {
        get
        {
            return dbKYCConnectionString;
        }
    }
    // Returns the data provider name
    public static string DbProviderName
    {
        get
        {
            return dbProviderName;
        }
    }
    public static string DbKYCProviderName
    {
        get
        {
            return dbKYCProviderName;
        }
    }
    // Returns the address of the mail server
    public static string MailServer
    {
        get
        {
            return mailServer;
        }
    }

    // Send error log emails?
    public static bool EnableErrorLogEmail
    {
        get
        {
            return enableErrorLogEmail;
        }
    }

    // Returns the email address where to send error reports
    public static string ErrorLogEmail
    {
        get
        {
            return errorLogEmail;
        }
    }

    // Returns CredentialUser for sent mails
    public static string CredentialUser
    {
        get
        {
            return credentialUser;
        }
    }

    // Returns CredentialPassword for sent mails
    public static string CredentialPassword
    {
        get
        {
            return credentialPassword;
        }
    }
    //
    public static string BrokerTisco
    {
        get
        {
            return brokerTisco;
        }
    }
    //��ǹ���������
    public static string ReportConnectionString
    {
        get
        {
            return dbReportConnectionString;
        }
    }

    // Returns the data provider name
    public static string ReportProviderName
    {
        get
        {
            return dbReportProviderName;
        }
    }
    // Returns the data using for back date policy 
    public static int BackDatePolicy
    {
        get
        {
            return backDatePolicy;
        }
    }
    // Returns the data using for  date policy for renew 
    public static int LimitDateForRenew
    {
        get
        {
            return limitDateForRenew;
        }
    }
    // Returns the data using for back date policy for limit chassis expiry 
    public static int LimitChassisExpiry
    {
        get
        {
            return limitChassisExpiry;
        }
    }
    // Returns the data using for URL Reporting Service
    public static string UrlReportingService
    {
        get
        {
            return urlReportingService;
        }
    }

    public static string UrlReportingServiceNew
    {
        get
        {
            return urlReportingServiceNew;
        }
    }

    public static string UrlReportingServiceTQM
    {
        get
        {
            return urlReportingServiceTQM;
        }
    }
    public static int LimitPrintTimeOut
    {
        get
        {
            return limitPrintTimeOut;
        }
    }

     public static int LimitBeforeUserPasswordExpiry
    {
        get
        {
            return limitBeforeUserPasswordExpiry;
        }
    }

    public static int LimitUserPasswordExpiry
    {
        get
        {
            return limitUserPasswordExpiry;
        }
    }

    //LimitClass5DefaultOD_Deduct
    public static int LimitClass5DefaultOD_Deduct
    {
        get
        {
            return limitClass5DefaultOD_Deduct;
        }
    }

    public static string UrlFileUpload
    {
        get
        {
            return urlFileUpload;
        }
    }

    public static string UrlFileDownload
    {
        get
        {
            return urlFileDownload;
        }
    }

     public static string OpenSystem
    {
        get
        {
            return openSystem;
        }
    }

    public static string QttClientCodeC
    {
        get
        {
            return  qttClientCodeC;
        }
    }

    public static string QttClientCodeP
    {
        get
        {
            return qttClientCodeP;
        }
    }
    public static string QttDriver18
    {
        get
        {
            return qttDriver18;
        }
    }
    public static string QttDriver25
    {
        get
        {
            return qttDriver25;
        }
    }
    public static string QttDriver36
    {
        get
        {
            return qttDriver36;
        }
    }
    public static string QttDriver51
    {
        get
        {
            return qttDriver51;
        }
    }

    public static int DefaultStandardSumInsured
    {
        get 
        {
            return defaultStandardSumInsured;
        }
    }

    public static string ApprovalEmail
    {
        get
        {
            return approvalEmail;
        }
    }


}
