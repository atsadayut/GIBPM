﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

using PA.BLL;
using PA.BusinessObjects;
using PA.DAL;
using System.Data;
using System.Data.Common;
using System.IO;
using System.Globalization;
using System.Collections;
using System.Net;
using System.Web.Services.Protocols;

/// <summary>
/// Summary description for INF_AXAPAWS
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class INF_AXAPAWS : System.Web.Services.WebService
{
    const string PrefixPA = "Q";

    public INF_AXAPAWS()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    public class ObjAXAPAPlanPackage
    {
        public string _msg { get; set; }
        public string _packageID { get; set; }
        public string _packageName { get; set; }
        public string _packageShortName { get; set; }
        public int _ageBegin { get; set; }
        public int _ageEnd { get; set; }
        public int _ageChildrenBegin { get; set; }
        public int _ageChildrenEnd { get; set; }
    }

    public class ObjAXAPAListPlanPackage
    {
        public string _msg { get; set; }
        public List<ObjAXAPAPlanPackage> _listPAPlanPackage { get; set; }
    }

    public class ObjAXAPAOccupation
    {
        public int _occupationID { get; set; }
        public string _occupationClass { get; set; }
        public string _description { get; set; }

    }

    public class ObjAXAPAListOccupation
    {
        public string _msg { get; set; }
        public List<ObjAXAPAOccupation> _listPAOccupation { get; set; }
    }

    public class ObjAXAPAPlanInsure
    {
        public string _planCode { get; set; }
        public string _planName { get; set; }
    }

    public class ObjAXAPAListPlanInsure
    {
        public string _msg { get; set; }
        public List<ObjAXAPAPlanInsure> _listPAPlanInsure { get; set; }
    }

    public class ObjAXAPAPlanCoverage
    {
        public string _coverageNameTH { get; set; }
        public string _coverageNameEN { get; set; }
        public string _coverageAmount { get; set; }
        public double _PANetPremium { get; set; }
        public double _PATotalPremium { get; set; }
    }

    public class ObjAXAPAListPlanCoverage
    {
        public string _msg { get; set; }
        public List<ObjAXAPAPlanCoverage> _listPAPlanCoverage { get; set; }
    }

    public class ObjAXAPAPolicyHolderDetail
    {
        public string _clientType { get; set; }
        public string _clientTitle { get; set; }
        public string _clientName { get; set; }
        public string _clientSurName { get; set; }
        public string _birthday { get; set; }
        public string _idCard { get; set; }
        public string _branchNo { get; set; }
        public string _gender { get; set; }
        public string _maritalStatus { get; set; }
        public string _nationlity { get; set; }

        public string _addressNo { get; set; }
        public string _building { get; set; }
        public string _soi { get; set; }
        public string _road { get; set; }
        public string _province { get; set; }
        public string _amphur { get; set; }
        public string _tumbol { get; set; }
        public string _provinceID { get; set; }
        public string _amphurID { get; set; }
        public string _tumbolID { get; set; }
        public string _postCode { get; set; }
        public string _email { get; set; }
        public string _tel { get; set; }

        public bool _flagAddCoverage { get; set; }
    }

    public class ObjAXAPAAdultDetail
    {
        public string _clientTitle { get; set; }
        public string _clientName { get; set; }
        public string _clientSurName { get; set; }
        public string _birthday { get; set; }
        public string _idCard { get; set; }
        public List<ObjAXAPABeneficialy> _beneficiary { get; set; }
    }

    public class ObjAXAPAChildDetail
    {
        public string _clientTitle { get; set; }
        public string _clientName { get; set; }
        public string _clientSurName { get; set; }
        public string _birthday { get; set; }
        public string _idCard { get; set; }
        public bool _isStudent { get; set; }
        public bool _isSingle { get; set; }
        public List<ObjAXAPABeneficialy> _beneficiary { get; set; }
    }

    public class ObjAXAPABeneficialy
    {
        public string _clientTitle { get; set; }
        public string _clientName { get; set; }
        public string _clientSurName { get; set; }
        public string _relationShip { get; set; }
        public string _ratio { get; set; }
        public string _tel { get; set; }
    }

    public class ObjAXAPAPlanPremium
    {
        public string _msg { get; set; }
        public int _sumInsuredPA2 { get; set; }
        public int _sumInsuredME { get; set; }
        public int _premiumPA2 { get; set; }
        public int _premiumME { get; set; }
        public double _netPremium { get; set; }
        public int _tax { get; set; }
        public int _stamp { get; set; }
        public double _totalPremium { get; set; }
    }

    public class ObjAXAPAPremiumPayment
    {
        public string _msg { get; set; }
        public double _netPremium { get; set; }
        public int _tax { get; set; }
        public int _stamp { get; set; }
        public double _totalPremium { get; set; }
    }

    public class ObjAXAPAPolicyIssued
    {
        public string _msg { get; set; }
        public string _deliverDocMsg { get; set; }
        public string _policyNo { get; set; }
    }

    public class ObjAXAResendPolicy
    {
        public string jobNo { get; set; }
        public string policyNo { get; set; }
        public string policyType { get; set; }
        public string planId { get; set; }
    }

    public class ObjAXAPAListPlanPackageCoverage
    {
        public string _msg { get; set; }
        public List<ObjAXAPAPlanPackageCoverage> _listPAPlanPackage { get; set; }
    }

    public class ObjAXAPAPlanPackageCoverage
    {
        public string _msg { get; set; }
        public string _packageID { get; set; }
        public string _packageName { get; set; }
        public string _packageShortName { get; set; }
        public int _ageBegin { get; set; }
        public int _ageEnd { get; set; }
        public int _ageChildrenBegin { get; set; }
        public int _ageChildrenEnd { get; set; }
        public List<ObjAXAPAPlanPackageCoverageData> _listPlanPackageCoverageData { get; set; }
    }

    public class ObjAXAPAPlanPackageCoverageData
    {
        public string _coverageName { get; set; }
        public ObjAXAPAPlanPackageCoverageDataType _type { get; set; }
        public List<ObjAXAPAPlanPackageCoverageDataDetail> _coverageDetail { get; set; }
    }

    public class ObjAXAPAPlanPackageCoverageDataDetail
    {
        public string _id { get; set; }
        public string _code { get; set; }
        public string _name { get; set; }
    }

    public enum ObjAXAPAPlanPackageCoverageDataType { planCode = 1, coverageTitle = 2, coverage = 3, totalPremium = 4 }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="language"></param>
    /// <param name="packageID"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAPAPlanPackage GetAXAPAPlanPackageByPackageID(string agentCode, string groupBrokerId, string password, string language, string packageID)
    {
        string retMsg = string.Empty;
        language = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();

        ObjAXAPAPlanPackage objPAPlanPackage = new ObjAXAPAPlanPackage();

        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            #endregion

            #region ###Validate Corect Data into Web Service
            if (string.IsNullOrEmpty(packageID))
            {
                isValidateOK = false;
                retMsg += " | Package ID null!!!";
            }
            #endregion

            if (isValidateOK == true)
            {
                PAGetDDLTableBLL clsPAGetDDLTableBLL = new PAGetDDLTableBLL();
                DataTable dt = clsPAGetDDLTableBLL.GetDDLPackageByPackageID(packageID, language);

                if (dt.Rows.Count > 0)
                {
                    string _packageID = dt.Rows[0]["PackageID"].ToString();
                    string _packageName = dt.Rows[0]["PackageName"].ToString();
                    string _packageShortName = dt.Rows[0]["PackageShortName"].ToString();
                    int _ageBegin = int.Parse(dt.Rows[0]["AgeOfInsurerFrom"].ToString());
                    int _ageEnd = int.Parse(dt.Rows[0]["AgeOfInsurerTo"].ToString());
                    int _ageChildrenBegin = int.Parse(dt.Rows[0]["AgeOfChildrenFrom"].ToString());
                    int _ageChildrenEnd = int.Parse(dt.Rows[0]["AgeOfChildrenTo"].ToString());

                    objPAPlanPackage._packageID = _packageID;
                    objPAPlanPackage._packageName = _packageName;
                    objPAPlanPackage._packageShortName = _packageShortName;
                    objPAPlanPackage._ageBegin = _ageBegin;
                    objPAPlanPackage._ageEnd = _ageEnd;
                    objPAPlanPackage._ageChildrenBegin = _ageChildrenBegin;
                    objPAPlanPackage._ageChildrenEnd = _ageChildrenEnd;

                    retMsg = "SUCCESS";
                }
                else
                {
                    retMsg = "EMPTY DATA";
                }
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        //msg = retMsg;
        //return lstAXAPAPlanPackage.Cast<ObjAXAPAPlanPackage>().ToList();
        objPAPlanPackage._msg = retMsg;

        return objPAPlanPackage;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="language"></param>
    /// <param name="birthdate_of_first_insured"></param>
    /// <param name="occupationID"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAPAListPlanPackageCoverage GetAXAPAPlanPackageCoverage(string agentCode, string groupBrokerId, string password, string language, string birthdate_of_first_insured, int occupationID)
    {
        string retMsg = string.Empty;
        language = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();

        ObjAXAPAListPlanPackageCoverage objListPAPlanPackageCoverage = new ObjAXAPAListPlanPackageCoverage();
        List<ObjAXAPAPlanPackageCoverage> lstAXAPAPlanPackageCoverage = new List<ObjAXAPAPlanPackageCoverage>();

        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            #endregion

            #region ###Validate Corect Data into Web Service
            if (string.IsNullOrEmpty(birthdate_of_first_insured))
            {
                isValidateOK = false;
                retMsg += " | Birth Date of 1st insured Must be complete!!!";
            }
            else
            {
                string[] arrDate = birthdate_of_first_insured.Split('/');

                if (Int32.Parse(arrDate[2].Substring(0, 4)) > 2500)
                {
                    isValidateOK = false;
                    retMsg += " | Birth Date(year) of 1st insured Value Must be A.D.!!!";
                }
            }
            #endregion

            if (isValidateOK == true)
            {
                retMsg = "SUCCESS";
                ObjAXAPAListPlanPackage _listPlanPackage = GetAXAPAPlanPackage(agentCode, groupBrokerId, password, language, birthdate_of_first_insured);
                if (String.Equals(_listPlanPackage._msg, "SUCCESS"))
                {
                    foreach (ObjAXAPAPlanPackage itemPlanPackage in _listPlanPackage._listPAPlanPackage)
                    {
                        ObjAXAPAPlanPackageCoverage planPackageCoverage = new ObjAXAPAPlanPackageCoverage();
                        planPackageCoverage._packageID = itemPlanPackage._packageID;
                        planPackageCoverage._packageName = itemPlanPackage._packageName;
                        planPackageCoverage._packageShortName = itemPlanPackage._packageShortName;
                        planPackageCoverage._ageBegin = itemPlanPackage._ageBegin;
                        planPackageCoverage._ageEnd = itemPlanPackage._ageEnd;
                        planPackageCoverage._ageChildrenBegin = itemPlanPackage._ageChildrenBegin;
                        planPackageCoverage._ageChildrenEnd = itemPlanPackage._ageChildrenEnd;
                        planPackageCoverage._listPlanPackageCoverageData = new List<ObjAXAPAPlanPackageCoverageData>();

                        ObjAXAPAListPlanInsure _listPlanInsure = GetAXAPAPlanInsure(agentCode, groupBrokerId, password, language, itemPlanPackage._packageID, occupationID);
                        if (String.Equals(_listPlanInsure._msg, "SUCCESS"))
                        {
                            foreach (ObjAXAPAPlanInsure itemPlanInsure in _listPlanInsure._listPAPlanInsure)
                            {
                                string planCoverageDetailId = String.Format("{0}|{1}", itemPlanPackage._packageID, itemPlanInsure._planCode);

                                ObjAXAPAListPlanCoverage _listPlanCoverage = GetAXAPAPlanCoverage(agentCode, groupBrokerId, password, language, itemPlanInsure._planCode, occupationID);
                                if (String.Equals(_listPlanCoverage._msg, "SUCCESS"))
                                {
                                    if (planPackageCoverage._listPlanPackageCoverageData != null)
                                    {
                                        if (planPackageCoverage._listPlanPackageCoverageData.Count > 0)
                                        {
                                            planPackageCoverage._listPlanPackageCoverageData[0]._coverageDetail.Add(new ObjAXAPAPlanPackageCoverageDataDetail() { _id = planCoverageDetailId, _code = itemPlanInsure._planCode, _name = itemPlanInsure._planName });
                                        }
                                        else
                                        {
                                            ObjAXAPAPlanPackageCoverageData planPackageCoverageData = new ObjAXAPAPlanPackageCoverageData();
                                            planPackageCoverageData._coverageName = itemPlanPackage._packageShortName;
                                            planPackageCoverageData._type = ObjAXAPAPlanPackageCoverageDataType.planCode;
                                            planPackageCoverageData._coverageDetail = new List<ObjAXAPAPlanPackageCoverageDataDetail>();
                                            planPackageCoverageData._coverageDetail.Add(new ObjAXAPAPlanPackageCoverageDataDetail() { _id = planCoverageDetailId, _code = itemPlanInsure._planCode, _name = itemPlanInsure._planName });
                                            planPackageCoverage._listPlanPackageCoverageData.Add(planPackageCoverageData);
                                        }
                                    }
                                    else
                                    {
                                        ObjAXAPAPlanPackageCoverageData planPackageCoverageData = new ObjAXAPAPlanPackageCoverageData();
                                        planPackageCoverageData._coverageName = itemPlanPackage._packageShortName;
                                        planPackageCoverageData._type = ObjAXAPAPlanPackageCoverageDataType.planCode;
                                        planPackageCoverageData._coverageDetail = new List<ObjAXAPAPlanPackageCoverageDataDetail>();
                                        planPackageCoverageData._coverageDetail.Add(new ObjAXAPAPlanPackageCoverageDataDetail() { _id = planCoverageDetailId, _code = itemPlanInsure._planCode, _name = itemPlanInsure._planName });
                                        planPackageCoverage._listPlanPackageCoverageData.Add(planPackageCoverageData);
                                    }

                                    foreach (ObjAXAPAPlanCoverage itemPlanCoverage in _listPlanCoverage._listPAPlanCoverage)
                                    {
                                        int outCoverageAmount;
                                        string CoverageName = (language == "E") ? itemPlanCoverage._coverageNameEN : itemPlanCoverage._coverageNameTH;
                                        string CoverageAmount = itemPlanCoverage._coverageAmount;
                                        int indexCoverage = planPackageCoverage._listPlanPackageCoverageData.FindIndex(s => s._coverageName == CoverageName);
                                        if (indexCoverage != -1)
                                        {
                                            planPackageCoverage._listPlanPackageCoverageData[indexCoverage]._coverageDetail.Add(new ObjAXAPAPlanPackageCoverageDataDetail() { _id = planCoverageDetailId, _name = CoverageAmount });
                                        }
                                        else
                                        {
                                            ObjAXAPAPlanPackageCoverageData planPackageCoverageData = new ObjAXAPAPlanPackageCoverageData();
                                            planPackageCoverageData._coverageName = CoverageName;
                                            planPackageCoverageData._type = (new string[] { "ข้อตกลงคุ้มครอง (บาท)", "การขยายความคุ้มครอง/จำกัดวงเงินความรับผิด (บาท)", "Insuring agreement (Baht)", "Extended/ Limited Cover (Baht)" }.Contains(CoverageName)) ? ObjAXAPAPlanPackageCoverageDataType.coverageTitle : ObjAXAPAPlanPackageCoverageDataType.coverage;
                                            planPackageCoverageData._coverageDetail = new List<ObjAXAPAPlanPackageCoverageDataDetail>();
                                            planPackageCoverageData._coverageDetail.Add(new ObjAXAPAPlanPackageCoverageDataDetail() { _id = planCoverageDetailId, _name = CoverageAmount });
                                            planPackageCoverage._listPlanPackageCoverageData.Add(planPackageCoverageData);
                                        }
                                    }

                                    ObjAXAPAPlanPremium _planPremium = GetAXAPAPlanPremium(agentCode, groupBrokerId, password, language, itemPlanInsure._planCode, occupationID);
                                    if (String.Equals(_planPremium._msg, "SUCCESS"))
                                    {
                                        int indexPremium = planPackageCoverage._listPlanPackageCoverageData.FindIndex(s => s._coverageName == ((language == "E") ? "Premium" : "เบี้ยประกันภัย"));
                                        if (indexPremium != -1)
                                        {
                                            planPackageCoverage._listPlanPackageCoverageData[indexPremium]._coverageDetail.Add(new ObjAXAPAPlanPackageCoverageDataDetail() { _id = planCoverageDetailId, _name = _planPremium._totalPremium.ToString() });
                                        }
                                        else
                                        {
                                            ObjAXAPAPlanPackageCoverageData planPackageCoverageData = new ObjAXAPAPlanPackageCoverageData();
                                            planPackageCoverageData._coverageName = (language == "E") ? "Premium" : "เบี้ยประกันภัย";
                                            planPackageCoverageData._type = ObjAXAPAPlanPackageCoverageDataType.totalPremium;
                                            planPackageCoverageData._coverageDetail = new List<ObjAXAPAPlanPackageCoverageDataDetail>();
                                            planPackageCoverageData._coverageDetail.Add(new ObjAXAPAPlanPackageCoverageDataDetail() { _id = planCoverageDetailId, _name = _planPremium._totalPremium.ToString() });
                                            planPackageCoverage._listPlanPackageCoverageData.Add(planPackageCoverageData);
                                        }
                                    }
                                    else
                                    {
                                        retMsg = _planPremium._msg;
                                    }

                                    if (planPackageCoverage._listPlanPackageCoverageData != null)
                                    {
                                        int countCoverageDetail = planPackageCoverage._listPlanPackageCoverageData.Max(s => s._coverageDetail.Count);
                                        for (int c = 0; c < planPackageCoverage._listPlanPackageCoverageData.Count; c++)
                                        {
                                            if (planPackageCoverage._listPlanPackageCoverageData[c]._coverageDetail != null)
                                            {
                                                if (planPackageCoverage._listPlanPackageCoverageData[c]._coverageDetail.Count < countCoverageDetail)
                                                {
                                                    for (int cDetail = planPackageCoverage._listPlanPackageCoverageData[c]._coverageDetail.Count; cDetail < countCoverageDetail; cDetail++)
                                                    {
                                                        planPackageCoverage._listPlanPackageCoverageData[c]._coverageDetail.Add(new ObjAXAPAPlanPackageCoverageDataDetail() { _id = itemPlanPackage._packageID + itemPlanInsure._planCode, _name = String.Empty });
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    retMsg = _listPlanCoverage._msg;
                                }
                            }
                        }
                        else
                        {
                            retMsg = _listPlanInsure._msg;
                        }
                        lstAXAPAPlanPackageCoverage.Add(planPackageCoverage);
                    }
                }
                else
                {
                    retMsg = _listPlanPackage._msg;
                }
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        objListPAPlanPackageCoverage._msg = retMsg;
        objListPAPlanPackageCoverage._listPAPlanPackage = lstAXAPAPlanPackageCoverage.Cast<ObjAXAPAPlanPackageCoverage>().ToList();

        return objListPAPlanPackageCoverage;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="language"></param>
    /// <param name="birthdate_of_first_insured"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAPAListPlanPackage GetAXAPAPlanPackage(string agentCode, string groupBrokerId, string password, string language, string birthdate_of_first_insured)
    {
        string retMsg = string.Empty;
        language = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();

        ObjAXAPAListPlanPackage objListPAPlanPackage = new ObjAXAPAListPlanPackage();
        List<ObjAXAPAPlanPackage> lstAXAPAPlanPackage = new List<ObjAXAPAPlanPackage>();

        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            #endregion

            #region ###Validate Corect Data into Web Service
            if (string.IsNullOrEmpty(birthdate_of_first_insured))
            {
                isValidateOK = false;
                retMsg += " | Birth Date of 1st insured Must be complete!!!";
            }
            else
            {
                string[] arrDate = birthdate_of_first_insured.Split('/');

                if (Int32.Parse(arrDate[2].Substring(0, 4)) > 2500)
                {
                    isValidateOK = false;
                    retMsg += " | Birth Date(year) of 1st insured Value Must be A.D.!!!";
                }
            }
            #endregion

            if (isValidateOK == true)
            {
                //Calulate age
                int age = this.GetAge(birthdate_of_first_insured);
                //End

                PAGetDDLTableBLL clsPAGetDDLTableBLL = new PAGetDDLTableBLL();
                DataTable dt = clsPAGetDDLTableBLL.GetDDLPackage(age, language);

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ObjAXAPAPlanPackage item = new ObjAXAPAPlanPackage();
                    string packageID = dt.Rows[i]["PackageID"].ToString();
                    string packageName = dt.Rows[i]["PackageName"].ToString();
                    string packageShortName = dt.Rows[i]["PackageShortName"].ToString();
                    int ageBegin = int.Parse(dt.Rows[i]["AgeOfInsurerFrom"].ToString());
                    int ageEnd = int.Parse(dt.Rows[i]["AgeOfInsurerTo"].ToString());
                    int ageChildrenBegin = int.Parse(dt.Rows[i]["AgeOfChildrenFrom"].ToString());
                    int ageChildrenEnd = int.Parse(dt.Rows[i]["AgeOfChildrenTo"].ToString());

                    item._packageID = packageID;
                    item._packageName = packageName;
                    item._packageShortName = packageShortName;
                    item._ageBegin = ageBegin;
                    item._ageEnd = ageEnd;
                    item._ageChildrenBegin = ageChildrenBegin;
                    item._ageChildrenEnd = ageChildrenEnd;

                    lstAXAPAPlanPackage.Add(item);
                }

                retMsg = "SUCCESS";
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        //msg = retMsg;
        //return lstAXAPAPlanPackage.Cast<ObjAXAPAPlanPackage>().ToList();
        objListPAPlanPackage._msg = retMsg;
        objListPAPlanPackage._listPAPlanPackage = lstAXAPAPlanPackage.Cast<ObjAXAPAPlanPackage>().ToList();

        return objListPAPlanPackage;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="language"></param>
    /// <returns></returns>    
    [WebMethod]
    public ObjAXAPAListOccupation GetAXAPAOccupation(string agentCode, string groupBrokerId, string password, string language)
    {
        string retMsg = string.Empty;
        language = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();
        ObjAXAPAListOccupation objListOccupation = new ObjAXAPAListOccupation();
        List<ObjAXAPAOccupation> lstAXAPAOccupation = new List<ObjAXAPAOccupation>();
        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            #endregion

            if (isValidateOK == true)
            {
                PAGetDDLTableBLL clsPAGetDDLTableBLL = new PAGetDDLTableBLL();
                DataTable dt = clsPAGetDDLTableBLL.GetDDLPAOccupation(language);

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ObjAXAPAOccupation item = new ObjAXAPAOccupation();
                    int occupationID = Convert.ToInt32(dt.Rows[i]["OccupationID"].ToString());
                    string occupatnClass = dt.Rows[i]["OccupatnClass"].ToString();
                    string description = dt.Rows[i]["Description"].ToString();

                    item._occupationID = occupationID;
                    item._occupationClass = occupatnClass;
                    item._description = description;

                    lstAXAPAOccupation.Add(item);
                }

                retMsg = "SUCCESS";
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        //msg = retMsg;
        //return lstAXAPAOccupation.Cast<ObjAXAPAOccupation>().ToList();
        objListOccupation._msg = retMsg;
        objListOccupation._listPAOccupation = lstAXAPAOccupation.Cast<ObjAXAPAOccupation>().ToList();

        return objListOccupation;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="language"></param>
    /// <param name="packageID"></param>
    /// <param name="occupationID"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAPAListPlanInsure GetAXAPAPlanInsure(string agentCode, string groupBrokerId, string password, string language, string packageID, int occupationID)
    {
        string retMsg = string.Empty;
        language = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();

        ObjAXAPAListPlanInsure objPAListPlanInsure = new ObjAXAPAListPlanInsure();
        List<ObjAXAPAPlanInsure> lstAXAPAPlanInsure = new List<ObjAXAPAPlanInsure>();

        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            #endregion

            if (isValidateOK == true)
            {

                PAOccupationBLL clsPAOccupation = new PAOccupationBLL();
                PAOccupation clsOccupation = clsPAOccupation.GetPAOccupation(occupationID);
                string occupationClass = clsOccupation.OccupatnClass;


                PAGetDDLTableBLL clsPAGetDDLTableBLL = new PAGetDDLTableBLL();
                DataTable dt = clsPAGetDDLTableBLL.GetDDLPlan(packageID, language, occupationClass);

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ObjAXAPAPlanInsure item = new ObjAXAPAPlanInsure();
                    string planCode = dt.Rows[i]["PlanCode"].ToString();
                    string planName = dt.Rows[i]["PlanName"].ToString();

                    item._planCode = planCode;
                    item._planName = planName;

                    lstAXAPAPlanInsure.Add(item);
                }

                retMsg = "SUCCESS";
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        //msg = retMsg;
        //return lstAXAPAPlanInsure.Cast<ObjAXAPAPlanInsure>().ToList();
        objPAListPlanInsure._msg = retMsg;
        objPAListPlanInsure._listPAPlanInsure = lstAXAPAPlanInsure.Cast<ObjAXAPAPlanInsure>().ToList();

        return objPAListPlanInsure;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="language"></param>
    /// <param name="planCode"></param>
    /// <param name="occupationID"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAPAListPlanCoverage GetAXAPAPlanCoverage(string agentCode, string groupBrokerId, string password, string language, string planCode, int occupationID)
    {
        string retMsg = string.Empty;
        language = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();

        ObjAXAPAListPlanCoverage objPAListPlanCoverage = new ObjAXAPAListPlanCoverage();
        List<ObjAXAPAPlanCoverage> lstAXAPAPlanCoverage = new List<ObjAXAPAPlanCoverage>();

        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            #endregion

            if (isValidateOK == true)
            {
                PAOccupationBLL clsPAOccupation = new PAOccupationBLL();
                PAOccupation clsOccupation = clsPAOccupation.GetPAOccupation(occupationID);
                string occupationClass = clsOccupation.OccupatnClass;

                PAPlanCoveragesBLL clsPAGetPlanCoveragesBLL = new PAPlanCoveragesBLL();
                DataTable dt = clsPAGetPlanCoveragesBLL.GetDtPAPlanCoverages(planCode);

                PAPlanPremiumsBLL clsPAGetPlanPremium = new PAPlanPremiumsBLL();
                DataTable dt_premium = clsPAGetPlanPremium.GetDtPAPlanPremiums(planCode, occupationClass);

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ObjAXAPAPlanCoverage item = new ObjAXAPAPlanCoverage();
                    string coverageNameTH = dt.Rows[i]["CoverageNameTH"].ToString();
                    string coverageNameEN = dt.Rows[i]["CoverageNameEN"].ToString();
                    string coverageAmount = dt.Rows[i]["CoverageAmount"].ToString();
                    double netpremium = Convert.ToDouble(dt_premium.Rows[0]["GrossPremium"].ToString());
                    double totalpremium = Convert.ToDouble(dt_premium.Rows[0]["TotalPremium"].ToString());

                    item._coverageNameTH = coverageNameTH;
                    item._coverageNameEN = coverageNameEN;
                    item._coverageAmount = coverageAmount;
                    item._PANetPremium = netpremium;
                    item._PATotalPremium = totalpremium;

                    lstAXAPAPlanCoverage.Add(item);
                }

                retMsg = "SUCCESS";
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        //msg = retMsg;
        //return lstAXAPAPlanCoverage.Cast<ObjAXAPAPlanCoverage>().ToList();
        objPAListPlanCoverage._msg = retMsg;
        objPAListPlanCoverage._listPAPlanCoverage = lstAXAPAPlanCoverage.Cast<ObjAXAPAPlanCoverage>().ToList();

        return objPAListPlanCoverage;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="language"></param>
    /// <param name="planCode"></param>
    /// <param name="occupationID"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAPAPlanPremium GetAXAPAPlanPremium(string agentCode, string groupBrokerId, string password, string language, string planCode, int occupationID)
    {
        string retMsg = string.Empty;
        language = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();

        ObjAXAPAPlanPremium objPAListPlanCoverage = new ObjAXAPAPlanPremium();

        try
        {
            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            #endregion

            #region ###Validate Corect Data into Web Service
            if (string.IsNullOrEmpty(planCode))
            {
                isValidateOK = false;
                retMsg += " | Insurance Plan Code Must have value!!!";
            }
            //if (string.IsNullOrEmpty(occupationDesc))
            //{
            //    isValidateOK = false;
            //    retMsg += " | Occupation Must have value!!!";
            //}
            #endregion

            if (isValidateOK == true)
            {
                PAOccupationBLL clsPAOccupation = new PAOccupationBLL();
                PAOccupation clsOccupation = clsPAOccupation.GetPAOccupation(occupationID);
                string occupationClass = clsOccupation.OccupatnClass;

                //-------------------------------------------------------------------------------------------------------------
                //BEGIN VARIABLE-PLAN PREMIUM
                PAPlanPremiumsBLL clsPAPlanPremiumsBLL = new PAPlanPremiumsBLL();
                DataTable dt = clsPAPlanPremiumsBLL.GetDtPAPlanPremiums(planCode, occupationClass);
                if (dt.Rows.Count > 0)
                {
                    int _sumInsuredPA2 = int.Parse(dt.Rows[0]["SumInsuredPA2"].ToString());
                    int _sumInsuredME = int.Parse(dt.Rows[0]["SumInsuredME"].ToString());
                    int _premiumPA2 = int.Parse(dt.Rows[0]["PremiumPA2"].ToString());
                    int _premiumME = int.Parse(dt.Rows[0]["PremiumME"].ToString());
                    double _netPremium = double.Parse(dt.Rows[0]["GrossPremium"].ToString());
                    int _tax = int.Parse(dt.Rows[0]["SBT"].ToString());
                    int _stamp = int.Parse(dt.Rows[0]["Stamp"].ToString());
                    double _totalPremium = double.Parse(dt.Rows[0]["TotalPremium"].ToString());

                    objPAListPlanCoverage._sumInsuredPA2 = _sumInsuredPA2;
                    objPAListPlanCoverage._sumInsuredME = _sumInsuredME;
                    objPAListPlanCoverage._premiumPA2 = _premiumPA2;
                    objPAListPlanCoverage._premiumME = _premiumME;
                    objPAListPlanCoverage._netPremium = _netPremium;
                    objPAListPlanCoverage._tax = _tax;
                    objPAListPlanCoverage._stamp = _stamp;
                    objPAListPlanCoverage._totalPremium = _totalPremium;

                    retMsg = "SUCCESS";
                }
                else
                {
                    retMsg = "EMPTY DATA";
                }
            }
            else
            {
                retMsg = secMsg;
            }
        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        //msg = retMsg;
        //return lstAXAPAPlanCoverage.Cast<ObjAXAPAPlanCoverage>().ToList();
        objPAListPlanCoverage._msg = retMsg;

        return objPAListPlanCoverage;
    }

    ///// <summary>
    ///// 
    ///// </summary>
    ///// <param name="agentCode"></param>
    ///// <param name="groupBrokerId"></param>
    ///// <param name="password"></param>
    ///// <param name="language"></param>
    ///// <param name="packageID"></param>
    ///// <param name="planCode"></param>
    ///// <param name="occupationID"></param>
    ///// <param name="InceptionDate"></param>
    ///// <param name="lstInsuredChilds"></param>
    ///// <returns></returns>
    //[WebMethod]
    //public ObjAXAPAPremiumPayment GetAXAPAPremiumPayment(string agentCode, string groupBrokerId, string password, string language, string packageID, string planCode, int occupationID, string InceptionDate, List<ObjAXAPAChildDetail> lstInsuredChilds)
    //{
    //    string retMsg = string.Empty;
    //    double netPremium = 0;
    //    double totalPremium = 0;
    //    int tax = 0;
    //    int stamp = 0;

    //    language = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();

    //    try
    //    {

    //        #region ###Validate security & authorization into Web Service
    //        string secMsg = string.Empty;
    //        bool isValidateOK = false;
    //        isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
    //        //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
    //        #endregion

    //        #region ###Validate Corect Data into Web Service
    //        if (string.IsNullOrEmpty(InceptionDate))
    //        {
    //            isValidateOK = false;
    //            retMsg += " | Inception date Must be complete!!!";
    //        }
    //        else
    //        {
    //            string[] arrDate = InceptionDate.Split('/');

    //            if (Int32.Parse(arrDate[2].Substring(0, 4)) > 2500)
    //            {
    //                isValidateOK = false;
    //                retMsg += " | Inception date Value Must be A.D.!!!";
    //            }
    //        }
    //        if (string.IsNullOrEmpty(packageID))
    //        {
    //            isValidateOK = false;
    //            retMsg += " | PackageID Data Must have value!!!";
    //        }
    //        if (string.IsNullOrEmpty(planCode))
    //        {
    //            isValidateOK = false;
    //            retMsg += " | Insurance Plan Code Must have value!!!";
    //        }
    //        //if (string.IsNullOrEmpty(occupationDesc))
    //        //{
    //        //    isValidateOK = false;
    //        //    retMsg += " | Occupation Must have value!!!";
    //        //}
    //        if (lstInsuredChilds == null)
    //        {
    //            isValidateOK = false;
    //            retMsg += " | Childs detail data can not be null value!!!";
    //        }
    //        #endregion

    //        if (isValidateOK == true)
    //        {

    //            PAOccupationBLL clsPAOccupation = new PAOccupationBLL();
    //            PAOccupation clsOccupation = clsPAOccupation.GetPAOccupation(occupationID);
    //            string occupationClass = clsOccupation.OccupatnClass;

    //            //-------------------------------------------------------------------------------------------------------------
    //            //BEGIN VARIABLE-PLAN PREMIUM
    //            PAPlanPremiumsBLL clsPAPlanPremiumsBLL = new PAPlanPremiumsBLL();
    //            DataTable dt = clsPAPlanPremiumsBLL.GetDtPAPlanPremiums(planCode, occupationClass);
    //            double m_d_SumInsuredPA2 = double.Parse(dt.Rows[0]["SumInsuredPA2"].ToString().Trim());
    //            double m_d_SumInsuredME = double.Parse(dt.Rows[0]["SumInsuredME"].ToString().Trim());
    //            double m_d_PremiumPA2 = double.Parse(dt.Rows[0]["PremiumPA2"].ToString().Trim());
    //            double m_d_PremiumME = double.Parse(dt.Rows[0]["PremiumME"].ToString().Trim());
    //            double m_d_AddPremium = double.Parse(dt.Rows[0]["AddPremium"].ToString().Trim());
    //            double m_d_netpremium = double.Parse(dt.Rows[0]["GrossPremium"].ToString().Trim());
    //            double m_d_tax = double.Parse(dt.Rows[0]["SBT"].ToString().Trim());
    //            double m_d_stamp = double.Parse(dt.Rows[0]["Stamp"].ToString().Trim());
    //            double m_d_total = double.Parse(dt.Rows[0]["TotalPremium"].ToString().Trim());
    //            //END VARIABLE-PLAN PREMIUM

    //            //-------------------------------------------------------------------------------------------------------------

    //            #region "# CAL TOTAL PREMIUM"

    //            int m_sum_TotalPremiumPolicyInsure = 0;
    //            int m_sum_SBTPolicyInsure = 0;
    //            int m_sum_StampPolicyInsure = 0;
    //            int m_sum_GrossPremiumPolicyInsure = 0;


    //            if (packageID == "0004") // 0004 = Family
    //            {
    //                DateTime d_Insured_birthday = new DateTime();
    //                DateTime d_InceptionDate = new DateTime();
    //                bool ret = false;

    //                string[] arrInceptionDate = InceptionDate.Split('/');
    //                d_InceptionDate = Convert.ToDateTime(arrInceptionDate[2] + "-" + arrInceptionDate[1] + "-" + arrInceptionDate[0]); //DEFAULT EFFECTTIVE DATE FROM

    //                m_sum_GrossPremiumPolicyInsure += Convert.ToInt32(m_d_netpremium);
    //                m_sum_StampPolicyInsure += Convert.ToInt32(m_d_stamp);
    //                m_sum_SBTPolicyInsure += Convert.ToInt32(m_d_tax);
    //                m_sum_TotalPremiumPolicyInsure += Convert.ToInt32(m_d_total);

    //                //decimal m_suminsured_discount = 1.00M;
    //                decimal m_premium_discount = 1.00M;

    //                for (int c = 0; c < lstInsuredChilds.Count; c++)
    //                {
    //                    Nullable<int> m_GrossPremiumPolicyInsure = (int)m_d_netpremium;
    //                    Nullable<int> m_StampPolicyInsure = (int)m_d_stamp;
    //                    Nullable<int> m_SBTPolicyInsure = (int)m_d_tax;
    //                    Nullable<int> m_TotalPremiumPolicyInsure = (int)m_d_total;

    //                    //IF Child  17 years 
    //                    //then  discount 
    //                    string[] arrInsuredbirthday = lstInsuredChilds[c]._birthday.Split('/');

    //                    d_Insured_birthday = Convert.ToDateTime(arrInsuredbirthday[2] + "-" + arrInsuredbirthday[1] + "-" + arrInsuredbirthday[0]);
    //                    ret = this.IsBirthDayOverLimitOfEffectiveDate(1, 17, d_Insured_birthday, d_InceptionDate);
    //                    if (!ret)
    //                    {
    //                        //m_suminsured_discount = 0.50M;
    //                        m_premium_discount = 0.850M;
    //                    }
    //                    else
    //                    {

    //                        ret = this.IsBirthDayOverLimitOfEffectiveDate(18, 21, d_Insured_birthday, d_InceptionDate);
    //                        bool m_isStudent_and_isSingle = false;
    //                        if (lstInsuredChilds[c]._isStudent == true && lstInsuredChilds[c]._isSingle == true)
    //                        {
    //                            m_isStudent_and_isSingle = true; //on = true = selected
    //                        }
    //                        //IF Child between 18 years and  21 years ,be student and single
    //                        // then discount
    //                        if (!ret && m_isStudent_and_isSingle)
    //                        {
    //                            //m_suminsured_discount = 0.50M;
    //                            m_premium_discount = 0.850M;
    //                        }
    //                        else
    //                        {
    //                            //m_suminsured_discount = 1.00M;
    //                            m_premium_discount = 1.00M;
    //                        }
    //                    }
    //                    //2013-04-03 เพิ่มการเช็ค ทศนิยมตั้งแต่ 0.75 ให้ปัดขึ้น
    //                    double n = Math.Round((double)m_GrossPremiumPolicyInsure * Convert.ToDouble(m_premium_discount), 2);
    //                    string s = string.Format("{0:0.00}", n);

    //                    Int32 d = Int32.Parse(s.Substring(s.IndexOf(".") + 1));

    //                    if (d >= 75)
    //                    {
    //                        m_GrossPremiumPolicyInsure = Convert.ToInt32(Math.Floor((double)m_GrossPremiumPolicyInsure * Convert.ToDouble(m_premium_discount))) + 1;
    //                    }
    //                    else
    //                    {
    //                        m_GrossPremiumPolicyInsure = Convert.ToInt32(Math.Floor((double)m_GrossPremiumPolicyInsure * Convert.ToDouble(m_premium_discount)));
    //                    }

    //                    //m_GrossPremiumPolicyInsure = Convert.ToInt32(Math.Round((double)m_GrossPremiumPolicyInsure * Convert.ToDouble(m_premium_discount)));

    //                    m_StampPolicyInsure = Convert.ToInt32((Math.Ceiling((double)m_GrossPremiumPolicyInsure * 0.004)));
    //                    m_SBTPolicyInsure = 0;//Convert.ToInt32((Math.Ceiling((double)m_GrossPremiumPolicyInsure * 0.0275)));

    //                    //else not discount

    //                    m_TotalPremiumPolicyInsure = m_GrossPremiumPolicyInsure + m_StampPolicyInsure + m_SBTPolicyInsure;

    //                    //summary of all insured
    //                    m_sum_GrossPremiumPolicyInsure += Convert.ToInt32(m_GrossPremiumPolicyInsure);
    //                    m_sum_StampPolicyInsure += Convert.ToInt32(m_StampPolicyInsure);
    //                    m_sum_SBTPolicyInsure += Convert.ToInt32(m_SBTPolicyInsure);
    //                    m_sum_TotalPremiumPolicyInsure += Convert.ToInt32(m_TotalPremiumPolicyInsure);
    //                }
    //            }
    //            else
    //            {
    //                m_sum_GrossPremiumPolicyInsure = Convert.ToInt32(m_d_netpremium);
    //                m_sum_StampPolicyInsure = Convert.ToInt32(m_d_stamp);
    //                m_sum_SBTPolicyInsure = Convert.ToInt32(m_d_tax);
    //                m_sum_TotalPremiumPolicyInsure = Convert.ToInt32(m_d_total);
    //            }

    //            netPremium = m_sum_GrossPremiumPolicyInsure;
    //            tax = m_sum_SBTPolicyInsure;
    //            stamp = m_sum_StampPolicyInsure;
    //            totalPremium = m_sum_TotalPremiumPolicyInsure;

    //            #endregion

    //            retMsg = "SUCCESS";

    //        }
    //        else
    //        {
    //            retMsg = secMsg;
    //        }

    //    }
    //    catch (Exception ex)
    //    {
    //        retMsg = ex.Message.ToString();
    //    }

    //    //oNetPremium = netPremium;
    //    //oSbt = tax;
    //    //oStamp = stamp;
    //    //oTotalPremium = totalPremium;        

    //    //return retMsg;
    //    ObjAXAPAPremiumPayment objPremiumPayment = new ObjAXAPAPremiumPayment();
    //    objPremiumPayment._msg = retMsg;
    //    objPremiumPayment._netPremium = netPremium;
    //    objPremiumPayment._tax = tax;
    //    objPremiumPayment._stamp = stamp;
    //    objPremiumPayment._totalPremium = totalPremium;

    //    return objPremiumPayment;
    //}

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="language"></param>
    /// <param name="packageID"></param>
    /// <param name="planCode"></param>
    /// <param name="occupationID"></param>
    /// <param name="InceptionDate"></param>
    /// <param name="lstInsuredChilds"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAPAPremiumPayment GetAXAPAPremiumPayment(string agentCode, string groupBrokerId, string password, string language, string packageID, string planCode, int occupationID, string InceptionDate, List<ObjAXAPAAdultDetail> lstInsuredAdults, List<ObjAXAPAChildDetail> lstInsuredChilds)
    {
        string retMsg = string.Empty;
        double netPremium = 0;
        double totalPremium = 0;
        int tax = 0;
        int stamp = 0;

        language = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();

        try
        {

            #region ###Validate security & authorization into Web Service
            string secMsg = string.Empty;
            bool isValidateOK = false;
            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out secMsg);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            #endregion

            #region ###Validate Corect Data into Web Service
            if (string.IsNullOrEmpty(InceptionDate))
            {
                isValidateOK = false;
                retMsg += " | Inception date Must be complete!!!";
            }
            else
            {
                string[] arrDate = InceptionDate.Split('/');

                if (Int32.Parse(arrDate[2].Substring(0, 4)) > 2500)
                {
                    isValidateOK = false;
                    retMsg += " | Inception date Value Must be A.D.!!!";
                }
            }

            if (lstInsuredAdults == null || lstInsuredAdults[0] == null)
            {
                isValidateOK = false;
                retMsg += " | List of traveller adult can not be null value!!!";

            }

            if (string.IsNullOrEmpty(packageID))
            {
                isValidateOK = false;
                retMsg += " | PackageID Data Must have value!!!";
            }
            if (string.IsNullOrEmpty(planCode))
            {
                isValidateOK = false;
                retMsg += " | Insurance Plan Code Must have value!!!";
            }
            //if (string.IsNullOrEmpty(occupationDesc))
            //{
            //    isValidateOK = false;
            //    retMsg += " | Occupation Must have value!!!";
            //}
            if (lstInsuredChilds == null)
            {
                isValidateOK = false;
                retMsg += " | Childs detail data can not be null value!!!";
            }
            #endregion

            if (isValidateOK == true)
            {

                PAOccupationBLL clsPAOccupation = new PAOccupationBLL();
                PAOccupation clsOccupation = clsPAOccupation.GetPAOccupation(occupationID);
                string occupationClass = clsOccupation.OccupatnClass;

                //-------------------------------------------------------------------------------------------------------------
                //BEGIN VARIABLE-PLAN PREMIUM
                PAPlanPremiumsBLL clsPAPlanPremiumsBLL = new PAPlanPremiumsBLL();
                DataTable dt = clsPAPlanPremiumsBLL.GetDtPAPlanPremiums(planCode, occupationClass);
                double m_d_SumInsuredPA2 = double.Parse(dt.Rows[0]["SumInsuredPA2"].ToString().Trim());
                double m_d_SumInsuredME = double.Parse(dt.Rows[0]["SumInsuredME"].ToString().Trim());
                double m_d_PremiumPA2 = double.Parse(dt.Rows[0]["PremiumPA2"].ToString().Trim());
                double m_d_PremiumME = double.Parse(dt.Rows[0]["PremiumME"].ToString().Trim());
                double m_d_AddPremium = double.Parse(dt.Rows[0]["AddPremium"].ToString().Trim());
                double m_d_netpremium = double.Parse(dt.Rows[0]["GrossPremium"].ToString().Trim());
                double m_d_tax = double.Parse(dt.Rows[0]["SBT"].ToString().Trim());
                double m_d_stamp = double.Parse(dt.Rows[0]["Stamp"].ToString().Trim());
                double m_d_total = double.Parse(dt.Rows[0]["TotalPremium"].ToString().Trim());
                //END VARIABLE-PLAN PREMIUM

                //-------------------------------------------------------------------------------------------------------------

                #region "# CAL TOTAL PREMIUM"

                int m_sum_TotalPremiumPolicyInsure = 0;
                int m_sum_SBTPolicyInsure = 0;
                int m_sum_StampPolicyInsure = 0;
                int m_sum_GrossPremiumPolicyInsure = 0;

                foreach (ObjAXAPAAdultDetail item in lstInsuredAdults)
                {
                    m_sum_GrossPremiumPolicyInsure += Convert.ToInt32(m_d_netpremium);
                    m_sum_StampPolicyInsure += Convert.ToInt32(m_d_stamp);
                    m_sum_SBTPolicyInsure += Convert.ToInt32(m_d_tax);
                    m_sum_TotalPremiumPolicyInsure += Convert.ToInt32(m_d_total);
                }

                if (packageID == "0004") // 0004 = Family
                {
                    DateTime d_Insured_birthday = new DateTime();
                    DateTime d_InceptionDate = new DateTime();
                    bool ret = false;

                    string[] arrInceptionDate = InceptionDate.Split('/');
                    d_InceptionDate = Convert.ToDateTime(arrInceptionDate[2] + "-" + arrInceptionDate[1] + "-" + arrInceptionDate[0]); //DEFAULT EFFECTTIVE DATE FROM

                    //decimal m_suminsured_discount = 1.00M;
                    decimal m_premium_discount = 1.00M;

                    for (int c = 0; c < lstInsuredChilds.Count; c++)
                    {
                        Nullable<int> m_GrossPremiumPolicyInsure = (int)m_d_netpremium;
                        Nullable<int> m_StampPolicyInsure = (int)m_d_stamp;
                        Nullable<int> m_SBTPolicyInsure = (int)m_d_tax;
                        Nullable<int> m_TotalPremiumPolicyInsure = (int)m_d_total;

                        //IF Child  17 years 
                        //then  discount 
                        string[] arrInsuredbirthday = lstInsuredChilds[c]._birthday.Split('/');

                        d_Insured_birthday = Convert.ToDateTime(arrInsuredbirthday[2] + "-" + arrInsuredbirthday[1] + "-" + arrInsuredbirthday[0]);
                        ret = this.IsBirthDayOverLimitOfEffectiveDate(1, 17, d_Insured_birthday, d_InceptionDate);
                        if (!ret)
                        {
                            //m_suminsured_discount = 0.50M;
                            m_premium_discount = 0.850M;
                        }
                        else
                        {

                            ret = this.IsBirthDayOverLimitOfEffectiveDate(18, 21, d_Insured_birthday, d_InceptionDate);
                            bool m_isStudent_and_isSingle = false;
                            if (lstInsuredChilds[c]._isStudent == true && lstInsuredChilds[c]._isSingle == true)
                            {
                                m_isStudent_and_isSingle = true; //on = true = selected
                            }
                            //IF Child between 18 years and  21 years ,be student and single
                            // then discount
                            if (!ret && m_isStudent_and_isSingle)
                            {
                                //m_suminsured_discount = 0.50M;
                                m_premium_discount = 0.850M;
                            }
                            else
                            {
                                //m_suminsured_discount = 1.00M;
                                m_premium_discount = 1.00M;
                            }
                        }
                        //2013-04-03 เพิ่มการเช็ค ทศนิยมตั้งแต่ 0.75 ให้ปัดขึ้น
                        double n = Math.Round((double)m_GrossPremiumPolicyInsure * Convert.ToDouble(m_premium_discount), 2);
                        string s = string.Format("{0:0.00}", n);

                        Int32 d = Int32.Parse(s.Substring(s.IndexOf(".") + 1));

                        if (d >= 75)
                        {
                            m_GrossPremiumPolicyInsure = Convert.ToInt32(Math.Floor((double)m_GrossPremiumPolicyInsure * Convert.ToDouble(m_premium_discount))) + 1;
                        }
                        else
                        {
                            m_GrossPremiumPolicyInsure = Convert.ToInt32(Math.Floor((double)m_GrossPremiumPolicyInsure * Convert.ToDouble(m_premium_discount)));
                        }

                        //m_GrossPremiumPolicyInsure = Convert.ToInt32(Math.Round((double)m_GrossPremiumPolicyInsure * Convert.ToDouble(m_premium_discount)));

                        m_StampPolicyInsure = Convert.ToInt32((Math.Ceiling((double)m_GrossPremiumPolicyInsure * 0.004)));
                        m_SBTPolicyInsure = 0;//Convert.ToInt32((Math.Ceiling((double)m_GrossPremiumPolicyInsure * 0.0275)));

                        //else not discount

                        m_TotalPremiumPolicyInsure = m_GrossPremiumPolicyInsure + m_StampPolicyInsure + m_SBTPolicyInsure;

                        //summary of all insured
                        m_sum_GrossPremiumPolicyInsure += Convert.ToInt32(m_GrossPremiumPolicyInsure);
                        m_sum_StampPolicyInsure += Convert.ToInt32(m_StampPolicyInsure);
                        m_sum_SBTPolicyInsure += Convert.ToInt32(m_SBTPolicyInsure);
                        m_sum_TotalPremiumPolicyInsure += Convert.ToInt32(m_TotalPremiumPolicyInsure);
                    }
                }

                //netPremium = m_sum_GrossPremiumPolicyInsure;
                //tax = m_sum_SBTPolicyInsure;
                //stamp = m_sum_StampPolicyInsure;
                //totalPremium = m_sum_TotalPremiumPolicyInsure;

                netPremium = m_sum_GrossPremiumPolicyInsure;
                tax = 0;//Convert.ToInt32((Math.Ceiling((double)m_sum_GrossPremiumPolicyInsure * 0.0275)));
                stamp = Convert.ToInt32((Math.Ceiling((double)m_sum_GrossPremiumPolicyInsure * 0.004)));
                totalPremium = netPremium + stamp + tax;

                #endregion

                retMsg = "SUCCESS";

            }
            else
            {
                retMsg = secMsg;
            }

        }
        catch (Exception ex)
        {
            retMsg = ex.Message.ToString();
        }

        //oNetPremium = netPremium;
        //oSbt = tax;
        //oStamp = stamp;
        //oTotalPremium = totalPremium;        

        //return retMsg;
        ObjAXAPAPremiumPayment objPremiumPayment = new ObjAXAPAPremiumPayment();
        objPremiumPayment._msg = retMsg;
        objPremiumPayment._netPremium = netPremium;
        objPremiumPayment._tax = tax;
        objPremiumPayment._stamp = stamp;
        objPremiumPayment._totalPremium = totalPremium;

        return objPremiumPayment;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="language"></param>
    /// <param name="InceptionDate"></param>
    /// <param name="ExpiryDate"></param>
    /// <param name="birthdate_of_first_insured"></param>
    /// <param name="packageID"></param>
    /// <param name="occupationID"></param>
    /// <param name="planCode"></param>
    /// <param name="policyHolderDetail"></param>
    /// <param name="lstInsuredAdults"></param>
    /// <param name="lstInsuredChilds"></param>
    /// <param name="referenceCode"></param>
    /// <param name="isFTP"></param>
    /// <param name="ftpServer"></param>
    /// <param name="ftpUser"></param>
    /// <param name="ftpPass"></param>
    /// <param name="brokerEmail"></param>
    /// <returns></returns>
    [WebMethod]
    public ObjAXAPAPolicyIssued ProcessAXAPAPolicyIssue(string agentCode, string groupBrokerId, string password, string language, string InceptionDate, string ExpiryDate, string birthdate_of_first_insured, string packageID, int occupationID, string planCode, ObjAXAPAPolicyHolderDetail policyHolderDetail, List<ObjAXAPAAdultDetail> lstInsuredAdults, List<ObjAXAPAChildDetail> lstInsuredChilds, string referenceCode, bool isFTP, string ftpServer, string ftpUser, string ftpPass, string brokerEmail)
    {
        string retMsg = string.Empty;
        string retDeiverDoc = string.Empty;
        bool isValidateOK = true;

        language = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();

        #region ###Validate Corect Data into Web Service

        if (string.IsNullOrEmpty(language))
        {
            isValidateOK = false;
            retMsg += " | Language Must be 'T' or 'E' !!!";
        }

        if ((string.IsNullOrEmpty(InceptionDate) || string.IsNullOrEmpty(ExpiryDate))
            || (InceptionDate.Length < 10 || ExpiryDate.Length < 10))
        {
            isValidateOK = false;
            retMsg += " | Inception Date or Expiry Date Data Must be complete!!!";
        }
        else
        {
            string[] arrInceptionDate = InceptionDate.Split('/');
            string[] arrExpiryDate = ExpiryDate.Split('/');

            if (Int32.Parse(arrInceptionDate[2].Substring(0, 4)) > 2500)
            {
                isValidateOK = false;
                retMsg += " | Departure Date(Year) Value Must be A.D.!!!";
            }

            if (Int32.Parse(arrExpiryDate[2].Substring(0, 4)) > 2500)
            {
                isValidateOK = false;
                retMsg += " | Return Date(Year) Value Must be A.D.!!!";
            }
        }
        if (lstInsuredAdults == null || lstInsuredAdults[0] == null)
        {
            isValidateOK = false;
            retMsg += " | List of traveller adult can not be null value!!!";

        }
        else if (string.IsNullOrEmpty(birthdate_of_first_insured) || string.IsNullOrEmpty(lstInsuredAdults[0]._birthday))
        {
            isValidateOK = false;
            retMsg += " | Date of birth of first insured Must be complete!!!";

        }
        else
        {
            string[] arrbirthdate_of_first_insured = birthdate_of_first_insured.Split('/');

            if (Int32.Parse(arrbirthdate_of_first_insured[2].Substring(0, 4)) > 2500)
            {
                isValidateOK = false;
                retMsg += " | Date of birth of first insured(Year) Value Must be A.D.!!!";
            }

            if (birthdate_of_first_insured != lstInsuredAdults[0]._birthday)
            {
                isValidateOK = false;
                retMsg += " | Date of birth of first insured parameter must same as Date of birth of first Adult insured. !!!";
            }
        }

        if (string.IsNullOrEmpty(packageID))
        {
            isValidateOK = false;
            retMsg += " | PackageID Data Must be complete!!!";
        }

        if (string.IsNullOrEmpty(planCode))
        {
            isValidateOK = false;
            retMsg += " | Insurance Plan Code Data Must be complete!!!";
        }

        if (policyHolderDetail == null)
        {
            isValidateOK = false;
            retMsg += " | Policy holder detail data can not be null value!!!";
        }



        if (lstInsuredChilds == null)
        {
            isValidateOK = false;
            retMsg += " | List of insured child can not be null value!!!";
        }
        else
        {
            if (packageID != "0004")
            {
                if (lstInsuredChilds.Count > 0)
                {
                    isValidateOK = false;
                    retMsg += " | This Package not support -> List of child insured must be empty(count 0) only!!!";
                }
            }
        }

        if (isFTP == true)
        {
            if (string.IsNullOrEmpty(ftpServer) || string.IsNullOrEmpty(ftpUser) || string.IsNullOrEmpty(ftpPass))
            {
                isValidateOK = false;
                retMsg += " | FTP Data Must be complete!!!";
            }
        }
        else
        {
            if (string.IsNullOrEmpty(brokerEmail))
            {
                isValidateOK = false;
                retMsg += " | Broker email Data Must be complete!!!";
            }
        }
        #endregion

        string PolicyNo = "";

        #region ###Validate security & authorization into Web Service
        if (isValidateOK == true)
        {

            string retMsgSecur = "";

            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out retMsgSecur);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            if (isValidateOK == false)
            {
                retMsg += retMsgSecur;
            }
        }
        #endregion

        if (isValidateOK == true)
        {


            PAOccupationBLL clsPAOccupation = new PAOccupationBLL();
            PAOccupation clsOccupation = clsPAOccupation.GetPAOccupation(occupationID);
            string occupationClass = clsOccupation.OccupatnClass;
            string occupationDesc = language == "E" ? clsOccupation.DescriptionEN : clsOccupation.DescriptionTH;

            PAPlanPackagesBLL clsPAPlanPackage = new PAPlanPackagesBLL();
            PAPlanPackages clsPlanPackage = clsPAPlanPackage.GetPAPlanPackages(packageID);

            int NumbersOfChildren = lstInsuredChilds.Count;
            int NumbersOfAdult = lstInsuredAdults.Count;
            string EffectiveDateFrom = TA.TAUtilities.ConvertDateFieldToDB(InceptionDate);
            string EffectiveDateTo = TA.TAUtilities.ConvertDateFieldToDB(ExpiryDate);

            int insuredCounter = 0;

            //BEGIN VARIABLE-PLAN PREMIUM
            PAPlanPremiumsBLL clsPAPlanPremiumsBLL = new PAPlanPremiumsBLL();
            DataTable dt = clsPAPlanPremiumsBLL.GetDtPAPlanPremiums(planCode, occupationClass);
            int m_d_SumInsuredPA2 = int.Parse(dt.Rows[0]["SumInsuredPA2"].ToString().Trim());
            int m_d_SumInsuredME = int.Parse(dt.Rows[0]["SumInsuredME"].ToString().Trim());
            int m_d_PremiumPA2 = int.Parse(dt.Rows[0]["PremiumPA2"].ToString().Trim());
            int m_d_PremiumME = int.Parse(dt.Rows[0]["PremiumME"].ToString().Trim());
            int m_d_AddPremium = int.Parse(dt.Rows[0]["AddPremium"].ToString().Trim());
            int m_d_netpremium = int.Parse(dt.Rows[0]["GrossPremium"].ToString().Trim());
            int m_d_sbt = int.Parse(dt.Rows[0]["SBT"].ToString().Trim());
            int m_d_stamp = int.Parse(dt.Rows[0]["Stamp"].ToString().Trim());
            int m_d_total = int.Parse(dt.Rows[0]["TotalPremium"].ToString().Trim());
            //END VARIABLE-PLAN PREMIUM

            DbTransaction dbTransaction = null;


            #region "GET/SET JOB NUMBER (NOW NONE TRANSACTION)"
            //GET/SET JOB NUMBER
            //string m_JobNo = "AXA-TA-20120500007";
            PAJobRunningBLL clsjobrunning = new PAJobRunningBLL();
            string JobNo = string.Empty;
            //JobNo = clsjobrunning.GetTAJobRunningNumber(dbTransaction);                
            JobNo = clsjobrunning.GetPAJobRunningNumber();
            if (string.IsNullOrEmpty(JobNo))
            {
                throw new Exception("เกิดข้อผิดพลาดในการสร้างหมายเลข Job Number กรุณาทดลองบันทึกงานอีกครั้งหรือติดต่อผู้ดูแลระบบ");
            }
            #endregion

            DbProviderHelper db = new DbProviderHelper();
            db.GetConnection();

            #region "OPEN DB"
            //OPEN DB
            //DbProviderHelper dbHelper = new DbProviderHelper();
            //dbHelper.GetConnection();
            //dbHelper.OpenDb();            
            db.OpenDb();
            #endregion

            #region "OPEN TRANSACTION"
            //TRANSACTION BEGIN
            //dbTransaction = dbHelper.BeginTransaction();
            dbTransaction = db.BeginTransaction();
            #endregion

            try
            {
                #region "#1-INSERTTRANSPOLICY"
                //Create TransPolicy
                PATransPoliciesBLL clsPATransPoliciesBLL = new PATransPoliciesBLL();


                //clsPATransPoliciesBLL.SetPATransPolicy(m_JobNo, "0003", "1A", "2012-08-30", "2013-08-30", "BR002", "AJ", "01", "Programer", 0, 890, 7, 20, 1000, 0, "G0001", "Nam", "T");
                clsPATransPoliciesBLL.SetPATransPolicy(db,JobNo, packageID, planCode, EffectiveDateFrom, EffectiveDateTo, agentCode, "", occupationClass, occupationDesc, NumbersOfChildren, 0, 0, 0, 0, 0, groupBrokerId, agentCode, language, dbTransaction);
                #endregion

                #region "#2-INSERT/UPDATE TRANSPOLICYHOLDER"
                PATransPolicyHoldersBLL clsPATransPolicyHoldersBLL = new PATransPolicyHoldersBLL();
                //clsPATransPolicyHoldersBLL.SetPATransPolicyHolders(JobNo, 1, "P", "นาย", "ลอง", "ลองนามสกุล", "1/1", "อาคาร", "ซอย", "ถนน", "กรุงเทพมหานคร", "หลักสี่", "ตำบล", "10240", "1989-08-28", "F", "Z", "", "38418000XXXXX", "081", "Test@hotmail.com", "T", "");
                if (!string.IsNullOrEmpty(policyHolderDetail._birthday))
                {
                    policyHolderDetail._birthday = TA.TAUtilities.ConvertDateFieldToDB(policyHolderDetail._birthday);
                }

                clsPATransPolicyHoldersBLL.SetPATransPolicyHolders(db,JobNo, 1, policyHolderDetail._clientType, policyHolderDetail._clientTitle, policyHolderDetail._clientName, policyHolderDetail._clientSurName, policyHolderDetail._addressNo, policyHolderDetail._building, policyHolderDetail._soi, policyHolderDetail._road, policyHolderDetail._province, policyHolderDetail._amphur, policyHolderDetail._tumbol, policyHolderDetail._postCode, policyHolderDetail._birthday, policyHolderDetail._gender, policyHolderDetail._maritalStatus, policyHolderDetail._nationlity, policyHolderDetail._idCard, policyHolderDetail._tel, policyHolderDetail._email, language, policyHolderDetail._branchNo, dbTransaction);
                #endregion

                #region "#3,4-INSERT/UPDATE TRANSPOLICY INSURE"

                int m_InsuredIDPolicyInsure = 1;

                int numberofchid = lstInsuredChilds.Count;
                if (numberofchid == 0)
                {
                    if (packageID != "0004") // 0004 = Family
                    {
                        numberofchid = -1; // Set for != Family
                    }
                }
                int m_sum_TotalPremiumPolicyInsure = 0;
                int m_sum_SBTPolicyInsure = 0;
                int m_sum_StampPolicyInsure = 0;
                int m_sum_GrossPremiumPolicyInsure = 0;

                //---------------------Adults---------------------
                foreach (ObjAXAPAAdultDetail item in lstInsuredAdults)
                {
                    m_sum_GrossPremiumPolicyInsure += Convert.ToInt32(m_d_netpremium);
                    m_sum_StampPolicyInsure += Convert.ToInt32(m_d_stamp);
                    m_sum_SBTPolicyInsure += Convert.ToInt32(m_d_sbt);
                    m_sum_TotalPremiumPolicyInsure += Convert.ToInt32(m_d_total);

                    string m_BirthdayPolicyInsure = "";
                    if (!string.IsNullOrEmpty(item._birthday))
                    {
                        m_BirthdayPolicyInsure = TA.TAUtilities.ConvertDateFieldToDB(item._birthday);
                    }

                    sbyte m_isBeneficiaryPolicyInsure = 0;
                    if (item._beneficiary.Count > 0)
                    {
                        m_isBeneficiaryPolicyInsure = 1;
                    }
                    PATransPolicyInsuredsBLL clsPATransPolicyInsuredsBLL = new PATransPolicyInsuredsBLL();
                    clsPATransPolicyInsuredsBLL.SetPATransPolicyInsureds(db,JobNo, m_InsuredIDPolicyInsure, "", item._clientTitle, item._clientName, item._clientSurName, m_BirthdayPolicyInsure, item._idCard, "", m_d_SumInsuredPA2, m_d_SumInsuredME, m_d_PremiumPA2, m_d_PremiumME, m_d_AddPremium, m_d_netpremium, m_d_stamp, m_d_sbt, m_d_total, m_isBeneficiaryPolicyInsure, 0, 0, 1, 1, packageID, planCode, dbTransaction);

                    #region "#4-INSERT/UPDATE TRANSPOLICY BENEFICIARIES OF INSURE ONLY"

                    int beneficiarySeq = 1;
                    foreach (ObjAXAPABeneficialy benefic in item._beneficiary)
                    {
                        if (benefic == null)
                        {
                            throw new Exception("| Beneficial of Adult Insured is NULL OR Not Assigned?!!");
                        }
                        PATransBeneficiariesBLL clsPATransBeneficiariesBLL = new PATransBeneficiariesBLL();
                        //clsPATransBeneficiariesBLL.SetPATransBeneficiary(m_JobNo, 1, 1, "นาย", "สมมุติ", "นามสกุล", "พ่อ", "100", "021111999");
                        clsPATransBeneficiariesBLL.SetPATransBeneficiary(db,JobNo, m_InsuredIDPolicyInsure, beneficiarySeq, benefic._clientTitle, benefic._clientName, benefic._clientSurName, benefic._relationShip, benefic._ratio, benefic._tel, dbTransaction);

                        if (beneficiarySeq > 3)
                        {
                            break;
                        }
                        beneficiarySeq++;

                    }
                    #endregion


                    m_InsuredIDPolicyInsure++;

                    if (packageID == "0004")
                    {
                        if (m_InsuredIDPolicyInsure == 3)
                        {
                            break;
                        }
                    }
                    else
                    {
                        break;
                    }
                }

                //-----------------------Childs-------------------------
                if (packageID == "0004")
                {
                    decimal m_suminsured_discount = 1.00M;
                    decimal m_premium_discount = 1.00M;

                    foreach (ObjAXAPAChildDetail item in lstInsuredChilds)
                    {
                        if (item == null)
                        {
                            throw new Exception("| Child Insured is NULL OR Not Assigned?!!");
                        }

                        DateTime d_Insured_birthday = new DateTime();
                        DateTime d_InceptionDate = new DateTime();
                        bool ret = false;

                        string[] arrInceptionDate = InceptionDate.Split('/');
                        d_InceptionDate = Convert.ToDateTime(arrInceptionDate[2] + "-" + arrInceptionDate[1] + "-" + arrInceptionDate[0]); //DEFAULT EFFECTTIVE DATE FROM


                        int m_SumInsuredPA2PolicyInsure = (int)m_d_SumInsuredPA2;
                        int m_SumInsuredMEPolicyInsure = (int)m_d_SumInsuredME;
                        int m_PremiumPA2PolicyInsure = (int)m_d_PremiumME;
                        int m_PremiumMEPolicyInsure = (int)m_d_PremiumPA2;
                        int m_AddPremiumPolicyInsure = (int)m_d_AddPremium;
                        int m_GrossPremiumPolicyInsure = (int)m_d_netpremium;
                        int m_StampPolicyInsure = (int)m_d_stamp;
                        int m_SBTPolicyInsure = (int)m_d_sbt;
                        int m_TotalPremiumPolicyInsure = (int)m_d_total;

                        string m_BirthdayPolicyInsure = "";
                        if (!string.IsNullOrEmpty(item._birthday))
                        {
                            m_BirthdayPolicyInsure = TA.TAUtilities.ConvertDateFieldToDB(item._birthday);
                        }

                        sbyte m_isBeneficiaryPolicyInsure = 0;
                        if (item._beneficiary.Count > 0)
                        {
                            m_isBeneficiaryPolicyInsure = 1;
                        }

                        //IF Child  17 years 
                        //then  discount 
                        d_Insured_birthday = Convert.ToDateTime(m_BirthdayPolicyInsure);
                        ret = this.IsBirthDayOverLimitOfEffectiveDate(1, 17, d_Insured_birthday, d_InceptionDate);
                        if (!ret)
                        {
                            m_suminsured_discount = 0.50M;
                            m_premium_discount = 0.850M;
                        }
                        else
                        {

                            ret = this.IsBirthDayOverLimitOfEffectiveDate(18, 21, d_Insured_birthday, d_InceptionDate);
                            bool m_isStudent_and_isSingle = false;
                            if (item._isStudent == true && item._isSingle == true)
                            {
                                m_isStudent_and_isSingle = true; //on = true = selected
                            }
                            //IF Child between 18 years and  21 years ,be student and single
                            // then discount
                            if (!ret && m_isStudent_and_isSingle)
                            {
                                m_suminsured_discount = 0.50M;
                                m_premium_discount = 0.850M;
                            }
                            else
                            {
                                m_suminsured_discount = 1.00M;
                                m_premium_discount = 1.00M;
                            }
                        }

                        m_SumInsuredPA2PolicyInsure = Convert.ToInt32(m_SumInsuredPA2PolicyInsure * Convert.ToDouble(m_suminsured_discount));
                        m_SumInsuredMEPolicyInsure = Convert.ToInt32(m_d_SumInsuredME * Convert.ToDouble(m_suminsured_discount));


                        m_PremiumPA2PolicyInsure = Convert.ToInt32(m_d_PremiumME * Convert.ToDouble(m_premium_discount));
                        m_PremiumMEPolicyInsure = Convert.ToInt32(m_d_PremiumPA2 * Convert.ToDouble(m_premium_discount));
                        m_AddPremiumPolicyInsure = Convert.ToInt32(m_d_AddPremium * Convert.ToDouble(m_premium_discount));

                        //2013-04-03 เพิ่มการเช็ค ทศนิยมตั้งแต่ 0.75 ให้ปัดขึ้น
                        double n = Math.Round((double)m_GrossPremiumPolicyInsure * Convert.ToDouble(m_premium_discount), 2);
                        string s = string.Format("{0:0.00}", n);
                        Int32 d = Int32.Parse(s.Substring(s.IndexOf(".") + 1));
                        if (d >= 75)
                        {
                            m_GrossPremiumPolicyInsure = Convert.ToInt32(Math.Floor((double)m_GrossPremiumPolicyInsure * Convert.ToDouble(m_premium_discount))) + 1;
                        }
                        else
                        {
                            m_GrossPremiumPolicyInsure = Convert.ToInt32(Math.Floor((double)m_GrossPremiumPolicyInsure * Convert.ToDouble(m_premium_discount)));
                        }

                        m_StampPolicyInsure = Convert.ToInt32((Math.Ceiling((double)m_GrossPremiumPolicyInsure * 0.004)));
                        m_SBTPolicyInsure = 0;//Convert.ToInt32((Math.Ceiling((double)m_GrossPremiumPolicyInsure * 0.0275)));

                        //else not discount

                        m_TotalPremiumPolicyInsure = m_GrossPremiumPolicyInsure + m_StampPolicyInsure + m_SBTPolicyInsure;

                        //summary of all insured
                        m_sum_GrossPremiumPolicyInsure += Convert.ToInt32(m_GrossPremiumPolicyInsure);
                        m_sum_StampPolicyInsure += Convert.ToInt32(m_StampPolicyInsure);
                        m_sum_SBTPolicyInsure += Convert.ToInt32(m_SBTPolicyInsure);
                        m_sum_TotalPremiumPolicyInsure += Convert.ToInt32(m_TotalPremiumPolicyInsure);

                        m_isBeneficiaryPolicyInsure = 0;
                        if (item._beneficiary.Count > 0)
                        {
                            m_isBeneficiaryPolicyInsure = 1;
                        }
                        PATransPolicyInsuredsBLL clsPATransPolicyInsuredsBLL = new PATransPolicyInsuredsBLL();
                        //clsPATransPolicyInsuredsBLL.SetPATransPolicyInsureds(m_JobNo,1, "", "นาย", "ทดสอบ", "ทดสอบนามสกุล", "1989-08-28", "38418000XXXXX", "081", 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,0.50M,0.85M,1,1);            
                        clsPATransPolicyInsuredsBLL.SetPATransPolicyInsureds(db,JobNo, m_InsuredIDPolicyInsure, "", item._clientTitle, item._clientName, item._clientSurName, m_BirthdayPolicyInsure, item._idCard, "", m_SumInsuredPA2PolicyInsure, m_SumInsuredMEPolicyInsure, m_PremiumPA2PolicyInsure, m_PremiumMEPolicyInsure, m_AddPremiumPolicyInsure, m_GrossPremiumPolicyInsure, m_StampPolicyInsure, m_SBTPolicyInsure, m_TotalPremiumPolicyInsure, m_isBeneficiaryPolicyInsure, Convert.ToSByte(item._isStudent), Convert.ToSByte(item._isSingle), m_suminsured_discount, m_premium_discount, packageID, planCode, dbTransaction);

                        #region "#4-INSERT/UPDATE TRANSPOLICY BENEFICIARIES OF INSURE ONLY"

                        int beneficiarySeq = 1;
                        foreach (ObjAXAPABeneficialy benefic in item._beneficiary)
                        {

                            if (benefic == null)
                            {
                                throw new Exception("| Beneficial of Child Insured is NULL OR Not Assigned?!!");
                            }
                            PATransBeneficiariesBLL clsPATransBeneficiariesBLL = new PATransBeneficiariesBLL();
                            //clsPATransBeneficiariesBLL.SetPATransBeneficiary(JobNo, 1, 1, "นาย", "สมมุติ", "นามสกุล", "พ่อ", "100", "021111999");
                            clsPATransBeneficiariesBLL.SetPATransBeneficiary(db,JobNo, m_InsuredIDPolicyInsure, beneficiarySeq, benefic._clientTitle, benefic._clientName, benefic._clientSurName, benefic._relationShip, benefic._ratio, benefic._tel, dbTransaction);

                            if (beneficiarySeq > 3)
                            {
                                break;
                            }
                            beneficiarySeq++;

                        }
                        #endregion

                        //-------------increment Insure seq---------------
                        m_InsuredIDPolicyInsure++;
                    }
                }
                #endregion

                m_sum_StampPolicyInsure = Convert.ToInt32((Math.Ceiling((double)m_sum_GrossPremiumPolicyInsure * 0.004)));
                m_sum_SBTPolicyInsure = 0;//Convert.ToInt32((Math.Ceiling((double)m_sum_GrossPremiumPolicyInsure * 0.0275)));
                m_sum_TotalPremiumPolicyInsure = m_sum_GrossPremiumPolicyInsure + m_sum_StampPolicyInsure + m_sum_SBTPolicyInsure;

                #region "#5-INSERT/UPDATE TRANSPOLICY"

                //Create TransPolicy
                //PATransPoliciesBLL clsPATransPoliciesBLL = new PATransPoliciesBLL();
                //clsPATransPoliciesBLL.SetPATransPolicy(m_JobNo, "0003", "1A", "2012-08-30", "2013-08-30", "BR002", "AJ", "01", "Programer", 0, 890, 7, 20, 1000, 0, "G0001", "Nam", "T");
                clsPATransPoliciesBLL.SetPATransPolicy(db,JobNo, packageID, planCode, EffectiveDateFrom, EffectiveDateTo, agentCode, "", occupationClass, occupationDesc, NumbersOfChildren, m_sum_GrossPremiumPolicyInsure, m_sum_StampPolicyInsure, m_sum_SBTPolicyInsure, m_sum_TotalPremiumPolicyInsure, 0, groupBrokerId, agentCode, language, dbTransaction);
                #endregion

                #region "COMMIT DB"
                //COMMIT DB
                db.CommitTransaction(dbTransaction);
                #endregion

                #region "CLOSE DB"
                //CLOSE DB
                db.CloseDb();
                dbTransaction.Dispose();
                dbTransaction = null;

                #endregion

            }
            catch (Exception ex)
            {
                retMsg += ex.Message.ToString();

                if (dbTransaction != null)
                {
                    #region "ROLLBACK DB"
                    //ROLLBACK DB
                    db.RollbackTransaction(dbTransaction);
                    #endregion

                    #region "CLOSE DB"
                    //CLOSE DB
                    db.CloseDb();
                    #endregion
                }
            }

            if (retMsg == string.Empty)
                retMsg = "SUCCESS";

            string issueMsg = string.Empty;
            if (string.Compare(retMsg.ToUpper().Trim(), "SUCCESS") == 0)
            {
                PolicyNo = this.SetAXAPAPolicyIssue(agentCode, groupBrokerId, clsPlanPackage.PolicyType, planCode, referenceCode, JobNo, PrefixPA, out issueMsg);

                if (string.Compare(issueMsg.ToUpper().Trim(), "SUCCESS") == 0)
                {
                    retMsg = "SUCCESS";

                    #region ###Process Send E-mail or FTP Document
                    if (isFTP == false)
                    {
                        ObjAXAPAPolicyHolderDetail PolicyHolder = (ObjAXAPAPolicyHolderDetail)policyHolderDetail;
                        string insuredName = PolicyHolder._clientTitle + " " + PolicyHolder._clientName + " " + PolicyHolder._clientSurName;
                        string msgSendMail = string.Empty;

                        //Add Edit PDF Policy
                        DateTime CreateDate = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Now, "SE Asia Standard Time");

                        EditPDFPolicy(PolicyNo, "00", CreateDate);

                        msgSendMail = this.SendMail(PolicyNo, brokerEmail, insuredName);


                        if (string.Compare(msgSendMail.ToUpper().Trim(), "SUCCESS") == 0)
                        {
                            retDeiverDoc = "SUCCESS";
                        }
                    }
                    else
                    {
                        string msgFTP = string.Empty;


                        msgFTP = this.UploadFileToFTP(PolicyNo, ftpServer, ftpUser, ftpPass);


                        if (string.Compare(msgFTP.ToUpper().Trim(), "SUCCESS") == 0)
                        {
                            retDeiverDoc = "SUCCESS";
                        }
                    }

                    #endregion
                }
                else
                {
                    retMsg = issueMsg + " IN SET AXA POLICY ISSUE PROCESS!!!";
                }
            }
            else
            {
                retMsg += " IN SET AXA JOB PROCESS!!!";
            }
        }


        //deliverDocMsg = retDeiverDoc;
        //msg = retMsg;
        //return PolicyNo;
        ObjAXAPAPolicyIssued objPolicyIssue = new ObjAXAPAPolicyIssued();
        objPolicyIssue._msg = retMsg;
        objPolicyIssue._deliverDocMsg = retDeiverDoc;
        objPolicyIssue._policyNo = PolicyNo;

        return objPolicyIssue;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="agentCode"></param>
    /// <param name="groupBrokerId"></param>
    /// <param name="password"></param>
    /// <param name="language"></param>
    /// <param name="InceptionDate"></param>
    /// <param name="ExpiryDate"></param>
    /// <param name="birthdate_of_first_insured"></param>
    /// <param name="packageID"></param>
    /// <param name="occupationDesc"></param>
    /// <param name="planCode"></param>
    /// <param name="policyHolderDetail"></param>
    /// <param name="lstInsuredAdults"></param>
    /// <param name="lstInsuredChilds"></param>
    /// <param name="referenceCode"></param>
    /// <param name="isFTP"></param>
    /// <param name="ftpServer"></param>
    /// <param name="ftpUser"></param>
    /// <param name="ftpPass"></param>
    /// <param name="brokerEmail"></param>
    /// <returns></returns>
    [WebMethod]//Makkawat Update 20160127
    public ObjAXAPAPolicyIssued ProcessAXAPAPolicyIssueSmartPA(string agentCode, string groupBrokerId, string password, string language, string InceptionDate, string ExpiryDate, string birthdate_of_first_insured, string packageID, int occupationID, string planCode, ObjAXAPAPolicyHolderDetail policyHolderDetail, List<ObjAXAPAAdultDetail> lstInsuredAdults, List<ObjAXAPAChildDetail> lstInsuredChilds, string referenceCode, bool isFTP, string ftpServer, string ftpUser, string ftpPass, string brokerEmail)
    {
        string retMsg = string.Empty;
        string retDeiverDoc = string.Empty;
        bool isValidateOK = true;
        PAPlanPackages clsPlanPackage;
        PAPlanPackagesBLL clsPAPlanPackage = new PAPlanPackagesBLL();
        string coverageCodeAccidentPublic = "14";
        string[] arrContractSmartPAPlus = { "APX", "APG" };
        string[] prefix = { "Q", "P" };  // if pacakge normal PA prefix is Q7xxxxxxx  and PA smart pa plus is P75xxxxx

        language = string.IsNullOrEmpty(language) ? "E" : language.ToUpper().Trim();

        #region ###Validate Corect Data into Web Service

        if (string.IsNullOrEmpty(language))
        {
            isValidateOK = false;
            retMsg += " | Language Must be 'T' or 'E' !!!";
        }

        if ((string.IsNullOrEmpty(InceptionDate) || string.IsNullOrEmpty(ExpiryDate))
            || (InceptionDate.Length < 10 || ExpiryDate.Length < 10))
        {
            isValidateOK = false;
            retMsg += " | Inception Date or Expiry Date Data Must be complete!!!";
        }
        else
        {
            string[] arrInceptionDate = InceptionDate.Split('/');
            string[] arrExpiryDate = ExpiryDate.Split('/');

            if (Int32.Parse(arrInceptionDate[2].Substring(0, 4)) > 2500)
            {
                isValidateOK = false;
                retMsg += " | Departure Date(Year) Value Must be A.D.!!!";
            }

            if (Int32.Parse(arrExpiryDate[2].Substring(0, 4)) > 2500)
            {
                isValidateOK = false;
                retMsg += " | Return Date(Year) Value Must be A.D.!!!";
            }
        }
        if (lstInsuredAdults == null || lstInsuredAdults[0] == null)
        {
            isValidateOK = false;
            retMsg += " | List of traveller adult can not be null value!!!";

        }
        else if (string.IsNullOrEmpty(birthdate_of_first_insured) || string.IsNullOrEmpty(lstInsuredAdults[0]._birthday))
        {
            isValidateOK = false;
            retMsg += " | Date of birth of first insured Must be complete!!!";

        }
        else
        {
            string[] arrbirthdate_of_first_insured = birthdate_of_first_insured.Split('/');

            if (Int32.Parse(arrbirthdate_of_first_insured[2].Substring(0, 4)) > 2500)
            {
                isValidateOK = false;
                retMsg += " | Date of birth of first insured(Year) Value Must be A.D.!!!";
            }

            if (birthdate_of_first_insured != lstInsuredAdults[0]._birthday)
            {
                isValidateOK = false;
                retMsg += " | Date of birth of first insured parameter must same as Date of birth of first Adult insured. !!!";
            }
        }

        if (string.IsNullOrEmpty(packageID))
        {
            isValidateOK = false;
            retMsg += " | PackageID Data Must be complete!!!";
        }


        if (string.IsNullOrEmpty(planCode))
        {
            isValidateOK = false;
            retMsg += " | Insurance Plan Code Data Must be complete!!!";
        }

        if (policyHolderDetail == null)
        {
            isValidateOK = false;
            retMsg += " | Policy holder detail data can not be null value!!!";
        }



        if (lstInsuredChilds == null)
        {
            isValidateOK = false;
            retMsg += " | List of insured child can not be null value!!!";
        }
        else
        {
            //if (packageID != "0004") 
            clsPlanPackage = clsPAPlanPackage.GetPAPlanPackages(packageID);
            if (!clsPlanPackage.PolicyType.Equals("FAMILY"))
            {
                if (lstInsuredChilds.Count > 0)
                {
                    isValidateOK = false;
                    retMsg += " | This Package not support -> List of child insured must be empty(count 0) only!!!";
                }
            }
        }


        if (isFTP == true)
        {
            if (string.IsNullOrEmpty(ftpServer) || string.IsNullOrEmpty(ftpUser) || string.IsNullOrEmpty(ftpPass))
            {
                isValidateOK = false;
                retMsg += " | FTP Data Must be complete!!!";
            }
        }
        else
        {
            if (string.IsNullOrEmpty(brokerEmail))
            {
                isValidateOK = false;
                retMsg += " | Broker email Data Must be complete!!!";
            }
        }
        #endregion

        string PolicyNo = "";

        #region ###Validate security & authorization into Web Service
        if (isValidateOK == true)
        {

            string retMsgSecur = "";

            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out retMsgSecur);
            //isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password);
            if (isValidateOK == false)
            {
                retMsg += retMsgSecur;
            }
        }
        #endregion

        DbProviderHelper db = new DbProviderHelper();
        db.GetConnection();

        if (isValidateOK == true)
        {


            PAOccupationBLL clsPAOccupation = new PAOccupationBLL();

            PAOccupation clsOccupation = clsPAOccupation.GetPAOccupation(occupationID);
            string occupationClass = clsOccupation.OccupatnClass;
            string occupationDesc = language == "E" ? clsOccupation.DescriptionEN : clsOccupation.DescriptionTH;

            //PAPlanPackagesBLL clsPAPlanPackage = new PAPlanPackagesBLL();
            clsPlanPackage = clsPAPlanPackage.GetPAPlanPackages(packageID);

            int NumbersOfChildren = lstInsuredAdults.Count;
            int NumbersOfAdult = lstInsuredChilds.Count;
            string EffectiveDateFrom = TA.TAUtilities.ConvertDateFieldToDB(InceptionDate);
            string EffectiveDateTo = TA.TAUtilities.ConvertDateFieldToDB(ExpiryDate);

            int insuredCounter = 0;


            //20160111
            PAPlanCoveragesBLL ppc = new PAPlanCoveragesBLL();
            DataTable dtco = ppc.GetDtPAPlanCoveragesRow(planCode, occupationClass, coverageCodeAccidentPublic);
            int m_d_CoverageAmtAccidentPublic = 0;
            int sum_CoverageAmtAccidentPublic_stamp = 0;
            if (dtco != null && dtco.Rows.Count > 0)
            {
                m_d_CoverageAmtAccidentPublic = int.Parse(dtco.Rows[0]["NetPremium"].ToString().Trim());
            }
            //

            //BEGIN VARIABLE-PLAN PREMIUM
            PAPlanPremiumsBLL clsPAPlanPremiumsBLL = new PAPlanPremiumsBLL();
            DataTable dt = clsPAPlanPremiumsBLL.GetDtPAPlanPremiums(planCode, occupationClass);
            int m_d_SumInsuredPA2 = int.Parse(dt.Rows[0]["SumInsuredPA2"].ToString().Trim());
            int m_d_SumInsuredME = int.Parse(dt.Rows[0]["SumInsuredME"].ToString().Trim());
            int m_d_PremiumPA2 = int.Parse(dt.Rows[0]["PremiumPA2"].ToString().Trim());
            int m_d_PremiumME = int.Parse(dt.Rows[0]["PremiumME"].ToString().Trim());
            int m_d_AddPremium = int.Parse(dt.Rows[0]["AddPremium"].ToString().Trim());
            int m_d_netpremium = int.Parse(dt.Rows[0]["GrossPremium"].ToString().Trim());
            int m_d_sbt = int.Parse(dt.Rows[0]["SBT"].ToString().Trim());
            int m_d_stamp = int.Parse(dt.Rows[0]["Stamp"].ToString().Trim());
            int m_d_total = int.Parse(dt.Rows[0]["TotalPremium"].ToString().Trim());
            //END VARIABLE-PLAN PREMIUM

            //BEGIN VARIABLE-PLAN PREMIUM (if smart PA type Family)
            int mm_d_SumInsuredPA2 = 0;
            int mm_d_SumInsuredME = 0;
            int mm_d_PremiumPA2 = 0;
            int mm_d_PremiumME = 0;
            int mm_d_AddPremium = 0;
            int mm_d_netpremium = 0;
            int mm_d_sbt = 0;
            int mm_d_stamp = 0;
            int mm_d_total = 0;

            if (clsPlanPackage.PolicyType.Equals("FAMILY") && clsPlanPackage.ContractType.Equals(arrContractSmartPAPlus[1]))// contract type for AXA Smart PA Plus
            {
                dt = clsPAPlanPremiumsBLL.GetDtPAPlanPremiums(planCode + "M", occupationClass);
                mm_d_SumInsuredPA2 = int.Parse(dt.Rows[0]["SumInsuredPA2"].ToString().Trim());
                mm_d_SumInsuredME = int.Parse(dt.Rows[0]["SumInsuredME"].ToString().Trim());
                mm_d_PremiumPA2 = int.Parse(dt.Rows[0]["PremiumPA2"].ToString().Trim());
                mm_d_PremiumME = int.Parse(dt.Rows[0]["PremiumME"].ToString().Trim());
                mm_d_AddPremium = int.Parse(dt.Rows[0]["AddPremium"].ToString().Trim());
                mm_d_netpremium = int.Parse(dt.Rows[0]["GrossPremium"].ToString().Trim());
                mm_d_sbt = int.Parse(dt.Rows[0]["SBT"].ToString().Trim());
                mm_d_stamp = int.Parse(dt.Rows[0]["Stamp"].ToString().Trim());
                mm_d_total = int.Parse(dt.Rows[0]["TotalPremium"].ToString().Trim());

                foreach (ObjAXAPAChildDetail insuredChilds in lstInsuredChilds)
                {
                    ObjAXAPAAdultDetail insuredAdult = new ObjAXAPAAdultDetail();
                    insuredAdult._beneficiary = insuredChilds._beneficiary;
                    insuredAdult._birthday = insuredChilds._birthday;
                    insuredAdult._clientName = insuredChilds._clientName;
                    insuredAdult._clientSurName = insuredChilds._clientSurName;
                    insuredAdult._clientTitle = insuredChilds._clientTitle;
                    insuredAdult._idCard = insuredChilds._idCard;
                    lstInsuredAdults.Add(insuredAdult);
                }

            }
            //END VARIABLE-PLAN PREMIUM (Member)

            DbTransaction dbTransaction = null;


            #region "GET/SET JOB NUMBER (NOW NONE TRANSACTION)"
            //GET/SET JOB NUMBER
            //string m_JobNo = "AXA-TA-20120500007";
            PAJobRunningBLL clsjobrunning = new PAJobRunningBLL();
            string JobNo = string.Empty;
            //JobNo = clsjobrunning.GetTAJobRunningNumber(dbTransaction);                
            JobNo = clsjobrunning.GetPAJobRunningNumber();
            if (string.IsNullOrEmpty(JobNo))
            {
                throw new Exception("เกิดข้อผิดพลาดในการสร้างหมายเลข Job Number กรุณาทดลองบันทึกงานอีกครั้งหรือติดต่อผู้ดูแลระบบ");
            }
            #endregion

            #region "OPEN DB"
            //OPEN DB
            //DbProviderHelper dbHelper = new DbProviderHelper();
            //dbHelper.GetConnection();
            //dbHelper.OpenDb();            
            db.OpenDb();
            #endregion

            #region "OPEN TRANSACTION"
            //TRANSACTION BEGIN
            //dbTransaction = dbHelper.BeginTransaction();
            dbTransaction = db.BeginTransaction();
            #endregion

            try
            {
                #region "#1-INSERTTRANSPOLICY"
                //Create TransPolicy
                PATransPoliciesBLL clsPATransPoliciesBLL = new PATransPoliciesBLL();


                //clsPATransPoliciesBLL.SetPATransPolicy(m_JobNo, "0003", "1A", "2012-08-30", "2013-08-30", "BR002", "AJ", "01", "Programer", 0, 890, 7, 20, 1000, 0, "G0001", "Nam", "T");
                if (clsPlanPackage.ContractType.Equals(arrContractSmartPAPlus[1])) // if contract type APG smart pa plus family non cal stamp
                {
                    clsPATransPoliciesBLL.SetPATransPolicyNONStamp(db,JobNo, packageID, planCode, EffectiveDateFrom, EffectiveDateTo, agentCode, "", occupationClass, occupationDesc, NumbersOfChildren, 0, 0, 0, 0, 0, groupBrokerId, agentCode, language, dbTransaction);
                }
                else
                {
                    clsPATransPoliciesBLL.SetPATransPolicyNONStamp(db,JobNo, packageID, planCode, EffectiveDateFrom, EffectiveDateTo, agentCode, "", occupationClass, occupationDesc, NumbersOfChildren, 0, 0, 0, 0, 0, groupBrokerId, agentCode, language, dbTransaction);
                }

                #endregion

                #region "#2-INSERT/UPDATE TRANSPOLICYHOLDER"
                PATransPolicyHoldersBLL clsPATransPolicyHoldersBLL = new PATransPolicyHoldersBLL();
                //clsPATransPolicyHoldersBLL.SetPATransPolicyHolders(JobNo, 1, "P", "นาย", "ลอง", "ลองนามสกุล", "1/1", "อาคาร", "ซอย", "ถนน", "กรุงเทพมหานคร", "หลักสี่", "ตำบล", "10240", "1989-08-28", "F", "Z", "", "38418000XXXXX", "081", "Test@hotmail.com", "T", "");
                if (!string.IsNullOrEmpty(policyHolderDetail._birthday))
                {
                    policyHolderDetail._birthday = TA.TAUtilities.ConvertDateFieldToDB(policyHolderDetail._birthday);
                }

                clsPATransPolicyHoldersBLL.SetPATransPolicyHolders(db,JobNo, 1, policyHolderDetail._clientType, policyHolderDetail._clientTitle, policyHolderDetail._clientName, policyHolderDetail._clientSurName, policyHolderDetail._addressNo, policyHolderDetail._building, policyHolderDetail._soi, policyHolderDetail._road, policyHolderDetail._province, policyHolderDetail._amphur, policyHolderDetail._tumbol, policyHolderDetail._postCode, policyHolderDetail._birthday, policyHolderDetail._gender, policyHolderDetail._maritalStatus, policyHolderDetail._nationlity, policyHolderDetail._idCard, policyHolderDetail._tel, policyHolderDetail._email, language, policyHolderDetail._branchNo, dbTransaction);
                #endregion

                #region "#3,4-INSERT/UPDATE TRANSPOLICY INSURE"

                int m_InsuredIDPolicyInsure = 1;

                int numberofchid = lstInsuredChilds.Count;



                if (numberofchid == 0)
                {
                    //if (packageID != "0004") // 0004 = Family
                    if (!clsPlanPackage.PolicyType.Equals("FAMILY")) // 20160111 : if not family set child = -1
                    {
                        numberofchid = -1; // Set for != Family
                    }
                }
                int m_sum_TotalPremiumPolicyInsure = 0;
                int m_sum_SBTPolicyInsure = 0;
                int m_sum_StampPolicyInsure = 0;
                int m_sum_GrossPremiumPolicyInsure = 0;
                string master_planCode = planCode;

                //---------------------Adults---------------------
                foreach (ObjAXAPAAdultDetail item in lstInsuredAdults)
                {



                    //BEGIN VARIABLE-PLAN PREMIUM (if smart PA type Family)
                    if (clsPlanPackage.PolicyType.Equals("FAMILY") && clsPlanPackage.ContractType.Equals(arrContractSmartPAPlus[1]) && (m_InsuredIDPolicyInsure > 1))// contract type for AXA Smart PA Plus
                    {

                        planCode = master_planCode + "M";  // ครั้งที่ 2 ต้องให้ plancode เปลี่ยนจาก P1-4 เป็น P1-4M
                        m_d_SumInsuredPA2 = mm_d_SumInsuredPA2;
                        m_d_SumInsuredME = mm_d_SumInsuredME;
                        m_d_PremiumPA2 = mm_d_PremiumPA2;
                        m_d_PremiumME = mm_d_PremiumME;
                        m_d_AddPremium = mm_d_AddPremium;
                        m_d_netpremium = mm_d_netpremium;
                        m_d_sbt = mm_d_sbt;
                        m_d_stamp = mm_d_stamp;
                        m_d_total = mm_d_total;

                    }
                    //END VARIABLE-PLAN PREMIUM (Member)


                    //20160111
                    if (policyHolderDetail._flagAddCoverage != null && policyHolderDetail._flagAddCoverage)
                    {

                        //m_d_AddPremium += m_d_CoverageAmtAccidentPublic; // 20160208 : comment เนื่องจากหน้าตารางไม่ต้องโชว์ add premiumn
                        //m_d_stamp       = Convert.ToInt16(Math.Ceiling(Convert.ToDouble(m_d_netpremium) * 0.004));
                        m_d_stamp += Convert.ToInt16(Math.Ceiling(Convert.ToDouble(m_d_CoverageAmtAccidentPublic) * 0.004));
                        m_d_netpremium += m_d_CoverageAmtAccidentPublic;
                        m_d_total = m_d_netpremium + m_d_stamp;

                        m_sum_GrossPremiumPolicyInsure += Convert.ToInt32(m_d_netpremium);
                        //m_sum_StampPolicyInsure += Convert.ToInt16(Math.Ceiling(Convert.ToDouble(m_d_netpremium) * 0.004));
                        m_sum_StampPolicyInsure += m_d_stamp;
                        m_sum_SBTPolicyInsure += Convert.ToInt32(m_d_sbt);
                        m_sum_TotalPremiumPolicyInsure += (m_d_netpremium + m_sum_StampPolicyInsure);

                        sum_CoverageAmtAccidentPublic_stamp += Convert.ToInt16(Math.Ceiling(Convert.ToDouble(m_d_CoverageAmtAccidentPublic) * 0.004));

                    }
                    else
                    {
                        m_sum_GrossPremiumPolicyInsure += Convert.ToInt32(m_d_netpremium);
                        m_sum_StampPolicyInsure += Convert.ToInt32(m_d_stamp);
                        m_sum_SBTPolicyInsure += Convert.ToInt32(m_d_sbt);
                        m_sum_TotalPremiumPolicyInsure += Convert.ToInt32(m_d_total);
                    }
                    //


                    string m_BirthdayPolicyInsure = "";
                    if (!string.IsNullOrEmpty(item._birthday))
                    {
                        m_BirthdayPolicyInsure = TA.TAUtilities.ConvertDateFieldToDB(item._birthday);
                    }

                    sbyte m_isBeneficiaryPolicyInsure = 0;
                    if (item._beneficiary.Count > 0)
                    {
                        m_isBeneficiaryPolicyInsure = 1;
                    }
                    PATransPolicyInsuredsBLL clsPATransPolicyInsuredsBLL = new PATransPolicyInsuredsBLL();
                    clsPATransPolicyInsuredsBLL.SetPATransPolicyInsureds(db,JobNo, m_InsuredIDPolicyInsure, "", item._clientTitle, item._clientName, item._clientSurName, m_BirthdayPolicyInsure, item._idCard, "", m_d_SumInsuredPA2, m_d_SumInsuredME, m_d_PremiumPA2, m_d_PremiumME, m_d_AddPremium, m_d_netpremium, m_d_stamp, m_d_sbt, m_d_total, m_isBeneficiaryPolicyInsure, 0, 0, 1, 1, packageID, planCode, policyHolderDetail._flagAddCoverage, dbTransaction);

                    #region "#4-INSERT/UPDATE TRANSPOLICY BENEFICIARIES OF INSURE ONLY"

                    int beneficiarySeq = 1;
                    foreach (ObjAXAPABeneficialy benefic in item._beneficiary)
                    {
                        if (benefic == null)
                        {
                            throw new Exception("| Beneficial of Adult Insured is NULL OR Not Assigned?!!");
                        }
                        PATransBeneficiariesBLL clsPATransBeneficiariesBLL = new PATransBeneficiariesBLL();
                        //clsPATransBeneficiariesBLL.SetPATransBeneficiary(m_JobNo, 1, 1, "นาย", "สมมุติ", "นามสกุล", "พ่อ", "100", "021111999");
                        clsPATransBeneficiariesBLL.SetPATransBeneficiary(db,JobNo, m_InsuredIDPolicyInsure, beneficiarySeq, benefic._clientTitle, benefic._clientName, benefic._clientSurName, benefic._relationShip, benefic._ratio, benefic._tel, dbTransaction);

                        if (beneficiarySeq > 3)
                        {
                            break;
                        }
                        beneficiarySeq++;

                    }
                    #endregion


                    m_InsuredIDPolicyInsure++;

                    //if (packageID == "0004")
                    if (clsPlanPackage.PolicyType.Equals("FAMILY"))
                    {
                        if ((m_InsuredIDPolicyInsure == 3) && (!clsPlanPackage.ContractType.Equals(arrContractSmartPAPlus[1])))
                        {
                            break;
                        }
                    }
                    else
                    {
                        break;
                    }
                }

                //-----------------------Childs-------------------------
                //if (packageID == "0004")
                if (clsPlanPackage.PolicyType.Equals("FAMILY") && !clsPlanPackage.ContractType.Equals(arrContractSmartPAPlus[1]))
                {
                    decimal m_suminsured_discount = 1.00M;
                    decimal m_premium_discount = 1.00M;

                    foreach (ObjAXAPAChildDetail item in lstInsuredChilds)
                    {
                        if (item == null)
                        {
                            throw new Exception("| Child Insured is NULL OR Not Assigned?!!");
                        }

                        DateTime d_Insured_birthday = new DateTime();
                        DateTime d_InceptionDate = new DateTime();
                        bool ret = false;

                        string[] arrInceptionDate = InceptionDate.Split('/');
                        d_InceptionDate = Convert.ToDateTime(arrInceptionDate[2] + "-" + arrInceptionDate[1] + "-" + arrInceptionDate[0]); //DEFAULT EFFECTTIVE DATE FROM


                        int m_SumInsuredPA2PolicyInsure = (int)m_d_SumInsuredPA2;
                        int m_SumInsuredMEPolicyInsure = (int)m_d_SumInsuredME;
                        int m_PremiumPA2PolicyInsure = (int)m_d_PremiumME;
                        int m_PremiumMEPolicyInsure = (int)m_d_PremiumPA2;
                        int m_AddPremiumPolicyInsure = (int)m_d_AddPremium;
                        int m_GrossPremiumPolicyInsure = (int)m_d_netpremium;
                        int m_StampPolicyInsure = (int)m_d_stamp;
                        int m_SBTPolicyInsure = (int)m_d_sbt;
                        int m_TotalPremiumPolicyInsure = (int)m_d_total;

                        string m_BirthdayPolicyInsure = "";
                        if (!string.IsNullOrEmpty(item._birthday))
                        {
                            m_BirthdayPolicyInsure = TA.TAUtilities.ConvertDateFieldToDB(item._birthday);
                        }

                        sbyte m_isBeneficiaryPolicyInsure = 0;
                        if (item._beneficiary.Count > 0)
                        {
                            m_isBeneficiaryPolicyInsure = 1;
                        }

                        //IF Child  17 years 
                        //then  discount 
                        d_Insured_birthday = Convert.ToDateTime(m_BirthdayPolicyInsure);
                        ret = this.IsBirthDayOverLimitOfEffectiveDate(1, 17, d_Insured_birthday, d_InceptionDate);
                        if (!ret)
                        {
                            m_suminsured_discount = 0.50M;
                            m_premium_discount = 0.850M;
                        }
                        else
                        {

                            ret = this.IsBirthDayOverLimitOfEffectiveDate(18, 21, d_Insured_birthday, d_InceptionDate);
                            bool m_isStudent_and_isSingle = false;
                            if (item._isStudent == true && item._isSingle == true)
                            {
                                m_isStudent_and_isSingle = true; //on = true = selected
                            }
                            //IF Child between 18 years and  21 years ,be student and single
                            // then discount
                            if (!ret && m_isStudent_and_isSingle)
                            {
                                m_suminsured_discount = 0.50M;
                                m_premium_discount = 0.850M;
                            }
                            else
                            {
                                m_suminsured_discount = 1.00M;
                                m_premium_discount = 1.00M;
                            }
                        }

                        m_SumInsuredPA2PolicyInsure = Convert.ToInt32(m_SumInsuredPA2PolicyInsure * Convert.ToDouble(m_suminsured_discount));
                        m_SumInsuredMEPolicyInsure = Convert.ToInt32(m_d_SumInsuredME * Convert.ToDouble(m_suminsured_discount));


                        m_PremiumPA2PolicyInsure = Convert.ToInt32(m_d_PremiumME * Convert.ToDouble(m_premium_discount));
                        m_PremiumMEPolicyInsure = Convert.ToInt32(m_d_PremiumPA2 * Convert.ToDouble(m_premium_discount));
                        m_AddPremiumPolicyInsure = Convert.ToInt32(m_d_AddPremium * Convert.ToDouble(m_premium_discount));

                        //2013-04-03 เพิ่มการเช็ค ทศนิยมตั้งแต่ 0.75 ให้ปัดขึ้น
                        double n = Math.Round((double)m_GrossPremiumPolicyInsure * Convert.ToDouble(m_premium_discount), 2);
                        string s = string.Format("{0:0.00}", n);
                        Int32 d = Int32.Parse(s.Substring(s.IndexOf(".") + 1));
                        if (d >= 75)
                        {
                            m_GrossPremiumPolicyInsure = Convert.ToInt32(Math.Floor((double)m_GrossPremiumPolicyInsure * Convert.ToDouble(m_premium_discount))) + 1;
                        }
                        else
                        {
                            m_GrossPremiumPolicyInsure = Convert.ToInt32(Math.Floor((double)m_GrossPremiumPolicyInsure * Convert.ToDouble(m_premium_discount)));
                        }

                        m_StampPolicyInsure = Convert.ToInt32((Math.Ceiling((double)m_GrossPremiumPolicyInsure * 0.004)));
                        m_SBTPolicyInsure = 0;//Convert.ToInt32((Math.Ceiling((double)m_GrossPremiumPolicyInsure * 0.0275)));

                        //else not discount

                        m_TotalPremiumPolicyInsure = m_GrossPremiumPolicyInsure + m_StampPolicyInsure + m_SBTPolicyInsure;

                        //summary of all insured
                        m_sum_GrossPremiumPolicyInsure += Convert.ToInt32(m_GrossPremiumPolicyInsure);
                        m_sum_StampPolicyInsure += Convert.ToInt32(m_StampPolicyInsure);
                        m_sum_SBTPolicyInsure += Convert.ToInt32(m_SBTPolicyInsure);
                        m_sum_TotalPremiumPolicyInsure += Convert.ToInt32(m_TotalPremiumPolicyInsure);

                        m_isBeneficiaryPolicyInsure = 0;
                        if (item._beneficiary.Count > 0)
                        {
                            m_isBeneficiaryPolicyInsure = 1;
                        }
                        PATransPolicyInsuredsBLL clsPATransPolicyInsuredsBLL = new PATransPolicyInsuredsBLL();
                        //clsPATransPolicyInsuredsBLL.SetPATransPolicyInsureds(m_JobNo,1, "", "นาย", "ทดสอบ", "ทดสอบนามสกุล", "1989-08-28", "38418000XXXXX", "081", 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,0.50M,0.85M,1,1);            
                        clsPATransPolicyInsuredsBLL.SetPATransPolicyInsureds(db,JobNo, m_InsuredIDPolicyInsure, "", item._clientTitle, item._clientName, item._clientSurName, m_BirthdayPolicyInsure, item._idCard, "", m_SumInsuredPA2PolicyInsure, m_SumInsuredMEPolicyInsure, m_PremiumPA2PolicyInsure, m_PremiumMEPolicyInsure, m_AddPremiumPolicyInsure, m_GrossPremiumPolicyInsure, m_StampPolicyInsure, m_SBTPolicyInsure, m_TotalPremiumPolicyInsure, m_isBeneficiaryPolicyInsure, Convert.ToSByte(item._isStudent), Convert.ToSByte(item._isSingle), m_suminsured_discount, m_premium_discount, packageID, planCode, policyHolderDetail._flagAddCoverage, dbTransaction);

                        #region "#4-INSERT/UPDATE TRANSPOLICY BENEFICIARIES OF INSURE ONLY"

                        int beneficiarySeq = 1;
                        foreach (ObjAXAPABeneficialy benefic in item._beneficiary)
                        {

                            if (benefic == null)
                            {
                                throw new Exception("| Beneficial of Child Insured is NULL OR Not Assigned?!!");
                            }
                            PATransBeneficiariesBLL clsPATransBeneficiariesBLL = new PATransBeneficiariesBLL();
                            //clsPATransBeneficiariesBLL.SetPATransBeneficiary(JobNo, 1, 1, "นาย", "สมมุติ", "นามสกุล", "พ่อ", "100", "021111999");
                            clsPATransBeneficiariesBLL.SetPATransBeneficiary(db, JobNo, m_InsuredIDPolicyInsure, beneficiarySeq, benefic._clientTitle, benefic._clientName, benefic._clientSurName, benefic._relationShip, benefic._ratio, benefic._tel, dbTransaction);

                            if (beneficiarySeq > 3)
                            {
                                break;
                            }
                            beneficiarySeq++;

                        }
                        #endregion

                        //-------------increment Insure seq---------------
                        m_InsuredIDPolicyInsure++;
                    }
                }
                #endregion

                #region "#5-INSERT/UPDATE TRANSPOLICY"

                //Create TransPolicy
                //PATransPoliciesBLL clsPATransPoliciesBLL = new PATransPoliciesBLL();
                //clsPATransPoliciesBLL.SetPATransPolicy(m_JobNo, "0003", "1A", "2012-08-30", "2013-08-30", "BR002", "AJ", "01", "Programer", 0, 890, 7, 20, 1000, 0, "G0001", "Nam", "T");

                //20160111
                planCode = master_planCode;


                if (clsPlanPackage.ContractType.Equals(arrContractSmartPAPlus[1])) // if contract type APG smart pa plus family non cal stamp
                {
                    clsPATransPoliciesBLL.SetPATransPolicyNONStamp(db,JobNo, packageID, planCode, EffectiveDateFrom, EffectiveDateTo, agentCode, "", occupationClass, occupationDesc, NumbersOfChildren, m_sum_GrossPremiumPolicyInsure, m_sum_StampPolicyInsure, m_sum_SBTPolicyInsure, m_sum_TotalPremiumPolicyInsure, 0, groupBrokerId, agentCode, language, dbTransaction);
                }
                else
                {
                    clsPATransPoliciesBLL.SetPATransPolicyNONStamp(db,JobNo, packageID, planCode, EffectiveDateFrom, EffectiveDateTo, agentCode, "", occupationClass, occupationDesc, NumbersOfChildren, m_sum_GrossPremiumPolicyInsure, m_sum_StampPolicyInsure, m_sum_SBTPolicyInsure, m_sum_TotalPremiumPolicyInsure, 0, groupBrokerId, agentCode, language, dbTransaction);
                }


                #endregion

                #region "COMMIT DB"
                //COMMIT DB
                db.CommitTransaction(dbTransaction);
                #endregion

                #region "CLOSE DB"
                //CLOSE DB
                db.CloseDb();
                dbTransaction.Dispose();
                dbTransaction = null;

                #endregion

            }
            catch (Exception ex)
            {
                retMsg += ex.Message.ToString();

                if (dbTransaction != null)
                {
                    #region "ROLLBACK DB"
                    //ROLLBACK DB
                    db.RollbackTransaction(dbTransaction);
                    #endregion

                    #region "CLOSE DB"
                    //CLOSE DB
                    db.CloseDb();
                    #endregion
                }
            }

            if (retMsg == string.Empty)
                retMsg = "SUCCESS";

            string issueMsg = string.Empty;
            if (string.Compare(retMsg.ToUpper().Trim(), "SUCCESS") == 0)
            {

                // if case package smart pa smart plus have prefix running P75xxxxxx and pa normal package prefix running is Q7xxxx
                if (clsPlanPackage.ContractType.Equals(arrContractSmartPAPlus[0]) || clsPlanPackage.ContractType.Equals(arrContractSmartPAPlus[1]))
                {
                    PolicyNo = this.SetAXAPAPolicyIssue(agentCode, groupBrokerId, clsPlanPackage.PolicyType, planCode, referenceCode, JobNo, prefix[1], out issueMsg);
                }
                else
                {
                    PolicyNo = this.SetAXAPAPolicyIssue(agentCode, groupBrokerId, clsPlanPackage.PolicyType, planCode, referenceCode, JobNo, prefix[0], out issueMsg);
                }

                if (string.Compare(issueMsg.ToUpper().Trim(), "SUCCESS") == 0)
                {
                    retMsg = "SUCCESS";

                    #region ###Process Send E-mail or FTP Document
                    if (isFTP == false)
                    {
                        ObjAXAPAPolicyHolderDetail PolicyHolder = (ObjAXAPAPolicyHolderDetail)policyHolderDetail;
                        string insuredName = PolicyHolder._clientTitle + " " + PolicyHolder._clientName + " " + PolicyHolder._clientSurName;
                        string msgSendMail = string.Empty;

                        //Add Edit PDF Policy
                        DateTime CreateDate = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Now, "SE Asia Standard Time");

                        EditPDFPolicy(PolicyNo, "00", CreateDate);


                        msgSendMail = this.SendMail(PolicyNo, brokerEmail, insuredName);


                        if (string.Compare(msgSendMail.ToUpper().Trim(), "SUCCESS") == 0)
                        {
                            retDeiverDoc = "SUCCESS";
                        }
                    }
                    else
                    {
                        string msgFTP = string.Empty;


                        msgFTP = this.UploadFileToFTP(PolicyNo, ftpServer, ftpUser, ftpPass);


                        if (string.Compare(msgFTP.ToUpper().Trim(), "SUCCESS") == 0)
                        {
                            retDeiverDoc = "SUCCESS";
                        }
                    }

                    #endregion
                }
                else
                {
                    retMsg = issueMsg + " IN SET AXA POLICY ISSUE PROCESS!!!";
                }
            }
            else
            {
                retMsg += " IN SET AXA JOB PROCESS!!!";
            }
        }


        //deliverDocMsg = retDeiverDoc;
        //msg = retMsg;
        //return PolicyNo;
        ObjAXAPAPolicyIssued objPolicyIssue = new ObjAXAPAPolicyIssued();
        objPolicyIssue._msg = retMsg;
        objPolicyIssue._deliverDocMsg = retDeiverDoc;
        objPolicyIssue._policyNo = PolicyNo;

        return objPolicyIssue;
    }

    [WebMethod]//Makkawat Update 20150811
    public bool ReSendAXAPAPolicyIssue(string agentCode, string groupBrokerId, string password, string brokerEmail, string referenceCode)
    {
        try
        {
            bool result = false;
            bool isValidateOK = true;

            string retMsg = String.Empty;
            string msgSendMail = String.Empty;

            #region ###Validate security & authorization into Web Service

            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out retMsg);

            if (isValidateOK == false)
            {
                throw new Exception(retMsg);
            }
            #endregion

            if (isValidateOK == true)
            {
                PAB2CPolicyNoBLL getPolicyNo = new PAB2CPolicyNoBLL();
                DataTable dt = getPolicyNo.spPAB2C_FindPolicyNoByRef(referenceCode);

                List<ObjAXAResendPolicy> policyNoList = new List<ObjAXAResendPolicy>();
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        ObjAXAResendPolicy resendPolicy = new ObjAXAResendPolicy();
                        resendPolicy.jobNo = row["JobNo"].ToString();
                        resendPolicy.policyNo = row["PolicyNo"].ToString();
                        resendPolicy.policyType = row["PolicyType"].ToString();
                        resendPolicy.planId = row["PlanCode"].ToString();

                        policyNoList.Add(resendPolicy);
                    }
                }

                if (policyNoList.Count() > 0)
                {
                    int i = 0;
                    foreach (ObjAXAResendPolicy resendPolicy in policyNoList)
                    {
                        string insuredName = String.Empty;
                        dt = getPolicyNo.spPAB2C_FindPolicyHoldersNameByJobNo(resendPolicy.jobNo);

                        if (dt.Rows.Count > 0)
                        {
                            foreach (DataRow row in dt.Rows)
                            {
                                insuredName = String.Format("{0} {1} {2}", row["ClientTitle"].ToString(), row["ClientName"].ToString(), row["ClientSurName"].ToString());
                            }
                        }

                        //Is have policy find document 
                        string type = "00";//Fix
                        string path = @Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/DOC/") + resendPolicy.policyNo + @"\" + resendPolicy.policyNo + type + @".pdf";

                        if (!System.IO.File.Exists(path))
                        {
                            DataTable DTAble = new DataTable();
                            PATransPoliciesBLL getPrintListReportName = new PATransPoliciesBLL();

                            DTAble = getPrintListReportName.GetPAPrintListReportName(resendPolicy.policyNo);

                            string url = QuickLinkConfiguration.UrlReportingServiceNew + DTAble.Rows[0]["ReportName"].ToString() + "&rs:Format=pdf&rs:command=render&JobNo=" + resendPolicy.jobNo + "&PolicyType=" + resendPolicy.policyType + "&PlanId=" + resendPolicy.planId;
                            this.PrintPAPolicy(url, resendPolicy.policyNo, "00");

                            //Add Edit PDF Policy
                            DateTime CreateDate = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(Convert.ToDateTime(DTAble.Rows[0]["CreateDate"].ToString()), "SE Asia Standard Time");

                            EditPDFPolicy(resendPolicy.policyNo, "00", CreateDate);
                        }
                        //send email
                        msgSendMail = this.SendMail(resendPolicy.policyNo, brokerEmail, insuredName);
                        result = true;
                        i++;
                    }
                }

            }

            return result;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    [WebMethod]//Makkawat Update 20150814
    public bool ReGeneratePolicyIssue(string agentCode, string groupBrokerId, string password, string referenceCode)
    {
        try
        {
            bool result = false;
            bool isValidateOK = true;

            string retMsg = String.Empty;
            string msgSendMail = String.Empty;

            #region ###Validate security & authorization into Web Service

            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out retMsg);

            if (isValidateOK == false)
            {
                throw new Exception(retMsg);
            }
            #endregion

            if (isValidateOK == true)
            {
                PAB2CPolicyNoBLL getPolicyNo = new PAB2CPolicyNoBLL();
                DataTable dt = getPolicyNo.spPAB2C_FindPolicyNoByRef(referenceCode);

                List<ObjAXAResendPolicy> policyNoList = new List<ObjAXAResendPolicy>();
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        ObjAXAResendPolicy resendPolicy = new ObjAXAResendPolicy();
                        resendPolicy.jobNo = row["JobNo"].ToString();
                        resendPolicy.policyNo = row["PolicyNo"].ToString();
                        resendPolicy.policyType = row["PolicyType"].ToString();
                        resendPolicy.planId = row["PlanCode"].ToString();

                        policyNoList.Add(resendPolicy);
                    }
                }

                if (policyNoList.Count() > 0)
                {
                    foreach (ObjAXAResendPolicy resendPolicy in policyNoList)
                    {
                        //Is have policy find document 
                        string type = "00";//Fix
                        string path = @Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/DOC/") + resendPolicy.policyNo + @"\" + resendPolicy.policyNo + type + @".pdf";

                        if (!System.IO.File.Exists(path))
                        {
                            DataTable DTAble = new DataTable();
                            PATransPoliciesBLL getPrintListReportName = new PATransPoliciesBLL();

                            DTAble = getPrintListReportName.GetPAPrintListReportName(resendPolicy.policyNo);

                            string url = QuickLinkConfiguration.UrlReportingServiceNew + DTAble.Rows[0]["ReportName"].ToString() + "&rs:Format=pdf&rs:command=render&JobNo=" + resendPolicy.jobNo + "&PolicyType=" + resendPolicy.policyType + "&PlanId=" + resendPolicy.planId;
                            this.PrintPAPolicy(url, resendPolicy.policyNo, "00");

                            //Add Edit PDF Policy
                            DateTime CreateDate = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(Convert.ToDateTime(DTAble.Rows[0]["CreateDate"].ToString()), "SE Asia Standard Time");

                            EditPDFPolicy(resendPolicy.policyNo, "00", CreateDate);
                        }
                        result = true;
                    }
                }

            }

            return result;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    [WebMethod]//Makkawat Update 20150814
    public ObjAXAPAPolicyIssued GetAXAPAPolicy(string agentCode, string groupBrokerId, string password, string referenceCode)
    {
        try
        {
            bool isValidateOK = true;
            string retMsg = String.Empty;
            ObjAXAPAPolicyIssued objPolicyIssued = null;

            #region ###Validate security & authorization into Web Service

            isValidateOK = AXAWSUsernameAssertion.CheckAXAWSUsernameAssertion(agentCode, groupBrokerId, password, out retMsg);

            if (isValidateOK == false)
            {
                throw new Exception(retMsg);
            }

            #endregion

            if (isValidateOK == true)
            {
                //DbProviderHelper.OpenDb(); // OPEN DB
                PATransPoliciesBLL clstranspolicy = new PATransPoliciesBLL();
                DataTable dt = clstranspolicy.GetPATransPolicyByReturnINV(referenceCode);
                //DbProviderHelper.CloseDb(); // CLOSE DB
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        if (dt.Rows[0]["PolicyNo"] != DBNull.Value)
                        {
                            objPolicyIssued = new ObjAXAPAPolicyIssued();
                            objPolicyIssued._msg = "SUCCESS";
                            objPolicyIssued._deliverDocMsg = "SUCCESS";
                            objPolicyIssued._policyNo = dt.Rows[0]["PolicyNo"].ToString();
                        }
                    }
                }
            }

            return objPolicyIssued;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private string SetAXAPAPolicyIssue(string agentCode, string groupBrokerId, string policyType, string planID, string refInv, string JobNo, string Prefix, out string msg)
    {
        string retMsg = string.Empty;
        string userID = string.Empty;

        string PolicyNo = "";

        try
        {
            if (!string.IsNullOrEmpty(policyType))
                policyType = policyType.ToUpper().Trim();

            #region #-1 GET POLIYNO
            PAB2CPolicyNoBLL getPolicyNo = new PAB2CPolicyNoBLL();
            PolicyNo = getPolicyNo.spPAB2C_SetPolicyNo(JobNo, Prefix);

            #endregion

            #region #-2 UPDATE POLICYNO TO JOBNO

            getPolicyNo.spTAB2C_UpdatePolicyNoToJobNo(JobNo, PolicyNo, refInv);

            #endregion

            #region #-3 SetTransTaxInvoince
            PATransPoliciesBLL tranPolicy = new PATransPoliciesBLL();
            tranPolicy.SetPATransTaxInvoince(PolicyNo, JobNo, agentCode);

            #endregion

            #region #-4 SetTranPrint

            tranPolicy.SetPATransPrint(PolicyNo, JobNo, agentCode, groupBrokerId, agentCode);

            #endregion

            #region #-5 SaveFile

            DataTable DTAble = new DataTable();
            DTAble = tranPolicy.GetPAPrintListReportName(PolicyNo);

            string url = QuickLinkConfiguration.UrlReportingServiceNew + DTAble.Rows[0]["ReportName"].ToString() + "&rs:Format=pdf&rs:command=render&JobNo=" + JobNo + "&PolicyType=" + policyType + "&PlanId=" + planID;
            this.PrintPAPolicy(url, PolicyNo, "00");

            #endregion

        }
        catch (Exception ex)
        {
            retMsg += ex.Message.ToString() + " | ";
        }

        if (retMsg == string.Empty)
            retMsg = "SUCCESS";

        msg = retMsg;

        return PolicyNo;
    }

    private int GetAge(string birthDate)
    {
        int ret = 0;
        if (!birthDate.Trim().Equals(string.Empty))
        {
            DateTime birthday = TA.TAUtilities.CheckCultureAndConvertToDateTime(birthDate.Trim());
            long nyear = TA.TAUtilities.DateDiff(TA.TAUtilities.DateInterval.Year, birthday, TA.TAUtilities.GetEnDateTimeNow());
            long nday = TA.TAUtilities.DateDiff(TA.TAUtilities.DateInterval.Day, birthday, TA.TAUtilities.GetEnDateTimeNow());
            if (nday >= 365)
            {
                ret = (int)nyear;
            }
        }
        return ret;
    }

    private bool IsBirthDayOverLimitOfEffectiveDate(int nminday, int nmaxday, DateTime birthday, DateTime effdatefrom)
    {
        bool ret = false;
        long numOfDays = TA.TAUtilities.DateDiff(TA.TAUtilities.DateInterval.Year, birthday, effdatefrom);
        if (nminday <= numOfDays && numOfDays <= nmaxday)
        {
            ret = false;
        }
        else
        {
            ret = true;
        }
        return ret;
    }

    public void PrintPAPolicy(string url, string policyno, string type)
    {
        string Command = "Render";
        string Format = "PDF";

        System.Net.NetworkCredential Credentials = new System.Net.NetworkCredential();
        Credentials.UserName = "quicklink";
        Credentials.Password = "Password1";
        Credentials.Domain = "bkk.dom";
        //We can get values of these parameters from Request object.

        string URL = url;

        //Specify the path for saving.
        System.IO.DirectoryInfo di = new DirectoryInfo(@Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/DOC/") + policyno);

        if (!di.Exists)
        {
            System.IO.Directory.CreateDirectory(@Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/DOC/") + policyno);

        }

        string path = @Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/DOC/") + policyno + @"\" + policyno + type + @".pdf";


        if (!File.Exists(path))
        {

            System.Net.HttpWebRequest Req = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(URL);
            Req.Credentials = Credentials;
            Req.ContentType = " text/html";


            Req.Method = "GET";


            System.Net.HttpWebResponse objResponse = (System.Net.HttpWebResponse)Req.GetResponse();

            System.IO.FileStream fs = new System.IO.FileStream(path, System.IO.FileMode.Create);

            System.IO.Stream stream = objResponse.GetResponseStream();

            byte[] buf = new byte[1024];

            int len = stream.Read(buf, 0, 1024);

            while (len > 0)
            {

                fs.Write(buf, 0, len);

                len = stream.Read(buf, 0, 1024);

            }

            stream.Close();

            fs.Close();
        }
    }

    private void EditPDFPolicy(string policyno, string type, DateTime createdate)
    {
        Spire.Pdf.PdfDocument pdfDoc = new Spire.Pdf.PdfDocument();
        try
        {
            string path = @Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/DOC/") + policyno + @"\" + policyno + type + @".pdf";
            if (File.Exists(path))
            {
                pdfDoc.LoadFromFile(path);
                if (pdfDoc.Pages.Count == 3)//INDIVIDUAL
                {
                    Spire.Pdf.PdfPageBase page1 = pdfDoc.Pages[1];
                    Spire.Pdf.PdfPageBase page2 = pdfDoc.Pages[0];

                    DrawImageSignature(page1);
                    DrawTextDateSale(page1, createdate);
                    DrawTextTimeSale(page2, createdate);
                }
                else if (pdfDoc.Pages.Count == 4)//FAMILY
                {
                    Spire.Pdf.PdfPageBase page1 = pdfDoc.Pages[2];
                    Spire.Pdf.PdfPageBase page2 = pdfDoc.Pages[0];

                    DrawImageSignature(page1);
                    DrawTextDateSale(page1, createdate);
                    DrawTextTimeSale(page2, createdate);
                }

                pdfDoc.Pages.RemoveAt(pdfDoc.Pages.Count - 1); //Remove Debit Note
                pdfDoc.SaveToFile(path);
                pdfDoc.Close();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            pdfDoc.Dispose();
        }
    }

    private void DrawImageSignature(Spire.Pdf.PdfPageBase page)
    {
        string signature = @Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/Signature/") + "signature.png";
        Spire.Pdf.Graphics.PdfImage image = Spire.Pdf.Graphics.PdfImage.FromFile(signature);
        float width = image.Width * 0.75f;
        float height = image.Height * 0.75f;
        float x = (page.Canvas.ClientSize.Width - width) / 2;

        page.Canvas.DrawImage(image, 370, 510, width, height);
    }

    private void DrawTextDateSale(Spire.Pdf.PdfPageBase page, DateTime dateTime)
    {
        Spire.Pdf.Graphics.PdfImage image = Spire.Pdf.Graphics.PdfImage.FromImage(DrawText(dateTime.ToString("dd/MM/yyyy  ", new System.Globalization.CultureInfo("en-us")), new System.Drawing.Font("Arial", 14), System.Drawing.Color.Black, System.Drawing.Color.White));
        float width = image.Width * 0.4f;
        float height = image.Height * 0.4f;

        page.Canvas.DrawImage(image, 490, 230, width, height);
    }

    private void DrawTextTimeSale(Spire.Pdf.PdfPageBase page, DateTime dateTime)
    {
        Spire.Pdf.Graphics.PdfImage image = Spire.Pdf.Graphics.PdfImage.FromImage(DrawText(dateTime.ToString("  HH:mm  ", new System.Globalization.CultureInfo("en-us")), new System.Drawing.Font("Arial", 14), System.Drawing.Color.Black, System.Drawing.Color.White));
        float width = image.Width * 0.4f;
        float height = image.Height * 0.4f;

        page.Canvas.DrawImage(image, 275, 305, width, height);
    }

    private System.Drawing.Bitmap DrawText(String text, System.Drawing.Font font, System.Drawing.Color textColor, System.Drawing.Color backColor)
    {
        //first, create a dummy bitmap just to get a graphics object
        System.Drawing.Bitmap img = new System.Drawing.Bitmap(1, 1);
        System.Drawing.Graphics drawing = System.Drawing.Graphics.FromImage(img);

        //measure the string to see how big the image needs to be
        System.Drawing.SizeF textSize = drawing.MeasureString(text, font);

        //free up the dummy image and old graphics object
        img.Dispose();
        drawing.Dispose();

        //create a new image of the right size
        img = new System.Drawing.Bitmap((int)textSize.Width, (int)textSize.Height);

        drawing = System.Drawing.Graphics.FromImage(img);

        //paint the background
        drawing.Clear(backColor);

        //create a brush for the text
        System.Drawing.Brush textBrush = new System.Drawing.SolidBrush(textColor);

        drawing.DrawString(text, font, textBrush, 0, 0);

        drawing.Save();

        textBrush.Dispose();
        drawing.Dispose();

        return img;

    }

    private string SendMail(string PolicyNo, string brokerEmail, string insuredName)
    {
        string retMsg = string.Empty;
        string emailFrom = (PolicyNo.StartsWith("P")) ? "axathai@axa.co.th" : "RNMB-Direct@axa.co.th"; // if pacakge normal PA prefix is Q7xxxxxxx  and PA smart pa plus is P75xxxxx
        string emailTo = brokerEmail;
        string subject = "Confirmation of Personal Accident Insurance Schedule";

        string emailPath = Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + String.Format("/Email/{0}.html", (PolicyNo.StartsWith("P")) ? "SmartPersonalAccident" : "PersonalAccident")); // if pacakge normal PA prefix is Q7xxxxxxx  and PA smart pa plus is P75xxxxx
        string body = System.IO.File.ReadAllText(emailPath);
        //body = String.Format(body, insuredName, PolicyNo);
        body = body.Replace("[SendName]", insuredName);
        body = body.Replace("[Policy]", PolicyNo);

        #region Email
        //string body = "เรียน ท่านนายหน้า/ผู้ออกกรมธรรม์<br/><br/>";
        //body += "<p>บริษัท แอกซ่าประกันภัย จำกัด (มหาชน) ขอขอบคุณที่ท่านไว้วางใจให้บริษัทเป็นผู้ให้ความคุ้มครองแก่ลูกค้าของท่าน</p><br/><br/>";
        //body += "<p>บริษัทฯ ขอเรียนให้ท่านทราบว่ากรมธรรม์คุณ " + insuredName + "ได้รับความคุ้มครองแล้ว กรมธรรม์เลขที่ " + PolicyNo + " ท่านสามารถพิมพ์กรมธรรม์ และเอกสารต่าง ๆ ที่แนบมากับอีเมล์ฉบับนี้ พร้อมกับแนบเอกสารเงื่อนไขความคุ้มครอง เพื่อจัดส่งให้กับลูกค้าของท่านต่อไป</p><br/>";
        //body += "<p>เอกสารที่ลูกค้าจะได้รับประกอบด้วย</p>";
        //body += "<ol>";
        //body += "<li>หน้าตารางกรมธรรม์</li>";
        //body += "<li>ใบแจ้งหนี้ หรือใบกำกับภาษี</li>";
        //body += "<li>เอกสารแนบกรมธรรม์ที่ระบุเงื่อนไขการความคุ้มครองโดยละเอียด</li>";
        //body += "<li>ซองใส่กรมธรรม์</li>";
        //body += "<li> ใบเสร็จรับเงิน (มอบให้กับลูกค้าเมื่อชำระเงินแล้ว พร้อมกับลงชื่อผู้รับเงิน)</li>";
        //body += "</ol><br/>";

        //body += "<p>บริษัทฯ มีความเชื่อมั่นว่า ท่านได้อธิบายเงื่อนไขความคุ้มครอง และประโยชน์ต่าง ๆ เกี่ยวกับกรมธรรม์ฉบับนี้ให้กับลูกค้าของท่านทราบก่อนตกลงทำประกันภัยแล้ว </p><br/>";

        //body += "<p>เพื่อเป็นการรักษาประโยชน์สูงสุดให้กับลูกค้าของท่าน ขอให้ท่านอธิบายเงื่อนความคุ้มครอง และประโยชน์ต่าง ๆ ที่ลูกค้าพึงจะได้รับโดยละเอียดอีกครั้งขณะนำกรมธรรม์ไปมอบให้ </p><br/>";

        //body += "<p>ทั้งนี้ หากท่านมีข้อสงสัยประการใด สามารถติดต่อสอบถามกับเจ้าหน้าที่รับประกันภัยที่ดูแลท่านตลอดเวลาทำการ  </p><br/>";

        //body += "<p>ขอแสดงความนับถือบริษัท<br/>แอกซ่าประกันภัย จำกัด (มหาชน)<br/>โทร. 02-118-8000</p>";
        //body += "<p>บริการช่วยเหลือฉุกเฉิน 24 ชั่วโมง<br/>แอกซ่า ฮอตไลน์<br/>โทร. 02-642-6688, 02-206-5488<br/>เว็บไซด์ : <a href='http://www.axa.co.th' target='_blank'>www.axa.co.th</a></p>";
        #endregion

        try
        {
            //string url = "";
            string type = "00";

            string path = path = Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/DOC/" + PolicyNo);

            string filePath = path + "\\" + PolicyNo + type + ".pdf";

            Utilities.SendMail(emailFrom, emailTo, subject, body, true, filePath);

            retMsg = "SUCCESS";

            //Response.End();
        }
        catch (Exception ex)
        {
            Utilities.LogError(ex);
            retMsg = ex.Message.ToString();
        }

        return retMsg;
    }

    private string UploadFileToFTP(string PolicyNo, string _UploadPath, string _FTPUser, string _FTPPass)
    {
        string retMsg = string.Empty;

        try
        {
            string type = "00";
            string path = path = Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/DOC/" + PolicyNo);
            string filename = PolicyNo + type + ".pdf";
            string filePath = path + "\\" + filename;

            FileStream stream = File.OpenRead(filePath);
            byte[] myData = new Byte[stream.Length];
            stream.Read(myData, 0, myData.Length);
            stream.Close();

            string ftpfullpath = _UploadPath + filename;
            FtpWebRequest ftp = (FtpWebRequest)FtpWebRequest.Create(ftpfullpath);
            ftp.Credentials = new NetworkCredential(_FTPUser, _FTPPass);

            ftp.KeepAlive = true;
            ftp.UseBinary = true;
            ftp.Timeout = 20000; // 20 sec
            ftp.Method = WebRequestMethods.Ftp.UploadFile;

            //FileStream fs = File.OpenRead(_FileName);
            //byte[] buffer = new byte[fs.Length];
            //fs.Read(buffer, 0, buffer.Length);
            //fs.Close();

            Stream ftpstream = ftp.GetRequestStream();
            ftpstream.Write(myData, 0, myData.Length);
            ftpstream.Close();

            retMsg = "SUCCESS";
        }
        catch (Exception ex)
        {
            Utilities.LogError(ex);
            retMsg = ex.Message.ToString();
        }

        return retMsg;
    }

}
