﻿using System;
using System.Configuration;

/// <summary>
/// Summary description for PAConfiguration is 
/// Get data from web.config of this project to using at the module travel.
/// </summary>

namespace PA
{
    public static class PAConfiguration
    {
        private readonly static string siteName;
        private readonly static string dbConnectionString;
        private readonly static string dbProviderName;

        // class constuctor
        static PAConfiguration()
        {
            //
            // TODO: Add constructor logic here
            //
            siteName = ConfigurationManager.AppSettings["SiteName"];
            dbConnectionString = ConfigurationManager.ConnectionStrings["PADBConnectionString"].ConnectionString;
            dbProviderName = ConfigurationManager.ConnectionStrings["PADBConnectionString"].ProviderName;
        }

        // Return site string name
        public static string SiteName
        {
            get
            {
                return siteName;
            }
        }

        // Return connection string name
        public static string DbConnectionString
        {
            get
            {
                return dbConnectionString;
            }
        }

        // Returns the data provider name
        public static string DbProviderName
        {
            get
            {
                return dbProviderName;
            }
        }
    }
}