using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;

namespace PA.DAL
{
    /// <summary>
    /// 
    /// </summary>
    /// <lastupdate>2012-08-24</lastupdate>
	public class PAGetDDLTableDAO
	{
        DbProviderHelper db;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <lastupdate>2012-08-24</lastupdate>
        public PAGetDDLTableDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
        }

        /// <summary>
        /// GET
        /// </summary>
        /// <param name="LANG"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-24</lastupdate>
        public DataTable GetDDLGender(string LANG)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand comm = db.CreateCommand("spPA_getDDLGender", CommandType.StoredProcedure);
                comm.Parameters.Add(db.CreateParameter("@LANG", DbType.String, LANG));
                              
                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return db.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// GET
        /// </summary>
        /// <param name="LANG"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-24</lastupdate>
        public DataTable GetDDLMarried(string LANG)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand comm = db.CreateCommand("spPA_getDDLMarried", CommandType.StoredProcedure);
                comm.Parameters.Add(db.CreateParameter("@LANG", DbType.String, LANG));
                
                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return db.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// GET
        /// </summary>
        /// <param name="LANG"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-24</lastupdate>
        public DataTable GetDDLNationality(string LANG)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand comm = db.CreateCommand("spPA_getDDLNationality", CommandType.StoredProcedure);
                comm.Parameters.Add(db.CreateParameter("@LANG", DbType.String, LANG));

                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return db.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// GET
        /// </summary>
        /// <param name="PACKAGEID"></param>
        /// <param name="LANG"></param>
        /// <returns></returns>
        /// <lastupdate>2015-07-16</lastupdate>
        public DataTable GetDDLPackageByPackageID(string PACKAGEID, string LANG)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand comm = db.CreateCommand("spPA_getDDLPackageByPackageID", CommandType.StoredProcedure);
                comm.Parameters.Add(db.CreateParameter("@PACKAGEID", DbType.String, PACKAGEID));
                comm.Parameters.Add(db.CreateParameter("@LANG", DbType.String, LANG));

                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return db.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// GET
        /// </summary>
        /// <param name="AGE"></param>
        /// <param name="LANG"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-24</lastupdate>
        public DataTable GetDDLPackage(int AGE,string LANG)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand comm = db.CreateCommand("spPA_getDDLPackage", CommandType.StoredProcedure);
                comm.Parameters.Add(db.CreateParameter("@AGE", DbType.Int32, AGE));
                comm.Parameters.Add(db.CreateParameter("@LANG", DbType.String, LANG));

                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return db.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// GET
        /// </summary>
        /// <param name="PackageID"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-24</lastupdate>
        public DataTable GetDDLPlan(string PackageID, string lang, string occupationClass)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand comm = db.CreateCommand("spPA_getDDLPlan", CommandType.StoredProcedure);
                comm.Parameters.Add(db.CreateParameter("@PackageID", DbType.String, PackageID));
                comm.Parameters.Add(db.CreateParameter("@Lang", DbType.String, lang));
                comm.Parameters.Add(db.CreateParameter("@OccupationClass", DbType.String, occupationClass));

                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return db.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// GET
        /// </summary>
        /// <param name="LANG"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-24</lastupdate>
        public DataTable GetDDLRelation(string LANG)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand comm = db.CreateCommand("spPA_getDDLRelation", CommandType.StoredProcedure);
                comm.Parameters.Add(db.CreateParameter("@Lang", DbType.String, LANG));

                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return db.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// GET
        /// </summary>
        /// <param name="LANG"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-24</lastupdate>
        public DataTable GetDDLTitle(string LANG)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand comm = db.CreateCommand("spPA_getDDLTitle", CommandType.StoredProcedure);
                comm.Parameters.Add(db.CreateParameter("@LANG", DbType.String, LANG));

                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return db.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// GET
        /// </summary>
        /// <param name="LANG"></param>
        /// <returns></returns>
        /// <lastupdate>2014-07-24</lastupdate>
        public DataTable GetDDLPAOccupation(string LANG)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand comm = db.CreateCommand("spPA_getDDLPAOccupation", CommandType.StoredProcedure);
                comm.Parameters.Add(db.CreateParameter("@LANG", DbType.String, LANG));

                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return db.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
	}
}
