using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;

namespace PA.DAL
{
	public class PAPlanPackagesDAO
	{
        DbProviderHelper db;

		public PAPlanPackagesDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
        }
		
		public PAPlanPackages GetPAPlanPackages(string PackageID)
		{
            //DbProviderHelper dbHelper = new DbProviderHelper();
            DbDataReader oDbDataReader = null;
            try
			{
				PAPlanPackages oPAPlanPackages = new PAPlanPackages();
                DbCommand oDbCommand = db.CreateCommand("spPA_getPlanPackages", CommandType.StoredProcedure);
                oDbCommand.Parameters.Add(db.CreateParameter("@PackageID", DbType.String, PackageID));
                oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oPAPlanPackages.PackageID = Convert.ToString(oDbDataReader["PackageID"]);

					if(oDbDataReader["PackageNameTH"] != DBNull.Value)
						oPAPlanPackages.PackageNameTH = Convert.ToString(oDbDataReader["PackageNameTH"]);

					if(oDbDataReader["PackageNameEN"] != DBNull.Value)
						oPAPlanPackages.PackageNameEN = Convert.ToString(oDbDataReader["PackageNameEN"]);

                    if (oDbDataReader["PolicyType"] != DBNull.Value)
                        oPAPlanPackages.PolicyType = Convert.ToString(oDbDataReader["PolicyType"]);

					if(oDbDataReader["ContractType"] != DBNull.Value)
						oPAPlanPackages.ContractType = Convert.ToString(oDbDataReader["ContractType"]);

					if(oDbDataReader["RiskType"] != DBNull.Value)
						oPAPlanPackages.RiskType = Convert.ToString(oDbDataReader["RiskType"]);

					if(oDbDataReader["PremiumClass"] != DBNull.Value)
						oPAPlanPackages.PremiumClass = Convert.ToString(oDbDataReader["PremiumClass"]);

					if(oDbDataReader["AgeOfInsurerFrom"] != DBNull.Value)
						oPAPlanPackages.AgeOfInsurerFrom = Convert.ToInt32(oDbDataReader["AgeOfInsurerFrom"]);

					if(oDbDataReader["AgeOfInsurerTo"] != DBNull.Value)
						oPAPlanPackages.AgeOfInsurerTo = Convert.ToInt32(oDbDataReader["AgeOfInsurerTo"]);

					if(oDbDataReader["AgeOfChildrenFrom"] != DBNull.Value)
						oPAPlanPackages.AgeOfChildrenFrom = Convert.ToInt32(oDbDataReader["AgeOfChildrenFrom"]);

					if(oDbDataReader["AgeOfChildrenTo"] != DBNull.Value)
						oPAPlanPackages.AgeOfChildrenTo = Convert.ToInt32(oDbDataReader["AgeOfChildrenTo"]);

					if(oDbDataReader["isEnable"] != DBNull.Value)
						oPAPlanPackages.isEnable = Convert.ToSByte(oDbDataReader["isEnable"]);

					if(oDbDataReader["CreatedDate"] != DBNull.Value)
						oPAPlanPackages.CreatedDate = Convert.ToDateTime(oDbDataReader["CreatedDate"]);
				}
				oDbDataReader.Close();
				return oPAPlanPackages;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}

	}
}
