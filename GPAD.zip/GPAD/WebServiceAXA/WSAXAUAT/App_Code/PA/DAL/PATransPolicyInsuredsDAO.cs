using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;

namespace PA.DAL
{
    /// <summary>
    /// 
    /// </summary>
    /// <lastupdate>2012-08-26</lastupdate>
	public class PATransPolicyInsuredsDAO
	{
        DbProviderHelper db;

		public PATransPolicyInsuredsDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}
		public List<PATransPolicyInsureds> GetPATransPolicyInsuredss()
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<PATransPolicyInsureds> lstPATransPolicyInsuredss = new List<PATransPolicyInsureds>();
                //DbProviderHelper dbHelper = new DbProviderHelper();
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					PATransPolicyInsureds oPATransPolicyInsureds = new PATransPolicyInsureds();
					oPATransPolicyInsureds.JobNo = Convert.ToString(oDbDataReader["JobNo"]);
					oPATransPolicyInsureds.InsuredID = Convert.ToInt32(oDbDataReader["InsuredID"]);

					if(oDbDataReader["ClientCode"] != DBNull.Value)
						oPATransPolicyInsureds.ClientCode = Convert.ToString(oDbDataReader["ClientCode"]);

					if(oDbDataReader["ClientTitle"] != DBNull.Value)
						oPATransPolicyInsureds.ClientTitle = Convert.ToString(oDbDataReader["ClientTitle"]);

					if(oDbDataReader["ClientName"] != DBNull.Value)
						oPATransPolicyInsureds.ClientName = Convert.ToString(oDbDataReader["ClientName"]);

					if(oDbDataReader["ClientSurName"] != DBNull.Value)
						oPATransPolicyInsureds.ClientSurName = Convert.ToString(oDbDataReader["ClientSurName"]);

					if(oDbDataReader["Birthday"] != DBNull.Value)
						oPATransPolicyInsureds.Birthday = Convert.ToString(oDbDataReader["Birthday"]);

					if(oDbDataReader["IDCard"] != DBNull.Value)
						oPATransPolicyInsureds.IDCard = Convert.ToString(oDbDataReader["IDCard"]);

					if(oDbDataReader["PassportID"] != DBNull.Value)
						oPATransPolicyInsureds.PassportID = Convert.ToString(oDbDataReader["PassportID"]);

					if(oDbDataReader["Tel"] != DBNull.Value)
						oPATransPolicyInsureds.Tel = Convert.ToString(oDbDataReader["Tel"]);

					if(oDbDataReader["SumInsuredPA2"] != DBNull.Value)
						oPATransPolicyInsureds.SumInsuredPA2 = Convert.ToInt32(oDbDataReader["SumInsuredPA2"]);

					if(oDbDataReader["SumInsuredME"] != DBNull.Value)
						oPATransPolicyInsureds.SumInsuredME = Convert.ToInt32(oDbDataReader["SumInsuredME"]);

					if(oDbDataReader["PremiumPA2"] != DBNull.Value)
						oPATransPolicyInsureds.PremiumPA2 = Convert.ToInt32(oDbDataReader["PremiumPA2"]);

					if(oDbDataReader["PremiumME"] != DBNull.Value)
						oPATransPolicyInsureds.PremiumME = Convert.ToInt32(oDbDataReader["PremiumME"]);

					if(oDbDataReader["AddPremium"] != DBNull.Value)
						oPATransPolicyInsureds.AddPremium = Convert.ToInt32(oDbDataReader["AddPremium"]);

					if(oDbDataReader["GrossPremium"] != DBNull.Value)
						oPATransPolicyInsureds.GrossPremium = Convert.ToInt32(oDbDataReader["GrossPremium"]);

					if(oDbDataReader["Stamp"] != DBNull.Value)
						oPATransPolicyInsureds.Stamp = Convert.ToInt32(oDbDataReader["Stamp"]);

					if(oDbDataReader["SBT"] != DBNull.Value)
						oPATransPolicyInsureds.SBT = Convert.ToInt32(oDbDataReader["SBT"]);

					if(oDbDataReader["TotalPremium"] != DBNull.Value)
						oPATransPolicyInsureds.TotalPremium = Convert.ToInt32(oDbDataReader["TotalPremium"]);

					if(oDbDataReader["isBeneficiary"] != DBNull.Value)
						oPATransPolicyInsureds.isBeneficiary = Convert.ToSByte(oDbDataReader["isBeneficiary"]);

					if(oDbDataReader["isStudent"] != DBNull.Value)
						oPATransPolicyInsureds.isStudent = Convert.ToSByte(oDbDataReader["isStudent"]);

					if(oDbDataReader["isSingle"] != DBNull.Value)
						oPATransPolicyInsureds.isSingle = Convert.ToSByte(oDbDataReader["isSingle"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oPATransPolicyInsureds.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);

					if(oDbDataReader["Message"] != DBNull.Value)
						oPATransPolicyInsureds.Message = Convert.ToString(oDbDataReader["Message"]);
					lstPATransPolicyInsuredss.Add(oPATransPolicyInsureds);
				}
				oDbDataReader.Close();
				return lstPATransPolicyInsuredss;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}
		public PATransPolicyInsureds GetPATransPolicyInsureds(string JobNo,int InsuredID)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				PATransPolicyInsureds oPATransPolicyInsureds = new PATransPolicyInsureds();
                //DbProviderHelper dbHelper = new DbProviderHelper();
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
				oDbCommand.Parameters.Add(db.CreateParameter("@JobNo",DbType.String,JobNo));
				oDbCommand.Parameters.Add(db.CreateParameter("@InsuredID",DbType.Int32,InsuredID));
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oPATransPolicyInsureds.JobNo = Convert.ToString(oDbDataReader["JobNo"]);
					oPATransPolicyInsureds.InsuredID = Convert.ToInt32(oDbDataReader["InsuredID"]);

					if(oDbDataReader["ClientCode"] != DBNull.Value)
						oPATransPolicyInsureds.ClientCode = Convert.ToString(oDbDataReader["ClientCode"]);

					if(oDbDataReader["ClientTitle"] != DBNull.Value)
						oPATransPolicyInsureds.ClientTitle = Convert.ToString(oDbDataReader["ClientTitle"]);

					if(oDbDataReader["ClientName"] != DBNull.Value)
						oPATransPolicyInsureds.ClientName = Convert.ToString(oDbDataReader["ClientName"]);

					if(oDbDataReader["ClientSurName"] != DBNull.Value)
						oPATransPolicyInsureds.ClientSurName = Convert.ToString(oDbDataReader["ClientSurName"]);

					if(oDbDataReader["Birthday"] != DBNull.Value)
						oPATransPolicyInsureds.Birthday = Convert.ToString(oDbDataReader["Birthday"]);

					if(oDbDataReader["IDCard"] != DBNull.Value)
						oPATransPolicyInsureds.IDCard = Convert.ToString(oDbDataReader["IDCard"]);

					if(oDbDataReader["PassportID"] != DBNull.Value)
						oPATransPolicyInsureds.PassportID = Convert.ToString(oDbDataReader["PassportID"]);

					if(oDbDataReader["Tel"] != DBNull.Value)
						oPATransPolicyInsureds.Tel = Convert.ToString(oDbDataReader["Tel"]);

					if(oDbDataReader["SumInsuredPA2"] != DBNull.Value)
						oPATransPolicyInsureds.SumInsuredPA2 = Convert.ToInt32(oDbDataReader["SumInsuredPA2"]);

					if(oDbDataReader["SumInsuredME"] != DBNull.Value)
						oPATransPolicyInsureds.SumInsuredME = Convert.ToInt32(oDbDataReader["SumInsuredME"]);

					if(oDbDataReader["PremiumPA2"] != DBNull.Value)
						oPATransPolicyInsureds.PremiumPA2 = Convert.ToInt32(oDbDataReader["PremiumPA2"]);

					if(oDbDataReader["PremiumME"] != DBNull.Value)
						oPATransPolicyInsureds.PremiumME = Convert.ToInt32(oDbDataReader["PremiumME"]);

					if(oDbDataReader["AddPremium"] != DBNull.Value)
						oPATransPolicyInsureds.AddPremium = Convert.ToInt32(oDbDataReader["AddPremium"]);

					if(oDbDataReader["GrossPremium"] != DBNull.Value)
						oPATransPolicyInsureds.GrossPremium = Convert.ToInt32(oDbDataReader["GrossPremium"]);

					if(oDbDataReader["Stamp"] != DBNull.Value)
						oPATransPolicyInsureds.Stamp = Convert.ToInt32(oDbDataReader["Stamp"]);

					if(oDbDataReader["SBT"] != DBNull.Value)
						oPATransPolicyInsureds.SBT = Convert.ToInt32(oDbDataReader["SBT"]);

					if(oDbDataReader["TotalPremium"] != DBNull.Value)
						oPATransPolicyInsureds.TotalPremium = Convert.ToInt32(oDbDataReader["TotalPremium"]);

					if(oDbDataReader["isBeneficiary"] != DBNull.Value)
						oPATransPolicyInsureds.isBeneficiary = Convert.ToSByte(oDbDataReader["isBeneficiary"]);

					if(oDbDataReader["isStudent"] != DBNull.Value)
						oPATransPolicyInsureds.isStudent = Convert.ToSByte(oDbDataReader["isStudent"]);

					if(oDbDataReader["isSingle"] != DBNull.Value)
						oPATransPolicyInsureds.isSingle = Convert.ToSByte(oDbDataReader["isSingle"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oPATransPolicyInsureds.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);

					if(oDbDataReader["Message"] != DBNull.Value)
						oPATransPolicyInsureds.Message = Convert.ToString(oDbDataReader["Message"]);
				}
				oDbDataReader.Close();
				return oPATransPolicyInsureds;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}
		public int AddPATransPolicyInsureds(string JobNo,int InsuredID,string ClientCode,string ClientTitle,string ClientName,string ClientSurName,string Birthday,string IDCard,string PassportID,string Tel,Nullable<int> SumInsuredPA2,Nullable<int> SumInsuredME,Nullable<int> PremiumPA2,Nullable<int> PremiumME,Nullable<int> AddPremium,Nullable<int> GrossPremium,Nullable<int> Stamp,Nullable<int> SBT,Nullable<int> TotalPremium,Nullable<SByte> isBeneficiary,Nullable<SByte> isStudent,Nullable<SByte> isSingle,Nullable<DateTime> CreateDate,string Message)
		{
			try
			{
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);                
				if (ClientCode!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientCode",DbType.String,ClientCode));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientCode",DbType.String,DBNull.Value));
				if (ClientTitle!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle",DbType.String,ClientTitle));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle",DbType.String,DBNull.Value));
				if (ClientName!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientName",DbType.String,ClientName));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientName",DbType.String,DBNull.Value));
				if (ClientSurName!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName",DbType.String,ClientSurName));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName",DbType.String,DBNull.Value));
				if (Birthday!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Birthday",DbType.String,Birthday));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Birthday",DbType.String,DBNull.Value));
				if (IDCard!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@IDCard",DbType.String,IDCard));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@IDCard",DbType.String,DBNull.Value));
				if (PassportID!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@PassportID",DbType.String,PassportID));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@PassportID",DbType.String,DBNull.Value));
				if (Tel!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Tel",DbType.String,Tel));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Tel",DbType.String,DBNull.Value));
				if (SumInsuredPA2.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@SumInsuredPA2",DbType.Int32,SumInsuredPA2));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@SumInsuredPA2",DbType.Int32,DBNull.Value));
				if (SumInsuredME.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@SumInsuredME",DbType.Int32,SumInsuredME));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@SumInsuredME",DbType.Int32,DBNull.Value));
				if (PremiumPA2.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@PremiumPA2",DbType.Int32,PremiumPA2));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@PremiumPA2",DbType.Int32,DBNull.Value));
				if (PremiumME.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@PremiumME",DbType.Int32,PremiumME));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@PremiumME",DbType.Int32,DBNull.Value));
				if (AddPremium.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@AddPremium",DbType.Int32,AddPremium));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@AddPremium",DbType.Int32,DBNull.Value));
				if (GrossPremium.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@GrossPremium",DbType.Int32,GrossPremium));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@GrossPremium",DbType.Int32,DBNull.Value));
				if (Stamp.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@Stamp",DbType.Int32,Stamp));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Stamp",DbType.Int32,DBNull.Value));
				if (SBT.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@SBT",DbType.Int32,SBT));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@SBT",DbType.Int32,DBNull.Value));
				if (TotalPremium.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@TotalPremium",DbType.Int32,TotalPremium));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@TotalPremium",DbType.Int32,DBNull.Value));
				if (isBeneficiary.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@isBeneficiary",DbType.SByte,isBeneficiary));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@isBeneficiary",DbType.SByte,DBNull.Value));
				if (isStudent.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@isStudent",DbType.SByte,isStudent));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@isStudent",DbType.SByte,DBNull.Value));
				if (isSingle.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@isSingle",DbType.SByte,isSingle));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@isSingle",DbType.SByte,DBNull.Value));
				if (CreateDate.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@CreateDate",DbType.DateTime,CreateDate));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@CreateDate",DbType.DateTime,DBNull.Value));
				if (Message!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Message",DbType.String,Message));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Message",DbType.String,DBNull.Value));

				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public int UpdatePATransPolicyInsureds(string JobNo,int InsuredID,string ClientCode,string ClientTitle,string ClientName,string ClientSurName,string Birthday,string IDCard,string PassportID,string Tel,Nullable<int> SumInsuredPA2,Nullable<int> SumInsuredME,Nullable<int> PremiumPA2,Nullable<int> PremiumME,Nullable<int> AddPremium,Nullable<int> GrossPremium,Nullable<int> Stamp,Nullable<int> SBT,Nullable<int> TotalPremium,Nullable<SByte> isBeneficiary,Nullable<SByte> isStudent,Nullable<SByte> isSingle,Nullable<DateTime> CreateDate,string Message)
		{

			try
			{
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);                
				if (ClientCode!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientCode",DbType.String,ClientCode));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientCode",DbType.String,DBNull.Value));
				if (ClientTitle!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle",DbType.String,ClientTitle));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle",DbType.String,DBNull.Value));
				if (ClientName!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientName",DbType.String,ClientName));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientName",DbType.String,DBNull.Value));
				if (ClientSurName!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName",DbType.String,ClientSurName));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName",DbType.String,DBNull.Value));
				if (Birthday!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Birthday",DbType.String,Birthday));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Birthday",DbType.String,DBNull.Value));
				if (IDCard!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@IDCard",DbType.String,IDCard));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@IDCard",DbType.String,DBNull.Value));
				if (PassportID!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@PassportID",DbType.String,PassportID));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@PassportID",DbType.String,DBNull.Value));
				if (Tel!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Tel",DbType.String,Tel));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Tel",DbType.String,DBNull.Value));
				if (SumInsuredPA2.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@SumInsuredPA2",DbType.Int32,SumInsuredPA2));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@SumInsuredPA2",DbType.Int32,DBNull.Value));
				if (SumInsuredME.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@SumInsuredME",DbType.Int32,SumInsuredME));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@SumInsuredME",DbType.Int32,DBNull.Value));
				if (PremiumPA2.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@PremiumPA2",DbType.Int32,PremiumPA2));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@PremiumPA2",DbType.Int32,DBNull.Value));
				if (PremiumME.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@PremiumME",DbType.Int32,PremiumME));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@PremiumME",DbType.Int32,DBNull.Value));
				if (AddPremium.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@AddPremium",DbType.Int32,AddPremium));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@AddPremium",DbType.Int32,DBNull.Value));
				if (GrossPremium.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@GrossPremium",DbType.Int32,GrossPremium));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@GrossPremium",DbType.Int32,DBNull.Value));
				if (Stamp.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@Stamp",DbType.Int32,Stamp));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Stamp",DbType.Int32,DBNull.Value));
				if (SBT.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@SBT",DbType.Int32,SBT));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@SBT",DbType.Int32,DBNull.Value));
				if (TotalPremium.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@TotalPremium",DbType.Int32,TotalPremium));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@TotalPremium",DbType.Int32,DBNull.Value));
				if (isBeneficiary.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@isBeneficiary",DbType.SByte,isBeneficiary));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@isBeneficiary",DbType.SByte,DBNull.Value));
				if (isStudent.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@isStudent",DbType.SByte,isStudent));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@isStudent",DbType.SByte,DBNull.Value));
				if (isSingle.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@isSingle",DbType.SByte,isSingle));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@isSingle",DbType.SByte,DBNull.Value));
				if (CreateDate.HasValue)
					oDbCommand.Parameters.Add(db.CreateParameter("@CreateDate",DbType.DateTime,CreateDate));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@CreateDate",DbType.DateTime,DBNull.Value));
				if (Message!=null)
					oDbCommand.Parameters.Add(db.CreateParameter("@Message",DbType.String,Message));
				else
					oDbCommand.Parameters.Add(db.CreateParameter("@Message",DbType.String,DBNull.Value));
				oDbCommand.Parameters.Add(db.CreateParameter("@JobNo",DbType.String,JobNo));
				oDbCommand.Parameters.Add(db.CreateParameter("@InsuredID",DbType.Int32,InsuredID));
				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public int RemovePATransPolicyInsureds(string JobNo,int InsuredID)
		{

			try
			{
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);                
				oDbCommand.Parameters.Add(db.CreateParameter("@JobNo",DbType.String,JobNo));
				oDbCommand.Parameters.Add(db.CreateParameter("@InsuredID",DbType.Int32,InsuredID));
				return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public List<PATransPolicyInsureds> GetPATransPolicyInsuredssOfPATransPolicyHolders(string JobNo)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<PATransPolicyInsureds> lstPATransPolicyInsuredss = new List<PATransPolicyInsureds>();
                //DbProviderHelper dbHelper = new DbProviderHelper();
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
				oDbCommand.Parameters.Add(db.CreateParameter("@JobNo",DbType.String,JobNo));
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					PATransPolicyInsureds oPATransPolicyInsureds = new PATransPolicyInsureds();
					oPATransPolicyInsureds.JobNo = Convert.ToString(oDbDataReader["JobNo"]);
					oPATransPolicyInsureds.InsuredID = Convert.ToInt32(oDbDataReader["InsuredID"]);

					if(oDbDataReader["ClientCode"] != DBNull.Value)
						oPATransPolicyInsureds.ClientCode = Convert.ToString(oDbDataReader["ClientCode"]);

					if(oDbDataReader["ClientTitle"] != DBNull.Value)
						oPATransPolicyInsureds.ClientTitle = Convert.ToString(oDbDataReader["ClientTitle"]);

					if(oDbDataReader["ClientName"] != DBNull.Value)
						oPATransPolicyInsureds.ClientName = Convert.ToString(oDbDataReader["ClientName"]);

					if(oDbDataReader["ClientSurName"] != DBNull.Value)
						oPATransPolicyInsureds.ClientSurName = Convert.ToString(oDbDataReader["ClientSurName"]);

					if(oDbDataReader["Birthday"] != DBNull.Value)
						oPATransPolicyInsureds.Birthday = Convert.ToString(oDbDataReader["Birthday"]);

					if(oDbDataReader["IDCard"] != DBNull.Value)
						oPATransPolicyInsureds.IDCard = Convert.ToString(oDbDataReader["IDCard"]);

					if(oDbDataReader["PassportID"] != DBNull.Value)
						oPATransPolicyInsureds.PassportID = Convert.ToString(oDbDataReader["PassportID"]);

					if(oDbDataReader["Tel"] != DBNull.Value)
						oPATransPolicyInsureds.Tel = Convert.ToString(oDbDataReader["Tel"]);

					if(oDbDataReader["SumInsuredPA2"] != DBNull.Value)
						oPATransPolicyInsureds.SumInsuredPA2 = Convert.ToInt32(oDbDataReader["SumInsuredPA2"]);

					if(oDbDataReader["SumInsuredME"] != DBNull.Value)
						oPATransPolicyInsureds.SumInsuredME = Convert.ToInt32(oDbDataReader["SumInsuredME"]);

					if(oDbDataReader["PremiumPA2"] != DBNull.Value)
						oPATransPolicyInsureds.PremiumPA2 = Convert.ToInt32(oDbDataReader["PremiumPA2"]);

					if(oDbDataReader["PremiumME"] != DBNull.Value)
						oPATransPolicyInsureds.PremiumME = Convert.ToInt32(oDbDataReader["PremiumME"]);

					if(oDbDataReader["AddPremium"] != DBNull.Value)
						oPATransPolicyInsureds.AddPremium = Convert.ToInt32(oDbDataReader["AddPremium"]);

					if(oDbDataReader["GrossPremium"] != DBNull.Value)
						oPATransPolicyInsureds.GrossPremium = Convert.ToInt32(oDbDataReader["GrossPremium"]);

					if(oDbDataReader["Stamp"] != DBNull.Value)
						oPATransPolicyInsureds.Stamp = Convert.ToInt32(oDbDataReader["Stamp"]);

					if(oDbDataReader["SBT"] != DBNull.Value)
						oPATransPolicyInsureds.SBT = Convert.ToInt32(oDbDataReader["SBT"]);

					if(oDbDataReader["TotalPremium"] != DBNull.Value)
						oPATransPolicyInsureds.TotalPremium = Convert.ToInt32(oDbDataReader["TotalPremium"]);

					if(oDbDataReader["isBeneficiary"] != DBNull.Value)
						oPATransPolicyInsureds.isBeneficiary = Convert.ToSByte(oDbDataReader["isBeneficiary"]);

					if(oDbDataReader["isStudent"] != DBNull.Value)
						oPATransPolicyInsureds.isStudent = Convert.ToSByte(oDbDataReader["isStudent"]);

					if(oDbDataReader["isSingle"] != DBNull.Value)
						oPATransPolicyInsureds.isSingle = Convert.ToSByte(oDbDataReader["isSingle"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oPATransPolicyInsureds.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);

					if(oDbDataReader["Message"] != DBNull.Value)
						oPATransPolicyInsureds.Message = Convert.ToString(oDbDataReader["Message"]);
					lstPATransPolicyInsuredss.Add(oPATransPolicyInsureds);
				}
				oDbDataReader.Close();
				return lstPATransPolicyInsuredss;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}
		public PATransPolicyHolders GetPATransPolicyHoldersOfPATransPolicyInsureds(string JobNo)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				PATransPolicyHolders oPATransPolicyHolders = new PATransPolicyHolders();
                //DbProviderHelper dbHelper = new DbProviderHelper();
				DbCommand oDbCommand = db.CreateCommand("",CommandType.StoredProcedure);
				oDbCommand.Parameters.Add(db.CreateParameter("@JobNo",DbType.String,JobNo));
				oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oPATransPolicyHolders.JobNo = Convert.ToString(oDbDataReader["JobNo"]);

					if(oDbDataReader["ClientCode"] != DBNull.Value)
						oPATransPolicyHolders.ClientCode = Convert.ToString(oDbDataReader["ClientCode"]);

					if(oDbDataReader["ClientType"] != DBNull.Value)
						oPATransPolicyHolders.ClientType = Convert.ToString(oDbDataReader["ClientType"]);

					if(oDbDataReader["ClientTitle"] != DBNull.Value)
						oPATransPolicyHolders.ClientTitle = Convert.ToString(oDbDataReader["ClientTitle"]);

					if(oDbDataReader["ClientName"] != DBNull.Value)
						oPATransPolicyHolders.ClientName = Convert.ToString(oDbDataReader["ClientName"]);

					if(oDbDataReader["ClientSurName"] != DBNull.Value)
						oPATransPolicyHolders.ClientSurName = Convert.ToString(oDbDataReader["ClientSurName"]);

					if(oDbDataReader["AddressNo"] != DBNull.Value)
						oPATransPolicyHolders.AddressNo = Convert.ToString(oDbDataReader["AddressNo"]);

					if(oDbDataReader["Building"] != DBNull.Value)
						oPATransPolicyHolders.Building = Convert.ToString(oDbDataReader["Building"]);

					if(oDbDataReader["Soi"] != DBNull.Value)
						oPATransPolicyHolders.Soi = Convert.ToString(oDbDataReader["Soi"]);

					if(oDbDataReader["Road"] != DBNull.Value)
						oPATransPolicyHolders.Road = Convert.ToString(oDbDataReader["Road"]);

					if(oDbDataReader["Tumbol"] != DBNull.Value)
						oPATransPolicyHolders.Tumbol = Convert.ToString(oDbDataReader["Tumbol"]);

					if(oDbDataReader["Amphur"] != DBNull.Value)
						oPATransPolicyHolders.Amphur = Convert.ToString(oDbDataReader["Amphur"]);

					if(oDbDataReader["Province"] != DBNull.Value)
						oPATransPolicyHolders.Province = Convert.ToString(oDbDataReader["Province"]);

					if(oDbDataReader["PostCode"] != DBNull.Value)
						oPATransPolicyHolders.PostCode = Convert.ToString(oDbDataReader["PostCode"]);

					if(oDbDataReader["CountryCode"] != DBNull.Value)
						oPATransPolicyHolders.CountryCode = Convert.ToString(oDbDataReader["CountryCode"]);

					if(oDbDataReader["Birthday"] != DBNull.Value)
						oPATransPolicyHolders.Birthday = Convert.ToString(oDbDataReader["Birthday"]);

					if(oDbDataReader["ClientGender"] != DBNull.Value)
						oPATransPolicyHolders.ClientGender = Convert.ToString(oDbDataReader["ClientGender"]);

					if(oDbDataReader["ClientStatus"] != DBNull.Value)
						oPATransPolicyHolders.ClientStatus = Convert.ToString(oDbDataReader["ClientStatus"]);

					if(oDbDataReader["PassportID"] != DBNull.Value)
						oPATransPolicyHolders.PassportID = Convert.ToString(oDbDataReader["PassportID"]);

					if(oDbDataReader["IDCard"] != DBNull.Value)
						oPATransPolicyHolders.IDCard = Convert.ToString(oDbDataReader["IDCard"]);

					if(oDbDataReader["TaxID"] != DBNull.Value)
						oPATransPolicyHolders.TaxID = Convert.ToString(oDbDataReader["TaxID"]);

					if(oDbDataReader["Tel"] != DBNull.Value)
						oPATransPolicyHolders.Tel = Convert.ToString(oDbDataReader["Tel"]);

					if(oDbDataReader["Email"] != DBNull.Value)
						oPATransPolicyHolders.Email = Convert.ToString(oDbDataReader["Email"]);

					if(oDbDataReader["Language"] != DBNull.Value)
						oPATransPolicyHolders.Language = Convert.ToString(oDbDataReader["Language"]);

					if(oDbDataReader["CreateDate"] != DBNull.Value)
						oPATransPolicyHolders.CreateDate = Convert.ToDateTime(oDbDataReader["CreateDate"]);

					if(oDbDataReader["Message"] != DBNull.Value)
						oPATransPolicyHolders.Message = Convert.ToString(oDbDataReader["Message"]);
				}
				oDbDataReader.Close();
				return oPATransPolicyHolders;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}

        /// <summary>
        /// SET
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="InsuredID"></param>
        /// <param name="ClientCode"></param>
        /// <param name="ClientTitle"></param>
        /// <param name="ClientName"></param>
        /// <param name="ClientSurName"></param>
        /// <param name="Birthday"></param>
        /// <param name="IDCard"></param>
        /// <param name="Tel"></param>
        /// <param name="SumInsuredPA2"></param>
        /// <param name="SumInsuredME"></param>
        /// <param name="PremiumPA2"></param>
        /// <param name="PremiumME"></param>
        /// <param name="AddPremium"></param>
        /// <param name="GrossPremium"></param>
        /// <param name="Stamp"></param>
        /// <param name="SBT"></param>
        /// <param name="TotalPremium"></param>
        /// <param name="isBeneficiary"></param>
        /// <param name="isStudent"></param>
        /// <param name="isSingle"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-26</lastupdate>
        public int SetPATransPolicyInsureds(string JobNo, int InsuredID, string ClientCode, string ClientTitle, string ClientName, string ClientSurName, string Birthday, string IDCard, string Tel, Nullable<int> SumInsuredPA2, Nullable<int> SumInsuredME, Nullable<int> PremiumPA2, Nullable<int> PremiumME, Nullable<int> AddPremium, Nullable<int> GrossPremium, Nullable<int> Stamp, Nullable<int> SBT, Nullable<int> TotalPremium, Nullable<SByte> isBeneficiary, Nullable<SByte> isStudent, Nullable<SByte> isSingle)
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = db.CreateCommand("spPA_SetTransPolicyInsured", CommandType.StoredProcedure);                
                oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, JobNo));
                oDbCommand.Parameters.Add(db.CreateParameter("@InsuredID", DbType.String, InsuredID));
                if (ClientCode != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientCode", DbType.String, ClientCode));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientCode", DbType.String, DBNull.Value));
                if (ClientTitle != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle", DbType.String, ClientTitle));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle", DbType.String, DBNull.Value));
                if (ClientName != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientName", DbType.String, ClientName));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientName", DbType.String, DBNull.Value));
                if (ClientSurName != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName", DbType.String, ClientSurName));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName", DbType.String, DBNull.Value));
                if (Birthday != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Birthday", DbType.String, Birthday));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Birthday", DbType.String, DBNull.Value));
                if (IDCard != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@IDCard", DbType.String, IDCard));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@IDCard", DbType.String, DBNull.Value));
                if (Tel != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tel", DbType.String, Tel));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tel", DbType.String, DBNull.Value));
                if (SumInsuredPA2.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@SumInsuredPA2", DbType.Int32, SumInsuredPA2));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@SumInsuredPA2", DbType.Int32, DBNull.Value));
                if (SumInsuredME.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@SumInsuredME", DbType.Int32, SumInsuredME));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@SumInsuredME", DbType.Int32, DBNull.Value));
                if (PremiumPA2.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PremiumPA2", DbType.Int32, PremiumPA2));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PremiumPA2", DbType.Int32, DBNull.Value));
                if (PremiumME.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PremiumME", DbType.Int32, PremiumME));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PremiumME", DbType.Int32, DBNull.Value));
                if (AddPremium.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@AddPremium", DbType.Int32, AddPremium));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@AddPremium", DbType.Int32, DBNull.Value));
                if (GrossPremium.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@GrossPremium", DbType.Int32, GrossPremium));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@GrossPremium", DbType.Int32, DBNull.Value));
                if (Stamp.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Stamp", DbType.Int32, Stamp));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Stamp", DbType.Int32, DBNull.Value));
                if (SBT.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@SBT", DbType.Int32, SBT));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@SBT", DbType.Int32, DBNull.Value));
                if (TotalPremium.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@TotalPremium", DbType.Int32, TotalPremium));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@TotalPremium", DbType.Int32, DBNull.Value));
                if (isBeneficiary.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@isBeneficiary", DbType.Int16, isBeneficiary));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@isBeneficiary", DbType.Int16, DBNull.Value));
                if (isStudent.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@isStudent", DbType.Int16, isStudent));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@isStudent", DbType.Int16, DBNull.Value));
                if (isSingle.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@isSingle", DbType.Int16, isSingle));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@isSingle", DbType.Int16, DBNull.Value));
                

                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// SET WITH TRANSACTION
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="InsuredID"></param>
        /// <param name="ClientCode"></param>
        /// <param name="ClientTitle"></param>
        /// <param name="ClientName"></param>
        /// <param name="ClientSurName"></param>
        /// <param name="Birthday"></param>
        /// <param name="IDCard"></param>
        /// <param name="Tel"></param>
        /// <param name="SumInsuredPA2"></param>
        /// <param name="SumInsuredME"></param>
        /// <param name="PremiumPA2"></param>
        /// <param name="PremiumME"></param>
        /// <param name="AddPremium"></param>
        /// <param name="GrossPremium"></param>
        /// <param name="Stamp"></param>
        /// <param name="SBT"></param>
        /// <param name="TotalPremium"></param>
        /// <param name="isBeneficiary"></param>
        /// <param name="isStudent"></param>
        /// <param name="isSingle"></param>
        /// <param name="dbTransaction"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-26</lastupdate>
        public int SetPATransPolicyInsureds(DbProviderHelper db,string JobNo, int InsuredID, string ClientCode, string ClientTitle, string ClientName, string ClientSurName, string Birthday, string IDCard, string Tel, Nullable<int> SumInsuredPA2, Nullable<int> SumInsuredME, Nullable<int> PremiumPA2, Nullable<int> PremiumME, Nullable<int> AddPremium, Nullable<int> GrossPremium, Nullable<int> Stamp, Nullable<int> SBT, Nullable<int> TotalPremium, Nullable<SByte> isBeneficiary, Nullable<SByte> isStudent, Nullable<SByte> isSingle, Nullable<decimal> SumPercent, Nullable<decimal> PremiumPercent, string PackageID, string PlanCode, DbTransaction dbTransaction)
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = db.CreateCommand("spPA_SetTransPolicyInsured", CommandType.StoredProcedure, dbTransaction);
                oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, JobNo));
                oDbCommand.Parameters.Add(db.CreateParameter("@InsuredID", DbType.String, InsuredID));
                if (ClientCode != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientCode", DbType.String, ClientCode));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientCode", DbType.String, DBNull.Value));
                if (ClientTitle != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle", DbType.String, ClientTitle));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle", DbType.String, DBNull.Value));
                if (ClientName != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientName", DbType.String, ClientName));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientName", DbType.String, DBNull.Value));
                if (ClientSurName != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName", DbType.String, ClientSurName));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName", DbType.String, DBNull.Value));
                if (Birthday != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Birthday", DbType.String, Birthday));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Birthday", DbType.String, DBNull.Value));
                if (IDCard != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@IDCard", DbType.String, IDCard));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@IDCard", DbType.String, DBNull.Value));
                if (Tel != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tel", DbType.String, Tel));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tel", DbType.String, DBNull.Value));
                if (SumInsuredPA2.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@SumInsuredPA2", DbType.Int32, SumInsuredPA2));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@SumInsuredPA2", DbType.Int32, DBNull.Value));
                if (SumInsuredME.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@SumInsuredME", DbType.Int32, SumInsuredME));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@SumInsuredME", DbType.Int32, DBNull.Value));
                if (PremiumPA2.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PremiumPA2", DbType.Int32, PremiumPA2));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PremiumPA2", DbType.Int32, DBNull.Value));
                if (PremiumME.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PremiumME", DbType.Int32, PremiumME));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PremiumME", DbType.Int32, DBNull.Value));
                if (AddPremium.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@AddPremium", DbType.Int32, AddPremium));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@AddPremium", DbType.Int32, DBNull.Value));
                if (GrossPremium.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@GrossPremium", DbType.Int32, GrossPremium));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@GrossPremium", DbType.Int32, DBNull.Value));
                if (Stamp.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Stamp", DbType.Int32, Stamp));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Stamp", DbType.Int32, DBNull.Value));
                if (SBT.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@SBT", DbType.Int32, SBT));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@SBT", DbType.Int32, DBNull.Value));
                if (TotalPremium.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@TotalPremium", DbType.Int32, TotalPremium));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@TotalPremium", DbType.Int32, DBNull.Value));
                if (isBeneficiary.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@isBeneficiary", DbType.Int16, isBeneficiary));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@isBeneficiary", DbType.Int16, DBNull.Value));
                if (isStudent.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@isStudent", DbType.Int16, isStudent));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@isStudent", DbType.Int16, DBNull.Value));
                if (isSingle.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@isSingle", DbType.Int16, isSingle));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@isSingle", DbType.Int16, DBNull.Value));
                if (SumPercent.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@SumPercent", DbType.Decimal, SumPercent));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@SumPercent", DbType.Decimal, DBNull.Value));
                if (PremiumPercent.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PremiumPercent", DbType.Decimal, PremiumPercent));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PremiumPercent", DbType.Decimal, DBNull.Value));
                if (PackageID != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PackageID", DbType.String, PackageID));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PackageID", DbType.String, DBNull.Value));
                if (PlanCode != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PlanCode", DbType.String, PlanCode));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PlanCode", DbType.String, DBNull.Value));


                return db.ExecuteNonQuery(oDbCommand,true);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// SET WITH TRANSACTION
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="InsuredID"></param>
        /// <param name="ClientCode"></param>
        /// <param name="ClientTitle"></param>
        /// <param name="ClientName"></param>
        /// <param name="ClientSurName"></param>
        /// <param name="Birthday"></param>
        /// <param name="IDCard"></param>
        /// <param name="Tel"></param>
        /// <param name="SumInsuredPA2"></param>
        /// <param name="SumInsuredME"></param>
        /// <param name="PremiumPA2"></param>
        /// <param name="PremiumME"></param>
        /// <param name="AddPremium"></param>
        /// <param name="GrossPremium"></param>
        /// <param name="Stamp"></param>
        /// <param name="SBT"></param>
        /// <param name="TotalPremium"></param>
        /// <param name="isBeneficiary"></param>
        /// <param name="isStudent"></param>
        /// <param name="isSingle"></param>
        /// <param name="SumPercent"></param>
        /// <param name="PremiumPercent"></param>
        /// <param name="PackageID"></param>
        /// <param name="PlanCode"></param>
        /// <param name="FlagClearPremium"></param>
        /// <param name="dbTransaction"></param>
        /// <returns></returns>
        /// <lastupdate>2016-01-27</lastupdate>
        public int SetPATransPolicyInsureds(DbProviderHelper db,string JobNo, int InsuredID, string ClientCode, string ClientTitle, string ClientName, string ClientSurName, string Birthday, string IDCard, string Tel, Nullable<int> SumInsuredPA2, Nullable<int> SumInsuredME, Nullable<int> PremiumPA2, Nullable<int> PremiumME, Nullable<int> AddPremium, Nullable<int> GrossPremium, Nullable<int> Stamp, Nullable<int> SBT, Nullable<int> TotalPremium, Nullable<SByte> isBeneficiary, Nullable<SByte> isStudent, Nullable<SByte> isSingle, Nullable<decimal> SumPercent, Nullable<decimal> PremiumPercent, string PackageID, string PlanCode, bool FlagClearPremium, DbTransaction dbTransaction)
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = db.CreateCommand("spPA_SetTransPolicyInsuredFlagClear", CommandType.StoredProcedure, dbTransaction);
                oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, JobNo));
                oDbCommand.Parameters.Add(db.CreateParameter("@InsuredID", DbType.String, InsuredID));
                if (ClientCode != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientCode", DbType.String, ClientCode));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientCode", DbType.String, DBNull.Value));
                if (ClientTitle != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle", DbType.String, ClientTitle));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientTitle", DbType.String, DBNull.Value));
                if (ClientName != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientName", DbType.String, ClientName));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientName", DbType.String, DBNull.Value));
                if (ClientSurName != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName", DbType.String, ClientSurName));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@ClientSurName", DbType.String, DBNull.Value));
                if (Birthday != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Birthday", DbType.String, Birthday));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Birthday", DbType.String, DBNull.Value));
                if (IDCard != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@IDCard", DbType.String, IDCard));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@IDCard", DbType.String, DBNull.Value));
                if (Tel != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tel", DbType.String, Tel));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Tel", DbType.String, DBNull.Value));
                if (SumInsuredPA2.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@SumInsuredPA2", DbType.Int32, SumInsuredPA2));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@SumInsuredPA2", DbType.Int32, DBNull.Value));
                if (SumInsuredME.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@SumInsuredME", DbType.Int32, SumInsuredME));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@SumInsuredME", DbType.Int32, DBNull.Value));
                if (PremiumPA2.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PremiumPA2", DbType.Int32, PremiumPA2));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PremiumPA2", DbType.Int32, DBNull.Value));
                if (PremiumME.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PremiumME", DbType.Int32, PremiumME));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PremiumME", DbType.Int32, DBNull.Value));
                if (AddPremium.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@AddPremium", DbType.Int32, AddPremium));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@AddPremium", DbType.Int32, DBNull.Value));
                if (GrossPremium.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@GrossPremium", DbType.Int32, GrossPremium));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@GrossPremium", DbType.Int32, DBNull.Value));
                if (Stamp.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Stamp", DbType.Int32, Stamp));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Stamp", DbType.Int32, DBNull.Value));
                if (SBT.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@SBT", DbType.Int32, SBT));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@SBT", DbType.Int32, DBNull.Value));
                if (TotalPremium.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@TotalPremium", DbType.Int32, TotalPremium));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@TotalPremium", DbType.Int32, DBNull.Value));
                if (isBeneficiary.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@isBeneficiary", DbType.Int16, isBeneficiary));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@isBeneficiary", DbType.Int16, DBNull.Value));
                if (isStudent.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@isStudent", DbType.Int16, isStudent));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@isStudent", DbType.Int16, DBNull.Value));
                if (isSingle.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@isSingle", DbType.Int16, isSingle));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@isSingle", DbType.Int16, DBNull.Value));
                if (SumPercent.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@SumPercent", DbType.Decimal, SumPercent));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@SumPercent", DbType.Decimal, DBNull.Value));
                if (PremiumPercent.HasValue)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PremiumPercent", DbType.Decimal, PremiumPercent));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PremiumPercent", DbType.Decimal, DBNull.Value));
                if (PackageID != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PackageID", DbType.String, PackageID));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PackageID", DbType.String, DBNull.Value));
                if (PlanCode != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PlanCode", DbType.String, PlanCode));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PlanCode", DbType.String, DBNull.Value));

                oDbCommand.Parameters.Add(db.CreateParameter("@FlagClearPremium", DbType.Boolean, !FlagClearPremium));


                return db.ExecuteNonQuery(oDbCommand, true);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
		
	}
}
