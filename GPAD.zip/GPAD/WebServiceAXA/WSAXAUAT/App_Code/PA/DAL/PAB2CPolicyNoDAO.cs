using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;

namespace PA.DAL
{
	public class PAB2CPolicyNoDAO
	{
        DbProviderHelper db;

		public PAB2CPolicyNoDAO()
		{   
            db = new DbProviderHelper();
            db.GetConnection();
		}
        public string spPAB2C_SetPolicyNo()
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();
                // get a configured & create DbCommand object
                DbCommand comm = db.CreateCommand("spPAB2C_SetPolicyNo", CommandType.StoredProcedure);

                // create parameter and direction
                DbParameter param = comm.CreateParameter();
                param.ParameterName = "@PolicyNo";
                param.DbType = DbType.String;
                param.Size = 20;
                param.Direction = ParameterDirection.Output;
                comm.Parameters.Add(param);

                //execute command
                int ret = db.ExecuteNonQuery(comm);

                //return jobno
                return param.Value.ToString();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public string spPAB2C_SetPolicyNo(string JobNo, string Prefix)
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();
                // get a configured & create DbCommand object
                DbCommand comm = db.CreateCommand("spPAB2C_SetPolicyNoByJobNo", CommandType.StoredProcedure);

                // create parameter and direction
                DbParameter param = comm.CreateParameter();
                param.ParameterName = "@PolicyNo";
                param.DbType = DbType.String;
                param.Size = 20;
                param.Direction = ParameterDirection.Output;
                comm.Parameters.Add(param);

                DbParameter param2 = comm.CreateParameter();
                param2.ParameterName = "@JobNo";
                param2.DbType = DbType.String;
                param2.Size = 200;
                param2.Value = JobNo;
                param2.Direction = ParameterDirection.Input;
                comm.Parameters.Add(param2);

                DbParameter param3 = comm.CreateParameter();
                param3.ParameterName = "@Prefix";
                param3.DbType = DbType.String;
                param3.Size = 10;
                param3.Value = Prefix;
                param3.Direction = ParameterDirection.Input;
                comm.Parameters.Add(param3);

                //execute command
                int ret = db.ExecuteNonQuery(comm);

                //return jobno
                return param.Value.ToString();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }
        public int spPAB2C_UpdatePolicyNoToJobNo(string JobNo, string PolicyNo, string RETURNINV)
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();

                DbCommand oDbCommand = db.CreateCommand("UPDATE [PATransPolicies] SET [PolicyNo]=@PolicyNo, [RETURNINV] = @RETURNINV WHERE [JobNo] = @JobNo", CommandType.Text);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (PolicyNo != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@PolicyNo", DbType.String, PolicyNo));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@PolicyNo", DbType.String, DBNull.Value));

                if (RETURNINV != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@RETURNINV", DbType.String, RETURNINV));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@RETURNINV", DbType.String, DBNull.Value));

                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //Makkawat Update 20150811
        public DataTable spPAB2C_FindPolicyNoByRef(string RETURNINV)
        {
            DbDataReader oDbDataReader = null;
            try
            {
                DataTable result = new DataTable();
                DbCommand oDbCommand = db.CreateCommand("SELECT [JobNo],[PolicyNo],[PolicyType],[PlanCode] FROM [PATransPolicies] where RETURNINV = @RETURNINV", CommandType.Text);
                oDbCommand.Parameters.Add(db.CreateParameter("@RETURNINV", DbType.String, RETURNINV));
                oDbDataReader = db.ExecuteReader(oDbCommand);

                result.Load(oDbDataReader);

                oDbDataReader.Close();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //Makkawat Update 20150811
        public DataTable spPAB2C_FindPolicyHoldersNameByJobNo(string JobNo)
        {
            DbDataReader oDbDataReader = null;
            try
            {
                DataTable result = new DataTable();
                DbCommand oDbCommand = db.CreateCommand("SELECT [ClientTitle],[ClientName],[ClientSurName] FROM [PATransPolicyHolders] where [JobNo] = @JobNo", CommandType.Text);
                oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, JobNo));
                oDbDataReader = db.ExecuteReader(oDbCommand);

                result.Load(oDbDataReader);

                oDbDataReader.Close();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
	}
}
