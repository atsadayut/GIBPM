using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;

namespace PA.DAL
{
	public class PAOccupationDAO
	{
        DbProviderHelper db;

		public PAOccupationDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}
		public PAOccupation GetPAOccupation(string lang,string occupationDesc)
		{
            DbDataReader oDbDataReader = null;
            try
			{
                PAOccupation oPAOccupation = new PAOccupation();
                string cCommand ="";
                if (lang == "T")
                {
                    cCommand = "SELECT * FROM [PAOccupation] WHERE [DescriptionTH]=@occupationDesc";
                }
                else
                {
                    cCommand = "SELECT * FROM [PAOccupation] WHERE [DescriptionEN]=@occupationDesc";
                }
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = db.CreateCommand(cCommand, CommandType.Text);
                oDbCommand.Parameters.Add(db.CreateParameter("@occupationDesc", DbType.String, occupationDesc));
                oDbDataReader = db.ExecuteReader(oDbCommand);
                while (oDbDataReader.Read())
                {
                    oPAOccupation.OccupationID = Convert.ToInt32(oDbDataReader["OccupationID"]);

                    if (oDbDataReader["OccupatnClass"] != DBNull.Value)
                        oPAOccupation.OccupatnClass = Convert.ToString(oDbDataReader["OccupatnClass"]);

                    if (oDbDataReader["DescriptionTH"] != DBNull.Value)
                        oPAOccupation.DescriptionTH = Convert.ToString(oDbDataReader["DescriptionTH"]);

                    if (oDbDataReader["DescriptionEN"] != DBNull.Value)
                        oPAOccupation.DescriptionEN = Convert.ToString(oDbDataReader["DescriptionEN"]);

                    if (oDbDataReader["Remark"] != DBNull.Value)
                        oPAOccupation.Remark = Convert.ToString(oDbDataReader["Remark"]);

                    if (oDbDataReader["Status"] != DBNull.Value)
                        oPAOccupation.Status = Convert.ToBoolean(oDbDataReader["Status"]);
                }
                oDbDataReader.Close();
                return oPAOccupation;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}
		public PAOccupation GetPAOccupation(int OccupationID)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				PAOccupation oPAOccupation = new PAOccupation();
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = db.CreateCommand("SELECT [OccupationID],[OccupatnClass],[DescriptionTH],[DescriptionEN],[Remark],[Status] FROM [PAOccupation] WHERE [OccupationID]=@OccupationID", CommandType.Text);
                oDbCommand.Parameters.Add(db.CreateParameter("@OccupationID", DbType.Int32, OccupationID));
                oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oPAOccupation.OccupationID = Convert.ToInt32(oDbDataReader["OccupationID"]);

					if(oDbDataReader["OccupatnClass"] != DBNull.Value)
						oPAOccupation.OccupatnClass = Convert.ToString(oDbDataReader["OccupatnClass"]);

					if(oDbDataReader["DescriptionTH"] != DBNull.Value)
						oPAOccupation.DescriptionTH = Convert.ToString(oDbDataReader["DescriptionTH"]);

					if(oDbDataReader["DescriptionEN"] != DBNull.Value)
						oPAOccupation.DescriptionEN = Convert.ToString(oDbDataReader["DescriptionEN"]);

					if(oDbDataReader["Remark"] != DBNull.Value)
						oPAOccupation.Remark = Convert.ToString(oDbDataReader["Remark"]);

					if(oDbDataReader["Status"] != DBNull.Value)
						oPAOccupation.Status = Convert.ToBoolean(oDbDataReader["Status"]);
				}
				oDbDataReader.Close();
				return oPAOccupation;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}

	}
}
