using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;

namespace PA.DAL
{
    /// <summary>
    /// 
    /// </summary>
    /// <lastupdate>2012-08-25</lastupdate>
	public class PATransLongNamesDAO
	{
        DbProviderHelper db;

		public PATransLongNamesDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}
		public List<PATransLongNames> GetPATransLongNamess()
		{
            DbDataReader oDbDataReader = null;
            try
			{
				List<PATransLongNames> lstPATransLongNamess = new List<PATransLongNames>();
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = db.CreateCommand("", CommandType.StoredProcedure);
                oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					PATransLongNames oPATransLongNames = new PATransLongNames();
					oPATransLongNames.JobNo = Convert.ToString(oDbDataReader["JobNo"]);

					if(oDbDataReader["LongName1"] != DBNull.Value)
						oPATransLongNames.LongName1 = Convert.ToString(oDbDataReader["LongName1"]);

					if(oDbDataReader["LongName2"] != DBNull.Value)
						oPATransLongNames.LongName2 = Convert.ToString(oDbDataReader["LongName2"]);

					if(oDbDataReader["LongName3"] != DBNull.Value)
						oPATransLongNames.LongName3 = Convert.ToString(oDbDataReader["LongName3"]);

					if(oDbDataReader["LongName4"] != DBNull.Value)
						oPATransLongNames.LongName4 = Convert.ToString(oDbDataReader["LongName4"]);

					if(oDbDataReader["Message"] != DBNull.Value)
						oPATransLongNames.Message = Convert.ToString(oDbDataReader["Message"]);
					lstPATransLongNamess.Add(oPATransLongNames);
				}
				oDbDataReader.Close();
				return lstPATransLongNamess;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}
		public PATransLongNames GetPATransLongNames(string JobNo)
		{
            DbDataReader oDbDataReader = null;
            try
			{
				PATransLongNames oPATransLongNames = new PATransLongNames();
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = db.CreateCommand("", CommandType.StoredProcedure);
                oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, JobNo));
                oDbDataReader = db.ExecuteReader(oDbCommand);
				while (oDbDataReader.Read())
				{
					oPATransLongNames.JobNo = Convert.ToString(oDbDataReader["JobNo"]);

					if(oDbDataReader["LongName1"] != DBNull.Value)
						oPATransLongNames.LongName1 = Convert.ToString(oDbDataReader["LongName1"]);

					if(oDbDataReader["LongName2"] != DBNull.Value)
						oPATransLongNames.LongName2 = Convert.ToString(oDbDataReader["LongName2"]);

					if(oDbDataReader["LongName3"] != DBNull.Value)
						oPATransLongNames.LongName3 = Convert.ToString(oDbDataReader["LongName3"]);

					if(oDbDataReader["LongName4"] != DBNull.Value)
						oPATransLongNames.LongName4 = Convert.ToString(oDbDataReader["LongName4"]);

					if(oDbDataReader["Message"] != DBNull.Value)
						oPATransLongNames.Message = Convert.ToString(oDbDataReader["Message"]);
				}
				oDbDataReader.Close();
				return oPATransLongNames;
			}
			catch (Exception ex)
			{
                oDbDataReader.Close();
                throw ex;
			}
		}
		public int AddPATransLongNames(string JobNo,string LongName1,string LongName2,string LongName3,string LongName4,string Message)
		{
			try
			{
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = db.CreateCommand("", CommandType.StoredProcedure);
				if (LongName1!=null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName1", DbType.String, LongName1));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName1", DbType.String, DBNull.Value));
				if (LongName2!=null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName2", DbType.String, LongName2));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName2", DbType.String, DBNull.Value));
				if (LongName3!=null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName3", DbType.String, LongName3));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName3", DbType.String, DBNull.Value));
				if (LongName4!=null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName4", DbType.String, LongName4));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName4", DbType.String, DBNull.Value));
				if (Message!=null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Message", DbType.String, Message));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Message", DbType.String, DBNull.Value));

                return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public int UpdatePATransLongNames(string JobNo,string LongName1,string LongName2,string LongName3,string LongName4,string Message)
		{

			try
			{
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = db.CreateCommand("", CommandType.StoredProcedure);
				if (LongName1!=null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName1", DbType.String, LongName1));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName1", DbType.String, DBNull.Value));
				if (LongName2!=null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName2", DbType.String, LongName2));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName2", DbType.String, DBNull.Value));
				if (LongName3!=null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName3", DbType.String, LongName3));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName3", DbType.String, DBNull.Value));
				if (LongName4!=null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName4", DbType.String, LongName4));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName4", DbType.String, DBNull.Value));
				if (Message!=null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@Message", DbType.String, Message));
				else
                    oDbCommand.Parameters.Add(db.CreateParameter("@Message", DbType.String, DBNull.Value));
                oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, JobNo));
                return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public int RemovePATransLongNames(string JobNo)
		{

			try
			{
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = db.CreateCommand("", CommandType.StoredProcedure);
                oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, JobNo));
                return db.ExecuteNonQuery(oDbCommand);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

        /// <summary>
        /// SET
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="LongName1"></param>
        /// <param name="LongName2"></param>
        /// <param name="LongName3"></param>
        /// <param name="LongName4"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-25</lastupdate>
        public int SetPATransLongName(string JobNo, string LongName1, string LongName2, string LongName3, string LongName4)
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = db.CreateCommand("spPA_SetTransLongName", CommandType.StoredProcedure);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (LongName1 != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName1", DbType.String, LongName1));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName1", DbType.String, DBNull.Value));
                if (LongName2 != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName2", DbType.String, LongName2));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName2", DbType.String, DBNull.Value));
                if (LongName3 != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName3", DbType.String, LongName3));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName3", DbType.String, DBNull.Value));
                if (LongName4 != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName4", DbType.String, LongName4));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName4", DbType.String, DBNull.Value));

                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// SET WITH TRANSACTION
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="LongName1"></param>
        /// <param name="LongName2"></param>
        /// <param name="LongName3"></param>
        /// <param name="LongName4"></param>
        /// <param name="dbTransaction"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-25</lastupdate>
        public int SetPATransLongName(string JobNo, string LongName1, string LongName2, string LongName3, string LongName4, DbTransaction dbTransaction)
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = db.CreateCommand("spPA_SetTransLongName", CommandType.StoredProcedure, dbTransaction);
                if (JobNo != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, JobNo));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, DBNull.Value));
                if (LongName1 != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName1", DbType.String, LongName1));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName1", DbType.String, DBNull.Value));
                if (LongName2 != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName2", DbType.String, LongName2));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName2", DbType.String, DBNull.Value));
                if (LongName3 != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName3", DbType.String, LongName3));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName3", DbType.String, DBNull.Value));
                if (LongName4 != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName4", DbType.String, LongName4));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@LongName4", DbType.String, DBNull.Value));

                return db.ExecuteNonQuery(oDbCommand, true);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
	}
}
