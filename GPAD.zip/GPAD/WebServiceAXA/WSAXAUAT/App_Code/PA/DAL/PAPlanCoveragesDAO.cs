using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;

namespace PA.DAL
{
    /// <summary>
    /// 
    /// </summary>
    /// <lastupdate>2012-08-24</lastupdate>
	public class PAPlanCoveragesDAO
	{
        DbProviderHelper db;

		public PAPlanCoveragesDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
        }
	
        /// <summary>
        /// GET
        /// </summary>
        /// <param name="PlanCode"></param>
        /// <param name="LANG"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-24</lastupdate>
        public DataTable GetDtPAPlanCoverages(string PlanCode, string LANG)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();

                DbCommand comm = db.CreateCommand("spPA_getPlanCoverage", CommandType.StoredProcedure);
                comm.Parameters.Add(db.CreateParameter("@PlanCode", DbType.String, PlanCode));
                comm.Parameters.Add(db.CreateParameter("@LANG", DbType.String, LANG));
                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return db.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetDtPAPlanCoverages(string PlanCode)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();

                DbCommand comm = db.CreateCommand("spPAB2C_getPlanCoverage", CommandType.StoredProcedure);
                comm.Parameters.Add(db.CreateParameter("@PlanCode", DbType.String, PlanCode));
                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return db.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetDtPAPlanCoveragesRow(string PlanCode, string Occu, string CoverageCode)
        {
            try
            {
                // get a configured & create DbCommand object
                //DbProviderHelper dbHelper = new DbProviderHelper();

                DbCommand comm = db.CreateCommand("spPAB2C_getPlanCoverageRow", CommandType.StoredProcedure);
                comm.Parameters.Add(db.CreateParameter("@PlanCode", DbType.String, PlanCode));
                comm.Parameters.Add(db.CreateParameter("@Occu", DbType.String, Occu));
                comm.Parameters.Add(db.CreateParameter("@CoverageCode", DbType.Int32, CoverageCode));
                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return db.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
	}
}
