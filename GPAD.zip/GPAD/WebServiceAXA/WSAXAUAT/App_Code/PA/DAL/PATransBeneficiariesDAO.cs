using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;

namespace PA.DAL
{
    /// <summary>
    /// 
    /// </summary>
    /// <lastupdate>2012-08-25</lastupdate>
	public class PATransBeneficiariesDAO
	{
        DbProviderHelper db;

		public PATransBeneficiariesDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}
		

        /// <summary>
        /// SET
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="InsuredID"></param>
        /// <param name="BeneficiaryID"></param>
        /// <param name="BeneficiaryTitle"></param>
        /// <param name="BeneficiaryName"></param>
        /// <param name="BeneficiarySurName"></param>
        /// <param name="BeneficiaryRelation"></param>
        /// <param name="BeneficiaryRatio"></param>
        /// <param name="BeneficiaryTel"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-26</lastupdate>
        public int SetPATransBeneficiary(string JobNo, int InsuredID, int BeneficiaryID, string BeneficiaryTitle, string BeneficiaryName, string BeneficiarySurName, string BeneficiaryRelation, string BeneficiaryRatio, string BeneficiaryTel)
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = db.CreateCommand("spPA_SetTransBeneficiary", CommandType.StoredProcedure);
                oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, JobNo));
                oDbCommand.Parameters.Add(db.CreateParameter("@InsuredID", DbType.Int32, InsuredID));
                oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiaryID", DbType.Int32, BeneficiaryID));

                if (BeneficiaryTitle != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiaryTitle", DbType.String, BeneficiaryTitle));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiaryTitle", DbType.String, DBNull.Value));
                if (BeneficiaryName != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiaryName", DbType.String, BeneficiaryName));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiaryName", DbType.String, DBNull.Value));
                if (BeneficiarySurName != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiarySurName", DbType.String, BeneficiarySurName));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiarySurName", DbType.String, DBNull.Value));
                if (BeneficiaryRelation != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiaryRelation", DbType.String, BeneficiaryRelation));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiaryRelation", DbType.String, DBNull.Value));
                if (BeneficiaryRatio != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiaryRatio", DbType.String, BeneficiaryRatio));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiaryRatio", DbType.String, DBNull.Value));
                if (BeneficiaryTel != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiaryTel", DbType.String, BeneficiaryTel));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiaryTel", DbType.String, DBNull.Value));

                return db.ExecuteNonQuery(oDbCommand);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// SET WITH TRANSACTION
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="InsuredID"></param>
        /// <param name="BeneficiaryID"></param>
        /// <param name="BeneficiaryTitle"></param>
        /// <param name="BeneficiaryName"></param>
        /// <param name="BeneficiarySurName"></param>
        /// <param name="BeneficiaryRelation"></param>
        /// <param name="BeneficiaryRatio"></param>
        /// <param name="BeneficiaryTel"></param>
        /// <param name="dbTransaction"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-26</lastupdate>
        public int SetPATransBeneficiary(DbProviderHelper db,string JobNo, int InsuredID, int BeneficiaryID, string BeneficiaryTitle, string BeneficiaryName, string BeneficiarySurName, string BeneficiaryRelation, string BeneficiaryRatio, string BeneficiaryTel, DbTransaction dbTransaction)
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();
                DbCommand oDbCommand = db.CreateCommand("spPA_SetTransBeneficiary", CommandType.StoredProcedure, dbTransaction);
                oDbCommand.Parameters.Add(db.CreateParameter("@JobNo", DbType.String, JobNo));
                oDbCommand.Parameters.Add(db.CreateParameter("@InsuredID", DbType.Int32, InsuredID));
                oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiaryID", DbType.Int32, BeneficiaryID));

                if (BeneficiaryTitle != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiaryTitle", DbType.String, BeneficiaryTitle));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiaryTitle", DbType.String, DBNull.Value));
                if (BeneficiaryName != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiaryName", DbType.String, BeneficiaryName));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiaryName", DbType.String, DBNull.Value));
                if (BeneficiarySurName != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiarySurName", DbType.String, BeneficiarySurName));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiarySurName", DbType.String, DBNull.Value));
                if (BeneficiaryRelation != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiaryRelation", DbType.String, BeneficiaryRelation));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiaryRelation", DbType.String, DBNull.Value));
                if (BeneficiaryRatio != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiaryRatio", DbType.String, BeneficiaryRatio));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiaryRatio", DbType.String, DBNull.Value));
                if (BeneficiaryTel != null)
                    oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiaryTel", DbType.String, BeneficiaryTel));
                else
                    oDbCommand.Parameters.Add(db.CreateParameter("@BeneficiaryTel", DbType.String, DBNull.Value));

                return db.ExecuteNonQuery(oDbCommand, true);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
