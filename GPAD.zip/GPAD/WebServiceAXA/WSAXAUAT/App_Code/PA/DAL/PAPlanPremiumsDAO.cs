using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;

namespace PA.DAL
{
    /// <summary>
    /// 
    /// </summary>
    /// <lastupdate>2012-08-24</lastupdate>
	public class PAPlanPremiumsDAO
	{
        DbProviderHelper db;

		public PAPlanPremiumsDAO()
		{
            db = new DbProviderHelper();
            db.GetConnection();
		}

        /// <summary>
        /// GET
        /// </summary>
        /// <param name="PlanCode"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-24</lastupdate>
        public DataTable GetDtPAPlanPremiums(string PlanCode, string OccupationClass)
        {
            try
            {
                //DbProviderHelper dbHelper = new DbProviderHelper();
                // get a configured & create DbCommand object
                DbCommand comm = db.CreateCommand("spPA_getPlanPremium", CommandType.StoredProcedure);
                comm.Parameters.Add(db.CreateParameter("@PlanCode", DbType.String, PlanCode));
                comm.Parameters.Add(db.CreateParameter("@OccupationClass", DbType.String, OccupationClass));
        
                // create DataAdapter object
                DbDataAdapter adap = db.CreateDataAdapter(comm);
                // get data and return with DataTable object
                return db.FillDataTable(adap);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

	}
}
