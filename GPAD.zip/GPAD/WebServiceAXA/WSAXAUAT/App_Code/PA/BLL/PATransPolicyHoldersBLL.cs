using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;
using PA.DAL;

namespace PA.BLL
{
    /// <summary>
    /// 
    /// </summary>
    /// <lastupdate>2012-08-25</lastupdate>
	public class PATransPolicyHoldersBLL
	{
		private PATransPolicyHoldersDAO _PATransPolicyHoldersDAO;

		public PATransPolicyHoldersDAO PATransPolicyHoldersDAO
		{
			get { return _PATransPolicyHoldersDAO; }
			set { _PATransPolicyHoldersDAO = value; }
		}

		public PATransPolicyHoldersBLL()
		{
			PATransPolicyHoldersDAO = new PATransPolicyHoldersDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<PATransPolicyHolders> GetPATransPolicyHolderss()
		{
			try
			{
				return PATransPolicyHoldersDAO.GetPATransPolicyHolderss();
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public PATransPolicyHolders GetPATransPolicyHolders(string JobNo)
		{
			try
			{
				return PATransPolicyHoldersDAO.GetPATransPolicyHolders(JobNo);
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int AddPATransPolicyHolders(string JobNo,string ClientCode,string ClientType,string ClientTitle,string ClientName,string ClientSurName,string AddressNo,string Building,string Soi,string Road,string Tumbol,string Amphur,string Province,string PostCode,string CountryCode,string Birthday,string ClientGender,string ClientStatus,string PassportID,string IDCard,string TaxID,string Tel,string Email,string Language,Nullable<DateTime> CreateDate,string Message)
		{
			try
			{
				return PATransPolicyHoldersDAO.AddPATransPolicyHolders(JobNo,ClientCode,ClientType,ClientTitle,ClientName,ClientSurName,AddressNo,Building,Soi,Road,Tumbol,Amphur,Province,PostCode,CountryCode,Birthday,ClientGender,ClientStatus,PassportID,IDCard,TaxID,Tel,Email,Language,CreateDate,Message);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
		public int UpdatePATransPolicyHolders(string JobNo,string ClientCode,string ClientType,string ClientTitle,string ClientName,string ClientSurName,string AddressNo,string Building,string Soi,string Road,string Tumbol,string Amphur,string Province,string PostCode,string CountryCode,string Birthday,string ClientGender,string ClientStatus,string PassportID,string IDCard,string TaxID,string Tel,string Email,string Language,Nullable<DateTime> CreateDate,string Message)
		{
			try
			{
				return PATransPolicyHoldersDAO.UpdatePATransPolicyHolders(JobNo,ClientCode,ClientType,ClientTitle,ClientName,ClientSurName,AddressNo,Building,Soi,Road,Tumbol,Amphur,Province,PostCode,CountryCode,Birthday,ClientGender,ClientStatus,PassportID,IDCard,TaxID,Tel,Email,Language,CreateDate,Message);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Delete, true)]
		public int RemovePATransPolicyHolders(string JobNo)
		{
			try
			{
				return PATransPolicyHoldersDAO.RemovePATransPolicyHolders(JobNo);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public List<PATransPolicyHolders> GetPATransPolicyHolderssOfPATransPolicies(string JobNo)
		{
			try
			{
				return PATransPolicyHoldersDAO.GetPATransPolicyHolderssOfPATransPolicies(JobNo);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public PATransPolicies GetPATransPoliciesOfPATransPolicyHolders(string JobNo)
		{
			try
			{
				return PATransPolicyHoldersDAO.GetPATransPoliciesOfPATransPolicyHolders(JobNo);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		

        /// <summary>
        /// Set data with "spPA_SetTransPolicyHolder"
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="InsurerID"></param>
        /// <param name="ClientType"></param>
        /// <param name="ClientTitle"></param>
        /// <param name="ClientName"></param>
        /// <param name="ClientSurName"></param>
        /// <param name="AddressNo"></param>
        /// <param name="Building"></param>
        /// <param name="Soi"></param>
        /// <param name="Road"></param>
        /// <param name="Province"></param>
        /// <param name="Amphur"></param>
        /// <param name="Tumbol"></param>
        /// <param name="PostCode"></param>
        /// <param name="Birthday"></param>
        /// <param name="Gender"></param>
        /// <param name="Status"></param>
        /// <param name="Nationality"></param>
        /// <param name="IDCard"></param>
        /// <param name="Tel"></param>
        /// <param name="Email"></param>
        /// <param name="Lang"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-25</lastupdate>
        public int SetPATransPolicyHolders(string JobNo, int InsurerID, string ClientType, string ClientTitle, string ClientName, string ClientSurName, string AddressNo, string Building, string Soi, string Road, string Province, string Amphur, string Tumbol, string PostCode, string Birthday, string Gender, string Status, string Nationality, string IDCard, string Tel, string Email, string Lang, string BranchNo)
        {
            try
            {
                return PATransPolicyHoldersDAO.SetPATransPolicyHolders(JobNo, InsurerID, ClientType, ClientTitle, ClientName, ClientSurName, AddressNo, Building, Soi, Road, Province, Amphur, Tumbol, PostCode, Birthday, Gender, Status, Nationality, IDCard, Tel, Email, Lang, BranchNo);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Set data by "spPA_SetTransPolicyHolder" with transaction
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="InsurerID"></param>
        /// <param name="ClientType"></param>
        /// <param name="ClientTitle"></param>
        /// <param name="ClientName"></param>
        /// <param name="ClientSurName"></param>
        /// <param name="AddressNo"></param>
        /// <param name="Building"></param>
        /// <param name="Soi"></param>
        /// <param name="Road"></param>
        /// <param name="Province"></param>
        /// <param name="Amphur"></param>
        /// <param name="Tumbol"></param>
        /// <param name="PostCode"></param>
        /// <param name="Birthday"></param>
        /// <param name="Gender"></param>
        /// <param name="Status"></param>
        /// <param name="Nationality"></param>
        /// <param name="IDCard"></param>
        /// <param name="Tel"></param>
        /// <param name="Email"></param>
        /// <param name="Lang"></param>
        /// <param name="dbTransaction"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-25</lastupdate>
        public int SetPATransPolicyHolders(DbProviderHelper db,string JobNo, int InsurerID, string ClientType, string ClientTitle, string ClientName, string ClientSurName, string AddressNo, string Building, string Soi, string Road, string Province, string Amphur, string Tumbol, string PostCode, string Birthday, string Gender, string Status, string Nationality, string IDCard, string Tel, string Email, string Lang, string BranchNo, DbTransaction dbTransaction)
        {
            try
            {
                return PATransPolicyHoldersDAO.SetPATransPolicyHolders(db,JobNo, InsurerID, ClientType, ClientTitle, ClientName, ClientSurName, AddressNo, Building, Soi, Road, Province, Amphur, Tumbol, PostCode, Birthday, Gender, Status, Nationality, IDCard, Tel, Email, Lang, BranchNo, dbTransaction);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
	}
}
