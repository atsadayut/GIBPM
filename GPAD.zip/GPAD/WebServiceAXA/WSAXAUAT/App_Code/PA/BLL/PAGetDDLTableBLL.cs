using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;
using PA.DAL;

namespace PA.BLL
{
    /// <summary>
    /// 
    /// </summary>
    /// <lastupdate>2012-08-24</lastupdate>
    public class PAGetDDLTableBLL
    {
        private PAGetDDLTableDAO _PAGetDDLTableDAO;
        public PAGetDDLTableDAO PAGetDDLTableDAO
        {
            get { return _PAGetDDLTableDAO; }
            set { _PAGetDDLTableDAO = value; }
        }


        /// <summary>
        /// Constructor
        /// </summary>
        public PAGetDDLTableBLL()
        {
            PAGetDDLTableDAO = new PAGetDDLTableDAO();
        }

        /// <summary>
        /// Get data from "spPA_getDDLGender"
        /// </summary>
        /// <param name="LANG"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-24</lastupdate>
        public DataTable GetDDLGender(string LANG)
        {
            try
            {
                return PAGetDDLTableDAO.GetDDLGender(LANG);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get data from "spPA_getDDLMarried"
        /// </summary>
        /// <param name="LANG"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-24</lastupdate>
        public DataTable GetDDLMarried(string LANG)
        {
            try
            {
                return PAGetDDLTableDAO.GetDDLMarried(LANG);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get data from "spPA_getDDLNationality"
        /// </summary>
        /// <param name="LANG"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-24</lastupdate>
        public DataTable GetDDLNationality(string LANG)
        {
            try
            {
                return PAGetDDLTableDAO.GetDDLNationality(LANG);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get data from "spPA_getDDLPackageByPackageID"
        /// </summary>
        /// <param name="PACKAGEID"></param>
        /// <param name="LANG"></param>
        /// <returns></returns>
        /// <lastupdate>2015-07-16</lastupdate>
        public DataTable GetDDLPackageByPackageID(string PACKAGEID, string LANG)
        {
            try
            {
                return PAGetDDLTableDAO.GetDDLPackageByPackageID(PACKAGEID, LANG);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
      
        /// <summary>
        /// Get data from "spPA_getDDLPackage"
        /// </summary>
        /// <param name="AGE"></param>
        /// <param name="LANG"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-24</lastupdate>
        public DataTable GetDDLPackage(int AGE, string LANG)
        {
            try
            {
                return PAGetDDLTableDAO.GetDDLPackage(AGE,LANG);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get data from "spPA_getDDLPlan"
        /// </summary>
        /// <param name="PackageID"></param>
        /// <param name="lang"></param>
        /// <param name="OccupationClass"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-24</lastupdate>        
        public DataTable GetDDLPlan(string PackageID, string lang, string occupationClass)
        {
            try
            {
                return PAGetDDLTableDAO.GetDDLPlan(PackageID, lang, occupationClass);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get data from "spPA_getDDLRelation"
        /// </summary>
        /// <param name="LANG"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-24</lastupdate>
        public DataTable GetDDLRelation(string LANG)
        {
            try
            {
                return PAGetDDLTableDAO.GetDDLRelation(LANG);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get data from "spPA_getDDLTitle"
        /// </summary>
        /// <param name="LANG"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-24</lastupdate>
        public DataTable GetDDLTitle(string LANG)
        {
            try
            {
                return PAGetDDLTableDAO.GetDDLTitle(LANG);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get data from "spPA_getDDLPAOccupation"
        /// </summary>
        /// <param name="LANG"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-24</lastupdate>
        public DataTable GetDDLPAOccupation(string LANG)
        {
            try
            {
                return PAGetDDLTableDAO.GetDDLPAOccupation(LANG);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
