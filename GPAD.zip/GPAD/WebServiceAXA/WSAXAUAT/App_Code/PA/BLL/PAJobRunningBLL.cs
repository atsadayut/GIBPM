using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;
using PA.DAL;

namespace PA.BLL
{
	public class PAJobRunningBLL
	{
		private PAJobRunningDAO _PAJobRunningDAO;

		public PAJobRunningDAO PAJobRunningDAO
		{
			get { return _PAJobRunningDAO; }
			set { _PAJobRunningDAO = value; }
		}

		public PAJobRunningBLL()
		{
			PAJobRunningDAO = new PAJobRunningDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
        /// <summary>
        /// GET/SET JOB NUMBER
        /// </summary>
        /// <returns></returns>
        public string GetPAJobRunningNumber()
        {
            try
            {
                return PAJobRunningDAO.GetPAJobRunningNumber();
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

        public string GetPAJobRunningNumber(DbTransaction dbTransaction)
        {
            try
            {
                return PAJobRunningDAO.GetPAJobRunningNumber(dbTransaction);
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                throw ex;
            }
        }

	}
}
