using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;
using PA.DAL;

namespace PA.BLL
{
	public class PAPlanPackagesBLL
	{
		private PAPlanPackagesDAO _PAPlanPackagesDAO;

		public PAPlanPackagesDAO PAPlanPackagesDAO
		{
			get { return _PAPlanPackagesDAO; }
			set { _PAPlanPackagesDAO = value; }
		}

		public PAPlanPackagesBLL()
		{
			PAPlanPackagesDAO = new PAPlanPackagesDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public PAPlanPackages GetPAPlanPackages(string PackageID)
		{
			try
			{
				return PAPlanPackagesDAO.GetPAPlanPackages(PackageID);
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		
	}
}
