using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;
using PA.DAL;

namespace PA.BLL
{
	/// <summary>
	/// 
	/// </summary>
    /// <lastupdate>2012-08-24</lastupdate>
    public class PATransPolicyInsuredsBLL
	{
		private PATransPolicyInsuredsDAO _PATransPolicyInsuredsDAO;

		public PATransPolicyInsuredsDAO PATransPolicyInsuredsDAO
		{
			get { return _PATransPolicyInsuredsDAO; }
			set { _PATransPolicyInsuredsDAO = value; }
		}

		public PATransPolicyInsuredsBLL()
		{
			PATransPolicyInsuredsDAO = new PATransPolicyInsuredsDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<PATransPolicyInsureds> GetPATransPolicyInsuredss()
		{
			try
			{
				return PATransPolicyInsuredsDAO.GetPATransPolicyInsuredss();
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public PATransPolicyInsureds GetPATransPolicyInsureds(string JobNo,int InsuredID)
		{
			try
			{
				return PATransPolicyInsuredsDAO.GetPATransPolicyInsureds(JobNo,InsuredID);
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int AddPATransPolicyInsureds(string JobNo,int InsuredID,string ClientCode,string ClientTitle,string ClientName,string ClientSurName,string Birthday,string IDCard,string PassportID,string Tel,Nullable<int> SumInsuredPA2,Nullable<int> SumInsuredME,Nullable<int> PremiumPA2,Nullable<int> PremiumME,Nullable<int> AddPremium,Nullable<int> GrossPremium,Nullable<int> Stamp,Nullable<int> SBT,Nullable<int> TotalPremium,Nullable<SByte> isBeneficiary,Nullable<SByte> isStudent,Nullable<SByte> isSingle,Nullable<DateTime> CreateDate,string Message)
		{
			try
			{
				return PATransPolicyInsuredsDAO.AddPATransPolicyInsureds(JobNo,InsuredID,ClientCode,ClientTitle,ClientName,ClientSurName,Birthday,IDCard,PassportID,Tel,SumInsuredPA2,SumInsuredME,PremiumPA2,PremiumME,AddPremium,GrossPremium,Stamp,SBT,TotalPremium,isBeneficiary,isStudent,isSingle,CreateDate,Message);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
		public int UpdatePATransPolicyInsureds(string JobNo,int InsuredID,string ClientCode,string ClientTitle,string ClientName,string ClientSurName,string Birthday,string IDCard,string PassportID,string Tel,Nullable<int> SumInsuredPA2,Nullable<int> SumInsuredME,Nullable<int> PremiumPA2,Nullable<int> PremiumME,Nullable<int> AddPremium,Nullable<int> GrossPremium,Nullable<int> Stamp,Nullable<int> SBT,Nullable<int> TotalPremium,Nullable<SByte> isBeneficiary,Nullable<SByte> isStudent,Nullable<SByte> isSingle,Nullable<DateTime> CreateDate,string Message)
		{
			try
			{
				return PATransPolicyInsuredsDAO.UpdatePATransPolicyInsureds(JobNo,InsuredID,ClientCode,ClientTitle,ClientName,ClientSurName,Birthday,IDCard,PassportID,Tel,SumInsuredPA2,SumInsuredME,PremiumPA2,PremiumME,AddPremium,GrossPremium,Stamp,SBT,TotalPremium,isBeneficiary,isStudent,isSingle,CreateDate,Message);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Delete, true)]
		public int RemovePATransPolicyInsureds(string JobNo,int InsuredID)
		{
			try
			{
				return PATransPolicyInsuredsDAO.RemovePATransPolicyInsureds(JobNo,InsuredID);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public List<PATransPolicyInsureds> GetPATransPolicyInsuredssOfPATransPolicyHolders(string JobNo)
		{
			try
			{
				return PATransPolicyInsuredsDAO.GetPATransPolicyInsuredssOfPATransPolicyHolders(JobNo);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		public PATransPolicyHolders GetPATransPolicyHoldersOfPATransPolicyInsureds(string JobNo)
		{
			try
			{
				return PATransPolicyInsuredsDAO.GetPATransPolicyHoldersOfPATransPolicyInsureds(JobNo);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		

        /// <summary>
        /// Set data by "spPA_SetTransPolicyInsured"
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="InsuredID"></param>
        /// <param name="ClientCode"></param>
        /// <param name="ClientTitle"></param>
        /// <param name="ClientName"></param>
        /// <param name="ClientSurName"></param>
        /// <param name="Birthday"></param>
        /// <param name="IDCard"></param>
        /// <param name="Tel"></param>
        /// <param name="SumInsuredPA2"></param>
        /// <param name="SumInsuredME"></param>
        /// <param name="PremiumPA2"></param>
        /// <param name="PremiumME"></param>
        /// <param name="AddPremium"></param>
        /// <param name="GrossPremium"></param>
        /// <param name="Stamp"></param>
        /// <param name="SBT"></param>
        /// <param name="TotalPremium"></param>
        /// <param name="isBeneficiary"></param>
        /// <param name="isStudent"></param>
        /// <param name="isSingle"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-26</lastupdate>
        public int SetPATransPolicyInsureds(string JobNo, int InsuredID, string ClientCode, string ClientTitle, string ClientName, string ClientSurName, string Birthday, string IDCard, string Tel, Nullable<int> SumInsuredPA2, Nullable<int> SumInsuredME, Nullable<int> PremiumPA2, Nullable<int> PremiumME, Nullable<int> AddPremium, Nullable<int> GrossPremium, Nullable<int> Stamp, Nullable<int> SBT, Nullable<int> TotalPremium, Nullable<SByte> isBeneficiary, Nullable<SByte> isStudent, Nullable<SByte> isSingle)
        {
            try
            {
                return PATransPolicyInsuredsDAO.SetPATransPolicyInsureds(JobNo, InsuredID, ClientCode, ClientTitle, ClientName, ClientSurName, Birthday, IDCard, Tel, SumInsuredPA2, SumInsuredME, PremiumPA2, PremiumME, AddPremium, GrossPremium, Stamp, SBT, TotalPremium, isBeneficiary, isStudent, isSingle);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Set data by "spPA_SetTransPolicyInsured" with transaction
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="InsuredID"></param>
        /// <param name="ClientCode"></param>
        /// <param name="ClientTitle"></param>
        /// <param name="ClientName"></param>
        /// <param name="ClientSurName"></param>
        /// <param name="Birthday"></param>
        /// <param name="IDCard"></param>
        /// <param name="Tel"></param>
        /// <param name="SumInsuredPA2"></param>
        /// <param name="SumInsuredME"></param>
        /// <param name="PremiumPA2"></param>
        /// <param name="PremiumME"></param>
        /// <param name="AddPremium"></param>
        /// <param name="GrossPremium"></param>
        /// <param name="Stamp"></param>
        /// <param name="SBT"></param>
        /// <param name="TotalPremium"></param>
        /// <param name="isBeneficiary"></param>
        /// <param name="isStudent"></param>
        /// <param name="isSingle"></param>
        /// <param name="dbTransaction"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-26</lastupdate>
        public int SetPATransPolicyInsureds(DbProviderHelper db ,string JobNo, int InsuredID, string ClientCode, string ClientTitle, string ClientName, string ClientSurName, string Birthday, string IDCard, string Tel, Nullable<int> SumInsuredPA2, Nullable<int> SumInsuredME, Nullable<int> PremiumPA2, Nullable<int> PremiumME, Nullable<int> AddPremium, Nullable<int> GrossPremium, Nullable<int> Stamp, Nullable<int> SBT, Nullable<int> TotalPremium, Nullable<SByte> isBeneficiary, Nullable<SByte> isStudent, Nullable<SByte> isSingle, Nullable<decimal> SumPercent, Nullable<decimal> PremiumPercent, string PackageID, string PlanCode, DbTransaction dbTransaction)
        {
            try
            {
                return PATransPolicyInsuredsDAO.SetPATransPolicyInsureds(db,JobNo, InsuredID, ClientCode, ClientTitle, ClientName, ClientSurName, Birthday, IDCard, Tel, SumInsuredPA2, SumInsuredME, PremiumPA2, PremiumME, AddPremium, GrossPremium, Stamp, SBT, TotalPremium, isBeneficiary, isStudent, isSingle, SumPercent, PremiumPercent, PackageID, PlanCode, dbTransaction);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Set data by "spPA_SetTransPolicyInsuredFlagClear" with transaction
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="InsuredID"></param>
        /// <param name="ClientCode"></param>
        /// <param name="ClientTitle"></param>
        /// <param name="ClientName"></param>
        /// <param name="ClientSurName"></param>
        /// <param name="Birthday"></param>
        /// <param name="IDCard"></param>
        /// <param name="Tel"></param>
        /// <param name="SumInsuredPA2"></param>
        /// <param name="SumInsuredME"></param>
        /// <param name="PremiumPA2"></param>
        /// <param name="PremiumME"></param>
        /// <param name="AddPremium"></param>
        /// <param name="GrossPremium"></param>
        /// <param name="Stamp"></param>
        /// <param name="SBT"></param>
        /// <param name="TotalPremium"></param>
        /// <param name="isBeneficiary"></param>
        /// <param name="isStudent"></param>
        /// <param name="isSingle"></param>
        /// <param name="SumPercent"></param>
        /// <param name="PremiumPercent"></param>
        /// <param name="PackageID"></param>
        /// <param name="PlanCode"></param>
        /// <param name="FlagClearPremium"></param>
        /// <param name="dbTransaction"></param>
        /// <param name="dbTransaction"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-26</lastupdate>
        public int SetPATransPolicyInsureds(DbProviderHelper db,string JobNo, int InsuredID, string ClientCode, string ClientTitle, string ClientName, string ClientSurName, string Birthday, string IDCard, string Tel, Nullable<int> SumInsuredPA2, Nullable<int> SumInsuredME, Nullable<int> PremiumPA2, Nullable<int> PremiumME, Nullable<int> AddPremium, Nullable<int> GrossPremium, Nullable<int> Stamp, Nullable<int> SBT, Nullable<int> TotalPremium, Nullable<SByte> isBeneficiary, Nullable<SByte> isStudent, Nullable<SByte> isSingle, Nullable<decimal> SumPercent, Nullable<decimal> PremiumPercent, string PackageID, string PlanCode, bool FlagClearPremium, DbTransaction dbTransaction)
        {
            try
            {
                return PATransPolicyInsuredsDAO.SetPATransPolicyInsureds(db,JobNo, InsuredID, ClientCode, ClientTitle, ClientName, ClientSurName, Birthday, IDCard, Tel, SumInsuredPA2, SumInsuredME, PremiumPA2, PremiumME, AddPremium, GrossPremium, Stamp, SBT, TotalPremium, isBeneficiary, isStudent, isSingle, SumPercent, PremiumPercent, PackageID, PlanCode, FlagClearPremium, dbTransaction);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



	}
}
