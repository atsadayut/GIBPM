using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;
using PA.DAL;

namespace PA.BLL
{
    /// <summary>
    /// 
    /// </summary>
    /// <lastupdate>2012-08-25</lastupdate>
	public class PATransLongNamesBLL
	{
		private PATransLongNamesDAO _PATransLongNamesDAO;

		public PATransLongNamesDAO PATransLongNamesDAO
		{
			get { return _PATransLongNamesDAO; }
			set { _PATransLongNamesDAO = value; }
		}

		public PATransLongNamesBLL()
		{
			PATransLongNamesDAO = new PATransLongNamesDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public List<PATransLongNames> GetPATransLongNamess()
		{
			try
			{
				return PATransLongNamesDAO.GetPATransLongNamess();
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public PATransLongNames GetPATransLongNames(string JobNo)
		{
			try
			{
				return PATransLongNamesDAO.GetPATransLongNames(JobNo);
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Insert, true)]
		public int AddPATransLongNames(string JobNo,string LongName1,string LongName2,string LongName3,string LongName4,string Message)
		{
			try
			{
				return PATransLongNamesDAO.AddPATransLongNames(JobNo,LongName1,LongName2,LongName3,LongName4,Message);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
		public int UpdatePATransLongNames(string JobNo,string LongName1,string LongName2,string LongName3,string LongName4,string Message)
		{
			try
			{
				return PATransLongNamesDAO.UpdatePATransLongNames(JobNo,LongName1,LongName2,LongName3,LongName4,Message);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Delete, true)]
		public int RemovePATransLongNames(string JobNo)
		{
			try
			{
				return PATransLongNamesDAO.RemovePATransLongNames(JobNo);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		

        /// <summary>
        /// Set data by "spPA_SetTransLongName" 
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="LongName1"></param>
        /// <param name="LongName2"></param>
        /// <param name="LongName3"></param>
        /// <param name="LongName4"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-25</lastupdate>
        public int SetPATransLongName(string JobNo, string LongName1, string LongName2, string LongName3, string LongName4)
        {
            try
            {
                return PATransLongNamesDAO.SetPATransLongName(JobNo, LongName1, LongName2, LongName3, LongName4);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Set data by "spPA_SetTransLongName" with transaction
        /// </summary>
        /// <param name="JobNo"></param>
        /// <param name="LongName1"></param>
        /// <param name="LongName2"></param>
        /// <param name="LongName3"></param>
        /// <param name="LongName4"></param>
        /// <param name="dbTransaction"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-25</lastupdate>
        public int SetPATransLongName(string JobNo, string LongName1, string LongName2, string LongName3, string LongName4, DbTransaction dbTransaction)
        {
            try
            {
                return PATransLongNamesDAO.SetPATransLongName(JobNo, LongName1, LongName2, LongName3, LongName4, dbTransaction);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
	}
}
