using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;
using PA.DAL;

namespace PA.BLL
{
	public class PAB2CPolicyNoBLL
	{
		private PAB2CPolicyNoDAO _TAB2CPolicyNoDAO;

		public PAB2CPolicyNoDAO PAB2CPolicyNoDAO
		{
			get { return _TAB2CPolicyNoDAO; }
			set { _TAB2CPolicyNoDAO = value; }
		}

		public PAB2CPolicyNoBLL()
		{
			PAB2CPolicyNoDAO = new PAB2CPolicyNoDAO();
		}
        [System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
        public string spPAB2C_SetPolicyNo()
        {
            try
            {
                return PAB2CPolicyNoDAO.spPAB2C_SetPolicyNo();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
        public string spPAB2C_SetPolicyNo(string JobNo, string Prefix)
        {
            try
            {
                return PAB2CPolicyNoDAO.spPAB2C_SetPolicyNo(JobNo, Prefix);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Update, true)]
        public int spTAB2C_UpdatePolicyNoToJobNo(string JobNo, string PolicyNo, string RETURNINV)
        {
            try
            {
                return PAB2CPolicyNoDAO.spPAB2C_UpdatePolicyNoToJobNo(JobNo, PolicyNo, RETURNINV);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //Makkawat Update 20150811
        public DataTable spPAB2C_FindPolicyNoByRef(string RETURNINV)
        {
            try
            {
                return PAB2CPolicyNoDAO.spPAB2C_FindPolicyNoByRef(RETURNINV);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //Makkawat Update 20150811
        public DataTable spPAB2C_FindPolicyHoldersNameByJobNo(string RETURNINV)
        {
            try
            {
                return PAB2CPolicyNoDAO.spPAB2C_FindPolicyHoldersNameByJobNo(RETURNINV);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

	}
}
