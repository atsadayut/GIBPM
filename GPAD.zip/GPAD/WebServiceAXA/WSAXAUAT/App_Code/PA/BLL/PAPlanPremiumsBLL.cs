using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;
using PA.DAL;

namespace PA.BLL
{
    /// <summary>
    /// 
    /// </summary>
    /// <lastupdate>2012-08-24</lastupdate>
	public class PAPlanPremiumsBLL
	{
		private PAPlanPremiumsDAO _PAPlanPremiumsDAO;

		public PAPlanPremiumsDAO PAPlanPremiumsDAO
		{
			get { return _PAPlanPremiumsDAO; }
			set { _PAPlanPremiumsDAO = value; }
		}

		public PAPlanPremiumsBLL()
		{
			PAPlanPremiumsDAO = new PAPlanPremiumsDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]

        /// <summary>
        /// Get data from "spPA_getPlanPremium"
        /// </summary>
        /// <param name="PlanCode"></param>
        /// <returns></returns>
        /// <lastupdate>2012-08-24</lastupdate>
        public DataTable GetDtPAPlanPremiums(string PlanCode, string OccupationClass)
        {
            try
            {
                return PAPlanPremiumsDAO.GetDtPAPlanPremiums(PlanCode, OccupationClass);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
	}
}
