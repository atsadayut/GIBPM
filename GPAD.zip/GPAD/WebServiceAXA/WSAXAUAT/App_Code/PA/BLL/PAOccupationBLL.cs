using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using PA.BusinessObjects;
using PA.DAL;

namespace PA.BLL
{
	public class PAOccupationBLL
	{
		private PAOccupationDAO _PAOccupationDAO;

		public PAOccupationDAO PAOccupationDAO
		{
			get { return _PAOccupationDAO; }
			set { _PAOccupationDAO = value; }
		}

		public PAOccupationBLL()
		{
			PAOccupationDAO = new PAOccupationDAO();
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, true)]
		public PAOccupation GetPAOccupation(string lang,string occupationDesc)
		{
			try
			{
                return PAOccupationDAO.GetPAOccupation(lang, occupationDesc);
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		[System.ComponentModel.DataObjectMethodAttribute(System.ComponentModel.DataObjectMethodType.Select, false)]
		public PAOccupation GetPAOccupation(int OccupationID)
		{
			try
			{
				return PAOccupationDAO.GetPAOccupation(OccupationID);
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}
		
	}
}
