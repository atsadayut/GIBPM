using System;
using System.Text;

namespace PA.BusinessObjects
{
	[Serializable()]
	public class PAJobRunning
	{
		private string _PREFIX;

		public string PREFIX
		{
			get { return _PREFIX; }
			set { _PREFIX = value; }
		}

		private int _YEAR;

		public int YEAR
		{
			get { return _YEAR; }
			set { _YEAR = value; }
		}

		private int _MONTH;

		public int MONTH
		{
			get { return _MONTH; }
			set { _MONTH = value; }
		}

		private string _RUNNING;

		public string RUNNING
		{
			get { return _RUNNING; }
			set { _RUNNING = value; }
		}

		public PAJobRunning()
		{ }

		public PAJobRunning(string PREFIX,int YEAR,int MONTH,string RUNNING)
		{
			this.PREFIX = PREFIX;
			this.YEAR = YEAR;
			this.MONTH = MONTH;
			this.RUNNING = RUNNING;
		}

		public override string ToString()
		{
			return "PREFIX = " + PREFIX + ",YEAR = " + YEAR.ToString() + ",MONTH = " + MONTH.ToString() + ",RUNNING = " + RUNNING;
		}

		public class PREFIXComparer : System.Collections.Generic.IComparer<PAJobRunning>
		{
			public SorterMode SorterMode;
			public PREFIXComparer()
			{ }
			public PREFIXComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<PAJobRunning> Membres
			int System.Collections.Generic.IComparer<PAJobRunning>.Compare(PAJobRunning x, PAJobRunning y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PREFIX.CompareTo(x.PREFIX);
				}
				else
				{
					return x.PREFIX.CompareTo(y.PREFIX);
				}
			}
			#endregion
		}
		public class YEARComparer : System.Collections.Generic.IComparer<PAJobRunning>
		{
			public SorterMode SorterMode;
			public YEARComparer()
			{ }
			public YEARComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<PAJobRunning> Membres
			int System.Collections.Generic.IComparer<PAJobRunning>.Compare(PAJobRunning x, PAJobRunning y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.YEAR.CompareTo(x.YEAR);
				}
				else
				{
					return x.YEAR.CompareTo(y.YEAR);
				}
			}
			#endregion
		}
		public class MONTHComparer : System.Collections.Generic.IComparer<PAJobRunning>
		{
			public SorterMode SorterMode;
			public MONTHComparer()
			{ }
			public MONTHComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<PAJobRunning> Membres
			int System.Collections.Generic.IComparer<PAJobRunning>.Compare(PAJobRunning x, PAJobRunning y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.MONTH.CompareTo(x.MONTH);
				}
				else
				{
					return x.MONTH.CompareTo(y.MONTH);
				}
			}
			#endregion
		}
		public class RUNNINGComparer : System.Collections.Generic.IComparer<PAJobRunning>
		{
			public SorterMode SorterMode;
			public RUNNINGComparer()
			{ }
			public RUNNINGComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<PAJobRunning> Membres
			int System.Collections.Generic.IComparer<PAJobRunning>.Compare(PAJobRunning x, PAJobRunning y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.RUNNING.CompareTo(x.RUNNING);
				}
				else
				{
					return x.RUNNING.CompareTo(y.RUNNING);
				}
			}
			#endregion
		}
	}
}
