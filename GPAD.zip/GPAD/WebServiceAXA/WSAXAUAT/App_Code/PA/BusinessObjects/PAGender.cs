using System;
using System.Text;

namespace PA.BusinessObjects
{
	[Serializable()]
	public class PAGender
	{
		private int _GenderCode;

		public int GenderCode
		{
			get { return _GenderCode; }
			set { _GenderCode = value; }
		}

		private string _Gender;

		public string Gender
		{
			get { return _Gender; }
			set { _Gender = value; }
		}


		public PAGender()
		{ }

        public PAGender(int GenderCode, string Gender)
		{
			this.GenderCode = GenderCode;
			this.Gender = Gender;

		}

		public override string ToString()
		{
			return "GenderCode = " + GenderCode.ToString() + ",Gender = " + Gender;
		}


	}
}
