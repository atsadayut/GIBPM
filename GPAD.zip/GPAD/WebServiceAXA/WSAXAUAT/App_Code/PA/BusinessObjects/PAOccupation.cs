using System;
using System.Text;

namespace PA.BusinessObjects
{
	[Serializable()]
	public class PAOccupation
	{
		private int _OccupationID;

		public int OccupationID
		{
			get { return _OccupationID; }
			set { _OccupationID = value; }
		}

		private string _OccupatnClass;

		public string OccupatnClass
		{
			get { return _OccupatnClass; }
			set { _OccupatnClass = value; }
		}

		private string _DescriptionTH;

		public string DescriptionTH
		{
			get { return _DescriptionTH; }
			set { _DescriptionTH = value; }
		}

		private string _DescriptionEN;

		public string DescriptionEN
		{
			get { return _DescriptionEN; }
			set { _DescriptionEN = value; }
		}

		private string _Remark;

		public string Remark
		{
			get { return _Remark; }
			set { _Remark = value; }
		}

		private Nullable<bool> _Status;

		public Nullable<bool> Status
		{
			get { return _Status; }
			set { _Status = value; }
		}

		public PAOccupation()
		{ }

		public PAOccupation(int OccupationID,string OccupatnClass,string DescriptionTH,string DescriptionEN,string Remark,Nullable<bool> Status)
		{
			this.OccupationID = OccupationID;
			this.OccupatnClass = OccupatnClass;
			this.DescriptionTH = DescriptionTH;
			this.DescriptionEN = DescriptionEN;
			this.Remark = Remark;
			this.Status = Status;
		}

		public override string ToString()
		{
			return "OccupationID = " + OccupationID.ToString() + ",OccupatnClass = " + OccupatnClass + ",DescriptionTH = " + DescriptionTH + ",DescriptionEN = " + DescriptionEN + ",Remark = " + Remark + ",Status = " + Status.ToString();
		}


	}
}
