using System;
using System.Text;

namespace PA.BusinessObjects
{
	public enum SorterMode
	{
		Ascending,
		Descending
	}
}
