using System;
using System.Text;

namespace PA.BusinessObjects
{
	[Serializable()]
	public class PAPackage
	{
		private int _PackageID;

		public int PackageID
		{
			get { return _PackageID; }
			set { _PackageID = value; }
		}

        private string _PackageName;

		public string PackageName
		{
            get { return _PackageName; }
            set { _PackageName = value; }
		}


		public PAPackage()
		{ }

        public PAPackage(int PackageID, string PackageName)
		{
			this.PackageID = PackageID;
            this.PackageName = PackageName;

		}

		public override string ToString()
		{
            return "PackageID = " + PackageID.ToString() + ",PackageName = " + PackageName;
		}


	}
}
