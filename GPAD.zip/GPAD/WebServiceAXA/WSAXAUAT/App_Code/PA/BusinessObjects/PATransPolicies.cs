using System;
using System.Text;

namespace PA.BusinessObjects
{
	[Serializable()]
	public class PATransPolicies
	{
		private string _JobNo;

		public string JobNo
		{
			get { return _JobNo; }
			set { _JobNo = value; }
		}

		private string _PolicyNo;

		public string PolicyNo
		{
			get { return _PolicyNo; }
			set { _PolicyNo = value; }
		}

		private string _PackageID;

		public string PackageID
		{
			get { return _PackageID; }
			set { _PackageID = value; }
		}

		private string _PlanCode;

		public string PlanCode
		{
			get { return _PlanCode; }
			set { _PlanCode = value; }
		}

		private string _InceptionDate;

		public string InceptionDate
		{
			get { return _InceptionDate; }
			set { _InceptionDate = value; }
		}

		private string _ExpiryDate;

		public string ExpiryDate
		{
			get { return _ExpiryDate; }
			set { _ExpiryDate = value; }
		}

		private string _ContractType;

		public string ContractType
		{
			get { return _ContractType; }
			set { _ContractType = value; }
		}

		private string _RiskType;

		public string RiskType
		{
			get { return _RiskType; }
			set { _RiskType = value; }
		}

		private string _PremiumClass;

		public string PremiumClass
		{
			get { return _PremiumClass; }
			set { _PremiumClass = value; }
		}

		private string _AgentCode;

		public string AgentCode
		{
			get { return _AgentCode; }
			set { _AgentCode = value; }
		}

		private string _StaffCode;

		public string StaffCode
		{
			get { return _StaffCode; }
			set { _StaffCode = value; }
		}

		private string _OccupatnClass;

		public string OccupatnClass
		{
			get { return _OccupatnClass; }
			set { _OccupatnClass = value; }
		}

		private string _OccupatnDestination;

		public string OccupatnDestination
		{
			get { return _OccupatnDestination; }
			set { _OccupatnDestination = value; }
		}

		private Nullable<int> _NoOfChildren;

		public Nullable<int> NoOfChildren
		{
			get { return _NoOfChildren; }
			set { _NoOfChildren = value; }
		}

		private Nullable<int> _GrossPremium;

		public Nullable<int> GrossPremium
		{
			get { return _GrossPremium; }
			set { _GrossPremium = value; }
		}

		private Nullable<int> _Stamp;

		public Nullable<int> Stamp
		{
			get { return _Stamp; }
			set { _Stamp = value; }
		}

		private Nullable<int> _SBT;

		public Nullable<int> SBT
		{
			get { return _SBT; }
			set { _SBT = value; }
		}

		private Nullable<int> _TotalPremium;

		public Nullable<int> TotalPremium
		{
			get { return _TotalPremium; }
			set { _TotalPremium = value; }
		}

		private string _PreprintedClauses1;

		public string PreprintedClauses1
		{
			get { return _PreprintedClauses1; }
			set { _PreprintedClauses1 = value; }
		}

		private string _PreprintedClauses2;

		public string PreprintedClauses2
		{
			get { return _PreprintedClauses2; }
			set { _PreprintedClauses2 = value; }
		}

		private string _PreprintedClauses3;

		public string PreprintedClauses3
		{
			get { return _PreprintedClauses3; }
			set { _PreprintedClauses3 = value; }
		}

		private string _ClauseCodes1;

		public string ClauseCodes1
		{
			get { return _ClauseCodes1; }
			set { _ClauseCodes1 = value; }
		}

		private string _ClauseCodes2;

		public string ClauseCodes2
		{
			get { return _ClauseCodes2; }
			set { _ClauseCodes2 = value; }
		}

		private string _ClauseCodes3;

		public string ClauseCodes3
		{
			get { return _ClauseCodes3; }
			set { _ClauseCodes3 = value; }
		}

		private Nullable<SByte> _isLongName;

		public Nullable<SByte> isLongName
		{
			get { return _isLongName; }
			set { _isLongName = value; }
		}

		private string _GroupBrokerID;

		public string GroupBrokerID
		{
			get { return _GroupBrokerID; }
			set { _GroupBrokerID = value; }
		}

		private Nullable<DateTime> _CreatedDate;

		public Nullable<DateTime> CreatedDate
		{
			get { return _CreatedDate; }
			set { _CreatedDate = value; }
		}

		private string _CreatedUser;

		public string CreatedUser
		{
			get { return _CreatedUser; }
			set { _CreatedUser = value; }
		}

		private Nullable<DateTime> _ModifiedDate;

		public Nullable<DateTime> ModifiedDate
		{
			get { return _ModifiedDate; }
			set { _ModifiedDate = value; }
		}

		private string _ModifiedUser;

		public string ModifiedUser
		{
			get { return _ModifiedUser; }
			set { _ModifiedUser = value; }
		}

		private string _Message;

		public string Message
		{
			get { return _Message; }
			set { _Message = value; }
		}

		public PATransPolicies()
		{ }

		public PATransPolicies(string JobNo,string PolicyNo,string PackageID,string PlanCode,string InceptionDate,string ExpiryDate,string ContractType,string RiskType,string PremiumClass,string AgentCode,string StaffCode,string OccupatnClass,string OccupatnDestination,Nullable<int> NoOfChildren,Nullable<int> GrossPremium,Nullable<int> Stamp,Nullable<int> SBT,Nullable<int> TotalPremium,string PreprintedClauses1,string PreprintedClauses2,string PreprintedClauses3,string ClauseCodes1,string ClauseCodes2,string ClauseCodes3,Nullable<SByte> isLongName,string GroupBrokerID,Nullable<DateTime> CreatedDate,string CreatedUser,Nullable<DateTime> ModifiedDate,string ModifiedUser,string Message)
		{
			this.JobNo = JobNo;
			this.PolicyNo = PolicyNo;
			this.PackageID = PackageID;
			this.PlanCode = PlanCode;
			this.InceptionDate = InceptionDate;
			this.ExpiryDate = ExpiryDate;
			this.ContractType = ContractType;
			this.RiskType = RiskType;
			this.PremiumClass = PremiumClass;
			this.AgentCode = AgentCode;
			this.StaffCode = StaffCode;
			this.OccupatnClass = OccupatnClass;
			this.OccupatnDestination = OccupatnDestination;
			this.NoOfChildren = NoOfChildren;
			this.GrossPremium = GrossPremium;
			this.Stamp = Stamp;
			this.SBT = SBT;
			this.TotalPremium = TotalPremium;
			this.PreprintedClauses1 = PreprintedClauses1;
			this.PreprintedClauses2 = PreprintedClauses2;
			this.PreprintedClauses3 = PreprintedClauses3;
			this.ClauseCodes1 = ClauseCodes1;
			this.ClauseCodes2 = ClauseCodes2;
			this.ClauseCodes3 = ClauseCodes3;
			this.isLongName = isLongName;
			this.GroupBrokerID = GroupBrokerID;
			this.CreatedDate = CreatedDate;
			this.CreatedUser = CreatedUser;
			this.ModifiedDate = ModifiedDate;
			this.ModifiedUser = ModifiedUser;
			this.Message = Message;
		}

		public override string ToString()
		{
			return "JobNo = " + JobNo + ",PolicyNo = " + PolicyNo + ",PackageID = " + PackageID + ",PlanCode = " + PlanCode + ",InceptionDate = " + InceptionDate + ",ExpiryDate = " + ExpiryDate + ",ContractType = " + ContractType + ",RiskType = " + RiskType + ",PremiumClass = " + PremiumClass + ",AgentCode = " + AgentCode + ",StaffCode = " + StaffCode + ",OccupatnClass = " + OccupatnClass + ",OccupatnDestination = " + OccupatnDestination + ",NoOfChildren = " + NoOfChildren.ToString() + ",GrossPremium = " + GrossPremium.ToString() + ",Stamp = " + Stamp.ToString() + ",SBT = " + SBT.ToString() + ",TotalPremium = " + TotalPremium.ToString() + ",PreprintedClauses1 = " + PreprintedClauses1 + ",PreprintedClauses2 = " + PreprintedClauses2 + ",PreprintedClauses3 = " + PreprintedClauses3 + ",ClauseCodes1 = " + ClauseCodes1 + ",ClauseCodes2 = " + ClauseCodes2 + ",ClauseCodes3 = " + ClauseCodes3 + ",isLongName = " + isLongName.ToString() + ",GroupBrokerID = " + GroupBrokerID + ",CreatedDate = " + CreatedDate.ToString() + ",CreatedUser = " + CreatedUser + ",ModifiedDate = " + ModifiedDate.ToString() + ",ModifiedUser = " + ModifiedUser + ",Message = " + Message;
		}

		
	}
}
