using System;
using System.Text;

namespace PA.BusinessObjects
{
	[Serializable()]
	public class PAPlanCoverages
	{

		private string _CoverageName;

		public string CoverageName
		{
			get { return _CoverageName; }
			set { _CoverageName = value; }
		}

        private string _CoverageAmount;

        public string CoverageAmount
		{
            get { return _CoverageAmount; }
            set { _CoverageAmount = value; }
		}


		public PAPlanCoverages()
		{ }

        public PAPlanCoverages(string CoverageName, string CoverageAmount)
		{

            this.CoverageName = CoverageName;
            this.CoverageAmount = CoverageAmount;

		}

		public override string ToString()
		{
            return "CoverageName = " + CoverageName.ToString() + ",CoverageAmount = " + CoverageAmount;
		}

		
	}
}
