using System;
using System.Text;

namespace PA.BusinessObjects
{
	[Serializable()]
	public class PATransLongNames
	{
		private string _JobNo;

		public string JobNo
		{
			get { return _JobNo; }
			set { _JobNo = value; }
		}

		private string _LongName1;

		public string LongName1
		{
			get { return _LongName1; }
			set { _LongName1 = value; }
		}

		private string _LongName2;

		public string LongName2
		{
			get { return _LongName2; }
			set { _LongName2 = value; }
		}

		private string _LongName3;

		public string LongName3
		{
			get { return _LongName3; }
			set { _LongName3 = value; }
		}

		private string _LongName4;

		public string LongName4
		{
			get { return _LongName4; }
			set { _LongName4 = value; }
		}

		private string _Message;

		public string Message
		{
			get { return _Message; }
			set { _Message = value; }
		}

		public PATransLongNames()
		{ }

		public PATransLongNames(string JobNo,string LongName1,string LongName2,string LongName3,string LongName4,string Message)
		{
			this.JobNo = JobNo;
			this.LongName1 = LongName1;
			this.LongName2 = LongName2;
			this.LongName3 = LongName3;
			this.LongName4 = LongName4;
			this.Message = Message;
		}

		public override string ToString()
		{
			return "JobNo = " + JobNo + ",LongName1 = " + LongName1 + ",LongName2 = " + LongName2 + ",LongName3 = " + LongName3 + ",LongName4 = " + LongName4 + ",Message = " + Message;
		}

		public class JobNoComparer : System.Collections.Generic.IComparer<PATransLongNames>
		{
			public SorterMode SorterMode;
			public JobNoComparer()
			{ }
			public JobNoComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<PATransLongNames> Membres
			int System.Collections.Generic.IComparer<PATransLongNames>.Compare(PATransLongNames x, PATransLongNames y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.JobNo.CompareTo(x.JobNo);
				}
				else
				{
					return x.JobNo.CompareTo(y.JobNo);
				}
			}
			#endregion
		}
		public class LongName1Comparer : System.Collections.Generic.IComparer<PATransLongNames>
		{
			public SorterMode SorterMode;
			public LongName1Comparer()
			{ }
			public LongName1Comparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<PATransLongNames> Membres
			int System.Collections.Generic.IComparer<PATransLongNames>.Compare(PATransLongNames x, PATransLongNames y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.LongName1.CompareTo(x.LongName1);
				}
				else
				{
					return x.LongName1.CompareTo(y.LongName1);
				}
			}
			#endregion
		}
		public class LongName2Comparer : System.Collections.Generic.IComparer<PATransLongNames>
		{
			public SorterMode SorterMode;
			public LongName2Comparer()
			{ }
			public LongName2Comparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<PATransLongNames> Membres
			int System.Collections.Generic.IComparer<PATransLongNames>.Compare(PATransLongNames x, PATransLongNames y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.LongName2.CompareTo(x.LongName2);
				}
				else
				{
					return x.LongName2.CompareTo(y.LongName2);
				}
			}
			#endregion
		}
		public class LongName3Comparer : System.Collections.Generic.IComparer<PATransLongNames>
		{
			public SorterMode SorterMode;
			public LongName3Comparer()
			{ }
			public LongName3Comparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<PATransLongNames> Membres
			int System.Collections.Generic.IComparer<PATransLongNames>.Compare(PATransLongNames x, PATransLongNames y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.LongName3.CompareTo(x.LongName3);
				}
				else
				{
					return x.LongName3.CompareTo(y.LongName3);
				}
			}
			#endregion
		}
		public class LongName4Comparer : System.Collections.Generic.IComparer<PATransLongNames>
		{
			public SorterMode SorterMode;
			public LongName4Comparer()
			{ }
			public LongName4Comparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<PATransLongNames> Membres
			int System.Collections.Generic.IComparer<PATransLongNames>.Compare(PATransLongNames x, PATransLongNames y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.LongName4.CompareTo(x.LongName4);
				}
				else
				{
					return x.LongName4.CompareTo(y.LongName4);
				}
			}
			#endregion
		}
		public class MessageComparer : System.Collections.Generic.IComparer<PATransLongNames>
		{
			public SorterMode SorterMode;
			public MessageComparer()
			{ }
			public MessageComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<PATransLongNames> Membres
			int System.Collections.Generic.IComparer<PATransLongNames>.Compare(PATransLongNames x, PATransLongNames y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.Message.CompareTo(x.Message);
				}
				else
				{
					return x.Message.CompareTo(y.Message);
				}
			}
			#endregion
		}
	}
}
