using System;
using System.Text;

namespace PA.BusinessObjects
{
	[Serializable()]
	public class PATransPolicyHolders
	{
		private string _JobNo;

		public string JobNo
		{
			get { return _JobNo; }
			set { _JobNo = value; }
		}

		private string _ClientCode;

		public string ClientCode
		{
			get { return _ClientCode; }
			set { _ClientCode = value; }
		}

		private string _ClientType;

		public string ClientType
		{
			get { return _ClientType; }
			set { _ClientType = value; }
		}

		private string _ClientTitle;

		public string ClientTitle
		{
			get { return _ClientTitle; }
			set { _ClientTitle = value; }
		}

		private string _ClientName;

		public string ClientName
		{
			get { return _ClientName; }
			set { _ClientName = value; }
		}

		private string _ClientSurName;

		public string ClientSurName
		{
			get { return _ClientSurName; }
			set { _ClientSurName = value; }
		}

		private string _AddressNo;

		public string AddressNo
		{
			get { return _AddressNo; }
			set { _AddressNo = value; }
		}

		private string _Building;

		public string Building
		{
			get { return _Building; }
			set { _Building = value; }
		}

		private string _Soi;

		public string Soi
		{
			get { return _Soi; }
			set { _Soi = value; }
		}

		private string _Road;

		public string Road
		{
			get { return _Road; }
			set { _Road = value; }
		}

		private string _Tumbol;

		public string Tumbol
		{
			get { return _Tumbol; }
			set { _Tumbol = value; }
		}

		private string _Amphur;

		public string Amphur
		{
			get { return _Amphur; }
			set { _Amphur = value; }
		}

		private string _Province;

		public string Province
		{
			get { return _Province; }
			set { _Province = value; }
		}

		private string _PostCode;

		public string PostCode
		{
			get { return _PostCode; }
			set { _PostCode = value; }
		}

		private string _CountryCode;

		public string CountryCode
		{
			get { return _CountryCode; }
			set { _CountryCode = value; }
		}

		private string _Birthday;

		public string Birthday
		{
			get { return _Birthday; }
			set { _Birthday = value; }
		}

		private string _ClientGender;

		public string ClientGender
		{
			get { return _ClientGender; }
			set { _ClientGender = value; }
		}

		private string _ClientStatus;

		public string ClientStatus
		{
			get { return _ClientStatus; }
			set { _ClientStatus = value; }
		}

		private string _PassportID;

		public string PassportID
		{
			get { return _PassportID; }
			set { _PassportID = value; }
		}

		private string _IDCard;

		public string IDCard
		{
			get { return _IDCard; }
			set { _IDCard = value; }
		}

		private string _TaxID;

		public string TaxID
		{
			get { return _TaxID; }
			set { _TaxID = value; }
		}

		private string _Tel;

		public string Tel
		{
			get { return _Tel; }
			set { _Tel = value; }
		}

		private string _Email;

		public string Email
		{
			get { return _Email; }
			set { _Email = value; }
		}

		private string _Language;

		public string Language
		{
			get { return _Language; }
			set { _Language = value; }
		}

        private string _BranchNo;

        public string BranchNo
        {
            get { return _BranchNo; }
            set { _BranchNo = value; }
        }

		private Nullable<DateTime> _CreateDate;

		public Nullable<DateTime> CreateDate
		{
			get { return _CreateDate; }
			set { _CreateDate = value; }
		}

		private string _Message;

		public string Message
		{
			get { return _Message; }
			set { _Message = value; }
		}

		public PATransPolicyHolders()
		{ }

		public PATransPolicyHolders(string JobNo,string ClientCode,string ClientType,string ClientTitle,string ClientName,string ClientSurName,string AddressNo,string Building,string Soi,string Road,string Tumbol,string Amphur,string Province,string PostCode,string CountryCode,string Birthday,string ClientGender,string ClientStatus,string PassportID,string IDCard,string TaxID,string Tel,string Email,string Language,Nullable<DateTime> CreateDate,string Message)
		{
			this.JobNo = JobNo;
			this.ClientCode = ClientCode;
			this.ClientType = ClientType;
			this.ClientTitle = ClientTitle;
			this.ClientName = ClientName;
			this.ClientSurName = ClientSurName;
			this.AddressNo = AddressNo;
			this.Building = Building;
			this.Soi = Soi;
			this.Road = Road;
			this.Tumbol = Tumbol;
			this.Amphur = Amphur;
			this.Province = Province;
			this.PostCode = PostCode;
			this.CountryCode = CountryCode;
			this.Birthday = Birthday;
			this.ClientGender = ClientGender;
			this.ClientStatus = ClientStatus;
			this.PassportID = PassportID;
			this.IDCard = IDCard;
			this.TaxID = TaxID;
			this.Tel = Tel;
			this.Email = Email;
			this.Language = Language;
			this.CreateDate = CreateDate;
			this.Message = Message;
		}

		public override string ToString()
		{
			return "JobNo = " + JobNo + ",ClientCode = " + ClientCode + ",ClientType = " + ClientType + ",ClientTitle = " + ClientTitle + ",ClientName = " + ClientName + ",ClientSurName = " + ClientSurName + ",AddressNo = " + AddressNo + ",Building = " + Building + ",Soi = " + Soi + ",Road = " + Road + ",Tumbol = " + Tumbol + ",Amphur = " + Amphur + ",Province = " + Province + ",PostCode = " + PostCode + ",CountryCode = " + CountryCode + ",Birthday = " + Birthday + ",ClientGender = " + ClientGender + ",ClientStatus = " + ClientStatus + ",PassportID = " + PassportID + ",IDCard = " + IDCard + ",TaxID = " + TaxID + ",Tel = " + Tel + ",Email = " + Email + ",Language = " + Language + ",CreateDate = " + CreateDate.ToString() + ",Message = " + Message;
		}

	}
}
