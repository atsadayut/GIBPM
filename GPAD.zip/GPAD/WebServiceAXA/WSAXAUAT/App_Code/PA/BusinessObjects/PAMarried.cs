using System;
using System.Text;

namespace PA.BusinessObjects
{
	[Serializable()]
	public class PAMarried
	{
		private int _MarriedCode;

		public int MarriedCode
		{
			get { return _MarriedCode; }
			set { _MarriedCode = value; }
		}

		private string _Married;

		public string Married
		{
			get { return _Married; }
			set { _Married = value; }
		}


		public PAMarried()
		{ }

        public PAMarried(int MarriedCode, string Married)
		{
			this.MarriedCode = MarriedCode;
			this.Married = Married;

		}

		public override string ToString()
		{
			return "MarriedCode = " + MarriedCode.ToString() + ",Married = " + Married;
		}


	}
}
