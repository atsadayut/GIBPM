using System;
using System.Text;

namespace PA.BusinessObjects
{
	[Serializable()]
	public class PAPlanPremiums
	{
		private string _PlanCode;

		public string PlanCode
		{
			get { return _PlanCode; }
			set { _PlanCode = value; }
		}

		private string _PlanName;

		public string PlanName
		{
			get { return _PlanName; }
			set { _PlanName = value; }
		}

		private Nullable<int> _SumInsuredPA2;

		public Nullable<int> SumInsuredPA2
		{
			get { return _SumInsuredPA2; }
			set { _SumInsuredPA2 = value; }
		}

		private Nullable<int> _SumInsuredME;

		public Nullable<int> SumInsuredME
		{
			get { return _SumInsuredME; }
			set { _SumInsuredME = value; }
		}

		private Nullable<int> _PremiumPA2;

		public Nullable<int> PremiumPA2
		{
			get { return _PremiumPA2; }
			set { _PremiumPA2 = value; }
		}

		private Nullable<int> _PremiumME;

		public Nullable<int> PremiumME
		{
			get { return _PremiumME; }
			set { _PremiumME = value; }
		}

		private Nullable<int> _AddPremium;

		public Nullable<int> AddPremium
		{
			get { return _AddPremium; }
			set { _AddPremium = value; }
		}

		private Nullable<int> _GrossPremium;

		public Nullable<int> GrossPremium
		{
			get { return _GrossPremium; }
			set { _GrossPremium = value; }
		}

		private Nullable<int> _Stamp;

		public Nullable<int> Stamp
		{
			get { return _Stamp; }
			set { _Stamp = value; }
		}

		private Nullable<int> _SBT;

		public Nullable<int> SBT
		{
			get { return _SBT; }
			set { _SBT = value; }
		}

		private Nullable<int> _TotalPremium;

		public Nullable<int> TotalPremium
		{
			get { return _TotalPremium; }
			set { _TotalPremium = value; }
		}

		private string _PreprintedClauses1;

		public string PreprintedClauses1
		{
			get { return _PreprintedClauses1; }
			set { _PreprintedClauses1 = value; }
		}

		private string _PreprintedClauses2;

		public string PreprintedClauses2
		{
			get { return _PreprintedClauses2; }
			set { _PreprintedClauses2 = value; }
		}

		private string _PreprintedClauses3;

		public string PreprintedClauses3
		{
			get { return _PreprintedClauses3; }
			set { _PreprintedClauses3 = value; }
		}

		private string _ClauseCodes1;

		public string ClauseCodes1
		{
			get { return _ClauseCodes1; }
			set { _ClauseCodes1 = value; }
		}

		private string _ClauseCodes2;

		public string ClauseCodes2
		{
			get { return _ClauseCodes2; }
			set { _ClauseCodes2 = value; }
		}

		private string _ClauseCodes3;

		public string ClauseCodes3
		{
			get { return _ClauseCodes3; }
			set { _ClauseCodes3 = value; }
		}

		private Nullable<SByte> _isEnable;

		public Nullable<SByte> isEnable
		{
			get { return _isEnable; }
			set { _isEnable = value; }
		}

		private Nullable<DateTime> _CreatedDate;

		public Nullable<DateTime> CreatedDate
		{
			get { return _CreatedDate; }
			set { _CreatedDate = value; }
		}

		private string _CreatedUser;

		public string CreatedUser
		{
			get { return _CreatedUser; }
			set { _CreatedUser = value; }
		}

		public PAPlanPremiums()
		{ }

		public PAPlanPremiums(string PlanCode,string PlanName,Nullable<int> SumInsuredPA2,Nullable<int> SumInsuredME,Nullable<int> PremiumPA2,Nullable<int> PremiumME,Nullable<int> AddPremium,Nullable<int> GrossPremium,Nullable<int> Stamp,Nullable<int> SBT,Nullable<int> TotalPremium,string PreprintedClauses1,string PreprintedClauses2,string PreprintedClauses3,string ClauseCodes1,string ClauseCodes2,string ClauseCodes3,Nullable<SByte> isEnable,Nullable<DateTime> CreatedDate,string CreatedUser)
		{
			this.PlanCode = PlanCode;
			this.PlanName = PlanName;
			this.SumInsuredPA2 = SumInsuredPA2;
			this.SumInsuredME = SumInsuredME;
			this.PremiumPA2 = PremiumPA2;
			this.PremiumME = PremiumME;
			this.AddPremium = AddPremium;
			this.GrossPremium = GrossPremium;
			this.Stamp = Stamp;
			this.SBT = SBT;
			this.TotalPremium = TotalPremium;
			this.PreprintedClauses1 = PreprintedClauses1;
			this.PreprintedClauses2 = PreprintedClauses2;
			this.PreprintedClauses3 = PreprintedClauses3;
			this.ClauseCodes1 = ClauseCodes1;
			this.ClauseCodes2 = ClauseCodes2;
			this.ClauseCodes3 = ClauseCodes3;
			this.isEnable = isEnable;
			this.CreatedDate = CreatedDate;
			this.CreatedUser = CreatedUser;
		}

		public override string ToString()
		{
			return "PlanCode = " + PlanCode + ",PlanName = " + PlanName + ",SumInsuredPA2 = " + SumInsuredPA2.ToString() + ",SumInsuredME = " + SumInsuredME.ToString() + ",PremiumPA2 = " + PremiumPA2.ToString() + ",PremiumME = " + PremiumME.ToString() + ",AddPremium = " + AddPremium.ToString() + ",GrossPremium = " + GrossPremium.ToString() + ",Stamp = " + Stamp.ToString() + ",SBT = " + SBT.ToString() + ",TotalPremium = " + TotalPremium.ToString() + ",PreprintedClauses1 = " + PreprintedClauses1 + ",PreprintedClauses2 = " + PreprintedClauses2 + ",PreprintedClauses3 = " + PreprintedClauses3 + ",ClauseCodes1 = " + ClauseCodes1 + ",ClauseCodes2 = " + ClauseCodes2 + ",ClauseCodes3 = " + ClauseCodes3 + ",isEnable = " + isEnable.ToString() + ",CreatedDate = " + CreatedDate.ToString() + ",CreatedUser = " + CreatedUser;
		}

		public class PlanCodeComparer : System.Collections.Generic.IComparer<PAPlanPremiums>
		{
			public SorterMode SorterMode;
			public PlanCodeComparer()
			{ }
			public PlanCodeComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<PAPlanPremiums> Membres
			int System.Collections.Generic.IComparer<PAPlanPremiums>.Compare(PAPlanPremiums x, PAPlanPremiums y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PlanCode.CompareTo(x.PlanCode);
				}
				else
				{
					return x.PlanCode.CompareTo(y.PlanCode);
				}
			}
			#endregion
		}
		public class PlanNameComparer : System.Collections.Generic.IComparer<PAPlanPremiums>
		{
			public SorterMode SorterMode;
			public PlanNameComparer()
			{ }
			public PlanNameComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<PAPlanPremiums> Membres
			int System.Collections.Generic.IComparer<PAPlanPremiums>.Compare(PAPlanPremiums x, PAPlanPremiums y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PlanName.CompareTo(x.PlanName);
				}
				else
				{
					return x.PlanName.CompareTo(y.PlanName);
				}
			}
			#endregion
		}
		public class PreprintedClauses1Comparer : System.Collections.Generic.IComparer<PAPlanPremiums>
		{
			public SorterMode SorterMode;
			public PreprintedClauses1Comparer()
			{ }
			public PreprintedClauses1Comparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<PAPlanPremiums> Membres
			int System.Collections.Generic.IComparer<PAPlanPremiums>.Compare(PAPlanPremiums x, PAPlanPremiums y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PreprintedClauses1.CompareTo(x.PreprintedClauses1);
				}
				else
				{
					return x.PreprintedClauses1.CompareTo(y.PreprintedClauses1);
				}
			}
			#endregion
		}
		public class PreprintedClauses2Comparer : System.Collections.Generic.IComparer<PAPlanPremiums>
		{
			public SorterMode SorterMode;
			public PreprintedClauses2Comparer()
			{ }
			public PreprintedClauses2Comparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<PAPlanPremiums> Membres
			int System.Collections.Generic.IComparer<PAPlanPremiums>.Compare(PAPlanPremiums x, PAPlanPremiums y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PreprintedClauses2.CompareTo(x.PreprintedClauses2);
				}
				else
				{
					return x.PreprintedClauses2.CompareTo(y.PreprintedClauses2);
				}
			}
			#endregion
		}
		public class PreprintedClauses3Comparer : System.Collections.Generic.IComparer<PAPlanPremiums>
		{
			public SorterMode SorterMode;
			public PreprintedClauses3Comparer()
			{ }
			public PreprintedClauses3Comparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<PAPlanPremiums> Membres
			int System.Collections.Generic.IComparer<PAPlanPremiums>.Compare(PAPlanPremiums x, PAPlanPremiums y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PreprintedClauses3.CompareTo(x.PreprintedClauses3);
				}
				else
				{
					return x.PreprintedClauses3.CompareTo(y.PreprintedClauses3);
				}
			}
			#endregion
		}
		public class ClauseCodes1Comparer : System.Collections.Generic.IComparer<PAPlanPremiums>
		{
			public SorterMode SorterMode;
			public ClauseCodes1Comparer()
			{ }
			public ClauseCodes1Comparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<PAPlanPremiums> Membres
			int System.Collections.Generic.IComparer<PAPlanPremiums>.Compare(PAPlanPremiums x, PAPlanPremiums y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ClauseCodes1.CompareTo(x.ClauseCodes1);
				}
				else
				{
					return x.ClauseCodes1.CompareTo(y.ClauseCodes1);
				}
			}
			#endregion
		}
		public class ClauseCodes2Comparer : System.Collections.Generic.IComparer<PAPlanPremiums>
		{
			public SorterMode SorterMode;
			public ClauseCodes2Comparer()
			{ }
			public ClauseCodes2Comparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<PAPlanPremiums> Membres
			int System.Collections.Generic.IComparer<PAPlanPremiums>.Compare(PAPlanPremiums x, PAPlanPremiums y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ClauseCodes2.CompareTo(x.ClauseCodes2);
				}
				else
				{
					return x.ClauseCodes2.CompareTo(y.ClauseCodes2);
				}
			}
			#endregion
		}
		public class ClauseCodes3Comparer : System.Collections.Generic.IComparer<PAPlanPremiums>
		{
			public SorterMode SorterMode;
			public ClauseCodes3Comparer()
			{ }
			public ClauseCodes3Comparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<PAPlanPremiums> Membres
			int System.Collections.Generic.IComparer<PAPlanPremiums>.Compare(PAPlanPremiums x, PAPlanPremiums y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.ClauseCodes3.CompareTo(x.ClauseCodes3);
				}
				else
				{
					return x.ClauseCodes3.CompareTo(y.ClauseCodes3);
				}
			}
			#endregion
		}
		public class CreatedUserComparer : System.Collections.Generic.IComparer<PAPlanPremiums>
		{
			public SorterMode SorterMode;
			public CreatedUserComparer()
			{ }
			public CreatedUserComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<PAPlanPremiums> Membres
			int System.Collections.Generic.IComparer<PAPlanPremiums>.Compare(PAPlanPremiums x, PAPlanPremiums y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.CreatedUser.CompareTo(x.CreatedUser);
				}
				else
				{
					return x.CreatedUser.CompareTo(y.CreatedUser);
				}
			}
			#endregion
		}
	}
}
