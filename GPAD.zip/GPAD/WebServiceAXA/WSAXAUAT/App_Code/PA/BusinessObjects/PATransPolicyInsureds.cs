using System;
using System.Text;

namespace PA.BusinessObjects
{
	[Serializable()]
	public class PATransPolicyInsureds
	{
		private string _JobNo;

		public string JobNo
		{
			get { return _JobNo; }
			set { _JobNo = value; }
		}

		private int _InsuredID;

		public int InsuredID
		{
			get { return _InsuredID; }
			set { _InsuredID = value; }
		}

		private string _ClientCode;

		public string ClientCode
		{
			get { return _ClientCode; }
			set { _ClientCode = value; }
		}

		private string _ClientTitle;

		public string ClientTitle
		{
			get { return _ClientTitle; }
			set { _ClientTitle = value; }
		}

		private string _ClientName;

		public string ClientName
		{
			get { return _ClientName; }
			set { _ClientName = value; }
		}

		private string _ClientSurName;

		public string ClientSurName
		{
			get { return _ClientSurName; }
			set { _ClientSurName = value; }
		}

		private string _Birthday;

		public string Birthday
		{
			get { return _Birthday; }
			set { _Birthday = value; }
		}

		private string _IDCard;

		public string IDCard
		{
			get { return _IDCard; }
			set { _IDCard = value; }
		}

		private string _PassportID;

		public string PassportID
		{
			get { return _PassportID; }
			set { _PassportID = value; }
		}

		private string _Tel;

		public string Tel
		{
			get { return _Tel; }
			set { _Tel = value; }
		}

		private Nullable<int> _SumInsuredPA2;

		public Nullable<int> SumInsuredPA2
		{
			get { return _SumInsuredPA2; }
			set { _SumInsuredPA2 = value; }
		}

		private Nullable<int> _SumInsuredME;

		public Nullable<int> SumInsuredME
		{
			get { return _SumInsuredME; }
			set { _SumInsuredME = value; }
		}

		private Nullable<int> _PremiumPA2;

		public Nullable<int> PremiumPA2
		{
			get { return _PremiumPA2; }
			set { _PremiumPA2 = value; }
		}

		private Nullable<int> _PremiumME;

		public Nullable<int> PremiumME
		{
			get { return _PremiumME; }
			set { _PremiumME = value; }
		}

		private Nullable<int> _AddPremium;

		public Nullable<int> AddPremium
		{
			get { return _AddPremium; }
			set { _AddPremium = value; }
		}

		private Nullable<int> _GrossPremium;

		public Nullable<int> GrossPremium
		{
			get { return _GrossPremium; }
			set { _GrossPremium = value; }
		}

		private Nullable<int> _Stamp;

		public Nullable<int> Stamp
		{
			get { return _Stamp; }
			set { _Stamp = value; }
		}

		private Nullable<int> _SBT;

		public Nullable<int> SBT
		{
			get { return _SBT; }
			set { _SBT = value; }
		}

		private Nullable<int> _TotalPremium;

		public Nullable<int> TotalPremium
		{
			get { return _TotalPremium; }
			set { _TotalPremium = value; }
		}

		private Nullable<SByte> _isBeneficiary;

		public Nullable<SByte> isBeneficiary
		{
			get { return _isBeneficiary; }
			set { _isBeneficiary = value; }
		}

		private Nullable<SByte> _isStudent;

		public Nullable<SByte> isStudent
		{
			get { return _isStudent; }
			set { _isStudent = value; }
		}

		private Nullable<SByte> _isSingle;

		public Nullable<SByte> isSingle
		{
			get { return _isSingle; }
			set { _isSingle = value; }
		}

		private Nullable<DateTime> _CreateDate;

		public Nullable<DateTime> CreateDate
		{
			get { return _CreateDate; }
			set { _CreateDate = value; }
		}

		private string _Message;

		public string Message
		{
			get { return _Message; }
			set { _Message = value; }
		}

		public PATransPolicyInsureds()
		{ }

		public PATransPolicyInsureds(string JobNo,int InsuredID,string ClientCode,string ClientTitle,string ClientName,string ClientSurName,string Birthday,string IDCard,string PassportID,string Tel,Nullable<int> SumInsuredPA2,Nullable<int> SumInsuredME,Nullable<int> PremiumPA2,Nullable<int> PremiumME,Nullable<int> AddPremium,Nullable<int> GrossPremium,Nullable<int> Stamp,Nullable<int> SBT,Nullable<int> TotalPremium,Nullable<SByte> isBeneficiary,Nullable<SByte> isStudent,Nullable<SByte> isSingle,Nullable<DateTime> CreateDate,string Message)
		{
			this.JobNo = JobNo;
			this.InsuredID = InsuredID;
			this.ClientCode = ClientCode;
			this.ClientTitle = ClientTitle;
			this.ClientName = ClientName;
			this.ClientSurName = ClientSurName;
			this.Birthday = Birthday;
			this.IDCard = IDCard;
			this.PassportID = PassportID;
			this.Tel = Tel;
			this.SumInsuredPA2 = SumInsuredPA2;
			this.SumInsuredME = SumInsuredME;
			this.PremiumPA2 = PremiumPA2;
			this.PremiumME = PremiumME;
			this.AddPremium = AddPremium;
			this.GrossPremium = GrossPremium;
			this.Stamp = Stamp;
			this.SBT = SBT;
			this.TotalPremium = TotalPremium;
			this.isBeneficiary = isBeneficiary;
			this.isStudent = isStudent;
			this.isSingle = isSingle;
			this.CreateDate = CreateDate;
			this.Message = Message;
		}

		public override string ToString()
		{
			return "JobNo = " + JobNo + ",InsuredID = " + InsuredID.ToString() + ",ClientCode = " + ClientCode + ",ClientTitle = " + ClientTitle + ",ClientName = " + ClientName + ",ClientSurName = " + ClientSurName + ",Birthday = " + Birthday + ",IDCard = " + IDCard + ",PassportID = " + PassportID + ",Tel = " + Tel + ",SumInsuredPA2 = " + SumInsuredPA2.ToString() + ",SumInsuredME = " + SumInsuredME.ToString() + ",PremiumPA2 = " + PremiumPA2.ToString() + ",PremiumME = " + PremiumME.ToString() + ",AddPremium = " + AddPremium.ToString() + ",GrossPremium = " + GrossPremium.ToString() + ",Stamp = " + Stamp.ToString() + ",SBT = " + SBT.ToString() + ",TotalPremium = " + TotalPremium.ToString() + ",isBeneficiary = " + isBeneficiary.ToString() + ",isStudent = " + isStudent.ToString() + ",isSingle = " + isSingle.ToString() + ",CreateDate = " + CreateDate.ToString() + ",Message = " + Message;
		}

	}
}
