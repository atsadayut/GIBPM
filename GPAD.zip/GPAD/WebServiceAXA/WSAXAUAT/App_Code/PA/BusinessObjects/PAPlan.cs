using System;
using System.Text;

namespace PA.BusinessObjects
{
	[Serializable()]
	public class PAPlan
	{
		private int _PlanCode;

		public int PlanCode
		{
			get { return _PlanCode; }
			set { _PlanCode = value; }
		}

        private string _PlanName;

		public string PlanName
		{
            get { return _PlanName; }
            set { _PlanName = value; }
		}


		public PAPlan()
		{ }

        public PAPlan(int PlanCode, string PlanName)
		{
			this.PlanCode = PlanCode;
            this.PlanName = PlanName;

		}

		public override string ToString()
		{
            return "PlanCode = " + PlanCode.ToString() + ",PlanName = " + PlanName;
		}


	}
}
