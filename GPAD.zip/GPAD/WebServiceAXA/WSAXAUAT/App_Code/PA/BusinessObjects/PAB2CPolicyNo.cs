using System;
using System.Text;

namespace PA.BusinessObjects
{
	[Serializable()]
	public class PAB2CPolicyNo
	{
		private string _PREFIX;

		public string PREFIX
		{
			get { return _PREFIX; }
			set { _PREFIX = value; }
		}

		private int _RUNNING;

		public int RUNNING
		{
			get { return _RUNNING; }
			set { _RUNNING = value; }
		}

		public PAB2CPolicyNo()
		{ }

		public PAB2CPolicyNo(string PREFIX,int RUNNING)
		{
			this.PREFIX = PREFIX;
			this.RUNNING = RUNNING;
		}

		public override string ToString()
		{
			return "PREFIX = " + PREFIX + ",RUNNING = " + RUNNING.ToString();
		}

		public class PREFIXComparer : System.Collections.Generic.IComparer<PAB2CPolicyNo>
		{
			public SorterMode SorterMode;
			public PREFIXComparer()
			{ }
			public PREFIXComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<PAB2CPolicyNo> Membres
			int System.Collections.Generic.IComparer<PAB2CPolicyNo>.Compare(PAB2CPolicyNo x, PAB2CPolicyNo y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.PREFIX.CompareTo(x.PREFIX);
				}
				else
				{
					return x.PREFIX.CompareTo(y.PREFIX);
				}
			}
			#endregion
		}
		public class RUNNINGComparer : System.Collections.Generic.IComparer<PAB2CPolicyNo>
		{
			public SorterMode SorterMode;
			public RUNNINGComparer()
			{ }
			public RUNNINGComparer(SorterMode SorterMode)
			{
				this.SorterMode = SorterMode;
			}
			#region IComparer<PAB2CPolicyNo> Membres
			int System.Collections.Generic.IComparer<PAB2CPolicyNo>.Compare(PAB2CPolicyNo x, PAB2CPolicyNo y)
			{
				if (SorterMode == SorterMode.Ascending)
				{
					return y.RUNNING.CompareTo(x.RUNNING);
				}
				else
				{
					return x.RUNNING.CompareTo(y.RUNNING);
				}
			}
			#endregion
		}
	}
}
