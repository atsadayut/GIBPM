using System;
using System.Text;

namespace PA.BusinessObjects
{
	[Serializable()]
	public class PANationality
	{
		private int _NationalityCode;

		public int NationalityCode
		{
			get { return _NationalityCode; }
			set { _NationalityCode = value; }
		}

		private string _Nationality;

		public string Nationality
		{
			get { return _Nationality; }
			set { _Nationality = value; }
		}


		public PANationality()
		{ }

        public PANationality(int NationalityCode, string Nationality)
		{
			this.NationalityCode = NationalityCode;
			this.Nationality = Nationality;

		}

		public override string ToString()
		{
			return "NationalityCode = " + NationalityCode.ToString() + ",Nationality = " + Nationality;
		}


	}
}
