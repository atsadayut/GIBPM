﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

using System.Data;
//using TAWS;
using System.IO;
using System.Net;
//using PAWS;
//using broker_test;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        

        try
        {
            
/*            //-------------- Policy Type = INDIVIDUAL --------------------
            string language = "E";

            ObjAXATAPolicyHolderDetail personal = new ObjAXATAPolicyHolderDetail();
            personal._clientType = "P";
            personal._clientTitle = "Mr.";
            personal._clientName = "Name";
            personal._clientSurName = "SurName";
            personal._branchNo = "";
            personal._birthday = "15/10/1980";

            personal._clientAddress1 = "Address";
            personal._clientAddress2 = "";
            personal._amphur = "Amphur";
            personal._tumbol = "Tumbol";
            personal._province = "Province";
            personal._amphurID = "";
            personal._tumbolID = "";
            personal._provinceID = "";
            personal._email = "email";
            personal._postCode = "1100";
            personal._tel = "201112223";

            ObjAXATATravellerDetail[] tra1 = new ObjAXATATravellerDetail[1];

            ObjAXATATravellerDetail temp = new ObjAXATATravellerDetail();
            temp._clientTitle = "InsuredTitle1";
            temp._clientName = "InsuredName1";
            temp._clientSurName = "InsuredSurname1";
            temp._birthday = "11/11/1999";
            temp._passportID = "EXAA112";
            temp._beneficiary = "ESTATE OF THE INSURED PERSON";
            tra1[0] = temp;


            ObjAXATATravellerDetail[] tra2 = new ObjAXATATravellerDetail[0];
            //tra2[0] = temp;


            INF_AXATAWS testcall = new INF_AXATAWS();
            ObjAXATAPolicyIssued policy = testcall.ProcessAXATAPolicyIssue("BD039", "BK001", "Password@1", language, "JAPAN", "15/08/2014", "15/08/2014", "INDIVIDUAL", "0001", personal, tra1, tra2, "TEST01", true, "ftp://118.174.139.78/IN", "ftpuser", "Qazxsw987", "ak13ok@gmail.com");
            
            Response.Write(policy._msg + "," + policy._deliverDocMsg + "," + policy._policyNo);
            */
            //----------------- Poilcy Type = FAMILY------------------------
            /*string language = "E";

            ObjAXATAPolicyHolderDetail personal = new ObjAXATAPolicyHolderDetail();
            personal._clientType = "P";
            personal._clientTitle = "Mr.";
            personal._clientName = "Name";
            personal._clientSurName = "SurName";
            personal._branchNo = "";
            personal._birthday = "15/10/1980";

            personal._clientAddress1 = "Address";
            personal._clientAddress2 = "";
            personal._amphur = "Amphur";
            personal._tumbol = "Tumbol";
            personal._province = "Province";
            personal._amphurID = "";
            personal._tumbolID = "";
            personal._provinceID = "";
            personal._email = "mail";
            personal._postCode = "1100";
            personal._tel = "201112223";

            ObjAXATATravellerDetail[] tra1 = new ObjAXATATravellerDetail[2];

            ObjAXATATravellerDetail temp = new ObjAXATATravellerDetail();
            temp._clientTitle = "InsuredTitle1";
            temp._clientName = "Father";
            temp._clientSurName = "Insured1";
            temp._birthday = "11/11/1989";
            temp._passportID = "EXAA112";
            temp._beneficiary = "ESTATE OF THE INSURED PERSON";

            tra1[0] = temp;

            ObjAXATATravellerDetail temp2 = new ObjAXATATravellerDetail();
            temp2._clientTitle = "InsuredTitle2";
            temp2._clientName = "Mother";
            temp2._clientSurName = "Insured2";
            temp2._birthday = "11/11/1989";
            temp2._passportID = "EXAA112";
            temp2._beneficiary = "ESTATE OF THE INSURED PERSON";

            tra1[1] = temp2;



            ObjAXATATravellerDetail[] tra2 = new ObjAXATATravellerDetail[1];

            ObjAXATATravellerDetail temp3 = new ObjAXATATravellerDetail();
            temp3._clientTitle = "InsuredTitle1";
            temp3._clientName = "Child1";
            temp3._clientSurName = "Insured1";
            temp3._birthday = "11/11/2000";
            temp3._passportID = "EXAA112";
            temp3._beneficiary = "ESTATE OF THE INSURED PERSON";

            tra2[0] = temp3;


            INF_AXATAWS testcall = new INF_AXATAWS();
            ObjAXATAPolicyIssued policy = testcall.ProcessAXATAPolicyIssue("BD039", "BK001", "Password@1", language, "JAPAN", "15/08/2014", "15/08/2014", "FAMILY", "0001", personal, tra1, tra2, "TEST01", false, "", "", "", "mail@broker.get");
            */
            /*
            ObjAXAPAPolicyHolderDetail p_holder = new ObjAXAPAPolicyHolderDetail();
            p_holder._clientType = "P";
            p_holder._clientTitle = "Kun";
            p_holder._clientName = "Name";
            p_holder._clientSurName = "Surname";
            p_holder._email = "mail";
            p_holder._idCard = "AK10001";
            p_holder._gender = "Z";
            p_holder._maritalStatus = "Z";
            p_holder._nationlity = "TH";
            p_holder._birthday = "15/01/1980";
            p_holder._addressNo = "102/11";
            p_holder._building = "building";
            p_holder._road = "road";
            p_holder._soi = "soi";
            p_holder._province = "province";
            p_holder._provinceID = "";
            p_holder._tumbol = "tumbol";
            p_holder._tumbolID = "";
            p_holder._amphur = "amphur";
            p_holder._amphurID = "";
            p_holder._postCode = "10321";
            p_holder._tel = "010042111";

            ObjAXAPAAdultDetail[] adult = new ObjAXAPAAdultDetail[1];

            ObjAXAPAAdultDetail temp = new ObjAXAPAAdultDetail();
            temp._clientTitle = "InsuredTitle1";
            temp._clientName = "Father";
            temp._clientSurName = "Insured1";
            temp._birthday = "11/11/1989";
            temp._idCard = "EXAA112";
            temp._beneficiary = new ObjAXAPABeneficialy[0];

            adult[0] = temp;


            ObjAXAPAChildDetail[] child = new ObjAXAPAChildDetail[0];


            INF_AXAPAWS testcall = new INF_AXAPAWS();
            //ObjAXAPAPolicyIssued policy= testcall.ProcessAXAPAPolicyIssue("BD039", "BK001", "Password@1", "T", "14/08/2014", "14/08/2015", "11/11/1989", "0002", "กิจการค้าวัสดุก่อสร้าง", "1A", p_holder, adult, child, "TEST!", false, "ftp://118.174.139.78/IN", "ftpuser", "Qazxsw987", "ak13ok@gmail.com");

            //ObjAXAPAListOccupation occ = policy.GetAXAPAOccupation("BD039", "BK001", "Password@1", "T");
            //Response.Write(occ._msg + "," + occ._listPAOccupation[0]._description);

            //ObjAXAPAListPlanInsure plan = policy.GetAXAPAPlanInsure("BD039", "BK001", "Password@1", "T", "0002", "กิจการค้าวัสดุก่อสร้าง");
            //Response.Write(plan._msg + "," + plan._listPAPlanInsure[0]._planCode);

            //ObjAXAPAListPlanCoverage cover = policy.GetAXAPAPlanCoverage("BD039", "BK001", "Password@1", "T", "1A", "กิจการค้าวัสดุก่อสร้าง");
            //Response.Write(cover._msg + "," + cover._listPAPlanCoverage.Length);
            //Response.Write(policy._msg + "," + policy._deliverDocMsg + "," + policy._policyNo);
             
             
            */
            Response.Write(UploadFileToFTP("Q8000002", "ftp://118.174.139.78/IN/", "ftpuser", "Qazxsw987"));
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    private string UploadFileToFTP(string PolicyNo, string _UploadPath, string _FTPUser, string _FTPPass)
    {
        string retMsg = string.Empty;

        try
        {
            string type = "00";
            string path = path = Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "/DOC/" + PolicyNo);
            string filename = PolicyNo + type + ".pdf";
            string filePath = path + "\\" + filename;


            FileStream stream = File.OpenRead(filePath);
            byte[] myData = new Byte[stream.Length];
            stream.Read(myData, 0, myData.Length);
            stream.Close();

            string ftpfullpath = _UploadPath + filename;
            FtpWebRequest ftp = (FtpWebRequest)FtpWebRequest.Create(ftpfullpath);
            ftp.Credentials = new NetworkCredential(_FTPUser, _FTPPass);

            ftp.KeepAlive = true;
            ftp.UseBinary = true;
            ftp.Timeout = 20000; // 20 sec
            ftp.Method = WebRequestMethods.Ftp.UploadFile;

            //FileStream fs = File.OpenRead(_FileName);
            //byte[] buffer = new byte[fs.Length];
            //fs.Read(buffer, 0, buffer.Length);
            //fs.Close();

            Stream ftpstream = ftp.GetRequestStream();
            ftpstream.Write(myData, 0, myData.Length);
            ftpstream.Close();

            retMsg = "SUCCESS";
        }
        catch (Exception ex)
        {
            //Utilities.LogError(ex);
            retMsg = ex.Message.ToString();
        }

        return retMsg;
    }    
}