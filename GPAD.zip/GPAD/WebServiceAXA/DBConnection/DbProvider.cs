﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBConnection
{
    public class DbProvider
    {
        protected string connectionString = String.Empty;

        public DbProvider()
        {

        }

        public DbProvider(string connection)
        {
            connectionString = connection;
        }
    }
}
