﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;

namespace DBConnection
{
    public class SqlDbProvider : DbProvider
    {
        protected SqlConnection sqlConn = new SqlConnection();
        protected SqlCommand sqlComm = new SqlCommand();
        protected SqlDataAdapter sqlAdp = new SqlDataAdapter();

        protected SqlTransaction sqlTransaction;

        public SqlDbProvider()
        {

        }

        public SqlDbProvider(string connection):base(connection)
        {
            sqlConn.ConnectionString = connection;
        }

        public void BeginTransaction()
        {
            sqlTransaction = sqlConn.BeginTransaction();
        }

        public void CommitTransaction()
        {
            sqlTransaction.Commit();
        }

        public void RollbackTransaction()
        {
            sqlTransaction.Rollback();
        }

        public void Disponse()
        {
            sqlConn.Close();
            sqlConn.Dispose();
            sqlComm.Dispose();

            GC.SuppressFinalize(this);
        }
    }
}
